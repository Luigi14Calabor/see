<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-19 01:03:14 --> Config Class Initialized
DEBUG - 2011-05-19 01:03:14 --> Hooks Class Initialized
DEBUG - 2011-05-19 01:03:14 --> Utf8 Class Initialized
DEBUG - 2011-05-19 01:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 01:03:14 --> URI Class Initialized
DEBUG - 2011-05-19 01:03:14 --> Router Class Initialized
ERROR - 2011-05-19 01:03:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-19 01:29:46 --> Config Class Initialized
DEBUG - 2011-05-19 01:29:46 --> Hooks Class Initialized
DEBUG - 2011-05-19 01:29:46 --> Utf8 Class Initialized
DEBUG - 2011-05-19 01:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 01:29:46 --> URI Class Initialized
DEBUG - 2011-05-19 01:29:46 --> Router Class Initialized
DEBUG - 2011-05-19 01:29:46 --> Output Class Initialized
DEBUG - 2011-05-19 01:29:46 --> Input Class Initialized
DEBUG - 2011-05-19 01:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 01:29:47 --> Language Class Initialized
DEBUG - 2011-05-19 01:29:47 --> Loader Class Initialized
DEBUG - 2011-05-19 01:29:48 --> Controller Class Initialized
ERROR - 2011-05-19 01:29:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 01:29:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 01:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 01:29:48 --> Model Class Initialized
DEBUG - 2011-05-19 01:29:48 --> Model Class Initialized
DEBUG - 2011-05-19 01:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 01:29:48 --> Database Driver Class Initialized
DEBUG - 2011-05-19 01:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 01:29:48 --> Helper loaded: url_helper
DEBUG - 2011-05-19 01:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 01:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 01:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 01:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 01:29:48 --> Final output sent to browser
DEBUG - 2011-05-19 01:29:48 --> Total execution time: 2.2669
DEBUG - 2011-05-19 03:46:42 --> Config Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Hooks Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Utf8 Class Initialized
DEBUG - 2011-05-19 03:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 03:46:42 --> URI Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Router Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Output Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Input Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 03:46:42 --> Language Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Loader Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Controller Class Initialized
ERROR - 2011-05-19 03:46:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 03:46:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 03:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 03:46:42 --> Model Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Model Class Initialized
DEBUG - 2011-05-19 03:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 03:46:42 --> Database Driver Class Initialized
DEBUG - 2011-05-19 03:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 03:46:43 --> Helper loaded: url_helper
DEBUG - 2011-05-19 03:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 03:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 03:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 03:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 03:46:43 --> Final output sent to browser
DEBUG - 2011-05-19 03:46:43 --> Total execution time: 1.6144
DEBUG - 2011-05-19 03:46:46 --> Config Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Hooks Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Utf8 Class Initialized
DEBUG - 2011-05-19 03:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 03:46:46 --> URI Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Router Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Output Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Input Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 03:46:46 --> Language Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Loader Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Controller Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Model Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Model Class Initialized
DEBUG - 2011-05-19 03:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 03:46:46 --> Database Driver Class Initialized
DEBUG - 2011-05-19 03:46:48 --> Final output sent to browser
DEBUG - 2011-05-19 03:46:48 --> Total execution time: 1.7512
DEBUG - 2011-05-19 03:46:56 --> Config Class Initialized
DEBUG - 2011-05-19 03:46:56 --> Hooks Class Initialized
DEBUG - 2011-05-19 03:46:56 --> Utf8 Class Initialized
DEBUG - 2011-05-19 03:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 03:46:56 --> URI Class Initialized
DEBUG - 2011-05-19 03:46:56 --> Router Class Initialized
ERROR - 2011-05-19 03:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:16:36 --> Config Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:16:36 --> URI Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Router Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Output Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Input Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:16:36 --> Language Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Loader Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Controller Class Initialized
ERROR - 2011-05-19 04:16:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:16:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:16:36 --> Model Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Model Class Initialized
DEBUG - 2011-05-19 04:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:16:36 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:16:36 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:16:36 --> Final output sent to browser
DEBUG - 2011-05-19 04:16:36 --> Total execution time: 0.3897
DEBUG - 2011-05-19 04:16:38 --> Config Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:16:38 --> URI Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Router Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Output Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Input Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:16:38 --> Language Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Loader Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Controller Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Model Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Model Class Initialized
DEBUG - 2011-05-19 04:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:16:38 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:16:39 --> Final output sent to browser
DEBUG - 2011-05-19 04:16:39 --> Total execution time: 1.0147
DEBUG - 2011-05-19 04:16:40 --> Config Class Initialized
DEBUG - 2011-05-19 04:16:40 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:16:40 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:16:40 --> URI Class Initialized
DEBUG - 2011-05-19 04:16:40 --> Router Class Initialized
ERROR - 2011-05-19 04:16:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:17:12 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:12 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:12 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:12 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:12 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:12 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:12 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:12 --> Total execution time: 0.1085
DEBUG - 2011-05-19 04:17:13 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:13 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:13 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Controller Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:13 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:14 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:14 --> Total execution time: 0.7165
DEBUG - 2011-05-19 04:17:16 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:16 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:16 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:16 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:16 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:16 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:16 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:16 --> Total execution time: 0.0307
DEBUG - 2011-05-19 04:17:16 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:16 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:16 --> Router Class Initialized
ERROR - 2011-05-19 04:17:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:17:23 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:23 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:23 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:23 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:23 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:23 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:23 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:23 --> Total execution time: 0.0272
DEBUG - 2011-05-19 04:17:24 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:24 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:24 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Controller Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:24 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:24 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:24 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:24 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:24 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:24 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:24 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:24 --> Total execution time: 0.0286
DEBUG - 2011-05-19 04:17:25 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:25 --> Total execution time: 0.5881
DEBUG - 2011-05-19 04:17:25 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:25 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:25 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:25 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:25 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:25 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:25 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:25 --> Total execution time: 0.0300
DEBUG - 2011-05-19 04:17:26 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:26 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:26 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:26 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:26 --> Router Class Initialized
ERROR - 2011-05-19 04:17:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:17:34 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:34 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:34 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:34 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:34 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:34 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:34 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:34 --> Total execution time: 0.0366
DEBUG - 2011-05-19 04:17:35 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:35 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:35 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Controller Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:35 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:35 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:35 --> Total execution time: 0.5223
DEBUG - 2011-05-19 04:17:36 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:36 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:36 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:36 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:36 --> Router Class Initialized
ERROR - 2011-05-19 04:17:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:17:43 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:43 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:43 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:43 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:43 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:43 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:43 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:43 --> Total execution time: 0.0318
DEBUG - 2011-05-19 04:17:44 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:44 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:44 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Controller Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:44 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:44 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:44 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:44 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:44 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:44 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:44 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:44 --> Total execution time: 0.0312
DEBUG - 2011-05-19 04:17:44 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:44 --> Total execution time: 0.4928
DEBUG - 2011-05-19 04:17:47 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:47 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:47 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:47 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:47 --> Router Class Initialized
ERROR - 2011-05-19 04:17:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:17:51 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:51 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:51 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:51 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:51 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:51 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:51 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:51 --> Total execution time: 0.0291
DEBUG - 2011-05-19 04:17:53 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:53 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:53 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Controller Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:53 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:54 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:54 --> Total execution time: 0.8053
DEBUG - 2011-05-19 04:17:55 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:55 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:55 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:55 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:55 --> Router Class Initialized
ERROR - 2011-05-19 04:17:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:17:56 --> Config Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:17:56 --> URI Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Router Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Output Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Input Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:17:56 --> Language Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Loader Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Controller Class Initialized
ERROR - 2011-05-19 04:17:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:17:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:56 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Model Class Initialized
DEBUG - 2011-05-19 04:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:17:56 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:17:56 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:17:56 --> Final output sent to browser
DEBUG - 2011-05-19 04:17:56 --> Total execution time: 0.0805
DEBUG - 2011-05-19 04:18:04 --> Config Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:18:04 --> URI Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Router Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Output Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Input Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:18:04 --> Language Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Loader Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Controller Class Initialized
ERROR - 2011-05-19 04:18:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:18:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:18:04 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:18:04 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:18:04 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:18:04 --> Final output sent to browser
DEBUG - 2011-05-19 04:18:04 --> Total execution time: 0.0341
DEBUG - 2011-05-19 04:18:05 --> Config Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:18:05 --> URI Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Router Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Output Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Input Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:18:05 --> Language Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Loader Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Controller Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:18:05 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:18:05 --> Final output sent to browser
DEBUG - 2011-05-19 04:18:05 --> Total execution time: 0.6382
DEBUG - 2011-05-19 04:18:07 --> Config Class Initialized
DEBUG - 2011-05-19 04:18:07 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:18:07 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:18:07 --> URI Class Initialized
DEBUG - 2011-05-19 04:18:07 --> Router Class Initialized
ERROR - 2011-05-19 04:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 04:18:08 --> Config Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:18:08 --> URI Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Router Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Output Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Input Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:18:08 --> Language Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Loader Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Controller Class Initialized
ERROR - 2011-05-19 04:18:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 04:18:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 04:18:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:18:08 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:18:08 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:18:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 04:18:08 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:18:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:18:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:18:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:18:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:18:08 --> Final output sent to browser
DEBUG - 2011-05-19 04:18:08 --> Total execution time: 0.0327
DEBUG - 2011-05-19 04:18:28 --> Config Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:18:28 --> URI Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Router Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Output Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Input Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 04:18:28 --> Language Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Loader Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Controller Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Model Class Initialized
DEBUG - 2011-05-19 04:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 04:18:28 --> Database Driver Class Initialized
DEBUG - 2011-05-19 04:18:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 04:18:28 --> Helper loaded: url_helper
DEBUG - 2011-05-19 04:18:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 04:18:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 04:18:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 04:18:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 04:18:28 --> Final output sent to browser
DEBUG - 2011-05-19 04:18:28 --> Total execution time: 0.3902
DEBUG - 2011-05-19 04:18:32 --> Config Class Initialized
DEBUG - 2011-05-19 04:18:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 04:18:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 04:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 04:18:32 --> URI Class Initialized
DEBUG - 2011-05-19 04:18:32 --> Router Class Initialized
ERROR - 2011-05-19 04:18:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 05:43:18 --> Config Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Hooks Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Utf8 Class Initialized
DEBUG - 2011-05-19 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 05:43:18 --> URI Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Router Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Output Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Input Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 05:43:18 --> Language Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Loader Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Controller Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-19 05:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 05:43:18 --> Database Driver Class Initialized
DEBUG - 2011-05-19 05:43:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 05:43:19 --> Helper loaded: url_helper
DEBUG - 2011-05-19 05:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 05:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 05:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 05:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 05:43:19 --> Final output sent to browser
DEBUG - 2011-05-19 05:43:19 --> Total execution time: 0.5549
DEBUG - 2011-05-19 05:43:20 --> Config Class Initialized
DEBUG - 2011-05-19 05:43:20 --> Hooks Class Initialized
DEBUG - 2011-05-19 05:43:20 --> Utf8 Class Initialized
DEBUG - 2011-05-19 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 05:43:20 --> URI Class Initialized
DEBUG - 2011-05-19 05:43:20 --> Router Class Initialized
ERROR - 2011-05-19 05:43:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 05:43:20 --> Config Class Initialized
DEBUG - 2011-05-19 05:43:20 --> Hooks Class Initialized
DEBUG - 2011-05-19 05:43:20 --> Utf8 Class Initialized
DEBUG - 2011-05-19 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 05:43:20 --> URI Class Initialized
DEBUG - 2011-05-19 05:43:20 --> Router Class Initialized
ERROR - 2011-05-19 05:43:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 05:43:21 --> Config Class Initialized
DEBUG - 2011-05-19 05:43:21 --> Hooks Class Initialized
DEBUG - 2011-05-19 05:43:21 --> Utf8 Class Initialized
DEBUG - 2011-05-19 05:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 05:43:21 --> URI Class Initialized
DEBUG - 2011-05-19 05:43:21 --> Router Class Initialized
ERROR - 2011-05-19 05:43:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 12:56:43 --> Config Class Initialized
DEBUG - 2011-05-19 12:56:43 --> Hooks Class Initialized
DEBUG - 2011-05-19 12:56:43 --> Utf8 Class Initialized
DEBUG - 2011-05-19 12:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 12:56:43 --> URI Class Initialized
DEBUG - 2011-05-19 12:56:43 --> Router Class Initialized
ERROR - 2011-05-19 12:56:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-19 12:57:38 --> Config Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Hooks Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Utf8 Class Initialized
DEBUG - 2011-05-19 12:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 12:57:38 --> URI Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Router Class Initialized
DEBUG - 2011-05-19 12:57:38 --> No URI present. Default controller set.
DEBUG - 2011-05-19 12:57:38 --> Output Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Input Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 12:57:38 --> Language Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Loader Class Initialized
DEBUG - 2011-05-19 12:57:38 --> Controller Class Initialized
DEBUG - 2011-05-19 12:57:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-19 12:57:39 --> Helper loaded: url_helper
DEBUG - 2011-05-19 12:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 12:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 12:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 12:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 12:57:39 --> Final output sent to browser
DEBUG - 2011-05-19 12:57:39 --> Total execution time: 0.2269
DEBUG - 2011-05-19 13:25:15 --> Config Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:25:15 --> URI Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Router Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Output Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Input Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:25:15 --> Language Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Loader Class Initialized
DEBUG - 2011-05-19 13:25:15 --> Controller Class Initialized
ERROR - 2011-05-19 13:25:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:25:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:25:16 --> Model Class Initialized
DEBUG - 2011-05-19 13:25:16 --> Model Class Initialized
DEBUG - 2011-05-19 13:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:25:17 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:25:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:25:18 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:25:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:25:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:25:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:25:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:25:18 --> Final output sent to browser
DEBUG - 2011-05-19 13:25:18 --> Total execution time: 3.1855
DEBUG - 2011-05-19 13:25:20 --> Config Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:25:20 --> URI Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Router Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Output Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Input Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:25:20 --> Language Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Loader Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Controller Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Model Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Model Class Initialized
DEBUG - 2011-05-19 13:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:25:20 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:25:21 --> Final output sent to browser
DEBUG - 2011-05-19 13:25:21 --> Total execution time: 1.1447
DEBUG - 2011-05-19 13:25:23 --> Config Class Initialized
DEBUG - 2011-05-19 13:25:23 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:25:23 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:25:23 --> URI Class Initialized
DEBUG - 2011-05-19 13:25:23 --> Router Class Initialized
ERROR - 2011-05-19 13:25:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 13:25:24 --> Config Class Initialized
DEBUG - 2011-05-19 13:25:24 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:25:24 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:25:24 --> URI Class Initialized
DEBUG - 2011-05-19 13:25:24 --> Router Class Initialized
ERROR - 2011-05-19 13:25:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 13:25:25 --> Config Class Initialized
DEBUG - 2011-05-19 13:25:25 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:25:25 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:25:25 --> URI Class Initialized
DEBUG - 2011-05-19 13:25:25 --> Router Class Initialized
ERROR - 2011-05-19 13:25:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 13:26:12 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:12 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:12 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:12 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:12 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:12 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:12 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:12 --> Total execution time: 0.0390
DEBUG - 2011-05-19 13:26:13 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:13 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:13 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Controller Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:13 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:14 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:14 --> Total execution time: 0.5959
DEBUG - 2011-05-19 13:26:17 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:17 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:17 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:17 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:17 --> Router Class Initialized
ERROR - 2011-05-19 13:26:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 13:26:27 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:27 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:27 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:27 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:27 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:27 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:27 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:27 --> Total execution time: 0.0290
DEBUG - 2011-05-19 13:26:28 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:28 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:28 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:28 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:28 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Controller Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Loader Class Initialized
ERROR - 2011-05-19 13:26:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:28 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:28 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Model Class Initialized
ERROR - 2011-05-19 13:26:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:28 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:28 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:28 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:28 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:28 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:28 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:28 --> Total execution time: 0.0335
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:28 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:28 --> Total execution time: 0.0344
DEBUG - 2011-05-19 13:26:28 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:28 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:28 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:28 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:28 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:28 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:28 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:28 --> Total execution time: 0.0334
DEBUG - 2011-05-19 13:26:29 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:29 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:29 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:29 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:29 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:29 --> Total execution time: 0.0676
DEBUG - 2011-05-19 13:26:29 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:29 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:29 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:29 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:29 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:29 --> Total execution time: 0.0484
DEBUG - 2011-05-19 13:26:29 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:29 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:29 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:29 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:29 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:29 --> Total execution time: 0.0680
DEBUG - 2011-05-19 13:26:29 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:29 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:29 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:29 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:29 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:29 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:29 --> Total execution time: 0.0960
DEBUG - 2011-05-19 13:26:30 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:30 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:30 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:30 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:30 --> Total execution time: 0.0626
DEBUG - 2011-05-19 13:26:30 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:30 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:30 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:30 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:30 --> Total execution time: 0.1163
DEBUG - 2011-05-19 13:26:30 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:30 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:30 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:30 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:30 --> Total execution time: 0.0292
DEBUG - 2011-05-19 13:26:30 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:30 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:30 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:30 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:30 --> Total execution time: 0.0324
DEBUG - 2011-05-19 13:26:30 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:30 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:30 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:30 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:30 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:30 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:30 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:30 --> Total execution time: 0.0322
DEBUG - 2011-05-19 13:26:31 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:31 --> Total execution time: 0.1226
DEBUG - 2011-05-19 13:26:31 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:31 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:31 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:31 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:31 --> Total execution time: 0.0529
DEBUG - 2011-05-19 13:26:31 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:31 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:31 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:31 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:31 --> Total execution time: 0.0376
DEBUG - 2011-05-19 13:26:31 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:31 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:31 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:31 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:31 --> Total execution time: 0.0410
DEBUG - 2011-05-19 13:26:31 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:31 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:31 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:31 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:31 --> Total execution time: 0.0895
DEBUG - 2011-05-19 13:26:31 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:31 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:31 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:32 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:32 --> Total execution time: 0.1289
DEBUG - 2011-05-19 13:26:32 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:32 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:32 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:32 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:32 --> Total execution time: 0.0441
DEBUG - 2011-05-19 13:26:32 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:32 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:32 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:32 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:32 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:32 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:32 --> Total execution time: 0.1124
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:32 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:32 --> Total execution time: 0.2575
DEBUG - 2011-05-19 13:26:32 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:32 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:32 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:32 --> Total execution time: 0.1326
DEBUG - 2011-05-19 13:26:32 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:32 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:32 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:32 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:32 --> Total execution time: 0.0737
DEBUG - 2011-05-19 13:26:33 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:33 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:33 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:33 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:33 --> Total execution time: 0.0317
DEBUG - 2011-05-19 13:26:33 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:33 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:33 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:33 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:33 --> Total execution time: 0.1082
DEBUG - 2011-05-19 13:26:33 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:33 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:33 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:33 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:33 --> Total execution time: 0.0646
DEBUG - 2011-05-19 13:26:33 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:33 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:33 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:33 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:33 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:33 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:33 --> Total execution time: 0.2856
DEBUG - 2011-05-19 13:26:33 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:33 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:33 --> Total execution time: 0.0720
DEBUG - 2011-05-19 13:26:33 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:33 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:33 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:33 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:33 --> Total execution time: 0.0295
DEBUG - 2011-05-19 13:26:34 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:34 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:34 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:34 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:34 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:34 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:34 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:34 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:34 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:34 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:34 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:34 --> Total execution time: 0.0879
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:34 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:34 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:34 --> Total execution time: 0.0710
DEBUG - 2011-05-19 13:26:34 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:34 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:34 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:34 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:34 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:34 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:34 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:34 --> Total execution time: 0.0586
DEBUG - 2011-05-19 13:26:35 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:35 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:35 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Controller Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:35 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:36 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:36 --> Total execution time: 0.4787
DEBUG - 2011-05-19 13:26:39 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:39 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Router Class Initialized
ERROR - 2011-05-19 13:26:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 13:26:39 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:39 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Router Class Initialized
ERROR - 2011-05-19 13:26:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-19 13:26:39 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:39 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:39 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:39 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:39 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:39 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:39 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:39 --> Total execution time: 0.0277
DEBUG - 2011-05-19 13:26:40 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:40 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:40 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:40 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:40 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:40 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:40 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:40 --> Total execution time: 0.0347
DEBUG - 2011-05-19 13:26:41 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:41 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:41 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Controller Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:41 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:42 --> Total execution time: 0.7122
DEBUG - 2011-05-19 13:26:42 --> Config Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:26:42 --> URI Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Router Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Output Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Input Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:26:42 --> Language Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Loader Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Controller Class Initialized
ERROR - 2011-05-19 13:26:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:26:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:42 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Model Class Initialized
DEBUG - 2011-05-19 13:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:26:42 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:26:42 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:26:42 --> Final output sent to browser
DEBUG - 2011-05-19 13:26:42 --> Total execution time: 0.0533
DEBUG - 2011-05-19 13:27:08 --> Config Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:27:08 --> URI Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Router Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Output Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Input Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:27:08 --> Language Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Loader Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Controller Class Initialized
ERROR - 2011-05-19 13:27:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:27:08 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:27:08 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:27:08 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:27:08 --> Final output sent to browser
DEBUG - 2011-05-19 13:27:08 --> Total execution time: 0.0321
DEBUG - 2011-05-19 13:27:09 --> Config Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:27:09 --> URI Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Router Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Output Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Input Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:27:09 --> Language Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Loader Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Controller Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:27:09 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:27:09 --> Final output sent to browser
DEBUG - 2011-05-19 13:27:09 --> Total execution time: 0.5242
DEBUG - 2011-05-19 13:27:11 --> Config Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:27:11 --> URI Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Router Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Output Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Input Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:27:11 --> Language Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Loader Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Controller Class Initialized
ERROR - 2011-05-19 13:27:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:27:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:27:11 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:27:11 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:27:11 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:27:11 --> Final output sent to browser
DEBUG - 2011-05-19 13:27:11 --> Total execution time: 0.0298
DEBUG - 2011-05-19 13:27:50 --> Config Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:27:50 --> URI Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Router Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Output Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Input Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:27:50 --> Language Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Loader Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Controller Class Initialized
ERROR - 2011-05-19 13:27:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:27:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:27:50 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:27:50 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:27:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:27:50 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:27:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:27:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:27:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:27:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:27:50 --> Final output sent to browser
DEBUG - 2011-05-19 13:27:50 --> Total execution time: 0.0330
DEBUG - 2011-05-19 13:27:51 --> Config Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:27:51 --> URI Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Router Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Output Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Input Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:27:51 --> Language Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Loader Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Controller Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Model Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:27:51 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:27:51 --> Final output sent to browser
DEBUG - 2011-05-19 13:27:51 --> Total execution time: 0.5865
DEBUG - 2011-05-19 13:28:05 --> Config Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:28:05 --> URI Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Router Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Output Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Input Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:28:05 --> Language Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Loader Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Controller Class Initialized
ERROR - 2011-05-19 13:28:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:28:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:28:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:28:05 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:28:05 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:28:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:28:05 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:28:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:28:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:28:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:28:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:28:05 --> Final output sent to browser
DEBUG - 2011-05-19 13:28:05 --> Total execution time: 0.0290
DEBUG - 2011-05-19 13:28:06 --> Config Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:28:06 --> URI Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Router Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Output Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Input Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:28:06 --> Language Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Loader Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Controller Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:28:06 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:28:06 --> Final output sent to browser
DEBUG - 2011-05-19 13:28:06 --> Total execution time: 0.6061
DEBUG - 2011-05-19 13:28:12 --> Config Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:28:12 --> URI Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Router Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Output Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Input Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:28:12 --> Language Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Loader Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Controller Class Initialized
ERROR - 2011-05-19 13:28:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 13:28:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 13:28:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:28:12 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:28:12 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:28:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 13:28:12 --> Helper loaded: url_helper
DEBUG - 2011-05-19 13:28:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 13:28:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 13:28:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 13:28:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 13:28:12 --> Final output sent to browser
DEBUG - 2011-05-19 13:28:12 --> Total execution time: 0.0305
DEBUG - 2011-05-19 13:28:12 --> Config Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Hooks Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Utf8 Class Initialized
DEBUG - 2011-05-19 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 13:28:12 --> URI Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Router Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Output Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Input Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 13:28:12 --> Language Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Loader Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Controller Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Model Class Initialized
DEBUG - 2011-05-19 13:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 13:28:12 --> Database Driver Class Initialized
DEBUG - 2011-05-19 13:28:13 --> Final output sent to browser
DEBUG - 2011-05-19 13:28:13 --> Total execution time: 0.5102
DEBUG - 2011-05-19 14:29:51 --> Config Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Hooks Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Utf8 Class Initialized
DEBUG - 2011-05-19 14:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 14:29:52 --> URI Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Router Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Output Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Input Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 14:29:52 --> Language Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Loader Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Controller Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Model Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Model Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Model Class Initialized
DEBUG - 2011-05-19 14:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 14:29:53 --> Database Driver Class Initialized
DEBUG - 2011-05-19 14:29:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 14:29:54 --> Helper loaded: url_helper
DEBUG - 2011-05-19 14:29:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 14:29:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 14:29:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 14:29:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 14:29:54 --> Final output sent to browser
DEBUG - 2011-05-19 14:29:54 --> Total execution time: 2.7028
DEBUG - 2011-05-19 14:29:57 --> Config Class Initialized
DEBUG - 2011-05-19 14:29:57 --> Hooks Class Initialized
DEBUG - 2011-05-19 14:29:57 --> Utf8 Class Initialized
DEBUG - 2011-05-19 14:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 14:29:57 --> URI Class Initialized
DEBUG - 2011-05-19 14:29:57 --> Router Class Initialized
ERROR - 2011-05-19 14:29:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 14:29:58 --> Config Class Initialized
DEBUG - 2011-05-19 14:29:58 --> Hooks Class Initialized
DEBUG - 2011-05-19 14:29:59 --> Utf8 Class Initialized
DEBUG - 2011-05-19 14:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 14:29:59 --> URI Class Initialized
DEBUG - 2011-05-19 14:29:59 --> Router Class Initialized
ERROR - 2011-05-19 14:29:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 14:29:59 --> Config Class Initialized
DEBUG - 2011-05-19 14:29:59 --> Hooks Class Initialized
DEBUG - 2011-05-19 14:29:59 --> Utf8 Class Initialized
DEBUG - 2011-05-19 14:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 14:29:59 --> URI Class Initialized
DEBUG - 2011-05-19 14:29:59 --> Router Class Initialized
ERROR - 2011-05-19 14:29:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 15:18:27 --> Config Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:18:27 --> URI Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Router Class Initialized
DEBUG - 2011-05-19 15:18:27 --> No URI present. Default controller set.
DEBUG - 2011-05-19 15:18:27 --> Output Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Input Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 15:18:27 --> Language Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Loader Class Initialized
DEBUG - 2011-05-19 15:18:27 --> Controller Class Initialized
DEBUG - 2011-05-19 15:18:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-19 15:18:27 --> Helper loaded: url_helper
DEBUG - 2011-05-19 15:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 15:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 15:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 15:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 15:18:27 --> Final output sent to browser
DEBUG - 2011-05-19 15:18:27 --> Total execution time: 0.2904
DEBUG - 2011-05-19 15:18:39 --> Config Class Initialized
DEBUG - 2011-05-19 15:18:39 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:18:39 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:18:39 --> URI Class Initialized
DEBUG - 2011-05-19 15:18:39 --> Router Class Initialized
ERROR - 2011-05-19 15:18:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 15:18:39 --> Config Class Initialized
DEBUG - 2011-05-19 15:18:39 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:18:39 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:18:39 --> URI Class Initialized
DEBUG - 2011-05-19 15:18:39 --> Router Class Initialized
ERROR - 2011-05-19 15:18:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 15:18:41 --> Config Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:18:41 --> URI Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Router Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Output Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Input Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 15:18:41 --> Language Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Loader Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Controller Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Model Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Model Class Initialized
DEBUG - 2011-05-19 15:18:41 --> Model Class Initialized
DEBUG - 2011-05-19 15:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 15:18:42 --> Database Driver Class Initialized
DEBUG - 2011-05-19 15:18:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 15:18:42 --> Helper loaded: url_helper
DEBUG - 2011-05-19 15:18:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 15:18:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 15:18:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 15:18:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 15:18:42 --> Final output sent to browser
DEBUG - 2011-05-19 15:18:42 --> Total execution time: 1.3922
DEBUG - 2011-05-19 15:19:08 --> Config Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:19:08 --> URI Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Router Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Output Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Input Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 15:19:08 --> Language Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Loader Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Controller Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 15:19:08 --> Database Driver Class Initialized
DEBUG - 2011-05-19 15:19:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 15:19:09 --> Helper loaded: url_helper
DEBUG - 2011-05-19 15:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 15:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 15:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 15:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 15:19:09 --> Final output sent to browser
DEBUG - 2011-05-19 15:19:09 --> Total execution time: 0.2599
DEBUG - 2011-05-19 15:19:17 --> Config Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:19:17 --> URI Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Router Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Output Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Input Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 15:19:17 --> Language Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Loader Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Controller Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 15:19:17 --> Database Driver Class Initialized
DEBUG - 2011-05-19 15:19:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 15:19:17 --> Helper loaded: url_helper
DEBUG - 2011-05-19 15:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 15:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 15:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 15:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 15:19:17 --> Final output sent to browser
DEBUG - 2011-05-19 15:19:17 --> Total execution time: 0.0490
DEBUG - 2011-05-19 15:19:32 --> Config Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:19:32 --> URI Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Router Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Output Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Input Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 15:19:32 --> Language Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Loader Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Controller Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 15:19:32 --> Database Driver Class Initialized
DEBUG - 2011-05-19 15:19:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 15:19:32 --> Helper loaded: url_helper
DEBUG - 2011-05-19 15:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 15:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 15:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 15:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 15:19:32 --> Final output sent to browser
DEBUG - 2011-05-19 15:19:32 --> Total execution time: 0.3617
DEBUG - 2011-05-19 15:19:36 --> Config Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Hooks Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Utf8 Class Initialized
DEBUG - 2011-05-19 15:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 15:19:36 --> URI Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Router Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Output Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Input Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 15:19:36 --> Language Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Loader Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Controller Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Model Class Initialized
DEBUG - 2011-05-19 15:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 15:19:36 --> Database Driver Class Initialized
DEBUG - 2011-05-19 15:19:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 15:19:36 --> Helper loaded: url_helper
DEBUG - 2011-05-19 15:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 15:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 15:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 15:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 15:19:36 --> Final output sent to browser
DEBUG - 2011-05-19 15:19:36 --> Total execution time: 0.0529
DEBUG - 2011-05-19 19:13:22 --> Config Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Hooks Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Utf8 Class Initialized
DEBUG - 2011-05-19 19:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 19:13:22 --> URI Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Router Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Output Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Input Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 19:13:22 --> Language Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Loader Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Controller Class Initialized
ERROR - 2011-05-19 19:13:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 19:13:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 19:13:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 19:13:22 --> Model Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Model Class Initialized
DEBUG - 2011-05-19 19:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 19:13:22 --> Database Driver Class Initialized
DEBUG - 2011-05-19 19:13:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 19:13:22 --> Helper loaded: url_helper
DEBUG - 2011-05-19 19:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 19:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 19:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 19:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 19:13:22 --> Final output sent to browser
DEBUG - 2011-05-19 19:13:22 --> Total execution time: 0.5116
DEBUG - 2011-05-19 19:13:24 --> Config Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Hooks Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Utf8 Class Initialized
DEBUG - 2011-05-19 19:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 19:13:24 --> URI Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Router Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Output Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Input Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 19:13:24 --> Language Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Loader Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Controller Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Model Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Model Class Initialized
DEBUG - 2011-05-19 19:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 19:13:24 --> Database Driver Class Initialized
DEBUG - 2011-05-19 19:13:25 --> Final output sent to browser
DEBUG - 2011-05-19 19:13:25 --> Total execution time: 0.8316
DEBUG - 2011-05-19 19:13:26 --> Config Class Initialized
DEBUG - 2011-05-19 19:13:26 --> Hooks Class Initialized
DEBUG - 2011-05-19 19:13:26 --> Utf8 Class Initialized
DEBUG - 2011-05-19 19:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 19:13:26 --> URI Class Initialized
DEBUG - 2011-05-19 19:13:26 --> Router Class Initialized
ERROR - 2011-05-19 19:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 20:12:59 --> Config Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:12:59 --> URI Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Router Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Output Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Input Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:12:59 --> Language Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Loader Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Controller Class Initialized
ERROR - 2011-05-19 20:12:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:12:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:12:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:12:59 --> Model Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Model Class Initialized
DEBUG - 2011-05-19 20:12:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:12:59 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:12:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:12:59 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:12:59 --> Final output sent to browser
DEBUG - 2011-05-19 20:12:59 --> Total execution time: 0.3574
DEBUG - 2011-05-19 20:13:00 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:00 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Router Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Output Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Input Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:13:00 --> Language Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Loader Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Controller Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:13:00 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:13:00 --> Final output sent to browser
DEBUG - 2011-05-19 20:13:00 --> Total execution time: 0.8490
DEBUG - 2011-05-19 20:13:01 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:01 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Router Class Initialized
ERROR - 2011-05-19 20:13:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 20:13:01 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:01 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Router Class Initialized
ERROR - 2011-05-19 20:13:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 20:13:01 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:01 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:01 --> Router Class Initialized
ERROR - 2011-05-19 20:13:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 20:13:39 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:39 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Router Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Output Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Input Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:13:39 --> Language Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Loader Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Controller Class Initialized
ERROR - 2011-05-19 20:13:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:13:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:13:39 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:13:39 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:13:39 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:13:39 --> Final output sent to browser
DEBUG - 2011-05-19 20:13:39 --> Total execution time: 0.0269
DEBUG - 2011-05-19 20:13:40 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:40 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Router Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Output Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Input Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:13:40 --> Language Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Loader Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Controller Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:13:40 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Final output sent to browser
DEBUG - 2011-05-19 20:13:40 --> Total execution time: 0.6152
DEBUG - 2011-05-19 20:13:40 --> Config Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:13:40 --> URI Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Router Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Output Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Input Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:13:40 --> Language Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Loader Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Controller Class Initialized
ERROR - 2011-05-19 20:13:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:13:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:13:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:13:40 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Model Class Initialized
DEBUG - 2011-05-19 20:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:13:40 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:13:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:13:40 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:13:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:13:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:13:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:13:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:13:40 --> Final output sent to browser
DEBUG - 2011-05-19 20:13:40 --> Total execution time: 0.0284
DEBUG - 2011-05-19 20:14:10 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:10 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:10 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:10 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:10 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:10 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:10 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:10 --> Total execution time: 0.0316
DEBUG - 2011-05-19 20:14:11 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:11 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:11 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Controller Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:11 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:11 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:11 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:11 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:11 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:11 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:11 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:11 --> Total execution time: 0.0329
DEBUG - 2011-05-19 20:14:11 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:11 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:11 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:11 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:11 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:11 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:11 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:11 --> Total execution time: 0.0310
DEBUG - 2011-05-19 20:14:11 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:11 --> Total execution time: 0.6418
DEBUG - 2011-05-19 20:14:30 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:30 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:30 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:30 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:30 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:30 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:30 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:30 --> Total execution time: 0.0355
DEBUG - 2011-05-19 20:14:31 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:31 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:31 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Controller Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:31 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:31 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:31 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:31 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:31 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:31 --> Total execution time: 0.0284
DEBUG - 2011-05-19 20:14:31 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:31 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:31 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:31 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:31 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:31 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:31 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:31 --> Total execution time: 0.0299
DEBUG - 2011-05-19 20:14:31 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:31 --> Total execution time: 0.5388
DEBUG - 2011-05-19 20:14:37 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:37 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:37 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:37 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:37 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:37 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:37 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:37 --> Total execution time: 0.0283
DEBUG - 2011-05-19 20:14:37 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:37 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:37 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Controller Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:37 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:38 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:38 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:38 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:38 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:38 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:38 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:38 --> Total execution time: 0.0287
DEBUG - 2011-05-19 20:14:39 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:39 --> Total execution time: 1.3697
DEBUG - 2011-05-19 20:14:48 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:48 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:48 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:48 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:48 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:48 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:48 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:48 --> Total execution time: 0.0274
DEBUG - 2011-05-19 20:14:48 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:48 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:48 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Controller Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:48 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:49 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:49 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:49 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:49 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:49 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:49 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:49 --> Total execution time: 0.0274
DEBUG - 2011-05-19 20:14:49 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:49 --> Total execution time: 0.5316
DEBUG - 2011-05-19 20:14:49 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:49 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:49 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:49 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:49 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:49 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:49 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:49 --> Total execution time: 0.0283
DEBUG - 2011-05-19 20:14:56 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:56 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:56 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:56 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:56 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:56 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:56 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:56 --> Total execution time: 0.0306
DEBUG - 2011-05-19 20:14:57 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:57 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:57 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Controller Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:57 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Config Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Hooks Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Utf8 Class Initialized
DEBUG - 2011-05-19 20:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 20:14:57 --> URI Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Router Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Output Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Input Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 20:14:57 --> Language Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Loader Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Controller Class Initialized
ERROR - 2011-05-19 20:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 20:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 20:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:57 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Model Class Initialized
DEBUG - 2011-05-19 20:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 20:14:57 --> Database Driver Class Initialized
DEBUG - 2011-05-19 20:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 20:14:57 --> Helper loaded: url_helper
DEBUG - 2011-05-19 20:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 20:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 20:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 20:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 20:14:57 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:57 --> Total execution time: 0.0421
DEBUG - 2011-05-19 20:14:57 --> Final output sent to browser
DEBUG - 2011-05-19 20:14:57 --> Total execution time: 0.5029
DEBUG - 2011-05-19 22:04:42 --> Config Class Initialized
DEBUG - 2011-05-19 22:04:42 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:04:42 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:04:42 --> URI Class Initialized
DEBUG - 2011-05-19 22:04:42 --> Router Class Initialized
ERROR - 2011-05-19 22:04:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-19 22:12:24 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:24 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Router Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Output Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Input Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:12:24 --> Language Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Loader Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Controller Class Initialized
ERROR - 2011-05-19 22:12:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:12:24 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:12:24 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:12:24 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:12:24 --> Final output sent to browser
DEBUG - 2011-05-19 22:12:24 --> Total execution time: 0.3358
DEBUG - 2011-05-19 22:12:28 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:28 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Router Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Output Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Input Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:12:28 --> Language Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Loader Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Controller Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:12:28 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:12:29 --> Final output sent to browser
DEBUG - 2011-05-19 22:12:29 --> Total execution time: 0.6507
DEBUG - 2011-05-19 22:12:32 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:32 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:32 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:32 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:32 --> Router Class Initialized
ERROR - 2011-05-19 22:12:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 22:12:52 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:52 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Router Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Output Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Input Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:12:52 --> Language Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Loader Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Controller Class Initialized
ERROR - 2011-05-19 22:12:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:12:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:12:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:12:52 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:12:52 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:12:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:12:52 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:12:52 --> Final output sent to browser
DEBUG - 2011-05-19 22:12:52 --> Total execution time: 0.0565
DEBUG - 2011-05-19 22:12:52 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:52 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:52 --> Router Class Initialized
ERROR - 2011-05-19 22:12:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 22:12:54 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:54 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Router Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Output Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Input Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:12:54 --> Language Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Loader Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Controller Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:12:54 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Final output sent to browser
DEBUG - 2011-05-19 22:12:56 --> Total execution time: 1.5623
DEBUG - 2011-05-19 22:12:56 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:56 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Router Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Output Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Input Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:12:56 --> Language Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Loader Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Controller Class Initialized
ERROR - 2011-05-19 22:12:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:12:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:12:56 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Model Class Initialized
DEBUG - 2011-05-19 22:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:12:56 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:12:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:12:56 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:12:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:12:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:12:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:12:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:12:56 --> Final output sent to browser
DEBUG - 2011-05-19 22:12:56 --> Total execution time: 0.2280
DEBUG - 2011-05-19 22:12:59 --> Config Class Initialized
DEBUG - 2011-05-19 22:12:59 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:12:59 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:12:59 --> URI Class Initialized
DEBUG - 2011-05-19 22:12:59 --> Router Class Initialized
ERROR - 2011-05-19 22:12:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 22:13:04 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:04 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:04 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Controller Class Initialized
ERROR - 2011-05-19 22:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:04 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:04 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:04 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:13:04 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:04 --> Total execution time: 0.0336
DEBUG - 2011-05-19 22:13:06 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:06 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:06 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Controller Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:06 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:07 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:07 --> Total execution time: 0.5449
DEBUG - 2011-05-19 22:13:07 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:07 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Controller Class Initialized
ERROR - 2011-05-19 22:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:07 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:07 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:13:07 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:07 --> Total execution time: 0.0875
DEBUG - 2011-05-19 22:13:07 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:07 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:07 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Controller Class Initialized
ERROR - 2011-05-19 22:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:07 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:07 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:13:07 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:07 --> Total execution time: 0.0364
DEBUG - 2011-05-19 22:13:07 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:07 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:07 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Controller Class Initialized
ERROR - 2011-05-19 22:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:07 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:07 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:13:07 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:07 --> Total execution time: 0.0819
DEBUG - 2011-05-19 22:13:10 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:10 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:10 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:10 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:10 --> Router Class Initialized
ERROR - 2011-05-19 22:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 22:13:26 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:26 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:26 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Controller Class Initialized
ERROR - 2011-05-19 22:13:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:13:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:26 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:26 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:26 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:13:26 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:26 --> Total execution time: 0.0686
DEBUG - 2011-05-19 22:13:29 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:29 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:29 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Controller Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:29 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:29 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Router Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Output Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Input Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:13:29 --> Language Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Loader Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Controller Class Initialized
ERROR - 2011-05-19 22:13:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-19 22:13:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-19 22:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:29 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Model Class Initialized
DEBUG - 2011-05-19 22:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 22:13:29 --> Database Driver Class Initialized
DEBUG - 2011-05-19 22:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-19 22:13:29 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:13:29 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:29 --> Total execution time: 0.0382
DEBUG - 2011-05-19 22:13:30 --> Final output sent to browser
DEBUG - 2011-05-19 22:13:30 --> Total execution time: 1.2157
DEBUG - 2011-05-19 22:13:33 --> Config Class Initialized
DEBUG - 2011-05-19 22:13:33 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:13:33 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:13:33 --> URI Class Initialized
DEBUG - 2011-05-19 22:13:33 --> Router Class Initialized
ERROR - 2011-05-19 22:13:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 22:15:44 --> Config Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Hooks Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Utf8 Class Initialized
DEBUG - 2011-05-19 22:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 22:15:44 --> URI Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Router Class Initialized
DEBUG - 2011-05-19 22:15:44 --> No URI present. Default controller set.
DEBUG - 2011-05-19 22:15:44 --> Output Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Input Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 22:15:44 --> Language Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Loader Class Initialized
DEBUG - 2011-05-19 22:15:44 --> Controller Class Initialized
DEBUG - 2011-05-19 22:15:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-19 22:15:44 --> Helper loaded: url_helper
DEBUG - 2011-05-19 22:15:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 22:15:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 22:15:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 22:15:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 22:15:44 --> Final output sent to browser
DEBUG - 2011-05-19 22:15:44 --> Total execution time: 0.0588
DEBUG - 2011-05-19 23:12:02 --> Config Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:12:02 --> URI Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Router Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Output Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Input Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:12:02 --> Language Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Loader Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Controller Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:12:02 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:12:03 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:12:03 --> Final output sent to browser
DEBUG - 2011-05-19 23:12:03 --> Total execution time: 0.6571
DEBUG - 2011-05-19 23:12:08 --> Config Class Initialized
DEBUG - 2011-05-19 23:12:08 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:12:08 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:12:08 --> URI Class Initialized
DEBUG - 2011-05-19 23:12:08 --> Router Class Initialized
ERROR - 2011-05-19 23:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-19 23:12:21 --> Config Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:12:21 --> URI Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Router Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Output Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Input Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:12:21 --> Language Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Loader Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Controller Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:12:21 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:12:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:12:21 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:12:21 --> Final output sent to browser
DEBUG - 2011-05-19 23:12:21 --> Total execution time: 0.1502
DEBUG - 2011-05-19 23:12:28 --> Config Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:12:28 --> URI Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Router Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Output Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Input Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:12:28 --> Language Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Loader Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Controller Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Model Class Initialized
DEBUG - 2011-05-19 23:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:12:28 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:12:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:12:28 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:12:28 --> Final output sent to browser
DEBUG - 2011-05-19 23:12:28 --> Total execution time: 0.0439
DEBUG - 2011-05-19 23:13:01 --> Config Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:13:01 --> URI Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Router Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Output Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Input Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:13:01 --> Language Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Loader Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Controller Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:13:01 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:13:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:13:02 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:13:02 --> Final output sent to browser
DEBUG - 2011-05-19 23:13:02 --> Total execution time: 0.2167
DEBUG - 2011-05-19 23:13:04 --> Config Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:13:04 --> URI Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Router Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Output Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Input Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:13:04 --> Language Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Loader Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Controller Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:13:04 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:13:05 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:13:05 --> Final output sent to browser
DEBUG - 2011-05-19 23:13:05 --> Total execution time: 0.0450
DEBUG - 2011-05-19 23:13:05 --> Config Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:13:05 --> URI Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Router Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Output Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Input Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:13:05 --> Language Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Loader Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Controller Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:13:05 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:13:05 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:13:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:13:05 --> Final output sent to browser
DEBUG - 2011-05-19 23:13:05 --> Total execution time: 0.0423
DEBUG - 2011-05-19 23:13:25 --> Config Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Hooks Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Utf8 Class Initialized
DEBUG - 2011-05-19 23:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-19 23:13:25 --> URI Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Router Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Output Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Input Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-19 23:13:25 --> Language Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Loader Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Controller Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Model Class Initialized
DEBUG - 2011-05-19 23:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-19 23:13:25 --> Database Driver Class Initialized
DEBUG - 2011-05-19 23:13:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-19 23:13:25 --> Helper loaded: url_helper
DEBUG - 2011-05-19 23:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-19 23:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-19 23:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-19 23:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-19 23:13:25 --> Final output sent to browser
DEBUG - 2011-05-19 23:13:25 --> Total execution time: 0.0709

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-05 02:14:04 --> Config Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Hooks Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Utf8 Class Initialized
DEBUG - 2011-10-05 02:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 02:14:04 --> URI Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Router Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Output Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Input Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 02:14:04 --> Language Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Loader Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Controller Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Model Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Model Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Model Class Initialized
DEBUG - 2011-10-05 02:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 02:14:04 --> Database Driver Class Initialized
DEBUG - 2011-10-05 02:14:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 02:14:07 --> Helper loaded: url_helper
DEBUG - 2011-10-05 02:14:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 02:14:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 02:14:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 02:14:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 02:14:07 --> Final output sent to browser
DEBUG - 2011-10-05 02:14:07 --> Total execution time: 3.5420
DEBUG - 2011-10-05 02:14:08 --> Config Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Hooks Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Utf8 Class Initialized
DEBUG - 2011-10-05 02:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 02:14:08 --> URI Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Router Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Output Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Input Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 02:14:08 --> Language Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Loader Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Controller Class Initialized
ERROR - 2011-10-05 02:14:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 02:14:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 02:14:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 02:14:08 --> Model Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Model Class Initialized
DEBUG - 2011-10-05 02:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 02:14:08 --> Database Driver Class Initialized
DEBUG - 2011-10-05 02:14:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 02:14:08 --> Helper loaded: url_helper
DEBUG - 2011-10-05 02:14:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 02:14:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 02:14:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 02:14:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 02:14:08 --> Final output sent to browser
DEBUG - 2011-10-05 02:14:08 --> Total execution time: 0.1403
DEBUG - 2011-10-05 03:35:58 --> Config Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Hooks Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Utf8 Class Initialized
DEBUG - 2011-10-05 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 03:35:58 --> URI Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Router Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Output Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Input Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 03:35:58 --> Language Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Loader Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Controller Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Model Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Model Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Model Class Initialized
DEBUG - 2011-10-05 03:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 03:35:58 --> Database Driver Class Initialized
DEBUG - 2011-10-05 03:36:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 03:36:01 --> Helper loaded: url_helper
DEBUG - 2011-10-05 03:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 03:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 03:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 03:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 03:36:01 --> Final output sent to browser
DEBUG - 2011-10-05 03:36:01 --> Total execution time: 2.6145
DEBUG - 2011-10-05 03:43:49 --> Config Class Initialized
DEBUG - 2011-10-05 03:43:49 --> Hooks Class Initialized
DEBUG - 2011-10-05 03:43:49 --> Utf8 Class Initialized
DEBUG - 2011-10-05 03:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 03:43:49 --> URI Class Initialized
DEBUG - 2011-10-05 03:43:49 --> Router Class Initialized
ERROR - 2011-10-05 03:43:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 04:01:30 --> Config Class Initialized
DEBUG - 2011-10-05 04:01:30 --> Hooks Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Utf8 Class Initialized
DEBUG - 2011-10-05 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 04:01:31 --> URI Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Router Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Output Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Input Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 04:01:31 --> Language Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Loader Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Controller Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Model Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Model Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Model Class Initialized
DEBUG - 2011-10-05 04:01:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 04:01:31 --> Database Driver Class Initialized
DEBUG - 2011-10-05 04:01:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 04:01:54 --> Helper loaded: url_helper
DEBUG - 2011-10-05 04:01:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 04:01:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 04:01:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 04:01:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 04:01:54 --> Final output sent to browser
DEBUG - 2011-10-05 04:01:54 --> Total execution time: 23.8454
DEBUG - 2011-10-05 04:01:55 --> Config Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Hooks Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Utf8 Class Initialized
DEBUG - 2011-10-05 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 04:01:55 --> URI Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Router Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Output Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Input Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 04:01:55 --> Language Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Loader Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Controller Class Initialized
ERROR - 2011-10-05 04:01:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 04:01:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 04:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 04:01:55 --> Model Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Model Class Initialized
DEBUG - 2011-10-05 04:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 04:01:55 --> Database Driver Class Initialized
DEBUG - 2011-10-05 04:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 04:01:55 --> Helper loaded: url_helper
DEBUG - 2011-10-05 04:01:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 04:01:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 04:01:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 04:01:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 04:01:55 --> Final output sent to browser
DEBUG - 2011-10-05 04:01:55 --> Total execution time: 0.1047
DEBUG - 2011-10-05 05:26:53 --> Config Class Initialized
DEBUG - 2011-10-05 05:26:53 --> Hooks Class Initialized
DEBUG - 2011-10-05 05:26:53 --> Utf8 Class Initialized
DEBUG - 2011-10-05 05:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 05:26:53 --> URI Class Initialized
DEBUG - 2011-10-05 05:26:53 --> Router Class Initialized
DEBUG - 2011-10-05 05:26:53 --> Output Class Initialized
DEBUG - 2011-10-05 05:26:53 --> Input Class Initialized
DEBUG - 2011-10-05 05:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 05:26:54 --> Language Class Initialized
DEBUG - 2011-10-05 05:26:54 --> Loader Class Initialized
DEBUG - 2011-10-05 05:26:54 --> Controller Class Initialized
DEBUG - 2011-10-05 05:26:54 --> Model Class Initialized
DEBUG - 2011-10-05 05:26:54 --> Model Class Initialized
DEBUG - 2011-10-05 05:26:54 --> Model Class Initialized
DEBUG - 2011-10-05 05:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 05:26:54 --> Database Driver Class Initialized
DEBUG - 2011-10-05 05:26:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 05:26:55 --> Helper loaded: url_helper
DEBUG - 2011-10-05 05:26:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 05:26:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 05:26:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 05:26:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 05:26:55 --> Final output sent to browser
DEBUG - 2011-10-05 05:26:55 --> Total execution time: 1.4157
DEBUG - 2011-10-05 05:27:01 --> Config Class Initialized
DEBUG - 2011-10-05 05:27:01 --> Hooks Class Initialized
DEBUG - 2011-10-05 05:27:01 --> Utf8 Class Initialized
DEBUG - 2011-10-05 05:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 05:27:01 --> URI Class Initialized
DEBUG - 2011-10-05 05:27:01 --> Router Class Initialized
ERROR - 2011-10-05 05:27:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-05 05:27:02 --> Config Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Hooks Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Utf8 Class Initialized
DEBUG - 2011-10-05 05:27:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 05:27:02 --> URI Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Router Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Output Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Input Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 05:27:02 --> Language Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Loader Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Controller Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Model Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Model Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Model Class Initialized
DEBUG - 2011-10-05 05:27:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 05:27:02 --> Database Driver Class Initialized
DEBUG - 2011-10-05 05:27:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 05:27:02 --> Helper loaded: url_helper
DEBUG - 2011-10-05 05:27:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 05:27:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 05:27:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 05:27:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 05:27:02 --> Final output sent to browser
DEBUG - 2011-10-05 05:27:02 --> Total execution time: 0.0586
DEBUG - 2011-10-05 08:16:41 --> Config Class Initialized
DEBUG - 2011-10-05 08:16:41 --> Hooks Class Initialized
DEBUG - 2011-10-05 08:16:41 --> Utf8 Class Initialized
DEBUG - 2011-10-05 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 08:16:41 --> URI Class Initialized
DEBUG - 2011-10-05 08:16:41 --> Router Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Output Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Input Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 08:16:42 --> Language Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Loader Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Controller Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Model Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Model Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Model Class Initialized
DEBUG - 2011-10-05 08:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 08:16:42 --> Database Driver Class Initialized
DEBUG - 2011-10-05 08:16:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 08:16:49 --> Helper loaded: url_helper
DEBUG - 2011-10-05 08:16:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 08:16:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 08:16:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 08:16:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 08:16:49 --> Final output sent to browser
DEBUG - 2011-10-05 08:16:49 --> Total execution time: 7.6293
DEBUG - 2011-10-05 08:35:40 --> Config Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Hooks Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Utf8 Class Initialized
DEBUG - 2011-10-05 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 08:35:40 --> URI Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Router Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Output Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Input Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 08:35:40 --> Language Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Loader Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Controller Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Model Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Model Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Model Class Initialized
DEBUG - 2011-10-05 08:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 08:35:40 --> Database Driver Class Initialized
DEBUG - 2011-10-05 08:35:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 08:35:40 --> Helper loaded: url_helper
DEBUG - 2011-10-05 08:35:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 08:35:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 08:35:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 08:35:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 08:35:40 --> Final output sent to browser
DEBUG - 2011-10-05 08:35:40 --> Total execution time: 0.1271
DEBUG - 2011-10-05 08:42:13 --> Config Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Hooks Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Utf8 Class Initialized
DEBUG - 2011-10-05 08:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 08:42:13 --> URI Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Router Class Initialized
ERROR - 2011-10-05 08:42:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-05 08:42:13 --> Config Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Hooks Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Utf8 Class Initialized
DEBUG - 2011-10-05 08:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 08:42:13 --> URI Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Router Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Output Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Input Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 08:42:13 --> Language Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Loader Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Controller Class Initialized
ERROR - 2011-10-05 08:42:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 08:42:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 08:42:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 08:42:13 --> Model Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Model Class Initialized
DEBUG - 2011-10-05 08:42:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 08:42:13 --> Database Driver Class Initialized
DEBUG - 2011-10-05 08:42:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 08:42:13 --> Helper loaded: url_helper
DEBUG - 2011-10-05 08:42:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 08:42:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 08:42:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 08:42:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 08:42:13 --> Final output sent to browser
DEBUG - 2011-10-05 08:42:13 --> Total execution time: 0.1005
DEBUG - 2011-10-05 09:15:15 --> Config Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:15:15 --> URI Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Router Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Output Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Input Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 09:15:15 --> Language Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Loader Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Controller Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Model Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Model Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Model Class Initialized
DEBUG - 2011-10-05 09:15:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 09:15:15 --> Database Driver Class Initialized
DEBUG - 2011-10-05 09:15:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 09:15:16 --> Helper loaded: url_helper
DEBUG - 2011-10-05 09:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 09:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 09:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 09:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 09:15:16 --> Final output sent to browser
DEBUG - 2011-10-05 09:15:16 --> Total execution time: 1.2898
DEBUG - 2011-10-05 09:15:17 --> Config Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:15:17 --> URI Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Router Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Output Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Input Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 09:15:17 --> Language Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Loader Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Controller Class Initialized
ERROR - 2011-10-05 09:15:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 09:15:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 09:15:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 09:15:17 --> Model Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Model Class Initialized
DEBUG - 2011-10-05 09:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 09:15:17 --> Database Driver Class Initialized
DEBUG - 2011-10-05 09:15:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 09:15:17 --> Helper loaded: url_helper
DEBUG - 2011-10-05 09:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 09:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 09:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 09:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 09:15:17 --> Final output sent to browser
DEBUG - 2011-10-05 09:15:17 --> Total execution time: 0.0792
DEBUG - 2011-10-05 09:48:48 --> Config Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:48:48 --> URI Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Router Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Output Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Input Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 09:48:48 --> Language Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Loader Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Controller Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Model Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Model Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Model Class Initialized
DEBUG - 2011-10-05 09:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 09:48:48 --> Database Driver Class Initialized
DEBUG - 2011-10-05 09:48:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 09:48:48 --> Helper loaded: url_helper
DEBUG - 2011-10-05 09:48:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 09:48:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 09:48:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 09:48:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 09:48:48 --> Final output sent to browser
DEBUG - 2011-10-05 09:48:48 --> Total execution time: 0.5313
DEBUG - 2011-10-05 09:48:50 --> Config Class Initialized
DEBUG - 2011-10-05 09:48:51 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:48:51 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:48:51 --> URI Class Initialized
DEBUG - 2011-10-05 09:48:51 --> Router Class Initialized
ERROR - 2011-10-05 09:48:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 09:48:58 --> Config Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:48:58 --> URI Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Router Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Output Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Input Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 09:48:58 --> Language Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Loader Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Controller Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Model Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Model Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Model Class Initialized
DEBUG - 2011-10-05 09:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 09:48:58 --> Database Driver Class Initialized
DEBUG - 2011-10-05 09:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 09:48:58 --> Helper loaded: url_helper
DEBUG - 2011-10-05 09:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 09:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 09:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 09:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 09:48:58 --> Final output sent to browser
DEBUG - 2011-10-05 09:48:58 --> Total execution time: 0.2834
DEBUG - 2011-10-05 09:49:00 --> Config Class Initialized
DEBUG - 2011-10-05 09:49:00 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:49:00 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:49:00 --> URI Class Initialized
DEBUG - 2011-10-05 09:49:00 --> Router Class Initialized
ERROR - 2011-10-05 09:49:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 09:49:23 --> Config Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:49:23 --> URI Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Router Class Initialized
ERROR - 2011-10-05 09:49:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-05 09:49:23 --> Config Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Hooks Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Utf8 Class Initialized
DEBUG - 2011-10-05 09:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 09:49:23 --> URI Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Router Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Output Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Input Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 09:49:23 --> Language Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Loader Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Controller Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Model Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Model Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Model Class Initialized
DEBUG - 2011-10-05 09:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 09:49:23 --> Database Driver Class Initialized
DEBUG - 2011-10-05 09:49:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 09:49:23 --> Helper loaded: url_helper
DEBUG - 2011-10-05 09:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 09:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 09:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 09:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 09:49:23 --> Final output sent to browser
DEBUG - 2011-10-05 09:49:23 --> Total execution time: 0.1854
DEBUG - 2011-10-05 10:24:17 --> Config Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Hooks Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Utf8 Class Initialized
DEBUG - 2011-10-05 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 10:24:17 --> URI Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Router Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Output Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Input Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 10:24:17 --> Language Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Loader Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Controller Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Model Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Model Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Model Class Initialized
DEBUG - 2011-10-05 10:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 10:24:17 --> Database Driver Class Initialized
DEBUG - 2011-10-05 10:24:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 10:24:18 --> Helper loaded: url_helper
DEBUG - 2011-10-05 10:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 10:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 10:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 10:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 10:24:18 --> Final output sent to browser
DEBUG - 2011-10-05 10:24:18 --> Total execution time: 0.4171
DEBUG - 2011-10-05 10:24:24 --> Config Class Initialized
DEBUG - 2011-10-05 10:24:24 --> Hooks Class Initialized
DEBUG - 2011-10-05 10:24:24 --> Utf8 Class Initialized
DEBUG - 2011-10-05 10:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 10:24:24 --> URI Class Initialized
DEBUG - 2011-10-05 10:24:24 --> Router Class Initialized
ERROR - 2011-10-05 10:24:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 10:24:25 --> Config Class Initialized
DEBUG - 2011-10-05 10:24:25 --> Hooks Class Initialized
DEBUG - 2011-10-05 10:24:25 --> Utf8 Class Initialized
DEBUG - 2011-10-05 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 10:24:25 --> URI Class Initialized
DEBUG - 2011-10-05 10:24:25 --> Router Class Initialized
ERROR - 2011-10-05 10:24:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 10:24:48 --> Config Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Hooks Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Utf8 Class Initialized
DEBUG - 2011-10-05 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 10:24:48 --> URI Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Router Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Output Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Input Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 10:24:48 --> Language Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Loader Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Controller Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Model Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Model Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Model Class Initialized
DEBUG - 2011-10-05 10:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 10:24:48 --> Database Driver Class Initialized
DEBUG - 2011-10-05 10:24:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 10:24:48 --> Helper loaded: url_helper
DEBUG - 2011-10-05 10:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 10:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 10:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 10:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 10:24:48 --> Final output sent to browser
DEBUG - 2011-10-05 10:24:48 --> Total execution time: 0.1760
DEBUG - 2011-10-05 10:24:50 --> Config Class Initialized
DEBUG - 2011-10-05 10:24:50 --> Hooks Class Initialized
DEBUG - 2011-10-05 10:24:50 --> Utf8 Class Initialized
DEBUG - 2011-10-05 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 10:24:50 --> URI Class Initialized
DEBUG - 2011-10-05 10:24:50 --> Router Class Initialized
ERROR - 2011-10-05 10:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 11:39:57 --> Config Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:39:57 --> URI Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Router Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Output Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Input Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:39:57 --> Language Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Loader Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Controller Class Initialized
ERROR - 2011-10-05 11:39:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 11:39:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 11:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 11:39:57 --> Model Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Model Class Initialized
DEBUG - 2011-10-05 11:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 11:39:57 --> Database Driver Class Initialized
DEBUG - 2011-10-05 11:39:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 11:39:59 --> Helper loaded: url_helper
DEBUG - 2011-10-05 11:39:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 11:39:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 11:39:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 11:39:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 11:39:59 --> Final output sent to browser
DEBUG - 2011-10-05 11:39:59 --> Total execution time: 1.4731
DEBUG - 2011-10-05 11:40:00 --> Config Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:40:00 --> URI Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Router Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Output Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Input Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:40:00 --> Language Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Loader Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Controller Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Model Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Model Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 11:40:00 --> Database Driver Class Initialized
DEBUG - 2011-10-05 11:40:00 --> Final output sent to browser
DEBUG - 2011-10-05 11:40:00 --> Total execution time: 0.8876
DEBUG - 2011-10-05 11:40:02 --> Config Class Initialized
DEBUG - 2011-10-05 11:40:02 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:40:02 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:40:02 --> URI Class Initialized
DEBUG - 2011-10-05 11:40:02 --> Router Class Initialized
ERROR - 2011-10-05 11:40:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 11:40:03 --> Config Class Initialized
DEBUG - 2011-10-05 11:40:03 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:40:03 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:40:03 --> URI Class Initialized
DEBUG - 2011-10-05 11:40:03 --> Router Class Initialized
ERROR - 2011-10-05 11:40:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 11:41:24 --> Config Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:41:24 --> URI Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Router Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Output Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Input Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:41:24 --> Language Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Loader Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Controller Class Initialized
ERROR - 2011-10-05 11:41:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 11:41:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 11:41:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 11:41:24 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 11:41:24 --> Database Driver Class Initialized
DEBUG - 2011-10-05 11:41:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 11:41:24 --> Helper loaded: url_helper
DEBUG - 2011-10-05 11:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 11:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 11:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 11:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 11:41:24 --> Final output sent to browser
DEBUG - 2011-10-05 11:41:24 --> Total execution time: 0.0370
DEBUG - 2011-10-05 11:41:24 --> Config Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:41:24 --> URI Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Router Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Output Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Input Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:41:24 --> Language Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Loader Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Controller Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 11:41:24 --> Database Driver Class Initialized
DEBUG - 2011-10-05 11:41:25 --> Final output sent to browser
DEBUG - 2011-10-05 11:41:25 --> Total execution time: 0.6130
DEBUG - 2011-10-05 11:41:35 --> Config Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:41:35 --> URI Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Router Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Output Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Input Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:41:35 --> Language Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Loader Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Controller Class Initialized
ERROR - 2011-10-05 11:41:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 11:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 11:41:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 11:41:35 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 11:41:35 --> Database Driver Class Initialized
DEBUG - 2011-10-05 11:41:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 11:41:35 --> Helper loaded: url_helper
DEBUG - 2011-10-05 11:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 11:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 11:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 11:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 11:41:35 --> Final output sent to browser
DEBUG - 2011-10-05 11:41:35 --> Total execution time: 0.0317
DEBUG - 2011-10-05 11:41:36 --> Config Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:41:36 --> URI Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Router Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Output Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Input Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:41:36 --> Language Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Loader Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Controller Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Model Class Initialized
DEBUG - 2011-10-05 11:41:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 11:41:36 --> Database Driver Class Initialized
DEBUG - 2011-10-05 11:41:37 --> Final output sent to browser
DEBUG - 2011-10-05 11:41:37 --> Total execution time: 0.5964
DEBUG - 2011-10-05 11:54:30 --> Config Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Hooks Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Utf8 Class Initialized
DEBUG - 2011-10-05 11:54:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 11:54:30 --> URI Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Router Class Initialized
DEBUG - 2011-10-05 11:54:30 --> No URI present. Default controller set.
DEBUG - 2011-10-05 11:54:30 --> Output Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Input Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 11:54:30 --> Language Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Loader Class Initialized
DEBUG - 2011-10-05 11:54:30 --> Controller Class Initialized
DEBUG - 2011-10-05 11:54:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-05 11:54:30 --> Helper loaded: url_helper
DEBUG - 2011-10-05 11:54:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 11:54:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 11:54:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 11:54:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 11:54:30 --> Final output sent to browser
DEBUG - 2011-10-05 11:54:30 --> Total execution time: 0.0702
DEBUG - 2011-10-05 12:32:40 --> Config Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:32:40 --> URI Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Router Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Output Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Input Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:32:40 --> Language Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Loader Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Controller Class Initialized
ERROR - 2011-10-05 12:32:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 12:32:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 12:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 12:32:40 --> Model Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Model Class Initialized
DEBUG - 2011-10-05 12:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:32:40 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 12:32:40 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:32:40 --> Final output sent to browser
DEBUG - 2011-10-05 12:32:40 --> Total execution time: 0.0432
DEBUG - 2011-10-05 12:32:54 --> Config Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:32:54 --> URI Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Router Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Output Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Input Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:32:54 --> Language Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Loader Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Controller Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Model Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Model Class Initialized
DEBUG - 2011-10-05 12:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:32:54 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:32:55 --> Final output sent to browser
DEBUG - 2011-10-05 12:32:55 --> Total execution time: 0.8778
DEBUG - 2011-10-05 12:44:09 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:09 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:09 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:09 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:10 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:10 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:10 --> Total execution time: 0.7466
DEBUG - 2011-10-05 12:44:13 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:13 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:13 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:13 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:13 --> Router Class Initialized
ERROR - 2011-10-05 12:44:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:13 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:13 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:13 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:13 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:13 --> Router Class Initialized
ERROR - 2011-10-05 12:44:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:17 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:17 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:17 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:18 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:18 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:18 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:18 --> Total execution time: 0.2842
DEBUG - 2011-10-05 12:44:19 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:19 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Router Class Initialized
ERROR - 2011-10-05 12:44:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:19 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:19 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:19 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:20 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:20 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:20 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:20 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:20 --> Total execution time: 0.0642
DEBUG - 2011-10-05 12:44:29 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:29 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:29 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:29 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:29 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:29 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:29 --> Total execution time: 0.4669
DEBUG - 2011-10-05 12:44:30 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:30 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:30 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:30 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:30 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:30 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:30 --> Total execution time: 0.0537
DEBUG - 2011-10-05 12:44:30 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:30 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:30 --> Router Class Initialized
ERROR - 2011-10-05 12:44:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:40 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:40 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:40 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:40 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:40 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:40 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:40 --> Total execution time: 0.0486
DEBUG - 2011-10-05 12:44:41 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:41 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:41 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:41 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:41 --> Router Class Initialized
ERROR - 2011-10-05 12:44:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:48 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:48 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:48 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:48 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:48 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:48 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:48 --> Total execution time: 0.7853
DEBUG - 2011-10-05 12:44:50 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:50 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:50 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:50 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:50 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:50 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:50 --> Total execution time: 0.1209
DEBUG - 2011-10-05 12:44:50 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:50 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Router Class Initialized
ERROR - 2011-10-05 12:44:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:50 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:50 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:50 --> Router Class Initialized
ERROR - 2011-10-05 12:44:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:55 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:55 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:55 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:55 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:56 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:56 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:56 --> Total execution time: 0.2227
DEBUG - 2011-10-05 12:44:57 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:57 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:57 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:57 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:57 --> Router Class Initialized
ERROR - 2011-10-05 12:44:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:44:58 --> Config Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:44:58 --> URI Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Router Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Output Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Input Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:44:58 --> Language Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Loader Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Controller Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Model Class Initialized
DEBUG - 2011-10-05 12:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:44:58 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:44:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:44:58 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:44:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:44:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:44:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:44:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:44:58 --> Final output sent to browser
DEBUG - 2011-10-05 12:44:58 --> Total execution time: 0.0520
DEBUG - 2011-10-05 12:45:00 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:00 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:00 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:00 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:01 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:01 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:01 --> Total execution time: 0.3095
DEBUG - 2011-10-05 12:45:03 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:03 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Router Class Initialized
ERROR - 2011-10-05 12:45:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:03 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:03 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:03 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:03 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:04 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:04 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:04 --> Total execution time: 0.6000
DEBUG - 2011-10-05 12:45:05 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:05 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:05 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:05 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:07 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:07 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:07 --> Total execution time: 1.8348
DEBUG - 2011-10-05 12:45:08 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:08 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:08 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:08 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:08 --> Router Class Initialized
ERROR - 2011-10-05 12:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:11 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:11 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:11 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:11 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:12 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:12 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:12 --> Total execution time: 0.5805
DEBUG - 2011-10-05 12:45:13 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:13 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:13 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:13 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:13 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:13 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:13 --> Total execution time: 0.2815
DEBUG - 2011-10-05 12:45:13 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:13 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:13 --> Router Class Initialized
ERROR - 2011-10-05 12:45:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:15 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:15 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:15 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:15 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:16 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:16 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:16 --> Total execution time: 0.7284
DEBUG - 2011-10-05 12:45:16 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:16 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:16 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:16 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:16 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:16 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:16 --> Total execution time: 0.2424
DEBUG - 2011-10-05 12:45:17 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:17 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:17 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:17 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:17 --> Router Class Initialized
ERROR - 2011-10-05 12:45:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:18 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:18 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:18 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:18 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:18 --> Router Class Initialized
ERROR - 2011-10-05 12:45:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:20 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:20 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:20 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:20 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:20 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:20 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:20 --> Total execution time: 0.3277
DEBUG - 2011-10-05 12:45:22 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:22 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:22 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:22 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:22 --> Router Class Initialized
ERROR - 2011-10-05 12:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:25 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:25 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:25 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:25 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:26 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:26 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:26 --> Total execution time: 0.8529
DEBUG - 2011-10-05 12:45:27 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:27 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:27 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:27 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:27 --> Router Class Initialized
ERROR - 2011-10-05 12:45:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:37 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:37 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:37 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:37 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:37 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:37 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:37 --> Total execution time: 0.1113
DEBUG - 2011-10-05 12:45:38 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:38 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:38 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:38 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:38 --> Router Class Initialized
ERROR - 2011-10-05 12:45:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:39 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:39 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:39 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:39 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:39 --> Router Class Initialized
ERROR - 2011-10-05 12:45:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:42 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:42 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:42 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:42 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:42 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:42 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:42 --> Total execution time: 0.0508
DEBUG - 2011-10-05 12:45:43 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:43 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:43 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:43 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:43 --> Router Class Initialized
ERROR - 2011-10-05 12:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:48 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:48 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:48 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:48 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:49 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:49 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:49 --> Total execution time: 0.3932
DEBUG - 2011-10-05 12:45:50 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:50 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:50 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:50 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:50 --> Router Class Initialized
ERROR - 2011-10-05 12:45:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:56 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:56 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:56 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:56 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:56 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:56 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:56 --> Total execution time: 0.2669
DEBUG - 2011-10-05 12:45:57 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:57 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:57 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:57 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:57 --> Router Class Initialized
ERROR - 2011-10-05 12:45:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 12:45:59 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:59 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:59 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:59 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:45:59 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:45:59 --> Final output sent to browser
DEBUG - 2011-10-05 12:45:59 --> Total execution time: 0.0510
DEBUG - 2011-10-05 12:45:59 --> Config Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:45:59 --> URI Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Router Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Output Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Input Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:45:59 --> Language Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Loader Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Controller Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Model Class Initialized
DEBUG - 2011-10-05 12:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:45:59 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:45:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:46:00 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:46:00 --> Final output sent to browser
DEBUG - 2011-10-05 12:46:00 --> Total execution time: 0.0889
DEBUG - 2011-10-05 12:46:01 --> Config Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:46:01 --> URI Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Router Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Output Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Input Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:46:01 --> Language Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Loader Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Controller Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:46:01 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:46:01 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:46:01 --> Final output sent to browser
DEBUG - 2011-10-05 12:46:01 --> Total execution time: 0.0559
DEBUG - 2011-10-05 12:46:02 --> Config Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:46:02 --> URI Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Router Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Output Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Input Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:46:02 --> Language Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Loader Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Controller Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:46:02 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:46:02 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:46:02 --> Final output sent to browser
DEBUG - 2011-10-05 12:46:02 --> Total execution time: 0.0573
DEBUG - 2011-10-05 12:46:02 --> Config Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:46:02 --> URI Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Router Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Output Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Input Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:46:02 --> Language Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Loader Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Controller Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:46:02 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:46:02 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:46:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:46:02 --> Final output sent to browser
DEBUG - 2011-10-05 12:46:02 --> Total execution time: 0.2282
DEBUG - 2011-10-05 12:46:04 --> Config Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:46:04 --> URI Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Router Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Output Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Input Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 12:46:04 --> Language Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Loader Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Controller Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Model Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 12:46:04 --> Database Driver Class Initialized
DEBUG - 2011-10-05 12:46:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 12:46:04 --> Helper loaded: url_helper
DEBUG - 2011-10-05 12:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 12:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 12:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 12:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 12:46:04 --> Final output sent to browser
DEBUG - 2011-10-05 12:46:04 --> Total execution time: 0.0495
DEBUG - 2011-10-05 12:46:04 --> Config Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Hooks Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Utf8 Class Initialized
DEBUG - 2011-10-05 12:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 12:46:04 --> URI Class Initialized
DEBUG - 2011-10-05 12:46:04 --> Router Class Initialized
ERROR - 2011-10-05 12:46:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 13:07:34 --> Config Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:07:34 --> URI Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Router Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Output Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Input Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:07:34 --> Language Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Loader Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Controller Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Model Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Model Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Model Class Initialized
DEBUG - 2011-10-05 13:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:07:34 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:07:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:07:34 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:07:34 --> Final output sent to browser
DEBUG - 2011-10-05 13:07:34 --> Total execution time: 0.0465
DEBUG - 2011-10-05 13:07:36 --> Config Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:07:36 --> URI Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Router Class Initialized
ERROR - 2011-10-05 13:07:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 13:07:36 --> Config Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:07:36 --> URI Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Router Class Initialized
ERROR - 2011-10-05 13:07:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 13:07:36 --> Config Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:07:36 --> URI Class Initialized
DEBUG - 2011-10-05 13:07:36 --> Router Class Initialized
ERROR - 2011-10-05 13:07:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 13:07:54 --> Config Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:07:54 --> URI Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Router Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Output Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Input Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:07:54 --> Language Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Loader Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Controller Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Model Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Model Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Model Class Initialized
DEBUG - 2011-10-05 13:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:07:54 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:07:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:07:54 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:07:54 --> Final output sent to browser
DEBUG - 2011-10-05 13:07:54 --> Total execution time: 0.3033
DEBUG - 2011-10-05 13:08:08 --> Config Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:08:08 --> URI Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Router Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Output Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Input Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:08:08 --> Language Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Loader Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Controller Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:08:08 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:08:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:08:08 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:08:08 --> Final output sent to browser
DEBUG - 2011-10-05 13:08:08 --> Total execution time: 0.0562
DEBUG - 2011-10-05 13:08:25 --> Config Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:08:25 --> URI Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Router Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Output Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Input Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:08:25 --> Language Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Loader Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Controller Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:08:25 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:08:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:08:25 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:08:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:08:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:08:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:08:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:08:25 --> Final output sent to browser
DEBUG - 2011-10-05 13:08:25 --> Total execution time: 0.4516
DEBUG - 2011-10-05 13:08:51 --> Config Class Initialized
DEBUG - 2011-10-05 13:08:51 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:08:51 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:08:51 --> URI Class Initialized
DEBUG - 2011-10-05 13:08:51 --> Router Class Initialized
DEBUG - 2011-10-05 13:08:51 --> Output Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Input Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:08:52 --> Language Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Loader Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Controller Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Model Class Initialized
DEBUG - 2011-10-05 13:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:08:52 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:08:53 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:08:53 --> Final output sent to browser
DEBUG - 2011-10-05 13:08:53 --> Total execution time: 1.1042
DEBUG - 2011-10-05 13:09:06 --> Config Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:09:06 --> URI Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Router Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Output Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Input Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:09:06 --> Language Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Loader Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Controller Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:09:06 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:09:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:09:06 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:09:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:09:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:09:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:09:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:09:06 --> Final output sent to browser
DEBUG - 2011-10-05 13:09:06 --> Total execution time: 0.1824
DEBUG - 2011-10-05 13:09:26 --> Config Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:09:26 --> URI Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Router Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Output Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Input Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:09:26 --> Language Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Loader Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Controller Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:09:26 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:09:26 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:09:26 --> Final output sent to browser
DEBUG - 2011-10-05 13:09:26 --> Total execution time: 0.0493
DEBUG - 2011-10-05 13:09:46 --> Config Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:09:46 --> URI Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Router Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Output Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Input Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:09:46 --> Language Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Loader Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Controller Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Model Class Initialized
DEBUG - 2011-10-05 13:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:09:46 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:09:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:09:46 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:09:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:09:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:09:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:09:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:09:46 --> Final output sent to browser
DEBUG - 2011-10-05 13:09:46 --> Total execution time: 0.3171
DEBUG - 2011-10-05 13:10:10 --> Config Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:10:10 --> URI Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Router Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Output Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Input Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:10:10 --> Language Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Loader Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Controller Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Model Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Model Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Model Class Initialized
DEBUG - 2011-10-05 13:10:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:10:10 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:10:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:10:11 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:10:11 --> Final output sent to browser
DEBUG - 2011-10-05 13:10:11 --> Total execution time: 1.2129
DEBUG - 2011-10-05 13:10:48 --> Config Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:10:48 --> URI Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Router Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Output Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Input Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:10:48 --> Language Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Loader Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Controller Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Model Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Model Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Model Class Initialized
DEBUG - 2011-10-05 13:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:10:48 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:10:49 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:10:49 --> Final output sent to browser
DEBUG - 2011-10-05 13:10:49 --> Total execution time: 0.3756
DEBUG - 2011-10-05 13:11:12 --> Config Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:11:12 --> URI Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Router Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Output Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Input Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:11:12 --> Language Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Loader Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Controller Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:11:12 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:11:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:11:13 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:11:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:11:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:11:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:11:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:11:13 --> Final output sent to browser
DEBUG - 2011-10-05 13:11:13 --> Total execution time: 0.4925
DEBUG - 2011-10-05 13:11:32 --> Config Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:11:32 --> URI Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Router Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Output Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Input Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:11:32 --> Language Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Loader Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Controller Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:11:32 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:11:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:11:32 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:11:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:11:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:11:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:11:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:11:32 --> Final output sent to browser
DEBUG - 2011-10-05 13:11:32 --> Total execution time: 0.3468
DEBUG - 2011-10-05 13:11:49 --> Config Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:11:49 --> URI Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Router Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Output Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Input Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:11:49 --> Language Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Loader Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Controller Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Model Class Initialized
DEBUG - 2011-10-05 13:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:11:49 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:11:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:11:49 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:11:49 --> Final output sent to browser
DEBUG - 2011-10-05 13:11:49 --> Total execution time: 0.2314
DEBUG - 2011-10-05 13:12:12 --> Config Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:12:12 --> URI Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Router Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Output Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Input Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:12:12 --> Language Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Loader Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Controller Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:12:12 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:12:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:12:12 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:12:12 --> Final output sent to browser
DEBUG - 2011-10-05 13:12:12 --> Total execution time: 0.2812
DEBUG - 2011-10-05 13:12:29 --> Config Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:12:29 --> URI Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Router Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Output Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Input Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:12:29 --> Language Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Loader Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Controller Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:12:29 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:12:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:12:30 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:12:30 --> Final output sent to browser
DEBUG - 2011-10-05 13:12:30 --> Total execution time: 0.1103
DEBUG - 2011-10-05 13:12:55 --> Config Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:12:55 --> URI Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Router Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Output Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Input Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:12:55 --> Language Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Loader Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Controller Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Model Class Initialized
DEBUG - 2011-10-05 13:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:12:55 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:12:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:12:56 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:12:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:12:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:12:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:12:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:12:56 --> Final output sent to browser
DEBUG - 2011-10-05 13:12:56 --> Total execution time: 1.0801
DEBUG - 2011-10-05 13:13:20 --> Config Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:13:20 --> URI Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Router Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Output Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Input Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:13:20 --> Language Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Loader Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Controller Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Model Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Model Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Model Class Initialized
DEBUG - 2011-10-05 13:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:13:20 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:13:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:13:20 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:13:20 --> Final output sent to browser
DEBUG - 2011-10-05 13:13:20 --> Total execution time: 0.3012
DEBUG - 2011-10-05 13:13:44 --> Config Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:13:44 --> URI Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Router Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Output Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Input Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:13:44 --> Language Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Loader Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Controller Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Model Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Model Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Model Class Initialized
DEBUG - 2011-10-05 13:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:13:44 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:13:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:13:45 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:13:45 --> Final output sent to browser
DEBUG - 2011-10-05 13:13:45 --> Total execution time: 0.2509
DEBUG - 2011-10-05 13:14:02 --> Config Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:14:02 --> URI Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Router Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Output Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Input Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:14:02 --> Language Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Loader Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Controller Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:14:02 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:14:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:14:02 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:14:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:14:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:14:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:14:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:14:02 --> Final output sent to browser
DEBUG - 2011-10-05 13:14:02 --> Total execution time: 0.2058
DEBUG - 2011-10-05 13:14:12 --> Config Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:14:12 --> URI Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Router Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Output Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Input Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:14:12 --> Language Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Loader Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Controller Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:14:12 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:14:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:14:12 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:14:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:14:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:14:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:14:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:14:12 --> Final output sent to browser
DEBUG - 2011-10-05 13:14:12 --> Total execution time: 0.0932
DEBUG - 2011-10-05 13:14:30 --> Config Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Hooks Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Utf8 Class Initialized
DEBUG - 2011-10-05 13:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 13:14:30 --> URI Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Router Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Output Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Input Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 13:14:30 --> Language Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Loader Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Controller Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Model Class Initialized
DEBUG - 2011-10-05 13:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 13:14:30 --> Database Driver Class Initialized
DEBUG - 2011-10-05 13:14:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 13:14:31 --> Helper loaded: url_helper
DEBUG - 2011-10-05 13:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 13:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 13:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 13:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 13:14:31 --> Final output sent to browser
DEBUG - 2011-10-05 13:14:31 --> Total execution time: 0.3046
DEBUG - 2011-10-05 14:09:39 --> Config Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:09:39 --> URI Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Router Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Output Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Input Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:09:39 --> Language Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Loader Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Controller Class Initialized
ERROR - 2011-10-05 14:09:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 14:09:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 14:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:09:39 --> Model Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Model Class Initialized
DEBUG - 2011-10-05 14:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:09:39 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:09:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:09:40 --> Helper loaded: url_helper
DEBUG - 2011-10-05 14:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 14:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 14:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 14:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 14:09:40 --> Final output sent to browser
DEBUG - 2011-10-05 14:09:40 --> Total execution time: 0.6772
DEBUG - 2011-10-05 14:10:20 --> Config Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:10:20 --> URI Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Router Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Output Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Input Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:10:20 --> Language Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Loader Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Controller Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Model Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Model Class Initialized
DEBUG - 2011-10-05 14:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:10:20 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:10:22 --> Final output sent to browser
DEBUG - 2011-10-05 14:10:22 --> Total execution time: 1.9586
DEBUG - 2011-10-05 14:12:43 --> Config Class Initialized
DEBUG - 2011-10-05 14:12:43 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:12:43 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:12:43 --> URI Class Initialized
DEBUG - 2011-10-05 14:12:43 --> Router Class Initialized
ERROR - 2011-10-05 14:12:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 14:13:39 --> Config Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:13:39 --> URI Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Router Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Output Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Input Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:13:39 --> Language Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Loader Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Controller Class Initialized
ERROR - 2011-10-05 14:13:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 14:13:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 14:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:13:39 --> Model Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Model Class Initialized
DEBUG - 2011-10-05 14:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:13:39 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:13:39 --> Helper loaded: url_helper
DEBUG - 2011-10-05 14:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 14:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 14:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 14:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 14:13:39 --> Final output sent to browser
DEBUG - 2011-10-05 14:13:39 --> Total execution time: 0.0337
DEBUG - 2011-10-05 14:14:22 --> Config Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:14:22 --> URI Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Router Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Output Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Input Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:14:22 --> Language Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Loader Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Controller Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Model Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Model Class Initialized
DEBUG - 2011-10-05 14:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:14:22 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:14:25 --> Final output sent to browser
DEBUG - 2011-10-05 14:14:25 --> Total execution time: 3.3808
DEBUG - 2011-10-05 14:19:24 --> Config Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:19:24 --> URI Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Router Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Output Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Input Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:19:24 --> Language Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Loader Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Controller Class Initialized
ERROR - 2011-10-05 14:19:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 14:19:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 14:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:19:24 --> Model Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Model Class Initialized
DEBUG - 2011-10-05 14:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:19:24 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:19:24 --> Helper loaded: url_helper
DEBUG - 2011-10-05 14:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 14:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 14:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 14:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 14:19:24 --> Final output sent to browser
DEBUG - 2011-10-05 14:19:24 --> Total execution time: 0.0298
DEBUG - 2011-10-05 14:19:30 --> Config Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:19:30 --> URI Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Router Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Output Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Input Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:19:30 --> Language Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Loader Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Controller Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Model Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Model Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:19:30 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:19:30 --> Final output sent to browser
DEBUG - 2011-10-05 14:19:30 --> Total execution time: 0.7496
DEBUG - 2011-10-05 14:25:32 --> Config Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:25:32 --> URI Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Router Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Output Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Input Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:25:32 --> Language Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Loader Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Controller Class Initialized
ERROR - 2011-10-05 14:25:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 14:25:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 14:25:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:25:32 --> Model Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Model Class Initialized
DEBUG - 2011-10-05 14:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:25:32 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:25:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:25:32 --> Helper loaded: url_helper
DEBUG - 2011-10-05 14:25:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 14:25:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 14:25:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 14:25:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 14:25:32 --> Final output sent to browser
DEBUG - 2011-10-05 14:25:32 --> Total execution time: 0.0367
DEBUG - 2011-10-05 14:25:49 --> Config Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:25:49 --> URI Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Router Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Output Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Input Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:25:49 --> Language Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Loader Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Controller Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Model Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Model Class Initialized
DEBUG - 2011-10-05 14:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:25:49 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:25:50 --> Final output sent to browser
DEBUG - 2011-10-05 14:25:50 --> Total execution time: 1.5309
DEBUG - 2011-10-05 14:29:27 --> Config Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:29:27 --> URI Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Router Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Output Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Input Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:29:27 --> Language Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Loader Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Controller Class Initialized
ERROR - 2011-10-05 14:29:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 14:29:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 14:29:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:29:27 --> Model Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Model Class Initialized
DEBUG - 2011-10-05 14:29:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:29:27 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:29:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:29:27 --> Helper loaded: url_helper
DEBUG - 2011-10-05 14:29:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 14:29:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 14:29:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 14:29:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 14:29:27 --> Final output sent to browser
DEBUG - 2011-10-05 14:29:27 --> Total execution time: 0.0890
DEBUG - 2011-10-05 14:29:37 --> Config Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:29:37 --> URI Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Router Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Output Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Input Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:29:37 --> Language Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Loader Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Controller Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Model Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Model Class Initialized
DEBUG - 2011-10-05 14:29:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:29:37 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:29:38 --> Final output sent to browser
DEBUG - 2011-10-05 14:29:38 --> Total execution time: 0.8256
DEBUG - 2011-10-05 14:30:11 --> Config Class Initialized
DEBUG - 2011-10-05 14:30:11 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:30:11 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:30:11 --> URI Class Initialized
DEBUG - 2011-10-05 14:30:11 --> Router Class Initialized
ERROR - 2011-10-05 14:30:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 14:30:27 --> Config Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:30:27 --> URI Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Router Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Output Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Input Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:30:27 --> Language Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Loader Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Controller Class Initialized
ERROR - 2011-10-05 14:30:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 14:30:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 14:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:30:27 --> Model Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Model Class Initialized
DEBUG - 2011-10-05 14:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:30:27 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 14:30:27 --> Helper loaded: url_helper
DEBUG - 2011-10-05 14:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 14:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 14:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 14:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 14:30:27 --> Final output sent to browser
DEBUG - 2011-10-05 14:30:27 --> Total execution time: 0.0303
DEBUG - 2011-10-05 14:30:28 --> Config Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:30:28 --> URI Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Router Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Output Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Input Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 14:30:28 --> Language Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Loader Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Controller Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Model Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Model Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 14:30:28 --> Database Driver Class Initialized
DEBUG - 2011-10-05 14:30:28 --> Final output sent to browser
DEBUG - 2011-10-05 14:30:28 --> Total execution time: 0.6538
DEBUG - 2011-10-05 14:33:42 --> Config Class Initialized
DEBUG - 2011-10-05 14:33:42 --> Hooks Class Initialized
DEBUG - 2011-10-05 14:33:42 --> Utf8 Class Initialized
DEBUG - 2011-10-05 14:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 14:33:42 --> URI Class Initialized
DEBUG - 2011-10-05 14:33:42 --> Router Class Initialized
ERROR - 2011-10-05 14:33:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-05 15:25:52 --> Config Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Hooks Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Utf8 Class Initialized
DEBUG - 2011-10-05 15:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 15:25:52 --> URI Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Router Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Output Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Input Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 15:25:52 --> Language Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Loader Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Controller Class Initialized
ERROR - 2011-10-05 15:25:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 15:25:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 15:25:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 15:25:52 --> Model Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Model Class Initialized
DEBUG - 2011-10-05 15:25:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 15:25:52 --> Database Driver Class Initialized
DEBUG - 2011-10-05 15:25:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 15:25:52 --> Helper loaded: url_helper
DEBUG - 2011-10-05 15:25:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 15:25:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 15:25:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 15:25:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 15:25:52 --> Final output sent to browser
DEBUG - 2011-10-05 15:25:52 --> Total execution time: 0.4643
DEBUG - 2011-10-05 15:25:57 --> Config Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Hooks Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Utf8 Class Initialized
DEBUG - 2011-10-05 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 15:25:57 --> URI Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Router Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Output Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Input Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 15:25:57 --> Language Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Loader Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Controller Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Model Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Model Class Initialized
DEBUG - 2011-10-05 15:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 15:25:57 --> Database Driver Class Initialized
DEBUG - 2011-10-05 15:25:58 --> Final output sent to browser
DEBUG - 2011-10-05 15:25:58 --> Total execution time: 0.6791
DEBUG - 2011-10-05 16:59:36 --> Config Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Hooks Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Utf8 Class Initialized
DEBUG - 2011-10-05 16:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 16:59:36 --> URI Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Router Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Output Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Input Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 16:59:36 --> Language Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Loader Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Controller Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Model Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Model Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Model Class Initialized
DEBUG - 2011-10-05 16:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 16:59:36 --> Database Driver Class Initialized
DEBUG - 2011-10-05 16:59:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 16:59:37 --> Helper loaded: url_helper
DEBUG - 2011-10-05 16:59:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 16:59:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 16:59:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 16:59:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 16:59:37 --> Final output sent to browser
DEBUG - 2011-10-05 16:59:37 --> Total execution time: 0.8162
DEBUG - 2011-10-05 16:59:38 --> Config Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Hooks Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Utf8 Class Initialized
DEBUG - 2011-10-05 16:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 16:59:38 --> URI Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Router Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Output Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Input Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 16:59:38 --> Language Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Loader Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Controller Class Initialized
ERROR - 2011-10-05 16:59:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 16:59:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 16:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 16:59:38 --> Model Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Model Class Initialized
DEBUG - 2011-10-05 16:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 16:59:38 --> Database Driver Class Initialized
DEBUG - 2011-10-05 16:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 16:59:38 --> Helper loaded: url_helper
DEBUG - 2011-10-05 16:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 16:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 16:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 16:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 16:59:38 --> Final output sent to browser
DEBUG - 2011-10-05 16:59:38 --> Total execution time: 0.0913
DEBUG - 2011-10-05 17:53:17 --> Config Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Hooks Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Utf8 Class Initialized
DEBUG - 2011-10-05 17:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 17:53:17 --> URI Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Router Class Initialized
DEBUG - 2011-10-05 17:53:17 --> No URI present. Default controller set.
DEBUG - 2011-10-05 17:53:17 --> Output Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Input Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 17:53:17 --> Language Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Loader Class Initialized
DEBUG - 2011-10-05 17:53:17 --> Controller Class Initialized
DEBUG - 2011-10-05 17:53:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-05 17:53:18 --> Helper loaded: url_helper
DEBUG - 2011-10-05 17:53:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 17:53:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 17:53:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 17:53:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 17:53:18 --> Final output sent to browser
DEBUG - 2011-10-05 17:53:18 --> Total execution time: 0.3398
DEBUG - 2011-10-05 18:08:50 --> Config Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Hooks Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Utf8 Class Initialized
DEBUG - 2011-10-05 18:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 18:08:50 --> URI Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Router Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Output Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Input Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 18:08:50 --> Language Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Loader Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Controller Class Initialized
ERROR - 2011-10-05 18:08:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-05 18:08:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-05 18:08:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 18:08:50 --> Model Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Model Class Initialized
DEBUG - 2011-10-05 18:08:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 18:08:50 --> Database Driver Class Initialized
DEBUG - 2011-10-05 18:08:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-05 18:08:51 --> Helper loaded: url_helper
DEBUG - 2011-10-05 18:08:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 18:08:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 18:08:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 18:08:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 18:08:51 --> Final output sent to browser
DEBUG - 2011-10-05 18:08:51 --> Total execution time: 0.3278
DEBUG - 2011-10-05 18:48:11 --> Config Class Initialized
DEBUG - 2011-10-05 18:48:11 --> Hooks Class Initialized
DEBUG - 2011-10-05 18:48:11 --> Utf8 Class Initialized
DEBUG - 2011-10-05 18:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 18:48:11 --> URI Class Initialized
DEBUG - 2011-10-05 18:48:11 --> Router Class Initialized
ERROR - 2011-10-05 18:48:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-05 18:48:12 --> Config Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Hooks Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Utf8 Class Initialized
DEBUG - 2011-10-05 18:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 18:48:12 --> URI Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Router Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Output Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Input Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 18:48:12 --> Language Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Loader Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Controller Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Model Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Model Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Model Class Initialized
DEBUG - 2011-10-05 18:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-05 18:48:12 --> Database Driver Class Initialized
DEBUG - 2011-10-05 18:48:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-05 18:48:12 --> Helper loaded: url_helper
DEBUG - 2011-10-05 18:48:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 18:48:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 18:48:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 18:48:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 18:48:12 --> Final output sent to browser
DEBUG - 2011-10-05 18:48:12 --> Total execution time: 0.7616
DEBUG - 2011-10-05 18:50:36 --> Config Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Hooks Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Utf8 Class Initialized
DEBUG - 2011-10-05 18:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 18:50:36 --> URI Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Router Class Initialized
DEBUG - 2011-10-05 18:50:36 --> No URI present. Default controller set.
DEBUG - 2011-10-05 18:50:36 --> Output Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Input Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 18:50:36 --> Language Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Loader Class Initialized
DEBUG - 2011-10-05 18:50:36 --> Controller Class Initialized
DEBUG - 2011-10-05 18:50:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-05 18:50:36 --> Helper loaded: url_helper
DEBUG - 2011-10-05 18:50:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 18:50:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 18:50:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 18:50:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 18:50:36 --> Final output sent to browser
DEBUG - 2011-10-05 18:50:36 --> Total execution time: 0.0424
DEBUG - 2011-10-05 23:02:03 --> Config Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Hooks Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Utf8 Class Initialized
DEBUG - 2011-10-05 23:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-05 23:02:03 --> URI Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Router Class Initialized
DEBUG - 2011-10-05 23:02:03 --> No URI present. Default controller set.
DEBUG - 2011-10-05 23:02:03 --> Output Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Input Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-05 23:02:03 --> Language Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Loader Class Initialized
DEBUG - 2011-10-05 23:02:03 --> Controller Class Initialized
DEBUG - 2011-10-05 23:02:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-05 23:02:03 --> Helper loaded: url_helper
DEBUG - 2011-10-05 23:02:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-05 23:02:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-05 23:02:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-05 23:02:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-05 23:02:03 --> Final output sent to browser
DEBUG - 2011-10-05 23:02:03 --> Total execution time: 0.0830

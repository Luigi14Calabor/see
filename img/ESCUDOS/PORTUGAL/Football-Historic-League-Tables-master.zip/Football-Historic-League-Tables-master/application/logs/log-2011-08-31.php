<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-31 00:24:28 --> Config Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:24:28 --> URI Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Router Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Output Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Input Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 00:24:28 --> Language Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Loader Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Controller Class Initialized
ERROR - 2011-08-31 00:24:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 00:24:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 00:24:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 00:24:28 --> Model Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Model Class Initialized
DEBUG - 2011-08-31 00:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 00:24:28 --> Database Driver Class Initialized
DEBUG - 2011-08-31 00:24:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 00:24:28 --> Helper loaded: url_helper
DEBUG - 2011-08-31 00:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 00:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 00:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 00:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 00:24:28 --> Final output sent to browser
DEBUG - 2011-08-31 00:24:28 --> Total execution time: 0.0635
DEBUG - 2011-08-31 00:24:29 --> Config Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:24:29 --> URI Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Router Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Output Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Input Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 00:24:29 --> Language Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Loader Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Controller Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Model Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Model Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 00:24:29 --> Database Driver Class Initialized
DEBUG - 2011-08-31 00:24:29 --> Final output sent to browser
DEBUG - 2011-08-31 00:24:29 --> Total execution time: 0.5458
DEBUG - 2011-08-31 00:24:31 --> Config Class Initialized
DEBUG - 2011-08-31 00:24:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:24:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:24:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:24:31 --> URI Class Initialized
DEBUG - 2011-08-31 00:24:31 --> Router Class Initialized
ERROR - 2011-08-31 00:24:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 00:24:32 --> Config Class Initialized
DEBUG - 2011-08-31 00:24:32 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:24:32 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:24:32 --> URI Class Initialized
DEBUG - 2011-08-31 00:24:32 --> Router Class Initialized
ERROR - 2011-08-31 00:24:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 00:25:25 --> Config Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:25:25 --> URI Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Router Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Output Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Input Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 00:25:25 --> Language Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Loader Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Controller Class Initialized
ERROR - 2011-08-31 00:25:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 00:25:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 00:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 00:25:25 --> Model Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Model Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 00:25:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 00:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 00:25:25 --> Helper loaded: url_helper
DEBUG - 2011-08-31 00:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 00:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 00:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 00:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 00:25:25 --> Final output sent to browser
DEBUG - 2011-08-31 00:25:25 --> Total execution time: 0.0334
DEBUG - 2011-08-31 00:25:25 --> Config Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:25:25 --> URI Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Router Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Output Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Input Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 00:25:25 --> Language Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Loader Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Controller Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Model Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Model Class Initialized
DEBUG - 2011-08-31 00:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 00:25:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 00:25:26 --> Final output sent to browser
DEBUG - 2011-08-31 00:25:26 --> Total execution time: 0.5343
DEBUG - 2011-08-31 00:26:26 --> Config Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:26:26 --> URI Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Router Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Output Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Input Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 00:26:26 --> Language Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Loader Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Controller Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Model Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Model Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Model Class Initialized
DEBUG - 2011-08-31 00:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 00:26:26 --> Database Driver Class Initialized
DEBUG - 2011-08-31 00:26:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 00:26:26 --> Helper loaded: url_helper
DEBUG - 2011-08-31 00:26:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 00:26:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 00:26:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 00:26:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 00:26:26 --> Final output sent to browser
DEBUG - 2011-08-31 00:26:26 --> Total execution time: 0.2255
DEBUG - 2011-08-31 00:54:26 --> Config Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 00:54:26 --> URI Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Router Class Initialized
DEBUG - 2011-08-31 00:54:26 --> No URI present. Default controller set.
DEBUG - 2011-08-31 00:54:26 --> Output Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Input Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 00:54:26 --> Language Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Loader Class Initialized
DEBUG - 2011-08-31 00:54:26 --> Controller Class Initialized
DEBUG - 2011-08-31 00:54:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 00:54:26 --> Helper loaded: url_helper
DEBUG - 2011-08-31 00:54:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 00:54:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 00:54:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 00:54:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 00:54:26 --> Final output sent to browser
DEBUG - 2011-08-31 00:54:26 --> Total execution time: 0.0155
DEBUG - 2011-08-31 01:27:24 --> Config Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:27:24 --> URI Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Router Class Initialized
DEBUG - 2011-08-31 01:27:24 --> No URI present. Default controller set.
DEBUG - 2011-08-31 01:27:24 --> Output Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Input Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:27:24 --> Language Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Loader Class Initialized
DEBUG - 2011-08-31 01:27:24 --> Controller Class Initialized
DEBUG - 2011-08-31 01:27:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 01:27:24 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:27:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:27:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:27:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:27:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:27:24 --> Final output sent to browser
DEBUG - 2011-08-31 01:27:24 --> Total execution time: 0.0436
DEBUG - 2011-08-31 01:46:08 --> Config Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:46:08 --> URI Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Router Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Output Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Input Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:46:08 --> Language Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Loader Class Initialized
DEBUG - 2011-08-31 01:46:08 --> Controller Class Initialized
DEBUG - 2011-08-31 01:46:09 --> Model Class Initialized
DEBUG - 2011-08-31 01:46:09 --> Model Class Initialized
DEBUG - 2011-08-31 01:46:10 --> Model Class Initialized
DEBUG - 2011-08-31 01:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:46:10 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:46:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 01:46:10 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:46:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:46:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:46:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:46:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:46:10 --> Final output sent to browser
DEBUG - 2011-08-31 01:46:10 --> Total execution time: 2.3115
DEBUG - 2011-08-31 01:46:26 --> Config Class Initialized
DEBUG - 2011-08-31 01:46:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:46:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:46:26 --> URI Class Initialized
DEBUG - 2011-08-31 01:46:26 --> Router Class Initialized
ERROR - 2011-08-31 01:46:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:48:41 --> Config Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:48:41 --> URI Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Router Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Output Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Input Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:48:41 --> Language Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Loader Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Controller Class Initialized
ERROR - 2011-08-31 01:48:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:48:41 --> Model Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Model Class Initialized
DEBUG - 2011-08-31 01:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:48:41 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:48:41 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:48:41 --> Final output sent to browser
DEBUG - 2011-08-31 01:48:41 --> Total execution time: 0.0831
DEBUG - 2011-08-31 01:48:43 --> Config Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:48:43 --> URI Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Router Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Output Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Input Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:48:43 --> Language Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Loader Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Controller Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Model Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Model Class Initialized
DEBUG - 2011-08-31 01:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:48:43 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:48:44 --> Final output sent to browser
DEBUG - 2011-08-31 01:48:44 --> Total execution time: 0.7303
DEBUG - 2011-08-31 01:48:50 --> Config Class Initialized
DEBUG - 2011-08-31 01:48:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:48:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:48:50 --> URI Class Initialized
DEBUG - 2011-08-31 01:48:50 --> Router Class Initialized
ERROR - 2011-08-31 01:48:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:49:49 --> Config Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:49:49 --> URI Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Router Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Output Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Input Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:49:49 --> Language Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Loader Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Controller Class Initialized
ERROR - 2011-08-31 01:49:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:49:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:49:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:49:49 --> Model Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Model Class Initialized
DEBUG - 2011-08-31 01:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:49:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:49:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:49:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:49:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:49:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:49:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:49:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:49:49 --> Final output sent to browser
DEBUG - 2011-08-31 01:49:49 --> Total execution time: 0.0284
DEBUG - 2011-08-31 01:49:50 --> Config Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:49:50 --> URI Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Router Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Output Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Input Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:49:50 --> Language Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Loader Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Controller Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Model Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Model Class Initialized
DEBUG - 2011-08-31 01:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:49:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:49:51 --> Final output sent to browser
DEBUG - 2011-08-31 01:49:51 --> Total execution time: 0.8455
DEBUG - 2011-08-31 01:50:01 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:01 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:01 --> Router Class Initialized
ERROR - 2011-08-31 01:50:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:50:23 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:23 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Router Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Output Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Input Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:50:23 --> Language Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Loader Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Controller Class Initialized
ERROR - 2011-08-31 01:50:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:50:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:50:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:23 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:50:23 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:50:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:23 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:50:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:50:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:50:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:50:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:50:23 --> Final output sent to browser
DEBUG - 2011-08-31 01:50:23 --> Total execution time: 0.0417
DEBUG - 2011-08-31 01:50:26 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:26 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Router Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Output Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Input Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:50:26 --> Language Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Loader Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Controller Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:50:26 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:50:26 --> Final output sent to browser
DEBUG - 2011-08-31 01:50:26 --> Total execution time: 0.6067
DEBUG - 2011-08-31 01:50:31 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:31 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:31 --> Router Class Initialized
ERROR - 2011-08-31 01:50:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:50:45 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:45 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Router Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Output Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Input Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:50:45 --> Language Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Loader Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Controller Class Initialized
ERROR - 2011-08-31 01:50:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:50:45 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:45 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:50:45 --> Final output sent to browser
DEBUG - 2011-08-31 01:50:45 --> Total execution time: 0.0352
DEBUG - 2011-08-31 01:50:46 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:46 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Router Class Initialized
ERROR - 2011-08-31 01:50:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 01:50:46 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:46 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Router Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Output Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Input Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:50:46 --> Language Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Loader Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Controller Class Initialized
ERROR - 2011-08-31 01:50:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:50:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:50:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:46 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:50:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:50:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:46 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:50:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:50:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:50:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:50:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:50:46 --> Final output sent to browser
DEBUG - 2011-08-31 01:50:46 --> Total execution time: 0.0653
DEBUG - 2011-08-31 01:50:48 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:48 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Router Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Output Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Input Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:50:48 --> Language Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Loader Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Controller Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:50:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:50:48 --> Final output sent to browser
DEBUG - 2011-08-31 01:50:48 --> Total execution time: 0.7033
DEBUG - 2011-08-31 01:50:55 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:55 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:55 --> Router Class Initialized
ERROR - 2011-08-31 01:50:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:50:57 --> Config Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:50:57 --> URI Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Router Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Output Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Input Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:50:57 --> Language Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Loader Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Controller Class Initialized
ERROR - 2011-08-31 01:50:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:50:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:57 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Model Class Initialized
DEBUG - 2011-08-31 01:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:50:57 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:50:57 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:50:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:50:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:50:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:50:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:50:57 --> Final output sent to browser
DEBUG - 2011-08-31 01:50:57 --> Total execution time: 0.0913
DEBUG - 2011-08-31 01:51:31 --> Config Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:51:31 --> URI Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Router Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Output Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Input Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:51:31 --> Language Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Loader Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Controller Class Initialized
ERROR - 2011-08-31 01:51:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:51:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:51:31 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:51:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:51:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:51:31 --> Final output sent to browser
DEBUG - 2011-08-31 01:51:31 --> Total execution time: 0.0276
DEBUG - 2011-08-31 01:51:33 --> Config Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:51:33 --> URI Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Router Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Output Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Input Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:51:33 --> Language Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Loader Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Controller Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:51:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:51:35 --> Final output sent to browser
DEBUG - 2011-08-31 01:51:35 --> Total execution time: 1.7598
DEBUG - 2011-08-31 01:51:39 --> Config Class Initialized
DEBUG - 2011-08-31 01:51:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:51:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:51:39 --> URI Class Initialized
DEBUG - 2011-08-31 01:51:39 --> Router Class Initialized
ERROR - 2011-08-31 01:51:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:51:55 --> Config Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:51:55 --> URI Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Router Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Output Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Input Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:51:55 --> Language Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Loader Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Controller Class Initialized
ERROR - 2011-08-31 01:51:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:51:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:51:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:51:55 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:51:55 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:51:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:51:55 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:51:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:51:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:51:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:51:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:51:55 --> Final output sent to browser
DEBUG - 2011-08-31 01:51:55 --> Total execution time: 0.0707
DEBUG - 2011-08-31 01:51:57 --> Config Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:51:57 --> URI Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Router Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Output Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Input Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:51:57 --> Language Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Loader Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Controller Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Model Class Initialized
DEBUG - 2011-08-31 01:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:51:57 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:51:58 --> Final output sent to browser
DEBUG - 2011-08-31 01:51:58 --> Total execution time: 1.5316
DEBUG - 2011-08-31 01:52:01 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:01 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:01 --> Router Class Initialized
ERROR - 2011-08-31 01:52:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:52:14 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:14 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Router Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Output Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Input Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:52:14 --> Language Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Loader Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Controller Class Initialized
ERROR - 2011-08-31 01:52:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:52:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:14 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:52:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:14 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:52:14 --> Final output sent to browser
DEBUG - 2011-08-31 01:52:14 --> Total execution time: 0.0302
DEBUG - 2011-08-31 01:52:16 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:16 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Router Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Output Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Input Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:52:16 --> Language Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Loader Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Controller Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:52:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:16 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Router Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Output Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Input Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:52:16 --> Language Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Loader Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Controller Class Initialized
ERROR - 2011-08-31 01:52:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:52:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:52:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:16 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:52:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:52:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:16 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:52:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:52:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:52:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:52:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:52:16 --> Final output sent to browser
DEBUG - 2011-08-31 01:52:16 --> Total execution time: 0.0328
DEBUG - 2011-08-31 01:52:17 --> Final output sent to browser
DEBUG - 2011-08-31 01:52:17 --> Total execution time: 1.0252
DEBUG - 2011-08-31 01:52:25 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:25 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:25 --> Router Class Initialized
ERROR - 2011-08-31 01:52:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:52:37 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:37 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Router Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Output Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Input Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:52:37 --> Language Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Loader Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Controller Class Initialized
ERROR - 2011-08-31 01:52:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:52:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:52:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:37 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:52:37 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:52:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:37 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:52:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:52:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:52:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:52:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:52:37 --> Final output sent to browser
DEBUG - 2011-08-31 01:52:37 --> Total execution time: 0.0298
DEBUG - 2011-08-31 01:52:39 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:39 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Router Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Output Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Input Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:52:39 --> Language Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Loader Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Controller Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:52:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:52:39 --> Final output sent to browser
DEBUG - 2011-08-31 01:52:39 --> Total execution time: 0.6931
DEBUG - 2011-08-31 01:52:40 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:40 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Router Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Output Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Input Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:52:40 --> Language Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Loader Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Controller Class Initialized
ERROR - 2011-08-31 01:52:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:52:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:40 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Model Class Initialized
DEBUG - 2011-08-31 01:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:52:40 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:52:40 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:52:40 --> Final output sent to browser
DEBUG - 2011-08-31 01:52:40 --> Total execution time: 0.0316
DEBUG - 2011-08-31 01:52:43 --> Config Class Initialized
DEBUG - 2011-08-31 01:52:43 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:52:43 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:52:43 --> URI Class Initialized
DEBUG - 2011-08-31 01:52:43 --> Router Class Initialized
ERROR - 2011-08-31 01:52:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:53:14 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:14 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:14 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Controller Class Initialized
ERROR - 2011-08-31 01:53:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:53:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:14 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:53:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:53:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:53:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:53:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:53:14 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:14 --> Total execution time: 0.0307
DEBUG - 2011-08-31 01:53:15 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:15 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:15 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Controller Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:15 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:16 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:16 --> Total execution time: 0.7581
DEBUG - 2011-08-31 01:53:19 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:19 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:19 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:19 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:19 --> Router Class Initialized
ERROR - 2011-08-31 01:53:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:53:31 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:31 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:31 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Controller Class Initialized
ERROR - 2011-08-31 01:53:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:53:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:53:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:31 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:53:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:53:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:53:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:53:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:53:31 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:31 --> Total execution time: 0.0450
DEBUG - 2011-08-31 01:53:32 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:32 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:32 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Controller Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:32 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:33 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:33 --> Total execution time: 0.5654
DEBUG - 2011-08-31 01:53:39 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:39 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:39 --> Router Class Initialized
ERROR - 2011-08-31 01:53:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 01:53:47 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:47 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:47 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Controller Class Initialized
ERROR - 2011-08-31 01:53:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:53:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:53:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:47 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:47 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:53:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:53:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:53:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:53:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:53:47 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:47 --> Total execution time: 0.0529
DEBUG - 2011-08-31 01:53:49 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:49 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:49 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Controller Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:49 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Router Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Output Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Input Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 01:53:49 --> Language Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Loader Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Controller Class Initialized
ERROR - 2011-08-31 01:53:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 01:53:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 01:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:49 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Model Class Initialized
DEBUG - 2011-08-31 01:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 01:53:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 01:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 01:53:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 01:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 01:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 01:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 01:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 01:53:49 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:49 --> Total execution time: 0.0920
DEBUG - 2011-08-31 01:53:50 --> Final output sent to browser
DEBUG - 2011-08-31 01:53:50 --> Total execution time: 0.5692
DEBUG - 2011-08-31 01:53:57 --> Config Class Initialized
DEBUG - 2011-08-31 01:53:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 01:53:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 01:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 01:53:57 --> URI Class Initialized
DEBUG - 2011-08-31 01:53:57 --> Router Class Initialized
ERROR - 2011-08-31 01:53:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 02:09:35 --> Config Class Initialized
DEBUG - 2011-08-31 02:09:35 --> Hooks Class Initialized
DEBUG - 2011-08-31 02:09:35 --> Utf8 Class Initialized
DEBUG - 2011-08-31 02:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 02:09:35 --> URI Class Initialized
DEBUG - 2011-08-31 02:09:35 --> Router Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Output Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Input Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 02:09:36 --> Language Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Loader Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Controller Class Initialized
ERROR - 2011-08-31 02:09:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 02:09:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 02:09:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 02:09:36 --> Model Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Model Class Initialized
DEBUG - 2011-08-31 02:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 02:09:36 --> Database Driver Class Initialized
DEBUG - 2011-08-31 02:09:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 02:09:36 --> Helper loaded: url_helper
DEBUG - 2011-08-31 02:09:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 02:09:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 02:09:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 02:09:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 02:09:36 --> Final output sent to browser
DEBUG - 2011-08-31 02:09:36 --> Total execution time: 0.5086
DEBUG - 2011-08-31 02:09:37 --> Config Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 02:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 02:09:37 --> URI Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Router Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Output Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Input Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 02:09:37 --> Language Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Loader Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Controller Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Model Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Model Class Initialized
DEBUG - 2011-08-31 02:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 02:09:37 --> Database Driver Class Initialized
DEBUG - 2011-08-31 02:09:38 --> Final output sent to browser
DEBUG - 2011-08-31 02:09:38 --> Total execution time: 0.5315
DEBUG - 2011-08-31 02:09:39 --> Config Class Initialized
DEBUG - 2011-08-31 02:09:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 02:09:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 02:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 02:09:39 --> URI Class Initialized
DEBUG - 2011-08-31 02:09:39 --> Router Class Initialized
ERROR - 2011-08-31 02:09:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 02:09:40 --> Config Class Initialized
DEBUG - 2011-08-31 02:09:40 --> Hooks Class Initialized
DEBUG - 2011-08-31 02:09:40 --> Utf8 Class Initialized
DEBUG - 2011-08-31 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 02:09:40 --> URI Class Initialized
DEBUG - 2011-08-31 02:09:40 --> Router Class Initialized
ERROR - 2011-08-31 02:09:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 03:07:56 --> Config Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:07:56 --> URI Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Router Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Output Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Input Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:07:56 --> Language Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Loader Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Controller Class Initialized
ERROR - 2011-08-31 03:07:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 03:07:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 03:07:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:07:56 --> Model Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Model Class Initialized
DEBUG - 2011-08-31 03:07:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:07:56 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:07:58 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:07:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:07:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:07:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:07:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:07:58 --> Final output sent to browser
DEBUG - 2011-08-31 03:07:58 --> Total execution time: 1.5653
DEBUG - 2011-08-31 03:07:59 --> Config Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:07:59 --> URI Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Router Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Output Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Input Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:07:59 --> Language Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Loader Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Controller Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Model Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Model Class Initialized
DEBUG - 2011-08-31 03:07:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:07:59 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:08:01 --> Final output sent to browser
DEBUG - 2011-08-31 03:08:01 --> Total execution time: 1.7147
DEBUG - 2011-08-31 03:08:02 --> Config Class Initialized
DEBUG - 2011-08-31 03:08:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:08:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:08:02 --> URI Class Initialized
DEBUG - 2011-08-31 03:08:02 --> Router Class Initialized
ERROR - 2011-08-31 03:08:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 03:18:44 --> Config Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:18:44 --> URI Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Router Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Output Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Input Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:18:44 --> Language Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Loader Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Controller Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Model Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Model Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Model Class Initialized
DEBUG - 2011-08-31 03:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:18:44 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:18:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:18:44 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:18:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:18:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:18:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:18:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:18:44 --> Final output sent to browser
DEBUG - 2011-08-31 03:18:44 --> Total execution time: 0.7548
DEBUG - 2011-08-31 03:18:59 --> Config Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:18:59 --> URI Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Router Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Output Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Input Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:18:59 --> Language Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Loader Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Controller Class Initialized
ERROR - 2011-08-31 03:18:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 03:18:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 03:18:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:18:59 --> Model Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Model Class Initialized
DEBUG - 2011-08-31 03:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:18:59 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:18:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:18:59 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:18:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:18:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:18:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:18:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:18:59 --> Final output sent to browser
DEBUG - 2011-08-31 03:18:59 --> Total execution time: 0.0526
DEBUG - 2011-08-31 03:32:08 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:08 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:08 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Router Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Router Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Output Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Output Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Input Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Input Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:32:08 --> Language Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Language Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Loader Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Loader Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Controller Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Controller Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Model Class Initialized
ERROR - 2011-08-31 03:32:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 03:32:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:32:08 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:32:08 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:32:08 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:32:08 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:32:08 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:32:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:32:08 --> Final output sent to browser
DEBUG - 2011-08-31 03:32:08 --> Total execution time: 0.2511
DEBUG - 2011-08-31 03:32:08 --> Final output sent to browser
DEBUG - 2011-08-31 03:32:08 --> Total execution time: 0.2513
DEBUG - 2011-08-31 03:32:13 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:13 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Router Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Output Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Input Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:32:13 --> Language Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Loader Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Controller Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:32:13 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:32:14 --> Final output sent to browser
DEBUG - 2011-08-31 03:32:14 --> Total execution time: 1.0691
DEBUG - 2011-08-31 03:32:24 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:24 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:24 --> Router Class Initialized
ERROR - 2011-08-31 03:32:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 03:32:27 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:27 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:27 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:27 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:27 --> Router Class Initialized
ERROR - 2011-08-31 03:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 03:32:28 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:28 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:28 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:28 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:28 --> Router Class Initialized
ERROR - 2011-08-31 03:32:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 03:32:46 --> Config Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:32:46 --> URI Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Router Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Output Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Input Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:32:46 --> Language Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Loader Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Controller Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Model Class Initialized
DEBUG - 2011-08-31 03:32:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:32:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:32:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:32:48 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:32:48 --> Final output sent to browser
DEBUG - 2011-08-31 03:32:48 --> Total execution time: 2.3376
DEBUG - 2011-08-31 03:33:34 --> Config Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:33:34 --> URI Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Router Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Output Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Input Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:33:34 --> Language Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Loader Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Controller Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:33:34 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:33:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:33:35 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:33:35 --> Final output sent to browser
DEBUG - 2011-08-31 03:33:35 --> Total execution time: 0.7455
DEBUG - 2011-08-31 03:33:43 --> Config Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:33:43 --> URI Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Router Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Output Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Input Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:33:43 --> Language Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Loader Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Controller Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:33:43 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:33:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:33:43 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:33:43 --> Final output sent to browser
DEBUG - 2011-08-31 03:33:43 --> Total execution time: 0.0615
DEBUG - 2011-08-31 03:33:46 --> Config Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:33:46 --> URI Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Router Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Output Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Input Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:33:46 --> Language Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Loader Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Controller Class Initialized
ERROR - 2011-08-31 03:33:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 03:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 03:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:33:46 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:33:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:33:46 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:33:46 --> Final output sent to browser
DEBUG - 2011-08-31 03:33:46 --> Total execution time: 0.0323
DEBUG - 2011-08-31 03:33:48 --> Config Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:33:48 --> URI Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Router Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Output Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Input Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:33:48 --> Language Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Loader Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Controller Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Model Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:33:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:33:48 --> Final output sent to browser
DEBUG - 2011-08-31 03:33:48 --> Total execution time: 0.6675
DEBUG - 2011-08-31 03:34:01 --> Config Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:34:01 --> URI Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Router Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Output Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Input Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:34:01 --> Language Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Loader Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Controller Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:34:01 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:34:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:34:01 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:34:01 --> Final output sent to browser
DEBUG - 2011-08-31 03:34:01 --> Total execution time: 0.0814
DEBUG - 2011-08-31 03:34:01 --> Config Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:34:01 --> URI Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Router Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Output Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Input Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:34:01 --> Language Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Loader Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Controller Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:34:01 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:34:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:34:02 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:34:02 --> Final output sent to browser
DEBUG - 2011-08-31 03:34:02 --> Total execution time: 0.7653
DEBUG - 2011-08-31 03:34:03 --> Config Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:34:03 --> URI Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Router Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Output Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Input Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:34:03 --> Language Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Loader Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Controller Class Initialized
ERROR - 2011-08-31 03:34:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 03:34:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 03:34:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:34:03 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:34:03 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:34:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:34:03 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:34:03 --> Final output sent to browser
DEBUG - 2011-08-31 03:34:03 --> Total execution time: 0.0790
DEBUG - 2011-08-31 03:34:05 --> Config Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:34:05 --> URI Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Router Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Output Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Input Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:34:05 --> Language Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Loader Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Controller Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:34:05 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:34:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:34:05 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:34:05 --> Final output sent to browser
DEBUG - 2011-08-31 03:34:05 --> Total execution time: 0.1052
DEBUG - 2011-08-31 03:34:14 --> Config Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:34:14 --> URI Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Router Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Output Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Input Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:34:14 --> Language Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Loader Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Controller Class Initialized
ERROR - 2011-08-31 03:34:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 03:34:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 03:34:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:34:14 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:34:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:34:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 03:34:14 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:34:14 --> Final output sent to browser
DEBUG - 2011-08-31 03:34:14 --> Total execution time: 0.1093
DEBUG - 2011-08-31 03:34:15 --> Config Class Initialized
DEBUG - 2011-08-31 03:34:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:34:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:34:16 --> URI Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Router Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Output Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Input Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:34:16 --> Language Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Loader Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Controller Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Model Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:34:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:34:16 --> Final output sent to browser
DEBUG - 2011-08-31 03:34:16 --> Total execution time: 0.5894
DEBUG - 2011-08-31 03:35:33 --> Config Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:35:33 --> URI Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Router Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Output Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Input Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:35:33 --> Language Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Loader Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Controller Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Model Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Model Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Model Class Initialized
DEBUG - 2011-08-31 03:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:35:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:35:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:35:34 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:35:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:35:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:35:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:35:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:35:34 --> Final output sent to browser
DEBUG - 2011-08-31 03:35:34 --> Total execution time: 1.0992
DEBUG - 2011-08-31 03:35:36 --> Config Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:35:36 --> URI Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Router Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Output Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Input Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:35:36 --> Language Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Loader Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Controller Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Model Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Model Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Model Class Initialized
DEBUG - 2011-08-31 03:35:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:35:36 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:35:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:35:36 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:35:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:35:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:35:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:35:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:35:36 --> Final output sent to browser
DEBUG - 2011-08-31 03:35:36 --> Total execution time: 0.0580
DEBUG - 2011-08-31 03:38:27 --> Config Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:38:27 --> URI Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Router Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Output Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Input Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:38:27 --> Language Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Loader Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Controller Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:38:27 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:38:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:38:27 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:38:27 --> Final output sent to browser
DEBUG - 2011-08-31 03:38:27 --> Total execution time: 0.0633
DEBUG - 2011-08-31 03:38:48 --> Config Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:38:48 --> URI Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Router Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Output Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Input Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:38:48 --> Language Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Loader Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Controller Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:38:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:38:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:38:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:38:49 --> Final output sent to browser
DEBUG - 2011-08-31 03:38:49 --> Total execution time: 0.6829
DEBUG - 2011-08-31 03:38:52 --> Config Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 03:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 03:38:52 --> URI Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Router Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Output Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Input Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 03:38:52 --> Language Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Loader Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Controller Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Model Class Initialized
DEBUG - 2011-08-31 03:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 03:38:52 --> Database Driver Class Initialized
DEBUG - 2011-08-31 03:38:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 03:38:52 --> Helper loaded: url_helper
DEBUG - 2011-08-31 03:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 03:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 03:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 03:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 03:38:52 --> Final output sent to browser
DEBUG - 2011-08-31 03:38:52 --> Total execution time: 0.0938
DEBUG - 2011-08-31 04:48:09 --> Config Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Hooks Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Utf8 Class Initialized
DEBUG - 2011-08-31 04:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 04:48:09 --> URI Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Router Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Output Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Input Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 04:48:09 --> Language Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Loader Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Controller Class Initialized
ERROR - 2011-08-31 04:48:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 04:48:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 04:48:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 04:48:09 --> Model Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Model Class Initialized
DEBUG - 2011-08-31 04:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 04:48:09 --> Database Driver Class Initialized
DEBUG - 2011-08-31 04:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 04:48:10 --> Helper loaded: url_helper
DEBUG - 2011-08-31 04:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 04:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 04:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 04:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 04:48:10 --> Final output sent to browser
DEBUG - 2011-08-31 04:48:10 --> Total execution time: 0.6051
DEBUG - 2011-08-31 05:35:38 --> Config Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:35:38 --> URI Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Router Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Output Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Input Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:35:38 --> Language Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Loader Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Controller Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Model Class Initialized
DEBUG - 2011-08-31 05:35:38 --> Model Class Initialized
DEBUG - 2011-08-31 05:35:39 --> Model Class Initialized
DEBUG - 2011-08-31 05:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:35:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:35:39 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:35:39 --> Final output sent to browser
DEBUG - 2011-08-31 05:35:39 --> Total execution time: 0.7606
DEBUG - 2011-08-31 05:36:08 --> Config Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:36:08 --> URI Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Router Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Output Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Input Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:36:08 --> Language Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Loader Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Controller Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:36:08 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:36:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:36:10 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:36:10 --> Final output sent to browser
DEBUG - 2011-08-31 05:36:10 --> Total execution time: 2.3159
DEBUG - 2011-08-31 05:36:14 --> Config Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:36:14 --> URI Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Router Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Output Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Input Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:36:14 --> Language Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Loader Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Controller Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:36:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:36:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:36:14 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:36:14 --> Final output sent to browser
DEBUG - 2011-08-31 05:36:14 --> Total execution time: 0.0481
DEBUG - 2011-08-31 05:36:48 --> Config Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:36:48 --> URI Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Router Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Output Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Input Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:36:48 --> Language Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Loader Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Controller Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Model Class Initialized
DEBUG - 2011-08-31 05:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:36:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:36:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:36:49 --> Final output sent to browser
DEBUG - 2011-08-31 05:36:49 --> Total execution time: 0.5229
DEBUG - 2011-08-31 05:37:04 --> Config Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:37:04 --> URI Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Router Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Output Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Input Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:37:04 --> Language Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Loader Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Controller Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:37:04 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:37:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:37:04 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:37:04 --> Final output sent to browser
DEBUG - 2011-08-31 05:37:04 --> Total execution time: 0.0471
DEBUG - 2011-08-31 05:37:07 --> Config Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:37:07 --> URI Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Router Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Output Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Input Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:37:07 --> Language Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Loader Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Controller Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:37:07 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:37:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:37:07 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:37:07 --> Final output sent to browser
DEBUG - 2011-08-31 05:37:07 --> Total execution time: 0.0467
DEBUG - 2011-08-31 05:37:10 --> Config Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Hooks Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Utf8 Class Initialized
DEBUG - 2011-08-31 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 05:37:10 --> URI Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Router Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Output Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Input Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 05:37:10 --> Language Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Loader Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Controller Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Model Class Initialized
DEBUG - 2011-08-31 05:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 05:37:10 --> Database Driver Class Initialized
DEBUG - 2011-08-31 05:37:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 05:37:10 --> Helper loaded: url_helper
DEBUG - 2011-08-31 05:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 05:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 05:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 05:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 05:37:10 --> Final output sent to browser
DEBUG - 2011-08-31 05:37:10 --> Total execution time: 0.0495
DEBUG - 2011-08-31 06:07:25 --> Config Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 06:07:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 06:07:25 --> URI Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Router Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Output Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Input Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 06:07:25 --> Language Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Loader Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Controller Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Model Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Model Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Model Class Initialized
DEBUG - 2011-08-31 06:07:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 06:07:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 06:07:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 06:07:25 --> Helper loaded: url_helper
DEBUG - 2011-08-31 06:07:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 06:07:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 06:07:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 06:07:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 06:07:25 --> Final output sent to browser
DEBUG - 2011-08-31 06:07:25 --> Total execution time: 0.5512
DEBUG - 2011-08-31 06:23:56 --> Config Class Initialized
DEBUG - 2011-08-31 06:23:56 --> Hooks Class Initialized
DEBUG - 2011-08-31 06:23:56 --> Utf8 Class Initialized
DEBUG - 2011-08-31 06:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 06:23:56 --> URI Class Initialized
DEBUG - 2011-08-31 06:23:56 --> Router Class Initialized
ERROR - 2011-08-31 06:23:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 06:47:25 --> Config Class Initialized
DEBUG - 2011-08-31 06:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 06:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 06:47:25 --> URI Class Initialized
DEBUG - 2011-08-31 06:47:25 --> Router Class Initialized
ERROR - 2011-08-31 06:47:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 06:47:26 --> Config Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 06:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 06:47:26 --> URI Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Router Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Output Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Input Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 06:47:26 --> Language Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Loader Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Controller Class Initialized
ERROR - 2011-08-31 06:47:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 06:47:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 06:47:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 06:47:26 --> Model Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Model Class Initialized
DEBUG - 2011-08-31 06:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 06:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-31 06:47:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 06:47:26 --> Helper loaded: url_helper
DEBUG - 2011-08-31 06:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 06:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 06:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 06:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 06:47:26 --> Final output sent to browser
DEBUG - 2011-08-31 06:47:26 --> Total execution time: 0.1944
DEBUG - 2011-08-31 07:43:16 --> Config Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 07:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 07:43:16 --> URI Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Router Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Output Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Input Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 07:43:16 --> Language Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Loader Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Controller Class Initialized
ERROR - 2011-08-31 07:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 07:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 07:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 07:43:16 --> Model Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Model Class Initialized
DEBUG - 2011-08-31 07:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 07:43:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 07:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 07:43:16 --> Helper loaded: url_helper
DEBUG - 2011-08-31 07:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 07:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 07:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 07:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 07:43:16 --> Final output sent to browser
DEBUG - 2011-08-31 07:43:16 --> Total execution time: 0.4158
DEBUG - 2011-08-31 08:07:23 --> Config Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Hooks Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Utf8 Class Initialized
DEBUG - 2011-08-31 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 08:07:23 --> URI Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Router Class Initialized
DEBUG - 2011-08-31 08:07:23 --> No URI present. Default controller set.
DEBUG - 2011-08-31 08:07:23 --> Output Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Input Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 08:07:23 --> Language Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Loader Class Initialized
DEBUG - 2011-08-31 08:07:23 --> Controller Class Initialized
DEBUG - 2011-08-31 08:07:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 08:07:23 --> Helper loaded: url_helper
DEBUG - 2011-08-31 08:07:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 08:07:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 08:07:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 08:07:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 08:07:23 --> Final output sent to browser
DEBUG - 2011-08-31 08:07:23 --> Total execution time: 0.0952
DEBUG - 2011-08-31 08:23:58 --> Config Class Initialized
DEBUG - 2011-08-31 08:23:58 --> Hooks Class Initialized
DEBUG - 2011-08-31 08:23:58 --> Utf8 Class Initialized
DEBUG - 2011-08-31 08:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 08:23:58 --> URI Class Initialized
DEBUG - 2011-08-31 08:23:58 --> Router Class Initialized
ERROR - 2011-08-31 08:23:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 08:45:02 --> Config Class Initialized
DEBUG - 2011-08-31 08:45:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 08:45:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 08:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 08:45:03 --> URI Class Initialized
DEBUG - 2011-08-31 08:45:03 --> Router Class Initialized
DEBUG - 2011-08-31 08:45:03 --> No URI present. Default controller set.
DEBUG - 2011-08-31 08:45:03 --> Output Class Initialized
DEBUG - 2011-08-31 08:45:03 --> Input Class Initialized
DEBUG - 2011-08-31 08:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 08:45:03 --> Language Class Initialized
DEBUG - 2011-08-31 08:45:03 --> Loader Class Initialized
DEBUG - 2011-08-31 08:45:03 --> Controller Class Initialized
DEBUG - 2011-08-31 08:45:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 08:45:03 --> Helper loaded: url_helper
DEBUG - 2011-08-31 08:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 08:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 08:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 08:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 08:45:03 --> Final output sent to browser
DEBUG - 2011-08-31 08:45:03 --> Total execution time: 0.2516
DEBUG - 2011-08-31 08:53:10 --> Config Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Hooks Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Utf8 Class Initialized
DEBUG - 2011-08-31 08:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 08:53:10 --> URI Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Router Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Output Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Input Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 08:53:10 --> Language Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Loader Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Controller Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Model Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Model Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Model Class Initialized
DEBUG - 2011-08-31 08:53:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 08:53:10 --> Database Driver Class Initialized
DEBUG - 2011-08-31 08:53:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 08:53:10 --> Helper loaded: url_helper
DEBUG - 2011-08-31 08:53:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 08:53:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 08:53:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 08:53:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 08:53:10 --> Final output sent to browser
DEBUG - 2011-08-31 08:53:10 --> Total execution time: 0.4387
DEBUG - 2011-08-31 09:36:01 --> Config Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:36:01 --> URI Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Router Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Output Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Input Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:36:01 --> Language Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Loader Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Controller Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:36:01 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:36:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:36:02 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:36:02 --> Final output sent to browser
DEBUG - 2011-08-31 09:36:02 --> Total execution time: 0.8565
DEBUG - 2011-08-31 09:36:05 --> Config Class Initialized
DEBUG - 2011-08-31 09:36:05 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:36:06 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:36:06 --> URI Class Initialized
DEBUG - 2011-08-31 09:36:06 --> Router Class Initialized
ERROR - 2011-08-31 09:36:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 09:36:07 --> Config Class Initialized
DEBUG - 2011-08-31 09:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:36:07 --> URI Class Initialized
DEBUG - 2011-08-31 09:36:07 --> Router Class Initialized
ERROR - 2011-08-31 09:36:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 09:36:33 --> Config Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:36:33 --> URI Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Router Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Output Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Input Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:36:33 --> Language Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Loader Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Controller Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:36:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:36:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:36:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:36:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:36:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:36:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:36:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:36:33 --> Final output sent to browser
DEBUG - 2011-08-31 09:36:33 --> Total execution time: 0.0443
DEBUG - 2011-08-31 09:36:46 --> Config Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:36:46 --> URI Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Router Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Output Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Input Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:36:46 --> Language Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Loader Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Controller Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:36:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:36:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:36:46 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:36:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:36:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:36:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:36:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:36:46 --> Final output sent to browser
DEBUG - 2011-08-31 09:36:46 --> Total execution time: 0.2836
DEBUG - 2011-08-31 09:36:47 --> Config Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:36:47 --> URI Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Router Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Output Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Input Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:36:47 --> Language Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Loader Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Controller Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Model Class Initialized
DEBUG - 2011-08-31 09:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:36:47 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:36:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:36:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:36:47 --> Final output sent to browser
DEBUG - 2011-08-31 09:36:47 --> Total execution time: 0.0424
DEBUG - 2011-08-31 09:37:01 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:01 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:01 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:01 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:01 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:01 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:01 --> Total execution time: 0.3506
DEBUG - 2011-08-31 09:37:02 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:02 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:02 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:02 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:02 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:02 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:02 --> Total execution time: 0.0737
DEBUG - 2011-08-31 09:37:16 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:16 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:16 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:16 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:16 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:16 --> Total execution time: 0.3782
DEBUG - 2011-08-31 09:37:17 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:17 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:17 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:17 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:17 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:17 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:17 --> Total execution time: 0.0958
DEBUG - 2011-08-31 09:37:43 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:43 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:43 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:43 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:44 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:44 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:44 --> Total execution time: 0.3580
DEBUG - 2011-08-31 09:37:45 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:45 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:45 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:45 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:45 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:45 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:45 --> Total execution time: 0.0608
DEBUG - 2011-08-31 09:37:52 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:52 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:52 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:52 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:52 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:52 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:52 --> Total execution time: 0.2304
DEBUG - 2011-08-31 09:37:54 --> Config Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:37:54 --> URI Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Router Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Output Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Input Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:37:54 --> Language Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Loader Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Controller Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Model Class Initialized
DEBUG - 2011-08-31 09:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:37:54 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:37:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:37:54 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:37:54 --> Final output sent to browser
DEBUG - 2011-08-31 09:37:54 --> Total execution time: 0.0506
DEBUG - 2011-08-31 09:38:06 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:06 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:06 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:06 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:06 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:06 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:06 --> Total execution time: 0.4608
DEBUG - 2011-08-31 09:38:07 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:07 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:07 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:07 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:07 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:07 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:07 --> Total execution time: 0.0514
DEBUG - 2011-08-31 09:38:23 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:23 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:23 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:23 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:24 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:24 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:24 --> Total execution time: 0.2813
DEBUG - 2011-08-31 09:38:25 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:25 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:25 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:25 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:25 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:25 --> Total execution time: 0.1512
DEBUG - 2011-08-31 09:38:25 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:25 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:25 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:25 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:25 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:25 --> Total execution time: 0.1461
DEBUG - 2011-08-31 09:38:39 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:39 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:39 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:39 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:39 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:39 --> Total execution time: 0.0498
DEBUG - 2011-08-31 09:38:50 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:50 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:50 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:51 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:51 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:51 --> Total execution time: 0.4723
DEBUG - 2011-08-31 09:38:52 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:52 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:52 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:52 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:52 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:52 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:52 --> Total execution time: 0.0712
DEBUG - 2011-08-31 09:38:53 --> Config Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:38:53 --> URI Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Router Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Output Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Input Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:38:53 --> Language Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Loader Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Controller Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Model Class Initialized
DEBUG - 2011-08-31 09:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:38:53 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:38:53 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:38:53 --> Final output sent to browser
DEBUG - 2011-08-31 09:38:53 --> Total execution time: 0.0643
DEBUG - 2011-08-31 09:39:15 --> Config Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:39:15 --> URI Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Router Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Output Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Input Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:39:15 --> Language Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Loader Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Controller Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:39:15 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:39:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:39:15 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:39:15 --> Final output sent to browser
DEBUG - 2011-08-31 09:39:15 --> Total execution time: 0.3639
DEBUG - 2011-08-31 09:39:17 --> Config Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:39:17 --> URI Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Router Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Output Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Input Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:39:17 --> Language Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Loader Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Controller Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:39:17 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:39:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:39:17 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:39:17 --> Final output sent to browser
DEBUG - 2011-08-31 09:39:17 --> Total execution time: 0.0459
DEBUG - 2011-08-31 09:39:29 --> Config Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:39:29 --> URI Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Router Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Output Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Input Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:39:29 --> Language Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Loader Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Controller Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:39:29 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:39:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:39:30 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:39:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:39:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:39:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:39:30 --> Final output sent to browser
DEBUG - 2011-08-31 09:39:30 --> Total execution time: 1.3354
DEBUG - 2011-08-31 09:39:31 --> Config Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:39:31 --> URI Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Router Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Output Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Input Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:39:31 --> Language Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Loader Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Controller Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2011-08-31 09:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:39:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:39:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:39:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:39:31 --> Final output sent to browser
DEBUG - 2011-08-31 09:39:31 --> Total execution time: 0.1288
DEBUG - 2011-08-31 09:47:24 --> Config Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:47:24 --> URI Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Router Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Config Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Output Class Initialized
DEBUG - 2011-08-31 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 09:47:24 --> URI Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Input Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:47:24 --> Language Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Router Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Loader Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Controller Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Model Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Model Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Model Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:47:24 --> Output Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Input Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 09:47:24 --> Language Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Loader Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Controller Class Initialized
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 09:47:24 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:47:24 --> Final output sent to browser
DEBUG - 2011-08-31 09:47:24 --> Total execution time: 0.0491
ERROR - 2011-08-31 09:47:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 09:47:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 09:47:24 --> Model Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Model Class Initialized
DEBUG - 2011-08-31 09:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 09:47:24 --> Database Driver Class Initialized
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 09:47:24 --> Helper loaded: url_helper
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 09:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 09:47:24 --> Final output sent to browser
DEBUG - 2011-08-31 09:47:24 --> Total execution time: 0.0848
DEBUG - 2011-08-31 11:43:48 --> Config Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:43:48 --> URI Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Router Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Output Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Input Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 11:43:48 --> Language Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Loader Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Controller Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Model Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Model Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Model Class Initialized
DEBUG - 2011-08-31 11:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 11:43:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 11:43:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 11:43:48 --> Helper loaded: url_helper
DEBUG - 2011-08-31 11:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 11:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 11:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 11:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 11:43:48 --> Final output sent to browser
DEBUG - 2011-08-31 11:43:48 --> Total execution time: 0.3317
DEBUG - 2011-08-31 11:43:52 --> Config Class Initialized
DEBUG - 2011-08-31 11:43:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:43:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:43:52 --> URI Class Initialized
DEBUG - 2011-08-31 11:43:52 --> Router Class Initialized
ERROR - 2011-08-31 11:43:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 11:43:53 --> Config Class Initialized
DEBUG - 2011-08-31 11:43:53 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:43:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:43:53 --> URI Class Initialized
DEBUG - 2011-08-31 11:43:53 --> Router Class Initialized
ERROR - 2011-08-31 11:43:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 11:43:54 --> Config Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:43:54 --> URI Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Router Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Output Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Input Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 11:43:54 --> Language Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Loader Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Controller Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Model Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Model Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Model Class Initialized
DEBUG - 2011-08-31 11:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 11:43:54 --> Database Driver Class Initialized
DEBUG - 2011-08-31 11:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 11:43:54 --> Helper loaded: url_helper
DEBUG - 2011-08-31 11:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 11:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 11:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 11:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 11:43:54 --> Final output sent to browser
DEBUG - 2011-08-31 11:43:54 --> Total execution time: 0.0746
DEBUG - 2011-08-31 11:44:11 --> Config Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:44:11 --> URI Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Router Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Output Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Input Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 11:44:11 --> Language Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Loader Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Controller Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Model Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Model Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Model Class Initialized
DEBUG - 2011-08-31 11:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 11:44:11 --> Database Driver Class Initialized
DEBUG - 2011-08-31 11:44:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 11:44:11 --> Helper loaded: url_helper
DEBUG - 2011-08-31 11:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 11:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 11:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 11:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 11:44:11 --> Final output sent to browser
DEBUG - 2011-08-31 11:44:11 --> Total execution time: 0.2274
DEBUG - 2011-08-31 11:44:13 --> Config Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:44:13 --> URI Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Router Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Output Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Input Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 11:44:13 --> Language Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Loader Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Controller Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Model Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Model Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Model Class Initialized
DEBUG - 2011-08-31 11:44:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 11:44:13 --> Database Driver Class Initialized
DEBUG - 2011-08-31 11:44:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 11:44:13 --> Helper loaded: url_helper
DEBUG - 2011-08-31 11:44:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 11:44:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 11:44:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 11:44:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 11:44:13 --> Final output sent to browser
DEBUG - 2011-08-31 11:44:13 --> Total execution time: 0.0482
DEBUG - 2011-08-31 11:48:46 --> Config Class Initialized
DEBUG - 2011-08-31 11:48:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:48:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:48:46 --> URI Class Initialized
DEBUG - 2011-08-31 11:48:46 --> Router Class Initialized
ERROR - 2011-08-31 11:48:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 11:58:23 --> Config Class Initialized
DEBUG - 2011-08-31 11:58:23 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:58:23 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:58:23 --> URI Class Initialized
DEBUG - 2011-08-31 11:58:23 --> Router Class Initialized
ERROR - 2011-08-31 11:58:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 11:58:24 --> Config Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 11:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 11:58:24 --> URI Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Router Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Output Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Input Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 11:58:24 --> Language Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Loader Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Controller Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Model Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Model Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Model Class Initialized
DEBUG - 2011-08-31 11:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 11:58:24 --> Database Driver Class Initialized
DEBUG - 2011-08-31 11:58:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 11:58:24 --> Helper loaded: url_helper
DEBUG - 2011-08-31 11:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 11:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 11:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 11:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 11:58:24 --> Final output sent to browser
DEBUG - 2011-08-31 11:58:24 --> Total execution time: 0.5121
DEBUG - 2011-08-31 13:23:58 --> Config Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Hooks Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Utf8 Class Initialized
DEBUG - 2011-08-31 13:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 13:23:58 --> URI Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Router Class Initialized
DEBUG - 2011-08-31 13:23:58 --> No URI present. Default controller set.
DEBUG - 2011-08-31 13:23:58 --> Output Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Input Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 13:23:58 --> Language Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Loader Class Initialized
DEBUG - 2011-08-31 13:23:58 --> Controller Class Initialized
DEBUG - 2011-08-31 13:23:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 13:23:58 --> Helper loaded: url_helper
DEBUG - 2011-08-31 13:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 13:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 13:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 13:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 13:23:58 --> Final output sent to browser
DEBUG - 2011-08-31 13:23:58 --> Total execution time: 0.1208
DEBUG - 2011-08-31 13:52:59 --> Config Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 13:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 13:52:59 --> URI Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Router Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Output Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Input Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 13:52:59 --> Language Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Loader Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Controller Class Initialized
ERROR - 2011-08-31 13:52:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 13:52:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 13:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 13:52:59 --> Model Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Model Class Initialized
DEBUG - 2011-08-31 13:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 13:52:59 --> Database Driver Class Initialized
DEBUG - 2011-08-31 13:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 13:53:00 --> Helper loaded: url_helper
DEBUG - 2011-08-31 13:53:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 13:53:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 13:53:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 13:53:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 13:53:00 --> Final output sent to browser
DEBUG - 2011-08-31 13:53:00 --> Total execution time: 1.1655
DEBUG - 2011-08-31 13:53:02 --> Config Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 13:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 13:53:02 --> URI Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Router Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Output Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Input Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 13:53:02 --> Language Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Loader Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Controller Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Model Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Model Class Initialized
DEBUG - 2011-08-31 13:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 13:53:02 --> Database Driver Class Initialized
DEBUG - 2011-08-31 13:53:03 --> Final output sent to browser
DEBUG - 2011-08-31 13:53:03 --> Total execution time: 1.5646
DEBUG - 2011-08-31 13:55:55 --> Config Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 13:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 13:55:55 --> URI Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Router Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Output Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Input Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 13:55:55 --> Language Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Loader Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Controller Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Model Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Model Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Model Class Initialized
DEBUG - 2011-08-31 13:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 13:55:55 --> Database Driver Class Initialized
DEBUG - 2011-08-31 13:55:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 13:55:55 --> Helper loaded: url_helper
DEBUG - 2011-08-31 13:55:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 13:55:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 13:55:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 13:55:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 13:55:55 --> Final output sent to browser
DEBUG - 2011-08-31 13:55:55 --> Total execution time: 0.2085
DEBUG - 2011-08-31 13:56:00 --> Config Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Hooks Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Utf8 Class Initialized
DEBUG - 2011-08-31 13:56:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 13:56:00 --> URI Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Router Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Output Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Input Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 13:56:00 --> Language Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Loader Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Controller Class Initialized
ERROR - 2011-08-31 13:56:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 13:56:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 13:56:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 13:56:00 --> Model Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Model Class Initialized
DEBUG - 2011-08-31 13:56:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 13:56:00 --> Database Driver Class Initialized
DEBUG - 2011-08-31 13:56:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 13:56:00 --> Helper loaded: url_helper
DEBUG - 2011-08-31 13:56:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 13:56:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 13:56:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 13:56:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 13:56:00 --> Final output sent to browser
DEBUG - 2011-08-31 13:56:00 --> Total execution time: 0.0320
DEBUG - 2011-08-31 13:56:01 --> Config Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 13:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 13:56:01 --> URI Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Router Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Output Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Input Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 13:56:01 --> Language Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Loader Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Controller Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Model Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Model Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 13:56:01 --> Database Driver Class Initialized
DEBUG - 2011-08-31 13:56:01 --> Final output sent to browser
DEBUG - 2011-08-31 13:56:01 --> Total execution time: 0.5441
DEBUG - 2011-08-31 14:19:05 --> Config Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:19:05 --> URI Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Router Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Output Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Input Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 14:19:05 --> Language Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Loader Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Controller Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Model Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Model Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Model Class Initialized
DEBUG - 2011-08-31 14:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 14:19:05 --> Database Driver Class Initialized
DEBUG - 2011-08-31 14:19:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 14:19:05 --> Helper loaded: url_helper
DEBUG - 2011-08-31 14:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 14:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 14:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 14:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 14:19:05 --> Final output sent to browser
DEBUG - 2011-08-31 14:19:05 --> Total execution time: 0.1989
DEBUG - 2011-08-31 14:19:07 --> Config Class Initialized
DEBUG - 2011-08-31 14:19:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:19:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:19:07 --> URI Class Initialized
DEBUG - 2011-08-31 14:19:07 --> Router Class Initialized
ERROR - 2011-08-31 14:19:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 14:20:33 --> Config Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:20:33 --> URI Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Router Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Output Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Input Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 14:20:33 --> Language Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Loader Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Controller Class Initialized
ERROR - 2011-08-31 14:20:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 14:20:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 14:20:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 14:20:33 --> Model Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Model Class Initialized
DEBUG - 2011-08-31 14:20:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 14:20:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 14:20:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 14:20:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 14:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 14:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 14:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 14:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 14:20:33 --> Final output sent to browser
DEBUG - 2011-08-31 14:20:33 --> Total execution time: 0.0284
DEBUG - 2011-08-31 14:20:34 --> Config Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:20:34 --> URI Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Router Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Output Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Input Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 14:20:34 --> Language Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Loader Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Controller Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Model Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Model Class Initialized
DEBUG - 2011-08-31 14:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 14:20:34 --> Database Driver Class Initialized
DEBUG - 2011-08-31 14:20:35 --> Final output sent to browser
DEBUG - 2011-08-31 14:20:35 --> Total execution time: 0.5914
DEBUG - 2011-08-31 14:20:36 --> Config Class Initialized
DEBUG - 2011-08-31 14:20:36 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:20:36 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:20:36 --> URI Class Initialized
DEBUG - 2011-08-31 14:20:36 --> Router Class Initialized
ERROR - 2011-08-31 14:20:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 14:21:10 --> Config Class Initialized
DEBUG - 2011-08-31 14:21:10 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:21:10 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:21:10 --> URI Class Initialized
DEBUG - 2011-08-31 14:21:10 --> Router Class Initialized
ERROR - 2011-08-31 14:21:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 14:49:50 --> Config Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 14:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 14:49:50 --> URI Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Router Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Output Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Input Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 14:49:50 --> Language Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Loader Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Controller Class Initialized
ERROR - 2011-08-31 14:49:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 14:49:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 14:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 14:49:50 --> Model Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Model Class Initialized
DEBUG - 2011-08-31 14:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 14:49:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 14:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 14:49:50 --> Helper loaded: url_helper
DEBUG - 2011-08-31 14:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 14:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 14:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 14:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 14:49:50 --> Final output sent to browser
DEBUG - 2011-08-31 14:49:50 --> Total execution time: 0.0751
DEBUG - 2011-08-31 15:11:08 --> Config Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:11:08 --> URI Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Router Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Output Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Input Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:11:08 --> Language Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Loader Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Controller Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Model Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Model Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Model Class Initialized
DEBUG - 2011-08-31 15:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:11:08 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:11:08 --> Final output sent to browser
DEBUG - 2011-08-31 15:11:08 --> Total execution time: 0.3046
DEBUG - 2011-08-31 15:11:13 --> Config Class Initialized
DEBUG - 2011-08-31 15:11:13 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:11:13 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:11:13 --> URI Class Initialized
DEBUG - 2011-08-31 15:11:13 --> Router Class Initialized
ERROR - 2011-08-31 15:11:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:11:14 --> Config Class Initialized
DEBUG - 2011-08-31 15:11:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:11:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:11:14 --> URI Class Initialized
DEBUG - 2011-08-31 15:11:14 --> Router Class Initialized
ERROR - 2011-08-31 15:11:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:41:15 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:15 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Router Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Output Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Input Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:41:15 --> Language Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Loader Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Controller Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:41:15 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:41:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:41:16 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:41:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:41:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:41:16 --> Final output sent to browser
DEBUG - 2011-08-31 15:41:16 --> Total execution time: 0.5324
DEBUG - 2011-08-31 15:41:19 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:19 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:19 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:19 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:19 --> Router Class Initialized
ERROR - 2011-08-31 15:41:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:41:39 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:39 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Router Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Output Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Input Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:41:39 --> Language Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Loader Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Controller Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:41:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:41:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:41:39 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:41:39 --> Final output sent to browser
DEBUG - 2011-08-31 15:41:39 --> Total execution time: 0.3469
DEBUG - 2011-08-31 15:41:42 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:42 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:42 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:42 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:42 --> Router Class Initialized
ERROR - 2011-08-31 15:41:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:41:53 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:53 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Router Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Output Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Input Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:41:53 --> Language Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Loader Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Controller Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Model Class Initialized
DEBUG - 2011-08-31 15:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:41:53 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:41:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:41:53 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:41:53 --> Final output sent to browser
DEBUG - 2011-08-31 15:41:53 --> Total execution time: 0.3640
DEBUG - 2011-08-31 15:41:56 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:56 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:56 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:56 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:56 --> Router Class Initialized
ERROR - 2011-08-31 15:41:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:41:57 --> Config Class Initialized
DEBUG - 2011-08-31 15:41:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:41:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:41:57 --> URI Class Initialized
DEBUG - 2011-08-31 15:41:57 --> Router Class Initialized
ERROR - 2011-08-31 15:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:42:02 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:02 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Router Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Output Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Input Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:42:02 --> Language Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Loader Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Controller Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:42:02 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:42:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:42:03 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:42:03 --> Final output sent to browser
DEBUG - 2011-08-31 15:42:03 --> Total execution time: 0.3570
DEBUG - 2011-08-31 15:42:04 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:04 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:04 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:04 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:04 --> Router Class Initialized
ERROR - 2011-08-31 15:42:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:42:22 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:22 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Router Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Output Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Input Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:42:22 --> Language Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Loader Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Controller Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:42:22 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:42:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:42:22 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:42:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:42:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:42:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:42:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:42:22 --> Final output sent to browser
DEBUG - 2011-08-31 15:42:22 --> Total execution time: 0.2645
DEBUG - 2011-08-31 15:42:24 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:24 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:24 --> Router Class Initialized
ERROR - 2011-08-31 15:42:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:42:29 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:29 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Router Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Output Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Input Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:42:29 --> Language Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Loader Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Controller Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:42:29 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:42:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:42:30 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:42:30 --> Final output sent to browser
DEBUG - 2011-08-31 15:42:30 --> Total execution time: 0.6403
DEBUG - 2011-08-31 15:42:31 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:31 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:31 --> Router Class Initialized
ERROR - 2011-08-31 15:42:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:42:39 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:39 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Router Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Output Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Input Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:42:39 --> Language Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Loader Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Controller Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:42:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:42:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:42:40 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:42:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:42:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:42:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:42:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:42:40 --> Final output sent to browser
DEBUG - 2011-08-31 15:42:40 --> Total execution time: 0.5281
DEBUG - 2011-08-31 15:42:42 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:42 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:42 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:42 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:42 --> Router Class Initialized
ERROR - 2011-08-31 15:42:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:42:50 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:50 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Router Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Output Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Input Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:42:50 --> Language Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Loader Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Controller Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:42:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:42:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:42:50 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:42:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:42:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:42:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:42:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:42:50 --> Final output sent to browser
DEBUG - 2011-08-31 15:42:50 --> Total execution time: 0.3974
DEBUG - 2011-08-31 15:42:52 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:52 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:52 --> Router Class Initialized
ERROR - 2011-08-31 15:42:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:42:55 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:55 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Router Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Output Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Input Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:42:55 --> Language Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Loader Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Controller Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Model Class Initialized
DEBUG - 2011-08-31 15:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:42:55 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:42:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:42:55 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:42:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:42:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:42:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:42:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:42:55 --> Final output sent to browser
DEBUG - 2011-08-31 15:42:55 --> Total execution time: 0.0455
DEBUG - 2011-08-31 15:42:57 --> Config Class Initialized
DEBUG - 2011-08-31 15:42:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:42:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:42:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:42:57 --> URI Class Initialized
DEBUG - 2011-08-31 15:42:57 --> Router Class Initialized
ERROR - 2011-08-31 15:42:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:00 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:00 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:00 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:00 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:01 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:01 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:01 --> Total execution time: 0.6630
DEBUG - 2011-08-31 15:43:03 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:03 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:03 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:03 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:03 --> Router Class Initialized
ERROR - 2011-08-31 15:43:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:14 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:14 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:14 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:14 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:14 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:14 --> Total execution time: 0.3837
DEBUG - 2011-08-31 15:43:16 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:16 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:16 --> Router Class Initialized
ERROR - 2011-08-31 15:43:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:21 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:21 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:21 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:21 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:22 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:22 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:22 --> Total execution time: 0.7984
DEBUG - 2011-08-31 15:43:24 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:24 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Router Class Initialized
ERROR - 2011-08-31 15:43:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:24 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:24 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Router Class Initialized
ERROR - 2011-08-31 15:43:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 15:43:24 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:24 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:24 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:24 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:24 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:24 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:24 --> Total execution time: 0.0638
DEBUG - 2011-08-31 15:43:27 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:27 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:27 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:27 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:27 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:27 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:27 --> Total execution time: 0.0581
DEBUG - 2011-08-31 15:43:29 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:29 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:29 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:29 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:29 --> Router Class Initialized
ERROR - 2011-08-31 15:43:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:30 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:30 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:30 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:30 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:31 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:31 --> Total execution time: 0.5469
DEBUG - 2011-08-31 15:43:32 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:32 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:32 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:32 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:32 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:32 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:32 --> Total execution time: 0.0645
DEBUG - 2011-08-31 15:43:33 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:33 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:33 --> Router Class Initialized
ERROR - 2011-08-31 15:43:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:39 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:39 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:39 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:40 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:40 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:40 --> Total execution time: 1.0412
DEBUG - 2011-08-31 15:43:42 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:42 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Router Class Initialized
ERROR - 2011-08-31 15:43:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:43:42 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:42 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:42 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:42 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:42 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:43 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:43 --> Total execution time: 0.1937
DEBUG - 2011-08-31 15:43:59 --> Config Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:43:59 --> URI Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Router Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Output Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Input Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:43:59 --> Language Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Loader Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Controller Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Model Class Initialized
DEBUG - 2011-08-31 15:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:43:59 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:43:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:43:59 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:43:59 --> Final output sent to browser
DEBUG - 2011-08-31 15:43:59 --> Total execution time: 0.6569
DEBUG - 2011-08-31 15:44:02 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:02 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:02 --> Router Class Initialized
ERROR - 2011-08-31 15:44:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:44:15 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:15 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Router Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Output Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Input Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:44:15 --> Language Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Loader Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Controller Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:44:15 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:44:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:44:15 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:44:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:44:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:44:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:44:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:44:15 --> Final output sent to browser
DEBUG - 2011-08-31 15:44:15 --> Total execution time: 0.4015
DEBUG - 2011-08-31 15:44:18 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:18 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:18 --> Router Class Initialized
ERROR - 2011-08-31 15:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:44:20 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:20 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Router Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Output Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Input Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:44:20 --> Language Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Loader Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Controller Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:44:20 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:44:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:44:20 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:44:20 --> Final output sent to browser
DEBUG - 2011-08-31 15:44:20 --> Total execution time: 0.0505
DEBUG - 2011-08-31 15:44:22 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:22 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Router Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Output Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Input Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:44:22 --> Language Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Loader Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Controller Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:44:22 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:44:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:44:22 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:44:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:44:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:44:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:44:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:44:22 --> Final output sent to browser
DEBUG - 2011-08-31 15:44:22 --> Total execution time: 0.2248
DEBUG - 2011-08-31 15:44:24 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:24 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:24 --> Router Class Initialized
ERROR - 2011-08-31 15:44:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:44:31 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:31 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Router Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Output Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Input Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:44:31 --> Language Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Loader Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Controller Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:44:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:44:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:44:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:44:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:44:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:44:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:44:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:44:31 --> Final output sent to browser
DEBUG - 2011-08-31 15:44:31 --> Total execution time: 0.3434
DEBUG - 2011-08-31 15:44:33 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:33 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:33 --> Router Class Initialized
ERROR - 2011-08-31 15:44:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 15:44:36 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:36 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Router Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Output Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Input Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 15:44:36 --> Language Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Loader Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Controller Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Model Class Initialized
DEBUG - 2011-08-31 15:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 15:44:36 --> Database Driver Class Initialized
DEBUG - 2011-08-31 15:44:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 15:44:36 --> Helper loaded: url_helper
DEBUG - 2011-08-31 15:44:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 15:44:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 15:44:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 15:44:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 15:44:36 --> Final output sent to browser
DEBUG - 2011-08-31 15:44:36 --> Total execution time: 0.0834
DEBUG - 2011-08-31 15:44:37 --> Config Class Initialized
DEBUG - 2011-08-31 15:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 15:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 15:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 15:44:37 --> URI Class Initialized
DEBUG - 2011-08-31 15:44:37 --> Router Class Initialized
ERROR - 2011-08-31 15:44:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:12:42 --> Config Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:12:42 --> URI Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Router Class Initialized
DEBUG - 2011-08-31 16:12:42 --> No URI present. Default controller set.
DEBUG - 2011-08-31 16:12:42 --> Output Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Input Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:12:42 --> Language Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Loader Class Initialized
DEBUG - 2011-08-31 16:12:42 --> Controller Class Initialized
DEBUG - 2011-08-31 16:12:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 16:12:42 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:12:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:12:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:12:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:12:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:12:42 --> Final output sent to browser
DEBUG - 2011-08-31 16:12:42 --> Total execution time: 0.0811
DEBUG - 2011-08-31 16:28:41 --> Config Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:28:41 --> URI Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Router Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Output Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Input Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:28:41 --> Language Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Loader Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Controller Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Model Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Model Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Model Class Initialized
DEBUG - 2011-08-31 16:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:28:41 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:28:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:28:41 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:28:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:28:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:28:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:28:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:28:41 --> Final output sent to browser
DEBUG - 2011-08-31 16:28:41 --> Total execution time: 0.2157
DEBUG - 2011-08-31 16:28:49 --> Config Class Initialized
DEBUG - 2011-08-31 16:28:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:28:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:28:49 --> URI Class Initialized
DEBUG - 2011-08-31 16:28:49 --> Router Class Initialized
ERROR - 2011-08-31 16:28:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:28:50 --> Config Class Initialized
DEBUG - 2011-08-31 16:28:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:28:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:28:50 --> URI Class Initialized
DEBUG - 2011-08-31 16:28:50 --> Router Class Initialized
ERROR - 2011-08-31 16:28:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:28:51 --> Config Class Initialized
DEBUG - 2011-08-31 16:28:51 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:28:51 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:28:51 --> URI Class Initialized
DEBUG - 2011-08-31 16:28:51 --> Router Class Initialized
ERROR - 2011-08-31 16:28:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:28:52 --> Config Class Initialized
DEBUG - 2011-08-31 16:28:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:28:53 --> URI Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Router Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Output Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Input Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:28:53 --> Language Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Loader Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Controller Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Model Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Model Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Model Class Initialized
DEBUG - 2011-08-31 16:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:28:53 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:28:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:28:53 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:28:53 --> Final output sent to browser
DEBUG - 2011-08-31 16:28:53 --> Total execution time: 0.2963
DEBUG - 2011-08-31 16:29:11 --> Config Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:29:11 --> URI Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Router Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Output Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Input Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:29:11 --> Language Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Loader Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Controller Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:29:11 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:29:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:29:11 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:29:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:29:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:29:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:29:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:29:11 --> Final output sent to browser
DEBUG - 2011-08-31 16:29:11 --> Total execution time: 0.2916
DEBUG - 2011-08-31 16:29:21 --> Config Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:29:21 --> URI Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Router Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Output Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Input Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:29:21 --> Language Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Loader Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Controller Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:29:21 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:29:22 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:29:22 --> Final output sent to browser
DEBUG - 2011-08-31 16:29:22 --> Total execution time: 0.2725
DEBUG - 2011-08-31 16:29:29 --> Config Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:29:29 --> URI Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Router Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Output Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Input Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:29:29 --> Language Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Loader Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Controller Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:29:29 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:29:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:29:29 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:29:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:29:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:29:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:29:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:29:29 --> Final output sent to browser
DEBUG - 2011-08-31 16:29:29 --> Total execution time: 0.2036
DEBUG - 2011-08-31 16:29:38 --> Config Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:29:38 --> URI Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Router Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Output Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Input Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:29:38 --> Language Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Loader Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Controller Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:29:38 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:29:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:29:38 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:29:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:29:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:29:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:29:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:29:38 --> Final output sent to browser
DEBUG - 2011-08-31 16:29:38 --> Total execution time: 0.3200
DEBUG - 2011-08-31 16:29:52 --> Config Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:29:52 --> URI Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Router Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Output Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Input Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:29:52 --> Language Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Loader Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Controller Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Model Class Initialized
DEBUG - 2011-08-31 16:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:29:52 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:29:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:29:53 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:29:53 --> Final output sent to browser
DEBUG - 2011-08-31 16:29:53 --> Total execution time: 0.5274
DEBUG - 2011-08-31 16:30:03 --> Config Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:30:03 --> URI Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Router Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Output Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Input Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:30:03 --> Language Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Loader Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Controller Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:30:03 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:30:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:30:06 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:30:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:30:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:30:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:30:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:30:06 --> Final output sent to browser
DEBUG - 2011-08-31 16:30:06 --> Total execution time: 3.0407
DEBUG - 2011-08-31 16:30:18 --> Config Class Initialized
DEBUG - 2011-08-31 16:30:18 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:30:18 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:30:18 --> URI Class Initialized
DEBUG - 2011-08-31 16:30:18 --> Router Class Initialized
DEBUG - 2011-08-31 16:30:18 --> Output Class Initialized
DEBUG - 2011-08-31 16:30:18 --> Input Class Initialized
DEBUG - 2011-08-31 16:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:30:18 --> Language Class Initialized
DEBUG - 2011-08-31 16:30:19 --> Loader Class Initialized
DEBUG - 2011-08-31 16:30:19 --> Controller Class Initialized
DEBUG - 2011-08-31 16:30:19 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:19 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:19 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:30:19 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:30:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:30:19 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:30:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:30:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:30:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:30:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:30:19 --> Final output sent to browser
DEBUG - 2011-08-31 16:30:19 --> Total execution time: 1.0384
DEBUG - 2011-08-31 16:30:31 --> Config Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:30:31 --> URI Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Router Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Output Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Input Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:30:31 --> Language Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Loader Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Controller Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:30:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:30:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:30:31 --> Final output sent to browser
DEBUG - 2011-08-31 16:30:31 --> Total execution time: 0.2277
DEBUG - 2011-08-31 16:30:50 --> Config Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:30:50 --> URI Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Router Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Output Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Input Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:30:50 --> Language Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Loader Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Controller Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Model Class Initialized
DEBUG - 2011-08-31 16:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:30:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:30:50 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:30:50 --> Final output sent to browser
DEBUG - 2011-08-31 16:30:50 --> Total execution time: 0.2265
DEBUG - 2011-08-31 16:31:07 --> Config Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:31:07 --> URI Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Router Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Output Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Input Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:31:07 --> Language Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Loader Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Controller Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Model Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Model Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Model Class Initialized
DEBUG - 2011-08-31 16:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:31:07 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:31:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 16:31:07 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:31:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:31:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:31:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:31:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:31:07 --> Final output sent to browser
DEBUG - 2011-08-31 16:31:07 --> Total execution time: 0.0451
DEBUG - 2011-08-31 16:33:43 --> Config Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:33:43 --> URI Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Router Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Output Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Input Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:33:43 --> Language Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Loader Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Controller Class Initialized
ERROR - 2011-08-31 16:33:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:33:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:33:43 --> Model Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Model Class Initialized
DEBUG - 2011-08-31 16:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:33:43 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:33:43 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:33:43 --> Final output sent to browser
DEBUG - 2011-08-31 16:33:43 --> Total execution time: 0.0407
DEBUG - 2011-08-31 16:33:46 --> Config Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:33:46 --> URI Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Router Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Output Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Input Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:33:46 --> Language Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Loader Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Controller Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Model Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Model Class Initialized
DEBUG - 2011-08-31 16:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:33:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:33:50 --> Final output sent to browser
DEBUG - 2011-08-31 16:33:50 --> Total execution time: 3.4599
DEBUG - 2011-08-31 16:34:00 --> Config Class Initialized
DEBUG - 2011-08-31 16:34:00 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:34:00 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:34:00 --> URI Class Initialized
DEBUG - 2011-08-31 16:34:00 --> Router Class Initialized
ERROR - 2011-08-31 16:34:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:34:02 --> Config Class Initialized
DEBUG - 2011-08-31 16:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:34:02 --> URI Class Initialized
DEBUG - 2011-08-31 16:34:02 --> Router Class Initialized
ERROR - 2011-08-31 16:34:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:34:39 --> Config Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:34:39 --> URI Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Router Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Output Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Input Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:34:39 --> Language Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Loader Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Controller Class Initialized
ERROR - 2011-08-31 16:34:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:34:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:34:39 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:34:39 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:34:39 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:34:39 --> Final output sent to browser
DEBUG - 2011-08-31 16:34:39 --> Total execution time: 0.0319
DEBUG - 2011-08-31 16:34:49 --> Config Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:34:49 --> URI Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Router Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Output Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Input Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:34:49 --> Language Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Loader Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Controller Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:34:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:34:49 --> Final output sent to browser
DEBUG - 2011-08-31 16:34:49 --> Total execution time: 0.5002
DEBUG - 2011-08-31 16:34:56 --> Config Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:34:56 --> URI Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Router Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Output Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Input Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:34:56 --> Language Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Loader Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Controller Class Initialized
ERROR - 2011-08-31 16:34:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:34:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:34:56 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:34:56 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:34:56 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:34:56 --> Final output sent to browser
DEBUG - 2011-08-31 16:34:56 --> Total execution time: 0.0309
DEBUG - 2011-08-31 16:34:57 --> Config Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:34:57 --> URI Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Router Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Output Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Input Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:34:57 --> Language Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Loader Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Controller Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Model Class Initialized
DEBUG - 2011-08-31 16:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:34:57 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:34:58 --> Final output sent to browser
DEBUG - 2011-08-31 16:34:58 --> Total execution time: 0.7212
DEBUG - 2011-08-31 16:51:26 --> Config Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:51:26 --> URI Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Router Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Output Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Input Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:51:26 --> Language Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Loader Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Controller Class Initialized
ERROR - 2011-08-31 16:51:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:51:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:51:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:51:26 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:51:26 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:51:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:51:26 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:51:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:51:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:51:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:51:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:51:26 --> Final output sent to browser
DEBUG - 2011-08-31 16:51:26 --> Total execution time: 0.0492
DEBUG - 2011-08-31 16:51:27 --> Config Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:51:27 --> URI Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Router Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Output Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Input Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:51:27 --> Language Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Loader Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Controller Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:51:27 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:51:28 --> Final output sent to browser
DEBUG - 2011-08-31 16:51:28 --> Total execution time: 0.5184
DEBUG - 2011-08-31 16:51:31 --> Config Class Initialized
DEBUG - 2011-08-31 16:51:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:51:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:51:31 --> URI Class Initialized
DEBUG - 2011-08-31 16:51:31 --> Router Class Initialized
ERROR - 2011-08-31 16:51:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:51:57 --> Config Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:51:57 --> URI Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Router Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Output Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Input Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:51:57 --> Language Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Loader Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Controller Class Initialized
ERROR - 2011-08-31 16:51:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:51:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:51:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:51:57 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:51:57 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:51:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:51:57 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:51:57 --> Final output sent to browser
DEBUG - 2011-08-31 16:51:57 --> Total execution time: 0.0291
DEBUG - 2011-08-31 16:51:58 --> Config Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:51:58 --> URI Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Router Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Output Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Input Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:51:58 --> Language Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Loader Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Controller Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Model Class Initialized
DEBUG - 2011-08-31 16:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:51:58 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:51:59 --> Final output sent to browser
DEBUG - 2011-08-31 16:51:59 --> Total execution time: 0.4752
DEBUG - 2011-08-31 16:52:01 --> Config Class Initialized
DEBUG - 2011-08-31 16:52:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:52:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:52:01 --> URI Class Initialized
DEBUG - 2011-08-31 16:52:01 --> Router Class Initialized
ERROR - 2011-08-31 16:52:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:52:18 --> Config Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:52:18 --> URI Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Router Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Output Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Input Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:52:18 --> Language Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Loader Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Controller Class Initialized
ERROR - 2011-08-31 16:52:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:52:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:52:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:52:18 --> Model Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Model Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:52:18 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:52:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:52:18 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:52:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:52:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:52:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:52:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:52:18 --> Final output sent to browser
DEBUG - 2011-08-31 16:52:18 --> Total execution time: 0.0265
DEBUG - 2011-08-31 16:52:18 --> Config Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:52:18 --> URI Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Router Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Output Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Input Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:52:18 --> Language Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Loader Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Controller Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Model Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Model Class Initialized
DEBUG - 2011-08-31 16:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:52:18 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:52:19 --> Final output sent to browser
DEBUG - 2011-08-31 16:52:19 --> Total execution time: 0.4798
DEBUG - 2011-08-31 16:52:21 --> Config Class Initialized
DEBUG - 2011-08-31 16:52:21 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:52:21 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:52:21 --> URI Class Initialized
DEBUG - 2011-08-31 16:52:21 --> Router Class Initialized
ERROR - 2011-08-31 16:52:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:53:26 --> Config Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:53:26 --> URI Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Router Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Output Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Input Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:53:26 --> Language Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Loader Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Controller Class Initialized
ERROR - 2011-08-31 16:53:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:53:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:53:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:53:26 --> Model Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Model Class Initialized
DEBUG - 2011-08-31 16:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:53:26 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:53:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:53:26 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:53:26 --> Final output sent to browser
DEBUG - 2011-08-31 16:53:26 --> Total execution time: 0.0282
DEBUG - 2011-08-31 16:53:28 --> Config Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:53:28 --> URI Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Router Class Initialized
ERROR - 2011-08-31 16:53:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 16:53:28 --> Config Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:53:28 --> URI Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Router Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Output Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Input Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:53:28 --> Language Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Loader Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Controller Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Model Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Model Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:53:28 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:53:28 --> Final output sent to browser
DEBUG - 2011-08-31 16:53:28 --> Total execution time: 0.4481
DEBUG - 2011-08-31 16:54:00 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:00 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:00 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Controller Class Initialized
ERROR - 2011-08-31 16:54:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:54:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:54:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:00 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:00 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:00 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:54:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:54:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:54:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:54:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:54:00 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:00 --> Total execution time: 0.0404
DEBUG - 2011-08-31 16:54:01 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:01 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:01 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Controller Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:01 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:02 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:02 --> Total execution time: 0.6171
DEBUG - 2011-08-31 16:54:13 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:13 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:13 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Controller Class Initialized
ERROR - 2011-08-31 16:54:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:54:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:13 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:13 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:13 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:54:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:54:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:54:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:54:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:54:13 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:13 --> Total execution time: 0.0290
DEBUG - 2011-08-31 16:54:14 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:14 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:14 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Controller Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:14 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:14 --> Total execution time: 0.4586
DEBUG - 2011-08-31 16:54:33 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:33 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:33 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Controller Class Initialized
ERROR - 2011-08-31 16:54:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:54:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:54:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:33 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:54:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:54:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:54:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:54:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:54:33 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:33 --> Total execution time: 0.0291
DEBUG - 2011-08-31 16:54:33 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:33 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:33 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Controller Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:34 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:34 --> Total execution time: 0.5545
DEBUG - 2011-08-31 16:54:45 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:45 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:45 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Controller Class Initialized
ERROR - 2011-08-31 16:54:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 16:54:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 16:54:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:45 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:45 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 16:54:45 --> Helper loaded: url_helper
DEBUG - 2011-08-31 16:54:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 16:54:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 16:54:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 16:54:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 16:54:45 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:45 --> Total execution time: 0.0281
DEBUG - 2011-08-31 16:54:45 --> Config Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Hooks Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Utf8 Class Initialized
DEBUG - 2011-08-31 16:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 16:54:45 --> URI Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Router Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Output Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Input Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 16:54:45 --> Language Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Loader Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Controller Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Model Class Initialized
DEBUG - 2011-08-31 16:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 16:54:45 --> Database Driver Class Initialized
DEBUG - 2011-08-31 16:54:46 --> Final output sent to browser
DEBUG - 2011-08-31 16:54:46 --> Total execution time: 0.6245
DEBUG - 2011-08-31 17:46:56 --> Config Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:46:56 --> URI Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Router Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Output Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Input Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:46:56 --> Language Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Loader Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Controller Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Model Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Model Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Model Class Initialized
DEBUG - 2011-08-31 17:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:46:56 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:46:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 17:46:56 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:46:56 --> Final output sent to browser
DEBUG - 2011-08-31 17:46:56 --> Total execution time: 0.6760
DEBUG - 2011-08-31 17:56:40 --> Config Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:56:40 --> URI Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Router Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Output Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Input Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:56:40 --> Language Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Loader Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Controller Class Initialized
ERROR - 2011-08-31 17:56:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 17:56:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 17:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:56:40 --> Model Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Model Class Initialized
DEBUG - 2011-08-31 17:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:56:40 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:56:40 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:56:40 --> Final output sent to browser
DEBUG - 2011-08-31 17:56:40 --> Total execution time: 0.0660
DEBUG - 2011-08-31 17:56:49 --> Config Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:56:49 --> URI Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Router Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Output Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Input Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:56:49 --> Language Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Loader Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Controller Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Model Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Model Class Initialized
DEBUG - 2011-08-31 17:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:56:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:56:50 --> Final output sent to browser
DEBUG - 2011-08-31 17:56:50 --> Total execution time: 0.6925
DEBUG - 2011-08-31 17:57:38 --> Config Class Initialized
DEBUG - 2011-08-31 17:57:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:57:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:57:38 --> URI Class Initialized
DEBUG - 2011-08-31 17:57:38 --> Router Class Initialized
ERROR - 2011-08-31 17:57:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:57:38 --> Config Class Initialized
DEBUG - 2011-08-31 17:57:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:57:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:57:38 --> URI Class Initialized
DEBUG - 2011-08-31 17:57:38 --> Router Class Initialized
ERROR - 2011-08-31 17:57:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:57:49 --> Config Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:57:49 --> URI Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Router Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Output Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Input Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:57:49 --> Language Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Loader Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Controller Class Initialized
ERROR - 2011-08-31 17:57:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 17:57:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 17:57:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:57:49 --> Model Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Model Class Initialized
DEBUG - 2011-08-31 17:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:57:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:57:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:57:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:57:49 --> Final output sent to browser
DEBUG - 2011-08-31 17:57:49 --> Total execution time: 0.0295
DEBUG - 2011-08-31 17:57:50 --> Config Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:57:50 --> URI Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Router Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Output Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Input Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:57:50 --> Language Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Loader Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Controller Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Model Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Model Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:57:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:57:50 --> Final output sent to browser
DEBUG - 2011-08-31 17:57:50 --> Total execution time: 0.6268
DEBUG - 2011-08-31 17:57:51 --> Config Class Initialized
DEBUG - 2011-08-31 17:57:51 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:57:51 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:57:51 --> URI Class Initialized
DEBUG - 2011-08-31 17:57:51 --> Router Class Initialized
ERROR - 2011-08-31 17:57:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:58:15 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:15 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Router Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Output Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Input Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:58:15 --> Language Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Loader Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Controller Class Initialized
ERROR - 2011-08-31 17:58:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 17:58:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 17:58:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:58:15 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:58:15 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:58:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:58:15 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:58:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:58:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:58:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:58:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:58:15 --> Final output sent to browser
DEBUG - 2011-08-31 17:58:15 --> Total execution time: 0.0275
DEBUG - 2011-08-31 17:58:16 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:16 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Router Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Output Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Input Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:58:16 --> Language Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Loader Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Controller Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:58:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:58:16 --> Final output sent to browser
DEBUG - 2011-08-31 17:58:16 --> Total execution time: 0.4894
DEBUG - 2011-08-31 17:58:17 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:17 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:17 --> Router Class Initialized
ERROR - 2011-08-31 17:58:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:58:27 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:27 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Router Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Output Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Input Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:58:27 --> Language Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Loader Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Controller Class Initialized
ERROR - 2011-08-31 17:58:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 17:58:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 17:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:58:27 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:58:27 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:58:27 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:58:27 --> Final output sent to browser
DEBUG - 2011-08-31 17:58:27 --> Total execution time: 0.0277
DEBUG - 2011-08-31 17:58:27 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:27 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Router Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Output Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Input Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:58:27 --> Language Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Loader Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Controller Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:58:27 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:58:28 --> Final output sent to browser
DEBUG - 2011-08-31 17:58:28 --> Total execution time: 0.5117
DEBUG - 2011-08-31 17:58:44 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:44 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Router Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Output Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Input Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:58:44 --> Language Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Loader Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Controller Class Initialized
ERROR - 2011-08-31 17:58:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 17:58:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 17:58:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:58:44 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:58:44 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:44 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Router Class Initialized
ERROR - 2011-08-31 17:58:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:58:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 17:58:44 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:58:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:58:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:58:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:58:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:58:44 --> Final output sent to browser
DEBUG - 2011-08-31 17:58:44 --> Total execution time: 0.0296
DEBUG - 2011-08-31 17:58:44 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:44 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Router Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Output Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Input Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:58:44 --> Language Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Loader Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Controller Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Model Class Initialized
DEBUG - 2011-08-31 17:58:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:58:44 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:58:45 --> Final output sent to browser
DEBUG - 2011-08-31 17:58:45 --> Total execution time: 0.5873
DEBUG - 2011-08-31 17:58:46 --> Config Class Initialized
DEBUG - 2011-08-31 17:58:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:58:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:58:46 --> URI Class Initialized
DEBUG - 2011-08-31 17:58:46 --> Router Class Initialized
ERROR - 2011-08-31 17:58:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:59:17 --> Config Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:59:17 --> URI Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Router Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Output Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Input Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:59:17 --> Language Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Loader Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Controller Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:59:17 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 17:59:17 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:59:17 --> Final output sent to browser
DEBUG - 2011-08-31 17:59:17 --> Total execution time: 0.0603
DEBUG - 2011-08-31 17:59:19 --> Config Class Initialized
DEBUG - 2011-08-31 17:59:19 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:59:19 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:59:19 --> URI Class Initialized
DEBUG - 2011-08-31 17:59:19 --> Router Class Initialized
ERROR - 2011-08-31 17:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:59:35 --> Config Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:59:35 --> URI Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Router Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Output Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Input Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:59:35 --> Language Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Loader Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Controller Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:59:35 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:59:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 17:59:35 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:59:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:59:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:59:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:59:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:59:35 --> Final output sent to browser
DEBUG - 2011-08-31 17:59:35 --> Total execution time: 0.2953
DEBUG - 2011-08-31 17:59:37 --> Config Class Initialized
DEBUG - 2011-08-31 17:59:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:59:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:59:37 --> URI Class Initialized
DEBUG - 2011-08-31 17:59:37 --> Router Class Initialized
ERROR - 2011-08-31 17:59:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 17:59:48 --> Config Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:59:48 --> URI Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Router Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Output Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Input Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 17:59:48 --> Language Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Loader Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Controller Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Model Class Initialized
DEBUG - 2011-08-31 17:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 17:59:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 17:59:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 17:59:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 17:59:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 17:59:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 17:59:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 17:59:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 17:59:49 --> Final output sent to browser
DEBUG - 2011-08-31 17:59:49 --> Total execution time: 0.9925
DEBUG - 2011-08-31 17:59:51 --> Config Class Initialized
DEBUG - 2011-08-31 17:59:51 --> Hooks Class Initialized
DEBUG - 2011-08-31 17:59:51 --> Utf8 Class Initialized
DEBUG - 2011-08-31 17:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 17:59:51 --> URI Class Initialized
DEBUG - 2011-08-31 17:59:51 --> Router Class Initialized
ERROR - 2011-08-31 17:59:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:00:11 --> Config Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:00:11 --> URI Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Router Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Output Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Input Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:00:11 --> Language Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Loader Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Controller Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Model Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Model Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Model Class Initialized
DEBUG - 2011-08-31 18:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:00:11 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:00:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:00:12 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:00:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:00:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:00:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:00:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:00:12 --> Final output sent to browser
DEBUG - 2011-08-31 18:00:12 --> Total execution time: 1.0805
DEBUG - 2011-08-31 18:00:14 --> Config Class Initialized
DEBUG - 2011-08-31 18:00:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:00:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:00:14 --> URI Class Initialized
DEBUG - 2011-08-31 18:00:14 --> Router Class Initialized
ERROR - 2011-08-31 18:00:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:00:24 --> Config Class Initialized
DEBUG - 2011-08-31 18:00:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:00:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:00:24 --> URI Class Initialized
DEBUG - 2011-08-31 18:00:24 --> Router Class Initialized
DEBUG - 2011-08-31 18:00:24 --> Output Class Initialized
DEBUG - 2011-08-31 18:00:24 --> Input Class Initialized
DEBUG - 2011-08-31 18:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:00:24 --> Language Class Initialized
DEBUG - 2011-08-31 18:00:25 --> Loader Class Initialized
DEBUG - 2011-08-31 18:00:25 --> Controller Class Initialized
DEBUG - 2011-08-31 18:00:25 --> Model Class Initialized
DEBUG - 2011-08-31 18:00:25 --> Model Class Initialized
DEBUG - 2011-08-31 18:00:25 --> Model Class Initialized
DEBUG - 2011-08-31 18:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:00:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:00:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:00:25 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:00:25 --> Final output sent to browser
DEBUG - 2011-08-31 18:00:25 --> Total execution time: 0.4334
DEBUG - 2011-08-31 18:00:26 --> Config Class Initialized
DEBUG - 2011-08-31 18:00:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:00:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:00:26 --> URI Class Initialized
DEBUG - 2011-08-31 18:00:26 --> Router Class Initialized
ERROR - 2011-08-31 18:00:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:01:03 --> Config Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:01:03 --> URI Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Router Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Output Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Input Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:01:03 --> Language Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Loader Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Controller Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:01:03 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:01:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:01:03 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:01:03 --> Final output sent to browser
DEBUG - 2011-08-31 18:01:03 --> Total execution time: 0.2825
DEBUG - 2011-08-31 18:01:05 --> Config Class Initialized
DEBUG - 2011-08-31 18:01:05 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:01:05 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:01:05 --> URI Class Initialized
DEBUG - 2011-08-31 18:01:05 --> Router Class Initialized
ERROR - 2011-08-31 18:01:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:01:17 --> Config Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:01:17 --> URI Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Router Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Output Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Input Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:01:17 --> Language Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Loader Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Controller Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:01:17 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:01:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:01:19 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:01:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:01:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:01:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:01:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:01:19 --> Final output sent to browser
DEBUG - 2011-08-31 18:01:19 --> Total execution time: 1.6301
DEBUG - 2011-08-31 18:01:20 --> Config Class Initialized
DEBUG - 2011-08-31 18:01:20 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:01:20 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:01:20 --> URI Class Initialized
DEBUG - 2011-08-31 18:01:20 --> Router Class Initialized
ERROR - 2011-08-31 18:01:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:01:38 --> Config Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:01:38 --> URI Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Router Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Output Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Input Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:01:38 --> Language Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Loader Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Controller Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Model Class Initialized
DEBUG - 2011-08-31 18:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:01:38 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:01:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:01:38 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:01:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:01:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:01:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:01:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:01:38 --> Final output sent to browser
DEBUG - 2011-08-31 18:01:38 --> Total execution time: 0.3239
DEBUG - 2011-08-31 18:01:40 --> Config Class Initialized
DEBUG - 2011-08-31 18:01:40 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:01:40 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:01:40 --> URI Class Initialized
DEBUG - 2011-08-31 18:01:40 --> Router Class Initialized
ERROR - 2011-08-31 18:01:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:06:48 --> Config Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:06:48 --> URI Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Router Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Output Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Input Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:06:48 --> Language Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Loader Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Controller Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Model Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Model Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Model Class Initialized
DEBUG - 2011-08-31 18:06:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:06:48 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:06:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:06:48 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:06:48 --> Final output sent to browser
DEBUG - 2011-08-31 18:06:48 --> Total execution time: 0.2032
DEBUG - 2011-08-31 18:06:50 --> Config Class Initialized
DEBUG - 2011-08-31 18:06:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:06:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:06:50 --> URI Class Initialized
DEBUG - 2011-08-31 18:06:50 --> Router Class Initialized
ERROR - 2011-08-31 18:06:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:07:08 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:08 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Router Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Output Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Input Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:07:08 --> Language Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Loader Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Controller Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:07:08 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:07:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:07:08 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:07:08 --> Final output sent to browser
DEBUG - 2011-08-31 18:07:08 --> Total execution time: 0.3664
DEBUG - 2011-08-31 18:07:09 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:09 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:09 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:09 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:09 --> Router Class Initialized
ERROR - 2011-08-31 18:07:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:07:22 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:22 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Router Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Output Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Input Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:07:22 --> Language Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Loader Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Controller Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:07:22 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:07:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:07:22 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:07:22 --> Final output sent to browser
DEBUG - 2011-08-31 18:07:22 --> Total execution time: 0.2009
DEBUG - 2011-08-31 18:07:23 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:23 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:23 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:23 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:23 --> Router Class Initialized
ERROR - 2011-08-31 18:07:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:07:34 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:34 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Router Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Output Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Input Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:07:34 --> Language Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Loader Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Controller Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:07:34 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:07:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:07:34 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:07:34 --> Final output sent to browser
DEBUG - 2011-08-31 18:07:34 --> Total execution time: 0.8206
DEBUG - 2011-08-31 18:07:46 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:46 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Router Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Output Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Input Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:07:46 --> Language Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Loader Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Controller Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:07:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:46 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:46 --> Router Class Initialized
ERROR - 2011-08-31 18:07:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:07:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:07:46 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:07:46 --> Final output sent to browser
DEBUG - 2011-08-31 18:07:46 --> Total execution time: 0.1234
DEBUG - 2011-08-31 18:07:47 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:47 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:47 --> Router Class Initialized
ERROR - 2011-08-31 18:07:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:07:54 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:54 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Router Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Output Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Input Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:07:54 --> Language Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Loader Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Controller Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Model Class Initialized
DEBUG - 2011-08-31 18:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:07:54 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:07:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:07:54 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:07:54 --> Final output sent to browser
DEBUG - 2011-08-31 18:07:54 --> Total execution time: 0.0781
DEBUG - 2011-08-31 18:07:55 --> Config Class Initialized
DEBUG - 2011-08-31 18:07:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:07:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:07:55 --> URI Class Initialized
DEBUG - 2011-08-31 18:07:55 --> Router Class Initialized
ERROR - 2011-08-31 18:07:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:08:18 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:18 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Router Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Output Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Input Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:08:18 --> Language Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Loader Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Controller Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:08:18 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:08:18 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:08:18 --> Final output sent to browser
DEBUG - 2011-08-31 18:08:18 --> Total execution time: 0.5077
DEBUG - 2011-08-31 18:08:26 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:26 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:26 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:26 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:26 --> Router Class Initialized
ERROR - 2011-08-31 18:08:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:08:33 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:33 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Router Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Output Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Input Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:08:33 --> Language Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Loader Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Controller Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:08:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:08:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:08:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:08:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:08:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:08:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:08:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:08:33 --> Final output sent to browser
DEBUG - 2011-08-31 18:08:33 --> Total execution time: 0.2479
DEBUG - 2011-08-31 18:08:34 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:34 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:34 --> Router Class Initialized
ERROR - 2011-08-31 18:08:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:08:47 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:47 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Router Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Output Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Input Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:08:47 --> Language Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Loader Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Controller Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:08:47 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:08:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:08:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:08:47 --> Final output sent to browser
DEBUG - 2011-08-31 18:08:47 --> Total execution time: 0.2958
DEBUG - 2011-08-31 18:08:48 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:48 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:48 --> Router Class Initialized
ERROR - 2011-08-31 18:08:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:08:56 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:56 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Router Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Output Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Input Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:08:56 --> Language Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Loader Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Controller Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Model Class Initialized
DEBUG - 2011-08-31 18:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:08:56 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:08:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:08:57 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:08:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:08:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:08:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:08:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:08:57 --> Final output sent to browser
DEBUG - 2011-08-31 18:08:57 --> Total execution time: 0.4177
DEBUG - 2011-08-31 18:08:58 --> Config Class Initialized
DEBUG - 2011-08-31 18:08:58 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:08:58 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:08:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:08:58 --> URI Class Initialized
DEBUG - 2011-08-31 18:08:58 --> Router Class Initialized
ERROR - 2011-08-31 18:08:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:09:08 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:08 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Router Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Output Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Input Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:09:08 --> Language Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Loader Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Controller Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:09:08 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:09:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:09:09 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:09:09 --> Final output sent to browser
DEBUG - 2011-08-31 18:09:09 --> Total execution time: 0.4776
DEBUG - 2011-08-31 18:09:10 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:10 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:10 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:10 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:10 --> Router Class Initialized
ERROR - 2011-08-31 18:09:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:09:10 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:10 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:10 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:10 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:10 --> Router Class Initialized
ERROR - 2011-08-31 18:09:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:09:20 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:20 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Router Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Output Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Input Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:09:20 --> Language Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Loader Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Controller Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:09:20 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:09:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:09:20 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:09:20 --> Final output sent to browser
DEBUG - 2011-08-31 18:09:20 --> Total execution time: 0.2761
DEBUG - 2011-08-31 18:09:22 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:22 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:22 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:22 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:22 --> Router Class Initialized
ERROR - 2011-08-31 18:09:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:09:35 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:35 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Router Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Output Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Input Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:09:35 --> Language Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Loader Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Controller Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Model Class Initialized
DEBUG - 2011-08-31 18:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:09:35 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:09:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:09:35 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:09:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:09:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:09:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:09:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:09:35 --> Final output sent to browser
DEBUG - 2011-08-31 18:09:35 --> Total execution time: 0.1116
DEBUG - 2011-08-31 18:09:36 --> Config Class Initialized
DEBUG - 2011-08-31 18:09:36 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:09:36 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:09:36 --> URI Class Initialized
DEBUG - 2011-08-31 18:09:36 --> Router Class Initialized
ERROR - 2011-08-31 18:09:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:18:55 --> Config Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:18:55 --> URI Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Router Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Output Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Input Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:18:55 --> Language Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Loader Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Controller Class Initialized
ERROR - 2011-08-31 18:18:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 18:18:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 18:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 18:18:55 --> Model Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Model Class Initialized
DEBUG - 2011-08-31 18:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:18:55 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:18:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 18:18:56 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:18:56 --> Final output sent to browser
DEBUG - 2011-08-31 18:18:56 --> Total execution time: 0.2061
DEBUG - 2011-08-31 18:18:57 --> Config Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:18:57 --> URI Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Router Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Output Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Input Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:18:57 --> Language Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Loader Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Controller Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Model Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Model Class Initialized
DEBUG - 2011-08-31 18:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:18:57 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:18:58 --> Final output sent to browser
DEBUG - 2011-08-31 18:18:58 --> Total execution time: 0.9007
DEBUG - 2011-08-31 18:18:59 --> Config Class Initialized
DEBUG - 2011-08-31 18:18:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:18:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:18:59 --> URI Class Initialized
DEBUG - 2011-08-31 18:18:59 --> Router Class Initialized
ERROR - 2011-08-31 18:18:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:22:31 --> Config Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:22:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:22:31 --> URI Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Router Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Output Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Input Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:22:31 --> Language Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Loader Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Controller Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:22:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:22:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:22:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:22:31 --> Final output sent to browser
DEBUG - 2011-08-31 18:22:31 --> Total execution time: 0.0688
DEBUG - 2011-08-31 18:22:34 --> Config Class Initialized
DEBUG - 2011-08-31 18:22:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:22:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:22:34 --> URI Class Initialized
DEBUG - 2011-08-31 18:22:34 --> Router Class Initialized
ERROR - 2011-08-31 18:22:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:22:34 --> Config Class Initialized
DEBUG - 2011-08-31 18:22:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:22:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:22:34 --> URI Class Initialized
DEBUG - 2011-08-31 18:22:34 --> Router Class Initialized
ERROR - 2011-08-31 18:22:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:22:47 --> Config Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:22:47 --> URI Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Router Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Output Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Input Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:22:47 --> Language Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Loader Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Controller Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:22:47 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:22:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:22:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:22:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:22:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:22:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:22:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:22:47 --> Final output sent to browser
DEBUG - 2011-08-31 18:22:47 --> Total execution time: 0.3253
DEBUG - 2011-08-31 18:22:49 --> Config Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:22:49 --> URI Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Router Class Initialized
ERROR - 2011-08-31 18:22:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:22:49 --> Config Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:22:49 --> URI Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Router Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Output Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Input Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:22:49 --> Language Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Loader Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Controller Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-31 18:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:22:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:22:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:22:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:22:49 --> Final output sent to browser
DEBUG - 2011-08-31 18:22:49 --> Total execution time: 0.1775
DEBUG - 2011-08-31 18:23:01 --> Config Class Initialized
DEBUG - 2011-08-31 18:23:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:23:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:23:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:23:01 --> URI Class Initialized
DEBUG - 2011-08-31 18:23:01 --> Router Class Initialized
ERROR - 2011-08-31 18:23:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 18:34:13 --> Config Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:34:13 --> URI Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Router Class Initialized
DEBUG - 2011-08-31 18:34:13 --> No URI present. Default controller set.
DEBUG - 2011-08-31 18:34:13 --> Output Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Input Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:34:13 --> Language Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Loader Class Initialized
DEBUG - 2011-08-31 18:34:13 --> Controller Class Initialized
DEBUG - 2011-08-31 18:34:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 18:34:13 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:34:13 --> Final output sent to browser
DEBUG - 2011-08-31 18:34:13 --> Total execution time: 0.1284
DEBUG - 2011-08-31 18:45:21 --> Config Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Hooks Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Utf8 Class Initialized
DEBUG - 2011-08-31 18:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 18:45:21 --> URI Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Router Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Output Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Input Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 18:45:21 --> Language Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Loader Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Controller Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Model Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Model Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Model Class Initialized
DEBUG - 2011-08-31 18:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 18:45:21 --> Database Driver Class Initialized
DEBUG - 2011-08-31 18:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 18:45:21 --> Helper loaded: url_helper
DEBUG - 2011-08-31 18:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 18:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 18:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 18:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 18:45:21 --> Final output sent to browser
DEBUG - 2011-08-31 18:45:21 --> Total execution time: 0.2321
DEBUG - 2011-08-31 19:19:17 --> Config Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:19:17 --> URI Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Config Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Router Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:19:17 --> URI Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Output Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Router Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Input Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:19:17 --> Language Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Output Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Input Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:19:17 --> Language Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Loader Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Controller Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Loader Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:19:17 --> Controller Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:19:17 --> Config Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:19:17 --> URI Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Router Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Output Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Input Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:19:17 --> Language Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Loader Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Controller Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:19:18 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:19:18 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:19:18 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 19:19:18 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:19:18 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:19:18 --> Final output sent to browser
DEBUG - 2011-08-31 19:19:18 --> Total execution time: 0.8654
DEBUG - 2011-08-31 19:19:18 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:19:18 --> Final output sent to browser
DEBUG - 2011-08-31 19:19:18 --> Total execution time: 0.8759
DEBUG - 2011-08-31 19:19:18 --> Final output sent to browser
DEBUG - 2011-08-31 19:19:18 --> Total execution time: 0.8819
DEBUG - 2011-08-31 19:19:19 --> Config Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:19:19 --> URI Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Router Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Output Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Input Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:19:19 --> Language Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Loader Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Controller Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Config Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:19:19 --> URI Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Router Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Output Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Input Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:19:19 --> Language Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Loader Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Controller Class Initialized
ERROR - 2011-08-31 19:19:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 19:19:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:19:19 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:19:19 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Config Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:19:19 --> URI Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Router Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Output Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Input Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:19:19 --> Language Class Initialized
ERROR - 2011-08-31 19:19:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 19:19:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:19:19 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:19:19 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:19:19 --> Final output sent to browser
DEBUG - 2011-08-31 19:19:19 --> Total execution time: 0.0778
DEBUG - 2011-08-31 19:19:19 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Loader Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Controller Class Initialized
ERROR - 2011-08-31 19:19:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 19:19:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:19:19 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Model Class Initialized
DEBUG - 2011-08-31 19:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:19:19 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:19:19 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:19:19 --> Final output sent to browser
DEBUG - 2011-08-31 19:19:19 --> Total execution time: 0.0746
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:19:19 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:19:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:19:19 --> Final output sent to browser
DEBUG - 2011-08-31 19:19:19 --> Total execution time: 0.0674
DEBUG - 2011-08-31 19:25:49 --> Config Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:25:49 --> URI Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Router Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Output Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Input Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:25:49 --> Language Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Loader Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Controller Class Initialized
ERROR - 2011-08-31 19:25:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 19:25:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 19:25:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:25:49 --> Model Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Model Class Initialized
DEBUG - 2011-08-31 19:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:25:49 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:25:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 19:25:49 --> Helper loaded: url_helper
DEBUG - 2011-08-31 19:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 19:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 19:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 19:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 19:25:49 --> Final output sent to browser
DEBUG - 2011-08-31 19:25:49 --> Total execution time: 0.0392
DEBUG - 2011-08-31 19:25:50 --> Config Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:25:50 --> URI Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Router Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Output Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Input Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 19:25:50 --> Language Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Loader Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Controller Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Model Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Model Class Initialized
DEBUG - 2011-08-31 19:25:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 19:25:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 19:25:51 --> Final output sent to browser
DEBUG - 2011-08-31 19:25:51 --> Total execution time: 0.6112
DEBUG - 2011-08-31 19:25:52 --> Config Class Initialized
DEBUG - 2011-08-31 19:25:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 19:25:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 19:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 19:25:52 --> URI Class Initialized
DEBUG - 2011-08-31 19:25:52 --> Router Class Initialized
ERROR - 2011-08-31 19:25:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:04:31 --> Config Class Initialized
DEBUG - 2011-08-31 20:04:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:04:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:04:31 --> URI Class Initialized
DEBUG - 2011-08-31 20:04:31 --> Router Class Initialized
ERROR - 2011-08-31 20:04:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-31 20:05:00 --> Config Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:05:00 --> URI Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Router Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Output Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Input Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:05:00 --> Language Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Loader Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Controller Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Model Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Model Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Model Class Initialized
DEBUG - 2011-08-31 20:05:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:05:00 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:05:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:05:03 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:05:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:05:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:05:03 --> Final output sent to browser
DEBUG - 2011-08-31 20:05:03 --> Total execution time: 2.4273
DEBUG - 2011-08-31 20:14:11 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:11 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Router Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Output Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Input Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:14:11 --> Language Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Loader Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Controller Class Initialized
ERROR - 2011-08-31 20:14:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-31 20:14:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-31 20:14:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 20:14:11 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:14:11 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:14:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-31 20:14:11 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:14:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:14:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:14:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:14:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:14:11 --> Final output sent to browser
DEBUG - 2011-08-31 20:14:11 --> Total execution time: 0.0443
DEBUG - 2011-08-31 20:14:13 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:13 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Router Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Output Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Input Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:14:13 --> Language Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Loader Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Controller Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:14:13 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:14:13 --> Final output sent to browser
DEBUG - 2011-08-31 20:14:13 --> Total execution time: 0.5961
DEBUG - 2011-08-31 20:14:14 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:14 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:14 --> Router Class Initialized
ERROR - 2011-08-31 20:14:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:14:15 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:15 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:15 --> Router Class Initialized
ERROR - 2011-08-31 20:14:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:14:31 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:31 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Router Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Output Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Input Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:14:31 --> Language Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Loader Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Controller Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:14:31 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:14:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:14:32 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:14:32 --> Final output sent to browser
DEBUG - 2011-08-31 20:14:32 --> Total execution time: 0.1329
DEBUG - 2011-08-31 20:14:34 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:34 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:34 --> Router Class Initialized
ERROR - 2011-08-31 20:14:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:14:53 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:53 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Router Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Output Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Input Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:14:53 --> Language Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Loader Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Controller Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Model Class Initialized
DEBUG - 2011-08-31 20:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:14:53 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:14:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:14:53 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:14:53 --> Final output sent to browser
DEBUG - 2011-08-31 20:14:53 --> Total execution time: 0.2951
DEBUG - 2011-08-31 20:14:55 --> Config Class Initialized
DEBUG - 2011-08-31 20:14:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:14:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:14:55 --> URI Class Initialized
DEBUG - 2011-08-31 20:14:55 --> Router Class Initialized
ERROR - 2011-08-31 20:14:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:15:22 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:22 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Router Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Output Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Input Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:15:22 --> Language Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Loader Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Controller Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:15:22 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:15:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:15:22 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:15:22 --> Final output sent to browser
DEBUG - 2011-08-31 20:15:22 --> Total execution time: 0.2400
DEBUG - 2011-08-31 20:15:24 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:24 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:24 --> Router Class Initialized
ERROR - 2011-08-31 20:15:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:15:24 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:24 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:24 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:24 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:24 --> Router Class Initialized
ERROR - 2011-08-31 20:15:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:15:32 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:32 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Router Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Output Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Input Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:15:32 --> Language Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Loader Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Controller Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:15:32 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:15:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:15:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:15:33 --> Final output sent to browser
DEBUG - 2011-08-31 20:15:33 --> Total execution time: 0.2065
DEBUG - 2011-08-31 20:15:34 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:34 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:34 --> Router Class Initialized
ERROR - 2011-08-31 20:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:15:47 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:47 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Router Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Output Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Input Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:15:47 --> Language Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Loader Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Controller Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:15:47 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:15:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:15:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:15:47 --> Final output sent to browser
DEBUG - 2011-08-31 20:15:47 --> Total execution time: 0.2138
DEBUG - 2011-08-31 20:15:48 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:48 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:48 --> Router Class Initialized
ERROR - 2011-08-31 20:15:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:15:57 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:57 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:57 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:57 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:57 --> Router Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Output Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Input Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:15:58 --> Language Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Loader Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Controller Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Model Class Initialized
DEBUG - 2011-08-31 20:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:15:58 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:15:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:15:58 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:15:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:15:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:15:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:15:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:15:58 --> Final output sent to browser
DEBUG - 2011-08-31 20:15:58 --> Total execution time: 0.3175
DEBUG - 2011-08-31 20:15:59 --> Config Class Initialized
DEBUG - 2011-08-31 20:15:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:15:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:15:59 --> URI Class Initialized
DEBUG - 2011-08-31 20:15:59 --> Router Class Initialized
ERROR - 2011-08-31 20:15:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:16:11 --> Config Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:16:11 --> URI Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Router Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Output Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Input Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:16:11 --> Language Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Loader Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Controller Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Model Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Model Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Model Class Initialized
DEBUG - 2011-08-31 20:16:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:16:11 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:16:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:16:11 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:16:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:16:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:16:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:16:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:16:11 --> Final output sent to browser
DEBUG - 2011-08-31 20:16:11 --> Total execution time: 0.2540
DEBUG - 2011-08-31 20:16:12 --> Config Class Initialized
DEBUG - 2011-08-31 20:16:12 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:16:12 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:16:12 --> URI Class Initialized
DEBUG - 2011-08-31 20:16:12 --> Router Class Initialized
ERROR - 2011-08-31 20:16:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:16:28 --> Config Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:16:28 --> URI Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Router Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Output Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Input Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:16:28 --> Language Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Loader Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Controller Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Model Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Model Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Model Class Initialized
DEBUG - 2011-08-31 20:16:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:16:28 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:16:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:16:28 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:16:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:16:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:16:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:16:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:16:28 --> Final output sent to browser
DEBUG - 2011-08-31 20:16:28 --> Total execution time: 0.2290
DEBUG - 2011-08-31 20:16:29 --> Config Class Initialized
DEBUG - 2011-08-31 20:16:29 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:16:29 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:16:29 --> URI Class Initialized
DEBUG - 2011-08-31 20:16:29 --> Router Class Initialized
ERROR - 2011-08-31 20:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:16:30 --> Config Class Initialized
DEBUG - 2011-08-31 20:16:30 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:16:30 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:16:30 --> URI Class Initialized
DEBUG - 2011-08-31 20:16:30 --> Router Class Initialized
ERROR - 2011-08-31 20:16:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:17:00 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:00 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Router Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Output Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Input Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:17:00 --> Language Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Loader Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Controller Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:17:00 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:17:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:17:02 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:17:02 --> Final output sent to browser
DEBUG - 2011-08-31 20:17:02 --> Total execution time: 1.9541
DEBUG - 2011-08-31 20:17:03 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:03 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:03 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:03 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:03 --> Router Class Initialized
ERROR - 2011-08-31 20:17:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:17:16 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:16 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Router Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Output Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Input Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:17:16 --> Language Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Loader Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Controller Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:17:16 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:17:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:17:17 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:17:17 --> Final output sent to browser
DEBUG - 2011-08-31 20:17:17 --> Total execution time: 0.5676
DEBUG - 2011-08-31 20:17:18 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:18 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:18 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:18 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:18 --> Router Class Initialized
ERROR - 2011-08-31 20:17:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:17:34 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:34 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Router Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Output Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Input Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:17:34 --> Language Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Loader Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Controller Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:17:34 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:17:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:17:34 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:17:34 --> Final output sent to browser
DEBUG - 2011-08-31 20:17:34 --> Total execution time: 0.2963
DEBUG - 2011-08-31 20:17:35 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:35 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:35 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:35 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:35 --> Router Class Initialized
ERROR - 2011-08-31 20:17:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:17:46 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:46 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Router Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Output Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Input Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:17:46 --> Language Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Loader Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Controller Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:17:46 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:17:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:17:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:17:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:17:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:17:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:17:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:17:47 --> Final output sent to browser
DEBUG - 2011-08-31 20:17:47 --> Total execution time: 0.7532
DEBUG - 2011-08-31 20:17:48 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:48 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:48 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:48 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:48 --> Router Class Initialized
ERROR - 2011-08-31 20:17:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:17:58 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:58 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Router Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Output Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Input Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:17:58 --> Language Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Loader Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Controller Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Model Class Initialized
DEBUG - 2011-08-31 20:17:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:17:58 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:17:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:17:58 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:17:58 --> Final output sent to browser
DEBUG - 2011-08-31 20:17:58 --> Total execution time: 0.3061
DEBUG - 2011-08-31 20:17:59 --> Config Class Initialized
DEBUG - 2011-08-31 20:17:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:17:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:17:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:17:59 --> URI Class Initialized
DEBUG - 2011-08-31 20:17:59 --> Router Class Initialized
ERROR - 2011-08-31 20:17:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:18:14 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:14 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Router Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Output Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Input Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:18:14 --> Language Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Loader Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Controller Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:18:14 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:18:14 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:18:14 --> Final output sent to browser
DEBUG - 2011-08-31 20:18:14 --> Total execution time: 0.3936
DEBUG - 2011-08-31 20:18:15 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:15 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:15 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:15 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:15 --> Router Class Initialized
ERROR - 2011-08-31 20:18:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:18:31 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:31 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Router Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Output Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Input Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:18:31 --> Language Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Loader Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Controller Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:18:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:18:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:18:33 --> Final output sent to browser
DEBUG - 2011-08-31 20:18:33 --> Total execution time: 1.3774
DEBUG - 2011-08-31 20:18:34 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:34 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:34 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:34 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:34 --> Router Class Initialized
ERROR - 2011-08-31 20:18:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:18:35 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:35 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:35 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:35 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:35 --> Router Class Initialized
ERROR - 2011-08-31 20:18:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:18:40 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:40 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Router Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Output Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Input Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:18:40 --> Language Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Loader Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Controller Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:18:40 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:18:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:18:41 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:18:41 --> Final output sent to browser
DEBUG - 2011-08-31 20:18:41 --> Total execution time: 1.0074
DEBUG - 2011-08-31 20:18:42 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:42 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:42 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:42 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:42 --> Router Class Initialized
ERROR - 2011-08-31 20:18:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:18:50 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:50 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Router Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Output Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Input Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:18:50 --> Language Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Loader Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Controller Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Model Class Initialized
DEBUG - 2011-08-31 20:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:18:50 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:18:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:18:51 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:18:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:18:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:18:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:18:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:18:51 --> Final output sent to browser
DEBUG - 2011-08-31 20:18:51 --> Total execution time: 0.4659
DEBUG - 2011-08-31 20:18:52 --> Config Class Initialized
DEBUG - 2011-08-31 20:18:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:18:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:18:52 --> URI Class Initialized
DEBUG - 2011-08-31 20:18:52 --> Router Class Initialized
ERROR - 2011-08-31 20:18:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:19:06 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:06 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:06 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:06 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:06 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:06 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:06 --> Total execution time: 0.4625
DEBUG - 2011-08-31 20:19:07 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:07 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:07 --> Router Class Initialized
ERROR - 2011-08-31 20:19:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:19:30 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:30 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:30 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:30 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:31 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:31 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:31 --> Total execution time: 0.3549
DEBUG - 2011-08-31 20:19:32 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:32 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:32 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:32 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:32 --> Router Class Initialized
ERROR - 2011-08-31 20:19:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:19:33 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:33 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:33 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:33 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:33 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:33 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:33 --> Total execution time: 0.0697
DEBUG - 2011-08-31 20:19:36 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:36 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:36 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:36 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:36 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:36 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:36 --> Total execution time: 0.2009
DEBUG - 2011-08-31 20:19:37 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:37 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:37 --> Router Class Initialized
ERROR - 2011-08-31 20:19:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:19:38 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:38 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:38 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:38 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:38 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:38 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:38 --> Total execution time: 0.0459
DEBUG - 2011-08-31 20:19:43 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:43 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:43 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:43 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:43 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:43 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:43 --> Total execution time: 0.2263
DEBUG - 2011-08-31 20:19:44 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:44 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:44 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:44 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:44 --> Router Class Initialized
ERROR - 2011-08-31 20:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:19:47 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:47 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:47 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:47 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:47 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:47 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:47 --> Total execution time: 0.0418
DEBUG - 2011-08-31 20:19:52 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:52 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:52 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:52 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:52 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:52 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:52 --> Total execution time: 0.0475
DEBUG - 2011-08-31 20:19:53 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:53 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:53 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:53 --> Router Class Initialized
ERROR - 2011-08-31 20:19:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:19:59 --> Config Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:19:59 --> URI Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Router Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Output Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Input Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:19:59 --> Language Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Loader Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Controller Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Model Class Initialized
DEBUG - 2011-08-31 20:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:19:59 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:19:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:19:59 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:19:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:19:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:19:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:19:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:19:59 --> Final output sent to browser
DEBUG - 2011-08-31 20:19:59 --> Total execution time: 0.0630
DEBUG - 2011-08-31 20:20:01 --> Config Class Initialized
DEBUG - 2011-08-31 20:20:01 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:20:01 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:20:01 --> URI Class Initialized
DEBUG - 2011-08-31 20:20:01 --> Router Class Initialized
ERROR - 2011-08-31 20:20:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 20:34:12 --> Config Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-31 20:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 20:34:12 --> URI Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Router Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Output Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Input Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 20:34:12 --> Language Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Loader Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Controller Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Model Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Model Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Model Class Initialized
DEBUG - 2011-08-31 20:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 20:34:12 --> Database Driver Class Initialized
DEBUG - 2011-08-31 20:34:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 20:34:13 --> Helper loaded: url_helper
DEBUG - 2011-08-31 20:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 20:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 20:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 20:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 20:34:13 --> Final output sent to browser
DEBUG - 2011-08-31 20:34:13 --> Total execution time: 0.4260
DEBUG - 2011-08-31 21:46:25 --> Config Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Hooks Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Utf8 Class Initialized
DEBUG - 2011-08-31 21:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 21:46:25 --> URI Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Router Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Output Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Input Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 21:46:25 --> Language Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Loader Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Controller Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Model Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Model Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Model Class Initialized
DEBUG - 2011-08-31 21:46:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 21:46:25 --> Database Driver Class Initialized
DEBUG - 2011-08-31 21:46:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 21:46:25 --> Helper loaded: url_helper
DEBUG - 2011-08-31 21:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 21:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 21:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 21:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 21:46:25 --> Final output sent to browser
DEBUG - 2011-08-31 21:46:25 --> Total execution time: 0.2305
DEBUG - 2011-08-31 22:09:37 --> Config Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:09:37 --> URI Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Router Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Output Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Input Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:09:37 --> Language Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Loader Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Controller Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Model Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Model Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Model Class Initialized
DEBUG - 2011-08-31 22:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:09:37 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:09:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:09:38 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:09:38 --> Final output sent to browser
DEBUG - 2011-08-31 22:09:38 --> Total execution time: 0.9792
DEBUG - 2011-08-31 22:09:40 --> Config Class Initialized
DEBUG - 2011-08-31 22:09:40 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:09:40 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:09:40 --> URI Class Initialized
DEBUG - 2011-08-31 22:09:40 --> Router Class Initialized
ERROR - 2011-08-31 22:09:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:09:41 --> Config Class Initialized
DEBUG - 2011-08-31 22:09:41 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:09:41 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:09:41 --> URI Class Initialized
DEBUG - 2011-08-31 22:09:41 --> Router Class Initialized
ERROR - 2011-08-31 22:09:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:09:53 --> Config Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:09:53 --> URI Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Router Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Output Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Input Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:09:53 --> Language Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Loader Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Controller Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Model Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Model Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Model Class Initialized
DEBUG - 2011-08-31 22:09:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:09:53 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:09:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:09:53 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:09:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:09:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:09:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:09:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:09:53 --> Final output sent to browser
DEBUG - 2011-08-31 22:09:53 --> Total execution time: 0.3441
DEBUG - 2011-08-31 22:09:54 --> Config Class Initialized
DEBUG - 2011-08-31 22:09:54 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:09:54 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:09:54 --> URI Class Initialized
DEBUG - 2011-08-31 22:09:54 --> Router Class Initialized
ERROR - 2011-08-31 22:09:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:09:55 --> Config Class Initialized
DEBUG - 2011-08-31 22:09:55 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:09:55 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:09:55 --> URI Class Initialized
DEBUG - 2011-08-31 22:09:55 --> Router Class Initialized
ERROR - 2011-08-31 22:09:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:10:10 --> Config Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:10:10 --> URI Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Router Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Output Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Input Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:10:10 --> Language Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Loader Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Controller Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:10 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:10:11 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:10:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:10:11 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:10:11 --> Final output sent to browser
DEBUG - 2011-08-31 22:10:11 --> Total execution time: 0.0757
DEBUG - 2011-08-31 22:10:12 --> Config Class Initialized
DEBUG - 2011-08-31 22:10:12 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:10:12 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:10:12 --> URI Class Initialized
DEBUG - 2011-08-31 22:10:12 --> Router Class Initialized
ERROR - 2011-08-31 22:10:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:10:12 --> Config Class Initialized
DEBUG - 2011-08-31 22:10:12 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:10:12 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:10:12 --> URI Class Initialized
DEBUG - 2011-08-31 22:10:12 --> Router Class Initialized
ERROR - 2011-08-31 22:10:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:10:36 --> Config Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:10:36 --> URI Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Router Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Output Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Input Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:10:36 --> Language Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Loader Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Controller Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:10:36 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:10:36 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:10:36 --> Final output sent to browser
DEBUG - 2011-08-31 22:10:36 --> Total execution time: 0.2478
DEBUG - 2011-08-31 22:10:37 --> Config Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:10:37 --> URI Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Router Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Output Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Input Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:10:37 --> Language Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Loader Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Controller Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Model Class Initialized
DEBUG - 2011-08-31 22:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:10:37 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:10:37 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:10:37 --> Final output sent to browser
DEBUG - 2011-08-31 22:10:37 --> Total execution time: 0.0557
DEBUG - 2011-08-31 22:10:38 --> Config Class Initialized
DEBUG - 2011-08-31 22:10:38 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:10:38 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:10:38 --> URI Class Initialized
DEBUG - 2011-08-31 22:10:38 --> Router Class Initialized
ERROR - 2011-08-31 22:10:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:11:06 --> Config Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:11:06 --> URI Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Router Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Output Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Input Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:11:06 --> Language Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Loader Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Controller Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Model Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Model Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Model Class Initialized
DEBUG - 2011-08-31 22:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:11:06 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:11:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:11:06 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:11:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:11:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:11:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:11:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:11:06 --> Final output sent to browser
DEBUG - 2011-08-31 22:11:06 --> Total execution time: 0.2226
DEBUG - 2011-08-31 22:11:07 --> Config Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:11:07 --> URI Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Router Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Output Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Input Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:11:07 --> Language Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Loader Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Controller Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Model Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Model Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Model Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-31 22:11:07 --> Database Driver Class Initialized
DEBUG - 2011-08-31 22:11:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-31 22:11:07 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:11:07 --> Final output sent to browser
DEBUG - 2011-08-31 22:11:07 --> Total execution time: 0.0453
DEBUG - 2011-08-31 22:11:07 --> Config Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:11:07 --> URI Class Initialized
DEBUG - 2011-08-31 22:11:07 --> Router Class Initialized
ERROR - 2011-08-31 22:11:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-31 22:38:11 --> Config Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-31 22:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-31 22:38:11 --> URI Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Router Class Initialized
DEBUG - 2011-08-31 22:38:11 --> No URI present. Default controller set.
DEBUG - 2011-08-31 22:38:11 --> Output Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Input Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-31 22:38:11 --> Language Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Loader Class Initialized
DEBUG - 2011-08-31 22:38:11 --> Controller Class Initialized
DEBUG - 2011-08-31 22:38:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-31 22:38:11 --> Helper loaded: url_helper
DEBUG - 2011-08-31 22:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-31 22:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-31 22:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-31 22:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-31 22:38:11 --> Final output sent to browser
DEBUG - 2011-08-31 22:38:11 --> Total execution time: 0.0486

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-14 00:25:19 --> Config Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-14 00:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 00:25:19 --> URI Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Router Class Initialized
ERROR - 2011-09-14 00:25:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 00:25:19 --> Config Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-14 00:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 00:25:19 --> URI Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Router Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Output Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Input Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 00:25:19 --> Language Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Loader Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Controller Class Initialized
ERROR - 2011-09-14 00:25:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 00:25:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 00:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 00:25:19 --> Model Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Model Class Initialized
DEBUG - 2011-09-14 00:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 00:25:19 --> Database Driver Class Initialized
DEBUG - 2011-09-14 00:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 00:25:19 --> Helper loaded: url_helper
DEBUG - 2011-09-14 00:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 00:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 00:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 00:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 00:25:19 --> Final output sent to browser
DEBUG - 2011-09-14 00:25:19 --> Total execution time: 0.1213
DEBUG - 2011-09-14 01:22:55 --> Config Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 01:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 01:22:55 --> URI Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Router Class Initialized
DEBUG - 2011-09-14 01:22:55 --> No URI present. Default controller set.
DEBUG - 2011-09-14 01:22:55 --> Output Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Input Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 01:22:55 --> Language Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Loader Class Initialized
DEBUG - 2011-09-14 01:22:55 --> Controller Class Initialized
DEBUG - 2011-09-14 01:22:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 01:22:55 --> Helper loaded: url_helper
DEBUG - 2011-09-14 01:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 01:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 01:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 01:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 01:22:55 --> Final output sent to browser
DEBUG - 2011-09-14 01:22:55 --> Total execution time: 0.1347
DEBUG - 2011-09-14 01:34:56 --> Config Class Initialized
DEBUG - 2011-09-14 01:34:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 01:34:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 01:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 01:34:56 --> URI Class Initialized
DEBUG - 2011-09-14 01:34:56 --> Router Class Initialized
ERROR - 2011-09-14 01:34:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 02:03:47 --> Config Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:03:47 --> URI Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Router Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Output Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Input Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:03:47 --> Language Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Loader Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Controller Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Model Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Model Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Model Class Initialized
DEBUG - 2011-09-14 02:03:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:03:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:03:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:03:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:03:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:03:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:03:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:03:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:03:47 --> Final output sent to browser
DEBUG - 2011-09-14 02:03:47 --> Total execution time: 0.5560
DEBUG - 2011-09-14 02:03:48 --> Config Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:03:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:03:48 --> URI Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Router Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Output Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Input Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:03:48 --> Language Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Loader Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Controller Class Initialized
ERROR - 2011-09-14 02:03:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:03:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:03:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:03:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:03:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:03:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:03:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:03:48 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:03:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:03:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:03:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:03:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:03:48 --> Final output sent to browser
DEBUG - 2011-09-14 02:03:48 --> Total execution time: 0.0399
DEBUG - 2011-09-14 02:28:14 --> Config Class Initialized
DEBUG - 2011-09-14 02:28:14 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:28:14 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:28:14 --> URI Class Initialized
DEBUG - 2011-09-14 02:28:14 --> Router Class Initialized
ERROR - 2011-09-14 02:28:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 02:40:33 --> Config Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:40:33 --> URI Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Router Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Output Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Input Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:40:33 --> Language Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Loader Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Controller Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:40:33 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Config Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:40:33 --> URI Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Router Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Output Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Input Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:40:33 --> Language Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Loader Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Controller Class Initialized
ERROR - 2011-09-14 02:40:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:40:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:40:33 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:40:33 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:40:33 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:40:33 --> Final output sent to browser
DEBUG - 2011-09-14 02:40:33 --> Total execution time: 0.3875
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:40:33 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:40:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:40:33 --> Final output sent to browser
DEBUG - 2011-09-14 02:40:33 --> Total execution time: 0.8035
DEBUG - 2011-09-14 02:40:36 --> Config Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:40:36 --> URI Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Router Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Output Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Input Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:40:36 --> Language Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Loader Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Controller Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Model Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:40:36 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:40:36 --> Final output sent to browser
DEBUG - 2011-09-14 02:40:36 --> Total execution time: 0.7072
DEBUG - 2011-09-14 02:40:47 --> Config Class Initialized
DEBUG - 2011-09-14 02:40:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:40:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:40:47 --> URI Class Initialized
DEBUG - 2011-09-14 02:40:47 --> Router Class Initialized
ERROR - 2011-09-14 02:40:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:40:48 --> Config Class Initialized
DEBUG - 2011-09-14 02:40:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:40:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:40:48 --> URI Class Initialized
DEBUG - 2011-09-14 02:40:48 --> Router Class Initialized
ERROR - 2011-09-14 02:40:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:42:03 --> Config Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:42:03 --> URI Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Router Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Output Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Input Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:42:03 --> Language Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Loader Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Controller Class Initialized
ERROR - 2011-09-14 02:42:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:42:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:42:03 --> Model Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Model Class Initialized
DEBUG - 2011-09-14 02:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:42:03 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:42:03 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:42:03 --> Final output sent to browser
DEBUG - 2011-09-14 02:42:03 --> Total execution time: 0.0296
DEBUG - 2011-09-14 02:42:04 --> Config Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:42:04 --> URI Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Router Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Output Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Input Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:42:04 --> Language Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Loader Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Controller Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Model Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Model Class Initialized
DEBUG - 2011-09-14 02:42:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:42:04 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:42:05 --> Final output sent to browser
DEBUG - 2011-09-14 02:42:05 --> Total execution time: 0.7604
DEBUG - 2011-09-14 02:42:54 --> Config Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:42:54 --> URI Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Router Class Initialized
DEBUG - 2011-09-14 02:42:54 --> No URI present. Default controller set.
DEBUG - 2011-09-14 02:42:54 --> Output Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Input Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:42:54 --> Language Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Loader Class Initialized
DEBUG - 2011-09-14 02:42:54 --> Controller Class Initialized
DEBUG - 2011-09-14 02:42:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 02:42:54 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:42:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:42:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:42:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:42:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:42:54 --> Final output sent to browser
DEBUG - 2011-09-14 02:42:54 --> Total execution time: 0.0267
DEBUG - 2011-09-14 02:45:06 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:06 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Router Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Output Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Input Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:45:06 --> Language Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Loader Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Controller Class Initialized
ERROR - 2011-09-14 02:45:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:45:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:45:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:45:06 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:45:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:45:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:45:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:45:06 --> Final output sent to browser
DEBUG - 2011-09-14 02:45:06 --> Total execution time: 0.0285
DEBUG - 2011-09-14 02:45:09 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:09 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Router Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Output Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Input Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:45:09 --> Language Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Loader Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Controller Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:45:09 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:45:10 --> Final output sent to browser
DEBUG - 2011-09-14 02:45:10 --> Total execution time: 0.7945
DEBUG - 2011-09-14 02:45:13 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:13 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:13 --> Router Class Initialized
ERROR - 2011-09-14 02:45:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:45:38 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:38 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Router Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Output Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Input Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:45:38 --> Language Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Loader Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Controller Class Initialized
ERROR - 2011-09-14 02:45:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:45:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:45:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:45:38 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:45:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:45:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:45:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:45:38 --> Final output sent to browser
DEBUG - 2011-09-14 02:45:38 --> Total execution time: 0.0304
DEBUG - 2011-09-14 02:45:39 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:39 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Router Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Output Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Input Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:45:39 --> Language Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Loader Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Controller Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:45:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:45:40 --> Final output sent to browser
DEBUG - 2011-09-14 02:45:40 --> Total execution time: 0.5229
DEBUG - 2011-09-14 02:45:41 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:41 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Router Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Output Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Input Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:45:41 --> Language Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Loader Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Controller Class Initialized
ERROR - 2011-09-14 02:45:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:45:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:45:41 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Model Class Initialized
DEBUG - 2011-09-14 02:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:45:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:45:41 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:45:41 --> Final output sent to browser
DEBUG - 2011-09-14 02:45:41 --> Total execution time: 0.0278
DEBUG - 2011-09-14 02:45:42 --> Config Class Initialized
DEBUG - 2011-09-14 02:45:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:45:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:45:42 --> URI Class Initialized
DEBUG - 2011-09-14 02:45:42 --> Router Class Initialized
ERROR - 2011-09-14 02:45:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:46:47 --> Config Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:46:47 --> URI Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Router Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Output Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Input Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:46:47 --> Language Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Loader Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Controller Class Initialized
ERROR - 2011-09-14 02:46:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:46:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:46:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:46:47 --> Model Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Model Class Initialized
DEBUG - 2011-09-14 02:46:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:46:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:46:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:46:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:46:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:46:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:46:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:46:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:46:47 --> Final output sent to browser
DEBUG - 2011-09-14 02:46:47 --> Total execution time: 0.0278
DEBUG - 2011-09-14 02:46:48 --> Config Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:46:48 --> URI Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Router Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Output Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Input Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:46:48 --> Language Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Loader Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Controller Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:46:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:46:49 --> Final output sent to browser
DEBUG - 2011-09-14 02:46:49 --> Total execution time: 0.4400
DEBUG - 2011-09-14 02:46:51 --> Config Class Initialized
DEBUG - 2011-09-14 02:46:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:46:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:46:51 --> URI Class Initialized
DEBUG - 2011-09-14 02:46:51 --> Router Class Initialized
ERROR - 2011-09-14 02:46:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:47:41 --> Config Class Initialized
DEBUG - 2011-09-14 02:47:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:47:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:47:41 --> URI Class Initialized
DEBUG - 2011-09-14 02:47:41 --> Router Class Initialized
ERROR - 2011-09-14 02:47:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 02:50:20 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:20 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:20 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:20 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:20 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:20 --> Total execution time: 0.2397
DEBUG - 2011-09-14 02:50:22 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:22 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:22 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:22 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:22 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:22 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:22 --> Total execution time: 0.0862
DEBUG - 2011-09-14 02:50:23 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:23 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:23 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:23 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:23 --> Router Class Initialized
ERROR - 2011-09-14 02:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:50:23 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:23 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:23 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:23 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:23 --> Router Class Initialized
ERROR - 2011-09-14 02:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 02:50:38 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:38 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:38 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:39 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:39 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:39 --> Total execution time: 0.3441
DEBUG - 2011-09-14 02:50:40 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:40 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:40 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:40 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:40 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:40 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:40 --> Total execution time: 0.0539
DEBUG - 2011-09-14 02:50:48 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:48 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:48 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:48 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:48 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:48 --> Total execution time: 0.4659
DEBUG - 2011-09-14 02:50:50 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:50 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:50 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:50 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:50 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:50 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:50 --> Total execution time: 0.0438
DEBUG - 2011-09-14 02:50:57 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:57 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:57 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:57 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:58 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:58 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:58 --> Total execution time: 0.2001
DEBUG - 2011-09-14 02:50:59 --> Config Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:50:59 --> URI Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Router Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Output Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Input Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:50:59 --> Language Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Loader Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Controller Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Model Class Initialized
DEBUG - 2011-09-14 02:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:50:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:50:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:50:59 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:50:59 --> Final output sent to browser
DEBUG - 2011-09-14 02:50:59 --> Total execution time: 0.0443
DEBUG - 2011-09-14 02:51:00 --> Config Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:51:00 --> URI Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Router Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Output Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Input Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:51:00 --> Language Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Loader Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Controller Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Model Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Model Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Model Class Initialized
DEBUG - 2011-09-14 02:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:51:00 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:51:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 02:51:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:51:00 --> Final output sent to browser
DEBUG - 2011-09-14 02:51:00 --> Total execution time: 0.1691
DEBUG - 2011-09-14 02:58:49 --> Config Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 02:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 02:58:49 --> URI Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Router Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Output Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Input Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 02:58:49 --> Language Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Loader Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Controller Class Initialized
ERROR - 2011-09-14 02:58:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 02:58:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 02:58:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 02:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 02:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 02:58:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 02:58:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 02:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 02:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 02:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 02:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 02:58:49 --> Final output sent to browser
DEBUG - 2011-09-14 02:58:49 --> Total execution time: 0.0328
DEBUG - 2011-09-14 03:04:41 --> Config Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:04:41 --> URI Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Router Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Output Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Input Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:04:41 --> Language Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Loader Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Controller Class Initialized
ERROR - 2011-09-14 03:04:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:04:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:04:41 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:04:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:04:41 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:04:41 --> Final output sent to browser
DEBUG - 2011-09-14 03:04:41 --> Total execution time: 0.1337
DEBUG - 2011-09-14 03:04:42 --> Config Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:04:42 --> URI Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Router Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Output Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Input Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:04:42 --> Language Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Loader Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Controller Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:04:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:04:43 --> Final output sent to browser
DEBUG - 2011-09-14 03:04:43 --> Total execution time: 0.6216
DEBUG - 2011-09-14 03:04:45 --> Config Class Initialized
DEBUG - 2011-09-14 03:04:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:04:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:04:45 --> URI Class Initialized
DEBUG - 2011-09-14 03:04:45 --> Router Class Initialized
ERROR - 2011-09-14 03:04:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:04:52 --> Config Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:04:52 --> URI Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Router Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Output Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Input Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:04:52 --> Language Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Loader Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Controller Class Initialized
ERROR - 2011-09-14 03:04:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:04:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:04:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:04:52 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:04:52 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:04:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:04:52 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:04:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:04:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:04:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:04:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:04:52 --> Final output sent to browser
DEBUG - 2011-09-14 03:04:52 --> Total execution time: 0.0351
DEBUG - 2011-09-14 03:04:54 --> Config Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:04:54 --> URI Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Router Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Output Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Input Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:04:54 --> Language Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Loader Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Controller Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Model Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:04:54 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:04:54 --> Final output sent to browser
DEBUG - 2011-09-14 03:04:54 --> Total execution time: 0.5611
DEBUG - 2011-09-14 03:04:56 --> Config Class Initialized
DEBUG - 2011-09-14 03:04:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:04:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:04:56 --> URI Class Initialized
DEBUG - 2011-09-14 03:04:56 --> Router Class Initialized
ERROR - 2011-09-14 03:04:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:05:12 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:12 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Router Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Output Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Input Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:05:12 --> Language Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Loader Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Controller Class Initialized
ERROR - 2011-09-14 03:05:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:05:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:05:12 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:05:12 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:05:12 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:05:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:05:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:05:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:05:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:05:12 --> Final output sent to browser
DEBUG - 2011-09-14 03:05:12 --> Total execution time: 0.0304
DEBUG - 2011-09-14 03:05:13 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:13 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Router Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Output Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Input Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:05:13 --> Language Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Loader Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Controller Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:05:13 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:05:14 --> Final output sent to browser
DEBUG - 2011-09-14 03:05:14 --> Total execution time: 0.4996
DEBUG - 2011-09-14 03:05:16 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:16 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:16 --> Router Class Initialized
ERROR - 2011-09-14 03:05:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:05:20 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:20 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Router Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Output Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Input Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:05:20 --> Language Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Loader Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Controller Class Initialized
ERROR - 2011-09-14 03:05:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:05:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:05:20 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:05:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:05:20 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:05:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:05:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:05:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:05:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:05:20 --> Final output sent to browser
DEBUG - 2011-09-14 03:05:20 --> Total execution time: 0.0311
DEBUG - 2011-09-14 03:05:20 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:20 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Router Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Output Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Input Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:05:20 --> Language Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Loader Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Controller Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:05:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:05:21 --> Final output sent to browser
DEBUG - 2011-09-14 03:05:21 --> Total execution time: 0.5788
DEBUG - 2011-09-14 03:05:25 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:25 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:25 --> Router Class Initialized
ERROR - 2011-09-14 03:05:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:05:26 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:26 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Router Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Output Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Input Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:05:26 --> Language Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Loader Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Controller Class Initialized
ERROR - 2011-09-14 03:05:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:05:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:05:26 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:05:26 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:05:26 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:05:26 --> Final output sent to browser
DEBUG - 2011-09-14 03:05:26 --> Total execution time: 0.0292
DEBUG - 2011-09-14 03:05:26 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:26 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Router Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Output Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Input Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:05:26 --> Language Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Loader Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Controller Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Model Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:05:26 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:05:26 --> Final output sent to browser
DEBUG - 2011-09-14 03:05:26 --> Total execution time: 0.4594
DEBUG - 2011-09-14 03:05:29 --> Config Class Initialized
DEBUG - 2011-09-14 03:05:29 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:05:29 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:05:29 --> URI Class Initialized
DEBUG - 2011-09-14 03:05:29 --> Router Class Initialized
ERROR - 2011-09-14 03:05:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:07:30 --> Config Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:07:30 --> URI Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Router Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Output Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Input Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:07:30 --> Language Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Loader Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Controller Class Initialized
ERROR - 2011-09-14 03:07:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:07:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:07:30 --> Model Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Model Class Initialized
DEBUG - 2011-09-14 03:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:07:30 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:07:30 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:07:30 --> Final output sent to browser
DEBUG - 2011-09-14 03:07:30 --> Total execution time: 0.0272
DEBUG - 2011-09-14 03:07:31 --> Config Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:07:31 --> URI Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Router Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Output Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Input Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:07:31 --> Language Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Loader Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Controller Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Model Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Model Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:07:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:07:31 --> Final output sent to browser
DEBUG - 2011-09-14 03:07:31 --> Total execution time: 0.5031
DEBUG - 2011-09-14 03:07:33 --> Config Class Initialized
DEBUG - 2011-09-14 03:07:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:07:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:07:33 --> URI Class Initialized
DEBUG - 2011-09-14 03:07:33 --> Router Class Initialized
ERROR - 2011-09-14 03:07:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:07:33 --> Config Class Initialized
DEBUG - 2011-09-14 03:07:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:07:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:07:33 --> URI Class Initialized
DEBUG - 2011-09-14 03:07:33 --> Router Class Initialized
ERROR - 2011-09-14 03:07:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 03:27:31 --> Config Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:27:31 --> URI Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Router Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Output Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Input Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:27:31 --> Language Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Loader Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Controller Class Initialized
ERROR - 2011-09-14 03:27:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 03:27:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 03:27:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:27:31 --> Model Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Model Class Initialized
DEBUG - 2011-09-14 03:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:27:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:27:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 03:27:31 --> Helper loaded: url_helper
DEBUG - 2011-09-14 03:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 03:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 03:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 03:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 03:27:31 --> Final output sent to browser
DEBUG - 2011-09-14 03:27:31 --> Total execution time: 0.0653
DEBUG - 2011-09-14 03:27:32 --> Config Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:27:32 --> URI Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Router Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Output Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Input Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 03:27:32 --> Language Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Loader Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Controller Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Model Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Model Class Initialized
DEBUG - 2011-09-14 03:27:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 03:27:32 --> Database Driver Class Initialized
DEBUG - 2011-09-14 03:27:47 --> Final output sent to browser
DEBUG - 2011-09-14 03:27:47 --> Total execution time: 15.5051
DEBUG - 2011-09-14 03:37:37 --> Config Class Initialized
DEBUG - 2011-09-14 03:37:37 --> Hooks Class Initialized
DEBUG - 2011-09-14 03:37:37 --> Utf8 Class Initialized
DEBUG - 2011-09-14 03:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 03:37:37 --> URI Class Initialized
DEBUG - 2011-09-14 03:37:37 --> Router Class Initialized
ERROR - 2011-09-14 03:37:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 05:06:45 --> Config Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 05:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 05:06:45 --> URI Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Router Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Output Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Input Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 05:06:45 --> Language Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Loader Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Controller Class Initialized
ERROR - 2011-09-14 05:06:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 05:06:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 05:06:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 05:06:45 --> Model Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Model Class Initialized
DEBUG - 2011-09-14 05:06:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 05:06:45 --> Database Driver Class Initialized
DEBUG - 2011-09-14 05:06:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 05:06:45 --> Helper loaded: url_helper
DEBUG - 2011-09-14 05:06:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 05:06:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 05:06:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 05:06:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 05:06:45 --> Final output sent to browser
DEBUG - 2011-09-14 05:06:45 --> Total execution time: 0.4590
DEBUG - 2011-09-14 05:06:47 --> Config Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 05:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 05:06:47 --> URI Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Router Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Output Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Input Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 05:06:47 --> Language Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Loader Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Controller Class Initialized
ERROR - 2011-09-14 05:06:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 05:06:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 05:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 05:06:47 --> Model Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Model Class Initialized
DEBUG - 2011-09-14 05:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 05:06:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 05:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 05:06:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 05:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 05:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 05:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 05:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 05:06:47 --> Final output sent to browser
DEBUG - 2011-09-14 05:06:47 --> Total execution time: 0.0319
DEBUG - 2011-09-14 05:56:25 --> Config Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 05:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 05:56:25 --> URI Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Router Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Output Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Input Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 05:56:25 --> Language Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Loader Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Controller Class Initialized
ERROR - 2011-09-14 05:56:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 05:56:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 05:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 05:56:25 --> Model Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Model Class Initialized
DEBUG - 2011-09-14 05:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 05:56:25 --> Database Driver Class Initialized
DEBUG - 2011-09-14 05:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 05:56:25 --> Helper loaded: url_helper
DEBUG - 2011-09-14 05:56:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 05:56:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 05:56:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 05:56:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 05:56:25 --> Final output sent to browser
DEBUG - 2011-09-14 05:56:25 --> Total execution time: 0.0777
DEBUG - 2011-09-14 05:56:26 --> Config Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 05:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 05:56:26 --> URI Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Router Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Output Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Input Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 05:56:26 --> Language Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Loader Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Controller Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Model Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Model Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Model Class Initialized
DEBUG - 2011-09-14 05:56:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 05:56:26 --> Database Driver Class Initialized
DEBUG - 2011-09-14 05:56:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 05:56:27 --> Helper loaded: url_helper
DEBUG - 2011-09-14 05:56:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 05:56:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 05:56:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 05:56:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 05:56:27 --> Final output sent to browser
DEBUG - 2011-09-14 05:56:27 --> Total execution time: 0.5945
DEBUG - 2011-09-14 06:26:42 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:43 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Router Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Output Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Input Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:26:43 --> Language Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Loader Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Controller Class Initialized
ERROR - 2011-09-14 06:26:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 06:26:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 06:26:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 06:26:43 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:26:43 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:26:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 06:26:43 --> Helper loaded: url_helper
DEBUG - 2011-09-14 06:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 06:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 06:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 06:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 06:26:43 --> Final output sent to browser
DEBUG - 2011-09-14 06:26:43 --> Total execution time: 1.1806
DEBUG - 2011-09-14 06:26:45 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:45 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Router Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Output Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Input Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:26:45 --> Language Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Loader Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Controller Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:26:45 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:26:48 --> Final output sent to browser
DEBUG - 2011-09-14 06:26:48 --> Total execution time: 3.8555
DEBUG - 2011-09-14 06:26:50 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:50 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:50 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:50 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:50 --> Router Class Initialized
ERROR - 2011-09-14 06:26:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:26:52 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:52 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Router Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Output Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Input Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:26:52 --> Language Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Loader Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Controller Class Initialized
ERROR - 2011-09-14 06:26:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 06:26:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 06:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 06:26:52 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:26:52 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 06:26:52 --> Helper loaded: url_helper
DEBUG - 2011-09-14 06:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 06:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 06:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 06:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 06:26:52 --> Final output sent to browser
DEBUG - 2011-09-14 06:26:52 --> Total execution time: 0.0867
DEBUG - 2011-09-14 06:26:53 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:53 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Router Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Output Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Input Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:26:53 --> Language Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Loader Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Controller Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Model Class Initialized
DEBUG - 2011-09-14 06:26:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:26:53 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:26:54 --> Final output sent to browser
DEBUG - 2011-09-14 06:26:54 --> Total execution time: 0.8793
DEBUG - 2011-09-14 06:26:55 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:55 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:55 --> Router Class Initialized
ERROR - 2011-09-14 06:26:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:26:56 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:56 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:56 --> Router Class Initialized
ERROR - 2011-09-14 06:26:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:26:56 --> Config Class Initialized
DEBUG - 2011-09-14 06:26:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:26:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:26:56 --> URI Class Initialized
DEBUG - 2011-09-14 06:26:56 --> Router Class Initialized
ERROR - 2011-09-14 06:26:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:58:48 --> Config Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:58:48 --> URI Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Router Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Output Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Input Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:58:48 --> Language Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Config Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Loader Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Controller Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:58:48 --> URI Class Initialized
DEBUG - 2011-09-14 06:58:48 --> Router Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Output Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Input Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:58:49 --> Language Class Initialized
ERROR - 2011-09-14 06:58:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 06:58:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 06:58:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 06:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:58:49 --> Loader Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Controller Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:58:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 06:58:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 06:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 06:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 06:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 06:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 06:58:49 --> Final output sent to browser
DEBUG - 2011-09-14 06:58:49 --> Total execution time: 0.8675
DEBUG - 2011-09-14 06:58:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 06:58:51 --> Helper loaded: url_helper
DEBUG - 2011-09-14 06:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 06:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 06:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 06:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 06:58:51 --> Final output sent to browser
DEBUG - 2011-09-14 06:58:51 --> Total execution time: 2.2018
DEBUG - 2011-09-14 06:58:53 --> Config Class Initialized
DEBUG - 2011-09-14 06:58:53 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:58:53 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:58:53 --> URI Class Initialized
DEBUG - 2011-09-14 06:58:53 --> Router Class Initialized
ERROR - 2011-09-14 06:58:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:58:58 --> Config Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:58:58 --> URI Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Router Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Output Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Input Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 06:58:58 --> Language Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Loader Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Config Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:58:58 --> URI Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Router Class Initialized
ERROR - 2011-09-14 06:58:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:58:58 --> Controller Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Model Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 06:58:58 --> Database Driver Class Initialized
DEBUG - 2011-09-14 06:58:58 --> Final output sent to browser
DEBUG - 2011-09-14 06:58:58 --> Total execution time: 0.8544
DEBUG - 2011-09-14 06:59:05 --> Config Class Initialized
DEBUG - 2011-09-14 06:59:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:59:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:59:05 --> URI Class Initialized
DEBUG - 2011-09-14 06:59:05 --> Router Class Initialized
ERROR - 2011-09-14 06:59:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 06:59:06 --> Config Class Initialized
DEBUG - 2011-09-14 06:59:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 06:59:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 06:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 06:59:06 --> URI Class Initialized
DEBUG - 2011-09-14 06:59:06 --> Router Class Initialized
ERROR - 2011-09-14 06:59:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:01:05 --> Config Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:01:05 --> URI Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Router Class Initialized
DEBUG - 2011-09-14 07:01:05 --> No URI present. Default controller set.
DEBUG - 2011-09-14 07:01:05 --> Output Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Input Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:01:05 --> Language Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Loader Class Initialized
DEBUG - 2011-09-14 07:01:05 --> Controller Class Initialized
DEBUG - 2011-09-14 07:01:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 07:01:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:01:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:01:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:01:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:01:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:01:05 --> Final output sent to browser
DEBUG - 2011-09-14 07:01:05 --> Total execution time: 0.0672
DEBUG - 2011-09-14 07:13:49 --> Config Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:13:49 --> URI Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Router Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Output Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Input Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:13:49 --> Language Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Loader Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Controller Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Config Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Model Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:13:49 --> Model Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Model Class Initialized
DEBUG - 2011-09-14 07:13:49 --> URI Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:13:49 --> Router Class Initialized
ERROR - 2011-09-14 07:13:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:13:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:13:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 07:13:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:13:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:13:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:13:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:13:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:13:49 --> Final output sent to browser
DEBUG - 2011-09-14 07:13:49 --> Total execution time: 0.1043
DEBUG - 2011-09-14 07:13:49 --> Config Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:13:49 --> URI Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Router Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Output Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Input Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:13:49 --> Language Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Loader Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Controller Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Model Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Model Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Model Class Initialized
DEBUG - 2011-09-14 07:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:13:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:13:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 07:13:50 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:13:50 --> Final output sent to browser
DEBUG - 2011-09-14 07:13:50 --> Total execution time: 0.0681
DEBUG - 2011-09-14 07:17:01 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:01 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Router Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Output Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Input Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:17:01 --> Language Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Loader Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Controller Class Initialized
ERROR - 2011-09-14 07:17:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 07:17:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 07:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:17:01 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:17:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:17:02 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:17:02 --> Final output sent to browser
DEBUG - 2011-09-14 07:17:02 --> Total execution time: 0.3832
DEBUG - 2011-09-14 07:17:02 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:02 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Router Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Output Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Input Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:17:02 --> Language Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Loader Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Controller Class Initialized
ERROR - 2011-09-14 07:17:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 07:17:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:17:02 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:17:02 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:17:02 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:17:02 --> Final output sent to browser
DEBUG - 2011-09-14 07:17:02 --> Total execution time: 0.0901
DEBUG - 2011-09-14 07:17:04 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:04 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Router Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Output Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Input Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:17:04 --> Language Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Loader Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Controller Class Initialized
ERROR - 2011-09-14 07:17:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 07:17:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 07:17:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:17:04 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:17:04 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:17:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:17:05 --> Final output sent to browser
DEBUG - 2011-09-14 07:17:05 --> Total execution time: 0.1772
DEBUG - 2011-09-14 07:17:06 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:06 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Router Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Output Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Input Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:17:06 --> Language Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Loader Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Controller Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Model Class Initialized
DEBUG - 2011-09-14 07:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:17:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:17:08 --> Final output sent to browser
DEBUG - 2011-09-14 07:17:08 --> Total execution time: 1.9254
DEBUG - 2011-09-14 07:17:12 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:12 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:12 --> Router Class Initialized
ERROR - 2011-09-14 07:17:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:17:13 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:13 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:13 --> Router Class Initialized
ERROR - 2011-09-14 07:17:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:17:13 --> Config Class Initialized
DEBUG - 2011-09-14 07:17:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:17:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:17:13 --> URI Class Initialized
DEBUG - 2011-09-14 07:17:13 --> Router Class Initialized
ERROR - 2011-09-14 07:17:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:51:08 --> Config Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:51:08 --> URI Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Router Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Output Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Input Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:51:08 --> Language Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Loader Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Controller Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Model Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Model Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Model Class Initialized
DEBUG - 2011-09-14 07:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:51:08 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:51:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 07:51:11 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:51:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:51:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:51:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:51:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:51:11 --> Final output sent to browser
DEBUG - 2011-09-14 07:51:11 --> Total execution time: 3.1322
DEBUG - 2011-09-14 07:51:13 --> Config Class Initialized
DEBUG - 2011-09-14 07:51:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:51:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:51:13 --> URI Class Initialized
DEBUG - 2011-09-14 07:51:13 --> Router Class Initialized
ERROR - 2011-09-14 07:51:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:53:18 --> Config Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:53:18 --> URI Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Router Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Output Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Input Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:53:18 --> Language Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Loader Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Controller Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:53:19 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:53:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 07:53:19 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:53:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:53:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:53:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:53:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:53:19 --> Final output sent to browser
DEBUG - 2011-09-14 07:53:19 --> Total execution time: 0.3560
DEBUG - 2011-09-14 07:53:25 --> Config Class Initialized
DEBUG - 2011-09-14 07:53:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:53:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:53:25 --> URI Class Initialized
DEBUG - 2011-09-14 07:53:25 --> Router Class Initialized
ERROR - 2011-09-14 07:53:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:53:38 --> Config Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:53:38 --> URI Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Router Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Output Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Input Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:53:38 --> Language Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Loader Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Controller Class Initialized
ERROR - 2011-09-14 07:53:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 07:53:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 07:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:53:38 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:53:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:53:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:53:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:53:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:53:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:53:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:53:38 --> Final output sent to browser
DEBUG - 2011-09-14 07:53:38 --> Total execution time: 0.0737
DEBUG - 2011-09-14 07:53:40 --> Config Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:53:40 --> URI Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Router Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Output Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Input Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:53:40 --> Language Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Loader Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Controller Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Model Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:53:40 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:53:40 --> Final output sent to browser
DEBUG - 2011-09-14 07:53:40 --> Total execution time: 0.6148
DEBUG - 2011-09-14 07:53:54 --> Config Class Initialized
DEBUG - 2011-09-14 07:53:54 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:53:54 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:53:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:53:54 --> URI Class Initialized
DEBUG - 2011-09-14 07:53:54 --> Router Class Initialized
ERROR - 2011-09-14 07:53:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:54:04 --> Config Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:54:04 --> URI Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Router Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Output Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Input Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:54:04 --> Language Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Loader Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Controller Class Initialized
ERROR - 2011-09-14 07:54:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 07:54:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 07:54:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:54:04 --> Model Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Model Class Initialized
DEBUG - 2011-09-14 07:54:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:54:04 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:54:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:54:04 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:54:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:54:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:54:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:54:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:54:04 --> Final output sent to browser
DEBUG - 2011-09-14 07:54:04 --> Total execution time: 0.2146
DEBUG - 2011-09-14 07:54:06 --> Config Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:54:06 --> URI Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Router Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Output Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Input Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:54:06 --> Language Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Loader Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Controller Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Model Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Model Class Initialized
DEBUG - 2011-09-14 07:54:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:54:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:54:07 --> Final output sent to browser
DEBUG - 2011-09-14 07:54:07 --> Total execution time: 1.0565
DEBUG - 2011-09-14 07:54:30 --> Config Class Initialized
DEBUG - 2011-09-14 07:54:30 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:54:30 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:54:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:54:30 --> URI Class Initialized
DEBUG - 2011-09-14 07:54:30 --> Router Class Initialized
ERROR - 2011-09-14 07:54:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 07:55:01 --> Config Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:55:01 --> URI Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Router Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Output Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Input Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:55:01 --> Language Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Loader Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Controller Class Initialized
ERROR - 2011-09-14 07:55:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 07:55:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 07:55:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:55:01 --> Model Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Model Class Initialized
DEBUG - 2011-09-14 07:55:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:55:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:55:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 07:55:01 --> Helper loaded: url_helper
DEBUG - 2011-09-14 07:55:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 07:55:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 07:55:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 07:55:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 07:55:01 --> Final output sent to browser
DEBUG - 2011-09-14 07:55:01 --> Total execution time: 0.0710
DEBUG - 2011-09-14 07:55:02 --> Config Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:55:02 --> URI Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Router Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Output Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Input Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 07:55:02 --> Language Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Loader Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Controller Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Model Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Model Class Initialized
DEBUG - 2011-09-14 07:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 07:55:02 --> Database Driver Class Initialized
DEBUG - 2011-09-14 07:55:03 --> Final output sent to browser
DEBUG - 2011-09-14 07:55:03 --> Total execution time: 0.8026
DEBUG - 2011-09-14 07:55:05 --> Config Class Initialized
DEBUG - 2011-09-14 07:55:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 07:55:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 07:55:05 --> URI Class Initialized
DEBUG - 2011-09-14 07:55:05 --> Router Class Initialized
ERROR - 2011-09-14 07:55:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:02:04 --> Config Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:02:04 --> URI Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Router Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Output Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Input Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:02:04 --> Language Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Loader Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Controller Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:02:04 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:02:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:02:04 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:02:04 --> Final output sent to browser
DEBUG - 2011-09-14 08:02:04 --> Total execution time: 0.0992
DEBUG - 2011-09-14 08:02:06 --> Config Class Initialized
DEBUG - 2011-09-14 08:02:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:02:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:02:06 --> URI Class Initialized
DEBUG - 2011-09-14 08:02:06 --> Router Class Initialized
ERROR - 2011-09-14 08:02:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:02:15 --> Config Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:02:15 --> URI Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Router Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Output Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Input Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:02:15 --> Language Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Loader Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Controller Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:02:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:02:16 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:02:16 --> Final output sent to browser
DEBUG - 2011-09-14 08:02:16 --> Total execution time: 0.5892
DEBUG - 2011-09-14 08:02:17 --> Config Class Initialized
DEBUG - 2011-09-14 08:02:17 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:02:17 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:02:17 --> URI Class Initialized
DEBUG - 2011-09-14 08:02:17 --> Router Class Initialized
ERROR - 2011-09-14 08:02:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:02:28 --> Config Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:02:28 --> URI Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Router Class Initialized
ERROR - 2011-09-14 08:02:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 08:02:28 --> Config Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:02:28 --> URI Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Router Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Output Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Input Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:02:28 --> Language Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Loader Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Controller Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Model Class Initialized
DEBUG - 2011-09-14 08:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:02:28 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:02:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:02:28 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:02:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:02:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:02:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:02:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:02:28 --> Final output sent to browser
DEBUG - 2011-09-14 08:02:28 --> Total execution time: 0.3346
DEBUG - 2011-09-14 08:04:17 --> Config Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:04:17 --> URI Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Router Class Initialized
DEBUG - 2011-09-14 08:04:17 --> No URI present. Default controller set.
DEBUG - 2011-09-14 08:04:17 --> Output Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Input Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:04:17 --> Language Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Loader Class Initialized
DEBUG - 2011-09-14 08:04:17 --> Controller Class Initialized
DEBUG - 2011-09-14 08:04:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 08:04:17 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:04:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:04:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:04:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:04:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:04:17 --> Final output sent to browser
DEBUG - 2011-09-14 08:04:17 --> Total execution time: 0.1136
DEBUG - 2011-09-14 08:11:57 --> Config Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:11:57 --> URI Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Router Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Output Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Input Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:11:57 --> Language Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Loader Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Controller Class Initialized
ERROR - 2011-09-14 08:11:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 08:11:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 08:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:11:57 --> Model Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Model Class Initialized
DEBUG - 2011-09-14 08:11:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:11:57 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:11:57 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:11:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:11:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:11:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:11:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:11:57 --> Final output sent to browser
DEBUG - 2011-09-14 08:11:57 --> Total execution time: 0.0532
DEBUG - 2011-09-14 08:12:01 --> Config Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:12:01 --> URI Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Router Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Output Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Input Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:12:01 --> Language Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Loader Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Controller Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Model Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Model Class Initialized
DEBUG - 2011-09-14 08:12:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:12:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:12:02 --> Final output sent to browser
DEBUG - 2011-09-14 08:12:02 --> Total execution time: 0.7414
DEBUG - 2011-09-14 08:12:31 --> Config Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Config Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:12:31 --> URI Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Router Class Initialized
ERROR - 2011-09-14 08:12:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:12:31 --> URI Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Router Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Output Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Input Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:12:31 --> Language Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Loader Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Controller Class Initialized
ERROR - 2011-09-14 08:12:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 08:12:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 08:12:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:12:31 --> Model Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Model Class Initialized
DEBUG - 2011-09-14 08:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:12:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:12:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:12:31 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:12:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:12:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:12:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:12:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:12:31 --> Final output sent to browser
DEBUG - 2011-09-14 08:12:31 --> Total execution time: 0.1081
DEBUG - 2011-09-14 08:12:33 --> Config Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:12:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:12:33 --> URI Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Router Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Output Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Input Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:12:33 --> Language Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Loader Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Controller Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Model Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Model Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:12:33 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:12:33 --> Final output sent to browser
DEBUG - 2011-09-14 08:12:33 --> Total execution time: 0.8880
DEBUG - 2011-09-14 08:12:36 --> Config Class Initialized
DEBUG - 2011-09-14 08:12:37 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:12:37 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:12:37 --> URI Class Initialized
DEBUG - 2011-09-14 08:12:37 --> Router Class Initialized
ERROR - 2011-09-14 08:12:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:14:53 --> Config Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:14:53 --> URI Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Router Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Output Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Input Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:14:53 --> Language Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Loader Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Controller Class Initialized
ERROR - 2011-09-14 08:14:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 08:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 08:14:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:14:53 --> Model Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Model Class Initialized
DEBUG - 2011-09-14 08:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:14:54 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:14:54 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:14:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:14:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:14:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:14:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:14:54 --> Final output sent to browser
DEBUG - 2011-09-14 08:14:54 --> Total execution time: 0.1168
DEBUG - 2011-09-14 08:14:55 --> Config Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:14:55 --> URI Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Router Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Output Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Input Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:14:55 --> Language Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Loader Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Controller Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Model Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Model Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Model Class Initialized
DEBUG - 2011-09-14 08:14:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:14:55 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:14:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:14:55 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:14:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:14:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:14:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:14:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:14:55 --> Final output sent to browser
DEBUG - 2011-09-14 08:14:55 --> Total execution time: 0.0555
DEBUG - 2011-09-14 08:14:57 --> Config Class Initialized
DEBUG - 2011-09-14 08:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:14:57 --> URI Class Initialized
DEBUG - 2011-09-14 08:14:57 --> Router Class Initialized
ERROR - 2011-09-14 08:14:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:15:45 --> Config Class Initialized
DEBUG - 2011-09-14 08:15:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:15:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:15:45 --> URI Class Initialized
DEBUG - 2011-09-14 08:15:45 --> Router Class Initialized
ERROR - 2011-09-14 08:15:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:23:38 --> Config Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:23:38 --> URI Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Router Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Output Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Input Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:23:38 --> Language Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Loader Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Controller Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:23:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:23:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:23:38 --> Final output sent to browser
DEBUG - 2011-09-14 08:23:38 --> Total execution time: 0.0604
DEBUG - 2011-09-14 08:23:42 --> Config Class Initialized
DEBUG - 2011-09-14 08:23:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:23:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:23:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:23:42 --> URI Class Initialized
DEBUG - 2011-09-14 08:23:42 --> Router Class Initialized
ERROR - 2011-09-14 08:23:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:23:51 --> Config Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:23:51 --> URI Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Router Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Output Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Input Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:23:51 --> Language Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Loader Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Controller Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:23:51 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:23:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:23:51 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:23:51 --> Final output sent to browser
DEBUG - 2011-09-14 08:23:51 --> Total execution time: 0.0696
DEBUG - 2011-09-14 08:23:54 --> Config Class Initialized
DEBUG - 2011-09-14 08:23:54 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:23:54 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:23:54 --> URI Class Initialized
DEBUG - 2011-09-14 08:23:54 --> Router Class Initialized
ERROR - 2011-09-14 08:23:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:23:58 --> Config Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:23:58 --> URI Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Router Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Output Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Input Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:23:58 --> Language Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Loader Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Controller Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Model Class Initialized
DEBUG - 2011-09-14 08:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:23:58 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:23:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:23:58 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:23:58 --> Final output sent to browser
DEBUG - 2011-09-14 08:23:58 --> Total execution time: 0.1396
DEBUG - 2011-09-14 08:24:13 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:13 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Router Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Output Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Input Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:24:13 --> Language Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Loader Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Controller Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:24:13 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:24:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:24:15 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:24:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:24:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:24:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:24:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:24:15 --> Final output sent to browser
DEBUG - 2011-09-14 08:24:15 --> Total execution time: 1.6157
DEBUG - 2011-09-14 08:24:18 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:18 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Router Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Output Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Input Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:24:18 --> Language Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Loader Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Controller Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:24:18 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:24:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:24:18 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:24:18 --> Final output sent to browser
DEBUG - 2011-09-14 08:24:18 --> Total execution time: 0.0581
DEBUG - 2011-09-14 08:24:18 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:18 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:18 --> Router Class Initialized
ERROR - 2011-09-14 08:24:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:24:19 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:19 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:19 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:19 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:19 --> Router Class Initialized
ERROR - 2011-09-14 08:24:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:24:28 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:28 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Router Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Output Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Input Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:24:28 --> Language Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Loader Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Controller Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:24:28 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:24:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:24:28 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:24:28 --> Final output sent to browser
DEBUG - 2011-09-14 08:24:28 --> Total execution time: 0.0669
DEBUG - 2011-09-14 08:24:31 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:31 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:31 --> Router Class Initialized
ERROR - 2011-09-14 08:24:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:24:42 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:42 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Router Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Output Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Input Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:24:42 --> Language Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Loader Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Controller Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:24:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:24:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:24:43 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:24:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:24:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:24:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:24:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:24:43 --> Final output sent to browser
DEBUG - 2011-09-14 08:24:43 --> Total execution time: 0.3876
DEBUG - 2011-09-14 08:24:45 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:45 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Router Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Output Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Input Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:24:45 --> Language Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Loader Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Controller Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Model Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:24:45 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:24:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:24:45 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:24:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:24:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:24:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:24:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:24:45 --> Final output sent to browser
DEBUG - 2011-09-14 08:24:45 --> Total execution time: 0.0593
DEBUG - 2011-09-14 08:24:45 --> Config Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:24:45 --> URI Class Initialized
DEBUG - 2011-09-14 08:24:45 --> Router Class Initialized
ERROR - 2011-09-14 08:24:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:25:10 --> Config Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:25:10 --> URI Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Router Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Output Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Input Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:25:10 --> Language Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Loader Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Controller Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:25:10 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:25:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:25:11 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:25:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:25:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:25:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:25:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:25:11 --> Final output sent to browser
DEBUG - 2011-09-14 08:25:11 --> Total execution time: 0.6182
DEBUG - 2011-09-14 08:25:13 --> Config Class Initialized
DEBUG - 2011-09-14 08:25:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:25:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:25:13 --> URI Class Initialized
DEBUG - 2011-09-14 08:25:13 --> Router Class Initialized
ERROR - 2011-09-14 08:25:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:25:22 --> Config Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:25:22 --> URI Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Router Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Output Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Input Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:25:22 --> Language Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Loader Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Controller Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:25:22 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:25:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:25:24 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:25:24 --> Final output sent to browser
DEBUG - 2011-09-14 08:25:24 --> Total execution time: 1.8396
DEBUG - 2011-09-14 08:25:27 --> Config Class Initialized
DEBUG - 2011-09-14 08:25:27 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:25:27 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:25:27 --> URI Class Initialized
DEBUG - 2011-09-14 08:25:27 --> Router Class Initialized
ERROR - 2011-09-14 08:25:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:25:48 --> Config Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:25:48 --> URI Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Router Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Output Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Input Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:25:48 --> Language Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Loader Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Controller Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Model Class Initialized
DEBUG - 2011-09-14 08:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:25:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:25:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:25:48 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:25:48 --> Final output sent to browser
DEBUG - 2011-09-14 08:25:48 --> Total execution time: 0.3187
DEBUG - 2011-09-14 08:25:51 --> Config Class Initialized
DEBUG - 2011-09-14 08:25:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:25:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:25:51 --> URI Class Initialized
DEBUG - 2011-09-14 08:25:51 --> Router Class Initialized
ERROR - 2011-09-14 08:25:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:26:00 --> Config Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:26:00 --> URI Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Router Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Output Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Input Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:26:00 --> Language Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Loader Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Controller Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:26:00 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:26:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:26:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:26:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:26:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:26:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:26:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:26:00 --> Final output sent to browser
DEBUG - 2011-09-14 08:26:00 --> Total execution time: 0.4347
DEBUG - 2011-09-14 08:26:03 --> Config Class Initialized
DEBUG - 2011-09-14 08:26:03 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:26:03 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:26:03 --> URI Class Initialized
DEBUG - 2011-09-14 08:26:03 --> Router Class Initialized
ERROR - 2011-09-14 08:26:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:26:06 --> Config Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:26:06 --> URI Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Router Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Output Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Input Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:26:06 --> Language Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Loader Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Controller Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:26:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:26:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:26:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:26:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:26:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:26:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:26:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:26:06 --> Final output sent to browser
DEBUG - 2011-09-14 08:26:06 --> Total execution time: 0.0930
DEBUG - 2011-09-14 08:26:16 --> Config Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:26:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:26:16 --> URI Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Router Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Output Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Input Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:26:16 --> Language Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Loader Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Controller Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:26:16 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:26:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:26:16 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:26:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:26:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:26:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:26:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:26:16 --> Final output sent to browser
DEBUG - 2011-09-14 08:26:16 --> Total execution time: 0.0514
DEBUG - 2011-09-14 08:26:33 --> Config Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:26:33 --> URI Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Router Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Output Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Input Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:26:33 --> Language Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Loader Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Controller Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:26:33 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:26:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:26:33 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:26:33 --> Final output sent to browser
DEBUG - 2011-09-14 08:26:33 --> Total execution time: 0.0696
DEBUG - 2011-09-14 08:26:41 --> Config Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:26:41 --> URI Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Router Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Output Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Input Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:26:41 --> Language Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Loader Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Controller Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Model Class Initialized
DEBUG - 2011-09-14 08:26:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:26:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:26:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:26:41 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:26:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:26:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:26:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:26:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:26:41 --> Final output sent to browser
DEBUG - 2011-09-14 08:26:41 --> Total execution time: 0.0734
DEBUG - 2011-09-14 08:30:52 --> Config Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:30:52 --> URI Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Router Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Output Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Input Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:30:52 --> Language Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Loader Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Controller Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:30:52 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:30:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:30:52 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:30:52 --> Final output sent to browser
DEBUG - 2011-09-14 08:30:52 --> Total execution time: 0.1046
DEBUG - 2011-09-14 08:30:55 --> Config Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:30:55 --> URI Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Router Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Output Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Input Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:30:55 --> Language Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Loader Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Controller Class Initialized
ERROR - 2011-09-14 08:30:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 08:30:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 08:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:30:55 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:30:55 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:30:55 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:30:55 --> Final output sent to browser
DEBUG - 2011-09-14 08:30:55 --> Total execution time: 0.0335
DEBUG - 2011-09-14 08:30:57 --> Config Class Initialized
DEBUG - 2011-09-14 08:30:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:30:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:30:57 --> URI Class Initialized
DEBUG - 2011-09-14 08:30:57 --> Router Class Initialized
DEBUG - 2011-09-14 08:30:57 --> Output Class Initialized
DEBUG - 2011-09-14 08:30:57 --> Input Class Initialized
DEBUG - 2011-09-14 08:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:30:57 --> Language Class Initialized
DEBUG - 2011-09-14 08:30:58 --> Loader Class Initialized
DEBUG - 2011-09-14 08:30:58 --> Controller Class Initialized
DEBUG - 2011-09-14 08:30:58 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:58 --> Model Class Initialized
DEBUG - 2011-09-14 08:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:30:58 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:31:00 --> Final output sent to browser
DEBUG - 2011-09-14 08:31:00 --> Total execution time: 2.0200
DEBUG - 2011-09-14 08:31:00 --> Config Class Initialized
DEBUG - 2011-09-14 08:31:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:31:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:31:00 --> URI Class Initialized
DEBUG - 2011-09-14 08:31:00 --> Router Class Initialized
ERROR - 2011-09-14 08:31:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:31:02 --> Config Class Initialized
DEBUG - 2011-09-14 08:31:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:31:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:31:02 --> URI Class Initialized
DEBUG - 2011-09-14 08:31:02 --> Router Class Initialized
ERROR - 2011-09-14 08:31:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:31:03 --> Config Class Initialized
DEBUG - 2011-09-14 08:31:03 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:31:03 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:31:03 --> URI Class Initialized
DEBUG - 2011-09-14 08:31:03 --> Router Class Initialized
ERROR - 2011-09-14 08:31:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 08:50:08 --> Config Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:50:08 --> URI Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Router Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Output Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Input Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:50:08 --> Language Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Loader Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Controller Class Initialized
ERROR - 2011-09-14 08:50:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 08:50:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 08:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:50:08 --> Model Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Model Class Initialized
DEBUG - 2011-09-14 08:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:50:08 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 08:50:08 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:50:08 --> Final output sent to browser
DEBUG - 2011-09-14 08:50:08 --> Total execution time: 0.5316
DEBUG - 2011-09-14 08:50:09 --> Config Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Hooks Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Utf8 Class Initialized
DEBUG - 2011-09-14 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 08:50:09 --> URI Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Router Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Output Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Input Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 08:50:09 --> Language Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Loader Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Controller Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Model Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Model Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Model Class Initialized
DEBUG - 2011-09-14 08:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 08:50:09 --> Database Driver Class Initialized
DEBUG - 2011-09-14 08:50:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 08:50:09 --> Helper loaded: url_helper
DEBUG - 2011-09-14 08:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 08:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 08:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 08:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 08:50:09 --> Final output sent to browser
DEBUG - 2011-09-14 08:50:09 --> Total execution time: 0.2211
DEBUG - 2011-09-14 09:00:57 --> Config Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:00:57 --> URI Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Router Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Output Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Input Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:00:57 --> Language Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Loader Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Controller Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Model Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Model Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Model Class Initialized
DEBUG - 2011-09-14 09:00:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:00:57 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:00:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 09:00:57 --> Helper loaded: url_helper
DEBUG - 2011-09-14 09:00:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 09:00:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 09:00:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 09:00:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 09:00:57 --> Final output sent to browser
DEBUG - 2011-09-14 09:00:57 --> Total execution time: 0.1266
DEBUG - 2011-09-14 09:01:06 --> Config Class Initialized
DEBUG - 2011-09-14 09:01:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:01:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:01:07 --> URI Class Initialized
DEBUG - 2011-09-14 09:01:07 --> Router Class Initialized
ERROR - 2011-09-14 09:01:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 09:13:07 --> Config Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:13:07 --> URI Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Router Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Output Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Input Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:13:07 --> Language Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Loader Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Controller Class Initialized
ERROR - 2011-09-14 09:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 09:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 09:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 09:13:07 --> Model Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Model Class Initialized
DEBUG - 2011-09-14 09:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:13:07 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 09:13:07 --> Helper loaded: url_helper
DEBUG - 2011-09-14 09:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 09:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 09:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 09:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 09:13:07 --> Final output sent to browser
DEBUG - 2011-09-14 09:13:07 --> Total execution time: 0.1014
DEBUG - 2011-09-14 09:13:09 --> Config Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:13:09 --> URI Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Router Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Output Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Input Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:13:09 --> Language Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Loader Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Controller Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Model Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Model Class Initialized
DEBUG - 2011-09-14 09:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:13:09 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:13:11 --> Final output sent to browser
DEBUG - 2011-09-14 09:13:11 --> Total execution time: 1.9956
DEBUG - 2011-09-14 09:13:12 --> Config Class Initialized
DEBUG - 2011-09-14 09:13:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:13:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:13:12 --> URI Class Initialized
DEBUG - 2011-09-14 09:13:12 --> Router Class Initialized
ERROR - 2011-09-14 09:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 09:15:22 --> Config Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:15:22 --> URI Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Router Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Output Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Input Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:15:22 --> Language Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Loader Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Controller Class Initialized
ERROR - 2011-09-14 09:15:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 09:15:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 09:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 09:15:22 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:15:22 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 09:15:22 --> Helper loaded: url_helper
DEBUG - 2011-09-14 09:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 09:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 09:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 09:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 09:15:22 --> Final output sent to browser
DEBUG - 2011-09-14 09:15:22 --> Total execution time: 0.1760
DEBUG - 2011-09-14 09:15:24 --> Config Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:15:24 --> URI Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Router Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Output Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Input Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:15:24 --> Language Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Loader Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Controller Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:15:24 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:15:25 --> Final output sent to browser
DEBUG - 2011-09-14 09:15:25 --> Total execution time: 0.5743
DEBUG - 2011-09-14 09:15:26 --> Config Class Initialized
DEBUG - 2011-09-14 09:15:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:15:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:15:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:15:26 --> URI Class Initialized
DEBUG - 2011-09-14 09:15:26 --> Router Class Initialized
ERROR - 2011-09-14 09:15:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 09:15:42 --> Config Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:15:42 --> URI Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Router Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Output Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Input Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:15:42 --> Language Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Loader Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Controller Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:15:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Config Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:15:47 --> URI Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Router Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Output Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Input Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:15:47 --> Language Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Loader Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Controller Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Model Class Initialized
DEBUG - 2011-09-14 09:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:15:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 09:15:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 09:15:49 --> Final output sent to browser
DEBUG - 2011-09-14 09:15:49 --> Total execution time: 7.6092
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 09:15:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 09:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 09:15:49 --> Final output sent to browser
DEBUG - 2011-09-14 09:15:49 --> Total execution time: 2.0544
DEBUG - 2011-09-14 09:16:08 --> Config Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Hooks Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Utf8 Class Initialized
DEBUG - 2011-09-14 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 09:16:08 --> URI Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Router Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Output Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Input Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 09:16:08 --> Language Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Loader Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Controller Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Model Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Model Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Model Class Initialized
DEBUG - 2011-09-14 09:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 09:16:08 --> Database Driver Class Initialized
DEBUG - 2011-09-14 09:16:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 09:16:08 --> Helper loaded: url_helper
DEBUG - 2011-09-14 09:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 09:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 09:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 09:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 09:16:08 --> Final output sent to browser
DEBUG - 2011-09-14 09:16:08 --> Total execution time: 0.9055
DEBUG - 2011-09-14 10:24:58 --> Config Class Initialized
DEBUG - 2011-09-14 10:24:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:24:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:24:58 --> URI Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Router Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Output Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Input Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:24:59 --> Language Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Loader Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Controller Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Model Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Model Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Model Class Initialized
DEBUG - 2011-09-14 10:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:24:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:25:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:25:03 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:25:03 --> Final output sent to browser
DEBUG - 2011-09-14 10:25:03 --> Total execution time: 4.3973
DEBUG - 2011-09-14 10:42:36 --> Config Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:42:36 --> URI Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Router Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Output Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Input Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:42:36 --> Language Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Loader Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Controller Class Initialized
ERROR - 2011-09-14 10:42:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 10:42:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 10:42:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 10:42:36 --> Model Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Model Class Initialized
DEBUG - 2011-09-14 10:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:42:36 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:42:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 10:42:36 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:42:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:42:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:42:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:42:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:42:36 --> Final output sent to browser
DEBUG - 2011-09-14 10:42:36 --> Total execution time: 0.1336
DEBUG - 2011-09-14 10:42:41 --> Config Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:42:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:42:41 --> URI Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Router Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Output Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Input Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:42:41 --> Language Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Loader Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Controller Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Model Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Model Class Initialized
DEBUG - 2011-09-14 10:42:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:42:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:42:42 --> Final output sent to browser
DEBUG - 2011-09-14 10:42:42 --> Total execution time: 0.6074
DEBUG - 2011-09-14 10:43:05 --> Config Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:43:05 --> URI Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Router Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Output Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Input Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:43:05 --> Language Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Loader Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Controller Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Model Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Model Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Model Class Initialized
DEBUG - 2011-09-14 10:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:43:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:43:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:43:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:43:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:43:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:43:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:43:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:43:05 --> Final output sent to browser
DEBUG - 2011-09-14 10:43:05 --> Total execution time: 0.0462
DEBUG - 2011-09-14 10:47:47 --> Config Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:47:47 --> URI Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Router Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Output Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Input Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:47:47 --> Language Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Loader Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Controller Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:47:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:47:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:47:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:47:47 --> Final output sent to browser
DEBUG - 2011-09-14 10:47:47 --> Total execution time: 0.0474
DEBUG - 2011-09-14 10:47:50 --> Config Class Initialized
DEBUG - 2011-09-14 10:47:50 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:47:50 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:47:50 --> URI Class Initialized
DEBUG - 2011-09-14 10:47:50 --> Router Class Initialized
ERROR - 2011-09-14 10:47:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 10:47:54 --> Config Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:47:54 --> URI Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Router Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Output Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Input Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:47:54 --> Language Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Loader Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Controller Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:47:54 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:47:55 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:47:55 --> Final output sent to browser
DEBUG - 2011-09-14 10:47:55 --> Total execution time: 0.6221
DEBUG - 2011-09-14 10:47:56 --> Config Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:47:56 --> URI Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Router Class Initialized
ERROR - 2011-09-14 10:47:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 10:47:56 --> Config Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:47:56 --> URI Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Router Class Initialized
ERROR - 2011-09-14 10:47:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 10:47:56 --> Config Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:47:56 --> URI Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Router Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Output Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Input Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:47:56 --> Language Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Loader Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Controller Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Model Class Initialized
DEBUG - 2011-09-14 10:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:47:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:47:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:47:56 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:47:56 --> Final output sent to browser
DEBUG - 2011-09-14 10:47:56 --> Total execution time: 0.0558
DEBUG - 2011-09-14 10:48:23 --> Config Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:48:23 --> URI Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Router Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Output Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Input Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:48:23 --> Language Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Loader Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Controller Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Model Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Model Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Model Class Initialized
DEBUG - 2011-09-14 10:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:48:23 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:48:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:48:24 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:48:24 --> Final output sent to browser
DEBUG - 2011-09-14 10:48:24 --> Total execution time: 0.4830
DEBUG - 2011-09-14 10:48:26 --> Config Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:48:26 --> URI Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Router Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Output Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Input Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 10:48:26 --> Language Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Loader Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Controller Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Model Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Model Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Model Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 10:48:26 --> Database Driver Class Initialized
DEBUG - 2011-09-14 10:48:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 10:48:26 --> Helper loaded: url_helper
DEBUG - 2011-09-14 10:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 10:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 10:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 10:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 10:48:26 --> Final output sent to browser
DEBUG - 2011-09-14 10:48:26 --> Total execution time: 0.1596
DEBUG - 2011-09-14 10:48:26 --> Config Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 10:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 10:48:26 --> URI Class Initialized
DEBUG - 2011-09-14 10:48:26 --> Router Class Initialized
ERROR - 2011-09-14 10:48:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 11:01:21 --> Config Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:01:21 --> URI Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Router Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Output Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Input Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:01:21 --> Language Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Loader Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Controller Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:01:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:01:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:01:21 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:01:21 --> Final output sent to browser
DEBUG - 2011-09-14 11:01:21 --> Total execution time: 0.0820
DEBUG - 2011-09-14 11:01:25 --> Config Class Initialized
DEBUG - 2011-09-14 11:01:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:01:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:01:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:01:25 --> URI Class Initialized
DEBUG - 2011-09-14 11:01:25 --> Router Class Initialized
ERROR - 2011-09-14 11:01:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 11:01:48 --> Config Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:01:48 --> URI Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Router Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Output Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Input Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:01:48 --> Language Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Loader Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Controller Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:01:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:01:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:01:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:01:49 --> Final output sent to browser
DEBUG - 2011-09-14 11:01:49 --> Total execution time: 0.3485
DEBUG - 2011-09-14 11:01:52 --> Config Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:01:52 --> URI Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Router Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Output Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Input Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:01:52 --> Language Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Loader Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Controller Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:01:52 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:01:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:01:52 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:01:52 --> Final output sent to browser
DEBUG - 2011-09-14 11:01:52 --> Total execution time: 0.0456
DEBUG - 2011-09-14 11:01:58 --> Config Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:01:58 --> URI Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Router Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Output Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Input Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:01:58 --> Language Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Loader Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Controller Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Model Class Initialized
DEBUG - 2011-09-14 11:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:01:58 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:01:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:01:59 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:01:59 --> Final output sent to browser
DEBUG - 2011-09-14 11:01:59 --> Total execution time: 0.7202
DEBUG - 2011-09-14 11:02:01 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:01 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:01 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:01 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:01 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:01 --> Total execution time: 0.1204
DEBUG - 2011-09-14 11:02:26 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:26 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:26 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:26 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:26 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:26 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:26 --> Total execution time: 0.3220
DEBUG - 2011-09-14 11:02:29 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:29 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:29 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:29 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:29 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:29 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:29 --> Total execution time: 0.1160
DEBUG - 2011-09-14 11:02:34 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:34 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:34 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:34 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:34 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:34 --> Total execution time: 0.4818
DEBUG - 2011-09-14 11:02:41 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:41 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:41 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:41 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:41 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:41 --> Total execution time: 0.1057
DEBUG - 2011-09-14 11:02:41 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:41 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:41 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:42 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:42 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:42 --> Total execution time: 0.7384
DEBUG - 2011-09-14 11:02:50 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:50 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:50 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:50 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:50 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:50 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:50 --> Total execution time: 0.1197
DEBUG - 2011-09-14 11:02:51 --> Config Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:02:51 --> URI Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Router Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Output Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Input Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:02:51 --> Language Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Loader Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Controller Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Model Class Initialized
DEBUG - 2011-09-14 11:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:02:51 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:02:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:02:51 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:02:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:02:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:02:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:02:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:02:51 --> Final output sent to browser
DEBUG - 2011-09-14 11:02:51 --> Total execution time: 0.0480
DEBUG - 2011-09-14 11:03:22 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:22 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:22 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:22 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:22 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:22 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:22 --> Total execution time: 0.3375
DEBUG - 2011-09-14 11:03:32 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:32 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:32 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:32 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:32 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:32 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:32 --> Total execution time: 0.5692
DEBUG - 2011-09-14 11:03:35 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:35 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:35 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:35 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:35 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:35 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:35 --> Total execution time: 0.0942
DEBUG - 2011-09-14 11:03:39 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:39 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:39 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:39 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:39 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:39 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:39 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:39 --> Total execution time: 0.0550
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:39 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:39 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:39 --> Total execution time: 0.4794
DEBUG - 2011-09-14 11:03:42 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:42 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:42 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:42 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:42 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:42 --> Total execution time: 0.0483
DEBUG - 2011-09-14 11:03:46 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:46 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:46 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:46 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:50 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:50 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:50 --> Total execution time: 4.2344
DEBUG - 2011-09-14 11:03:52 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:52 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:52 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:52 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:53 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:53 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:53 --> Total execution time: 0.2258
DEBUG - 2011-09-14 11:03:55 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:55 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:55 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:55 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:56 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:56 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:56 --> Total execution time: 0.6926
DEBUG - 2011-09-14 11:03:59 --> Config Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:03:59 --> URI Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Router Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Output Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Input Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:03:59 --> Language Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Loader Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Controller Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Model Class Initialized
DEBUG - 2011-09-14 11:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:03:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:03:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:03:59 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:03:59 --> Final output sent to browser
DEBUG - 2011-09-14 11:03:59 --> Total execution time: 0.0447
DEBUG - 2011-09-14 11:04:00 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:00 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:00 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:00 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:00 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:00 --> Total execution time: 0.4361
DEBUG - 2011-09-14 11:04:05 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:05 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:05 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:05 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:05 --> Total execution time: 0.6852
DEBUG - 2011-09-14 11:04:07 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:07 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:07 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:07 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:07 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:07 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:07 --> Total execution time: 0.0865
DEBUG - 2011-09-14 11:04:07 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:07 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:07 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:07 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:08 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:08 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:08 --> Total execution time: 0.0501
DEBUG - 2011-09-14 11:04:11 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:11 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:11 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:11 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:11 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:11 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:11 --> Total execution time: 0.2817
DEBUG - 2011-09-14 11:04:12 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:12 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:12 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:12 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:12 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:12 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:12 --> Total execution time: 0.0561
DEBUG - 2011-09-14 11:04:16 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:16 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:16 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:16 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:17 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:17 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:17 --> Total execution time: 0.2204
DEBUG - 2011-09-14 11:04:18 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:18 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:18 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:18 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:18 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:18 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:18 --> Total execution time: 0.1370
DEBUG - 2011-09-14 11:04:21 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:21 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:21 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:22 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:22 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:22 --> Total execution time: 0.7931
DEBUG - 2011-09-14 11:04:24 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:24 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:24 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:24 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:24 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:24 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:24 --> Total execution time: 0.0515
DEBUG - 2011-09-14 11:04:27 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:27 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:27 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:27 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:27 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:27 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:27 --> Total execution time: 0.1847
DEBUG - 2011-09-14 11:04:31 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:31 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:31 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:32 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:32 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:32 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:32 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:32 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:32 --> Total execution time: 0.0563
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:32 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:32 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:32 --> Total execution time: 0.4584
DEBUG - 2011-09-14 11:04:33 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:33 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:33 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:33 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:33 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:33 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:33 --> Total execution time: 0.0531
DEBUG - 2011-09-14 11:04:38 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:38 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:38 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:38 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:38 --> Total execution time: 0.4592
DEBUG - 2011-09-14 11:04:39 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:39 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:39 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:39 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:39 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:39 --> Total execution time: 0.0448
DEBUG - 2011-09-14 11:04:43 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:43 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:43 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:43 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:43 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:43 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:43 --> Total execution time: 0.2483
DEBUG - 2011-09-14 11:04:45 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:45 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:45 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:45 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:45 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:45 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:45 --> Total execution time: 0.0473
DEBUG - 2011-09-14 11:04:47 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:47 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:47 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:48 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:48 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:48 --> Total execution time: 0.3401
DEBUG - 2011-09-14 11:04:49 --> Config Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:04:49 --> URI Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Router Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Output Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Input Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:04:49 --> Language Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Loader Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Controller Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Model Class Initialized
DEBUG - 2011-09-14 11:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:04:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:04:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:04:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:04:49 --> Final output sent to browser
DEBUG - 2011-09-14 11:04:49 --> Total execution time: 0.0422
DEBUG - 2011-09-14 11:05:01 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:01 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:01 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:05:01 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:01 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:01 --> Total execution time: 0.5901
DEBUG - 2011-09-14 11:05:07 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:07 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:07 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:07 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:05:08 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:08 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:08 --> Total execution time: 1.6230
DEBUG - 2011-09-14 11:05:09 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:09 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:09 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:09 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:05:09 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:09 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:09 --> Total execution time: 0.1147
DEBUG - 2011-09-14 11:05:15 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:15 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:15 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:05:16 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:16 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:16 --> Total execution time: 0.3102
DEBUG - 2011-09-14 11:05:16 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:16 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:16 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:16 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:05:16 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:16 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:16 --> Total execution time: 0.0540
DEBUG - 2011-09-14 11:05:21 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:21 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:21 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:05:21 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:21 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:21 --> Total execution time: 0.0550
DEBUG - 2011-09-14 11:05:38 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:38 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:38 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Controller Class Initialized
ERROR - 2011-09-14 11:05:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 11:05:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 11:05:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 11:05:38 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 11:05:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:05:38 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:38 --> Total execution time: 0.0304
DEBUG - 2011-09-14 11:05:41 --> Config Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:05:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:05:41 --> URI Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Router Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Output Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Input Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:05:41 --> Language Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Loader Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Controller Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Model Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:05:41 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:05:41 --> Final output sent to browser
DEBUG - 2011-09-14 11:05:41 --> Total execution time: 0.7099
DEBUG - 2011-09-14 11:34:09 --> Config Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:34:09 --> URI Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Router Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Output Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Input Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:34:09 --> Language Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Loader Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Controller Class Initialized
ERROR - 2011-09-14 11:34:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 11:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 11:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 11:34:09 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:34:09 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 11:34:09 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:34:09 --> Final output sent to browser
DEBUG - 2011-09-14 11:34:09 --> Total execution time: 0.1194
DEBUG - 2011-09-14 11:34:11 --> Config Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:34:11 --> URI Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Router Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Output Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Input Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:34:11 --> Language Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Loader Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Controller Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:34:11 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:34:11 --> Final output sent to browser
DEBUG - 2011-09-14 11:34:11 --> Total execution time: 0.6017
DEBUG - 2011-09-14 11:34:17 --> Config Class Initialized
DEBUG - 2011-09-14 11:34:17 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:34:17 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:34:17 --> URI Class Initialized
DEBUG - 2011-09-14 11:34:17 --> Router Class Initialized
ERROR - 2011-09-14 11:34:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 11:34:48 --> Config Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:34:48 --> URI Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Router Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Output Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Input Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:34:48 --> Language Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Loader Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Controller Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Model Class Initialized
DEBUG - 2011-09-14 11:34:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:34:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:34:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 11:34:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:34:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:34:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:34:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:34:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:34:49 --> Final output sent to browser
DEBUG - 2011-09-14 11:34:49 --> Total execution time: 1.1249
DEBUG - 2011-09-14 11:35:34 --> Config Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:35:34 --> URI Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Router Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Output Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Input Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:35:34 --> Language Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Loader Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Controller Class Initialized
ERROR - 2011-09-14 11:35:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 11:35:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 11:35:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 11:35:34 --> Model Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Model Class Initialized
DEBUG - 2011-09-14 11:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:35:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:35:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 11:35:34 --> Helper loaded: url_helper
DEBUG - 2011-09-14 11:35:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 11:35:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 11:35:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 11:35:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 11:35:34 --> Final output sent to browser
DEBUG - 2011-09-14 11:35:34 --> Total execution time: 0.0647
DEBUG - 2011-09-14 11:35:37 --> Config Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Hooks Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Utf8 Class Initialized
DEBUG - 2011-09-14 11:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 11:35:37 --> URI Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Router Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Output Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Input Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 11:35:37 --> Language Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Loader Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Controller Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Model Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Model Class Initialized
DEBUG - 2011-09-14 11:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 11:35:37 --> Database Driver Class Initialized
DEBUG - 2011-09-14 11:35:38 --> Final output sent to browser
DEBUG - 2011-09-14 11:35:38 --> Total execution time: 0.9895
DEBUG - 2011-09-14 12:01:38 --> Config Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:01:38 --> URI Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Router Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Output Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Input Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:01:38 --> Language Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Loader Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Controller Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Model Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Model Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Model Class Initialized
DEBUG - 2011-09-14 12:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:01:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:01:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:01:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:01:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:01:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:01:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:01:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:01:38 --> Final output sent to browser
DEBUG - 2011-09-14 12:01:38 --> Total execution time: 0.6599
DEBUG - 2011-09-14 12:02:15 --> Config Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:02:15 --> URI Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Router Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Output Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Input Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:02:15 --> Language Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Loader Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Controller Class Initialized
ERROR - 2011-09-14 12:02:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 12:02:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 12:02:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:02:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:02:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:02:15 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:02:15 --> Final output sent to browser
DEBUG - 2011-09-14 12:02:15 --> Total execution time: 0.0297
DEBUG - 2011-09-14 12:02:15 --> Config Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:02:15 --> URI Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Router Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Output Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Input Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:02:15 --> Language Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Loader Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Controller Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:02:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:02:16 --> Final output sent to browser
DEBUG - 2011-09-14 12:02:16 --> Total execution time: 0.7582
DEBUG - 2011-09-14 12:29:42 --> Config Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:29:42 --> URI Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Router Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Output Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Input Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:29:42 --> Language Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Loader Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Controller Class Initialized
ERROR - 2011-09-14 12:29:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 12:29:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 12:29:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:29:42 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:29:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:29:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:29:42 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:29:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:29:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:29:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:29:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:29:42 --> Final output sent to browser
DEBUG - 2011-09-14 12:29:42 --> Total execution time: 0.0649
DEBUG - 2011-09-14 12:29:42 --> Config Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:29:42 --> URI Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Router Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Output Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Input Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:29:42 --> Language Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Loader Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Controller Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:29:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:29:43 --> Final output sent to browser
DEBUG - 2011-09-14 12:29:43 --> Total execution time: 0.6034
DEBUG - 2011-09-14 12:29:59 --> Config Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:29:59 --> URI Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Router Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Output Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Input Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:29:59 --> Language Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Loader Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Controller Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:29:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:30:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:30:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:30:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:30:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:30:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:30:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:30:00 --> Final output sent to browser
DEBUG - 2011-09-14 12:30:00 --> Total execution time: 0.3878
DEBUG - 2011-09-14 12:47:06 --> Config Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:47:06 --> URI Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Router Class Initialized
ERROR - 2011-09-14 12:47:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 12:47:06 --> Config Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:47:06 --> URI Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Router Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Output Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Input Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:47:06 --> Language Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Loader Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Controller Class Initialized
ERROR - 2011-09-14 12:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 12:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 12:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:47:06 --> Model Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Model Class Initialized
DEBUG - 2011-09-14 12:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:47:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:47:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:47:06 --> Final output sent to browser
DEBUG - 2011-09-14 12:47:06 --> Total execution time: 0.1164
DEBUG - 2011-09-14 12:48:34 --> Config Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:48:34 --> URI Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Router Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Output Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Input Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:48:34 --> Language Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Loader Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Controller Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Model Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Model Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Model Class Initialized
DEBUG - 2011-09-14 12:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:48:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:48:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:48:35 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:48:35 --> Final output sent to browser
DEBUG - 2011-09-14 12:48:35 --> Total execution time: 0.3108
DEBUG - 2011-09-14 12:48:55 --> Config Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:48:55 --> URI Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Router Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Output Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Input Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:48:55 --> Language Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Loader Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Controller Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Model Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Model Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Model Class Initialized
DEBUG - 2011-09-14 12:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:48:55 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:48:55 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:48:55 --> Final output sent to browser
DEBUG - 2011-09-14 12:48:55 --> Total execution time: 0.0457
DEBUG - 2011-09-14 12:49:12 --> Config Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:49:12 --> URI Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Router Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Output Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Input Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:49:12 --> Language Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Loader Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Controller Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:49:12 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:49:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:49:12 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:49:12 --> Final output sent to browser
DEBUG - 2011-09-14 12:49:12 --> Total execution time: 0.6133
DEBUG - 2011-09-14 12:49:27 --> Config Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:49:27 --> URI Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Router Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Output Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Input Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:49:27 --> Language Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Loader Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Controller Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:49:27 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:49:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:49:28 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:49:28 --> Final output sent to browser
DEBUG - 2011-09-14 12:49:28 --> Total execution time: 0.2855
DEBUG - 2011-09-14 12:49:59 --> Config Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:49:59 --> URI Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Router Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Output Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Input Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:49:59 --> Language Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Loader Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Controller Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:49:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:50:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:50:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:50:00 --> Final output sent to browser
DEBUG - 2011-09-14 12:50:00 --> Total execution time: 0.3820
DEBUG - 2011-09-14 12:52:24 --> Config Class Initialized
DEBUG - 2011-09-14 12:52:24 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:52:24 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:52:25 --> URI Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Router Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Output Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Input Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:52:25 --> Language Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Loader Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Controller Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:52:25 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:52:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:52:25 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:52:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:52:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:52:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:52:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:52:25 --> Final output sent to browser
DEBUG - 2011-09-14 12:52:25 --> Total execution time: 0.0487
DEBUG - 2011-09-14 12:52:27 --> Config Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:52:27 --> URI Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Router Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Output Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Input Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:52:27 --> Language Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Loader Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Controller Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:52:27 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:52:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:52:27 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:52:27 --> Final output sent to browser
DEBUG - 2011-09-14 12:52:27 --> Total execution time: 0.0704
DEBUG - 2011-09-14 12:52:31 --> Config Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:52:31 --> URI Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Router Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Output Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Input Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:52:31 --> Language Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Loader Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Controller Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Model Class Initialized
DEBUG - 2011-09-14 12:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:52:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:52:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:52:31 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:52:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:52:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:52:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:52:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:52:31 --> Final output sent to browser
DEBUG - 2011-09-14 12:52:31 --> Total execution time: 0.0564
DEBUG - 2011-09-14 12:54:23 --> Config Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:54:23 --> URI Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Router Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Output Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Input Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:54:23 --> Language Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Loader Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Controller Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Model Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Model Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Model Class Initialized
DEBUG - 2011-09-14 12:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:54:23 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:54:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:54:23 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:54:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:54:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:54:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:54:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:54:23 --> Final output sent to browser
DEBUG - 2011-09-14 12:54:23 --> Total execution time: 0.4466
DEBUG - 2011-09-14 12:54:47 --> Config Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:54:47 --> URI Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Router Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Output Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Input Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:54:47 --> Language Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Loader Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Controller Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Model Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Model Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Model Class Initialized
DEBUG - 2011-09-14 12:54:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:54:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:54:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:54:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:54:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:54:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:54:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:54:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:54:47 --> Final output sent to browser
DEBUG - 2011-09-14 12:54:47 --> Total execution time: 0.0478
DEBUG - 2011-09-14 12:55:01 --> Config Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:55:01 --> URI Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Router Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Output Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Input Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:55:01 --> Language Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Loader Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Controller Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:55:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:55:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:55:01 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:55:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:55:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:55:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:55:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:55:01 --> Final output sent to browser
DEBUG - 2011-09-14 12:55:01 --> Total execution time: 0.2491
DEBUG - 2011-09-14 12:55:03 --> Config Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:55:03 --> URI Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Router Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Output Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Input Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:55:03 --> Language Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Loader Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Controller Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:55:03 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:55:03 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:55:03 --> Final output sent to browser
DEBUG - 2011-09-14 12:55:03 --> Total execution time: 0.1514
DEBUG - 2011-09-14 12:55:13 --> Config Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:55:13 --> URI Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Router Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Output Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Input Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:55:13 --> Language Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Loader Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Controller Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:55:13 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:55:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:55:13 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:55:13 --> Final output sent to browser
DEBUG - 2011-09-14 12:55:13 --> Total execution time: 0.6372
DEBUG - 2011-09-14 12:55:16 --> Config Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:55:16 --> URI Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Router Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Output Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Input Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:55:16 --> Language Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Loader Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Controller Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:55:16 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:55:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:55:16 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:55:16 --> Final output sent to browser
DEBUG - 2011-09-14 12:55:16 --> Total execution time: 0.1841
DEBUG - 2011-09-14 12:55:58 --> Config Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:55:58 --> URI Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Router Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Output Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Input Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:55:58 --> Language Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Loader Class Initialized
DEBUG - 2011-09-14 12:55:58 --> Controller Class Initialized
ERROR - 2011-09-14 12:55:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 12:55:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 12:55:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:55:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:55:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:55:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 12:55:59 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:55:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:55:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:55:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:55:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:55:59 --> Final output sent to browser
DEBUG - 2011-09-14 12:55:59 --> Total execution time: 0.0294
DEBUG - 2011-09-14 12:55:59 --> Config Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:55:59 --> URI Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Router Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Output Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Input Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:55:59 --> Language Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Loader Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Controller Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Model Class Initialized
DEBUG - 2011-09-14 12:55:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:55:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:56:00 --> Final output sent to browser
DEBUG - 2011-09-14 12:56:00 --> Total execution time: 0.6310
DEBUG - 2011-09-14 12:57:12 --> Config Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:57:12 --> URI Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Router Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Output Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Input Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:57:12 --> Language Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Loader Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Controller Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Model Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Model Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Model Class Initialized
DEBUG - 2011-09-14 12:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:57:12 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:57:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:57:12 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:57:12 --> Final output sent to browser
DEBUG - 2011-09-14 12:57:12 --> Total execution time: 0.2581
DEBUG - 2011-09-14 12:57:15 --> Config Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 12:57:15 --> URI Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Router Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Output Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Input Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 12:57:15 --> Language Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Loader Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Controller Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Model Class Initialized
DEBUG - 2011-09-14 12:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 12:57:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 12:57:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 12:57:15 --> Helper loaded: url_helper
DEBUG - 2011-09-14 12:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 12:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 12:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 12:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 12:57:15 --> Final output sent to browser
DEBUG - 2011-09-14 12:57:15 --> Total execution time: 0.0482
DEBUG - 2011-09-14 13:22:39 --> Config Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:22:39 --> URI Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Router Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Output Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Input Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:22:39 --> Language Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Loader Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Controller Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:22:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:22:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 13:22:39 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:22:39 --> Final output sent to browser
DEBUG - 2011-09-14 13:22:39 --> Total execution time: 0.3056
DEBUG - 2011-09-14 13:22:56 --> Config Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:22:56 --> URI Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Router Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Output Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Input Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:22:56 --> Language Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Loader Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Controller Class Initialized
ERROR - 2011-09-14 13:22:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:22:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:22:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:22:56 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:22:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:22:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:22:56 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:22:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:22:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:22:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:22:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:22:56 --> Final output sent to browser
DEBUG - 2011-09-14 13:22:56 --> Total execution time: 0.0337
DEBUG - 2011-09-14 13:22:57 --> Config Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:22:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:22:57 --> URI Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Router Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Output Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Input Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:22:57 --> Language Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Loader Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Controller Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Model Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:22:57 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:22:57 --> Final output sent to browser
DEBUG - 2011-09-14 13:22:57 --> Total execution time: 0.7418
DEBUG - 2011-09-14 13:28:35 --> Config Class Initialized
DEBUG - 2011-09-14 13:28:35 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:28:35 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:28:35 --> URI Class Initialized
DEBUG - 2011-09-14 13:28:35 --> Router Class Initialized
ERROR - 2011-09-14 13:28:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 13:37:10 --> Config Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:37:10 --> URI Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Router Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Output Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Input Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:37:10 --> Language Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Loader Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Controller Class Initialized
ERROR - 2011-09-14 13:37:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:37:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:37:10 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:37:10 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:37:10 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:37:10 --> Final output sent to browser
DEBUG - 2011-09-14 13:37:10 --> Total execution time: 0.0608
DEBUG - 2011-09-14 13:37:13 --> Config Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:37:13 --> URI Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Router Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Output Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Input Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:37:13 --> Language Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Loader Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Controller Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:37:13 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:37:14 --> Final output sent to browser
DEBUG - 2011-09-14 13:37:14 --> Total execution time: 0.6292
DEBUG - 2011-09-14 13:37:19 --> Config Class Initialized
DEBUG - 2011-09-14 13:37:19 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:37:19 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:37:19 --> URI Class Initialized
DEBUG - 2011-09-14 13:37:19 --> Router Class Initialized
ERROR - 2011-09-14 13:37:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 13:37:56 --> Config Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:37:56 --> URI Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Router Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Output Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Input Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:37:56 --> Language Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Loader Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Controller Class Initialized
ERROR - 2011-09-14 13:37:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:37:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:37:56 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:37:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:37:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:37:57 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:37:57 --> Final output sent to browser
DEBUG - 2011-09-14 13:37:57 --> Total execution time: 0.0309
DEBUG - 2011-09-14 13:37:59 --> Config Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:37:59 --> URI Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Router Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Output Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Input Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:37:59 --> Language Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Loader Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Controller Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Model Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:37:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:37:59 --> Final output sent to browser
DEBUG - 2011-09-14 13:37:59 --> Total execution time: 0.5828
DEBUG - 2011-09-14 13:38:01 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:01 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:01 --> Router Class Initialized
ERROR - 2011-09-14 13:38:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 13:38:13 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:13 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Router Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Output Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Input Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:38:13 --> Language Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Loader Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Controller Class Initialized
ERROR - 2011-09-14 13:38:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:38:13 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:38:13 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:38:13 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:38:13 --> Final output sent to browser
DEBUG - 2011-09-14 13:38:13 --> Total execution time: 0.1168
DEBUG - 2011-09-14 13:38:21 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:21 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Router Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Output Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Input Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:38:21 --> Language Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Loader Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Controller Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:38:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:38:21 --> Final output sent to browser
DEBUG - 2011-09-14 13:38:21 --> Total execution time: 0.5914
DEBUG - 2011-09-14 13:38:25 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:25 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:25 --> Router Class Initialized
ERROR - 2011-09-14 13:38:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 13:38:49 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:49 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Router Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Output Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Input Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:38:49 --> Language Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Loader Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Controller Class Initialized
ERROR - 2011-09-14 13:38:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:38:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:38:49 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:38:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:38:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:38:49 --> Final output sent to browser
DEBUG - 2011-09-14 13:38:49 --> Total execution time: 0.0373
DEBUG - 2011-09-14 13:38:51 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:51 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Router Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Output Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Input Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:38:51 --> Language Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Loader Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Controller Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Model Class Initialized
DEBUG - 2011-09-14 13:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:38:51 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:38:52 --> Final output sent to browser
DEBUG - 2011-09-14 13:38:52 --> Total execution time: 0.6787
DEBUG - 2011-09-14 13:38:55 --> Config Class Initialized
DEBUG - 2011-09-14 13:38:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:38:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:38:55 --> URI Class Initialized
DEBUG - 2011-09-14 13:38:55 --> Router Class Initialized
ERROR - 2011-09-14 13:38:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 13:39:00 --> Config Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:39:00 --> URI Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Router Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Output Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Input Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:39:00 --> Language Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Loader Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Controller Class Initialized
ERROR - 2011-09-14 13:39:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:39:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:39:00 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:39:00 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:39:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:39:01 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:39:01 --> Final output sent to browser
DEBUG - 2011-09-14 13:39:01 --> Total execution time: 0.0653
DEBUG - 2011-09-14 13:39:02 --> Config Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:39:02 --> URI Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Router Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Output Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Input Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:39:02 --> Language Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Loader Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Controller Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:39:02 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:39:03 --> Final output sent to browser
DEBUG - 2011-09-14 13:39:03 --> Total execution time: 0.7272
DEBUG - 2011-09-14 13:39:07 --> Config Class Initialized
DEBUG - 2011-09-14 13:39:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:39:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:39:07 --> URI Class Initialized
DEBUG - 2011-09-14 13:39:07 --> Router Class Initialized
ERROR - 2011-09-14 13:39:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 13:39:14 --> Config Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:39:14 --> URI Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Router Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Output Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Input Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:39:14 --> Language Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Loader Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Controller Class Initialized
ERROR - 2011-09-14 13:39:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 13:39:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 13:39:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:39:14 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:39:14 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:39:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 13:39:14 --> Helper loaded: url_helper
DEBUG - 2011-09-14 13:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 13:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 13:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 13:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 13:39:14 --> Final output sent to browser
DEBUG - 2011-09-14 13:39:14 --> Total execution time: 0.0912
DEBUG - 2011-09-14 13:39:16 --> Config Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:39:16 --> URI Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Router Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Output Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Input Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 13:39:16 --> Language Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Loader Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Controller Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Model Class Initialized
DEBUG - 2011-09-14 13:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 13:39:16 --> Database Driver Class Initialized
DEBUG - 2011-09-14 13:39:17 --> Final output sent to browser
DEBUG - 2011-09-14 13:39:17 --> Total execution time: 0.6568
DEBUG - 2011-09-14 13:39:21 --> Config Class Initialized
DEBUG - 2011-09-14 13:39:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 13:39:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 13:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 13:39:21 --> URI Class Initialized
DEBUG - 2011-09-14 13:39:21 --> Router Class Initialized
ERROR - 2011-09-14 13:39:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 15:42:46 --> Config Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:42:46 --> URI Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Router Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Output Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Input Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:42:46 --> Language Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Loader Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Controller Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Model Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Model Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Model Class Initialized
DEBUG - 2011-09-14 15:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:42:46 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:42:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:42:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:42:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:42:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:42:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:42:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:42:47 --> Final output sent to browser
DEBUG - 2011-09-14 15:42:47 --> Total execution time: 1.0318
DEBUG - 2011-09-14 15:42:50 --> Config Class Initialized
DEBUG - 2011-09-14 15:42:50 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:42:50 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:42:50 --> URI Class Initialized
DEBUG - 2011-09-14 15:42:50 --> Router Class Initialized
ERROR - 2011-09-14 15:42:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 15:42:51 --> Config Class Initialized
DEBUG - 2011-09-14 15:42:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:42:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:42:51 --> URI Class Initialized
DEBUG - 2011-09-14 15:42:51 --> Router Class Initialized
ERROR - 2011-09-14 15:42:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 15:42:51 --> Config Class Initialized
DEBUG - 2011-09-14 15:42:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:42:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:42:51 --> URI Class Initialized
DEBUG - 2011-09-14 15:42:51 --> Router Class Initialized
ERROR - 2011-09-14 15:42:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 15:43:04 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:04 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:04 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:04 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:04 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:04 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:04 --> Total execution time: 0.3210
DEBUG - 2011-09-14 15:43:06 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:06 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:06 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:06 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:06 --> Total execution time: 0.0772
DEBUG - 2011-09-14 15:43:24 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:24 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:24 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:24 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:24 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:24 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:24 --> Total execution time: 0.2105
DEBUG - 2011-09-14 15:43:26 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:26 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:26 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:26 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:27 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:27 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:27 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:27 --> Total execution time: 0.0474
DEBUG - 2011-09-14 15:43:27 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:27 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:27 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:27 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:27 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:27 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:27 --> Total execution time: 0.0463
DEBUG - 2011-09-14 15:43:31 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:31 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:31 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:32 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:32 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:32 --> Total execution time: 0.4743
DEBUG - 2011-09-14 15:43:40 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:40 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:40 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:40 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:40 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:40 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:40 --> Total execution time: 0.4062
DEBUG - 2011-09-14 15:43:49 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:49 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:49 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:49 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:49 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:49 --> Total execution time: 0.5184
DEBUG - 2011-09-14 15:43:56 --> Config Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:43:56 --> URI Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Router Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Output Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Input Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:43:56 --> Language Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Loader Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Controller Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Model Class Initialized
DEBUG - 2011-09-14 15:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:43:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:43:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:43:56 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:43:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:43:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:43:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:43:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:43:56 --> Final output sent to browser
DEBUG - 2011-09-14 15:43:56 --> Total execution time: 0.2652
DEBUG - 2011-09-14 15:44:03 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:03 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:03 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:03 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:03 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:03 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:03 --> Total execution time: 0.0625
DEBUG - 2011-09-14 15:44:05 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:05 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:05 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:06 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:06 --> Total execution time: 0.7058
DEBUG - 2011-09-14 15:44:15 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:15 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:15 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:16 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:16 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:16 --> Total execution time: 0.3185
DEBUG - 2011-09-14 15:44:19 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:19 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:19 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:19 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:19 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:19 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:19 --> Total execution time: 0.0410
DEBUG - 2011-09-14 15:44:21 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:21 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:21 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:21 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:21 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:21 --> Total execution time: 0.2983
DEBUG - 2011-09-14 15:44:22 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:22 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:22 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:22 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:22 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:22 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:22 --> Total execution time: 0.0526
DEBUG - 2011-09-14 15:44:27 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:27 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:27 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:27 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:28 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:28 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:28 --> Total execution time: 0.5291
DEBUG - 2011-09-14 15:44:30 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:30 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:30 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:30 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:30 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:30 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:30 --> Total execution time: 0.0497
DEBUG - 2011-09-14 15:44:35 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:35 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:35 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:35 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:35 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:35 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:35 --> Total execution time: 0.2599
DEBUG - 2011-09-14 15:44:36 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:36 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:36 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:36 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:36 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:36 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:36 --> Total execution time: 0.0774
DEBUG - 2011-09-14 15:44:42 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:42 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:42 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:42 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:42 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:42 --> Total execution time: 0.2500
DEBUG - 2011-09-14 15:44:43 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:43 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:43 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:43 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:43 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:43 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:43 --> Total execution time: 0.0438
DEBUG - 2011-09-14 15:44:47 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:47 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:47 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:47 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:47 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:47 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:47 --> Total execution time: 0.2566
DEBUG - 2011-09-14 15:44:48 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:48 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:48 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:48 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:48 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:48 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:48 --> Total execution time: 0.0445
DEBUG - 2011-09-14 15:44:54 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:54 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:54 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:54 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:54 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:54 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:54 --> Total execution time: 0.2742
DEBUG - 2011-09-14 15:44:55 --> Config Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:44:55 --> URI Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Router Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Output Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Input Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:44:55 --> Language Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Loader Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Controller Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Model Class Initialized
DEBUG - 2011-09-14 15:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:44:55 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:44:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:44:55 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:44:55 --> Final output sent to browser
DEBUG - 2011-09-14 15:44:55 --> Total execution time: 0.0440
DEBUG - 2011-09-14 15:45:00 --> Config Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:45:00 --> URI Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Router Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Output Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Input Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:45:00 --> Language Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Loader Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Controller Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:45:00 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:45:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:45:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:45:00 --> Final output sent to browser
DEBUG - 2011-09-14 15:45:00 --> Total execution time: 0.3324
DEBUG - 2011-09-14 15:45:06 --> Config Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:45:06 --> URI Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Router Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Output Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Input Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:45:06 --> Language Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Loader Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Controller Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:45:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:45:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:45:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:45:06 --> Final output sent to browser
DEBUG - 2011-09-14 15:45:06 --> Total execution time: 0.3472
DEBUG - 2011-09-14 15:45:12 --> Config Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:45:12 --> URI Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Router Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Output Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Input Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:45:12 --> Language Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Loader Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Controller Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:45:12 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:45:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:45:12 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:45:12 --> Final output sent to browser
DEBUG - 2011-09-14 15:45:12 --> Total execution time: 0.3016
DEBUG - 2011-09-14 15:45:39 --> Config Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:45:39 --> URI Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Router Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Output Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Input Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:45:39 --> Language Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Loader Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Controller Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Model Class Initialized
DEBUG - 2011-09-14 15:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:45:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:45:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:45:39 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:45:39 --> Final output sent to browser
DEBUG - 2011-09-14 15:45:39 --> Total execution time: 0.0492
DEBUG - 2011-09-14 15:45:45 --> Config Class Initialized
DEBUG - 2011-09-14 15:45:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:45:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:45:45 --> URI Class Initialized
DEBUG - 2011-09-14 15:45:45 --> Router Class Initialized
ERROR - 2011-09-14 15:45:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 15:45:45 --> Config Class Initialized
DEBUG - 2011-09-14 15:45:45 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:45:45 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:45:45 --> URI Class Initialized
DEBUG - 2011-09-14 15:45:45 --> Router Class Initialized
ERROR - 2011-09-14 15:45:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 15:46:30 --> Config Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:46:30 --> URI Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Router Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Output Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Input Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:46:30 --> Language Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Loader Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Controller Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Model Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Model Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Model Class Initialized
DEBUG - 2011-09-14 15:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:46:30 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:46:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:46:30 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:46:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:46:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:46:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:46:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:46:30 --> Final output sent to browser
DEBUG - 2011-09-14 15:46:30 --> Total execution time: 0.2707
DEBUG - 2011-09-14 15:46:34 --> Config Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:46:34 --> URI Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Router Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Output Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Input Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:46:34 --> Language Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Loader Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Controller Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Model Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Model Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Model Class Initialized
DEBUG - 2011-09-14 15:46:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:46:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:46:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:46:34 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:46:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:46:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:46:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:46:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:46:34 --> Final output sent to browser
DEBUG - 2011-09-14 15:46:34 --> Total execution time: 0.0419
DEBUG - 2011-09-14 15:56:42 --> Config Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:56:42 --> URI Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Router Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Output Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Input Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:56:42 --> Language Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Loader Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Controller Class Initialized
ERROR - 2011-09-14 15:56:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 15:56:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 15:56:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 15:56:42 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:56:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:56:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 15:56:42 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:56:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:56:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:56:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:56:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:56:42 --> Final output sent to browser
DEBUG - 2011-09-14 15:56:42 --> Total execution time: 0.1021
DEBUG - 2011-09-14 15:56:43 --> Config Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:56:43 --> URI Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Router Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Output Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Input Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:56:43 --> Language Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Loader Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Controller Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:56:43 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:56:43 --> Final output sent to browser
DEBUG - 2011-09-14 15:56:43 --> Total execution time: 0.5124
DEBUG - 2011-09-14 15:56:59 --> Config Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 15:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 15:56:59 --> URI Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Router Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Output Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Input Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 15:56:59 --> Language Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Loader Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Controller Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Model Class Initialized
DEBUG - 2011-09-14 15:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 15:56:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 15:57:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 15:57:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 15:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 15:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 15:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 15:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 15:57:00 --> Final output sent to browser
DEBUG - 2011-09-14 15:57:00 --> Total execution time: 0.0547
DEBUG - 2011-09-14 16:23:00 --> Config Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 16:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 16:23:00 --> URI Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Router Class Initialized
DEBUG - 2011-09-14 16:23:00 --> No URI present. Default controller set.
DEBUG - 2011-09-14 16:23:00 --> Output Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Input Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 16:23:00 --> Language Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Loader Class Initialized
DEBUG - 2011-09-14 16:23:00 --> Controller Class Initialized
DEBUG - 2011-09-14 16:23:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 16:23:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 16:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 16:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 16:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 16:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 16:23:00 --> Final output sent to browser
DEBUG - 2011-09-14 16:23:00 --> Total execution time: 0.0576
DEBUG - 2011-09-14 16:24:05 --> Config Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 16:24:05 --> URI Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Router Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Output Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Input Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 16:24:05 --> Language Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Loader Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Controller Class Initialized
ERROR - 2011-09-14 16:24:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 16:24:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 16:24:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 16:24:05 --> Model Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Model Class Initialized
DEBUG - 2011-09-14 16:24:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 16:24:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 16:24:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 16:24:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 16:24:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 16:24:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 16:24:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 16:24:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 16:24:05 --> Final output sent to browser
DEBUG - 2011-09-14 16:24:05 --> Total execution time: 0.0363
DEBUG - 2011-09-14 16:24:11 --> Config Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Hooks Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Utf8 Class Initialized
DEBUG - 2011-09-14 16:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 16:24:11 --> URI Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Router Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Output Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Input Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 16:24:11 --> Language Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Loader Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Controller Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Model Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Model Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 16:24:11 --> Database Driver Class Initialized
DEBUG - 2011-09-14 16:24:11 --> Final output sent to browser
DEBUG - 2011-09-14 16:24:11 --> Total execution time: 0.6075
DEBUG - 2011-09-14 16:39:34 --> Config Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 16:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 16:39:34 --> URI Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Router Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Output Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Input Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 16:39:34 --> Language Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Loader Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Controller Class Initialized
ERROR - 2011-09-14 16:39:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 16:39:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 16:39:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 16:39:34 --> Model Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Model Class Initialized
DEBUG - 2011-09-14 16:39:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 16:39:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 16:39:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 16:39:34 --> Helper loaded: url_helper
DEBUG - 2011-09-14 16:39:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 16:39:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 16:39:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 16:39:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 16:39:34 --> Final output sent to browser
DEBUG - 2011-09-14 16:39:34 --> Total execution time: 0.0330
DEBUG - 2011-09-14 16:39:36 --> Config Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Hooks Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Utf8 Class Initialized
DEBUG - 2011-09-14 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 16:39:36 --> URI Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Router Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Output Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Input Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 16:39:36 --> Language Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Loader Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Controller Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Model Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Model Class Initialized
DEBUG - 2011-09-14 16:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 16:39:36 --> Database Driver Class Initialized
DEBUG - 2011-09-14 16:39:37 --> Final output sent to browser
DEBUG - 2011-09-14 16:39:37 --> Total execution time: 0.6920
DEBUG - 2011-09-14 16:39:39 --> Config Class Initialized
DEBUG - 2011-09-14 16:39:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 16:39:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 16:39:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 16:39:39 --> URI Class Initialized
DEBUG - 2011-09-14 16:39:39 --> Router Class Initialized
ERROR - 2011-09-14 16:39:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:00:20 --> Config Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:00:20 --> URI Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Router Class Initialized
ERROR - 2011-09-14 17:00:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-14 17:00:20 --> Config Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:00:20 --> URI Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Router Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Output Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Input Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:00:20 --> Language Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Loader Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Controller Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Model Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Model Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Model Class Initialized
DEBUG - 2011-09-14 17:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:00:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:00:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 17:00:20 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:00:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:00:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:00:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:00:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:00:20 --> Final output sent to browser
DEBUG - 2011-09-14 17:00:20 --> Total execution time: 0.2144
DEBUG - 2011-09-14 17:30:31 --> Config Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:30:31 --> URI Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Router Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Output Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Input Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:30:31 --> Language Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Loader Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Controller Class Initialized
ERROR - 2011-09-14 17:30:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:30:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:30:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:30:31 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:30:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:30:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:30:31 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:30:31 --> Final output sent to browser
DEBUG - 2011-09-14 17:30:31 --> Total execution time: 0.3397
DEBUG - 2011-09-14 17:30:33 --> Config Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:30:33 --> URI Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Router Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Output Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Input Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:30:33 --> Language Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Loader Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Controller Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:30:33 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:30:33 --> Final output sent to browser
DEBUG - 2011-09-14 17:30:33 --> Total execution time: 0.6116
DEBUG - 2011-09-14 17:30:34 --> Config Class Initialized
DEBUG - 2011-09-14 17:30:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:30:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:30:34 --> URI Class Initialized
DEBUG - 2011-09-14 17:30:34 --> Router Class Initialized
ERROR - 2011-09-14 17:30:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:30:56 --> Config Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:30:56 --> URI Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Router Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Output Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Input Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:30:56 --> Language Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Loader Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Controller Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Model Class Initialized
DEBUG - 2011-09-14 17:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:30:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:30:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 17:30:56 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:30:56 --> Final output sent to browser
DEBUG - 2011-09-14 17:30:56 --> Total execution time: 0.2098
DEBUG - 2011-09-14 17:30:59 --> Config Class Initialized
DEBUG - 2011-09-14 17:30:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:30:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:30:59 --> URI Class Initialized
DEBUG - 2011-09-14 17:30:59 --> Router Class Initialized
ERROR - 2011-09-14 17:30:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:31:05 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:05 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:05 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Controller Class Initialized
ERROR - 2011-09-14 17:31:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:31:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:05 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:31:05 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:05 --> Total execution time: 0.0292
DEBUG - 2011-09-14 17:31:05 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:05 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:05 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Controller Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:06 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:06 --> Total execution time: 0.6166
DEBUG - 2011-09-14 17:31:07 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:07 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:07 --> Router Class Initialized
ERROR - 2011-09-14 17:31:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:31:20 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:20 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:20 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Controller Class Initialized
ERROR - 2011-09-14 17:31:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:31:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:31:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:20 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:20 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:31:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:31:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:31:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:31:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:31:20 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:20 --> Total execution time: 0.0311
DEBUG - 2011-09-14 17:31:21 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:21 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:21 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Controller Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:21 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:21 --> Total execution time: 0.5959
DEBUG - 2011-09-14 17:31:25 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:25 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:25 --> Router Class Initialized
ERROR - 2011-09-14 17:31:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:31:30 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:30 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:30 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Controller Class Initialized
ERROR - 2011-09-14 17:31:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:31:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:30 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:30 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:30 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:31:30 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:30 --> Total execution time: 0.0461
DEBUG - 2011-09-14 17:31:31 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:31 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:31 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Controller Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:32 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:32 --> Total execution time: 0.5796
DEBUG - 2011-09-14 17:31:33 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:33 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:33 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:33 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:33 --> Router Class Initialized
ERROR - 2011-09-14 17:31:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:31:38 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:38 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:38 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Controller Class Initialized
ERROR - 2011-09-14 17:31:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:31:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:38 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:38 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:31:38 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:31:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:31:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:31:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:31:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:31:38 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:38 --> Total execution time: 0.0344
DEBUG - 2011-09-14 17:31:39 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:39 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Router Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Output Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Input Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:31:39 --> Language Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Loader Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Controller Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Model Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:31:39 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:31:39 --> Final output sent to browser
DEBUG - 2011-09-14 17:31:39 --> Total execution time: 0.5308
DEBUG - 2011-09-14 17:31:40 --> Config Class Initialized
DEBUG - 2011-09-14 17:31:40 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:31:40 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:31:40 --> URI Class Initialized
DEBUG - 2011-09-14 17:31:40 --> Router Class Initialized
ERROR - 2011-09-14 17:31:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:32:00 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:00 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:00 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Controller Class Initialized
ERROR - 2011-09-14 17:32:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:00 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:00 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:00 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:32:00 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:00 --> Total execution time: 0.0267
DEBUG - 2011-09-14 17:32:01 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:01 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:01 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Controller Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:01 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:02 --> Total execution time: 0.5334
DEBUG - 2011-09-14 17:32:02 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:02 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:02 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Controller Class Initialized
ERROR - 2011-09-14 17:32:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:32:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:32:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:02 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:02 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:02 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:32:02 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:02 --> Total execution time: 0.0393
DEBUG - 2011-09-14 17:32:02 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:02 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:02 --> Router Class Initialized
ERROR - 2011-09-14 17:32:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:32:31 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:31 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:31 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Controller Class Initialized
ERROR - 2011-09-14 17:32:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:32:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:31 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:31 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:32:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:32:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:32:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:32:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:32:31 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:31 --> Total execution time: 0.0294
DEBUG - 2011-09-14 17:32:32 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:32 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:32 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:32 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:32 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:32 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Controller Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:32 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Controller Class Initialized
ERROR - 2011-09-14 17:32:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:32:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:32:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:32 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:32 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:32 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:32 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:32:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:32:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:32:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:32:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:32:32 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:32 --> Total execution time: 0.0291
DEBUG - 2011-09-14 17:32:33 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:33 --> Total execution time: 0.6089
DEBUG - 2011-09-14 17:32:35 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:35 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:35 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:35 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:35 --> Router Class Initialized
ERROR - 2011-09-14 17:32:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:32:43 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:43 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:43 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Controller Class Initialized
ERROR - 2011-09-14 17:32:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:32:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:32:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:43 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:43 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:43 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:32:43 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:43 --> Total execution time: 0.0386
DEBUG - 2011-09-14 17:32:44 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:44 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:44 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Controller Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:44 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:44 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Router Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Output Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Input Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:32:44 --> Language Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Loader Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Controller Class Initialized
ERROR - 2011-09-14 17:32:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:32:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:44 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Model Class Initialized
DEBUG - 2011-09-14 17:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:32:44 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:32:44 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:32:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:32:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:32:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:32:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:32:44 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:44 --> Total execution time: 0.0379
DEBUG - 2011-09-14 17:32:44 --> Final output sent to browser
DEBUG - 2011-09-14 17:32:44 --> Total execution time: 0.5690
DEBUG - 2011-09-14 17:32:46 --> Config Class Initialized
DEBUG - 2011-09-14 17:32:46 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:32:46 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:32:46 --> URI Class Initialized
DEBUG - 2011-09-14 17:32:46 --> Router Class Initialized
ERROR - 2011-09-14 17:32:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:33:02 --> Config Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:33:02 --> URI Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Router Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Output Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Input Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:33:02 --> Language Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Loader Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Controller Class Initialized
ERROR - 2011-09-14 17:33:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:33:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:33:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:33:02 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:33:02 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:33:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:33:02 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:33:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:33:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:33:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:33:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:33:02 --> Final output sent to browser
DEBUG - 2011-09-14 17:33:02 --> Total execution time: 0.0306
DEBUG - 2011-09-14 17:33:03 --> Config Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:33:03 --> URI Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Router Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Output Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Input Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:33:03 --> Language Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Loader Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Controller Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:33:03 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:33:04 --> Final output sent to browser
DEBUG - 2011-09-14 17:33:04 --> Total execution time: 0.6176
DEBUG - 2011-09-14 17:33:05 --> Config Class Initialized
DEBUG - 2011-09-14 17:33:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:33:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:33:05 --> URI Class Initialized
DEBUG - 2011-09-14 17:33:05 --> Router Class Initialized
ERROR - 2011-09-14 17:33:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 17:33:15 --> Config Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:33:15 --> URI Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Router Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Output Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Input Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:33:15 --> Language Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Loader Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Controller Class Initialized
ERROR - 2011-09-14 17:33:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 17:33:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 17:33:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:33:15 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:33:15 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:33:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 17:33:15 --> Helper loaded: url_helper
DEBUG - 2011-09-14 17:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 17:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 17:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 17:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 17:33:15 --> Final output sent to browser
DEBUG - 2011-09-14 17:33:15 --> Total execution time: 0.0300
DEBUG - 2011-09-14 17:33:16 --> Config Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:33:16 --> URI Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Router Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Output Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Input Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 17:33:16 --> Language Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Loader Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Controller Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Model Class Initialized
DEBUG - 2011-09-14 17:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 17:33:16 --> Database Driver Class Initialized
DEBUG - 2011-09-14 17:33:17 --> Final output sent to browser
DEBUG - 2011-09-14 17:33:17 --> Total execution time: 0.5590
DEBUG - 2011-09-14 17:33:18 --> Config Class Initialized
DEBUG - 2011-09-14 17:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-14 17:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-14 17:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 17:33:18 --> URI Class Initialized
DEBUG - 2011-09-14 17:33:18 --> Router Class Initialized
ERROR - 2011-09-14 17:33:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 18:34:52 --> Config Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:34:52 --> URI Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Router Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Output Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Input Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 18:34:52 --> Language Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Loader Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Controller Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Model Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Model Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Model Class Initialized
DEBUG - 2011-09-14 18:34:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 18:34:52 --> Database Driver Class Initialized
DEBUG - 2011-09-14 18:34:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 18:34:53 --> Helper loaded: url_helper
DEBUG - 2011-09-14 18:34:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 18:34:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 18:34:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 18:34:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 18:34:53 --> Final output sent to browser
DEBUG - 2011-09-14 18:34:53 --> Total execution time: 1.2403
DEBUG - 2011-09-14 18:35:43 --> Config Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:35:43 --> URI Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Router Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Output Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Input Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 18:35:43 --> Language Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Loader Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Controller Class Initialized
ERROR - 2011-09-14 18:35:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 18:35:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 18:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 18:35:43 --> Model Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Model Class Initialized
DEBUG - 2011-09-14 18:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 18:35:43 --> Database Driver Class Initialized
DEBUG - 2011-09-14 18:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 18:35:43 --> Helper loaded: url_helper
DEBUG - 2011-09-14 18:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 18:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 18:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 18:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 18:35:43 --> Final output sent to browser
DEBUG - 2011-09-14 18:35:43 --> Total execution time: 0.0951
DEBUG - 2011-09-14 18:35:44 --> Config Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:35:44 --> URI Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Router Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Output Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Input Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 18:35:44 --> Language Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Loader Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Controller Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Model Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Model Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 18:35:44 --> Database Driver Class Initialized
DEBUG - 2011-09-14 18:35:44 --> Final output sent to browser
DEBUG - 2011-09-14 18:35:44 --> Total execution time: 0.6251
DEBUG - 2011-09-14 18:37:59 --> Config Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:37:59 --> URI Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Router Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Output Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Input Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 18:37:59 --> Language Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Loader Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Controller Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Model Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Model Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Model Class Initialized
DEBUG - 2011-09-14 18:37:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 18:37:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 18:37:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 18:37:59 --> Helper loaded: url_helper
DEBUG - 2011-09-14 18:37:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 18:37:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 18:37:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 18:37:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 18:37:59 --> Final output sent to browser
DEBUG - 2011-09-14 18:37:59 --> Total execution time: 0.0444
DEBUG - 2011-09-14 18:38:07 --> Config Class Initialized
DEBUG - 2011-09-14 18:38:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:38:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:38:07 --> URI Class Initialized
DEBUG - 2011-09-14 18:38:07 --> Router Class Initialized
ERROR - 2011-09-14 18:38:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 18:38:08 --> Config Class Initialized
DEBUG - 2011-09-14 18:38:08 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:38:08 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:38:08 --> URI Class Initialized
DEBUG - 2011-09-14 18:38:08 --> Router Class Initialized
ERROR - 2011-09-14 18:38:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 18:38:08 --> Config Class Initialized
DEBUG - 2011-09-14 18:38:08 --> Hooks Class Initialized
DEBUG - 2011-09-14 18:38:08 --> Utf8 Class Initialized
DEBUG - 2011-09-14 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 18:38:08 --> URI Class Initialized
DEBUG - 2011-09-14 18:38:08 --> Router Class Initialized
ERROR - 2011-09-14 18:38:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 19:01:35 --> Config Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:01:35 --> URI Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Router Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Output Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Input Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:01:35 --> Language Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Loader Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Controller Class Initialized
ERROR - 2011-09-14 19:01:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 19:01:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 19:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:01:35 --> Model Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Model Class Initialized
DEBUG - 2011-09-14 19:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:01:35 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:01:35 --> Helper loaded: url_helper
DEBUG - 2011-09-14 19:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 19:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 19:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 19:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 19:01:35 --> Final output sent to browser
DEBUG - 2011-09-14 19:01:35 --> Total execution time: 0.0505
DEBUG - 2011-09-14 19:13:20 --> Config Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:13:20 --> URI Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Router Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Output Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Input Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:13:20 --> Language Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Loader Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Controller Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:13:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:13:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 19:13:20 --> Helper loaded: url_helper
DEBUG - 2011-09-14 19:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 19:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 19:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 19:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 19:13:20 --> Final output sent to browser
DEBUG - 2011-09-14 19:13:20 --> Total execution time: 0.3011
DEBUG - 2011-09-14 19:13:57 --> Config Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:13:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:13:57 --> URI Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Router Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Output Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Input Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:13:57 --> Language Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Loader Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Controller Class Initialized
ERROR - 2011-09-14 19:13:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 19:13:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 19:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:13:57 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:13:57 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:13:57 --> Helper loaded: url_helper
DEBUG - 2011-09-14 19:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 19:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 19:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 19:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 19:13:57 --> Final output sent to browser
DEBUG - 2011-09-14 19:13:57 --> Total execution time: 0.0332
DEBUG - 2011-09-14 19:13:58 --> Config Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:13:58 --> URI Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Router Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Output Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Input Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:13:58 --> Language Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Loader Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Controller Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Model Class Initialized
DEBUG - 2011-09-14 19:13:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:13:58 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:13:59 --> Final output sent to browser
DEBUG - 2011-09-14 19:13:59 --> Total execution time: 0.5951
DEBUG - 2011-09-14 19:23:37 --> Config Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:23:37 --> URI Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Router Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Output Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Input Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:23:37 --> Language Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Loader Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Controller Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Model Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Model Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Model Class Initialized
DEBUG - 2011-09-14 19:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:23:37 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:23:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 19:23:37 --> Helper loaded: url_helper
DEBUG - 2011-09-14 19:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 19:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 19:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 19:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 19:23:37 --> Final output sent to browser
DEBUG - 2011-09-14 19:23:37 --> Total execution time: 0.0741
DEBUG - 2011-09-14 19:23:40 --> Config Class Initialized
DEBUG - 2011-09-14 19:23:40 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:23:40 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:23:40 --> URI Class Initialized
DEBUG - 2011-09-14 19:23:40 --> Router Class Initialized
ERROR - 2011-09-14 19:23:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 19:23:41 --> Config Class Initialized
DEBUG - 2011-09-14 19:23:41 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:23:41 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:23:41 --> URI Class Initialized
DEBUG - 2011-09-14 19:23:41 --> Router Class Initialized
ERROR - 2011-09-14 19:23:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 19:24:09 --> Config Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:24:09 --> URI Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Router Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Output Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Input Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:24:09 --> Language Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Loader Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Controller Class Initialized
ERROR - 2011-09-14 19:24:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 19:24:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 19:24:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:24:09 --> Model Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Model Class Initialized
DEBUG - 2011-09-14 19:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:24:09 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:24:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:24:09 --> Helper loaded: url_helper
DEBUG - 2011-09-14 19:24:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 19:24:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 19:24:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 19:24:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 19:24:09 --> Final output sent to browser
DEBUG - 2011-09-14 19:24:09 --> Total execution time: 0.0289
DEBUG - 2011-09-14 19:24:11 --> Config Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:24:11 --> URI Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Router Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Output Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Input Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:24:11 --> Language Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Loader Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Controller Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Model Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Model Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:24:11 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:24:11 --> Final output sent to browser
DEBUG - 2011-09-14 19:24:11 --> Total execution time: 0.5173
DEBUG - 2011-09-14 19:25:23 --> Config Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:25:23 --> URI Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Router Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Output Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Input Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:25:23 --> Language Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Loader Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Controller Class Initialized
ERROR - 2011-09-14 19:25:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 19:25:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 19:25:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:25:23 --> Model Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Model Class Initialized
DEBUG - 2011-09-14 19:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:25:23 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:25:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 19:25:23 --> Helper loaded: url_helper
DEBUG - 2011-09-14 19:25:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 19:25:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 19:25:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 19:25:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 19:25:23 --> Final output sent to browser
DEBUG - 2011-09-14 19:25:23 --> Total execution time: 0.0293
DEBUG - 2011-09-14 19:25:24 --> Config Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-14 19:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 19:25:24 --> URI Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Router Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Output Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Input Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 19:25:24 --> Language Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Loader Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Controller Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Model Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Model Class Initialized
DEBUG - 2011-09-14 19:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 19:25:24 --> Database Driver Class Initialized
DEBUG - 2011-09-14 19:25:25 --> Final output sent to browser
DEBUG - 2011-09-14 19:25:25 --> Total execution time: 0.9188
DEBUG - 2011-09-14 20:24:24 --> Config Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Hooks Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Utf8 Class Initialized
DEBUG - 2011-09-14 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 20:24:24 --> URI Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Router Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Output Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Input Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 20:24:24 --> Language Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Loader Class Initialized
DEBUG - 2011-09-14 20:24:24 --> Controller Class Initialized
ERROR - 2011-09-14 20:24:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 20:24:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 20:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 20:24:25 --> Model Class Initialized
DEBUG - 2011-09-14 20:24:25 --> Model Class Initialized
DEBUG - 2011-09-14 20:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 20:24:25 --> Database Driver Class Initialized
DEBUG - 2011-09-14 20:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 20:24:25 --> Helper loaded: url_helper
DEBUG - 2011-09-14 20:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 20:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 20:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 20:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 20:24:25 --> Final output sent to browser
DEBUG - 2011-09-14 20:24:25 --> Total execution time: 0.4549
DEBUG - 2011-09-14 20:24:26 --> Config Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Hooks Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Utf8 Class Initialized
DEBUG - 2011-09-14 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 20:24:26 --> URI Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Router Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Output Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Input Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 20:24:26 --> Language Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Loader Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Controller Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Model Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Model Class Initialized
DEBUG - 2011-09-14 20:24:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 20:24:26 --> Database Driver Class Initialized
DEBUG - 2011-09-14 20:24:27 --> Final output sent to browser
DEBUG - 2011-09-14 20:24:27 --> Total execution time: 0.5786
DEBUG - 2011-09-14 21:50:05 --> Config Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Hooks Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Utf8 Class Initialized
DEBUG - 2011-09-14 21:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 21:50:05 --> URI Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Router Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Output Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Input Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 21:50:05 --> Language Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Loader Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Controller Class Initialized
ERROR - 2011-09-14 21:50:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 21:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 21:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 21:50:05 --> Model Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Model Class Initialized
DEBUG - 2011-09-14 21:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 21:50:05 --> Database Driver Class Initialized
DEBUG - 2011-09-14 21:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 21:50:05 --> Helper loaded: url_helper
DEBUG - 2011-09-14 21:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 21:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 21:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 21:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 21:50:05 --> Final output sent to browser
DEBUG - 2011-09-14 21:50:05 --> Total execution time: 0.3051
DEBUG - 2011-09-14 21:52:14 --> Config Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Hooks Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Utf8 Class Initialized
DEBUG - 2011-09-14 21:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 21:52:14 --> URI Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Router Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Output Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Input Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 21:52:14 --> Language Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Loader Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Controller Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Model Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Model Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Model Class Initialized
DEBUG - 2011-09-14 21:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 21:52:14 --> Database Driver Class Initialized
DEBUG - 2011-09-14 21:52:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 21:52:14 --> Helper loaded: url_helper
DEBUG - 2011-09-14 21:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 21:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 21:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 21:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 21:52:14 --> Final output sent to browser
DEBUG - 2011-09-14 21:52:14 --> Total execution time: 0.7337
DEBUG - 2011-09-14 21:57:01 --> Config Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-14 21:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 21:57:01 --> URI Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Router Class Initialized
DEBUG - 2011-09-14 21:57:01 --> No URI present. Default controller set.
DEBUG - 2011-09-14 21:57:01 --> Output Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Input Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 21:57:01 --> Language Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Loader Class Initialized
DEBUG - 2011-09-14 21:57:01 --> Controller Class Initialized
DEBUG - 2011-09-14 21:57:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 21:57:01 --> Helper loaded: url_helper
DEBUG - 2011-09-14 21:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 21:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 21:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 21:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 21:57:01 --> Final output sent to browser
DEBUG - 2011-09-14 21:57:01 --> Total execution time: 0.0630
DEBUG - 2011-09-14 22:06:34 --> Config Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:06:34 --> URI Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Router Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Output Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Input Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:06:34 --> Language Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Loader Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Controller Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Model Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Model Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Model Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Config Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:06:34 --> URI Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Router Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Output Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Input Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:06:34 --> Language Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Loader Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Controller Class Initialized
ERROR - 2011-09-14 22:06:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 22:06:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:06:34 --> Model Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Model Class Initialized
DEBUG - 2011-09-14 22:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:06:34 --> Helper loaded: url_helper
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 22:06:34 --> Final output sent to browser
DEBUG - 2011-09-14 22:06:34 --> Total execution time: 0.1151
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 22:06:34 --> Helper loaded: url_helper
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 22:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 22:06:34 --> Final output sent to browser
DEBUG - 2011-09-14 22:06:34 --> Total execution time: 0.5498
DEBUG - 2011-09-14 22:38:40 --> Config Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:38:40 --> URI Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Router Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Output Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Input Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:38:40 --> Language Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Loader Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Controller Class Initialized
ERROR - 2011-09-14 22:38:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 22:38:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 22:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:38:40 --> Model Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Model Class Initialized
DEBUG - 2011-09-14 22:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:38:40 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:38:40 --> Helper loaded: url_helper
DEBUG - 2011-09-14 22:38:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 22:38:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 22:38:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 22:38:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 22:38:40 --> Final output sent to browser
DEBUG - 2011-09-14 22:38:40 --> Total execution time: 0.1477
DEBUG - 2011-09-14 22:38:42 --> Config Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:38:42 --> URI Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Router Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Output Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Input Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:38:42 --> Language Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Loader Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Controller Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Model Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Model Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:38:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:38:42 --> Final output sent to browser
DEBUG - 2011-09-14 22:38:42 --> Total execution time: 0.5907
DEBUG - 2011-09-14 22:38:44 --> Config Class Initialized
DEBUG - 2011-09-14 22:38:44 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:38:44 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:38:44 --> URI Class Initialized
DEBUG - 2011-09-14 22:38:44 --> Router Class Initialized
ERROR - 2011-09-14 22:38:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 22:39:20 --> Config Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:39:20 --> URI Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Router Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Output Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Input Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:39:20 --> Language Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Loader Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Controller Class Initialized
ERROR - 2011-09-14 22:39:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 22:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 22:39:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:39:20 --> Model Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Model Class Initialized
DEBUG - 2011-09-14 22:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:39:20 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:39:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:39:20 --> Helper loaded: url_helper
DEBUG - 2011-09-14 22:39:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 22:39:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 22:39:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 22:39:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 22:39:20 --> Final output sent to browser
DEBUG - 2011-09-14 22:39:20 --> Total execution time: 0.0291
DEBUG - 2011-09-14 22:39:21 --> Config Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:39:21 --> URI Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Router Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Output Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Input Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:39:21 --> Language Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Loader Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Controller Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Model Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Model Class Initialized
DEBUG - 2011-09-14 22:39:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:39:21 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:39:22 --> Final output sent to browser
DEBUG - 2011-09-14 22:39:22 --> Total execution time: 0.5335
DEBUG - 2011-09-14 22:39:23 --> Config Class Initialized
DEBUG - 2011-09-14 22:39:23 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:39:23 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:39:23 --> URI Class Initialized
DEBUG - 2011-09-14 22:39:23 --> Router Class Initialized
ERROR - 2011-09-14 22:39:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 22:39:42 --> Config Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Hooks Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Utf8 Class Initialized
DEBUG - 2011-09-14 22:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 22:39:42 --> URI Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Router Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Output Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Input Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 22:39:42 --> Language Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Loader Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Controller Class Initialized
ERROR - 2011-09-14 22:39:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 22:39:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 22:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:39:42 --> Model Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Model Class Initialized
DEBUG - 2011-09-14 22:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 22:39:42 --> Database Driver Class Initialized
DEBUG - 2011-09-14 22:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 22:39:42 --> Helper loaded: url_helper
DEBUG - 2011-09-14 22:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 22:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 22:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 22:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 22:39:42 --> Final output sent to browser
DEBUG - 2011-09-14 22:39:42 --> Total execution time: 0.0281
DEBUG - 2011-09-14 23:11:29 --> Config Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:11:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:11:29 --> URI Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Router Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Output Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Input Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:11:29 --> Language Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Loader Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Controller Class Initialized
ERROR - 2011-09-14 23:11:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:11:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:11:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:11:29 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:11:29 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:11:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:11:29 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:11:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:11:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:11:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:11:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:11:29 --> Final output sent to browser
DEBUG - 2011-09-14 23:11:29 --> Total execution time: 0.4570
DEBUG - 2011-09-14 23:11:31 --> Config Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:11:31 --> URI Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Router Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Output Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Input Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:11:31 --> Language Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Loader Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Controller Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:11:31 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:11:31 --> Final output sent to browser
DEBUG - 2011-09-14 23:11:31 --> Total execution time: 0.6452
DEBUG - 2011-09-14 23:11:49 --> Config Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:11:49 --> URI Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Router Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Output Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Input Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:11:49 --> Language Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Loader Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Controller Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Model Class Initialized
DEBUG - 2011-09-14 23:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:11:49 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:11:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-14 23:11:50 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:11:50 --> Final output sent to browser
DEBUG - 2011-09-14 23:11:50 --> Total execution time: 0.3618
DEBUG - 2011-09-14 23:36:11 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:11 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:11 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Controller Class Initialized
ERROR - 2011-09-14 23:36:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:36:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:11 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:11 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:11 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:36:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:36:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:36:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:36:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:36:11 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:11 --> Total execution time: 0.0340
DEBUG - 2011-09-14 23:36:12 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:12 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:12 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Controller Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:12 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:13 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:13 --> Total execution time: 0.6299
DEBUG - 2011-09-14 23:36:14 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:14 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:14 --> Router Class Initialized
ERROR - 2011-09-14 23:36:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 23:36:15 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:15 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:15 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:15 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:15 --> Router Class Initialized
ERROR - 2011-09-14 23:36:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-14 23:36:37 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:37 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:37 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Controller Class Initialized
ERROR - 2011-09-14 23:36:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:36:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:37 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:37 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:37 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:36:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:36:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:36:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:36:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:36:37 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:37 --> Total execution time: 0.0340
DEBUG - 2011-09-14 23:36:37 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:37 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:37 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Controller Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:37 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:38 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:38 --> Total execution time: 0.6215
DEBUG - 2011-09-14 23:36:56 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:56 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:56 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Controller Class Initialized
ERROR - 2011-09-14 23:36:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:36:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:56 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:56 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:36:56 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:56 --> Total execution time: 0.0677
DEBUG - 2011-09-14 23:36:56 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:56 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:56 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Controller Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:56 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:57 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:57 --> Total execution time: 0.6332
DEBUG - 2011-09-14 23:36:59 --> Config Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:36:59 --> URI Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Router Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Output Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Input Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:36:59 --> Language Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Loader Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Controller Class Initialized
ERROR - 2011-09-14 23:36:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:36:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:36:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:59 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Model Class Initialized
DEBUG - 2011-09-14 23:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:36:59 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:36:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:36:59 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:36:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:36:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:36:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:36:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:36:59 --> Final output sent to browser
DEBUG - 2011-09-14 23:36:59 --> Total execution time: 0.0321
DEBUG - 2011-09-14 23:37:06 --> Config Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:37:06 --> URI Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Router Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Output Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Input Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:37:06 --> Language Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Loader Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Controller Class Initialized
ERROR - 2011-09-14 23:37:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:37:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:37:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:37:06 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:37:06 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:37:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:37:06 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:37:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:37:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:37:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:37:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:37:06 --> Final output sent to browser
DEBUG - 2011-09-14 23:37:06 --> Total execution time: 0.0296
DEBUG - 2011-09-14 23:37:07 --> Config Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:37:07 --> URI Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Router Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Output Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Input Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:37:07 --> Language Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Loader Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Controller Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:37:07 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:37:07 --> Final output sent to browser
DEBUG - 2011-09-14 23:37:07 --> Total execution time: 0.6768
DEBUG - 2011-09-14 23:37:13 --> Config Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:37:13 --> URI Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Router Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Output Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Input Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:37:13 --> Language Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Loader Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Controller Class Initialized
ERROR - 2011-09-14 23:37:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:37:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:37:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:37:13 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:37:13 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:37:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:37:13 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:37:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:37:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:37:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:37:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:37:13 --> Final output sent to browser
DEBUG - 2011-09-14 23:37:13 --> Total execution time: 0.0309
DEBUG - 2011-09-14 23:37:14 --> Config Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:37:14 --> URI Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Router Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Output Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Input Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:37:14 --> Language Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Loader Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Controller Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:37:14 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:37:14 --> Final output sent to browser
DEBUG - 2011-09-14 23:37:14 --> Total execution time: 0.6683
DEBUG - 2011-09-14 23:37:25 --> Config Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:37:25 --> URI Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Router Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Output Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Input Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:37:25 --> Language Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Loader Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Controller Class Initialized
ERROR - 2011-09-14 23:37:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-14 23:37:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-14 23:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:37:25 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:37:25 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-14 23:37:25 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:37:25 --> Final output sent to browser
DEBUG - 2011-09-14 23:37:25 --> Total execution time: 0.0266
DEBUG - 2011-09-14 23:37:25 --> Config Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:37:25 --> URI Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Router Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Output Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Input Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:37:25 --> Language Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Loader Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Controller Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Model Class Initialized
DEBUG - 2011-09-14 23:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-14 23:37:25 --> Database Driver Class Initialized
DEBUG - 2011-09-14 23:37:26 --> Final output sent to browser
DEBUG - 2011-09-14 23:37:26 --> Total execution time: 0.5742
DEBUG - 2011-09-14 23:53:51 --> Config Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Hooks Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Utf8 Class Initialized
DEBUG - 2011-09-14 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-14 23:53:51 --> URI Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Router Class Initialized
DEBUG - 2011-09-14 23:53:51 --> No URI present. Default controller set.
DEBUG - 2011-09-14 23:53:51 --> Output Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Input Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-14 23:53:51 --> Language Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Loader Class Initialized
DEBUG - 2011-09-14 23:53:51 --> Controller Class Initialized
DEBUG - 2011-09-14 23:53:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-14 23:53:51 --> Helper loaded: url_helper
DEBUG - 2011-09-14 23:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-14 23:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-14 23:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-14 23:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-14 23:53:51 --> Final output sent to browser
DEBUG - 2011-09-14 23:53:51 --> Total execution time: 0.0444

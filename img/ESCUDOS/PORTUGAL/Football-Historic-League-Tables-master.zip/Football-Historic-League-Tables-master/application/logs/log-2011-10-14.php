<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-14 00:01:10 --> Config Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Hooks Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Utf8 Class Initialized
DEBUG - 2011-10-14 00:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 00:01:10 --> URI Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Router Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Output Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Input Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 00:01:10 --> Language Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Loader Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Controller Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Model Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Model Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Model Class Initialized
DEBUG - 2011-10-14 00:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 00:01:10 --> Database Driver Class Initialized
DEBUG - 2011-10-14 00:01:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 00:01:11 --> Helper loaded: url_helper
DEBUG - 2011-10-14 00:01:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 00:01:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 00:01:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 00:01:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 00:01:11 --> Final output sent to browser
DEBUG - 2011-10-14 00:01:11 --> Total execution time: 1.5182
DEBUG - 2011-10-14 00:05:01 --> Config Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Hooks Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Utf8 Class Initialized
DEBUG - 2011-10-14 00:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 00:05:01 --> URI Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Router Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Output Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Input Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 00:05:01 --> Language Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Loader Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Controller Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Model Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Model Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Model Class Initialized
DEBUG - 2011-10-14 00:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 00:05:01 --> Database Driver Class Initialized
DEBUG - 2011-10-14 00:05:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 00:05:01 --> Helper loaded: url_helper
DEBUG - 2011-10-14 00:05:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 00:05:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 00:05:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 00:05:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 00:05:01 --> Final output sent to browser
DEBUG - 2011-10-14 00:05:01 --> Total execution time: 0.1761
DEBUG - 2011-10-14 01:27:06 --> Config Class Initialized
DEBUG - 2011-10-14 01:27:06 --> Hooks Class Initialized
DEBUG - 2011-10-14 01:27:06 --> Utf8 Class Initialized
DEBUG - 2011-10-14 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 01:27:06 --> URI Class Initialized
DEBUG - 2011-10-14 01:27:06 --> Router Class Initialized
ERROR - 2011-10-14 01:27:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 01:32:08 --> Config Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Hooks Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Utf8 Class Initialized
DEBUG - 2011-10-14 01:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 01:32:08 --> URI Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Router Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Output Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Input Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 01:32:08 --> Language Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Loader Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Controller Class Initialized
ERROR - 2011-10-14 01:32:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 01:32:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 01:32:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 01:32:08 --> Model Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Model Class Initialized
DEBUG - 2011-10-14 01:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 01:32:08 --> Database Driver Class Initialized
DEBUG - 2011-10-14 01:32:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 01:32:08 --> Helper loaded: url_helper
DEBUG - 2011-10-14 01:32:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 01:32:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 01:32:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 01:32:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 01:32:08 --> Final output sent to browser
DEBUG - 2011-10-14 01:32:08 --> Total execution time: 0.3670
DEBUG - 2011-10-14 03:04:48 --> Config Class Initialized
DEBUG - 2011-10-14 03:04:48 --> Hooks Class Initialized
DEBUG - 2011-10-14 03:04:48 --> Utf8 Class Initialized
DEBUG - 2011-10-14 03:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 03:04:48 --> URI Class Initialized
DEBUG - 2011-10-14 03:04:48 --> Router Class Initialized
ERROR - 2011-10-14 03:04:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 03:04:49 --> Config Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Hooks Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Utf8 Class Initialized
DEBUG - 2011-10-14 03:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 03:04:49 --> URI Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Router Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Output Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Input Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 03:04:49 --> Language Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Loader Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Controller Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Model Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Model Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Model Class Initialized
DEBUG - 2011-10-14 03:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 03:04:49 --> Database Driver Class Initialized
DEBUG - 2011-10-14 03:04:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 03:04:51 --> Helper loaded: url_helper
DEBUG - 2011-10-14 03:04:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 03:04:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 03:04:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 03:04:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 03:04:51 --> Final output sent to browser
DEBUG - 2011-10-14 03:04:51 --> Total execution time: 1.6483
DEBUG - 2011-10-14 03:04:52 --> Config Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Hooks Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Utf8 Class Initialized
DEBUG - 2011-10-14 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 03:04:52 --> URI Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Router Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Output Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Input Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 03:04:52 --> Language Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Loader Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Controller Class Initialized
ERROR - 2011-10-14 03:04:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 03:04:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 03:04:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 03:04:52 --> Model Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Model Class Initialized
DEBUG - 2011-10-14 03:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 03:04:52 --> Database Driver Class Initialized
DEBUG - 2011-10-14 03:04:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 03:04:52 --> Helper loaded: url_helper
DEBUG - 2011-10-14 03:04:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 03:04:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 03:04:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 03:04:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 03:04:52 --> Final output sent to browser
DEBUG - 2011-10-14 03:04:52 --> Total execution time: 0.1135
DEBUG - 2011-10-14 03:59:32 --> Config Class Initialized
DEBUG - 2011-10-14 03:59:32 --> Hooks Class Initialized
DEBUG - 2011-10-14 03:59:32 --> Utf8 Class Initialized
DEBUG - 2011-10-14 03:59:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 03:59:32 --> URI Class Initialized
DEBUG - 2011-10-14 03:59:32 --> Router Class Initialized
ERROR - 2011-10-14 03:59:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 05:01:49 --> Config Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Hooks Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Utf8 Class Initialized
DEBUG - 2011-10-14 05:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 05:01:49 --> URI Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Router Class Initialized
DEBUG - 2011-10-14 05:01:49 --> No URI present. Default controller set.
DEBUG - 2011-10-14 05:01:49 --> Output Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Input Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 05:01:49 --> Language Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Loader Class Initialized
DEBUG - 2011-10-14 05:01:49 --> Controller Class Initialized
DEBUG - 2011-10-14 05:01:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-14 05:01:49 --> Helper loaded: url_helper
DEBUG - 2011-10-14 05:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 05:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 05:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 05:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 05:01:49 --> Final output sent to browser
DEBUG - 2011-10-14 05:01:49 --> Total execution time: 0.1751
DEBUG - 2011-10-14 06:19:52 --> Config Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Hooks Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Utf8 Class Initialized
DEBUG - 2011-10-14 06:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 06:19:52 --> URI Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Router Class Initialized
DEBUG - 2011-10-14 06:19:52 --> No URI present. Default controller set.
DEBUG - 2011-10-14 06:19:52 --> Output Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Input Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 06:19:52 --> Language Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Loader Class Initialized
DEBUG - 2011-10-14 06:19:52 --> Controller Class Initialized
DEBUG - 2011-10-14 06:19:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-14 06:19:52 --> Helper loaded: url_helper
DEBUG - 2011-10-14 06:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 06:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 06:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 06:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 06:19:52 --> Final output sent to browser
DEBUG - 2011-10-14 06:19:52 --> Total execution time: 0.1917
DEBUG - 2011-10-14 06:30:14 --> Config Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Hooks Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Utf8 Class Initialized
DEBUG - 2011-10-14 06:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 06:30:14 --> URI Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Router Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Output Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Input Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 06:30:14 --> Language Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Loader Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Controller Class Initialized
ERROR - 2011-10-14 06:30:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 06:30:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 06:30:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 06:30:14 --> Model Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Model Class Initialized
DEBUG - 2011-10-14 06:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 06:30:14 --> Database Driver Class Initialized
DEBUG - 2011-10-14 06:30:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 06:30:15 --> Helper loaded: url_helper
DEBUG - 2011-10-14 06:30:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 06:30:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 06:30:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 06:30:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 06:30:15 --> Final output sent to browser
DEBUG - 2011-10-14 06:30:15 --> Total execution time: 0.5309
DEBUG - 2011-10-14 06:32:22 --> Config Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Hooks Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Utf8 Class Initialized
DEBUG - 2011-10-14 06:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 06:32:22 --> URI Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Router Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Output Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Input Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 06:32:22 --> Language Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Loader Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Controller Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Model Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Model Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Model Class Initialized
DEBUG - 2011-10-14 06:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 06:32:22 --> Database Driver Class Initialized
DEBUG - 2011-10-14 06:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 06:32:23 --> Helper loaded: url_helper
DEBUG - 2011-10-14 06:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 06:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 06:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 06:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 06:32:23 --> Final output sent to browser
DEBUG - 2011-10-14 06:32:23 --> Total execution time: 0.7396
DEBUG - 2011-10-14 09:50:25 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:25 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:25 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:25 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:25 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:25 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:25 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:25 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Controller Class Initialized
ERROR - 2011-10-14 09:50:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:50:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:50:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:26 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:26 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:26 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:50:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:50:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:50:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:50:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:50:26 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:26 --> Total execution time: 0.3238
DEBUG - 2011-10-14 09:50:26 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:26 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:26 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Controller Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:26 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:27 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:27 --> Total execution time: 0.5875
DEBUG - 2011-10-14 09:50:28 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:28 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:28 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:28 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:28 --> Router Class Initialized
ERROR - 2011-10-14 09:50:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 09:50:29 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:29 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:29 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:29 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:29 --> Router Class Initialized
ERROR - 2011-10-14 09:50:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 09:50:29 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:29 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:29 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:29 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:29 --> Router Class Initialized
ERROR - 2011-10-14 09:50:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 09:50:45 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:45 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:45 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Controller Class Initialized
ERROR - 2011-10-14 09:50:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:45 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:45 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:45 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:50:45 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:45 --> Total execution time: 0.0330
DEBUG - 2011-10-14 09:50:45 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:45 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:45 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Controller Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:45 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:46 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:46 --> Total execution time: 0.5968
DEBUG - 2011-10-14 09:50:57 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:57 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:57 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Controller Class Initialized
ERROR - 2011-10-14 09:50:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:50:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:57 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:57 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:57 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:50:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:50:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:50:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:50:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:50:57 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:57 --> Total execution time: 0.0318
DEBUG - 2011-10-14 09:50:57 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:57 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:57 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Controller Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:57 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:58 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:58 --> Total execution time: 0.6611
DEBUG - 2011-10-14 09:50:58 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:58 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:58 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:58 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:58 --> Router Class Initialized
ERROR - 2011-10-14 09:50:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 09:50:59 --> Config Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:50:59 --> URI Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Router Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Output Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Input Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:50:59 --> Language Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Loader Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Controller Class Initialized
ERROR - 2011-10-14 09:50:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:50:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:50:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:59 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Model Class Initialized
DEBUG - 2011-10-14 09:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:50:59 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:50:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:50:59 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:50:59 --> Final output sent to browser
DEBUG - 2011-10-14 09:50:59 --> Total execution time: 0.0318
DEBUG - 2011-10-14 09:51:07 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:07 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:07 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Controller Class Initialized
ERROR - 2011-10-14 09:51:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:07 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:07 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:07 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:51:07 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:07 --> Total execution time: 0.0306
DEBUG - 2011-10-14 09:51:07 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:07 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:07 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Controller Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:07 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:08 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:08 --> Total execution time: 0.6001
DEBUG - 2011-10-14 09:51:12 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:12 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:12 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:13 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:13 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Controller Class Initialized
ERROR - 2011-10-14 09:51:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:51:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:51:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:13 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:13 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:13 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:51:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:51:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:51:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:51:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:51:13 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:13 --> Total execution time: 0.0690
DEBUG - 2011-10-14 09:51:13 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:13 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:13 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Controller Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:13 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:14 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:14 --> Total execution time: 0.5858
DEBUG - 2011-10-14 09:51:18 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:18 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:18 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Controller Class Initialized
ERROR - 2011-10-14 09:51:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:51:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:51:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:18 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:18 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:18 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:51:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:51:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:51:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:51:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:51:18 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:18 --> Total execution time: 0.0422
DEBUG - 2011-10-14 09:51:18 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:18 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:18 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Controller Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:18 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:19 --> Total execution time: 0.6465
DEBUG - 2011-10-14 09:51:19 --> Config Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Hooks Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Utf8 Class Initialized
DEBUG - 2011-10-14 09:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 09:51:19 --> URI Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Router Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Output Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Input Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 09:51:19 --> Language Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Loader Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Controller Class Initialized
ERROR - 2011-10-14 09:51:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 09:51:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 09:51:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:19 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Model Class Initialized
DEBUG - 2011-10-14 09:51:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 09:51:19 --> Database Driver Class Initialized
DEBUG - 2011-10-14 09:51:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 09:51:19 --> Helper loaded: url_helper
DEBUG - 2011-10-14 09:51:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 09:51:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 09:51:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 09:51:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 09:51:19 --> Final output sent to browser
DEBUG - 2011-10-14 09:51:19 --> Total execution time: 0.0754
DEBUG - 2011-10-14 11:02:02 --> Config Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Hooks Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Utf8 Class Initialized
DEBUG - 2011-10-14 11:02:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 11:02:02 --> URI Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Router Class Initialized
ERROR - 2011-10-14 11:02:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 11:02:02 --> Config Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Hooks Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Utf8 Class Initialized
DEBUG - 2011-10-14 11:02:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 11:02:02 --> URI Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Router Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Output Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Input Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 11:02:02 --> Language Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Loader Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Controller Class Initialized
ERROR - 2011-10-14 11:02:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 11:02:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 11:02:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 11:02:02 --> Model Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Model Class Initialized
DEBUG - 2011-10-14 11:02:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 11:02:02 --> Database Driver Class Initialized
DEBUG - 2011-10-14 11:02:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 11:02:02 --> Helper loaded: url_helper
DEBUG - 2011-10-14 11:02:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 11:02:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 11:02:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 11:02:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 11:02:02 --> Final output sent to browser
DEBUG - 2011-10-14 11:02:02 --> Total execution time: 0.0545
DEBUG - 2011-10-14 12:16:32 --> Config Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Hooks Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Utf8 Class Initialized
DEBUG - 2011-10-14 12:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 12:16:32 --> URI Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Router Class Initialized
DEBUG - 2011-10-14 12:16:32 --> No URI present. Default controller set.
DEBUG - 2011-10-14 12:16:32 --> Output Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Input Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 12:16:32 --> Language Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Loader Class Initialized
DEBUG - 2011-10-14 12:16:32 --> Controller Class Initialized
DEBUG - 2011-10-14 12:16:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-14 12:16:32 --> Helper loaded: url_helper
DEBUG - 2011-10-14 12:16:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 12:16:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 12:16:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 12:16:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 12:16:32 --> Final output sent to browser
DEBUG - 2011-10-14 12:16:32 --> Total execution time: 0.1125
DEBUG - 2011-10-14 12:37:43 --> Config Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Hooks Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Utf8 Class Initialized
DEBUG - 2011-10-14 12:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 12:37:43 --> URI Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Router Class Initialized
DEBUG - 2011-10-14 12:37:43 --> No URI present. Default controller set.
DEBUG - 2011-10-14 12:37:43 --> Output Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Input Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 12:37:43 --> Language Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Loader Class Initialized
DEBUG - 2011-10-14 12:37:43 --> Controller Class Initialized
DEBUG - 2011-10-14 12:37:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-14 12:37:43 --> Helper loaded: url_helper
DEBUG - 2011-10-14 12:37:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 12:37:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 12:37:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 12:37:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 12:37:43 --> Final output sent to browser
DEBUG - 2011-10-14 12:37:43 --> Total execution time: 0.0379
DEBUG - 2011-10-14 16:38:51 --> Config Class Initialized
DEBUG - 2011-10-14 16:38:51 --> Hooks Class Initialized
DEBUG - 2011-10-14 16:38:51 --> Utf8 Class Initialized
DEBUG - 2011-10-14 16:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 16:38:51 --> URI Class Initialized
DEBUG - 2011-10-14 16:38:51 --> Router Class Initialized
ERROR - 2011-10-14 16:38:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 16:38:52 --> Config Class Initialized
DEBUG - 2011-10-14 16:38:52 --> Hooks Class Initialized
DEBUG - 2011-10-14 16:38:52 --> Utf8 Class Initialized
DEBUG - 2011-10-14 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 16:38:52 --> URI Class Initialized
DEBUG - 2011-10-14 16:38:52 --> Router Class Initialized
DEBUG - 2011-10-14 16:38:52 --> Output Class Initialized
DEBUG - 2011-10-14 16:38:54 --> Input Class Initialized
DEBUG - 2011-10-14 16:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 16:38:54 --> Language Class Initialized
DEBUG - 2011-10-14 16:38:54 --> Loader Class Initialized
DEBUG - 2011-10-14 16:38:54 --> Controller Class Initialized
DEBUG - 2011-10-14 16:38:55 --> Model Class Initialized
DEBUG - 2011-10-14 16:38:55 --> Model Class Initialized
DEBUG - 2011-10-14 16:38:56 --> Model Class Initialized
DEBUG - 2011-10-14 16:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 16:38:57 --> Database Driver Class Initialized
DEBUG - 2011-10-14 16:38:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 16:38:58 --> Helper loaded: url_helper
DEBUG - 2011-10-14 16:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 16:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 16:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 16:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 16:38:58 --> Final output sent to browser
DEBUG - 2011-10-14 16:38:58 --> Total execution time: 5.8696
DEBUG - 2011-10-14 16:39:00 --> Config Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Hooks Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Utf8 Class Initialized
DEBUG - 2011-10-14 16:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 16:39:00 --> URI Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Router Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Output Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Input Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 16:39:00 --> Language Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Loader Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Controller Class Initialized
ERROR - 2011-10-14 16:39:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 16:39:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 16:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 16:39:00 --> Model Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Model Class Initialized
DEBUG - 2011-10-14 16:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 16:39:00 --> Database Driver Class Initialized
DEBUG - 2011-10-14 16:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 16:39:00 --> Helper loaded: url_helper
DEBUG - 2011-10-14 16:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 16:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 16:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 16:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 16:39:00 --> Final output sent to browser
DEBUG - 2011-10-14 16:39:00 --> Total execution time: 0.2045
DEBUG - 2011-10-14 16:56:18 --> Config Class Initialized
DEBUG - 2011-10-14 16:56:18 --> Hooks Class Initialized
DEBUG - 2011-10-14 16:56:18 --> Utf8 Class Initialized
DEBUG - 2011-10-14 16:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 16:56:18 --> URI Class Initialized
DEBUG - 2011-10-14 16:56:18 --> Router Class Initialized
ERROR - 2011-10-14 16:56:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-14 16:56:19 --> Config Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Hooks Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Utf8 Class Initialized
DEBUG - 2011-10-14 16:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 16:56:19 --> URI Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Router Class Initialized
DEBUG - 2011-10-14 16:56:19 --> No URI present. Default controller set.
DEBUG - 2011-10-14 16:56:19 --> Output Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Input Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 16:56:19 --> Language Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Loader Class Initialized
DEBUG - 2011-10-14 16:56:19 --> Controller Class Initialized
DEBUG - 2011-10-14 16:56:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-14 16:56:19 --> Helper loaded: url_helper
DEBUG - 2011-10-14 16:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 16:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 16:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 16:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 16:56:19 --> Final output sent to browser
DEBUG - 2011-10-14 16:56:19 --> Total execution time: 0.0552
DEBUG - 2011-10-14 16:56:20 --> Config Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Hooks Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Utf8 Class Initialized
DEBUG - 2011-10-14 16:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 16:56:20 --> URI Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Router Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Output Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Input Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 16:56:20 --> Language Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Loader Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Controller Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Model Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Model Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Model Class Initialized
DEBUG - 2011-10-14 16:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 16:56:20 --> Database Driver Class Initialized
DEBUG - 2011-10-14 16:56:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 16:56:20 --> Helper loaded: url_helper
DEBUG - 2011-10-14 16:56:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 16:56:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 16:56:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 16:56:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 16:56:20 --> Final output sent to browser
DEBUG - 2011-10-14 16:56:20 --> Total execution time: 0.0676
DEBUG - 2011-10-14 17:04:49 --> Config Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:04:49 --> URI Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Router Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Output Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Input Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:04:49 --> Language Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Loader Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Controller Class Initialized
ERROR - 2011-10-14 17:04:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 17:04:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 17:04:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:04:49 --> Model Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Model Class Initialized
DEBUG - 2011-10-14 17:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:04:49 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:04:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:04:49 --> Helper loaded: url_helper
DEBUG - 2011-10-14 17:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 17:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 17:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 17:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 17:04:49 --> Final output sent to browser
DEBUG - 2011-10-14 17:04:49 --> Total execution time: 0.0302
DEBUG - 2011-10-14 17:04:50 --> Config Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:04:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:04:50 --> URI Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Router Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Output Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Input Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:04:50 --> Language Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Loader Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Controller Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Model Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Model Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:04:50 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:04:50 --> Final output sent to browser
DEBUG - 2011-10-14 17:04:50 --> Total execution time: 0.5260
DEBUG - 2011-10-14 17:04:53 --> Config Class Initialized
DEBUG - 2011-10-14 17:04:53 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:04:53 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:04:53 --> URI Class Initialized
DEBUG - 2011-10-14 17:04:53 --> Router Class Initialized
ERROR - 2011-10-14 17:04:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 17:04:56 --> Config Class Initialized
DEBUG - 2011-10-14 17:04:56 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:04:56 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:04:56 --> URI Class Initialized
DEBUG - 2011-10-14 17:04:56 --> Router Class Initialized
ERROR - 2011-10-14 17:04:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 17:05:38 --> Config Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:05:38 --> URI Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Router Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Output Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Input Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:05:38 --> Language Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Loader Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Controller Class Initialized
ERROR - 2011-10-14 17:05:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 17:05:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 17:05:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:05:38 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:05:38 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:05:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:05:38 --> Helper loaded: url_helper
DEBUG - 2011-10-14 17:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 17:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 17:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 17:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 17:05:38 --> Final output sent to browser
DEBUG - 2011-10-14 17:05:38 --> Total execution time: 0.0310
DEBUG - 2011-10-14 17:05:39 --> Config Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:05:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:05:39 --> URI Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Router Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Output Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Input Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:05:39 --> Language Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Loader Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Controller Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:05:39 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Final output sent to browser
DEBUG - 2011-10-14 17:05:40 --> Total execution time: 0.9070
DEBUG - 2011-10-14 17:05:40 --> Config Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:05:40 --> URI Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Router Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Output Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Input Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:05:40 --> Language Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Loader Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Controller Class Initialized
ERROR - 2011-10-14 17:05:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 17:05:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 17:05:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:05:40 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:05:40 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:05:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:05:40 --> Helper loaded: url_helper
DEBUG - 2011-10-14 17:05:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 17:05:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 17:05:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 17:05:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 17:05:40 --> Final output sent to browser
DEBUG - 2011-10-14 17:05:40 --> Total execution time: 0.0355
DEBUG - 2011-10-14 17:05:55 --> Config Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:05:55 --> URI Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Router Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Output Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Input Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:05:55 --> Language Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Loader Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Controller Class Initialized
ERROR - 2011-10-14 17:05:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 17:05:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 17:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:05:55 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:05:55 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 17:05:55 --> Helper loaded: url_helper
DEBUG - 2011-10-14 17:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 17:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 17:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 17:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 17:05:55 --> Final output sent to browser
DEBUG - 2011-10-14 17:05:55 --> Total execution time: 0.0458
DEBUG - 2011-10-14 17:05:56 --> Config Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Hooks Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Utf8 Class Initialized
DEBUG - 2011-10-14 17:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 17:05:56 --> URI Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Router Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Output Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Input Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 17:05:56 --> Language Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Loader Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Controller Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Model Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 17:05:56 --> Database Driver Class Initialized
DEBUG - 2011-10-14 17:05:56 --> Final output sent to browser
DEBUG - 2011-10-14 17:05:56 --> Total execution time: 0.5049
DEBUG - 2011-10-14 18:19:07 --> Config Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Hooks Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Utf8 Class Initialized
DEBUG - 2011-10-14 18:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 18:19:07 --> URI Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Router Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Output Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Input Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 18:19:07 --> Language Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Loader Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Controller Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Model Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Model Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Model Class Initialized
DEBUG - 2011-10-14 18:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 18:19:07 --> Database Driver Class Initialized
DEBUG - 2011-10-14 18:19:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 18:19:08 --> Helper loaded: url_helper
DEBUG - 2011-10-14 18:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 18:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 18:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 18:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 18:19:08 --> Final output sent to browser
DEBUG - 2011-10-14 18:19:08 --> Total execution time: 0.9280
DEBUG - 2011-10-14 18:41:55 --> Config Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Hooks Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Utf8 Class Initialized
DEBUG - 2011-10-14 18:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 18:41:55 --> URI Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Router Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Output Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Input Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 18:41:55 --> Language Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Loader Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Controller Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 18:41:55 --> Database Driver Class Initialized
DEBUG - 2011-10-14 18:41:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-14 18:41:56 --> Helper loaded: url_helper
DEBUG - 2011-10-14 18:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 18:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 18:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 18:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 18:41:56 --> Final output sent to browser
DEBUG - 2011-10-14 18:41:56 --> Total execution time: 0.2288
DEBUG - 2011-10-14 18:41:57 --> Config Class Initialized
DEBUG - 2011-10-14 18:41:57 --> Hooks Class Initialized
DEBUG - 2011-10-14 18:41:57 --> Utf8 Class Initialized
DEBUG - 2011-10-14 18:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 18:41:57 --> URI Class Initialized
DEBUG - 2011-10-14 18:41:57 --> Router Class Initialized
ERROR - 2011-10-14 18:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 18:41:58 --> Config Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Hooks Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Utf8 Class Initialized
DEBUG - 2011-10-14 18:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 18:41:58 --> URI Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Router Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Output Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Input Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 18:41:58 --> Language Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Loader Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Controller Class Initialized
ERROR - 2011-10-14 18:41:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-14 18:41:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-14 18:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 18:41:58 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 18:41:58 --> Database Driver Class Initialized
DEBUG - 2011-10-14 18:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-14 18:41:58 --> Helper loaded: url_helper
DEBUG - 2011-10-14 18:41:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 18:41:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 18:41:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 18:41:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 18:41:58 --> Final output sent to browser
DEBUG - 2011-10-14 18:41:58 --> Total execution time: 0.0436
DEBUG - 2011-10-14 18:41:58 --> Config Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Hooks Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Utf8 Class Initialized
DEBUG - 2011-10-14 18:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 18:41:58 --> URI Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Router Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Output Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Input Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 18:41:58 --> Language Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Loader Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Controller Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Model Class Initialized
DEBUG - 2011-10-14 18:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-14 18:41:58 --> Database Driver Class Initialized
DEBUG - 2011-10-14 18:41:59 --> Final output sent to browser
DEBUG - 2011-10-14 18:41:59 --> Total execution time: 0.7143
DEBUG - 2011-10-14 18:41:59 --> Config Class Initialized
DEBUG - 2011-10-14 18:41:59 --> Hooks Class Initialized
DEBUG - 2011-10-14 18:41:59 --> Utf8 Class Initialized
DEBUG - 2011-10-14 18:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 18:41:59 --> URI Class Initialized
DEBUG - 2011-10-14 18:41:59 --> Router Class Initialized
ERROR - 2011-10-14 18:41:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-14 19:39:01 --> Config Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Hooks Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Utf8 Class Initialized
DEBUG - 2011-10-14 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 19:39:01 --> URI Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Router Class Initialized
DEBUG - 2011-10-14 19:39:01 --> No URI present. Default controller set.
DEBUG - 2011-10-14 19:39:01 --> Output Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Input Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-14 19:39:01 --> Language Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Loader Class Initialized
DEBUG - 2011-10-14 19:39:01 --> Controller Class Initialized
DEBUG - 2011-10-14 19:39:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-14 19:39:01 --> Helper loaded: url_helper
DEBUG - 2011-10-14 19:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-14 19:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-14 19:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-14 19:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-14 19:39:01 --> Final output sent to browser
DEBUG - 2011-10-14 19:39:01 --> Total execution time: 0.0673
DEBUG - 2011-10-14 23:14:19 --> Config Class Initialized
DEBUG - 2011-10-14 23:14:19 --> Hooks Class Initialized
DEBUG - 2011-10-14 23:14:19 --> Utf8 Class Initialized
DEBUG - 2011-10-14 23:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-14 23:14:19 --> URI Class Initialized
DEBUG - 2011-10-14 23:14:19 --> Router Class Initialized
ERROR - 2011-10-14 23:14:19 --> 404 Page Not Found --> robots.txt

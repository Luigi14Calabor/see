<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-09 00:08:52 --> Config Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Hooks Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Utf8 Class Initialized
DEBUG - 2011-09-09 00:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 00:08:52 --> URI Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Router Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Output Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Input Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 00:08:52 --> Language Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Loader Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Controller Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Model Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Model Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Model Class Initialized
DEBUG - 2011-09-09 00:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 00:08:52 --> Database Driver Class Initialized
DEBUG - 2011-09-09 00:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 00:08:53 --> Helper loaded: url_helper
DEBUG - 2011-09-09 00:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 00:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 00:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 00:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 00:08:53 --> Final output sent to browser
DEBUG - 2011-09-09 00:08:53 --> Total execution time: 0.3400
DEBUG - 2011-09-09 00:08:55 --> Config Class Initialized
DEBUG - 2011-09-09 00:08:55 --> Hooks Class Initialized
DEBUG - 2011-09-09 00:08:55 --> Utf8 Class Initialized
DEBUG - 2011-09-09 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 00:08:55 --> URI Class Initialized
DEBUG - 2011-09-09 00:08:55 --> Router Class Initialized
ERROR - 2011-09-09 00:08:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 00:40:31 --> Config Class Initialized
DEBUG - 2011-09-09 00:40:31 --> Hooks Class Initialized
DEBUG - 2011-09-09 00:40:31 --> Utf8 Class Initialized
DEBUG - 2011-09-09 00:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 00:40:31 --> URI Class Initialized
DEBUG - 2011-09-09 00:40:31 --> Router Class Initialized
DEBUG - 2011-09-09 00:40:31 --> No URI present. Default controller set.
DEBUG - 2011-09-09 00:40:32 --> Output Class Initialized
DEBUG - 2011-09-09 00:40:32 --> Input Class Initialized
DEBUG - 2011-09-09 00:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 00:40:32 --> Language Class Initialized
DEBUG - 2011-09-09 00:40:32 --> Loader Class Initialized
DEBUG - 2011-09-09 00:40:32 --> Controller Class Initialized
DEBUG - 2011-09-09 00:40:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 00:40:32 --> Helper loaded: url_helper
DEBUG - 2011-09-09 00:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 00:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 00:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 00:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 00:40:32 --> Final output sent to browser
DEBUG - 2011-09-09 00:40:32 --> Total execution time: 0.1492
DEBUG - 2011-09-09 02:28:25 --> Config Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:28:25 --> URI Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Router Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Output Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Input Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:28:25 --> Language Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Loader Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Controller Class Initialized
ERROR - 2011-09-09 02:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 02:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 02:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 02:28:25 --> Model Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Model Class Initialized
DEBUG - 2011-09-09 02:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:28:25 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 02:28:26 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:28:26 --> Final output sent to browser
DEBUG - 2011-09-09 02:28:26 --> Total execution time: 1.1459
DEBUG - 2011-09-09 02:28:28 --> Config Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:28:28 --> URI Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Router Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Output Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Input Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:28:28 --> Language Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Loader Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Controller Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Model Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Model Class Initialized
DEBUG - 2011-09-09 02:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:28:28 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:28:31 --> Final output sent to browser
DEBUG - 2011-09-09 02:28:31 --> Total execution time: 3.2038
DEBUG - 2011-09-09 02:28:33 --> Config Class Initialized
DEBUG - 2011-09-09 02:28:33 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:28:33 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:28:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:28:33 --> URI Class Initialized
DEBUG - 2011-09-09 02:28:33 --> Router Class Initialized
ERROR - 2011-09-09 02:28:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 02:57:54 --> Config Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:57:54 --> URI Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Router Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Output Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Input Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:57:54 --> Language Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Loader Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Controller Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:57:54 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:57:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:57:56 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:57:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:57:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:57:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:57:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:57:56 --> Final output sent to browser
DEBUG - 2011-09-09 02:57:56 --> Total execution time: 2.4230
DEBUG - 2011-09-09 02:57:57 --> Config Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:57:57 --> URI Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Router Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Output Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Input Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:57:57 --> Language Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Loader Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Controller Class Initialized
ERROR - 2011-09-09 02:57:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 02:57:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 02:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 02:57:57 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:57:57 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 02:57:57 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:57:57 --> Final output sent to browser
DEBUG - 2011-09-09 02:57:57 --> Total execution time: 0.0990
DEBUG - 2011-09-09 02:57:58 --> Config Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:57:58 --> URI Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Router Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Output Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Input Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:57:58 --> Language Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Loader Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Controller Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Model Class Initialized
DEBUG - 2011-09-09 02:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:57:58 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:57:59 --> Config Class Initialized
DEBUG - 2011-09-09 02:57:59 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:57:59 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:57:59 --> URI Class Initialized
DEBUG - 2011-09-09 02:57:59 --> Router Class Initialized
ERROR - 2011-09-09 02:57:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 02:57:59 --> Final output sent to browser
DEBUG - 2011-09-09 02:57:59 --> Total execution time: 1.4900
DEBUG - 2011-09-09 02:58:39 --> Config Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:58:39 --> URI Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Router Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Output Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Input Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:58:39 --> Language Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Loader Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Controller Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Model Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Model Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Model Class Initialized
DEBUG - 2011-09-09 02:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:58:39 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:58:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:58:40 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:58:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:58:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:58:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:58:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:58:40 --> Final output sent to browser
DEBUG - 2011-09-09 02:58:40 --> Total execution time: 0.6775
DEBUG - 2011-09-09 02:58:46 --> Config Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:58:46 --> URI Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Router Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Output Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Input Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:58:46 --> Language Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Loader Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Controller Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Model Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Model Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Model Class Initialized
DEBUG - 2011-09-09 02:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:58:46 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:58:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:58:46 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:58:46 --> Final output sent to browser
DEBUG - 2011-09-09 02:58:46 --> Total execution time: 0.1881
DEBUG - 2011-09-09 02:59:12 --> Config Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:59:12 --> URI Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Router Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Output Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Input Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:59:12 --> Language Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Loader Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Controller Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:59:12 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:59:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:59:12 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:59:12 --> Final output sent to browser
DEBUG - 2011-09-09 02:59:12 --> Total execution time: 0.3302
DEBUG - 2011-09-09 02:59:18 --> Config Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:59:18 --> URI Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Router Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Output Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Input Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:59:18 --> Language Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Loader Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Controller Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:59:18 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:59:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:59:19 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:59:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:59:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:59:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:59:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:59:19 --> Final output sent to browser
DEBUG - 2011-09-09 02:59:19 --> Total execution time: 0.7054
DEBUG - 2011-09-09 02:59:38 --> Config Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:59:38 --> URI Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Router Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Output Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Input Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:59:38 --> Language Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Loader Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Controller Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:59:38 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:59:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:59:40 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:59:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:59:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:59:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:59:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:59:40 --> Final output sent to browser
DEBUG - 2011-09-09 02:59:40 --> Total execution time: 1.2584
DEBUG - 2011-09-09 02:59:48 --> Config Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:59:48 --> URI Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Router Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Output Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Input Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:59:48 --> Language Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Loader Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Controller Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:59:48 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:59:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:59:48 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:59:48 --> Final output sent to browser
DEBUG - 2011-09-09 02:59:48 --> Total execution time: 0.0799
DEBUG - 2011-09-09 02:59:57 --> Config Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Hooks Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Utf8 Class Initialized
DEBUG - 2011-09-09 02:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 02:59:57 --> URI Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Router Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Output Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Input Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 02:59:57 --> Language Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Loader Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Controller Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Model Class Initialized
DEBUG - 2011-09-09 02:59:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 02:59:57 --> Database Driver Class Initialized
DEBUG - 2011-09-09 02:59:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 02:59:59 --> Helper loaded: url_helper
DEBUG - 2011-09-09 02:59:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 02:59:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 02:59:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 02:59:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 02:59:59 --> Final output sent to browser
DEBUG - 2011-09-09 02:59:59 --> Total execution time: 2.0239
DEBUG - 2011-09-09 03:00:05 --> Config Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:00:05 --> URI Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Router Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Output Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Input Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:00:05 --> Language Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Loader Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Controller Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Model Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Model Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Model Class Initialized
DEBUG - 2011-09-09 03:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:00:05 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Config Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:00:20 --> URI Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Router Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Output Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Input Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:00:20 --> Language Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Loader Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Controller Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Model Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Model Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Model Class Initialized
DEBUG - 2011-09-09 03:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:00:20 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:00:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:00:54 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:00:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:00:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:00:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:00:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:00:54 --> Final output sent to browser
DEBUG - 2011-09-09 03:00:54 --> Total execution time: 49.6335
DEBUG - 2011-09-09 03:00:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:00:56 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:00:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:00:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:00:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:00:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:00:56 --> Final output sent to browser
DEBUG - 2011-09-09 03:00:56 --> Total execution time: 35.5673
DEBUG - 2011-09-09 03:00:58 --> Config Class Initialized
DEBUG - 2011-09-09 03:00:58 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:00:58 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:00:58 --> URI Class Initialized
DEBUG - 2011-09-09 03:00:58 --> Router Class Initialized
ERROR - 2011-09-09 03:00:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 03:01:40 --> Config Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:01:40 --> URI Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Router Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Output Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Input Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:01:40 --> Language Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Loader Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Controller Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:01:40 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:01:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:01:40 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:01:40 --> Final output sent to browser
DEBUG - 2011-09-09 03:01:40 --> Total execution time: 0.3300
DEBUG - 2011-09-09 03:01:50 --> Config Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:01:50 --> URI Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Router Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Output Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Input Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:01:50 --> Language Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Loader Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Controller Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:01:51 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:01:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:01:56 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:01:56 --> Final output sent to browser
DEBUG - 2011-09-09 03:01:56 --> Total execution time: 5.3628
DEBUG - 2011-09-09 03:01:58 --> Config Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:01:58 --> URI Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Router Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Output Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Input Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:01:58 --> Language Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Loader Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Controller Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Model Class Initialized
DEBUG - 2011-09-09 03:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:01:58 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:01:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:01:58 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:01:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:01:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:01:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:01:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:01:58 --> Final output sent to browser
DEBUG - 2011-09-09 03:01:58 --> Total execution time: 0.2829
DEBUG - 2011-09-09 03:02:12 --> Config Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:02:12 --> URI Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Router Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Output Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Input Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:02:12 --> Language Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Loader Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Controller Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Model Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Model Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Model Class Initialized
DEBUG - 2011-09-09 03:02:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:02:12 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:02:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:02:12 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:02:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:02:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:02:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:02:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:02:12 --> Final output sent to browser
DEBUG - 2011-09-09 03:02:12 --> Total execution time: 0.2261
DEBUG - 2011-09-09 03:02:24 --> Config Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:02:24 --> URI Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Router Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Output Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Input Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:02:24 --> Language Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Loader Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Controller Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Model Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Model Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Model Class Initialized
DEBUG - 2011-09-09 03:02:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:02:24 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:02:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:02:26 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:02:26 --> Final output sent to browser
DEBUG - 2011-09-09 03:02:26 --> Total execution time: 2.3932
DEBUG - 2011-09-09 03:03:26 --> Config Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:03:26 --> URI Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Router Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Output Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Input Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:03:26 --> Language Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Loader Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Controller Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Model Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Model Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Model Class Initialized
DEBUG - 2011-09-09 03:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:03:26 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:03:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:03:26 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:03:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:03:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:03:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:03:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:03:26 --> Final output sent to browser
DEBUG - 2011-09-09 03:03:26 --> Total execution time: 0.0493
DEBUG - 2011-09-09 03:03:27 --> Config Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:03:27 --> URI Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Router Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Output Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Input Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:03:27 --> Language Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Loader Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Controller Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Model Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Model Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Model Class Initialized
DEBUG - 2011-09-09 03:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:03:27 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:03:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:03:27 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:03:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:03:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:03:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:03:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:03:27 --> Final output sent to browser
DEBUG - 2011-09-09 03:03:27 --> Total execution time: 0.0700
DEBUG - 2011-09-09 03:24:48 --> Config Class Initialized
DEBUG - 2011-09-09 03:24:48 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:24:48 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:24:48 --> URI Class Initialized
DEBUG - 2011-09-09 03:24:48 --> Router Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Output Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Input Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:24:49 --> Language Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Loader Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Controller Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Model Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Model Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Model Class Initialized
DEBUG - 2011-09-09 03:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:24:49 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:24:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:24:50 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:24:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:24:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:24:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:24:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:24:50 --> Final output sent to browser
DEBUG - 2011-09-09 03:24:50 --> Total execution time: 1.8567
DEBUG - 2011-09-09 03:25:02 --> Config Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:25:02 --> URI Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Router Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Output Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Input Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:25:02 --> Language Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Loader Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Controller Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:25:02 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:25:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:25:04 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:25:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:25:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:25:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:25:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:25:04 --> Final output sent to browser
DEBUG - 2011-09-09 03:25:04 --> Total execution time: 1.4890
DEBUG - 2011-09-09 03:25:07 --> Config Class Initialized
DEBUG - 2011-09-09 03:25:07 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:25:07 --> URI Class Initialized
DEBUG - 2011-09-09 03:25:07 --> Router Class Initialized
ERROR - 2011-09-09 03:25:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 03:25:09 --> Config Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:25:09 --> URI Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Router Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Output Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Input Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:25:09 --> Language Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Loader Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Controller Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:25:09 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:25:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:25:09 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:25:09 --> Final output sent to browser
DEBUG - 2011-09-09 03:25:09 --> Total execution time: 0.0874
DEBUG - 2011-09-09 03:25:18 --> Config Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:25:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:25:18 --> URI Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Router Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Output Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Input Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:25:18 --> Language Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Loader Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Controller Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Model Class Initialized
DEBUG - 2011-09-09 03:25:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:25:18 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:25:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:25:19 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:25:19 --> Final output sent to browser
DEBUG - 2011-09-09 03:25:19 --> Total execution time: 0.0403
DEBUG - 2011-09-09 03:46:33 --> Config Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:46:33 --> URI Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Router Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Output Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Input Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:46:33 --> Language Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Loader Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Controller Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Model Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Model Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Model Class Initialized
DEBUG - 2011-09-09 03:46:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:46:33 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:46:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:46:34 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:46:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:46:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:46:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:46:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:46:34 --> Final output sent to browser
DEBUG - 2011-09-09 03:46:34 --> Total execution time: 1.3152
DEBUG - 2011-09-09 03:46:38 --> Config Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:46:38 --> URI Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Router Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Output Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Input Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:46:38 --> Language Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Loader Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Controller Class Initialized
ERROR - 2011-09-09 03:46:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 03:46:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 03:46:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 03:46:38 --> Model Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Model Class Initialized
DEBUG - 2011-09-09 03:46:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:46:38 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:46:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 03:46:38 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:46:38 --> Final output sent to browser
DEBUG - 2011-09-09 03:46:38 --> Total execution time: 0.1001
DEBUG - 2011-09-09 03:56:06 --> Config Class Initialized
DEBUG - 2011-09-09 03:56:06 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:56:06 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:56:06 --> URI Class Initialized
DEBUG - 2011-09-09 03:56:06 --> Router Class Initialized
ERROR - 2011-09-09 03:56:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 03:56:07 --> Config Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-09 03:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 03:56:07 --> URI Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Router Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Output Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Input Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 03:56:07 --> Language Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Loader Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Controller Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Model Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Model Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Model Class Initialized
DEBUG - 2011-09-09 03:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 03:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-09 03:56:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 03:56:07 --> Helper loaded: url_helper
DEBUG - 2011-09-09 03:56:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 03:56:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 03:56:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 03:56:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 03:56:07 --> Final output sent to browser
DEBUG - 2011-09-09 03:56:07 --> Total execution time: 0.0530
DEBUG - 2011-09-09 04:33:28 --> Config Class Initialized
DEBUG - 2011-09-09 04:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-09 04:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-09 04:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 04:33:28 --> URI Class Initialized
DEBUG - 2011-09-09 04:33:28 --> Router Class Initialized
ERROR - 2011-09-09 04:33:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 05:10:21 --> Config Class Initialized
DEBUG - 2011-09-09 05:10:21 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:10:21 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:10:21 --> URI Class Initialized
DEBUG - 2011-09-09 05:10:21 --> Router Class Initialized
ERROR - 2011-09-09 05:10:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 05:16:19 --> Config Class Initialized
DEBUG - 2011-09-09 05:16:19 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:16:19 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:16:19 --> URI Class Initialized
DEBUG - 2011-09-09 05:16:19 --> Router Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Output Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Input Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:16:20 --> Language Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Loader Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Controller Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Model Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Model Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Model Class Initialized
DEBUG - 2011-09-09 05:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:16:20 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:16:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:16:21 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:16:21 --> Final output sent to browser
DEBUG - 2011-09-09 05:16:21 --> Total execution time: 2.0599
DEBUG - 2011-09-09 05:16:37 --> Config Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:16:37 --> URI Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Router Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Output Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Input Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:16:37 --> Language Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Loader Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Controller Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Model Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Model Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Model Class Initialized
DEBUG - 2011-09-09 05:16:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:16:37 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:16:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:16:38 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:16:38 --> Final output sent to browser
DEBUG - 2011-09-09 05:16:38 --> Total execution time: 0.5325
DEBUG - 2011-09-09 05:17:29 --> Config Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:17:29 --> URI Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Router Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Output Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Input Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:17:29 --> Language Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Loader Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Controller Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Model Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Model Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Model Class Initialized
DEBUG - 2011-09-09 05:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:17:29 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:17:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:17:30 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:17:30 --> Final output sent to browser
DEBUG - 2011-09-09 05:17:30 --> Total execution time: 0.2935
DEBUG - 2011-09-09 05:17:31 --> Config Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:17:31 --> URI Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Router Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Output Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Input Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:17:31 --> Language Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Loader Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Controller Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Model Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Model Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Model Class Initialized
DEBUG - 2011-09-09 05:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:17:31 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:17:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:17:31 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:17:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:17:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:17:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:17:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:17:31 --> Final output sent to browser
DEBUG - 2011-09-09 05:17:31 --> Total execution time: 0.0431
DEBUG - 2011-09-09 05:18:12 --> Config Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:18:12 --> URI Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Router Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Output Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Input Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:18:12 --> Language Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Loader Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Controller Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:18:12 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:18:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:18:13 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:18:13 --> Final output sent to browser
DEBUG - 2011-09-09 05:18:13 --> Total execution time: 0.3391
DEBUG - 2011-09-09 05:18:15 --> Config Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:18:15 --> URI Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Router Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Output Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Input Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:18:15 --> Language Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Loader Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Controller Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:18:15 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:18:15 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:18:15 --> Final output sent to browser
DEBUG - 2011-09-09 05:18:15 --> Total execution time: 0.0516
DEBUG - 2011-09-09 05:18:50 --> Config Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:18:50 --> URI Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Router Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Output Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Input Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:18:50 --> Language Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Loader Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Controller Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:18:50 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:18:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:18:51 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:18:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:18:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:18:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:18:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:18:51 --> Final output sent to browser
DEBUG - 2011-09-09 05:18:51 --> Total execution time: 0.6023
DEBUG - 2011-09-09 05:18:53 --> Config Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:18:53 --> URI Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Router Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Output Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Input Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:18:53 --> Language Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Loader Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Controller Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Model Class Initialized
DEBUG - 2011-09-09 05:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:18:53 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:18:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:18:53 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:18:53 --> Final output sent to browser
DEBUG - 2011-09-09 05:18:53 --> Total execution time: 0.0504
DEBUG - 2011-09-09 05:19:25 --> Config Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:19:25 --> URI Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Router Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Output Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Input Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:19:25 --> Language Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Loader Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Controller Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:19:25 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:19:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:19:25 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:19:25 --> Final output sent to browser
DEBUG - 2011-09-09 05:19:25 --> Total execution time: 0.2375
DEBUG - 2011-09-09 05:19:31 --> Config Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:19:31 --> URI Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Router Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Output Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Input Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:19:31 --> Language Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Loader Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Controller Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:19:31 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:19:31 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:19:31 --> Final output sent to browser
DEBUG - 2011-09-09 05:19:31 --> Total execution time: 0.0495
DEBUG - 2011-09-09 05:19:43 --> Config Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:19:43 --> URI Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Router Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Output Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Input Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:19:43 --> Language Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Loader Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Controller Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:19:43 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:19:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:19:43 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:19:43 --> Final output sent to browser
DEBUG - 2011-09-09 05:19:43 --> Total execution time: 0.2537
DEBUG - 2011-09-09 05:19:48 --> Config Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:19:48 --> URI Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Router Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Output Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Input Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:19:48 --> Language Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Loader Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Controller Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Model Class Initialized
DEBUG - 2011-09-09 05:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:19:48 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:19:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:19:48 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:19:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:19:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:19:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:19:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:19:48 --> Final output sent to browser
DEBUG - 2011-09-09 05:19:48 --> Total execution time: 0.1213
DEBUG - 2011-09-09 05:20:14 --> Config Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:20:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:20:14 --> URI Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Router Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Output Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Input Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:20:14 --> Language Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Loader Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Controller Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:20:14 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:20:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:20:15 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:20:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:20:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:20:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:20:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:20:15 --> Final output sent to browser
DEBUG - 2011-09-09 05:20:15 --> Total execution time: 1.2195
DEBUG - 2011-09-09 05:20:21 --> Config Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:20:21 --> URI Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Router Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Output Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Input Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:20:21 --> Language Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Loader Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Controller Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:20:21 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:20:21 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:20:21 --> Final output sent to browser
DEBUG - 2011-09-09 05:20:21 --> Total execution time: 0.0988
DEBUG - 2011-09-09 05:20:32 --> Config Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:20:32 --> URI Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Router Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Output Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Input Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:20:32 --> Language Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Loader Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Controller Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:20:32 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:20:32 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:20:32 --> Final output sent to browser
DEBUG - 2011-09-09 05:20:32 --> Total execution time: 0.3032
DEBUG - 2011-09-09 05:20:34 --> Config Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:20:34 --> URI Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Router Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Output Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Input Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:20:34 --> Language Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Loader Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Controller Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:20:34 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:20:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:20:34 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:20:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:20:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:20:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:20:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:20:34 --> Final output sent to browser
DEBUG - 2011-09-09 05:20:34 --> Total execution time: 0.0505
DEBUG - 2011-09-09 05:20:46 --> Config Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:20:46 --> URI Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Router Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Output Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Input Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:20:46 --> Language Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Loader Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Controller Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:20:46 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:20:46 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:20:46 --> Final output sent to browser
DEBUG - 2011-09-09 05:20:46 --> Total execution time: 0.6724
DEBUG - 2011-09-09 05:20:49 --> Config Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:20:49 --> URI Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Router Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Output Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Input Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:20:49 --> Language Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Loader Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Controller Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Model Class Initialized
DEBUG - 2011-09-09 05:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:20:49 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:20:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 05:20:49 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:20:49 --> Final output sent to browser
DEBUG - 2011-09-09 05:20:49 --> Total execution time: 0.0477
DEBUG - 2011-09-09 05:46:28 --> Config Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:46:28 --> URI Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Router Class Initialized
ERROR - 2011-09-09 05:46:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 05:46:28 --> Config Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Hooks Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Utf8 Class Initialized
DEBUG - 2011-09-09 05:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 05:46:28 --> URI Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Router Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Output Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Input Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 05:46:28 --> Language Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Loader Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Controller Class Initialized
ERROR - 2011-09-09 05:46:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 05:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 05:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 05:46:28 --> Model Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Model Class Initialized
DEBUG - 2011-09-09 05:46:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 05:46:28 --> Database Driver Class Initialized
DEBUG - 2011-09-09 05:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 05:46:28 --> Helper loaded: url_helper
DEBUG - 2011-09-09 05:46:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 05:46:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 05:46:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 05:46:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 05:46:28 --> Final output sent to browser
DEBUG - 2011-09-09 05:46:28 --> Total execution time: 0.2047
DEBUG - 2011-09-09 06:58:01 --> Config Class Initialized
DEBUG - 2011-09-09 06:58:01 --> Hooks Class Initialized
DEBUG - 2011-09-09 06:58:01 --> Utf8 Class Initialized
DEBUG - 2011-09-09 06:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 06:58:02 --> URI Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Router Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Output Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Input Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 06:58:02 --> Language Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Loader Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Controller Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Model Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Model Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Model Class Initialized
DEBUG - 2011-09-09 06:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 06:58:02 --> Database Driver Class Initialized
DEBUG - 2011-09-09 06:58:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 06:58:03 --> Helper loaded: url_helper
DEBUG - 2011-09-09 06:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 06:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 06:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 06:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 06:58:03 --> Final output sent to browser
DEBUG - 2011-09-09 06:58:03 --> Total execution time: 1.2508
DEBUG - 2011-09-09 06:58:15 --> Config Class Initialized
DEBUG - 2011-09-09 06:58:15 --> Hooks Class Initialized
DEBUG - 2011-09-09 06:58:15 --> Utf8 Class Initialized
DEBUG - 2011-09-09 06:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 06:58:15 --> URI Class Initialized
DEBUG - 2011-09-09 06:58:15 --> Router Class Initialized
ERROR - 2011-09-09 06:58:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 07:06:38 --> Config Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:06:38 --> URI Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Router Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Output Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Input Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:06:38 --> Language Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Loader Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Controller Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Model Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Model Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Model Class Initialized
DEBUG - 2011-09-09 07:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:06:38 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 07:06:38 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:06:38 --> Final output sent to browser
DEBUG - 2011-09-09 07:06:38 --> Total execution time: 0.1986
DEBUG - 2011-09-09 07:07:17 --> Config Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:07:17 --> URI Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Router Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Output Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Input Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:07:17 --> Language Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Loader Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Controller Class Initialized
ERROR - 2011-09-09 07:07:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 07:07:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 07:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:07:17 --> Model Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Model Class Initialized
DEBUG - 2011-09-09 07:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:07:17 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:07:17 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:07:17 --> Final output sent to browser
DEBUG - 2011-09-09 07:07:17 --> Total execution time: 0.0994
DEBUG - 2011-09-09 07:07:18 --> Config Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:07:18 --> URI Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Router Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Output Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Input Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:07:18 --> Language Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Loader Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Controller Class Initialized
ERROR - 2011-09-09 07:07:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 07:07:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 07:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:07:18 --> Model Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Model Class Initialized
DEBUG - 2011-09-09 07:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:07:18 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:07:18 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:07:18 --> Final output sent to browser
DEBUG - 2011-09-09 07:07:18 --> Total execution time: 0.0779
DEBUG - 2011-09-09 07:16:59 --> Config Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:16:59 --> URI Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Router Class Initialized
DEBUG - 2011-09-09 07:16:59 --> No URI present. Default controller set.
DEBUG - 2011-09-09 07:16:59 --> Output Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Input Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:16:59 --> Language Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Loader Class Initialized
DEBUG - 2011-09-09 07:16:59 --> Controller Class Initialized
DEBUG - 2011-09-09 07:16:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 07:16:59 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:16:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:16:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:16:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:16:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:16:59 --> Final output sent to browser
DEBUG - 2011-09-09 07:16:59 --> Total execution time: 0.0724
DEBUG - 2011-09-09 07:20:54 --> Config Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:20:54 --> URI Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Router Class Initialized
DEBUG - 2011-09-09 07:20:54 --> No URI present. Default controller set.
DEBUG - 2011-09-09 07:20:54 --> Output Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Input Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:20:54 --> Language Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Loader Class Initialized
DEBUG - 2011-09-09 07:20:54 --> Controller Class Initialized
DEBUG - 2011-09-09 07:20:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 07:20:54 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:20:54 --> Final output sent to browser
DEBUG - 2011-09-09 07:20:54 --> Total execution time: 0.0241
DEBUG - 2011-09-09 07:38:37 --> Config Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:38:37 --> URI Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Router Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Output Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Input Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:38:37 --> Language Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Loader Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Controller Class Initialized
ERROR - 2011-09-09 07:38:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 07:38:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 07:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:38:37 --> Model Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Model Class Initialized
DEBUG - 2011-09-09 07:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:38:37 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:38:37 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:38:37 --> Final output sent to browser
DEBUG - 2011-09-09 07:38:37 --> Total execution time: 0.1794
DEBUG - 2011-09-09 07:38:39 --> Config Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:38:39 --> URI Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Router Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Output Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Input Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:38:39 --> Language Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Loader Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Controller Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Model Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Model Class Initialized
DEBUG - 2011-09-09 07:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:38:39 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:38:40 --> Final output sent to browser
DEBUG - 2011-09-09 07:38:40 --> Total execution time: 0.8430
DEBUG - 2011-09-09 07:40:19 --> Config Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:40:19 --> URI Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Router Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Output Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Input Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:40:19 --> Language Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Loader Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Controller Class Initialized
ERROR - 2011-09-09 07:40:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 07:40:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 07:40:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:40:19 --> Model Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Model Class Initialized
DEBUG - 2011-09-09 07:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:40:19 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:40:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 07:40:19 --> Helper loaded: url_helper
DEBUG - 2011-09-09 07:40:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 07:40:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 07:40:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 07:40:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 07:40:19 --> Final output sent to browser
DEBUG - 2011-09-09 07:40:19 --> Total execution time: 0.0282
DEBUG - 2011-09-09 07:40:21 --> Config Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Hooks Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Utf8 Class Initialized
DEBUG - 2011-09-09 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 07:40:21 --> URI Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Router Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Output Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Input Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 07:40:21 --> Language Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Loader Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Controller Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Model Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Model Class Initialized
DEBUG - 2011-09-09 07:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 07:40:21 --> Database Driver Class Initialized
DEBUG - 2011-09-09 07:40:22 --> Final output sent to browser
DEBUG - 2011-09-09 07:40:22 --> Total execution time: 0.8184
DEBUG - 2011-09-09 09:19:00 --> Config Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:19:00 --> URI Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Router Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Output Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Input Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:19:00 --> Language Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Loader Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Controller Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:19:00 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:19:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:19:01 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:19:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:19:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:19:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:19:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:19:01 --> Final output sent to browser
DEBUG - 2011-09-09 09:19:01 --> Total execution time: 0.6731
DEBUG - 2011-09-09 09:19:07 --> Config Class Initialized
DEBUG - 2011-09-09 09:19:07 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:19:07 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:19:07 --> URI Class Initialized
DEBUG - 2011-09-09 09:19:07 --> Router Class Initialized
ERROR - 2011-09-09 09:19:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 09:19:46 --> Config Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:19:46 --> URI Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Router Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Output Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Input Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:19:46 --> Language Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Loader Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Controller Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:19:46 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:19:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:19:46 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:19:46 --> Final output sent to browser
DEBUG - 2011-09-09 09:19:46 --> Total execution time: 0.1798
DEBUG - 2011-09-09 09:19:48 --> Config Class Initialized
DEBUG - 2011-09-09 09:19:48 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:19:48 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:19:48 --> URI Class Initialized
DEBUG - 2011-09-09 09:19:48 --> Router Class Initialized
ERROR - 2011-09-09 09:19:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 09:19:51 --> Config Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:19:51 --> URI Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Router Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Output Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Input Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:19:51 --> Language Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Loader Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Controller Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Model Class Initialized
DEBUG - 2011-09-09 09:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:19:51 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:19:51 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:19:51 --> Final output sent to browser
DEBUG - 2011-09-09 09:19:51 --> Total execution time: 0.1500
DEBUG - 2011-09-09 09:34:47 --> Config Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:34:47 --> URI Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Router Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Output Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Input Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:34:47 --> Language Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Loader Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Controller Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Model Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Model Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Model Class Initialized
DEBUG - 2011-09-09 09:34:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:34:47 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:34:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:34:47 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:34:47 --> Final output sent to browser
DEBUG - 2011-09-09 09:34:47 --> Total execution time: 0.0908
DEBUG - 2011-09-09 09:34:49 --> Config Class Initialized
DEBUG - 2011-09-09 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:34:49 --> URI Class Initialized
DEBUG - 2011-09-09 09:34:49 --> Router Class Initialized
ERROR - 2011-09-09 09:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 09:34:49 --> Config Class Initialized
DEBUG - 2011-09-09 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:34:49 --> URI Class Initialized
DEBUG - 2011-09-09 09:34:49 --> Router Class Initialized
ERROR - 2011-09-09 09:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 09:35:01 --> Config Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:35:01 --> URI Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Router Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Output Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Input Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:35:01 --> Language Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Loader Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Controller Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:35:01 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:35:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:35:02 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:35:02 --> Final output sent to browser
DEBUG - 2011-09-09 09:35:02 --> Total execution time: 0.8616
DEBUG - 2011-09-09 09:35:16 --> Config Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:35:16 --> URI Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Router Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Output Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Input Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:35:16 --> Language Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Loader Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Controller Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:35:16 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:35:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:35:17 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:35:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:35:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:35:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:35:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:35:17 --> Final output sent to browser
DEBUG - 2011-09-09 09:35:17 --> Total execution time: 0.5717
DEBUG - 2011-09-09 09:35:32 --> Config Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:35:32 --> URI Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Router Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Output Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Input Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:35:32 --> Language Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Loader Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Controller Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:35:32 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:35:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:35:33 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:35:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:35:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:35:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:35:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:35:33 --> Final output sent to browser
DEBUG - 2011-09-09 09:35:33 --> Total execution time: 0.5029
DEBUG - 2011-09-09 09:35:39 --> Config Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:35:39 --> URI Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Router Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Output Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Input Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:35:39 --> Language Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Loader Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Controller Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:35:39 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:35:39 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:35:39 --> Final output sent to browser
DEBUG - 2011-09-09 09:35:39 --> Total execution time: 0.8364
DEBUG - 2011-09-09 09:35:51 --> Config Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:35:51 --> URI Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Router Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Output Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Input Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:35:51 --> Language Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Loader Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Controller Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:35:51 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:35:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:35:52 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:35:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:35:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:35:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:35:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:35:52 --> Final output sent to browser
DEBUG - 2011-09-09 09:35:52 --> Total execution time: 1.0482
DEBUG - 2011-09-09 09:35:53 --> Config Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:35:53 --> URI Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Router Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Output Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Input Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:35:53 --> Language Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Loader Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Controller Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Model Class Initialized
DEBUG - 2011-09-09 09:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:35:53 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:35:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:35:53 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:35:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:35:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:35:53 --> Final output sent to browser
DEBUG - 2011-09-09 09:35:53 --> Total execution time: 0.0849
DEBUG - 2011-09-09 09:36:01 --> Config Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:36:01 --> URI Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Router Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Output Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Input Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:36:01 --> Language Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Loader Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Controller Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:36:01 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:36:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:36:01 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:36:01 --> Final output sent to browser
DEBUG - 2011-09-09 09:36:01 --> Total execution time: 0.3293
DEBUG - 2011-09-09 09:36:12 --> Config Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:36:12 --> URI Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Router Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Output Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Input Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:36:12 --> Language Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Loader Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Controller Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:36:12 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:36:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:36:12 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:36:12 --> Final output sent to browser
DEBUG - 2011-09-09 09:36:12 --> Total execution time: 0.5440
DEBUG - 2011-09-09 09:36:17 --> Config Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:36:17 --> URI Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Router Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Output Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Input Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:36:17 --> Language Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Loader Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Controller Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:36:17 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:36:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:36:17 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:36:17 --> Final output sent to browser
DEBUG - 2011-09-09 09:36:17 --> Total execution time: 0.0486
DEBUG - 2011-09-09 09:36:20 --> Config Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:36:20 --> URI Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Router Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Output Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Input Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:36:20 --> Language Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Loader Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Controller Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:36:20 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:36:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:36:20 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:36:20 --> Final output sent to browser
DEBUG - 2011-09-09 09:36:20 --> Total execution time: 0.4379
DEBUG - 2011-09-09 09:36:22 --> Config Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Hooks Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Utf8 Class Initialized
DEBUG - 2011-09-09 09:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 09:36:22 --> URI Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Router Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Output Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Input Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 09:36:22 --> Language Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Loader Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Controller Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Model Class Initialized
DEBUG - 2011-09-09 09:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 09:36:22 --> Database Driver Class Initialized
DEBUG - 2011-09-09 09:36:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 09:36:22 --> Helper loaded: url_helper
DEBUG - 2011-09-09 09:36:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 09:36:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 09:36:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 09:36:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 09:36:22 --> Final output sent to browser
DEBUG - 2011-09-09 09:36:22 --> Total execution time: 0.0551
DEBUG - 2011-09-09 10:46:20 --> Config Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Hooks Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Utf8 Class Initialized
DEBUG - 2011-09-09 10:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 10:46:20 --> URI Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Router Class Initialized
DEBUG - 2011-09-09 10:46:20 --> No URI present. Default controller set.
DEBUG - 2011-09-09 10:46:20 --> Output Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Input Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 10:46:20 --> Language Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Loader Class Initialized
DEBUG - 2011-09-09 10:46:20 --> Controller Class Initialized
DEBUG - 2011-09-09 10:46:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 10:46:20 --> Helper loaded: url_helper
DEBUG - 2011-09-09 10:46:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 10:46:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 10:46:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 10:46:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 10:46:20 --> Final output sent to browser
DEBUG - 2011-09-09 10:46:20 --> Total execution time: 0.0830
DEBUG - 2011-09-09 12:53:27 --> Config Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Hooks Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Utf8 Class Initialized
DEBUG - 2011-09-09 12:53:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 12:53:27 --> URI Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Router Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Output Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Input Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 12:53:27 --> Language Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Loader Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Controller Class Initialized
ERROR - 2011-09-09 12:53:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 12:53:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 12:53:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 12:53:27 --> Model Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Model Class Initialized
DEBUG - 2011-09-09 12:53:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 12:53:27 --> Database Driver Class Initialized
DEBUG - 2011-09-09 12:53:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 12:53:27 --> Helper loaded: url_helper
DEBUG - 2011-09-09 12:53:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 12:53:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 12:53:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 12:53:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 12:53:27 --> Final output sent to browser
DEBUG - 2011-09-09 12:53:27 --> Total execution time: 0.2688
DEBUG - 2011-09-09 12:53:29 --> Config Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Hooks Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Utf8 Class Initialized
DEBUG - 2011-09-09 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 12:53:29 --> URI Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Router Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Output Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Input Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 12:53:29 --> Language Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Loader Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Controller Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Model Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Model Class Initialized
DEBUG - 2011-09-09 12:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 12:53:29 --> Database Driver Class Initialized
DEBUG - 2011-09-09 12:53:30 --> Final output sent to browser
DEBUG - 2011-09-09 12:53:30 --> Total execution time: 0.7848
DEBUG - 2011-09-09 12:59:52 --> Config Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-09 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 12:59:52 --> URI Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Router Class Initialized
DEBUG - 2011-09-09 12:59:52 --> No URI present. Default controller set.
DEBUG - 2011-09-09 12:59:52 --> Output Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Input Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 12:59:52 --> Language Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Loader Class Initialized
DEBUG - 2011-09-09 12:59:52 --> Controller Class Initialized
DEBUG - 2011-09-09 12:59:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 12:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-09 12:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 12:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 12:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 12:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 12:59:52 --> Final output sent to browser
DEBUG - 2011-09-09 12:59:52 --> Total execution time: 0.0524
DEBUG - 2011-09-09 13:41:30 --> Config Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Hooks Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Utf8 Class Initialized
DEBUG - 2011-09-09 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 13:41:30 --> URI Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Router Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Output Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Input Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 13:41:30 --> Language Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Loader Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Controller Class Initialized
ERROR - 2011-09-09 13:41:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 13:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 13:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 13:41:30 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 13:41:30 --> Database Driver Class Initialized
DEBUG - 2011-09-09 13:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 13:41:30 --> Helper loaded: url_helper
DEBUG - 2011-09-09 13:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 13:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 13:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 13:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 13:41:30 --> Final output sent to browser
DEBUG - 2011-09-09 13:41:30 --> Total execution time: 0.0478
DEBUG - 2011-09-09 13:41:33 --> Config Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Hooks Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Utf8 Class Initialized
DEBUG - 2011-09-09 13:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 13:41:33 --> URI Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Router Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Output Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Input Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 13:41:33 --> Language Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Loader Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Controller Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 13:41:33 --> Database Driver Class Initialized
DEBUG - 2011-09-09 13:41:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 13:41:33 --> Helper loaded: url_helper
DEBUG - 2011-09-09 13:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 13:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 13:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 13:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 13:41:33 --> Final output sent to browser
DEBUG - 2011-09-09 13:41:33 --> Total execution time: 0.2596
DEBUG - 2011-09-09 13:41:35 --> Config Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Hooks Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Utf8 Class Initialized
DEBUG - 2011-09-09 13:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 13:41:35 --> URI Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Router Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Output Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Input Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 13:41:35 --> Language Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Loader Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Controller Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Model Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 13:41:35 --> Database Driver Class Initialized
DEBUG - 2011-09-09 13:41:35 --> Final output sent to browser
DEBUG - 2011-09-09 13:41:35 --> Total execution time: 0.5858
DEBUG - 2011-09-09 13:44:44 --> Config Class Initialized
DEBUG - 2011-09-09 13:44:44 --> Hooks Class Initialized
DEBUG - 2011-09-09 13:44:44 --> Utf8 Class Initialized
DEBUG - 2011-09-09 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 13:44:44 --> URI Class Initialized
DEBUG - 2011-09-09 13:44:44 --> Router Class Initialized
ERROR - 2011-09-09 13:44:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 14:18:27 --> Config Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Hooks Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Utf8 Class Initialized
DEBUG - 2011-09-09 14:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 14:18:27 --> URI Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Router Class Initialized
DEBUG - 2011-09-09 14:18:27 --> No URI present. Default controller set.
DEBUG - 2011-09-09 14:18:27 --> Output Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Input Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 14:18:27 --> Language Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Loader Class Initialized
DEBUG - 2011-09-09 14:18:27 --> Controller Class Initialized
DEBUG - 2011-09-09 14:18:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 14:18:27 --> Helper loaded: url_helper
DEBUG - 2011-09-09 14:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 14:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 14:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 14:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 14:18:27 --> Final output sent to browser
DEBUG - 2011-09-09 14:18:27 --> Total execution time: 0.0136
DEBUG - 2011-09-09 15:13:29 --> Config Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-09 15:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 15:13:29 --> URI Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Router Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Output Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Input Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 15:13:29 --> Language Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Loader Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Controller Class Initialized
ERROR - 2011-09-09 15:13:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 15:13:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 15:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 15:13:29 --> Model Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Model Class Initialized
DEBUG - 2011-09-09 15:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 15:13:29 --> Database Driver Class Initialized
DEBUG - 2011-09-09 15:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 15:13:29 --> Helper loaded: url_helper
DEBUG - 2011-09-09 15:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 15:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 15:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 15:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 15:13:29 --> Final output sent to browser
DEBUG - 2011-09-09 15:13:29 --> Total execution time: 0.0529
DEBUG - 2011-09-09 15:13:30 --> Config Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Hooks Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Utf8 Class Initialized
DEBUG - 2011-09-09 15:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 15:13:30 --> URI Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Router Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Output Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Input Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 15:13:30 --> Language Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Loader Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Controller Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Model Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Model Class Initialized
DEBUG - 2011-09-09 15:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 15:13:30 --> Database Driver Class Initialized
DEBUG - 2011-09-09 15:13:31 --> Final output sent to browser
DEBUG - 2011-09-09 15:13:31 --> Total execution time: 0.5452
DEBUG - 2011-09-09 15:13:31 --> Config Class Initialized
DEBUG - 2011-09-09 15:13:31 --> Hooks Class Initialized
DEBUG - 2011-09-09 15:13:31 --> Utf8 Class Initialized
DEBUG - 2011-09-09 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 15:13:31 --> URI Class Initialized
DEBUG - 2011-09-09 15:13:31 --> Router Class Initialized
ERROR - 2011-09-09 15:13:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 17:10:55 --> Config Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:10:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:10:55 --> URI Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Router Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Output Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Input Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:10:55 --> Language Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Loader Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Controller Class Initialized
ERROR - 2011-09-09 17:10:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 17:10:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 17:10:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:10:55 --> Model Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Model Class Initialized
DEBUG - 2011-09-09 17:10:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:10:55 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:10:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:10:56 --> Helper loaded: url_helper
DEBUG - 2011-09-09 17:10:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 17:10:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 17:10:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 17:10:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 17:10:56 --> Final output sent to browser
DEBUG - 2011-09-09 17:10:56 --> Total execution time: 0.1378
DEBUG - 2011-09-09 17:10:59 --> Config Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:11:00 --> URI Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Router Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Output Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Input Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:11:00 --> Language Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Loader Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Controller Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Model Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Model Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:11:00 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:11:00 --> Final output sent to browser
DEBUG - 2011-09-09 17:11:00 --> Total execution time: 0.8179
DEBUG - 2011-09-09 17:31:38 --> Config Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:31:38 --> URI Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Router Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Output Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Input Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:31:38 --> Language Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Loader Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Controller Class Initialized
ERROR - 2011-09-09 17:31:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 17:31:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 17:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:31:38 --> Model Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Model Class Initialized
DEBUG - 2011-09-09 17:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:31:38 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:31:38 --> Helper loaded: url_helper
DEBUG - 2011-09-09 17:31:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 17:31:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 17:31:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 17:31:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 17:31:38 --> Final output sent to browser
DEBUG - 2011-09-09 17:31:38 --> Total execution time: 0.0282
DEBUG - 2011-09-09 17:37:20 --> Config Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:37:20 --> URI Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Router Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Output Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Input Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:37:20 --> Language Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Loader Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Controller Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:37:20 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 17:37:21 --> Helper loaded: url_helper
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 17:37:21 --> Final output sent to browser
DEBUG - 2011-09-09 17:37:21 --> Total execution time: 0.9906
DEBUG - 2011-09-09 17:37:21 --> Config Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:37:21 --> URI Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Router Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Output Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Input Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:37:21 --> Language Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Loader Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Controller Class Initialized
ERROR - 2011-09-09 17:37:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 17:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:37:21 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:37:21 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:37:21 --> Helper loaded: url_helper
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 17:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 17:37:21 --> Final output sent to browser
DEBUG - 2011-09-09 17:37:21 --> Total execution time: 0.0274
DEBUG - 2011-09-09 17:37:47 --> Config Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:37:47 --> URI Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Router Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Output Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Input Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:37:47 --> Language Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Loader Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Controller Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:37:47 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:37:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 17:37:47 --> Helper loaded: url_helper
DEBUG - 2011-09-09 17:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 17:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 17:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 17:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 17:37:47 --> Final output sent to browser
DEBUG - 2011-09-09 17:37:47 --> Total execution time: 0.0458
DEBUG - 2011-09-09 17:37:48 --> Config Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Hooks Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Utf8 Class Initialized
DEBUG - 2011-09-09 17:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 17:37:48 --> URI Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Router Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Output Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Input Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 17:37:48 --> Language Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Loader Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Controller Class Initialized
ERROR - 2011-09-09 17:37:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 17:37:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 17:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:37:48 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Model Class Initialized
DEBUG - 2011-09-09 17:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 17:37:48 --> Database Driver Class Initialized
DEBUG - 2011-09-09 17:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 17:37:48 --> Helper loaded: url_helper
DEBUG - 2011-09-09 17:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 17:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 17:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 17:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 17:37:48 --> Final output sent to browser
DEBUG - 2011-09-09 17:37:48 --> Total execution time: 0.0272
DEBUG - 2011-09-09 19:09:56 --> Config Class Initialized
DEBUG - 2011-09-09 19:09:56 --> Hooks Class Initialized
DEBUG - 2011-09-09 19:09:56 --> Utf8 Class Initialized
DEBUG - 2011-09-09 19:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 19:09:56 --> URI Class Initialized
DEBUG - 2011-09-09 19:09:56 --> Router Class Initialized
ERROR - 2011-09-09 19:09:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 20:24:50 --> Config Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Hooks Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Utf8 Class Initialized
DEBUG - 2011-09-09 20:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 20:24:50 --> URI Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Router Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Output Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Input Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 20:24:50 --> Language Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Loader Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Controller Class Initialized
ERROR - 2011-09-09 20:24:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 20:24:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 20:24:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 20:24:50 --> Model Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Model Class Initialized
DEBUG - 2011-09-09 20:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 20:24:50 --> Database Driver Class Initialized
DEBUG - 2011-09-09 20:24:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 20:24:50 --> Helper loaded: url_helper
DEBUG - 2011-09-09 20:24:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 20:24:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 20:24:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 20:24:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 20:24:50 --> Final output sent to browser
DEBUG - 2011-09-09 20:24:50 --> Total execution time: 0.1135
DEBUG - 2011-09-09 20:25:53 --> Config Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Hooks Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Utf8 Class Initialized
DEBUG - 2011-09-09 20:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 20:25:53 --> URI Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Router Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Output Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Input Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 20:25:53 --> Language Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Loader Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Controller Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Model Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Model Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Model Class Initialized
DEBUG - 2011-09-09 20:25:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 20:25:53 --> Database Driver Class Initialized
DEBUG - 2011-09-09 20:25:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 20:25:53 --> Helper loaded: url_helper
DEBUG - 2011-09-09 20:25:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 20:25:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 20:25:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 20:25:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 20:25:53 --> Final output sent to browser
DEBUG - 2011-09-09 20:25:53 --> Total execution time: 0.3676
DEBUG - 2011-09-09 21:15:28 --> Config Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:15:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:15:28 --> URI Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Router Class Initialized
DEBUG - 2011-09-09 21:15:28 --> No URI present. Default controller set.
DEBUG - 2011-09-09 21:15:28 --> Output Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Input Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 21:15:28 --> Language Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Loader Class Initialized
DEBUG - 2011-09-09 21:15:28 --> Controller Class Initialized
DEBUG - 2011-09-09 21:15:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-09 21:15:28 --> Helper loaded: url_helper
DEBUG - 2011-09-09 21:15:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 21:15:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 21:15:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 21:15:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 21:15:28 --> Final output sent to browser
DEBUG - 2011-09-09 21:15:28 --> Total execution time: 0.0477
DEBUG - 2011-09-09 21:24:50 --> Config Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:24:50 --> URI Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Router Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Output Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Input Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 21:24:50 --> Language Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Loader Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Controller Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Model Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Model Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Model Class Initialized
DEBUG - 2011-09-09 21:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 21:24:50 --> Database Driver Class Initialized
DEBUG - 2011-09-09 21:24:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 21:24:50 --> Helper loaded: url_helper
DEBUG - 2011-09-09 21:24:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 21:24:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 21:24:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 21:24:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 21:24:50 --> Final output sent to browser
DEBUG - 2011-09-09 21:24:50 --> Total execution time: 0.2904
DEBUG - 2011-09-09 21:24:52 --> Config Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:24:52 --> URI Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Router Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Output Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Input Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 21:24:52 --> Language Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Loader Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Controller Class Initialized
ERROR - 2011-09-09 21:24:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 21:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 21:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 21:24:52 --> Model Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Model Class Initialized
DEBUG - 2011-09-09 21:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 21:24:52 --> Database Driver Class Initialized
DEBUG - 2011-09-09 21:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 21:24:52 --> Helper loaded: url_helper
DEBUG - 2011-09-09 21:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 21:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 21:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 21:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 21:24:52 --> Final output sent to browser
DEBUG - 2011-09-09 21:24:52 --> Total execution time: 0.0377
DEBUG - 2011-09-09 21:43:36 --> Config Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:43:36 --> URI Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Router Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Output Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Input Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 21:43:36 --> Language Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Loader Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Controller Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Model Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Model Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Model Class Initialized
DEBUG - 2011-09-09 21:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 21:43:36 --> Database Driver Class Initialized
DEBUG - 2011-09-09 21:43:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 21:43:36 --> Helper loaded: url_helper
DEBUG - 2011-09-09 21:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 21:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 21:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 21:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 21:43:36 --> Final output sent to browser
DEBUG - 2011-09-09 21:43:36 --> Total execution time: 0.0445
DEBUG - 2011-09-09 21:43:39 --> Config Class Initialized
DEBUG - 2011-09-09 21:43:39 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:43:39 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:43:39 --> URI Class Initialized
DEBUG - 2011-09-09 21:43:39 --> Router Class Initialized
ERROR - 2011-09-09 21:43:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-09 21:44:01 --> Config Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:44:01 --> URI Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Router Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Output Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Input Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 21:44:01 --> Language Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Loader Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Controller Class Initialized
ERROR - 2011-09-09 21:44:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 21:44:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 21:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 21:44:01 --> Model Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Model Class Initialized
DEBUG - 2011-09-09 21:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 21:44:01 --> Database Driver Class Initialized
DEBUG - 2011-09-09 21:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 21:44:01 --> Helper loaded: url_helper
DEBUG - 2011-09-09 21:44:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 21:44:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 21:44:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 21:44:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 21:44:01 --> Final output sent to browser
DEBUG - 2011-09-09 21:44:01 --> Total execution time: 0.0322
DEBUG - 2011-09-09 21:44:02 --> Config Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-09 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 21:44:02 --> URI Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Router Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Output Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Input Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 21:44:02 --> Language Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Loader Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Controller Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Model Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Model Class Initialized
DEBUG - 2011-09-09 21:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 21:44:02 --> Database Driver Class Initialized
DEBUG - 2011-09-09 21:44:03 --> Final output sent to browser
DEBUG - 2011-09-09 21:44:03 --> Total execution time: 0.7518
DEBUG - 2011-09-09 22:36:23 --> Config Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:36:23 --> URI Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Router Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Output Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Input Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:36:23 --> Language Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Loader Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Controller Class Initialized
ERROR - 2011-09-09 22:36:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 22:36:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 22:36:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:36:23 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:36:23 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:36:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:36:23 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:36:23 --> Final output sent to browser
DEBUG - 2011-09-09 22:36:23 --> Total execution time: 0.0315
DEBUG - 2011-09-09 22:36:28 --> Config Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:36:28 --> URI Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Router Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Output Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Input Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:36:28 --> Language Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Loader Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Controller Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:36:28 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:36:28 --> Final output sent to browser
DEBUG - 2011-09-09 22:36:28 --> Total execution time: 0.6926
DEBUG - 2011-09-09 22:36:55 --> Config Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:36:55 --> URI Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Router Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Output Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Input Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:36:55 --> Language Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Loader Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Controller Class Initialized
ERROR - 2011-09-09 22:36:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 22:36:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 22:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:36:55 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:36:55 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:36:55 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:36:55 --> Final output sent to browser
DEBUG - 2011-09-09 22:36:55 --> Total execution time: 0.0289
DEBUG - 2011-09-09 22:36:56 --> Config Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:36:56 --> URI Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Router Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Output Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Input Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:36:56 --> Language Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Loader Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Controller Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Model Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:36:56 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:36:56 --> Final output sent to browser
DEBUG - 2011-09-09 22:36:56 --> Total execution time: 0.7049
DEBUG - 2011-09-09 22:37:54 --> Config Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:37:54 --> URI Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Router Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Output Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Input Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:37:54 --> Language Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Loader Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Controller Class Initialized
ERROR - 2011-09-09 22:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 22:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 22:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:37:54 --> Model Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Model Class Initialized
DEBUG - 2011-09-09 22:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:37:54 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:37:54 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:37:54 --> Final output sent to browser
DEBUG - 2011-09-09 22:37:54 --> Total execution time: 0.0313
DEBUG - 2011-09-09 22:37:55 --> Config Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:37:55 --> URI Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Router Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Output Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Input Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:37:55 --> Language Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Loader Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Controller Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Model Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Model Class Initialized
DEBUG - 2011-09-09 22:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:37:55 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Config Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:37:56 --> URI Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Router Class Initialized
ERROR - 2011-09-09 22:37:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-09 22:37:56 --> Config Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:37:56 --> URI Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Router Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Output Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Input Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:37:56 --> Language Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Loader Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Controller Class Initialized
ERROR - 2011-09-09 22:37:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 22:37:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 22:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:37:56 --> Model Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Model Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:37:56 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:37:56 --> Final output sent to browser
DEBUG - 2011-09-09 22:37:56 --> Total execution time: 0.7381
DEBUG - 2011-09-09 22:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:37:56 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:37:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:37:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:37:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:37:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:37:56 --> Final output sent to browser
DEBUG - 2011-09-09 22:37:56 --> Total execution time: 0.0320
DEBUG - 2011-09-09 22:38:27 --> Config Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:38:27 --> URI Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Router Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Output Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Input Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:38:27 --> Language Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Loader Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Controller Class Initialized
ERROR - 2011-09-09 22:38:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 22:38:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 22:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:38:27 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:38:27 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:38:27 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:38:27 --> Final output sent to browser
DEBUG - 2011-09-09 22:38:27 --> Total execution time: 0.0328
DEBUG - 2011-09-09 22:38:30 --> Config Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:38:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:38:30 --> URI Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Router Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Output Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Input Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:38:30 --> Language Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Loader Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Controller Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:38:30 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:38:31 --> Final output sent to browser
DEBUG - 2011-09-09 22:38:31 --> Total execution time: 0.5333
DEBUG - 2011-09-09 22:38:48 --> Config Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:38:48 --> URI Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Router Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Output Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Input Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:38:48 --> Language Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Loader Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Controller Class Initialized
ERROR - 2011-09-09 22:38:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 22:38:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 22:38:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:38:48 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:38:48 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:38:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 22:38:48 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:38:48 --> Final output sent to browser
DEBUG - 2011-09-09 22:38:48 --> Total execution time: 0.0300
DEBUG - 2011-09-09 22:38:49 --> Config Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:38:49 --> URI Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Router Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Output Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Input Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:38:49 --> Language Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Loader Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Controller Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Model Class Initialized
DEBUG - 2011-09-09 22:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:38:49 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:38:50 --> Final output sent to browser
DEBUG - 2011-09-09 22:38:50 --> Total execution time: 0.5061
DEBUG - 2011-09-09 22:57:59 --> Config Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Hooks Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Utf8 Class Initialized
DEBUG - 2011-09-09 22:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 22:57:59 --> URI Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Router Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Output Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Input Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 22:57:59 --> Language Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Loader Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Controller Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Model Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Model Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Model Class Initialized
DEBUG - 2011-09-09 22:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 22:57:59 --> Database Driver Class Initialized
DEBUG - 2011-09-09 22:57:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-09 22:57:59 --> Helper loaded: url_helper
DEBUG - 2011-09-09 22:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 22:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 22:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 22:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 22:57:59 --> Final output sent to browser
DEBUG - 2011-09-09 22:57:59 --> Total execution time: 0.3130
DEBUG - 2011-09-09 23:00:14 --> Config Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Hooks Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Utf8 Class Initialized
DEBUG - 2011-09-09 23:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-09 23:00:14 --> URI Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Router Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Output Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Input Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-09 23:00:14 --> Language Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Loader Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Controller Class Initialized
ERROR - 2011-09-09 23:00:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-09 23:00:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-09 23:00:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 23:00:14 --> Model Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Model Class Initialized
DEBUG - 2011-09-09 23:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-09 23:00:14 --> Database Driver Class Initialized
DEBUG - 2011-09-09 23:00:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-09 23:00:14 --> Helper loaded: url_helper
DEBUG - 2011-09-09 23:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-09 23:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-09 23:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-09 23:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-09 23:00:14 --> Final output sent to browser
DEBUG - 2011-09-09 23:00:14 --> Total execution time: 0.0356

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-29 00:16:43 --> Config Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:16:43 --> URI Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Router Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Output Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Input Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:16:43 --> Language Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Loader Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Controller Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Model Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Model Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Model Class Initialized
DEBUG - 2011-08-29 00:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:16:43 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:16:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:16:43 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:16:43 --> Final output sent to browser
DEBUG - 2011-08-29 00:16:43 --> Total execution time: 0.2923
DEBUG - 2011-08-29 00:18:04 --> Config Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:18:04 --> URI Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Router Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Output Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Input Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:18:04 --> Language Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Loader Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Controller Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Model Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Model Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Model Class Initialized
DEBUG - 2011-08-29 00:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:18:04 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:18:04 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:18:04 --> Final output sent to browser
DEBUG - 2011-08-29 00:18:04 --> Total execution time: 0.0467
DEBUG - 2011-08-29 00:21:52 --> Config Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:21:52 --> URI Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Router Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Output Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Input Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:21:52 --> Language Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Loader Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Controller Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Model Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Model Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Model Class Initialized
DEBUG - 2011-08-29 00:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:21:52 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:21:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:21:52 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:21:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:21:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:21:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:21:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:21:52 --> Final output sent to browser
DEBUG - 2011-08-29 00:21:52 --> Total execution time: 0.1992
DEBUG - 2011-08-29 00:21:55 --> Config Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:21:55 --> URI Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Router Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Output Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Input Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:21:55 --> Language Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Loader Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Controller Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Model Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Model Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Model Class Initialized
DEBUG - 2011-08-29 00:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:21:55 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:21:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:21:55 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:21:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:21:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:21:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:21:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:21:55 --> Final output sent to browser
DEBUG - 2011-08-29 00:21:55 --> Total execution time: 0.0485
DEBUG - 2011-08-29 00:22:19 --> Config Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:22:19 --> URI Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Router Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Output Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Input Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:22:19 --> Language Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Loader Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Controller Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:22:19 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:22:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:22:19 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:22:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:22:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:22:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:22:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:22:19 --> Final output sent to browser
DEBUG - 2011-08-29 00:22:19 --> Total execution time: 0.1957
DEBUG - 2011-08-29 00:22:23 --> Config Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:22:23 --> URI Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Router Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Output Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Input Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:22:23 --> Language Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Loader Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Controller Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:22:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:22:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:22:23 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:22:23 --> Final output sent to browser
DEBUG - 2011-08-29 00:22:23 --> Total execution time: 0.0796
DEBUG - 2011-08-29 00:22:44 --> Config Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:22:44 --> URI Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Router Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Output Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Input Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:22:44 --> Language Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Loader Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Controller Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:22:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:22:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:22:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:22:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:22:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:22:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:22:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:22:44 --> Final output sent to browser
DEBUG - 2011-08-29 00:22:44 --> Total execution time: 0.7340
DEBUG - 2011-08-29 00:22:51 --> Config Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:22:51 --> URI Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Router Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Output Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Input Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:22:51 --> Language Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Loader Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Controller Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:22:51 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:22:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:22:51 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:22:51 --> Final output sent to browser
DEBUG - 2011-08-29 00:22:51 --> Total execution time: 0.0470
DEBUG - 2011-08-29 00:22:59 --> Config Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:22:59 --> URI Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Router Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Output Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Input Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:22:59 --> Language Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Loader Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Controller Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:22:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:22:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:00 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:00 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:00 --> Total execution time: 0.2893
DEBUG - 2011-08-29 00:23:03 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:03 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:03 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:03 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:04 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:04 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:04 --> Total execution time: 0.0438
DEBUG - 2011-08-29 00:23:18 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:18 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:18 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:18 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:18 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:18 --> Total execution time: 0.2100
DEBUG - 2011-08-29 00:23:21 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:21 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:21 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:21 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:21 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:21 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:21 --> Total execution time: 0.0417
DEBUG - 2011-08-29 00:23:29 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:29 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:29 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:29 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:30 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:30 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:30 --> Total execution time: 0.2261
DEBUG - 2011-08-29 00:23:33 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:33 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:33 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:33 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:33 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:33 --> Total execution time: 0.0560
DEBUG - 2011-08-29 00:23:43 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:43 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:43 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:43 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:43 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:43 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:43 --> Total execution time: 0.2410
DEBUG - 2011-08-29 00:23:46 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:46 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:46 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:46 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:46 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:46 --> Total execution time: 0.0462
DEBUG - 2011-08-29 00:23:56 --> Config Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:23:56 --> URI Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Router Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Output Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Input Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:23:56 --> Language Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Loader Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Controller Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Model Class Initialized
DEBUG - 2011-08-29 00:23:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:23:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:23:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:23:56 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:23:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:23:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:23:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:23:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:23:56 --> Final output sent to browser
DEBUG - 2011-08-29 00:23:56 --> Total execution time: 0.2474
DEBUG - 2011-08-29 00:24:04 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:04 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:04 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:04 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:04 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:04 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:04 --> Total execution time: 0.0698
DEBUG - 2011-08-29 00:24:11 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:11 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:11 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:11 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:12 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:12 --> Total execution time: 0.2150
DEBUG - 2011-08-29 00:24:15 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:15 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:15 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:15 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:15 --> Total execution time: 0.0469
DEBUG - 2011-08-29 00:24:25 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:25 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:25 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:25 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:25 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:25 --> Total execution time: 0.2362
DEBUG - 2011-08-29 00:24:28 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:28 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:28 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:28 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:28 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:28 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:28 --> Total execution time: 0.0451
DEBUG - 2011-08-29 00:24:35 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:35 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:35 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:36 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:36 --> Total execution time: 0.5095
DEBUG - 2011-08-29 00:24:39 --> Config Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:24:39 --> URI Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Router Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Output Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Input Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:24:39 --> Language Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Loader Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Controller Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Model Class Initialized
DEBUG - 2011-08-29 00:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:24:39 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:24:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:24:39 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:24:39 --> Final output sent to browser
DEBUG - 2011-08-29 00:24:39 --> Total execution time: 0.0653
DEBUG - 2011-08-29 00:25:07 --> Config Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:25:07 --> URI Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Router Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Output Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Input Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:25:07 --> Language Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Loader Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Controller Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Model Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Model Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Model Class Initialized
DEBUG - 2011-08-29 00:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:25:07 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:25:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:25:07 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:25:07 --> Final output sent to browser
DEBUG - 2011-08-29 00:25:07 --> Total execution time: 0.1092
DEBUG - 2011-08-29 00:25:11 --> Config Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:25:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:25:11 --> URI Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Router Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Output Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Input Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:25:11 --> Language Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Loader Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Controller Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Model Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Model Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Model Class Initialized
DEBUG - 2011-08-29 00:25:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:25:11 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:25:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:25:11 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:25:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:25:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:25:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:25:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:25:11 --> Final output sent to browser
DEBUG - 2011-08-29 00:25:11 --> Total execution time: 0.0453
DEBUG - 2011-08-29 00:35:59 --> Config Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:35:59 --> URI Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Router Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Output Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Input Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:35:59 --> Language Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Loader Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Controller Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:35:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:35:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:35:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 00:35:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:35:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:35:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:35:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:35:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:35:59 --> Final output sent to browser
DEBUG - 2011-08-29 00:35:59 --> Total execution time: 0.2369
DEBUG - 2011-08-29 00:36:02 --> Config Class Initialized
DEBUG - 2011-08-29 00:36:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:36:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:36:02 --> URI Class Initialized
DEBUG - 2011-08-29 00:36:02 --> Router Class Initialized
ERROR - 2011-08-29 00:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:36:03 --> Config Class Initialized
DEBUG - 2011-08-29 00:36:03 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:36:03 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:36:03 --> URI Class Initialized
DEBUG - 2011-08-29 00:36:03 --> Router Class Initialized
ERROR - 2011-08-29 00:36:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:15 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:15 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:15 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Controller Class Initialized
ERROR - 2011-08-29 00:47:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:47:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:47:15 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:15 --> Total execution time: 0.0298
DEBUG - 2011-08-29 00:47:15 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:15 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:15 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Controller Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:16 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:16 --> Total execution time: 0.5492
DEBUG - 2011-08-29 00:47:17 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:17 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:17 --> Router Class Initialized
ERROR - 2011-08-29 00:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:17 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:17 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:17 --> Router Class Initialized
ERROR - 2011-08-29 00:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:25 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:25 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:25 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Controller Class Initialized
ERROR - 2011-08-29 00:47:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:47:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:25 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:25 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:47:25 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:25 --> Total execution time: 0.0286
DEBUG - 2011-08-29 00:47:26 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:26 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:26 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Controller Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:26 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:26 --> Total execution time: 0.6859
DEBUG - 2011-08-29 00:47:27 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:27 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:27 --> Router Class Initialized
ERROR - 2011-08-29 00:47:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:35 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:35 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:35 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Controller Class Initialized
ERROR - 2011-08-29 00:47:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:47:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:47:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:35 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:47:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:47:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:47:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:47:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:47:35 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:35 --> Total execution time: 0.0277
DEBUG - 2011-08-29 00:47:35 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:35 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:35 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Controller Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:36 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:36 --> Total execution time: 0.5300
DEBUG - 2011-08-29 00:47:37 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:37 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:37 --> Router Class Initialized
ERROR - 2011-08-29 00:47:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:46 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:46 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:46 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Controller Class Initialized
ERROR - 2011-08-29 00:47:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:47:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:47:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:46 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:47:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:47:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:47:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:47:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:47:46 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:46 --> Total execution time: 0.0278
DEBUG - 2011-08-29 00:47:46 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:46 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:46 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Controller Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:47 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:47 --> Total execution time: 0.5034
DEBUG - 2011-08-29 00:47:48 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:48 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:48 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:48 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:48 --> Router Class Initialized
ERROR - 2011-08-29 00:47:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:53 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:53 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:53 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Controller Class Initialized
ERROR - 2011-08-29 00:47:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:47:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:47:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:53 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:53 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:53 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:47:53 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:53 --> Total execution time: 0.0281
DEBUG - 2011-08-29 00:47:54 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:54 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:54 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Controller Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:54 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:54 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:54 --> Total execution time: 0.6214
DEBUG - 2011-08-29 00:47:55 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:55 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:55 --> Router Class Initialized
ERROR - 2011-08-29 00:47:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:47:59 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:59 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:59 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Controller Class Initialized
ERROR - 2011-08-29 00:47:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:47:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:47:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:47:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:47:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:47:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:47:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:47:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:47:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:47:59 --> Final output sent to browser
DEBUG - 2011-08-29 00:47:59 --> Total execution time: 0.0298
DEBUG - 2011-08-29 00:47:59 --> Config Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:47:59 --> URI Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Router Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Output Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Input Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:47:59 --> Language Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Loader Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Controller Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Model Class Initialized
DEBUG - 2011-08-29 00:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:47:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:00 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:00 --> Total execution time: 0.6130
DEBUG - 2011-08-29 00:48:01 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:01 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:01 --> Router Class Initialized
ERROR - 2011-08-29 00:48:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:48:08 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:08 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:08 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Controller Class Initialized
ERROR - 2011-08-29 00:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:08 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:48:08 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:08 --> Total execution time: 0.0288
DEBUG - 2011-08-29 00:48:08 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:08 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:08 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Controller Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:09 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:09 --> Total execution time: 0.5722
DEBUG - 2011-08-29 00:48:11 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:11 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:11 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:11 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:11 --> Router Class Initialized
ERROR - 2011-08-29 00:48:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:48:18 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:18 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:18 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Controller Class Initialized
ERROR - 2011-08-29 00:48:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:48:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:18 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:48:18 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:18 --> Total execution time: 0.0282
DEBUG - 2011-08-29 00:48:18 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:18 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:18 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Controller Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:19 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:19 --> Total execution time: 0.7565
DEBUG - 2011-08-29 00:48:21 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:21 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:21 --> Router Class Initialized
ERROR - 2011-08-29 00:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:48:26 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:26 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:26 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Controller Class Initialized
ERROR - 2011-08-29 00:48:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:48:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:26 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:26 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:48:26 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:26 --> Total execution time: 0.0330
DEBUG - 2011-08-29 00:48:27 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:27 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:27 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Controller Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:27 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:27 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:27 --> Total execution time: 0.5952
DEBUG - 2011-08-29 00:48:28 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:28 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:28 --> Router Class Initialized
ERROR - 2011-08-29 00:48:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 00:48:35 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:35 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:35 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Controller Class Initialized
ERROR - 2011-08-29 00:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 00:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 00:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 00:48:35 --> Helper loaded: url_helper
DEBUG - 2011-08-29 00:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 00:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 00:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 00:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 00:48:35 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:35 --> Total execution time: 0.0604
DEBUG - 2011-08-29 00:48:36 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:36 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Router Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Output Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Input Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 00:48:36 --> Language Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Loader Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Controller Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Model Class Initialized
DEBUG - 2011-08-29 00:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 00:48:36 --> Database Driver Class Initialized
DEBUG - 2011-08-29 00:48:37 --> Final output sent to browser
DEBUG - 2011-08-29 00:48:37 --> Total execution time: 0.5744
DEBUG - 2011-08-29 00:48:37 --> Config Class Initialized
DEBUG - 2011-08-29 00:48:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 00:48:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 00:48:37 --> URI Class Initialized
DEBUG - 2011-08-29 00:48:37 --> Router Class Initialized
ERROR - 2011-08-29 00:48:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:36:42 --> Config Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:36:42 --> URI Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Router Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Output Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Input Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:36:42 --> Language Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Loader Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Controller Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Model Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Model Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Model Class Initialized
DEBUG - 2011-08-29 01:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:36:42 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:36:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:36:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:36:44 --> Final output sent to browser
DEBUG - 2011-08-29 01:36:44 --> Total execution time: 1.8450
DEBUG - 2011-08-29 01:36:51 --> Config Class Initialized
DEBUG - 2011-08-29 01:36:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:36:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:36:51 --> URI Class Initialized
DEBUG - 2011-08-29 01:36:51 --> Router Class Initialized
ERROR - 2011-08-29 01:36:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:36:52 --> Config Class Initialized
DEBUG - 2011-08-29 01:36:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:36:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:36:52 --> URI Class Initialized
DEBUG - 2011-08-29 01:36:52 --> Router Class Initialized
ERROR - 2011-08-29 01:36:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:40:44 --> Config Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:40:44 --> URI Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Router Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Output Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Input Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:40:44 --> Language Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Loader Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Controller Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Model Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Model Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Model Class Initialized
DEBUG - 2011-08-29 01:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:40:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:40:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:40:45 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:40:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:40:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:40:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:40:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:40:45 --> Final output sent to browser
DEBUG - 2011-08-29 01:40:45 --> Total execution time: 1.1720
DEBUG - 2011-08-29 01:40:49 --> Config Class Initialized
DEBUG - 2011-08-29 01:40:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:40:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:40:49 --> URI Class Initialized
DEBUG - 2011-08-29 01:40:49 --> Router Class Initialized
ERROR - 2011-08-29 01:40:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:41:03 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:03 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Router Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Output Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Input Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:41:03 --> Language Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Loader Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Controller Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:41:03 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:41:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:41:11 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:41:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:41:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:41:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:41:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:41:11 --> Final output sent to browser
DEBUG - 2011-08-29 01:41:11 --> Total execution time: 8.2131
DEBUG - 2011-08-29 01:41:16 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:16 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:16 --> Router Class Initialized
ERROR - 2011-08-29 01:41:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:41:18 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:18 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Router Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Output Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Input Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:41:18 --> Language Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Loader Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Controller Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:41:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:41:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:41:18 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:41:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:41:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:41:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:41:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:41:18 --> Final output sent to browser
DEBUG - 2011-08-29 01:41:18 --> Total execution time: 0.0799
DEBUG - 2011-08-29 01:41:26 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:26 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Router Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Output Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Input Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:41:26 --> Language Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Loader Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Controller Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:41:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:41:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:41:27 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:41:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:41:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:41:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:41:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:41:27 --> Final output sent to browser
DEBUG - 2011-08-29 01:41:27 --> Total execution time: 0.9444
DEBUG - 2011-08-29 01:41:32 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:32 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:32 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:32 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:32 --> Router Class Initialized
ERROR - 2011-08-29 01:41:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:41:53 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:53 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Router Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Output Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Input Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:41:53 --> Language Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Loader Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Controller Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Model Class Initialized
DEBUG - 2011-08-29 01:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:41:53 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:41:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:41:54 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:41:54 --> Final output sent to browser
DEBUG - 2011-08-29 01:41:54 --> Total execution time: 0.8281
DEBUG - 2011-08-29 01:41:56 --> Config Class Initialized
DEBUG - 2011-08-29 01:41:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:41:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:41:56 --> URI Class Initialized
DEBUG - 2011-08-29 01:41:57 --> Router Class Initialized
ERROR - 2011-08-29 01:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:42:23 --> Config Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:42:23 --> URI Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Router Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Output Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Input Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:42:23 --> Language Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Loader Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Controller Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Model Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Model Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Model Class Initialized
DEBUG - 2011-08-29 01:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:42:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:42:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:42:26 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:42:26 --> Final output sent to browser
DEBUG - 2011-08-29 01:42:26 --> Total execution time: 3.8129
DEBUG - 2011-08-29 01:42:33 --> Config Class Initialized
DEBUG - 2011-08-29 01:42:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:42:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:42:33 --> URI Class Initialized
DEBUG - 2011-08-29 01:42:33 --> Router Class Initialized
ERROR - 2011-08-29 01:42:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:42:46 --> Config Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:42:46 --> URI Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Router Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Output Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Input Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:42:46 --> Language Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Loader Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Controller Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Model Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Model Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Model Class Initialized
DEBUG - 2011-08-29 01:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:42:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:42:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:42:47 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:42:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:42:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:42:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:42:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:42:47 --> Final output sent to browser
DEBUG - 2011-08-29 01:42:47 --> Total execution time: 0.8673
DEBUG - 2011-08-29 01:42:50 --> Config Class Initialized
DEBUG - 2011-08-29 01:42:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:42:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:42:50 --> URI Class Initialized
DEBUG - 2011-08-29 01:42:50 --> Router Class Initialized
ERROR - 2011-08-29 01:42:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:43:01 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:01 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Router Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Output Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Input Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:43:01 --> Language Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Loader Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Controller Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:43:01 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:43:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:43:02 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:43:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:43:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:43:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:43:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:43:02 --> Final output sent to browser
DEBUG - 2011-08-29 01:43:02 --> Total execution time: 1.1069
DEBUG - 2011-08-29 01:43:07 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:07 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:07 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:07 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:07 --> Router Class Initialized
ERROR - 2011-08-29 01:43:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:43:18 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:18 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Router Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Output Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Input Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:43:18 --> Language Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Loader Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Controller Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:43:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:43:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:43:20 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:43:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:43:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:43:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:43:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:43:20 --> Final output sent to browser
DEBUG - 2011-08-29 01:43:20 --> Total execution time: 1.5945
DEBUG - 2011-08-29 01:43:25 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:25 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:25 --> Router Class Initialized
ERROR - 2011-08-29 01:43:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:43:33 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:33 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Router Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Output Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Input Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:43:33 --> Language Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Loader Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Controller Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:43:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:43:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:43:35 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:43:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:43:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:43:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:43:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:43:35 --> Final output sent to browser
DEBUG - 2011-08-29 01:43:35 --> Total execution time: 1.7815
DEBUG - 2011-08-29 01:43:40 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:40 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:40 --> Router Class Initialized
ERROR - 2011-08-29 01:43:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:43:47 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:47 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Router Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Output Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Input Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:43:47 --> Language Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Loader Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Controller Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:43:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:43:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:43:47 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:43:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:43:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:43:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:43:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:43:47 --> Final output sent to browser
DEBUG - 2011-08-29 01:43:47 --> Total execution time: 0.1554
DEBUG - 2011-08-29 01:43:51 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:51 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:51 --> Router Class Initialized
ERROR - 2011-08-29 01:43:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:43:56 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:56 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Router Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Output Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Input Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:43:56 --> Language Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Loader Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Controller Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:43:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:43:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:43:57 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:43:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:43:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:43:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:43:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:43:57 --> Final output sent to browser
DEBUG - 2011-08-29 01:43:57 --> Total execution time: 0.6953
DEBUG - 2011-08-29 01:43:59 --> Config Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:43:59 --> URI Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Router Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Output Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Input Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:43:59 --> Language Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Loader Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Controller Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Model Class Initialized
DEBUG - 2011-08-29 01:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:43:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:43:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:43:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:43:59 --> Final output sent to browser
DEBUG - 2011-08-29 01:43:59 --> Total execution time: 0.0515
DEBUG - 2011-08-29 01:44:03 --> Config Class Initialized
DEBUG - 2011-08-29 01:44:03 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:44:03 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:44:03 --> URI Class Initialized
DEBUG - 2011-08-29 01:44:03 --> Router Class Initialized
ERROR - 2011-08-29 01:44:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:44:16 --> Config Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:44:16 --> URI Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Router Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Output Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Input Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:44:16 --> Language Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Loader Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Controller Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:44:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:44:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:44:17 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:44:17 --> Final output sent to browser
DEBUG - 2011-08-29 01:44:17 --> Total execution time: 0.9518
DEBUG - 2011-08-29 01:44:19 --> Config Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:44:19 --> URI Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Router Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Output Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Input Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:44:19 --> Language Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Loader Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Controller Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:44:19 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:44:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 01:44:19 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:44:19 --> Final output sent to browser
DEBUG - 2011-08-29 01:44:19 --> Total execution time: 0.0544
DEBUG - 2011-08-29 01:44:21 --> Config Class Initialized
DEBUG - 2011-08-29 01:44:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:44:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:44:21 --> URI Class Initialized
DEBUG - 2011-08-29 01:44:21 --> Router Class Initialized
ERROR - 2011-08-29 01:44:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:44:30 --> Config Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:44:30 --> URI Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Router Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Output Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Input Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:44:30 --> Language Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Loader Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Controller Class Initialized
ERROR - 2011-08-29 01:44:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 01:44:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 01:44:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 01:44:30 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:44:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:44:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 01:44:30 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:44:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:44:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:44:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:44:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:44:30 --> Final output sent to browser
DEBUG - 2011-08-29 01:44:30 --> Total execution time: 0.0521
DEBUG - 2011-08-29 01:44:32 --> Config Class Initialized
DEBUG - 2011-08-29 01:44:32 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:44:32 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:44:32 --> URI Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Router Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Output Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Input Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:44:33 --> Language Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Loader Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Controller Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Model Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:44:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:44:33 --> Final output sent to browser
DEBUG - 2011-08-29 01:44:33 --> Total execution time: 0.8533
DEBUG - 2011-08-29 01:47:15 --> Config Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:47:15 --> URI Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Router Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Output Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Input Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:47:15 --> Language Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Loader Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Controller Class Initialized
ERROR - 2011-08-29 01:47:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 01:47:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 01:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 01:47:15 --> Model Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Model Class Initialized
DEBUG - 2011-08-29 01:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:47:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 01:47:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 01:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 01:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 01:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 01:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 01:47:15 --> Final output sent to browser
DEBUG - 2011-08-29 01:47:15 --> Total execution time: 0.0323
DEBUG - 2011-08-29 01:47:18 --> Config Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:47:18 --> URI Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Router Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Output Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Input Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 01:47:18 --> Language Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Loader Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Controller Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Model Class Initialized
DEBUG - 2011-08-29 01:47:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 01:47:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 01:47:19 --> Final output sent to browser
DEBUG - 2011-08-29 01:47:19 --> Total execution time: 0.4995
DEBUG - 2011-08-29 01:47:23 --> Config Class Initialized
DEBUG - 2011-08-29 01:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:47:23 --> URI Class Initialized
DEBUG - 2011-08-29 01:47:23 --> Router Class Initialized
ERROR - 2011-08-29 01:47:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 01:47:24 --> Config Class Initialized
DEBUG - 2011-08-29 01:47:24 --> Hooks Class Initialized
DEBUG - 2011-08-29 01:47:24 --> Utf8 Class Initialized
DEBUG - 2011-08-29 01:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 01:47:24 --> URI Class Initialized
DEBUG - 2011-08-29 01:47:24 --> Router Class Initialized
ERROR - 2011-08-29 01:47:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:09:55 --> Config Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:09:55 --> URI Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Router Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Output Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Input Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:09:55 --> Language Class Initialized
DEBUG - 2011-08-29 02:09:55 --> Loader Class Initialized
DEBUG - 2011-08-29 02:09:56 --> Controller Class Initialized
DEBUG - 2011-08-29 02:09:56 --> Model Class Initialized
DEBUG - 2011-08-29 02:09:56 --> Model Class Initialized
DEBUG - 2011-08-29 02:09:56 --> Model Class Initialized
DEBUG - 2011-08-29 02:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:09:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:09:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:09:57 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:09:57 --> Final output sent to browser
DEBUG - 2011-08-29 02:09:57 --> Total execution time: 1.7143
DEBUG - 2011-08-29 02:10:08 --> Config Class Initialized
DEBUG - 2011-08-29 02:10:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:10:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:10:08 --> URI Class Initialized
DEBUG - 2011-08-29 02:10:08 --> Router Class Initialized
ERROR - 2011-08-29 02:10:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:10:09 --> Config Class Initialized
DEBUG - 2011-08-29 02:10:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:10:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:10:09 --> URI Class Initialized
DEBUG - 2011-08-29 02:10:09 --> Router Class Initialized
ERROR - 2011-08-29 02:10:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:39:08 --> Config Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:39:08 --> URI Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Router Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Output Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Input Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:39:08 --> Language Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Loader Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Controller Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Model Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Model Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Model Class Initialized
DEBUG - 2011-08-29 02:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:39:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:39:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:39:11 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:39:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:39:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:39:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:39:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:39:11 --> Final output sent to browser
DEBUG - 2011-08-29 02:39:11 --> Total execution time: 2.9009
DEBUG - 2011-08-29 02:41:23 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:23 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:23 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:23 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:23 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:23 --> Total execution time: 0.1562
DEBUG - 2011-08-29 02:41:25 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:25 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:25 --> Router Class Initialized
ERROR - 2011-08-29 02:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:41:26 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:26 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:26 --> Router Class Initialized
ERROR - 2011-08-29 02:41:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:41:33 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:33 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:33 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:35 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:35 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:35 --> Total execution time: 2.3119
DEBUG - 2011-08-29 02:41:37 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:37 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Router Class Initialized
ERROR - 2011-08-29 02:41:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:41:37 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:37 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:37 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:37 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:37 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:37 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:37 --> Total execution time: 0.0468
DEBUG - 2011-08-29 02:41:41 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:41 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:41 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:41 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:42 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:42 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:42 --> Total execution time: 0.5575
DEBUG - 2011-08-29 02:41:43 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:43 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:43 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:43 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:43 --> Router Class Initialized
ERROR - 2011-08-29 02:41:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:41:44 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:44 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:44 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:44 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:44 --> Total execution time: 0.1526
DEBUG - 2011-08-29 02:41:47 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:47 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:47 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:48 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:48 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:48 --> Total execution time: 0.6209
DEBUG - 2011-08-29 02:41:49 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:49 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Router Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Output Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Input Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:41:49 --> Language Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Loader Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Controller Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Model Class Initialized
DEBUG - 2011-08-29 02:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:41:49 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:41:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:41:49 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:41:49 --> Final output sent to browser
DEBUG - 2011-08-29 02:41:49 --> Total execution time: 0.0537
DEBUG - 2011-08-29 02:41:52 --> Config Class Initialized
DEBUG - 2011-08-29 02:41:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:41:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:41:52 --> URI Class Initialized
DEBUG - 2011-08-29 02:41:52 --> Router Class Initialized
ERROR - 2011-08-29 02:41:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:07 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:07 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:07 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:08 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Router Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Output Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Input Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:42:08 --> Language Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Loader Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Controller Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Model Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Model Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Model Class Initialized
DEBUG - 2011-08-29 02:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:42:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:42:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:42:16 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:42:16 --> Final output sent to browser
DEBUG - 2011-08-29 02:42:16 --> Total execution time: 8.2601
DEBUG - 2011-08-29 02:42:18 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:18 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:18 --> Router Class Initialized
ERROR - 2011-08-29 02:42:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:19 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:19 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Router Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Output Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Input Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:42:19 --> Language Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Loader Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Controller Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Model Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Model Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Model Class Initialized
DEBUG - 2011-08-29 02:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:42:19 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:42:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 02:42:19 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:42:19 --> Final output sent to browser
DEBUG - 2011-08-29 02:42:19 --> Total execution time: 0.0908
DEBUG - 2011-08-29 02:42:33 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:33 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:33 --> Router Class Initialized
ERROR - 2011-08-29 02:42:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:35 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:35 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:35 --> Router Class Initialized
ERROR - 2011-08-29 02:42:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:36 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:36 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:36 --> Router Class Initialized
ERROR - 2011-08-29 02:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:37 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:37 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:37 --> Router Class Initialized
ERROR - 2011-08-29 02:42:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:40 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:40 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:40 --> Router Class Initialized
ERROR - 2011-08-29 02:42:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:41 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:41 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:41 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:41 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:41 --> Router Class Initialized
ERROR - 2011-08-29 02:42:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:42:47 --> Config Class Initialized
DEBUG - 2011-08-29 02:42:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:42:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:42:47 --> URI Class Initialized
DEBUG - 2011-08-29 02:42:47 --> Router Class Initialized
ERROR - 2011-08-29 02:42:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:48:15 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:15 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Router Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Output Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Input Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:48:15 --> Language Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Loader Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Controller Class Initialized
ERROR - 2011-08-29 02:48:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 02:48:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 02:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 02:48:15 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:48:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 02:48:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:48:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:48:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:48:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:48:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:48:15 --> Final output sent to browser
DEBUG - 2011-08-29 02:48:15 --> Total execution time: 0.0821
DEBUG - 2011-08-29 02:48:18 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:18 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Router Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Output Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Input Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:48:18 --> Language Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Loader Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Controller Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:48:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:48:19 --> Final output sent to browser
DEBUG - 2011-08-29 02:48:19 --> Total execution time: 0.8031
DEBUG - 2011-08-29 02:48:21 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:21 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:21 --> Router Class Initialized
ERROR - 2011-08-29 02:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:48:22 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:22 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:22 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:22 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:22 --> Router Class Initialized
ERROR - 2011-08-29 02:48:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:48:37 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:37 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Router Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Output Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Input Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:48:37 --> Language Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Loader Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Controller Class Initialized
ERROR - 2011-08-29 02:48:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 02:48:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 02:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 02:48:37 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:48:37 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 02:48:37 --> Helper loaded: url_helper
DEBUG - 2011-08-29 02:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 02:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 02:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 02:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 02:48:37 --> Final output sent to browser
DEBUG - 2011-08-29 02:48:37 --> Total execution time: 0.0359
DEBUG - 2011-08-29 02:48:41 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:41 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Router Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Output Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Input Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 02:48:41 --> Language Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Loader Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Controller Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Model Class Initialized
DEBUG - 2011-08-29 02:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 02:48:41 --> Database Driver Class Initialized
DEBUG - 2011-08-29 02:48:42 --> Final output sent to browser
DEBUG - 2011-08-29 02:48:42 --> Total execution time: 0.7207
DEBUG - 2011-08-29 02:48:44 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:44 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:45 --> Router Class Initialized
ERROR - 2011-08-29 02:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 02:48:45 --> Config Class Initialized
DEBUG - 2011-08-29 02:48:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 02:48:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 02:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 02:48:45 --> URI Class Initialized
DEBUG - 2011-08-29 02:48:45 --> Router Class Initialized
ERROR - 2011-08-29 02:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 03:32:18 --> Config Class Initialized
DEBUG - 2011-08-29 03:32:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 03:32:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 03:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 03:32:18 --> URI Class Initialized
DEBUG - 2011-08-29 03:32:18 --> Router Class Initialized
ERROR - 2011-08-29 03:32:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 03:52:51 --> Config Class Initialized
DEBUG - 2011-08-29 03:52:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 03:52:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 03:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 03:52:51 --> URI Class Initialized
DEBUG - 2011-08-29 03:52:51 --> Router Class Initialized
ERROR - 2011-08-29 03:52:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 04:20:15 --> Config Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 04:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 04:20:15 --> URI Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Router Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Output Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Input Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 04:20:15 --> Language Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Loader Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Controller Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Model Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Model Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Model Class Initialized
DEBUG - 2011-08-29 04:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 04:20:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 04:20:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 04:20:18 --> Helper loaded: url_helper
DEBUG - 2011-08-29 04:20:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 04:20:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 04:20:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 04:20:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 04:20:18 --> Final output sent to browser
DEBUG - 2011-08-29 04:20:18 --> Total execution time: 3.4556
DEBUG - 2011-08-29 04:24:14 --> Config Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 04:24:14 --> URI Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Router Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Output Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Input Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 04:24:14 --> Language Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Loader Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Controller Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Model Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Model Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Model Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 04:24:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Config Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 04:24:14 --> URI Class Initialized
DEBUG - 2011-08-29 04:24:14 --> Router Class Initialized
ERROR - 2011-08-29 04:24:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 04:24:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 04:24:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 04:24:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 04:24:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 04:24:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 04:24:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 04:24:15 --> Final output sent to browser
DEBUG - 2011-08-29 04:24:15 --> Total execution time: 1.5704
DEBUG - 2011-08-29 04:25:48 --> Config Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Hooks Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Utf8 Class Initialized
DEBUG - 2011-08-29 04:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 04:25:48 --> URI Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Router Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Output Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Input Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 04:25:48 --> Language Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Loader Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Controller Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Model Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Model Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Model Class Initialized
DEBUG - 2011-08-29 04:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 04:25:48 --> Database Driver Class Initialized
DEBUG - 2011-08-29 04:25:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 04:25:50 --> Helper loaded: url_helper
DEBUG - 2011-08-29 04:25:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 04:25:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 04:25:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 04:25:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 04:25:50 --> Final output sent to browser
DEBUG - 2011-08-29 04:25:50 --> Total execution time: 2.7162
DEBUG - 2011-08-29 04:25:54 --> Config Class Initialized
DEBUG - 2011-08-29 04:25:54 --> Hooks Class Initialized
DEBUG - 2011-08-29 04:25:54 --> Utf8 Class Initialized
DEBUG - 2011-08-29 04:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 04:25:54 --> URI Class Initialized
DEBUG - 2011-08-29 04:25:54 --> Router Class Initialized
ERROR - 2011-08-29 04:25:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 04:27:30 --> Config Class Initialized
DEBUG - 2011-08-29 04:27:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 04:27:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 04:27:30 --> URI Class Initialized
DEBUG - 2011-08-29 04:27:30 --> Router Class Initialized
ERROR - 2011-08-29 04:27:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 05:09:32 --> Config Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:09:32 --> URI Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Router Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Output Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Input Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:09:32 --> Language Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Loader Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Controller Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:09:32 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:09:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 05:09:33 --> Helper loaded: url_helper
DEBUG - 2011-08-29 05:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 05:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 05:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 05:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 05:09:33 --> Final output sent to browser
DEBUG - 2011-08-29 05:09:33 --> Total execution time: 0.5237
DEBUG - 2011-08-29 05:09:34 --> Config Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:09:34 --> URI Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Router Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Output Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Input Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:09:34 --> Language Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Loader Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Controller Class Initialized
ERROR - 2011-08-29 05:09:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 05:09:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 05:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 05:09:34 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:09:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 05:09:34 --> Helper loaded: url_helper
DEBUG - 2011-08-29 05:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 05:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 05:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 05:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 05:09:34 --> Final output sent to browser
DEBUG - 2011-08-29 05:09:34 --> Total execution time: 0.0831
DEBUG - 2011-08-29 05:09:34 --> Config Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:09:34 --> URI Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Router Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Output Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Input Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:09:34 --> Language Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Loader Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Controller Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Model Class Initialized
DEBUG - 2011-08-29 05:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:09:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:09:35 --> Final output sent to browser
DEBUG - 2011-08-29 05:09:35 --> Total execution time: 0.6850
DEBUG - 2011-08-29 05:09:36 --> Config Class Initialized
DEBUG - 2011-08-29 05:09:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:09:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:09:36 --> URI Class Initialized
DEBUG - 2011-08-29 05:09:36 --> Router Class Initialized
ERROR - 2011-08-29 05:09:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 05:11:12 --> Config Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:11:12 --> URI Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Router Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Output Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Input Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:11:12 --> Language Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Loader Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Controller Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Model Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Model Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Model Class Initialized
DEBUG - 2011-08-29 05:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:11:12 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:11:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 05:11:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 05:11:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 05:11:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 05:11:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 05:11:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 05:11:12 --> Final output sent to browser
DEBUG - 2011-08-29 05:11:12 --> Total execution time: 0.0439
DEBUG - 2011-08-29 05:11:15 --> Config Class Initialized
DEBUG - 2011-08-29 05:11:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:11:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:11:15 --> URI Class Initialized
DEBUG - 2011-08-29 05:11:15 --> Router Class Initialized
ERROR - 2011-08-29 05:11:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 05:24:09 --> Config Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:24:09 --> URI Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Router Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Output Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Input Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:24:09 --> Language Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Loader Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Controller Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Model Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Model Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Model Class Initialized
DEBUG - 2011-08-29 05:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:24:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:24:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 05:24:09 --> Helper loaded: url_helper
DEBUG - 2011-08-29 05:24:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 05:24:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 05:24:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 05:24:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 05:24:09 --> Final output sent to browser
DEBUG - 2011-08-29 05:24:09 --> Total execution time: 0.0674
DEBUG - 2011-08-29 05:24:15 --> Config Class Initialized
DEBUG - 2011-08-29 05:24:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:24:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:24:15 --> URI Class Initialized
DEBUG - 2011-08-29 05:24:15 --> Router Class Initialized
ERROR - 2011-08-29 05:24:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 05:24:28 --> Config Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:24:28 --> URI Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Router Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Output Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Input Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:24:28 --> Language Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Loader Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Controller Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Model Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Model Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Model Class Initialized
DEBUG - 2011-08-29 05:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:24:28 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:24:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 05:24:29 --> Helper loaded: url_helper
DEBUG - 2011-08-29 05:24:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 05:24:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 05:24:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 05:24:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 05:24:29 --> Final output sent to browser
DEBUG - 2011-08-29 05:24:29 --> Total execution time: 1.3698
DEBUG - 2011-08-29 05:24:33 --> Config Class Initialized
DEBUG - 2011-08-29 05:24:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:24:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:24:33 --> URI Class Initialized
DEBUG - 2011-08-29 05:24:33 --> Router Class Initialized
ERROR - 2011-08-29 05:24:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 05:52:16 --> Config Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 05:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 05:52:16 --> URI Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Router Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Output Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Input Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 05:52:16 --> Language Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Loader Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Controller Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Model Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Model Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Model Class Initialized
DEBUG - 2011-08-29 05:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 05:52:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 05:52:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 05:52:16 --> Helper loaded: url_helper
DEBUG - 2011-08-29 05:52:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 05:52:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 05:52:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 05:52:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 05:52:16 --> Final output sent to browser
DEBUG - 2011-08-29 05:52:16 --> Total execution time: 0.4323
DEBUG - 2011-08-29 06:13:08 --> Config Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:13:08 --> URI Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Router Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Output Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Input Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:13:08 --> Language Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Loader Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Controller Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Model Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Model Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Model Class Initialized
DEBUG - 2011-08-29 06:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:13:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:13:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 06:13:08 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:13:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:13:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:13:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:13:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:13:08 --> Final output sent to browser
DEBUG - 2011-08-29 06:13:08 --> Total execution time: 0.1826
DEBUG - 2011-08-29 06:13:09 --> Config Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:13:09 --> URI Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Router Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Output Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Input Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:13:09 --> Language Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Loader Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Controller Class Initialized
ERROR - 2011-08-29 06:13:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:13:09 --> Model Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Model Class Initialized
DEBUG - 2011-08-29 06:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:13:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:13:09 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:13:09 --> Final output sent to browser
DEBUG - 2011-08-29 06:13:09 --> Total execution time: 0.0767
DEBUG - 2011-08-29 06:15:16 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:16 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Router Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Output Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Input Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:15:16 --> Language Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Loader Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Controller Class Initialized
ERROR - 2011-08-29 06:15:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:15:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:15:16 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:15:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:15:16 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:15:16 --> Final output sent to browser
DEBUG - 2011-08-29 06:15:16 --> Total execution time: 0.0350
DEBUG - 2011-08-29 06:15:18 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:18 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Router Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Output Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Input Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:15:18 --> Language Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Loader Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Controller Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:15:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:15:19 --> Final output sent to browser
DEBUG - 2011-08-29 06:15:19 --> Total execution time: 0.8830
DEBUG - 2011-08-29 06:15:27 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:27 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:27 --> Router Class Initialized
ERROR - 2011-08-29 06:15:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:15:27 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:27 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:27 --> Router Class Initialized
ERROR - 2011-08-29 06:15:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:15:50 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:50 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Router Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Output Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Input Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:15:50 --> Language Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Loader Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Controller Class Initialized
ERROR - 2011-08-29 06:15:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:15:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:15:50 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:15:50 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:15:50 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:15:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:15:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:15:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:15:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:15:50 --> Final output sent to browser
DEBUG - 2011-08-29 06:15:50 --> Total execution time: 0.0285
DEBUG - 2011-08-29 06:15:51 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:51 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Router Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Output Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Input Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:15:51 --> Language Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Loader Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Controller Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:15:51 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:15:51 --> Final output sent to browser
DEBUG - 2011-08-29 06:15:51 --> Total execution time: 0.5415
DEBUG - 2011-08-29 06:15:59 --> Config Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:15:59 --> URI Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Router Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Output Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Input Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:15:59 --> Language Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Loader Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Controller Class Initialized
ERROR - 2011-08-29 06:15:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:15:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:15:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:15:59 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Model Class Initialized
DEBUG - 2011-08-29 06:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:15:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:15:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:15:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:15:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:15:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:15:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:15:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:15:59 --> Final output sent to browser
DEBUG - 2011-08-29 06:15:59 --> Total execution time: 0.0306
DEBUG - 2011-08-29 06:16:00 --> Config Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:16:00 --> URI Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Router Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Output Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Input Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:16:00 --> Language Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Loader Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Controller Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:16:00 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:16:00 --> Final output sent to browser
DEBUG - 2011-08-29 06:16:00 --> Total execution time: 0.6200
DEBUG - 2011-08-29 06:16:03 --> Config Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:16:03 --> URI Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Router Class Initialized
ERROR - 2011-08-29 06:16:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 06:16:03 --> Config Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:16:03 --> URI Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Router Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Output Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Input Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:16:03 --> Language Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Loader Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Controller Class Initialized
ERROR - 2011-08-29 06:16:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:16:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:16:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:16:03 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:16:03 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:16:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:16:03 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:16:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:16:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:16:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:16:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:16:03 --> Final output sent to browser
DEBUG - 2011-08-29 06:16:03 --> Total execution time: 0.0320
DEBUG - 2011-08-29 06:16:08 --> Config Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:16:08 --> URI Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Router Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Output Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Input Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:16:08 --> Language Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Loader Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Controller Class Initialized
ERROR - 2011-08-29 06:16:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:16:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:16:08 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:16:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:16:08 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:16:08 --> Final output sent to browser
DEBUG - 2011-08-29 06:16:08 --> Total execution time: 0.0566
DEBUG - 2011-08-29 06:16:09 --> Config Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:16:09 --> URI Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Router Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Output Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Input Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:16:09 --> Language Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Loader Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Controller Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Model Class Initialized
DEBUG - 2011-08-29 06:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:16:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:16:10 --> Final output sent to browser
DEBUG - 2011-08-29 06:16:10 --> Total execution time: 0.7625
DEBUG - 2011-08-29 06:30:28 --> Config Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:30:28 --> URI Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Router Class Initialized
DEBUG - 2011-08-29 06:30:28 --> No URI present. Default controller set.
DEBUG - 2011-08-29 06:30:28 --> Output Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Input Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:30:28 --> Language Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Loader Class Initialized
DEBUG - 2011-08-29 06:30:28 --> Controller Class Initialized
DEBUG - 2011-08-29 06:30:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 06:30:29 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:30:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:30:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:30:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:30:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:30:29 --> Final output sent to browser
DEBUG - 2011-08-29 06:30:29 --> Total execution time: 0.0496
DEBUG - 2011-08-29 06:32:59 --> Config Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:32:59 --> URI Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Router Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Output Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Input Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:32:59 --> Language Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Loader Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Controller Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Model Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Model Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Model Class Initialized
DEBUG - 2011-08-29 06:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:32:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:32:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 06:32:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:32:59 --> Final output sent to browser
DEBUG - 2011-08-29 06:32:59 --> Total execution time: 0.1635
DEBUG - 2011-08-29 06:33:00 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:00 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Router Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Output Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Input Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:33:00 --> Language Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Loader Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Controller Class Initialized
ERROR - 2011-08-29 06:33:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:33:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:33:00 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:33:00 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:33:00 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:33:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:33:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:33:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:33:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:33:00 --> Final output sent to browser
DEBUG - 2011-08-29 06:33:00 --> Total execution time: 0.0791
DEBUG - 2011-08-29 06:33:01 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:01 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Router Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Output Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Input Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:33:01 --> Language Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Loader Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Controller Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:33:01 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:33:02 --> Final output sent to browser
DEBUG - 2011-08-29 06:33:02 --> Total execution time: 0.6726
DEBUG - 2011-08-29 06:33:04 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:04 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Router Class Initialized
ERROR - 2011-08-29 06:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:33:04 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:04 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Router Class Initialized
ERROR - 2011-08-29 06:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:33:04 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:04 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:04 --> Router Class Initialized
ERROR - 2011-08-29 06:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:33:12 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:12 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Router Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Output Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Input Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:33:12 --> Language Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Loader Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Controller Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:33:12 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:33:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 06:33:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:33:12 --> Final output sent to browser
DEBUG - 2011-08-29 06:33:12 --> Total execution time: 0.3150
DEBUG - 2011-08-29 06:33:13 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:13 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Router Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Output Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Input Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:33:13 --> Language Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Loader Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Controller Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Model Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:33:13 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:33:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 06:33:13 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:33:13 --> Final output sent to browser
DEBUG - 2011-08-29 06:33:13 --> Total execution time: 0.0480
DEBUG - 2011-08-29 06:33:13 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:13 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:13 --> Router Class Initialized
ERROR - 2011-08-29 06:33:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:33:14 --> Config Class Initialized
DEBUG - 2011-08-29 06:33:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:33:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:33:14 --> URI Class Initialized
DEBUG - 2011-08-29 06:33:14 --> Router Class Initialized
ERROR - 2011-08-29 06:33:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 06:34:01 --> Config Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:34:01 --> URI Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Router Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Output Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Input Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:34:01 --> Language Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Loader Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Controller Class Initialized
ERROR - 2011-08-29 06:34:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 06:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 06:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:34:01 --> Model Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Model Class Initialized
DEBUG - 2011-08-29 06:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:34:01 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 06:34:01 --> Helper loaded: url_helper
DEBUG - 2011-08-29 06:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 06:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 06:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 06:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 06:34:01 --> Final output sent to browser
DEBUG - 2011-08-29 06:34:01 --> Total execution time: 0.0295
DEBUG - 2011-08-29 06:34:02 --> Config Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:34:02 --> URI Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Router Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Output Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Input Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 06:34:02 --> Language Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Loader Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Controller Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Model Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Model Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 06:34:02 --> Database Driver Class Initialized
DEBUG - 2011-08-29 06:34:02 --> Final output sent to browser
DEBUG - 2011-08-29 06:34:02 --> Total execution time: 0.4934
DEBUG - 2011-08-29 06:34:04 --> Config Class Initialized
DEBUG - 2011-08-29 06:34:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 06:34:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 06:34:04 --> URI Class Initialized
DEBUG - 2011-08-29 06:34:04 --> Router Class Initialized
ERROR - 2011-08-29 06:34:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 07:33:49 --> Config Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 07:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 07:33:49 --> URI Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Router Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Output Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Input Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 07:33:49 --> Language Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Loader Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Controller Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Model Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Model Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Model Class Initialized
DEBUG - 2011-08-29 07:33:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 07:33:50 --> Database Driver Class Initialized
DEBUG - 2011-08-29 07:33:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 07:33:50 --> Helper loaded: url_helper
DEBUG - 2011-08-29 07:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 07:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 07:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 07:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 07:33:50 --> Final output sent to browser
DEBUG - 2011-08-29 07:33:50 --> Total execution time: 1.0355
DEBUG - 2011-08-29 07:34:02 --> Config Class Initialized
DEBUG - 2011-08-29 07:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 07:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 07:34:02 --> URI Class Initialized
DEBUG - 2011-08-29 07:34:02 --> Router Class Initialized
ERROR - 2011-08-29 07:34:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 07:34:12 --> Config Class Initialized
DEBUG - 2011-08-29 07:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 07:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 07:34:12 --> URI Class Initialized
DEBUG - 2011-08-29 07:34:12 --> Router Class Initialized
ERROR - 2011-08-29 07:34:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 07:46:35 --> Config Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 07:46:35 --> URI Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Router Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Output Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Input Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 07:46:35 --> Language Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Loader Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Controller Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Model Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Model Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Model Class Initialized
DEBUG - 2011-08-29 07:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 07:46:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 07:46:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 07:46:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 07:46:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 07:46:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 07:46:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 07:46:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 07:46:36 --> Final output sent to browser
DEBUG - 2011-08-29 07:46:36 --> Total execution time: 0.6314
DEBUG - 2011-08-29 07:46:40 --> Config Class Initialized
DEBUG - 2011-08-29 07:46:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 07:46:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 07:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 07:46:40 --> URI Class Initialized
DEBUG - 2011-08-29 07:46:40 --> Router Class Initialized
ERROR - 2011-08-29 07:46:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 08:06:47 --> Config Class Initialized
DEBUG - 2011-08-29 08:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:06:47 --> URI Class Initialized
DEBUG - 2011-08-29 08:06:47 --> Router Class Initialized
ERROR - 2011-08-29 08:06:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 08:59:08 --> Config Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:59:08 --> URI Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Router Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Output Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Input Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 08:59:08 --> Language Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Loader Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Controller Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 08:59:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 08:59:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 08:59:08 --> Helper loaded: url_helper
DEBUG - 2011-08-29 08:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 08:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 08:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 08:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 08:59:08 --> Final output sent to browser
DEBUG - 2011-08-29 08:59:08 --> Total execution time: 0.7030
DEBUG - 2011-08-29 08:59:19 --> Config Class Initialized
DEBUG - 2011-08-29 08:59:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:59:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:59:19 --> URI Class Initialized
DEBUG - 2011-08-29 08:59:19 --> Router Class Initialized
ERROR - 2011-08-29 08:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 08:59:19 --> Config Class Initialized
DEBUG - 2011-08-29 08:59:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:59:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:59:19 --> URI Class Initialized
DEBUG - 2011-08-29 08:59:19 --> Router Class Initialized
ERROR - 2011-08-29 08:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 08:59:30 --> Config Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:59:30 --> URI Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Router Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Output Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Input Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 08:59:30 --> Language Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Loader Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Controller Class Initialized
ERROR - 2011-08-29 08:59:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 08:59:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 08:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 08:59:30 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 08:59:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 08:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 08:59:30 --> Helper loaded: url_helper
DEBUG - 2011-08-29 08:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 08:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 08:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 08:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 08:59:30 --> Final output sent to browser
DEBUG - 2011-08-29 08:59:30 --> Total execution time: 0.0890
DEBUG - 2011-08-29 08:59:31 --> Config Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:59:31 --> URI Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Router Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Output Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Input Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 08:59:31 --> Language Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Loader Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Controller Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Model Class Initialized
DEBUG - 2011-08-29 08:59:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 08:59:31 --> Database Driver Class Initialized
DEBUG - 2011-08-29 08:59:32 --> Final output sent to browser
DEBUG - 2011-08-29 08:59:32 --> Total execution time: 0.7843
DEBUG - 2011-08-29 08:59:40 --> Config Class Initialized
DEBUG - 2011-08-29 08:59:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 08:59:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 08:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 08:59:40 --> URI Class Initialized
DEBUG - 2011-08-29 08:59:40 --> Router Class Initialized
ERROR - 2011-08-29 08:59:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 10:17:04 --> Config Class Initialized
DEBUG - 2011-08-29 10:17:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 10:17:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 10:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 10:17:04 --> URI Class Initialized
DEBUG - 2011-08-29 10:17:04 --> Router Class Initialized
DEBUG - 2011-08-29 10:17:04 --> Output Class Initialized
DEBUG - 2011-08-29 10:17:04 --> Input Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 10:17:05 --> Language Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Loader Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Controller Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Model Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Model Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Model Class Initialized
DEBUG - 2011-08-29 10:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 10:17:05 --> Database Driver Class Initialized
DEBUG - 2011-08-29 10:17:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 10:17:05 --> Helper loaded: url_helper
DEBUG - 2011-08-29 10:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 10:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 10:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 10:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 10:17:05 --> Final output sent to browser
DEBUG - 2011-08-29 10:17:05 --> Total execution time: 0.6907
DEBUG - 2011-08-29 10:17:10 --> Config Class Initialized
DEBUG - 2011-08-29 10:17:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 10:17:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 10:17:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 10:17:10 --> URI Class Initialized
DEBUG - 2011-08-29 10:17:10 --> Router Class Initialized
ERROR - 2011-08-29 10:17:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 10:17:10 --> Config Class Initialized
DEBUG - 2011-08-29 10:17:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 10:17:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 10:17:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 10:17:10 --> URI Class Initialized
DEBUG - 2011-08-29 10:17:10 --> Router Class Initialized
ERROR - 2011-08-29 10:17:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 10:48:47 --> Config Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 10:48:47 --> URI Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Router Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Output Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Input Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 10:48:47 --> Language Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Loader Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Controller Class Initialized
ERROR - 2011-08-29 10:48:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 10:48:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 10:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 10:48:47 --> Model Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Model Class Initialized
DEBUG - 2011-08-29 10:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 10:48:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 10:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 10:48:47 --> Helper loaded: url_helper
DEBUG - 2011-08-29 10:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 10:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 10:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 10:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 10:48:47 --> Final output sent to browser
DEBUG - 2011-08-29 10:48:47 --> Total execution time: 0.1860
DEBUG - 2011-08-29 10:48:59 --> Config Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 10:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 10:48:59 --> URI Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Router Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Output Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Input Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 10:48:59 --> Language Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Loader Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Controller Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Model Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Model Class Initialized
DEBUG - 2011-08-29 10:48:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 10:48:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 10:49:00 --> Final output sent to browser
DEBUG - 2011-08-29 10:49:00 --> Total execution time: 0.9164
DEBUG - 2011-08-29 11:06:02 --> Config Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:06:02 --> URI Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Router Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Output Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Input Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:06:02 --> Language Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Loader Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Controller Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:06:02 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:06:02 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:06:02 --> Final output sent to browser
DEBUG - 2011-08-29 11:06:02 --> Total execution time: 0.7635
DEBUG - 2011-08-29 11:06:15 --> Config Class Initialized
DEBUG - 2011-08-29 11:06:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:06:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:06:15 --> URI Class Initialized
DEBUG - 2011-08-29 11:06:15 --> Router Class Initialized
ERROR - 2011-08-29 11:06:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 11:06:16 --> Config Class Initialized
DEBUG - 2011-08-29 11:06:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:06:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:06:16 --> URI Class Initialized
DEBUG - 2011-08-29 11:06:16 --> Router Class Initialized
ERROR - 2011-08-29 11:06:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 11:06:25 --> Config Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:06:25 --> URI Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Router Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Output Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Input Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:06:25 --> Language Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Loader Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Controller Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:06:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:06:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:06:26 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:06:26 --> Final output sent to browser
DEBUG - 2011-08-29 11:06:26 --> Total execution time: 0.3075
DEBUG - 2011-08-29 11:06:37 --> Config Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:06:37 --> URI Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Router Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Output Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Input Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:06:37 --> Language Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Loader Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Controller Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:06:37 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:06:37 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:06:37 --> Final output sent to browser
DEBUG - 2011-08-29 11:06:37 --> Total execution time: 0.3635
DEBUG - 2011-08-29 11:06:55 --> Config Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:06:55 --> URI Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Router Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Output Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Input Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:06:55 --> Language Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Loader Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Controller Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Model Class Initialized
DEBUG - 2011-08-29 11:06:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:06:55 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:06:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:06:55 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:06:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:06:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:06:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:06:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:06:55 --> Final output sent to browser
DEBUG - 2011-08-29 11:06:55 --> Total execution time: 0.3733
DEBUG - 2011-08-29 11:07:09 --> Config Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:07:09 --> URI Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Router Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Output Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Input Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:07:09 --> Language Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Loader Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Controller Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:07:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:07:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:07:09 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:07:09 --> Final output sent to browser
DEBUG - 2011-08-29 11:07:09 --> Total execution time: 0.2377
DEBUG - 2011-08-29 11:07:21 --> Config Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:07:21 --> URI Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Router Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Output Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Input Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:07:21 --> Language Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Loader Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Controller Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:07:21 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:07:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:07:22 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:07:22 --> Final output sent to browser
DEBUG - 2011-08-29 11:07:22 --> Total execution time: 0.2184
DEBUG - 2011-08-29 11:07:36 --> Config Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:07:36 --> URI Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Router Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Output Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Input Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:07:36 --> Language Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Loader Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Controller Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:07:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:07:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:07:36 --> Final output sent to browser
DEBUG - 2011-08-29 11:07:36 --> Total execution time: 0.2769
DEBUG - 2011-08-29 11:07:56 --> Config Class Initialized
DEBUG - 2011-08-29 11:07:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:07:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:07:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:07:56 --> URI Class Initialized
DEBUG - 2011-08-29 11:07:56 --> Router Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Output Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Input Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:07:57 --> Language Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Loader Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Controller Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Model Class Initialized
DEBUG - 2011-08-29 11:07:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:07:57 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:07:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:07:57 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:07:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:07:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:07:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:07:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:07:57 --> Final output sent to browser
DEBUG - 2011-08-29 11:07:57 --> Total execution time: 0.4544
DEBUG - 2011-08-29 11:08:18 --> Config Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:08:18 --> URI Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Router Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Output Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Input Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:08:18 --> Language Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Loader Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Controller Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:08:18 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:08:18 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:08:18 --> Final output sent to browser
DEBUG - 2011-08-29 11:08:18 --> Total execution time: 0.2481
DEBUG - 2011-08-29 11:08:29 --> Config Class Initialized
DEBUG - 2011-08-29 11:08:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:08:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:08:30 --> URI Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Router Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Output Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Input Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:08:30 --> Language Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Loader Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Controller Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:08:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:08:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:08:31 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:08:31 --> Final output sent to browser
DEBUG - 2011-08-29 11:08:31 --> Total execution time: 1.1131
DEBUG - 2011-08-29 11:08:44 --> Config Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:08:44 --> URI Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Router Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Output Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Input Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:08:44 --> Language Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Loader Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Controller Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:08:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:08:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:08:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:08:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:08:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:08:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:08:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:08:44 --> Final output sent to browser
DEBUG - 2011-08-29 11:08:44 --> Total execution time: 0.3854
DEBUG - 2011-08-29 11:08:56 --> Config Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:08:56 --> URI Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Router Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Output Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Input Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:08:56 --> Language Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Loader Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Controller Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Model Class Initialized
DEBUG - 2011-08-29 11:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:08:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:08:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:08:56 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:08:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:08:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:08:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:08:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:08:56 --> Final output sent to browser
DEBUG - 2011-08-29 11:08:56 --> Total execution time: 0.3264
DEBUG - 2011-08-29 11:09:09 --> Config Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:09:09 --> URI Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Router Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Output Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Input Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:09:09 --> Language Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Loader Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Controller Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:09:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:09:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:09:09 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:09:09 --> Final output sent to browser
DEBUG - 2011-08-29 11:09:09 --> Total execution time: 0.5005
DEBUG - 2011-08-29 11:09:20 --> Config Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:09:20 --> URI Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Router Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Output Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Input Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:09:20 --> Language Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Loader Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Controller Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:09:20 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:09:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:09:21 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:09:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:09:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:09:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:09:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:09:21 --> Final output sent to browser
DEBUG - 2011-08-29 11:09:21 --> Total execution time: 0.4879
DEBUG - 2011-08-29 11:09:39 --> Config Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:09:39 --> URI Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Router Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Output Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Input Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:09:39 --> Language Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Loader Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Controller Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:09:39 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:09:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:09:40 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:09:40 --> Final output sent to browser
DEBUG - 2011-08-29 11:09:40 --> Total execution time: 0.2778
DEBUG - 2011-08-29 11:09:59 --> Config Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:09:59 --> URI Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Router Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Output Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Input Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:09:59 --> Language Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Loader Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Controller Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Model Class Initialized
DEBUG - 2011-08-29 11:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:09:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:09:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:09:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:09:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:09:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:09:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:09:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:09:59 --> Final output sent to browser
DEBUG - 2011-08-29 11:09:59 --> Total execution time: 0.5453
DEBUG - 2011-08-29 11:10:07 --> Config Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:10:07 --> URI Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Router Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Output Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Input Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:10:07 --> Language Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Loader Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Controller Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Model Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Model Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Model Class Initialized
DEBUG - 2011-08-29 11:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:10:07 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:10:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:10:07 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:10:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:10:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:10:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:10:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:10:07 --> Final output sent to browser
DEBUG - 2011-08-29 11:10:07 --> Total execution time: 0.2509
DEBUG - 2011-08-29 11:10:36 --> Config Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:10:36 --> URI Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Router Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Output Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Input Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:10:36 --> Language Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Loader Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Controller Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Model Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Model Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Model Class Initialized
DEBUG - 2011-08-29 11:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:10:36 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:10:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:10:36 --> Final output sent to browser
DEBUG - 2011-08-29 11:10:36 --> Total execution time: 0.2680
DEBUG - 2011-08-29 11:30:27 --> Config Class Initialized
DEBUG - 2011-08-29 11:30:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:30:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:30:27 --> URI Class Initialized
DEBUG - 2011-08-29 11:30:27 --> Router Class Initialized
ERROR - 2011-08-29 11:30:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 11:30:28 --> Config Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:30:28 --> URI Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Router Class Initialized
DEBUG - 2011-08-29 11:30:28 --> No URI present. Default controller set.
DEBUG - 2011-08-29 11:30:28 --> Output Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Input Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:30:28 --> Language Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Loader Class Initialized
DEBUG - 2011-08-29 11:30:28 --> Controller Class Initialized
DEBUG - 2011-08-29 11:30:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 11:30:28 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:30:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:30:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:30:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:30:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:30:28 --> Final output sent to browser
DEBUG - 2011-08-29 11:30:28 --> Total execution time: 0.0709
DEBUG - 2011-08-29 11:30:29 --> Config Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:30:29 --> URI Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Router Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Output Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Input Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:30:29 --> Language Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Loader Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Controller Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Model Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Model Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Model Class Initialized
DEBUG - 2011-08-29 11:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:30:29 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:30:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:30:29 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:30:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:30:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:30:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:30:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:30:29 --> Final output sent to browser
DEBUG - 2011-08-29 11:30:29 --> Total execution time: 0.0744
DEBUG - 2011-08-29 11:30:30 --> Config Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:30:30 --> URI Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Router Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Output Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Input Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:30:30 --> Language Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Loader Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Controller Class Initialized
ERROR - 2011-08-29 11:30:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 11:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 11:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 11:30:30 --> Model Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Model Class Initialized
DEBUG - 2011-08-29 11:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:30:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 11:30:30 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:30:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:30:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:30:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:30:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:30:30 --> Final output sent to browser
DEBUG - 2011-08-29 11:30:30 --> Total execution time: 0.0294
DEBUG - 2011-08-29 11:53:06 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:06 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Router Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Output Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Input Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:53:06 --> Language Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Loader Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Controller Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:53:06 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:53:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:53:06 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:53:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:53:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:53:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:53:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:53:06 --> Final output sent to browser
DEBUG - 2011-08-29 11:53:06 --> Total execution time: 0.0649
DEBUG - 2011-08-29 11:53:08 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:08 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:08 --> Router Class Initialized
ERROR - 2011-08-29 11:53:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 11:53:37 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:37 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Router Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Output Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Input Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:53:37 --> Language Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Loader Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Controller Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:53:37 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:53:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:53:38 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:53:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:53:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:53:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:53:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:53:38 --> Final output sent to browser
DEBUG - 2011-08-29 11:53:38 --> Total execution time: 0.2291
DEBUG - 2011-08-29 11:53:38 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:38 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:38 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:38 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:38 --> Router Class Initialized
ERROR - 2011-08-29 11:53:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 11:53:40 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:40 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Router Class Initialized
ERROR - 2011-08-29 11:53:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 11:53:40 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:40 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Router Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Output Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Input Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:53:40 --> Language Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Loader Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Controller Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:53:40 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:53:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:53:41 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:53:41 --> Final output sent to browser
DEBUG - 2011-08-29 11:53:41 --> Total execution time: 0.1742
DEBUG - 2011-08-29 11:53:55 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:55 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Router Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Output Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Input Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:53:55 --> Language Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Loader Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Controller Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:53:55 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:53:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:53:55 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:53:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:53:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:53:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:53:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:53:55 --> Final output sent to browser
DEBUG - 2011-08-29 11:53:55 --> Total execution time: 0.3998
DEBUG - 2011-08-29 11:53:56 --> Config Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:53:56 --> URI Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Router Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Output Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Input Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:53:56 --> Language Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Loader Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Controller Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Model Class Initialized
DEBUG - 2011-08-29 11:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:53:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:53:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:53:56 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:53:56 --> Final output sent to browser
DEBUG - 2011-08-29 11:53:56 --> Total execution time: 0.0482
DEBUG - 2011-08-29 11:55:02 --> Config Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:55:02 --> URI Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Router Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Output Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Input Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:55:02 --> Language Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Loader Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Controller Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Model Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Model Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Model Class Initialized
DEBUG - 2011-08-29 11:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:55:02 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:55:03 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:55:03 --> Final output sent to browser
DEBUG - 2011-08-29 11:55:03 --> Total execution time: 0.8555
DEBUG - 2011-08-29 11:55:04 --> Config Class Initialized
DEBUG - 2011-08-29 11:55:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:55:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:55:04 --> URI Class Initialized
DEBUG - 2011-08-29 11:55:04 --> Router Class Initialized
ERROR - 2011-08-29 11:55:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 11:55:05 --> Config Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Hooks Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Utf8 Class Initialized
DEBUG - 2011-08-29 11:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 11:55:05 --> URI Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Router Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Output Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Input Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 11:55:05 --> Language Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Loader Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Controller Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Model Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Model Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Model Class Initialized
DEBUG - 2011-08-29 11:55:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 11:55:05 --> Database Driver Class Initialized
DEBUG - 2011-08-29 11:55:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 11:55:05 --> Helper loaded: url_helper
DEBUG - 2011-08-29 11:55:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 11:55:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 11:55:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 11:55:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 11:55:05 --> Final output sent to browser
DEBUG - 2011-08-29 11:55:05 --> Total execution time: 0.0491
DEBUG - 2011-08-29 12:03:31 --> Config Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:03:31 --> URI Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Router Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Output Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Input Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:03:31 --> Language Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Loader Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Controller Class Initialized
ERROR - 2011-08-29 12:03:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:03:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:03:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:03:31 --> Model Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Model Class Initialized
DEBUG - 2011-08-29 12:03:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:03:31 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:03:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:03:31 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:03:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:03:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:03:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:03:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:03:31 --> Final output sent to browser
DEBUG - 2011-08-29 12:03:31 --> Total execution time: 0.0644
DEBUG - 2011-08-29 12:03:34 --> Config Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:03:34 --> URI Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Router Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Output Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Input Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:03:34 --> Language Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Loader Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Controller Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Model Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Model Class Initialized
DEBUG - 2011-08-29 12:03:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:03:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:03:35 --> Final output sent to browser
DEBUG - 2011-08-29 12:03:35 --> Total execution time: 0.6582
DEBUG - 2011-08-29 12:14:23 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:23 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Router Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Output Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Input Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:14:23 --> Language Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Loader Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Controller Class Initialized
ERROR - 2011-08-29 12:14:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:14:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:14:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:14:23 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:14:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:14:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:14:23 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:14:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:14:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:14:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:14:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:14:23 --> Final output sent to browser
DEBUG - 2011-08-29 12:14:23 --> Total execution time: 0.0302
DEBUG - 2011-08-29 12:14:24 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:24 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Router Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Output Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Input Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:14:24 --> Language Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Loader Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Controller Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:14:24 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:14:25 --> Final output sent to browser
DEBUG - 2011-08-29 12:14:25 --> Total execution time: 0.6922
DEBUG - 2011-08-29 12:14:26 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:26 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:26 --> Router Class Initialized
ERROR - 2011-08-29 12:14:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:14:26 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:26 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:26 --> Router Class Initialized
ERROR - 2011-08-29 12:14:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:14:50 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:50 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Router Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Output Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Input Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:14:50 --> Language Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Loader Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Controller Class Initialized
ERROR - 2011-08-29 12:14:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:14:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:14:50 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:14:50 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:14:50 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:14:50 --> Final output sent to browser
DEBUG - 2011-08-29 12:14:50 --> Total execution time: 0.1466
DEBUG - 2011-08-29 12:14:50 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:50 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Router Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Output Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Input Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:14:50 --> Language Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Loader Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Controller Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:14:50 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:14:51 --> Final output sent to browser
DEBUG - 2011-08-29 12:14:51 --> Total execution time: 0.6301
DEBUG - 2011-08-29 12:14:51 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:51 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:51 --> Router Class Initialized
ERROR - 2011-08-29 12:14:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:14:52 --> Config Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:14:52 --> URI Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Router Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Output Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Input Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:14:52 --> Language Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Loader Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Controller Class Initialized
ERROR - 2011-08-29 12:14:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:14:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:14:52 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Model Class Initialized
DEBUG - 2011-08-29 12:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:14:52 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:14:52 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:14:52 --> Final output sent to browser
DEBUG - 2011-08-29 12:14:52 --> Total execution time: 0.0836
DEBUG - 2011-08-29 12:29:23 --> Config Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:29:23 --> URI Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Router Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Output Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Input Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:29:23 --> Language Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Loader Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Controller Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Model Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Model Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Model Class Initialized
DEBUG - 2011-08-29 12:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:29:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:29:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:29:23 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:29:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:29:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:29:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:29:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:29:23 --> Final output sent to browser
DEBUG - 2011-08-29 12:29:23 --> Total execution time: 0.2037
DEBUG - 2011-08-29 12:29:27 --> Config Class Initialized
DEBUG - 2011-08-29 12:29:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:29:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:29:27 --> URI Class Initialized
DEBUG - 2011-08-29 12:29:27 --> Router Class Initialized
ERROR - 2011-08-29 12:29:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:29:29 --> Config Class Initialized
DEBUG - 2011-08-29 12:29:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:29:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:29:29 --> URI Class Initialized
DEBUG - 2011-08-29 12:29:29 --> Router Class Initialized
ERROR - 2011-08-29 12:29:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:46:13 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:13 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Router Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Output Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Input Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:46:13 --> Language Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Loader Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Controller Class Initialized
ERROR - 2011-08-29 12:46:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:46:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:46:13 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:46:13 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:46:13 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:46:13 --> Final output sent to browser
DEBUG - 2011-08-29 12:46:13 --> Total execution time: 0.1082
DEBUG - 2011-08-29 12:46:15 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:15 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Router Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Output Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Input Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:46:15 --> Language Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Loader Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Controller Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:46:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:46:16 --> Final output sent to browser
DEBUG - 2011-08-29 12:46:16 --> Total execution time: 0.8297
DEBUG - 2011-08-29 12:46:18 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:18 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:18 --> Router Class Initialized
ERROR - 2011-08-29 12:46:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:46:51 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:51 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Router Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Output Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Input Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:46:51 --> Language Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Loader Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Controller Class Initialized
ERROR - 2011-08-29 12:46:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:46:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:46:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:46:51 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:46:51 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:46:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:46:51 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:46:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:46:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:46:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:46:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:46:51 --> Final output sent to browser
DEBUG - 2011-08-29 12:46:51 --> Total execution time: 0.0298
DEBUG - 2011-08-29 12:46:52 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:52 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Router Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Output Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Input Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:46:52 --> Language Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Loader Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Controller Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:46:52 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:52 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Router Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Output Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Input Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:46:52 --> Language Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Loader Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Controller Class Initialized
ERROR - 2011-08-29 12:46:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:46:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:46:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:46:52 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Model Class Initialized
DEBUG - 2011-08-29 12:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:46:52 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:46:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:46:52 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:46:52 --> Final output sent to browser
DEBUG - 2011-08-29 12:46:52 --> Total execution time: 0.0536
DEBUG - 2011-08-29 12:46:53 --> Final output sent to browser
DEBUG - 2011-08-29 12:46:53 --> Total execution time: 0.6380
DEBUG - 2011-08-29 12:46:56 --> Config Class Initialized
DEBUG - 2011-08-29 12:46:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:46:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:46:56 --> URI Class Initialized
DEBUG - 2011-08-29 12:46:56 --> Router Class Initialized
ERROR - 2011-08-29 12:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:47:13 --> Config Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:47:13 --> URI Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Router Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Output Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Input Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:47:13 --> Language Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Loader Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Controller Class Initialized
ERROR - 2011-08-29 12:47:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:47:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:47:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:47:13 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:47:13 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:47:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:47:13 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:47:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:47:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:47:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:47:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:47:13 --> Final output sent to browser
DEBUG - 2011-08-29 12:47:13 --> Total execution time: 0.0287
DEBUG - 2011-08-29 12:47:13 --> Config Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:47:13 --> URI Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Router Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Output Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Input Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:47:13 --> Language Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Loader Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Controller Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:47:13 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:47:14 --> Final output sent to browser
DEBUG - 2011-08-29 12:47:14 --> Total execution time: 0.5751
DEBUG - 2011-08-29 12:47:17 --> Config Class Initialized
DEBUG - 2011-08-29 12:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:47:17 --> URI Class Initialized
DEBUG - 2011-08-29 12:47:17 --> Router Class Initialized
ERROR - 2011-08-29 12:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:47:25 --> Config Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:47:25 --> URI Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Router Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Output Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Input Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:47:25 --> Language Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Loader Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Controller Class Initialized
ERROR - 2011-08-29 12:47:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 12:47:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 12:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:47:25 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:47:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 12:47:25 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:47:25 --> Final output sent to browser
DEBUG - 2011-08-29 12:47:25 --> Total execution time: 0.0278
DEBUG - 2011-08-29 12:47:26 --> Config Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:47:26 --> URI Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Router Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Output Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Input Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:47:26 --> Language Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Loader Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Controller Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Model Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:47:26 --> Final output sent to browser
DEBUG - 2011-08-29 12:47:26 --> Total execution time: 0.5003
DEBUG - 2011-08-29 12:47:28 --> Config Class Initialized
DEBUG - 2011-08-29 12:47:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:47:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:47:28 --> URI Class Initialized
DEBUG - 2011-08-29 12:47:28 --> Router Class Initialized
ERROR - 2011-08-29 12:47:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:54:47 --> Config Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:54:47 --> URI Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Router Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Output Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Input Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:54:47 --> Language Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Loader Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Controller Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Model Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Model Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Model Class Initialized
DEBUG - 2011-08-29 12:54:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:54:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:54:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:54:48 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:54:48 --> Final output sent to browser
DEBUG - 2011-08-29 12:54:48 --> Total execution time: 0.2653
DEBUG - 2011-08-29 12:55:06 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:06 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Router Class Initialized
ERROR - 2011-08-29 12:55:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:55:06 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:06 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Router Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Output Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Input Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:55:06 --> Language Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Loader Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Controller Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:55:06 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:55:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:55:07 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:55:07 --> Final output sent to browser
DEBUG - 2011-08-29 12:55:07 --> Total execution time: 0.7271
DEBUG - 2011-08-29 12:55:12 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:12 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Router Class Initialized
ERROR - 2011-08-29 12:55:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:55:12 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:12 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Router Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Output Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Input Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:55:12 --> Language Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Loader Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Controller Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:55:12 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:55:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:55:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:55:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:55:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:55:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:55:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:55:12 --> Final output sent to browser
DEBUG - 2011-08-29 12:55:12 --> Total execution time: 0.0439
DEBUG - 2011-08-29 12:55:13 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:13 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:13 --> Router Class Initialized
ERROR - 2011-08-29 12:55:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:55:13 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:13 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:13 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:13 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:13 --> Router Class Initialized
ERROR - 2011-08-29 12:55:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 12:55:16 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:16 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Router Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Output Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Input Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:55:16 --> Language Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Loader Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Controller Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:55:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:55:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:55:17 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:55:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:55:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:55:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:55:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:55:17 --> Final output sent to browser
DEBUG - 2011-08-29 12:55:17 --> Total execution time: 0.3182
DEBUG - 2011-08-29 12:55:26 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:26 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Router Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Output Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Input Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:55:26 --> Language Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Loader Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Controller Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:55:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:55:26 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:55:26 --> Final output sent to browser
DEBUG - 2011-08-29 12:55:26 --> Total execution time: 0.0448
DEBUG - 2011-08-29 12:55:31 --> Config Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Hooks Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Utf8 Class Initialized
DEBUG - 2011-08-29 12:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 12:55:31 --> URI Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Router Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Output Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Input Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 12:55:31 --> Language Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Loader Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Controller Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Model Class Initialized
DEBUG - 2011-08-29 12:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 12:55:31 --> Database Driver Class Initialized
DEBUG - 2011-08-29 12:55:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 12:55:31 --> Helper loaded: url_helper
DEBUG - 2011-08-29 12:55:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 12:55:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 12:55:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 12:55:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 12:55:31 --> Final output sent to browser
DEBUG - 2011-08-29 12:55:31 --> Total execution time: 0.2381
DEBUG - 2011-08-29 13:13:52 --> Config Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:13:52 --> URI Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Router Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Output Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Input Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:13:52 --> Language Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Loader Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Controller Class Initialized
ERROR - 2011-08-29 13:13:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 13:13:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 13:13:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:13:52 --> Model Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Model Class Initialized
DEBUG - 2011-08-29 13:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:13:52 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:13:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:13:52 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:13:52 --> Final output sent to browser
DEBUG - 2011-08-29 13:13:52 --> Total execution time: 0.0929
DEBUG - 2011-08-29 13:13:53 --> Config Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:13:53 --> URI Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Router Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Output Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Input Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:13:53 --> Language Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Loader Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Controller Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Model Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Model Class Initialized
DEBUG - 2011-08-29 13:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:13:53 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:13:54 --> Final output sent to browser
DEBUG - 2011-08-29 13:13:54 --> Total execution time: 0.6775
DEBUG - 2011-08-29 13:14:12 --> Config Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:14:12 --> URI Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Router Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Output Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Input Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:14:12 --> Language Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Loader Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Controller Class Initialized
ERROR - 2011-08-29 13:14:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 13:14:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 13:14:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:14:12 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:14:12 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:14:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:14:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:14:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:14:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:14:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:14:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:14:12 --> Final output sent to browser
DEBUG - 2011-08-29 13:14:12 --> Total execution time: 0.0287
DEBUG - 2011-08-29 13:14:15 --> Config Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:14:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:14:15 --> URI Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Router Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Output Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Input Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:14:15 --> Language Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Loader Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Controller Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:14:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:14:15 --> Final output sent to browser
DEBUG - 2011-08-29 13:14:15 --> Total execution time: 0.5438
DEBUG - 2011-08-29 13:14:57 --> Config Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:14:57 --> URI Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Router Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Output Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Input Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:14:57 --> Language Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Loader Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Controller Class Initialized
ERROR - 2011-08-29 13:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 13:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 13:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:14:57 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:14:57 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:14:57 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:14:57 --> Final output sent to browser
DEBUG - 2011-08-29 13:14:57 --> Total execution time: 0.0273
DEBUG - 2011-08-29 13:14:59 --> Config Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:14:59 --> URI Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Router Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Output Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Input Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:14:59 --> Language Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Loader Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Controller Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Model Class Initialized
DEBUG - 2011-08-29 13:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:14:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:15:00 --> Final output sent to browser
DEBUG - 2011-08-29 13:15:00 --> Total execution time: 0.5959
DEBUG - 2011-08-29 13:15:22 --> Config Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:15:22 --> URI Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Router Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Output Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Input Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:15:22 --> Language Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Loader Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Controller Class Initialized
ERROR - 2011-08-29 13:15:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 13:15:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 13:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:15:22 --> Model Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Model Class Initialized
DEBUG - 2011-08-29 13:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:15:22 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:15:22 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:15:22 --> Final output sent to browser
DEBUG - 2011-08-29 13:15:22 --> Total execution time: 0.1132
DEBUG - 2011-08-29 13:15:24 --> Config Class Initialized
DEBUG - 2011-08-29 13:15:24 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:15:24 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:15:24 --> URI Class Initialized
DEBUG - 2011-08-29 13:15:24 --> Router Class Initialized
DEBUG - 2011-08-29 13:15:24 --> Output Class Initialized
DEBUG - 2011-08-29 13:15:24 --> Input Class Initialized
DEBUG - 2011-08-29 13:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:15:25 --> Language Class Initialized
DEBUG - 2011-08-29 13:15:25 --> Loader Class Initialized
DEBUG - 2011-08-29 13:15:25 --> Controller Class Initialized
DEBUG - 2011-08-29 13:15:25 --> Model Class Initialized
DEBUG - 2011-08-29 13:15:25 --> Model Class Initialized
DEBUG - 2011-08-29 13:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:15:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:15:25 --> Final output sent to browser
DEBUG - 2011-08-29 13:15:25 --> Total execution time: 0.5573
DEBUG - 2011-08-29 13:26:04 --> Config Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:26:04 --> URI Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Router Class Initialized
DEBUG - 2011-08-29 13:26:04 --> No URI present. Default controller set.
DEBUG - 2011-08-29 13:26:04 --> Output Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Input Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:26:04 --> Language Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Loader Class Initialized
DEBUG - 2011-08-29 13:26:04 --> Controller Class Initialized
DEBUG - 2011-08-29 13:26:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 13:26:04 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:26:04 --> Final output sent to browser
DEBUG - 2011-08-29 13:26:04 --> Total execution time: 0.1220
DEBUG - 2011-08-29 13:47:20 --> Config Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:47:20 --> URI Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Router Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Output Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Input Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:47:20 --> Language Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Loader Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Controller Class Initialized
ERROR - 2011-08-29 13:47:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 13:47:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 13:47:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:47:20 --> Model Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Model Class Initialized
DEBUG - 2011-08-29 13:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:47:20 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:47:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:47:20 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:47:20 --> Final output sent to browser
DEBUG - 2011-08-29 13:47:20 --> Total execution time: 0.0612
DEBUG - 2011-08-29 13:56:29 --> Config Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:56:29 --> URI Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Router Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Output Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Input Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:56:29 --> Language Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Loader Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Controller Class Initialized
ERROR - 2011-08-29 13:56:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 13:56:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 13:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:56:29 --> Model Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Model Class Initialized
DEBUG - 2011-08-29 13:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:56:29 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 13:56:29 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:56:29 --> Final output sent to browser
DEBUG - 2011-08-29 13:56:29 --> Total execution time: 0.0578
DEBUG - 2011-08-29 13:56:30 --> Config Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:56:30 --> URI Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Router Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Output Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Input Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:56:30 --> Language Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Loader Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Controller Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Model Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Model Class Initialized
DEBUG - 2011-08-29 13:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:56:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:56:31 --> Final output sent to browser
DEBUG - 2011-08-29 13:56:31 --> Total execution time: 0.6956
DEBUG - 2011-08-29 13:56:32 --> Config Class Initialized
DEBUG - 2011-08-29 13:56:32 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:56:32 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:56:32 --> URI Class Initialized
DEBUG - 2011-08-29 13:56:32 --> Router Class Initialized
ERROR - 2011-08-29 13:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 13:56:32 --> Config Class Initialized
DEBUG - 2011-08-29 13:56:32 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:56:32 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:56:32 --> URI Class Initialized
DEBUG - 2011-08-29 13:56:32 --> Router Class Initialized
ERROR - 2011-08-29 13:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 13:56:33 --> Config Class Initialized
DEBUG - 2011-08-29 13:56:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:56:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:56:33 --> URI Class Initialized
DEBUG - 2011-08-29 13:56:33 --> Router Class Initialized
ERROR - 2011-08-29 13:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 13:57:12 --> Config Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:57:12 --> URI Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Router Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Output Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Input Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:57:12 --> Language Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Loader Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Controller Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:57:12 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:57:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 13:57:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:57:12 --> Final output sent to browser
DEBUG - 2011-08-29 13:57:12 --> Total execution time: 0.5961
DEBUG - 2011-08-29 13:57:15 --> Config Class Initialized
DEBUG - 2011-08-29 13:57:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:57:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:57:15 --> URI Class Initialized
DEBUG - 2011-08-29 13:57:15 --> Router Class Initialized
ERROR - 2011-08-29 13:57:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 13:57:26 --> Config Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:57:26 --> URI Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Router Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Output Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Input Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:57:26 --> Language Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Loader Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Controller Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:57:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:57:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 13:57:26 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:57:26 --> Final output sent to browser
DEBUG - 2011-08-29 13:57:26 --> Total execution time: 0.4268
DEBUG - 2011-08-29 13:57:27 --> Config Class Initialized
DEBUG - 2011-08-29 13:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:57:27 --> URI Class Initialized
DEBUG - 2011-08-29 13:57:28 --> Router Class Initialized
ERROR - 2011-08-29 13:57:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 13:57:36 --> Config Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:57:36 --> URI Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Router Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Output Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Input Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 13:57:36 --> Language Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Loader Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Controller Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Model Class Initialized
DEBUG - 2011-08-29 13:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 13:57:36 --> Database Driver Class Initialized
DEBUG - 2011-08-29 13:57:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 13:57:37 --> Helper loaded: url_helper
DEBUG - 2011-08-29 13:57:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 13:57:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 13:57:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 13:57:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 13:57:37 --> Final output sent to browser
DEBUG - 2011-08-29 13:57:37 --> Total execution time: 0.2685
DEBUG - 2011-08-29 13:57:39 --> Config Class Initialized
DEBUG - 2011-08-29 13:57:39 --> Hooks Class Initialized
DEBUG - 2011-08-29 13:57:39 --> Utf8 Class Initialized
DEBUG - 2011-08-29 13:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 13:57:39 --> URI Class Initialized
DEBUG - 2011-08-29 13:57:39 --> Router Class Initialized
ERROR - 2011-08-29 13:57:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 14:22:44 --> Config Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:22:44 --> URI Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Router Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Output Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Input Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:22:44 --> Language Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Loader Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Controller Class Initialized
ERROR - 2011-08-29 14:22:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 14:22:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 14:22:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:22:44 --> Model Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Model Class Initialized
DEBUG - 2011-08-29 14:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:22:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:22:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:22:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 14:22:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 14:22:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 14:22:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 14:22:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 14:22:44 --> Final output sent to browser
DEBUG - 2011-08-29 14:22:44 --> Total execution time: 0.0682
DEBUG - 2011-08-29 14:22:45 --> Config Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:22:45 --> URI Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Router Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Output Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Input Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:22:45 --> Language Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Loader Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Controller Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Model Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Model Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:22:45 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:22:45 --> Final output sent to browser
DEBUG - 2011-08-29 14:22:45 --> Total execution time: 0.4765
DEBUG - 2011-08-29 14:22:49 --> Config Class Initialized
DEBUG - 2011-08-29 14:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:22:49 --> URI Class Initialized
DEBUG - 2011-08-29 14:22:49 --> Router Class Initialized
ERROR - 2011-08-29 14:22:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 14:22:49 --> Config Class Initialized
DEBUG - 2011-08-29 14:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:22:49 --> URI Class Initialized
DEBUG - 2011-08-29 14:22:49 --> Router Class Initialized
ERROR - 2011-08-29 14:22:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 14:23:15 --> Config Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:23:15 --> URI Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Router Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Output Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Input Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:23:15 --> Language Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Loader Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Controller Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Model Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Model Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:23:15 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:23:15 --> Final output sent to browser
DEBUG - 2011-08-29 14:23:15 --> Total execution time: 0.3181
DEBUG - 2011-08-29 14:23:16 --> Config Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:23:16 --> URI Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Router Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Output Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Input Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:23:16 --> Language Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Loader Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Controller Class Initialized
ERROR - 2011-08-29 14:23:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 14:23:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 14:23:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:23:16 --> Model Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Model Class Initialized
DEBUG - 2011-08-29 14:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:23:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:23:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:23:16 --> Helper loaded: url_helper
DEBUG - 2011-08-29 14:23:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 14:23:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 14:23:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 14:23:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 14:23:16 --> Final output sent to browser
DEBUG - 2011-08-29 14:23:16 --> Total execution time: 0.0470
DEBUG - 2011-08-29 14:53:42 --> Config Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:53:42 --> URI Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Router Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Output Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Input Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:53:42 --> Language Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Loader Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Controller Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:53:42 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 14:53:42 --> Helper loaded: url_helper
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 14:53:42 --> Final output sent to browser
DEBUG - 2011-08-29 14:53:42 --> Total execution time: 0.2078
DEBUG - 2011-08-29 14:53:42 --> Config Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:53:42 --> URI Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Router Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Output Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Input Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:53:42 --> Language Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Loader Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Controller Class Initialized
ERROR - 2011-08-29 14:53:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 14:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:53:42 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:53:42 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:53:42 --> Helper loaded: url_helper
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 14:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 14:53:42 --> Final output sent to browser
DEBUG - 2011-08-29 14:53:42 --> Total execution time: 0.0323
DEBUG - 2011-08-29 14:53:43 --> Config Class Initialized
DEBUG - 2011-08-29 14:53:43 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:53:43 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:53:43 --> URI Class Initialized
DEBUG - 2011-08-29 14:53:43 --> Router Class Initialized
ERROR - 2011-08-29 14:53:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 14:53:44 --> Config Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:53:44 --> URI Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Router Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Output Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Input Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:53:44 --> Language Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Loader Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Controller Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Model Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:53:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:53:44 --> Final output sent to browser
DEBUG - 2011-08-29 14:53:44 --> Total execution time: 0.5976
DEBUG - 2011-08-29 14:53:45 --> Config Class Initialized
DEBUG - 2011-08-29 14:53:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:53:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:53:45 --> URI Class Initialized
DEBUG - 2011-08-29 14:53:45 --> Router Class Initialized
ERROR - 2011-08-29 14:53:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 14:53:46 --> Config Class Initialized
DEBUG - 2011-08-29 14:53:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:53:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:53:46 --> URI Class Initialized
DEBUG - 2011-08-29 14:53:46 --> Router Class Initialized
ERROR - 2011-08-29 14:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 14:54:07 --> Config Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:54:07 --> URI Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Router Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Output Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Input Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:54:07 --> Language Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Loader Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Controller Class Initialized
ERROR - 2011-08-29 14:54:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 14:54:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 14:54:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:54:07 --> Model Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Model Class Initialized
DEBUG - 2011-08-29 14:54:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:54:07 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:54:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 14:54:07 --> Helper loaded: url_helper
DEBUG - 2011-08-29 14:54:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 14:54:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 14:54:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 14:54:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 14:54:07 --> Final output sent to browser
DEBUG - 2011-08-29 14:54:07 --> Total execution time: 0.0347
DEBUG - 2011-08-29 14:54:08 --> Config Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:54:08 --> URI Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Router Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Output Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Input Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 14:54:08 --> Language Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Loader Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Controller Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Model Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Model Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 14:54:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 14:54:08 --> Final output sent to browser
DEBUG - 2011-08-29 14:54:08 --> Total execution time: 0.5973
DEBUG - 2011-08-29 14:54:10 --> Config Class Initialized
DEBUG - 2011-08-29 14:54:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 14:54:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 14:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 14:54:10 --> URI Class Initialized
DEBUG - 2011-08-29 14:54:10 --> Router Class Initialized
ERROR - 2011-08-29 14:54:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:10:35 --> Config Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:10:35 --> URI Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Router Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Output Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Input Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:10:35 --> Language Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Loader Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Controller Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Model Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Model Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Model Class Initialized
DEBUG - 2011-08-29 15:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:10:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 15:10:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:10:36 --> Final output sent to browser
DEBUG - 2011-08-29 15:10:36 --> Total execution time: 0.0502
DEBUG - 2011-08-29 15:19:59 --> Config Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:19:59 --> URI Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Router Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Output Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Input Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:19:59 --> Language Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Loader Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Controller Class Initialized
ERROR - 2011-08-29 15:19:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:19:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:19:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:19:59 --> Model Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Model Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:19:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:19:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:19:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:19:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:19:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:19:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:19:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:19:59 --> Final output sent to browser
DEBUG - 2011-08-29 15:19:59 --> Total execution time: 0.0279
DEBUG - 2011-08-29 15:19:59 --> Config Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:19:59 --> URI Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Router Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Output Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Input Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:19:59 --> Language Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Loader Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Controller Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Model Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Model Class Initialized
DEBUG - 2011-08-29 15:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:19:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:00 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:00 --> Total execution time: 0.6872
DEBUG - 2011-08-29 15:20:01 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:01 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Router Class Initialized
ERROR - 2011-08-29 15:20:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:20:01 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:01 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:01 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Controller Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:01 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 15:20:01 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:20:01 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:01 --> Total execution time: 0.0432
DEBUG - 2011-08-29 15:20:02 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:02 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:02 --> Router Class Initialized
ERROR - 2011-08-29 15:20:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:20:28 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:28 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:28 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Controller Class Initialized
ERROR - 2011-08-29 15:20:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:20:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:20:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:28 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:20:28 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:20:28 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:28 --> Total execution time: 0.0286
DEBUG - 2011-08-29 15:20:28 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:28 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:28 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Controller Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:28 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:29 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:29 --> Total execution time: 0.5565
DEBUG - 2011-08-29 15:20:29 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:29 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:29 --> Router Class Initialized
ERROR - 2011-08-29 15:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:20:40 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:40 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:40 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Controller Class Initialized
ERROR - 2011-08-29 15:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:20:40 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:40 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:20:40 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:20:40 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:40 --> Total execution time: 0.0286
DEBUG - 2011-08-29 15:20:40 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:40 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:40 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Controller Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:40 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:41 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:41 --> Total execution time: 0.6146
DEBUG - 2011-08-29 15:20:42 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:42 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:42 --> Router Class Initialized
ERROR - 2011-08-29 15:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:20:49 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:49 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:49 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Controller Class Initialized
ERROR - 2011-08-29 15:20:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:20:49 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:49 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:20:49 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:20:49 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:49 --> Total execution time: 0.0273
DEBUG - 2011-08-29 15:20:49 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:49 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Router Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Output Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Input Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:20:49 --> Language Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Loader Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Controller Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Model Class Initialized
DEBUG - 2011-08-29 15:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:20:49 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:20:50 --> Final output sent to browser
DEBUG - 2011-08-29 15:20:50 --> Total execution time: 0.5740
DEBUG - 2011-08-29 15:20:50 --> Config Class Initialized
DEBUG - 2011-08-29 15:20:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:20:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:20:50 --> URI Class Initialized
DEBUG - 2011-08-29 15:20:50 --> Router Class Initialized
ERROR - 2011-08-29 15:20:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:08 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:08 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:08 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:08 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:08 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:08 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:08 --> Total execution time: 0.0324
DEBUG - 2011-08-29 15:21:08 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:08 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:08 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:08 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:09 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:09 --> Total execution time: 0.5075
DEBUG - 2011-08-29 15:21:09 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:09 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:09 --> Router Class Initialized
ERROR - 2011-08-29 15:21:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:17 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:17 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:17 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:17 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:17 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:17 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:17 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:17 --> Total execution time: 0.0339
DEBUG - 2011-08-29 15:21:17 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:17 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:17 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:17 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:18 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:18 --> Total execution time: 0.6531
DEBUG - 2011-08-29 15:21:18 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:18 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:18 --> Router Class Initialized
ERROR - 2011-08-29 15:21:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:25 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:25 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:25 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:25 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:25 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:25 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:25 --> Total execution time: 0.0297
DEBUG - 2011-08-29 15:21:25 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:25 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:25 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:25 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:26 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:26 --> Total execution time: 0.5049
DEBUG - 2011-08-29 15:21:26 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:26 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:26 --> Router Class Initialized
ERROR - 2011-08-29 15:21:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:34 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:34 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:34 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:34 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:34 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:34 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:34 --> Total execution time: 0.0268
DEBUG - 2011-08-29 15:21:34 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:34 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:34 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:35 --> Total execution time: 0.5061
DEBUG - 2011-08-29 15:21:35 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:35 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Router Class Initialized
ERROR - 2011-08-29 15:21:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:35 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:35 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:35 --> Router Class Initialized
ERROR - 2011-08-29 15:21:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:42 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:42 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:42 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:42 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:42 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:42 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:42 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:42 --> Total execution time: 0.0291
DEBUG - 2011-08-29 15:21:42 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:42 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:42 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:42 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:42 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:42 --> Total execution time: 0.4853
DEBUG - 2011-08-29 15:21:43 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:43 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:43 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:43 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:43 --> Router Class Initialized
ERROR - 2011-08-29 15:21:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:47 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:47 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:47 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:47 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:47 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:47 --> Total execution time: 0.0292
DEBUG - 2011-08-29 15:21:47 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:47 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:47 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:47 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:47 --> Total execution time: 0.5016
DEBUG - 2011-08-29 15:21:48 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:48 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:48 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:48 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:48 --> Router Class Initialized
ERROR - 2011-08-29 15:21:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:55 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:55 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:55 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:55 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:55 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:55 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:55 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:55 --> Total execution time: 0.0265
DEBUG - 2011-08-29 15:21:56 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:56 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:56 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Controller Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:56 --> Total execution time: 0.4953
DEBUG - 2011-08-29 15:21:56 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:56 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:56 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:56 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:56 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:56 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:56 --> Total execution time: 0.0272
DEBUG - 2011-08-29 15:21:56 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:56 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:56 --> Router Class Initialized
ERROR - 2011-08-29 15:21:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:21:59 --> Config Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:21:59 --> URI Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Router Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Output Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Input Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:21:59 --> Language Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Loader Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Controller Class Initialized
ERROR - 2011-08-29 15:21:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:21:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:59 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Model Class Initialized
DEBUG - 2011-08-29 15:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:21:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:21:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:21:59 --> Final output sent to browser
DEBUG - 2011-08-29 15:21:59 --> Total execution time: 0.0282
DEBUG - 2011-08-29 15:22:00 --> Config Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:22:00 --> URI Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Router Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Output Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Input Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:22:00 --> Language Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Loader Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Controller Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Model Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Model Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:22:00 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:22:00 --> Final output sent to browser
DEBUG - 2011-08-29 15:22:00 --> Total execution time: 0.8171
DEBUG - 2011-08-29 15:22:01 --> Config Class Initialized
DEBUG - 2011-08-29 15:22:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:22:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:22:01 --> URI Class Initialized
DEBUG - 2011-08-29 15:22:01 --> Router Class Initialized
ERROR - 2011-08-29 15:22:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:22:06 --> Config Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:22:06 --> URI Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Router Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Output Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Input Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:22:06 --> Language Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Loader Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Controller Class Initialized
ERROR - 2011-08-29 15:22:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 15:22:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 15:22:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:22:06 --> Model Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Model Class Initialized
DEBUG - 2011-08-29 15:22:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:22:06 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:22:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 15:22:06 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:22:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:22:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:22:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:22:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:22:06 --> Final output sent to browser
DEBUG - 2011-08-29 15:22:06 --> Total execution time: 0.0517
DEBUG - 2011-08-29 15:22:10 --> Config Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:22:10 --> URI Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Router Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Output Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Input Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:22:10 --> Language Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Loader Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Controller Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Model Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Model Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:22:10 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:22:10 --> Final output sent to browser
DEBUG - 2011-08-29 15:22:10 --> Total execution time: 0.5346
DEBUG - 2011-08-29 15:22:11 --> Config Class Initialized
DEBUG - 2011-08-29 15:22:11 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:22:11 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:22:11 --> URI Class Initialized
DEBUG - 2011-08-29 15:22:11 --> Router Class Initialized
ERROR - 2011-08-29 15:22:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 15:27:53 --> Config Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:27:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:27:53 --> URI Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Router Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Output Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Input Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:27:53 --> Language Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Loader Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Controller Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Model Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Model Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Model Class Initialized
DEBUG - 2011-08-29 15:27:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:27:53 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:27:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 15:27:54 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:27:54 --> Final output sent to browser
DEBUG - 2011-08-29 15:27:54 --> Total execution time: 0.0430
DEBUG - 2011-08-29 15:28:16 --> Config Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:28:16 --> URI Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Router Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Output Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Input Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:28:16 --> Language Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Loader Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Controller Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Model Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Model Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Model Class Initialized
DEBUG - 2011-08-29 15:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:28:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:28:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 15:28:16 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:28:16 --> Final output sent to browser
DEBUG - 2011-08-29 15:28:16 --> Total execution time: 0.2280
DEBUG - 2011-08-29 15:28:20 --> Config Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:28:20 --> URI Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Router Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Output Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Input Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:28:20 --> Language Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Loader Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Controller Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Model Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Model Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Model Class Initialized
DEBUG - 2011-08-29 15:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:28:20 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 15:28:20 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:28:20 --> Final output sent to browser
DEBUG - 2011-08-29 15:28:20 --> Total execution time: 0.0882
DEBUG - 2011-08-29 15:58:47 --> Config Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 15:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 15:58:47 --> URI Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Router Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Output Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Input Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 15:58:47 --> Language Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Loader Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Controller Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Model Class Initialized
DEBUG - 2011-08-29 15:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 15:58:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 15:58:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 15:58:48 --> Helper loaded: url_helper
DEBUG - 2011-08-29 15:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 15:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 15:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 15:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 15:58:48 --> Final output sent to browser
DEBUG - 2011-08-29 15:58:48 --> Total execution time: 0.4993
DEBUG - 2011-08-29 16:11:29 --> Config Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:11:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:11:29 --> URI Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Router Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Output Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Input Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 16:11:29 --> Language Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Loader Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Controller Class Initialized
ERROR - 2011-08-29 16:11:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 16:11:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 16:11:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 16:11:29 --> Model Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Model Class Initialized
DEBUG - 2011-08-29 16:11:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 16:11:29 --> Database Driver Class Initialized
DEBUG - 2011-08-29 16:11:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 16:11:29 --> Helper loaded: url_helper
DEBUG - 2011-08-29 16:11:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 16:11:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 16:11:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 16:11:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 16:11:29 --> Final output sent to browser
DEBUG - 2011-08-29 16:11:29 --> Total execution time: 0.0600
DEBUG - 2011-08-29 16:11:30 --> Config Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:11:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:11:30 --> URI Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Router Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Output Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Input Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 16:11:30 --> Language Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Loader Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Controller Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Model Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Model Class Initialized
DEBUG - 2011-08-29 16:11:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 16:11:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 16:11:31 --> Final output sent to browser
DEBUG - 2011-08-29 16:11:31 --> Total execution time: 0.5586
DEBUG - 2011-08-29 16:11:39 --> Config Class Initialized
DEBUG - 2011-08-29 16:11:39 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:11:39 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:11:39 --> URI Class Initialized
DEBUG - 2011-08-29 16:11:39 --> Router Class Initialized
ERROR - 2011-08-29 16:11:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 16:11:40 --> Config Class Initialized
DEBUG - 2011-08-29 16:11:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:11:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:11:40 --> URI Class Initialized
DEBUG - 2011-08-29 16:11:40 --> Router Class Initialized
ERROR - 2011-08-29 16:11:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 16:23:04 --> Config Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:23:04 --> URI Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Router Class Initialized
DEBUG - 2011-08-29 16:23:04 --> No URI present. Default controller set.
DEBUG - 2011-08-29 16:23:04 --> Output Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Input Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 16:23:04 --> Language Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Loader Class Initialized
DEBUG - 2011-08-29 16:23:04 --> Controller Class Initialized
DEBUG - 2011-08-29 16:23:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 16:23:04 --> Helper loaded: url_helper
DEBUG - 2011-08-29 16:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 16:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 16:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 16:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 16:23:04 --> Final output sent to browser
DEBUG - 2011-08-29 16:23:04 --> Total execution time: 0.0533
DEBUG - 2011-08-29 16:38:38 --> Config Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:38:38 --> URI Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Router Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Output Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Input Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 16:38:38 --> Language Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Loader Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Controller Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Model Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Model Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Model Class Initialized
DEBUG - 2011-08-29 16:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 16:38:38 --> Database Driver Class Initialized
DEBUG - 2011-08-29 16:38:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 16:38:38 --> Helper loaded: url_helper
DEBUG - 2011-08-29 16:38:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 16:38:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 16:38:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 16:38:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 16:38:38 --> Final output sent to browser
DEBUG - 2011-08-29 16:38:38 --> Total execution time: 0.2482
DEBUG - 2011-08-29 16:38:39 --> Config Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Hooks Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Utf8 Class Initialized
DEBUG - 2011-08-29 16:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 16:38:39 --> URI Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Router Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Output Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Input Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 16:38:39 --> Language Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Loader Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Controller Class Initialized
ERROR - 2011-08-29 16:38:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 16:38:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 16:38:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 16:38:39 --> Model Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Model Class Initialized
DEBUG - 2011-08-29 16:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 16:38:39 --> Database Driver Class Initialized
DEBUG - 2011-08-29 16:38:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 16:38:39 --> Helper loaded: url_helper
DEBUG - 2011-08-29 16:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 16:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 16:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 16:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 16:38:39 --> Final output sent to browser
DEBUG - 2011-08-29 16:38:39 --> Total execution time: 0.0380
DEBUG - 2011-08-29 17:23:39 --> Config Class Initialized
DEBUG - 2011-08-29 17:23:39 --> Hooks Class Initialized
DEBUG - 2011-08-29 17:23:39 --> Utf8 Class Initialized
DEBUG - 2011-08-29 17:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 17:23:39 --> URI Class Initialized
DEBUG - 2011-08-29 17:23:39 --> Router Class Initialized
ERROR - 2011-08-29 17:23:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 17:35:55 --> Config Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 17:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 17:35:55 --> URI Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Router Class Initialized
ERROR - 2011-08-29 17:35:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 17:35:55 --> Config Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 17:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 17:35:55 --> URI Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Router Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Output Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Input Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 17:35:55 --> Language Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Loader Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Controller Class Initialized
ERROR - 2011-08-29 17:35:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 17:35:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 17:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 17:35:55 --> Model Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Model Class Initialized
DEBUG - 2011-08-29 17:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 17:35:55 --> Database Driver Class Initialized
DEBUG - 2011-08-29 17:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 17:35:55 --> Helper loaded: url_helper
DEBUG - 2011-08-29 17:35:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 17:35:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 17:35:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 17:35:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 17:35:55 --> Final output sent to browser
DEBUG - 2011-08-29 17:35:55 --> Total execution time: 0.0409
DEBUG - 2011-08-29 17:39:09 --> Config Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 17:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 17:39:09 --> URI Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Router Class Initialized
ERROR - 2011-08-29 17:39:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-29 17:39:09 --> Config Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 17:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 17:39:09 --> URI Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Router Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Output Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Input Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 17:39:09 --> Language Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Loader Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Controller Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Model Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Model Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Model Class Initialized
DEBUG - 2011-08-29 17:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 17:39:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 17:39:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 17:39:09 --> Helper loaded: url_helper
DEBUG - 2011-08-29 17:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 17:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 17:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 17:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 17:39:09 --> Final output sent to browser
DEBUG - 2011-08-29 17:39:09 --> Total execution time: 0.2866
DEBUG - 2011-08-29 18:08:53 --> Config Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:08:53 --> URI Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Router Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Output Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Input Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:08:53 --> Language Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Loader Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Controller Class Initialized
ERROR - 2011-08-29 18:08:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:08:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:08:53 --> Model Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Model Class Initialized
DEBUG - 2011-08-29 18:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:08:53 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:08:53 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:08:53 --> Final output sent to browser
DEBUG - 2011-08-29 18:08:53 --> Total execution time: 0.0567
DEBUG - 2011-08-29 18:08:54 --> Config Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:08:54 --> URI Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Router Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Output Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Input Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:08:54 --> Language Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Loader Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Controller Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:08:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:08:54 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:08:55 --> Final output sent to browser
DEBUG - 2011-08-29 18:08:55 --> Total execution time: 0.7976
DEBUG - 2011-08-29 18:08:56 --> Config Class Initialized
DEBUG - 2011-08-29 18:08:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:08:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:08:56 --> URI Class Initialized
DEBUG - 2011-08-29 18:08:56 --> Router Class Initialized
ERROR - 2011-08-29 18:08:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:09:05 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:05 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:05 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Controller Class Initialized
ERROR - 2011-08-29 18:09:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:09:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:09:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:05 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:05 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:05 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:09:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:09:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:09:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:09:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:09:05 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:05 --> Total execution time: 0.1279
DEBUG - 2011-08-29 18:09:06 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:06 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:06 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Controller Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:06 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:06 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:06 --> Total execution time: 0.6533
DEBUG - 2011-08-29 18:09:07 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:07 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:07 --> Router Class Initialized
ERROR - 2011-08-29 18:09:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:09:09 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:09 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:09 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Controller Class Initialized
ERROR - 2011-08-29 18:09:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:09:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:09:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:09 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:09 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:09 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:09:09 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:09 --> Total execution time: 0.0340
DEBUG - 2011-08-29 18:09:10 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:10 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:10 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Controller Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:10 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:11 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:11 --> Total execution time: 0.5697
DEBUG - 2011-08-29 18:09:12 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:12 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:12 --> Router Class Initialized
ERROR - 2011-08-29 18:09:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:09:21 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:21 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:21 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Controller Class Initialized
ERROR - 2011-08-29 18:09:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:09:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:09:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:21 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:21 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:21 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:09:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:09:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:09:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:09:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:09:21 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:21 --> Total execution time: 0.0353
DEBUG - 2011-08-29 18:09:22 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:22 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:22 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Controller Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:22 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:22 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:22 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Controller Class Initialized
ERROR - 2011-08-29 18:09:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:09:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:09:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:22 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:22 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:22 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:09:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:09:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:09:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:09:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:09:22 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:22 --> Total execution time: 0.0364
DEBUG - 2011-08-29 18:09:22 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:22 --> Total execution time: 0.6224
DEBUG - 2011-08-29 18:09:23 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:23 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:23 --> Router Class Initialized
ERROR - 2011-08-29 18:09:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:09:45 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:45 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:45 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Controller Class Initialized
ERROR - 2011-08-29 18:09:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:09:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:45 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:45 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:09:45 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:09:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:09:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:09:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:09:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:09:45 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:45 --> Total execution time: 0.0269
DEBUG - 2011-08-29 18:09:46 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:46 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Router Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Output Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Input Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:09:46 --> Language Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Loader Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Controller Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Model Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:09:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:09:46 --> Final output sent to browser
DEBUG - 2011-08-29 18:09:46 --> Total execution time: 0.6696
DEBUG - 2011-08-29 18:09:47 --> Config Class Initialized
DEBUG - 2011-08-29 18:09:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:09:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:09:47 --> URI Class Initialized
DEBUG - 2011-08-29 18:09:47 --> Router Class Initialized
ERROR - 2011-08-29 18:09:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:11:10 --> Config Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:11:10 --> URI Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Router Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Output Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Input Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:11:10 --> Language Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Loader Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Controller Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:11:10 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:11:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:11:10 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:11:10 --> Final output sent to browser
DEBUG - 2011-08-29 18:11:10 --> Total execution time: 0.2187
DEBUG - 2011-08-29 18:21:28 --> Config Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:21:28 --> URI Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Router Class Initialized
DEBUG - 2011-08-29 18:21:28 --> No URI present. Default controller set.
DEBUG - 2011-08-29 18:21:28 --> Output Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Input Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:21:28 --> Language Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Loader Class Initialized
DEBUG - 2011-08-29 18:21:28 --> Controller Class Initialized
DEBUG - 2011-08-29 18:21:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 18:21:28 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:21:28 --> Final output sent to browser
DEBUG - 2011-08-29 18:21:28 --> Total execution time: 0.0119
DEBUG - 2011-08-29 18:45:14 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:14 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:14 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Controller Class Initialized
ERROR - 2011-08-29 18:45:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:45:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:45:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:14 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:45:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:45:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:45:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:45:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:45:14 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:14 --> Total execution time: 0.0637
DEBUG - 2011-08-29 18:45:16 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:16 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:16 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Controller Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:16 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:16 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:16 --> Total execution time: 0.5976
DEBUG - 2011-08-29 18:45:18 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:18 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:18 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:18 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:18 --> Router Class Initialized
ERROR - 2011-08-29 18:45:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:45:33 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:33 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:33 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Controller Class Initialized
ERROR - 2011-08-29 18:45:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:45:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:33 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:33 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:45:33 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:33 --> Total execution time: 0.0378
DEBUG - 2011-08-29 18:45:34 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:34 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:34 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Controller Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:35 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:35 --> Total execution time: 1.1081
DEBUG - 2011-08-29 18:45:36 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:36 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:36 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:36 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:36 --> Router Class Initialized
ERROR - 2011-08-29 18:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:45:44 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:44 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:44 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Controller Class Initialized
ERROR - 2011-08-29 18:45:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:45:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:44 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:45:44 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:44 --> Total execution time: 0.0273
DEBUG - 2011-08-29 18:45:45 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:45 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:45 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Controller Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:45 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:45 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:45 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Controller Class Initialized
ERROR - 2011-08-29 18:45:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:45:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:45:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:45 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:45 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:45 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:45:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:45:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:45:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:45:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:45:45 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:45 --> Total execution time: 0.0264
DEBUG - 2011-08-29 18:45:45 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:45 --> Total execution time: 0.5127
DEBUG - 2011-08-29 18:45:47 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:47 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:47 --> Router Class Initialized
ERROR - 2011-08-29 18:45:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:45:54 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:54 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:54 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Controller Class Initialized
ERROR - 2011-08-29 18:45:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 18:45:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 18:45:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:54 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 18:45:54 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:45:54 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:54 --> Total execution time: 0.0302
DEBUG - 2011-08-29 18:45:55 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:55 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Router Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Output Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Input Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:45:55 --> Language Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Loader Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Controller Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Model Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:45:55 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:45:55 --> Final output sent to browser
DEBUG - 2011-08-29 18:45:55 --> Total execution time: 0.5589
DEBUG - 2011-08-29 18:45:57 --> Config Class Initialized
DEBUG - 2011-08-29 18:45:57 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:45:57 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:45:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:45:57 --> URI Class Initialized
DEBUG - 2011-08-29 18:45:57 --> Router Class Initialized
ERROR - 2011-08-29 18:45:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:49:54 --> Config Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:49:54 --> URI Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Router Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Output Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Input Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:49:54 --> Language Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Loader Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Controller Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Model Class Initialized
DEBUG - 2011-08-29 18:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:49:54 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:49:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:49:54 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:49:54 --> Final output sent to browser
DEBUG - 2011-08-29 18:49:54 --> Total execution time: 0.2254
DEBUG - 2011-08-29 18:49:58 --> Config Class Initialized
DEBUG - 2011-08-29 18:49:58 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:49:58 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:49:58 --> URI Class Initialized
DEBUG - 2011-08-29 18:49:58 --> Router Class Initialized
ERROR - 2011-08-29 18:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 18:50:35 --> Config Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:50:35 --> URI Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Router Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Output Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Input Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:50:35 --> Language Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Loader Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Controller Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Model Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Model Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Model Class Initialized
DEBUG - 2011-08-29 18:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:50:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:50:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:50:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:50:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:50:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:50:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:50:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:50:36 --> Final output sent to browser
DEBUG - 2011-08-29 18:50:36 --> Total execution time: 0.3046
DEBUG - 2011-08-29 18:51:10 --> Config Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:51:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:51:10 --> URI Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Router Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Output Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Input Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:51:10 --> Language Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Loader Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Controller Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Model Class Initialized
DEBUG - 2011-08-29 18:51:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:51:10 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:51:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:51:10 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:51:10 --> Final output sent to browser
DEBUG - 2011-08-29 18:51:10 --> Total execution time: 0.2374
DEBUG - 2011-08-29 18:51:38 --> Config Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:51:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:51:38 --> URI Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Router Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Output Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Input Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:51:38 --> Language Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Loader Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Controller Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Model Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Model Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Model Class Initialized
DEBUG - 2011-08-29 18:51:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:51:38 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:51:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:51:38 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:51:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:51:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:51:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:51:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:51:38 --> Final output sent to browser
DEBUG - 2011-08-29 18:51:38 --> Total execution time: 0.2512
DEBUG - 2011-08-29 18:52:01 --> Config Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:52:01 --> URI Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Router Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Output Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Input Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:52:01 --> Language Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Loader Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Controller Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:52:01 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:52:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:52:02 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:52:02 --> Final output sent to browser
DEBUG - 2011-08-29 18:52:02 --> Total execution time: 0.4842
DEBUG - 2011-08-29 18:52:34 --> Config Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:52:34 --> URI Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Router Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Output Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Input Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:52:34 --> Language Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Loader Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Controller Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:52:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:52:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:52:34 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:52:34 --> Final output sent to browser
DEBUG - 2011-08-29 18:52:34 --> Total execution time: 0.2125
DEBUG - 2011-08-29 18:52:59 --> Config Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:52:59 --> URI Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Router Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Output Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Input Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:52:59 --> Language Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Loader Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Controller Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Model Class Initialized
DEBUG - 2011-08-29 18:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:52:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:53:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:53:00 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:53:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:53:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:53:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:53:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:53:00 --> Final output sent to browser
DEBUG - 2011-08-29 18:53:00 --> Total execution time: 0.2240
DEBUG - 2011-08-29 18:53:21 --> Config Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:53:21 --> URI Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Router Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Output Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Input Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:53:21 --> Language Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Loader Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Controller Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:53:21 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:53:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:53:21 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:53:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:53:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:53:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:53:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:53:21 --> Final output sent to browser
DEBUG - 2011-08-29 18:53:21 --> Total execution time: 0.0431
DEBUG - 2011-08-29 18:53:34 --> Config Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:53:34 --> URI Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Router Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Output Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Input Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:53:34 --> Language Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Loader Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Controller Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:53:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:53:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:53:34 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:53:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:53:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:53:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:53:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:53:34 --> Final output sent to browser
DEBUG - 2011-08-29 18:53:34 --> Total execution time: 0.0426
DEBUG - 2011-08-29 18:53:46 --> Config Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:53:46 --> URI Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Router Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Output Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Input Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:53:46 --> Language Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Loader Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Controller Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:53:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:53:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:53:46 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:53:46 --> Final output sent to browser
DEBUG - 2011-08-29 18:53:46 --> Total execution time: 0.1525
DEBUG - 2011-08-29 18:53:56 --> Config Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:53:56 --> URI Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Router Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Output Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Input Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:53:56 --> Language Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Loader Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Controller Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Model Class Initialized
DEBUG - 2011-08-29 18:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:53:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:53:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:53:56 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:53:56 --> Final output sent to browser
DEBUG - 2011-08-29 18:53:56 --> Total execution time: 0.2724
DEBUG - 2011-08-29 18:54:14 --> Config Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:54:14 --> URI Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Router Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Output Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Input Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:54:14 --> Language Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Loader Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Controller Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:54:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:54:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:54:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:54:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:54:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:54:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:54:15 --> Final output sent to browser
DEBUG - 2011-08-29 18:54:15 --> Total execution time: 0.3956
DEBUG - 2011-08-29 18:54:27 --> Config Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:54:27 --> URI Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Router Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Output Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Input Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:54:27 --> Language Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Loader Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Controller Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:54:27 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:54:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:54:28 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:54:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:54:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:54:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:54:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:54:28 --> Final output sent to browser
DEBUG - 2011-08-29 18:54:28 --> Total execution time: 0.5722
DEBUG - 2011-08-29 18:54:44 --> Config Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:54:44 --> URI Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Router Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Output Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Input Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:54:44 --> Language Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Loader Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Controller Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Model Class Initialized
DEBUG - 2011-08-29 18:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:54:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:54:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:54:44 --> Final output sent to browser
DEBUG - 2011-08-29 18:54:44 --> Total execution time: 0.2147
DEBUG - 2011-08-29 18:55:19 --> Config Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:55:19 --> URI Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Router Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Output Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Input Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:55:19 --> Language Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Loader Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Controller Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Model Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Model Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Model Class Initialized
DEBUG - 2011-08-29 18:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:55:19 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:55:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:55:19 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:55:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:55:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:55:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:55:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:55:19 --> Final output sent to browser
DEBUG - 2011-08-29 18:55:19 --> Total execution time: 0.2698
DEBUG - 2011-08-29 18:55:49 --> Config Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:55:49 --> URI Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Router Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Output Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Input Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:55:49 --> Language Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Loader Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Controller Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Model Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Model Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Model Class Initialized
DEBUG - 2011-08-29 18:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:55:49 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:55:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:55:49 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:55:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:55:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:55:49 --> Final output sent to browser
DEBUG - 2011-08-29 18:55:49 --> Total execution time: 0.2106
DEBUG - 2011-08-29 18:56:14 --> Config Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:56:14 --> URI Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Router Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Output Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Input Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:56:14 --> Language Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Loader Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Controller Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:56:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:56:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:56:14 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:56:14 --> Final output sent to browser
DEBUG - 2011-08-29 18:56:14 --> Total execution time: 0.2273
DEBUG - 2011-08-29 18:56:28 --> Config Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:56:28 --> URI Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Router Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Output Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Input Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:56:28 --> Language Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Loader Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Controller Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:56:28 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:56:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:56:29 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:56:29 --> Final output sent to browser
DEBUG - 2011-08-29 18:56:29 --> Total execution time: 0.9699
DEBUG - 2011-08-29 18:56:47 --> Config Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:56:47 --> URI Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Router Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Output Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Input Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:56:47 --> Language Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Loader Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Controller Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Model Class Initialized
DEBUG - 2011-08-29 18:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:56:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:56:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:56:47 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:56:47 --> Final output sent to browser
DEBUG - 2011-08-29 18:56:47 --> Total execution time: 0.2017
DEBUG - 2011-08-29 18:57:14 --> Config Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:57:14 --> URI Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Router Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Output Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Input Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:57:14 --> Language Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Loader Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Controller Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:57:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:57:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:57:15 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:57:15 --> Final output sent to browser
DEBUG - 2011-08-29 18:57:15 --> Total execution time: 0.2307
DEBUG - 2011-08-29 18:57:26 --> Config Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:57:26 --> URI Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Router Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Output Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Input Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:57:26 --> Language Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Loader Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Controller Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:57:26 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:57:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:57:26 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:57:26 --> Final output sent to browser
DEBUG - 2011-08-29 18:57:26 --> Total execution time: 0.1840
DEBUG - 2011-08-29 18:57:41 --> Config Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Hooks Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Utf8 Class Initialized
DEBUG - 2011-08-29 18:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 18:57:41 --> URI Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Router Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Output Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Input Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 18:57:41 --> Language Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Loader Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Controller Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Model Class Initialized
DEBUG - 2011-08-29 18:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 18:57:41 --> Database Driver Class Initialized
DEBUG - 2011-08-29 18:57:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 18:57:41 --> Helper loaded: url_helper
DEBUG - 2011-08-29 18:57:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 18:57:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 18:57:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 18:57:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 18:57:41 --> Final output sent to browser
DEBUG - 2011-08-29 18:57:41 --> Total execution time: 0.0650
DEBUG - 2011-08-29 19:17:45 --> Config Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Hooks Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Utf8 Class Initialized
DEBUG - 2011-08-29 19:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 19:17:45 --> URI Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Router Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Output Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Input Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 19:17:45 --> Language Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Loader Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Controller Class Initialized
ERROR - 2011-08-29 19:17:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 19:17:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 19:17:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 19:17:45 --> Model Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Model Class Initialized
DEBUG - 2011-08-29 19:17:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 19:17:45 --> Database Driver Class Initialized
DEBUG - 2011-08-29 19:17:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 19:17:45 --> Helper loaded: url_helper
DEBUG - 2011-08-29 19:17:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 19:17:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 19:17:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 19:17:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 19:17:45 --> Final output sent to browser
DEBUG - 2011-08-29 19:17:45 --> Total execution time: 0.0743
DEBUG - 2011-08-29 19:17:46 --> Config Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Hooks Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Utf8 Class Initialized
DEBUG - 2011-08-29 19:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 19:17:46 --> URI Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Router Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Output Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Input Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 19:17:46 --> Language Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Loader Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Controller Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Model Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Model Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 19:17:46 --> Database Driver Class Initialized
DEBUG - 2011-08-29 19:17:46 --> Final output sent to browser
DEBUG - 2011-08-29 19:17:46 --> Total execution time: 0.6918
DEBUG - 2011-08-29 19:17:47 --> Config Class Initialized
DEBUG - 2011-08-29 19:17:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 19:17:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 19:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 19:17:47 --> URI Class Initialized
DEBUG - 2011-08-29 19:17:47 --> Router Class Initialized
ERROR - 2011-08-29 19:17:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 20:10:30 --> Config Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:10:30 --> URI Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Router Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Output Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Input Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:10:30 --> Language Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Loader Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Controller Class Initialized
ERROR - 2011-08-29 20:10:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 20:10:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 20:10:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:10:30 --> Model Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Model Class Initialized
DEBUG - 2011-08-29 20:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:10:30 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:10:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:10:30 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:10:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:10:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:10:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:10:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:10:30 --> Final output sent to browser
DEBUG - 2011-08-29 20:10:30 --> Total execution time: 0.0303
DEBUG - 2011-08-29 20:10:33 --> Config Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:10:33 --> URI Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Router Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Output Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Input Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:10:33 --> Language Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Loader Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Controller Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Model Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Model Class Initialized
DEBUG - 2011-08-29 20:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:10:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:10:34 --> Final output sent to browser
DEBUG - 2011-08-29 20:10:34 --> Total execution time: 0.4999
DEBUG - 2011-08-29 20:11:00 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:00 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:00 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:00 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:00 --> Router Class Initialized
ERROR - 2011-08-29 20:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 20:11:02 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:02 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:02 --> Router Class Initialized
ERROR - 2011-08-29 20:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 20:11:06 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:06 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:06 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:06 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:06 --> Router Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Output Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Input Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:11:07 --> Language Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Loader Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Controller Class Initialized
ERROR - 2011-08-29 20:11:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 20:11:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 20:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:11:07 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:11:07 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:11:07 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:11:07 --> Final output sent to browser
DEBUG - 2011-08-29 20:11:07 --> Total execution time: 0.0316
DEBUG - 2011-08-29 20:11:10 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:10 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Router Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Output Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Input Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:11:10 --> Language Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Loader Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Controller Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:11:10 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:11:10 --> Final output sent to browser
DEBUG - 2011-08-29 20:11:10 --> Total execution time: 0.7030
DEBUG - 2011-08-29 20:11:22 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:22 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Router Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Output Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Input Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:11:22 --> Language Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Loader Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Controller Class Initialized
ERROR - 2011-08-29 20:11:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 20:11:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 20:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:11:22 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:11:22 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:11:22 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:11:22 --> Final output sent to browser
DEBUG - 2011-08-29 20:11:22 --> Total execution time: 0.0302
DEBUG - 2011-08-29 20:11:24 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:24 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Router Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Output Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Input Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:11:24 --> Language Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Loader Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Controller Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:11:24 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:11:25 --> Final output sent to browser
DEBUG - 2011-08-29 20:11:25 --> Total execution time: 0.5443
DEBUG - 2011-08-29 20:11:34 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:34 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Router Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Output Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Input Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:11:34 --> Language Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Loader Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Controller Class Initialized
ERROR - 2011-08-29 20:11:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 20:11:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 20:11:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:11:34 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:11:34 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:11:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:11:34 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:11:34 --> Final output sent to browser
DEBUG - 2011-08-29 20:11:34 --> Total execution time: 0.0274
DEBUG - 2011-08-29 20:11:35 --> Config Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:11:35 --> URI Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Router Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Output Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Input Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:11:35 --> Language Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Loader Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Controller Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Model Class Initialized
DEBUG - 2011-08-29 20:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:11:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:11:36 --> Final output sent to browser
DEBUG - 2011-08-29 20:11:36 --> Total execution time: 0.4976
DEBUG - 2011-08-29 20:13:22 --> Config Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:13:22 --> URI Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Router Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Output Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Input Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:13:22 --> Language Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Loader Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Controller Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Model Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Model Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Model Class Initialized
DEBUG - 2011-08-29 20:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:13:22 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:13:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 20:13:22 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:13:22 --> Final output sent to browser
DEBUG - 2011-08-29 20:13:22 --> Total execution time: 0.2827
DEBUG - 2011-08-29 20:13:24 --> Config Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:13:24 --> URI Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Router Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Output Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Input Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:13:24 --> Language Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Loader Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Controller Class Initialized
ERROR - 2011-08-29 20:13:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 20:13:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 20:13:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:13:24 --> Model Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Model Class Initialized
DEBUG - 2011-08-29 20:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 20:13:24 --> Database Driver Class Initialized
DEBUG - 2011-08-29 20:13:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 20:13:24 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:13:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:13:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:13:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:13:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:13:24 --> Final output sent to browser
DEBUG - 2011-08-29 20:13:24 --> Total execution time: 0.0295
DEBUG - 2011-08-29 20:26:53 --> Config Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 20:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 20:26:53 --> URI Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Router Class Initialized
DEBUG - 2011-08-29 20:26:53 --> No URI present. Default controller set.
DEBUG - 2011-08-29 20:26:53 --> Output Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Input Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 20:26:53 --> Language Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Loader Class Initialized
DEBUG - 2011-08-29 20:26:53 --> Controller Class Initialized
DEBUG - 2011-08-29 20:26:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 20:26:53 --> Helper loaded: url_helper
DEBUG - 2011-08-29 20:26:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 20:26:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 20:26:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 20:26:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 20:26:53 --> Final output sent to browser
DEBUG - 2011-08-29 20:26:53 --> Total execution time: 0.0336
DEBUG - 2011-08-29 21:17:44 --> Config Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Hooks Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Utf8 Class Initialized
DEBUG - 2011-08-29 21:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 21:17:44 --> URI Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Router Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Output Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Input Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 21:17:44 --> Language Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Loader Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Controller Class Initialized
ERROR - 2011-08-29 21:17:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 21:17:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 21:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 21:17:44 --> Model Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Model Class Initialized
DEBUG - 2011-08-29 21:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 21:17:44 --> Database Driver Class Initialized
DEBUG - 2011-08-29 21:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 21:17:44 --> Helper loaded: url_helper
DEBUG - 2011-08-29 21:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 21:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 21:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 21:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 21:17:44 --> Final output sent to browser
DEBUG - 2011-08-29 21:17:44 --> Total execution time: 0.0334
DEBUG - 2011-08-29 21:17:47 --> Config Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 21:17:47 --> URI Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Router Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Output Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Input Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 21:17:47 --> Language Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Loader Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Controller Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Model Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Model Class Initialized
DEBUG - 2011-08-29 21:17:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 21:17:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 21:17:48 --> Final output sent to browser
DEBUG - 2011-08-29 21:17:48 --> Total execution time: 0.5961
DEBUG - 2011-08-29 21:17:52 --> Config Class Initialized
DEBUG - 2011-08-29 21:17:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 21:17:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 21:17:52 --> URI Class Initialized
DEBUG - 2011-08-29 21:17:52 --> Router Class Initialized
ERROR - 2011-08-29 21:17:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 21:17:53 --> Config Class Initialized
DEBUG - 2011-08-29 21:17:53 --> Hooks Class Initialized
DEBUG - 2011-08-29 21:17:53 --> Utf8 Class Initialized
DEBUG - 2011-08-29 21:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 21:17:53 --> URI Class Initialized
DEBUG - 2011-08-29 21:17:53 --> Router Class Initialized
ERROR - 2011-08-29 21:17:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 21:17:55 --> Config Class Initialized
DEBUG - 2011-08-29 21:17:55 --> Hooks Class Initialized
DEBUG - 2011-08-29 21:17:55 --> Utf8 Class Initialized
DEBUG - 2011-08-29 21:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 21:17:55 --> URI Class Initialized
DEBUG - 2011-08-29 21:17:55 --> Router Class Initialized
ERROR - 2011-08-29 21:17:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 21:58:12 --> Config Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Hooks Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Utf8 Class Initialized
DEBUG - 2011-08-29 21:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 21:58:12 --> URI Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Router Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Output Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Input Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 21:58:12 --> Language Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Loader Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Controller Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Model Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Model Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Model Class Initialized
DEBUG - 2011-08-29 21:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 21:58:12 --> Database Driver Class Initialized
DEBUG - 2011-08-29 21:58:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 21:58:12 --> Helper loaded: url_helper
DEBUG - 2011-08-29 21:58:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 21:58:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 21:58:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 21:58:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 21:58:12 --> Final output sent to browser
DEBUG - 2011-08-29 21:58:12 --> Total execution time: 0.4173
DEBUG - 2011-08-29 22:10:33 --> Config Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:10:33 --> URI Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Router Class Initialized
DEBUG - 2011-08-29 22:10:33 --> No URI present. Default controller set.
DEBUG - 2011-08-29 22:10:33 --> Output Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Input Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:10:33 --> Language Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Loader Class Initialized
DEBUG - 2011-08-29 22:10:33 --> Controller Class Initialized
DEBUG - 2011-08-29 22:10:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-29 22:10:33 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:10:33 --> Final output sent to browser
DEBUG - 2011-08-29 22:10:33 --> Total execution time: 0.0277
DEBUG - 2011-08-29 22:15:19 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:19 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Router Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Output Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Input Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:15:19 --> Language Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Loader Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Controller Class Initialized
ERROR - 2011-08-29 22:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:15:19 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:15:19 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:15:19 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:15:19 --> Final output sent to browser
DEBUG - 2011-08-29 22:15:19 --> Total execution time: 0.0414
DEBUG - 2011-08-29 22:15:19 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:19 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Router Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Output Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Input Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:15:19 --> Language Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Loader Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Controller Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:15:19 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:15:20 --> Final output sent to browser
DEBUG - 2011-08-29 22:15:20 --> Total execution time: 0.5432
DEBUG - 2011-08-29 22:15:20 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:20 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:20 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:20 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:20 --> Router Class Initialized
ERROR - 2011-08-29 22:15:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:15:47 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:47 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Router Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Output Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Input Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:15:47 --> Language Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Loader Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Controller Class Initialized
ERROR - 2011-08-29 22:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:15:47 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:15:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:15:47 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:15:47 --> Final output sent to browser
DEBUG - 2011-08-29 22:15:47 --> Total execution time: 0.0299
DEBUG - 2011-08-29 22:15:47 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:47 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Router Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Output Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Input Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:15:47 --> Language Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Loader Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Controller Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:15:47 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:15:47 --> Final output sent to browser
DEBUG - 2011-08-29 22:15:47 --> Total execution time: 0.4463
DEBUG - 2011-08-29 22:15:48 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:48 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:48 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:48 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:48 --> Router Class Initialized
ERROR - 2011-08-29 22:15:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:15:56 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:56 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Router Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Output Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Input Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:15:56 --> Language Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Loader Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Controller Class Initialized
ERROR - 2011-08-29 22:15:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:15:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:15:56 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:15:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:15:56 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:15:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:15:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:15:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:15:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:15:56 --> Final output sent to browser
DEBUG - 2011-08-29 22:15:56 --> Total execution time: 0.0301
DEBUG - 2011-08-29 22:15:56 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:56 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Router Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Output Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Input Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:15:56 --> Language Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Loader Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Controller Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Model Class Initialized
DEBUG - 2011-08-29 22:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:15:56 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:15:57 --> Final output sent to browser
DEBUG - 2011-08-29 22:15:57 --> Total execution time: 0.5180
DEBUG - 2011-08-29 22:15:58 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:58 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:58 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:58 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:58 --> Router Class Initialized
ERROR - 2011-08-29 22:15:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:15:58 --> Config Class Initialized
DEBUG - 2011-08-29 22:15:58 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:15:58 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:15:58 --> URI Class Initialized
DEBUG - 2011-08-29 22:15:58 --> Router Class Initialized
ERROR - 2011-08-29 22:15:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:14 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:14 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:14 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Controller Class Initialized
ERROR - 2011-08-29 22:16:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:16:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:14 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:14 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:16:14 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:14 --> Total execution time: 0.0274
DEBUG - 2011-08-29 22:16:14 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:14 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:14 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Controller Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:14 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:15 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:15 --> Total execution time: 0.5207
DEBUG - 2011-08-29 22:16:15 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:15 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:15 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:15 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:15 --> Router Class Initialized
ERROR - 2011-08-29 22:16:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:23 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:23 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:23 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Controller Class Initialized
ERROR - 2011-08-29 22:16:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:16:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:16:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:23 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:23 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:16:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:16:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:16:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:16:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:16:23 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:23 --> Total execution time: 0.0306
DEBUG - 2011-08-29 22:16:23 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:23 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:23 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Controller Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:23 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:24 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:24 --> Total execution time: 0.5790
DEBUG - 2011-08-29 22:16:25 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:25 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:25 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:25 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:25 --> Router Class Initialized
ERROR - 2011-08-29 22:16:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:31 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:31 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:31 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Controller Class Initialized
ERROR - 2011-08-29 22:16:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:16:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:31 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:31 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:31 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:16:31 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:31 --> Total execution time: 0.0279
DEBUG - 2011-08-29 22:16:31 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:31 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:31 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Controller Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:31 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:32 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:32 --> Total execution time: 0.5749
DEBUG - 2011-08-29 22:16:32 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:32 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:32 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:32 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:32 --> Router Class Initialized
ERROR - 2011-08-29 22:16:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:40 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:40 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:40 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Controller Class Initialized
ERROR - 2011-08-29 22:16:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:16:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:16:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:40 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:40 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:40 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:16:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:16:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:16:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:16:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:16:40 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:40 --> Total execution time: 0.0272
DEBUG - 2011-08-29 22:16:41 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:41 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:41 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Controller Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:41 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:41 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:41 --> Total execution time: 0.5669
DEBUG - 2011-08-29 22:16:42 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:42 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:42 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:42 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:42 --> Router Class Initialized
ERROR - 2011-08-29 22:16:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:43 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:43 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:43 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:43 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:43 --> Router Class Initialized
ERROR - 2011-08-29 22:16:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:50 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:50 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:50 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Controller Class Initialized
ERROR - 2011-08-29 22:16:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:16:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:16:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:50 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:50 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:50 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:16:50 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:50 --> Total execution time: 0.0286
DEBUG - 2011-08-29 22:16:50 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:50 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:50 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Controller Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:50 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:51 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:51 --> Total execution time: 0.5081
DEBUG - 2011-08-29 22:16:52 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:52 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:52 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:52 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:52 --> Router Class Initialized
ERROR - 2011-08-29 22:16:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:16:59 --> Config Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:16:59 --> URI Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Router Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Output Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Input Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:16:59 --> Language Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Loader Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Controller Class Initialized
ERROR - 2011-08-29 22:16:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:16:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:16:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:59 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Model Class Initialized
DEBUG - 2011-08-29 22:16:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:16:59 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:16:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:16:59 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:16:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:16:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:16:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:16:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:16:59 --> Final output sent to browser
DEBUG - 2011-08-29 22:16:59 --> Total execution time: 0.0280
DEBUG - 2011-08-29 22:17:00 --> Config Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:17:00 --> URI Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Router Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Output Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Input Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:17:00 --> Language Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Loader Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Controller Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Model Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Model Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:17:00 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:17:00 --> Final output sent to browser
DEBUG - 2011-08-29 22:17:00 --> Total execution time: 0.5937
DEBUG - 2011-08-29 22:17:02 --> Config Class Initialized
DEBUG - 2011-08-29 22:17:02 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:17:02 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:17:02 --> URI Class Initialized
DEBUG - 2011-08-29 22:17:02 --> Router Class Initialized
ERROR - 2011-08-29 22:17:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:17:20 --> Config Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:17:20 --> URI Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Router Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Output Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Input Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:17:20 --> Language Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Loader Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Controller Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Model Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Model Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Model Class Initialized
DEBUG - 2011-08-29 22:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:17:20 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:17:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 22:17:20 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:17:20 --> Final output sent to browser
DEBUG - 2011-08-29 22:17:20 --> Total execution time: 0.3830
DEBUG - 2011-08-29 22:17:21 --> Config Class Initialized
DEBUG - 2011-08-29 22:17:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:17:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:17:21 --> URI Class Initialized
DEBUG - 2011-08-29 22:17:21 --> Router Class Initialized
ERROR - 2011-08-29 22:17:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:17:21 --> Config Class Initialized
DEBUG - 2011-08-29 22:17:21 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:17:21 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:17:21 --> URI Class Initialized
DEBUG - 2011-08-29 22:17:21 --> Router Class Initialized
ERROR - 2011-08-29 22:17:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 22:19:24 --> Config Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:19:24 --> URI Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Router Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Output Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Input Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:19:24 --> Language Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Loader Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Controller Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Model Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Model Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Model Class Initialized
DEBUG - 2011-08-29 22:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:19:24 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:19:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 22:19:24 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:19:24 --> Final output sent to browser
DEBUG - 2011-08-29 22:19:24 --> Total execution time: 0.0445
DEBUG - 2011-08-29 22:21:00 --> Config Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Hooks Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Utf8 Class Initialized
DEBUG - 2011-08-29 22:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 22:21:00 --> URI Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Router Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Output Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Input Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 22:21:00 --> Language Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Loader Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Controller Class Initialized
ERROR - 2011-08-29 22:21:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 22:21:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 22:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:21:00 --> Model Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Model Class Initialized
DEBUG - 2011-08-29 22:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 22:21:00 --> Database Driver Class Initialized
DEBUG - 2011-08-29 22:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 22:21:00 --> Helper loaded: url_helper
DEBUG - 2011-08-29 22:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 22:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 22:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 22:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 22:21:00 --> Final output sent to browser
DEBUG - 2011-08-29 22:21:00 --> Total execution time: 0.0451
DEBUG - 2011-08-29 23:37:35 --> Config Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Hooks Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Utf8 Class Initialized
DEBUG - 2011-08-29 23:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 23:37:35 --> URI Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Router Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Output Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Input Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 23:37:35 --> Language Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Loader Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Controller Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Model Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Model Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Model Class Initialized
DEBUG - 2011-08-29 23:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 23:37:35 --> Database Driver Class Initialized
DEBUG - 2011-08-29 23:37:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-29 23:37:36 --> Helper loaded: url_helper
DEBUG - 2011-08-29 23:37:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 23:37:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 23:37:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 23:37:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 23:37:36 --> Final output sent to browser
DEBUG - 2011-08-29 23:37:36 --> Total execution time: 0.4390
DEBUG - 2011-08-29 23:37:38 --> Config Class Initialized
DEBUG - 2011-08-29 23:37:38 --> Hooks Class Initialized
DEBUG - 2011-08-29 23:37:38 --> Utf8 Class Initialized
DEBUG - 2011-08-29 23:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 23:37:38 --> URI Class Initialized
DEBUG - 2011-08-29 23:37:38 --> Router Class Initialized
ERROR - 2011-08-29 23:37:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-29 23:38:33 --> Config Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 23:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 23:38:33 --> URI Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Router Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Output Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Input Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 23:38:33 --> Language Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Loader Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Controller Class Initialized
ERROR - 2011-08-29 23:38:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 23:38:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 23:38:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 23:38:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 23:38:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 23:38:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 23:38:33 --> Helper loaded: url_helper
DEBUG - 2011-08-29 23:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 23:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 23:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 23:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 23:38:33 --> Final output sent to browser
DEBUG - 2011-08-29 23:38:33 --> Total execution time: 0.0289
DEBUG - 2011-08-29 23:38:33 --> Config Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 23:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 23:38:33 --> URI Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Router Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Output Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Input Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 23:38:33 --> Language Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Loader Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Controller Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 23:38:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 23:38:34 --> Final output sent to browser
DEBUG - 2011-08-29 23:38:34 --> Total execution time: 0.6840
DEBUG - 2011-08-29 23:39:33 --> Config Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 23:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 23:39:33 --> URI Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Router Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Output Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Input Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 23:39:33 --> Language Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Loader Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Controller Class Initialized
ERROR - 2011-08-29 23:39:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-29 23:39:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-29 23:39:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 23:39:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 23:39:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 23:39:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-29 23:39:33 --> Helper loaded: url_helper
DEBUG - 2011-08-29 23:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-29 23:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-29 23:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-29 23:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-29 23:39:33 --> Final output sent to browser
DEBUG - 2011-08-29 23:39:33 --> Total execution time: 0.1378
DEBUG - 2011-08-29 23:39:33 --> Config Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Hooks Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Utf8 Class Initialized
DEBUG - 2011-08-29 23:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-29 23:39:33 --> URI Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Router Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Output Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Input Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-29 23:39:33 --> Language Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Loader Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Controller Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Model Class Initialized
DEBUG - 2011-08-29 23:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-29 23:39:33 --> Database Driver Class Initialized
DEBUG - 2011-08-29 23:39:34 --> Final output sent to browser
DEBUG - 2011-08-29 23:39:34 --> Total execution time: 0.7536

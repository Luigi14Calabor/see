<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-26 03:32:37 --> Config Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Hooks Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Utf8 Class Initialized
DEBUG - 2011-05-26 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 03:32:37 --> URI Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Router Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Output Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Input Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 03:32:37 --> Language Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Loader Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Controller Class Initialized
DEBUG - 2011-05-26 03:32:37 --> Model Class Initialized
DEBUG - 2011-05-26 03:32:38 --> Model Class Initialized
DEBUG - 2011-05-26 03:32:38 --> Model Class Initialized
DEBUG - 2011-05-26 03:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 03:32:38 --> Database Driver Class Initialized
DEBUG - 2011-05-26 03:32:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 03:32:48 --> Helper loaded: url_helper
DEBUG - 2011-05-26 03:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 03:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 03:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 03:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 03:32:48 --> Final output sent to browser
DEBUG - 2011-05-26 03:32:48 --> Total execution time: 11.1219
DEBUG - 2011-05-26 03:32:51 --> Config Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Hooks Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Utf8 Class Initialized
DEBUG - 2011-05-26 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 03:32:51 --> URI Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Router Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Output Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Input Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 03:32:51 --> Language Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Loader Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Controller Class Initialized
ERROR - 2011-05-26 03:32:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 03:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 03:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 03:32:51 --> Model Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Model Class Initialized
DEBUG - 2011-05-26 03:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 03:32:51 --> Database Driver Class Initialized
DEBUG - 2011-05-26 03:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 03:32:51 --> Helper loaded: url_helper
DEBUG - 2011-05-26 03:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 03:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 03:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 03:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 03:32:51 --> Final output sent to browser
DEBUG - 2011-05-26 03:32:51 --> Total execution time: 0.1392
DEBUG - 2011-05-26 03:33:40 --> Config Class Initialized
DEBUG - 2011-05-26 03:33:40 --> Hooks Class Initialized
DEBUG - 2011-05-26 03:33:40 --> Utf8 Class Initialized
DEBUG - 2011-05-26 03:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 03:33:40 --> URI Class Initialized
DEBUG - 2011-05-26 03:33:40 --> Router Class Initialized
ERROR - 2011-05-26 03:33:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 03:58:37 --> Config Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Hooks Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Utf8 Class Initialized
DEBUG - 2011-05-26 03:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 03:58:37 --> URI Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Router Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Output Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Input Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 03:58:37 --> Language Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Loader Class Initialized
DEBUG - 2011-05-26 03:58:37 --> Controller Class Initialized
DEBUG - 2011-05-26 03:58:38 --> Model Class Initialized
DEBUG - 2011-05-26 03:58:38 --> Model Class Initialized
DEBUG - 2011-05-26 03:58:38 --> Model Class Initialized
DEBUG - 2011-05-26 03:58:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 03:58:38 --> Database Driver Class Initialized
DEBUG - 2011-05-26 03:58:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 03:58:42 --> Helper loaded: url_helper
DEBUG - 2011-05-26 03:58:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 03:58:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 03:58:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 03:58:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 03:58:42 --> Final output sent to browser
DEBUG - 2011-05-26 03:58:42 --> Total execution time: 4.3812
DEBUG - 2011-05-26 07:17:03 --> Config Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Hooks Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Utf8 Class Initialized
DEBUG - 2011-05-26 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 07:17:03 --> URI Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Router Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Output Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Input Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 07:17:03 --> Language Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Loader Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Controller Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Model Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Model Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Model Class Initialized
DEBUG - 2011-05-26 07:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 07:17:03 --> Database Driver Class Initialized
DEBUG - 2011-05-26 07:17:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 07:17:05 --> Helper loaded: url_helper
DEBUG - 2011-05-26 07:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 07:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 07:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 07:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 07:17:05 --> Final output sent to browser
DEBUG - 2011-05-26 07:17:05 --> Total execution time: 2.6683
DEBUG - 2011-05-26 08:21:33 --> Config Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Hooks Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Utf8 Class Initialized
DEBUG - 2011-05-26 08:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 08:21:33 --> URI Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Router Class Initialized
ERROR - 2011-05-26 08:21:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 08:21:33 --> Config Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Hooks Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Utf8 Class Initialized
DEBUG - 2011-05-26 08:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 08:21:33 --> URI Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Router Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Output Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Input Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 08:21:33 --> Language Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Loader Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Controller Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Model Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Model Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Model Class Initialized
DEBUG - 2011-05-26 08:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 08:21:33 --> Database Driver Class Initialized
DEBUG - 2011-05-26 08:21:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 08:21:34 --> Helper loaded: url_helper
DEBUG - 2011-05-26 08:21:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 08:21:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 08:21:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 08:21:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 08:21:34 --> Final output sent to browser
DEBUG - 2011-05-26 08:21:34 --> Total execution time: 0.9614
DEBUG - 2011-05-26 09:26:06 --> Config Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Hooks Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Utf8 Class Initialized
DEBUG - 2011-05-26 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 09:26:06 --> URI Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Router Class Initialized
DEBUG - 2011-05-26 09:26:06 --> No URI present. Default controller set.
DEBUG - 2011-05-26 09:26:06 --> Output Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Input Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 09:26:06 --> Language Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Loader Class Initialized
DEBUG - 2011-05-26 09:26:06 --> Controller Class Initialized
DEBUG - 2011-05-26 09:26:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-26 09:26:06 --> Helper loaded: url_helper
DEBUG - 2011-05-26 09:26:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 09:26:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 09:26:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 09:26:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 09:26:06 --> Final output sent to browser
DEBUG - 2011-05-26 09:26:06 --> Total execution time: 0.9483
DEBUG - 2011-05-26 10:59:31 --> Config Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Hooks Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Utf8 Class Initialized
DEBUG - 2011-05-26 10:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 10:59:31 --> URI Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Router Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Output Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Input Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 10:59:31 --> Language Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Loader Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Controller Class Initialized
ERROR - 2011-05-26 10:59:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 10:59:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 10:59:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 10:59:31 --> Model Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Model Class Initialized
DEBUG - 2011-05-26 10:59:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 10:59:31 --> Database Driver Class Initialized
DEBUG - 2011-05-26 10:59:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 10:59:31 --> Helper loaded: url_helper
DEBUG - 2011-05-26 10:59:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 10:59:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 10:59:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 10:59:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 10:59:31 --> Final output sent to browser
DEBUG - 2011-05-26 10:59:31 --> Total execution time: 0.3984
DEBUG - 2011-05-26 10:59:32 --> Config Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Hooks Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Utf8 Class Initialized
DEBUG - 2011-05-26 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 10:59:32 --> URI Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Router Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Output Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Input Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 10:59:32 --> Language Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Loader Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Controller Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Model Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Model Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Model Class Initialized
DEBUG - 2011-05-26 10:59:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 10:59:32 --> Database Driver Class Initialized
DEBUG - 2011-05-26 10:59:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 10:59:33 --> Helper loaded: url_helper
DEBUG - 2011-05-26 10:59:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 10:59:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 10:59:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 10:59:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 10:59:33 --> Final output sent to browser
DEBUG - 2011-05-26 10:59:33 --> Total execution time: 0.7557
DEBUG - 2011-05-26 11:02:09 --> Config Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Hooks Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Utf8 Class Initialized
DEBUG - 2011-05-26 11:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 11:02:09 --> URI Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Router Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Output Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Input Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 11:02:09 --> Language Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Loader Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Controller Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Model Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Model Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Model Class Initialized
DEBUG - 2011-05-26 11:02:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 11:02:09 --> Database Driver Class Initialized
DEBUG - 2011-05-26 11:02:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 11:02:09 --> Helper loaded: url_helper
DEBUG - 2011-05-26 11:02:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 11:02:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 11:02:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 11:02:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 11:02:09 --> Final output sent to browser
DEBUG - 2011-05-26 11:02:09 --> Total execution time: 0.0481
DEBUG - 2011-05-26 11:02:19 --> Config Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Hooks Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Utf8 Class Initialized
DEBUG - 2011-05-26 11:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 11:02:19 --> URI Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Router Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Output Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Input Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 11:02:19 --> Language Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Loader Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Controller Class Initialized
ERROR - 2011-05-26 11:02:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 11:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 11:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 11:02:19 --> Model Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Model Class Initialized
DEBUG - 2011-05-26 11:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 11:02:19 --> Database Driver Class Initialized
DEBUG - 2011-05-26 11:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 11:02:19 --> Helper loaded: url_helper
DEBUG - 2011-05-26 11:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 11:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 11:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 11:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 11:02:19 --> Final output sent to browser
DEBUG - 2011-05-26 11:02:19 --> Total execution time: 0.0499
DEBUG - 2011-05-26 12:10:46 --> Config Class Initialized
DEBUG - 2011-05-26 12:10:46 --> Hooks Class Initialized
DEBUG - 2011-05-26 12:10:46 --> Utf8 Class Initialized
DEBUG - 2011-05-26 12:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 12:10:46 --> URI Class Initialized
DEBUG - 2011-05-26 12:10:46 --> Router Class Initialized
ERROR - 2011-05-26 12:10:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 12:10:47 --> Config Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Hooks Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Utf8 Class Initialized
DEBUG - 2011-05-26 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 12:10:47 --> URI Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Router Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Output Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Input Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 12:10:47 --> Language Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Loader Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Controller Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Model Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Model Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Model Class Initialized
DEBUG - 2011-05-26 12:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 12:10:47 --> Database Driver Class Initialized
DEBUG - 2011-05-26 12:10:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 12:10:47 --> Helper loaded: url_helper
DEBUG - 2011-05-26 12:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 12:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 12:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 12:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 12:10:47 --> Final output sent to browser
DEBUG - 2011-05-26 12:10:47 --> Total execution time: 0.7366
DEBUG - 2011-05-26 12:11:18 --> Config Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Hooks Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Utf8 Class Initialized
DEBUG - 2011-05-26 12:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 12:11:18 --> URI Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Router Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Output Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Input Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 12:11:18 --> Language Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Loader Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Controller Class Initialized
ERROR - 2011-05-26 12:11:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 12:11:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 12:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 12:11:18 --> Model Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Model Class Initialized
DEBUG - 2011-05-26 12:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 12:11:18 --> Database Driver Class Initialized
DEBUG - 2011-05-26 12:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 12:11:18 --> Helper loaded: url_helper
DEBUG - 2011-05-26 12:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 12:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 12:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 12:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 12:11:18 --> Final output sent to browser
DEBUG - 2011-05-26 12:11:18 --> Total execution time: 0.1322
DEBUG - 2011-05-26 12:39:32 --> Config Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Hooks Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Utf8 Class Initialized
DEBUG - 2011-05-26 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 12:39:32 --> URI Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Router Class Initialized
ERROR - 2011-05-26 12:39:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 12:39:32 --> Config Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Hooks Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Utf8 Class Initialized
DEBUG - 2011-05-26 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 12:39:32 --> URI Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Router Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Output Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Input Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 12:39:32 --> Language Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Loader Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Controller Class Initialized
ERROR - 2011-05-26 12:39:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 12:39:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 12:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 12:39:32 --> Model Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Model Class Initialized
DEBUG - 2011-05-26 12:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 12:39:32 --> Database Driver Class Initialized
DEBUG - 2011-05-26 12:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 12:39:32 --> Helper loaded: url_helper
DEBUG - 2011-05-26 12:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 12:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 12:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 12:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 12:39:32 --> Final output sent to browser
DEBUG - 2011-05-26 12:39:32 --> Total execution time: 0.3746
DEBUG - 2011-05-26 13:32:31 --> Config Class Initialized
DEBUG - 2011-05-26 13:32:31 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:32:31 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:32:31 --> URI Class Initialized
DEBUG - 2011-05-26 13:32:31 --> Router Class Initialized
ERROR - 2011-05-26 13:32:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 13:32:32 --> Config Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:32:32 --> URI Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Router Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Output Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Input Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:32:32 --> Language Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Loader Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Controller Class Initialized
ERROR - 2011-05-26 13:32:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 13:32:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 13:32:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 13:32:32 --> Model Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Model Class Initialized
DEBUG - 2011-05-26 13:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:32:32 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:32:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 13:32:33 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:32:33 --> Final output sent to browser
DEBUG - 2011-05-26 13:32:33 --> Total execution time: 0.9278
DEBUG - 2011-05-26 13:32:36 --> Config Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:32:36 --> URI Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Router Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Output Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Input Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:32:36 --> Language Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Loader Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Controller Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Model Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Model Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Model Class Initialized
DEBUG - 2011-05-26 13:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:32:36 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:32:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:32:37 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:32:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:32:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:32:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:32:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:32:37 --> Final output sent to browser
DEBUG - 2011-05-26 13:32:37 --> Total execution time: 0.8587
DEBUG - 2011-05-26 13:40:11 --> Config Class Initialized
DEBUG - 2011-05-26 13:40:11 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:40:11 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:40:11 --> URI Class Initialized
DEBUG - 2011-05-26 13:40:11 --> Router Class Initialized
DEBUG - 2011-05-26 13:40:11 --> Output Class Initialized
DEBUG - 2011-05-26 13:40:11 --> Input Class Initialized
DEBUG - 2011-05-26 13:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:40:11 --> Language Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Config Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:40:12 --> URI Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Router Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Output Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Input Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:40:12 --> Language Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Loader Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Controller Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Loader Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Controller Class Initialized
ERROR - 2011-05-26 13:40:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 13:40:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 13:40:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 13:40:12 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:40:12 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:40:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 13:40:12 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:40:12 --> Final output sent to browser
DEBUG - 2011-05-26 13:40:12 --> Total execution time: 0.4503
DEBUG - 2011-05-26 13:40:12 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:40:12 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:40:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:40:13 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:40:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:40:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:40:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:40:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:40:13 --> Final output sent to browser
DEBUG - 2011-05-26 13:40:13 --> Total execution time: 1.9377
DEBUG - 2011-05-26 13:40:17 --> Config Class Initialized
DEBUG - 2011-05-26 13:40:17 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:40:17 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:40:17 --> URI Class Initialized
DEBUG - 2011-05-26 13:40:17 --> Router Class Initialized
ERROR - 2011-05-26 13:40:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-26 13:40:18 --> Config Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:40:18 --> URI Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Router Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Output Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Input Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:40:18 --> Language Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Loader Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Controller Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:40:18 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:40:19 --> Config Class Initialized
DEBUG - 2011-05-26 13:40:19 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:40:19 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:40:19 --> URI Class Initialized
DEBUG - 2011-05-26 13:40:19 --> Router Class Initialized
ERROR - 2011-05-26 13:40:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-26 13:40:19 --> Final output sent to browser
DEBUG - 2011-05-26 13:40:19 --> Total execution time: 1.2376
DEBUG - 2011-05-26 13:40:44 --> Config Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:40:44 --> URI Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Router Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Output Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Input Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:40:44 --> Language Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Loader Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Controller Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Model Class Initialized
DEBUG - 2011-05-26 13:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:40:44 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:40:44 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:40:44 --> Final output sent to browser
DEBUG - 2011-05-26 13:40:44 --> Total execution time: 0.3668
DEBUG - 2011-05-26 13:41:02 --> Config Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:41:02 --> URI Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Router Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Output Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Input Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:41:02 --> Language Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Loader Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Controller Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Model Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Model Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Model Class Initialized
DEBUG - 2011-05-26 13:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:41:02 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:41:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:41:02 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:41:02 --> Final output sent to browser
DEBUG - 2011-05-26 13:41:02 --> Total execution time: 0.5313
DEBUG - 2011-05-26 13:42:30 --> Config Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:42:30 --> URI Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Router Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Output Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Input Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:42:30 --> Language Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Loader Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Controller Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:42:30 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:42:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:42:30 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:42:30 --> Final output sent to browser
DEBUG - 2011-05-26 13:42:30 --> Total execution time: 0.2630
DEBUG - 2011-05-26 13:42:40 --> Config Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:42:40 --> URI Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Router Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Output Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Input Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:42:40 --> Language Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Loader Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Controller Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:42:40 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:42:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:42:40 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:42:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:42:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:42:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:42:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:42:40 --> Final output sent to browser
DEBUG - 2011-05-26 13:42:40 --> Total execution time: 0.2949
DEBUG - 2011-05-26 13:42:51 --> Config Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:42:51 --> URI Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Router Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Output Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Input Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:42:51 --> Language Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Loader Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Controller Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Model Class Initialized
DEBUG - 2011-05-26 13:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:42:51 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:42:52 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:42:52 --> Final output sent to browser
DEBUG - 2011-05-26 13:42:52 --> Total execution time: 0.4535
DEBUG - 2011-05-26 13:43:13 --> Config Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:43:13 --> URI Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Router Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Output Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Input Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:43:13 --> Language Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Loader Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Controller Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:43:13 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:43:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:43:13 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:43:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:43:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:43:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:43:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:43:13 --> Final output sent to browser
DEBUG - 2011-05-26 13:43:13 --> Total execution time: 0.0622
DEBUG - 2011-05-26 13:43:19 --> Config Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:43:19 --> URI Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Router Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Output Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Input Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:43:19 --> Language Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Loader Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Controller Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:43:19 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:43:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:43:19 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:43:19 --> Final output sent to browser
DEBUG - 2011-05-26 13:43:19 --> Total execution time: 0.0483
DEBUG - 2011-05-26 13:43:33 --> Config Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:43:33 --> URI Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Router Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Output Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Input Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:43:33 --> Language Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Loader Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Controller Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:43:33 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:43:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:43:33 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:43:33 --> Final output sent to browser
DEBUG - 2011-05-26 13:43:33 --> Total execution time: 0.0669
DEBUG - 2011-05-26 13:43:40 --> Config Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:43:40 --> URI Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Router Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Output Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Input Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:43:40 --> Language Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Loader Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Controller Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:43:40 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:43:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:43:40 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:43:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:43:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:43:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:43:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:43:40 --> Final output sent to browser
DEBUG - 2011-05-26 13:43:40 --> Total execution time: 0.0437
DEBUG - 2011-05-26 13:43:45 --> Config Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:43:45 --> URI Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Router Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Output Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Input Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:43:45 --> Language Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Loader Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Controller Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:43:45 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:43:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:43:45 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:43:45 --> Final output sent to browser
DEBUG - 2011-05-26 13:43:45 --> Total execution time: 0.2487
DEBUG - 2011-05-26 13:43:59 --> Config Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:43:59 --> URI Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Router Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Output Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Input Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:43:59 --> Language Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Loader Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Controller Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Model Class Initialized
DEBUG - 2011-05-26 13:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:43:59 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:43:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:43:59 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:43:59 --> Final output sent to browser
DEBUG - 2011-05-26 13:43:59 --> Total execution time: 0.2707
DEBUG - 2011-05-26 13:44:08 --> Config Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:44:08 --> URI Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Router Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Output Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Input Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:44:08 --> Language Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Loader Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Controller Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:44:08 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:44:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:44:09 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:44:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:44:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:44:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:44:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:44:09 --> Final output sent to browser
DEBUG - 2011-05-26 13:44:09 --> Total execution time: 0.2791
DEBUG - 2011-05-26 13:44:31 --> Config Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:44:31 --> URI Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Router Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Output Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Input Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:44:31 --> Language Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Loader Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Controller Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:44:31 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:44:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:44:31 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:44:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:44:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:44:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:44:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:44:31 --> Final output sent to browser
DEBUG - 2011-05-26 13:44:31 --> Total execution time: 0.2529
DEBUG - 2011-05-26 13:44:44 --> Config Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Hooks Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Utf8 Class Initialized
DEBUG - 2011-05-26 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 13:44:44 --> URI Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Router Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Output Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Input Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 13:44:44 --> Language Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Loader Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Controller Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Model Class Initialized
DEBUG - 2011-05-26 13:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 13:44:44 --> Database Driver Class Initialized
DEBUG - 2011-05-26 13:44:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 13:44:44 --> Helper loaded: url_helper
DEBUG - 2011-05-26 13:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 13:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 13:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 13:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 13:44:44 --> Final output sent to browser
DEBUG - 2011-05-26 13:44:44 --> Total execution time: 0.2301
DEBUG - 2011-05-26 14:04:58 --> Config Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Hooks Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Utf8 Class Initialized
DEBUG - 2011-05-26 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 14:04:58 --> URI Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Router Class Initialized
DEBUG - 2011-05-26 14:04:58 --> No URI present. Default controller set.
DEBUG - 2011-05-26 14:04:58 --> Output Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Input Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 14:04:58 --> Language Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Loader Class Initialized
DEBUG - 2011-05-26 14:04:58 --> Controller Class Initialized
DEBUG - 2011-05-26 14:04:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-26 14:04:59 --> Helper loaded: url_helper
DEBUG - 2011-05-26 14:04:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 14:04:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 14:04:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 14:04:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 14:04:59 --> Final output sent to browser
DEBUG - 2011-05-26 14:04:59 --> Total execution time: 0.8195
DEBUG - 2011-05-26 15:30:36 --> Config Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Hooks Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Utf8 Class Initialized
DEBUG - 2011-05-26 15:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 15:30:36 --> URI Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Router Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Output Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Input Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 15:30:36 --> Language Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Loader Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Controller Class Initialized
ERROR - 2011-05-26 15:30:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 15:30:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 15:30:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 15:30:36 --> Model Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Model Class Initialized
DEBUG - 2011-05-26 15:30:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 15:30:36 --> Database Driver Class Initialized
DEBUG - 2011-05-26 15:30:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 15:30:36 --> Helper loaded: url_helper
DEBUG - 2011-05-26 15:30:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 15:30:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 15:30:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 15:30:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 15:30:36 --> Final output sent to browser
DEBUG - 2011-05-26 15:30:36 --> Total execution time: 0.5157
DEBUG - 2011-05-26 15:30:37 --> Config Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Hooks Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Utf8 Class Initialized
DEBUG - 2011-05-26 15:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 15:30:37 --> URI Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Router Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Output Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Input Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 15:30:37 --> Language Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Loader Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Controller Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Model Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Model Class Initialized
DEBUG - 2011-05-26 15:30:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 15:30:37 --> Database Driver Class Initialized
DEBUG - 2011-05-26 15:30:38 --> Final output sent to browser
DEBUG - 2011-05-26 15:30:38 --> Total execution time: 0.8766
DEBUG - 2011-05-26 15:30:39 --> Config Class Initialized
DEBUG - 2011-05-26 15:30:39 --> Hooks Class Initialized
DEBUG - 2011-05-26 15:30:39 --> Utf8 Class Initialized
DEBUG - 2011-05-26 15:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 15:30:39 --> URI Class Initialized
DEBUG - 2011-05-26 15:30:39 --> Router Class Initialized
ERROR - 2011-05-26 15:30:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-26 16:37:02 --> Config Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Hooks Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Utf8 Class Initialized
DEBUG - 2011-05-26 16:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 16:37:02 --> URI Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Router Class Initialized
DEBUG - 2011-05-26 16:37:02 --> No URI present. Default controller set.
DEBUG - 2011-05-26 16:37:02 --> Output Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Input Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 16:37:02 --> Language Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Loader Class Initialized
DEBUG - 2011-05-26 16:37:02 --> Controller Class Initialized
DEBUG - 2011-05-26 16:37:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-26 16:37:02 --> Helper loaded: url_helper
DEBUG - 2011-05-26 16:37:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 16:37:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 16:37:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 16:37:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 16:37:02 --> Final output sent to browser
DEBUG - 2011-05-26 16:37:02 --> Total execution time: 0.2469
DEBUG - 2011-05-26 16:42:17 --> Config Class Initialized
DEBUG - 2011-05-26 16:42:17 --> Hooks Class Initialized
DEBUG - 2011-05-26 16:42:17 --> Utf8 Class Initialized
DEBUG - 2011-05-26 16:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 16:42:17 --> URI Class Initialized
DEBUG - 2011-05-26 16:42:17 --> Router Class Initialized
ERROR - 2011-05-26 16:42:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 16:42:18 --> Config Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Hooks Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Utf8 Class Initialized
DEBUG - 2011-05-26 16:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 16:42:18 --> URI Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Router Class Initialized
DEBUG - 2011-05-26 16:42:18 --> No URI present. Default controller set.
DEBUG - 2011-05-26 16:42:18 --> Output Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Input Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 16:42:18 --> Language Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Loader Class Initialized
DEBUG - 2011-05-26 16:42:18 --> Controller Class Initialized
DEBUG - 2011-05-26 16:42:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-26 16:42:18 --> Helper loaded: url_helper
DEBUG - 2011-05-26 16:42:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 16:42:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 16:42:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 16:42:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 16:42:18 --> Final output sent to browser
DEBUG - 2011-05-26 16:42:18 --> Total execution time: 0.0263
DEBUG - 2011-05-26 16:42:19 --> Config Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Hooks Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Utf8 Class Initialized
DEBUG - 2011-05-26 16:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 16:42:19 --> URI Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Router Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Output Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Input Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 16:42:19 --> Language Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Loader Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Controller Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Model Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Model Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Model Class Initialized
DEBUG - 2011-05-26 16:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 16:42:19 --> Database Driver Class Initialized
DEBUG - 2011-05-26 16:42:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 16:42:20 --> Helper loaded: url_helper
DEBUG - 2011-05-26 16:42:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 16:42:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 16:42:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 16:42:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 16:42:20 --> Final output sent to browser
DEBUG - 2011-05-26 16:42:20 --> Total execution time: 0.8505
DEBUG - 2011-05-26 17:13:22 --> Config Class Initialized
DEBUG - 2011-05-26 17:13:22 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:13:22 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:13:23 --> URI Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Router Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Output Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Input Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 17:13:23 --> Language Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Loader Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Controller Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Model Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Model Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Model Class Initialized
DEBUG - 2011-05-26 17:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 17:13:23 --> Database Driver Class Initialized
DEBUG - 2011-05-26 17:13:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 17:13:23 --> Helper loaded: url_helper
DEBUG - 2011-05-26 17:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 17:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 17:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 17:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 17:13:23 --> Final output sent to browser
DEBUG - 2011-05-26 17:13:23 --> Total execution time: 0.5446
DEBUG - 2011-05-26 17:15:57 --> Config Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:15:57 --> URI Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Router Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Output Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Input Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 17:15:57 --> Language Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Loader Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Controller Class Initialized
ERROR - 2011-05-26 17:15:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 17:15:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 17:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 17:15:57 --> Model Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Model Class Initialized
DEBUG - 2011-05-26 17:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 17:15:57 --> Database Driver Class Initialized
DEBUG - 2011-05-26 17:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 17:15:57 --> Helper loaded: url_helper
DEBUG - 2011-05-26 17:15:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 17:15:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 17:15:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 17:15:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 17:15:57 --> Final output sent to browser
DEBUG - 2011-05-26 17:15:57 --> Total execution time: 0.1025
DEBUG - 2011-05-26 17:15:58 --> Config Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:15:58 --> URI Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Router Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Output Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Input Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 17:15:58 --> Language Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Loader Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Controller Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Model Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Model Class Initialized
DEBUG - 2011-05-26 17:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 17:15:58 --> Database Driver Class Initialized
DEBUG - 2011-05-26 17:15:59 --> Final output sent to browser
DEBUG - 2011-05-26 17:15:59 --> Total execution time: 0.6261
DEBUG - 2011-05-26 17:15:59 --> Config Class Initialized
DEBUG - 2011-05-26 17:15:59 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:15:59 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:15:59 --> URI Class Initialized
DEBUG - 2011-05-26 17:15:59 --> Router Class Initialized
ERROR - 2011-05-26 17:15:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-26 17:16:34 --> Config Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:16:34 --> URI Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Router Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Output Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Input Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 17:16:34 --> Language Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Loader Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Controller Class Initialized
ERROR - 2011-05-26 17:16:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 17:16:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 17:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 17:16:34 --> Model Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Model Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 17:16:34 --> Database Driver Class Initialized
DEBUG - 2011-05-26 17:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 17:16:34 --> Helper loaded: url_helper
DEBUG - 2011-05-26 17:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 17:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 17:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 17:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 17:16:34 --> Final output sent to browser
DEBUG - 2011-05-26 17:16:34 --> Total execution time: 0.0311
DEBUG - 2011-05-26 17:16:34 --> Config Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:16:34 --> URI Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Router Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Output Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Input Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 17:16:34 --> Language Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Loader Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Controller Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Model Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Model Class Initialized
DEBUG - 2011-05-26 17:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 17:16:34 --> Database Driver Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Config Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:16:35 --> URI Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Router Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Output Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Input Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 17:16:35 --> Language Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Loader Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Controller Class Initialized
ERROR - 2011-05-26 17:16:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 17:16:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 17:16:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 17:16:35 --> Model Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Model Class Initialized
DEBUG - 2011-05-26 17:16:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 17:16:35 --> Database Driver Class Initialized
DEBUG - 2011-05-26 17:16:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 17:16:35 --> Helper loaded: url_helper
DEBUG - 2011-05-26 17:16:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 17:16:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 17:16:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 17:16:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 17:16:35 --> Final output sent to browser
DEBUG - 2011-05-26 17:16:35 --> Total execution time: 0.0305
DEBUG - 2011-05-26 17:16:35 --> Final output sent to browser
DEBUG - 2011-05-26 17:16:35 --> Total execution time: 0.6812
DEBUG - 2011-05-26 17:16:36 --> Config Class Initialized
DEBUG - 2011-05-26 17:16:36 --> Hooks Class Initialized
DEBUG - 2011-05-26 17:16:36 --> Utf8 Class Initialized
DEBUG - 2011-05-26 17:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 17:16:36 --> URI Class Initialized
DEBUG - 2011-05-26 17:16:36 --> Router Class Initialized
ERROR - 2011-05-26 17:16:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-26 20:27:29 --> Config Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Hooks Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Utf8 Class Initialized
DEBUG - 2011-05-26 20:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 20:27:29 --> URI Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Router Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Output Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Input Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 20:27:29 --> Language Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Loader Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Controller Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Model Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Model Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Model Class Initialized
DEBUG - 2011-05-26 20:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 20:27:29 --> Database Driver Class Initialized
DEBUG - 2011-05-26 20:27:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 20:27:29 --> Helper loaded: url_helper
DEBUG - 2011-05-26 20:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 20:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 20:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 20:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 20:27:29 --> Final output sent to browser
DEBUG - 2011-05-26 20:27:29 --> Total execution time: 0.7907
DEBUG - 2011-05-26 22:20:15 --> Config Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:20:15 --> URI Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Router Class Initialized
DEBUG - 2011-05-26 22:20:15 --> No URI present. Default controller set.
DEBUG - 2011-05-26 22:20:15 --> Output Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Input Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:20:15 --> Language Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Loader Class Initialized
DEBUG - 2011-05-26 22:20:15 --> Controller Class Initialized
DEBUG - 2011-05-26 22:20:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-26 22:20:17 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:20:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:20:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:20:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:20:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:20:17 --> Final output sent to browser
DEBUG - 2011-05-26 22:20:17 --> Total execution time: 2.6401
DEBUG - 2011-05-26 22:50:24 --> Config Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Config Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Config Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:50:24 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:50:24 --> URI Class Initialized
DEBUG - 2011-05-26 22:50:24 --> URI Class Initialized
DEBUG - 2011-05-26 22:50:24 --> URI Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Router Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Router Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Router Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Output Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Output Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Output Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Input Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Input Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Input Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:50:24 --> Language Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Language Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Language Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Loader Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Loader Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Loader Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Controller Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Controller Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Controller Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Model Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Model Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Model Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Model Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Model Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Model Class Initialized
DEBUG - 2011-05-26 22:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:50:25 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:50:25 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:50:25 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:50:25 --> Final output sent to browser
DEBUG - 2011-05-26 22:50:25 --> Total execution time: 0.9640
DEBUG - 2011-05-26 22:50:25 --> Final output sent to browser
DEBUG - 2011-05-26 22:50:25 --> Total execution time: 1.0934
DEBUG - 2011-05-26 22:50:25 --> Final output sent to browser
DEBUG - 2011-05-26 22:50:25 --> Total execution time: 1.1210
DEBUG - 2011-05-26 22:53:48 --> Config Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:53:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:53:48 --> URI Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Router Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Output Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Input Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:53:48 --> Language Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Loader Class Initialized
DEBUG - 2011-05-26 22:53:48 --> Controller Class Initialized
ERROR - 2011-05-26 22:53:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:53:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:53:49 --> Model Class Initialized
DEBUG - 2011-05-26 22:53:49 --> Model Class Initialized
DEBUG - 2011-05-26 22:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:53:49 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:53:49 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:53:49 --> Final output sent to browser
DEBUG - 2011-05-26 22:53:49 --> Total execution time: 0.1707
DEBUG - 2011-05-26 22:53:50 --> Config Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:53:50 --> URI Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Router Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Output Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Input Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:53:50 --> Language Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Loader Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Controller Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Model Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Model Class Initialized
DEBUG - 2011-05-26 22:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:53:50 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:53:51 --> Final output sent to browser
DEBUG - 2011-05-26 22:53:51 --> Total execution time: 0.6074
DEBUG - 2011-05-26 22:53:52 --> Config Class Initialized
DEBUG - 2011-05-26 22:53:52 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:53:52 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:53:52 --> URI Class Initialized
DEBUG - 2011-05-26 22:53:52 --> Router Class Initialized
ERROR - 2011-05-26 22:53:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-26 22:54:13 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:13 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:13 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Controller Class Initialized
ERROR - 2011-05-26 22:54:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:54:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:13 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:13 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:13 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:54:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:54:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:54:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:54:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:54:13 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:13 --> Total execution time: 0.0272
DEBUG - 2011-05-26 22:54:14 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:14 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:14 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Controller Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:14 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:15 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:15 --> Total execution time: 0.5924
DEBUG - 2011-05-26 22:54:19 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:19 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:19 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Controller Class Initialized
ERROR - 2011-05-26 22:54:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:54:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:54:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:19 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:19 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:19 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:54:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:54:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:54:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:54:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:54:19 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:19 --> Total execution time: 0.0332
DEBUG - 2011-05-26 22:54:19 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:19 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:19 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:20 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:20 --> Controller Class Initialized
DEBUG - 2011-05-26 22:54:20 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:20 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:20 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:20 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:20 --> Total execution time: 0.6891
DEBUG - 2011-05-26 22:54:25 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:25 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:25 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Controller Class Initialized
ERROR - 2011-05-26 22:54:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:54:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:25 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:25 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:25 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:54:25 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:25 --> Total execution time: 0.0263
DEBUG - 2011-05-26 22:54:26 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:26 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:26 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Controller Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:26 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:26 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:26 --> Total execution time: 0.6597
DEBUG - 2011-05-26 22:54:31 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:31 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:31 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Controller Class Initialized
ERROR - 2011-05-26 22:54:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:54:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:31 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:31 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:31 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:54:31 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:31 --> Total execution time: 0.0294
DEBUG - 2011-05-26 22:54:32 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:32 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:32 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Controller Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:32 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:32 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:32 --> Total execution time: 0.5024
DEBUG - 2011-05-26 22:54:46 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:46 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:46 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Controller Class Initialized
ERROR - 2011-05-26 22:54:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:46 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:46 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:46 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:54:46 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:46 --> Total execution time: 0.0622
DEBUG - 2011-05-26 22:54:47 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:47 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:47 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Controller Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:47 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:48 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:48 --> Total execution time: 0.6936
DEBUG - 2011-05-26 22:54:55 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:55 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:55 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Controller Class Initialized
ERROR - 2011-05-26 22:54:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:54:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:54:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:55 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:55 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:54:55 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:54:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:54:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:54:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:54:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:54:55 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:55 --> Total execution time: 0.0276
DEBUG - 2011-05-26 22:54:55 --> Config Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:54:55 --> URI Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Router Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Output Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Input Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:54:55 --> Language Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Loader Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Controller Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Model Class Initialized
DEBUG - 2011-05-26 22:54:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:54:55 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:54:56 --> Final output sent to browser
DEBUG - 2011-05-26 22:54:56 --> Total execution time: 0.5815
DEBUG - 2011-05-26 22:55:02 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:02 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:02 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Controller Class Initialized
ERROR - 2011-05-26 22:55:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:55:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:55:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:02 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:02 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:02 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:55:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:55:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:55:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:55:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:55:02 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:02 --> Total execution time: 0.0862
DEBUG - 2011-05-26 22:55:02 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:02 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:02 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Controller Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:02 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:03 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:03 --> Total execution time: 0.5631
DEBUG - 2011-05-26 22:55:12 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:12 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:12 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Controller Class Initialized
ERROR - 2011-05-26 22:55:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:55:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:55:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:12 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:12 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:12 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:55:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:55:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:55:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:55:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:55:12 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:12 --> Total execution time: 0.0310
DEBUG - 2011-05-26 22:55:13 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:13 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:13 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Controller Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:13 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:13 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:13 --> Total execution time: 0.6595
DEBUG - 2011-05-26 22:55:31 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:31 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:31 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Controller Class Initialized
ERROR - 2011-05-26 22:55:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:55:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:55:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:31 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:31 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:31 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:55:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:55:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:55:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:55:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:55:31 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:31 --> Total execution time: 0.0287
DEBUG - 2011-05-26 22:55:32 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:32 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:32 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Controller Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:32 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:33 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:33 --> Total execution time: 0.7285
DEBUG - 2011-05-26 22:55:44 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:44 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:44 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Controller Class Initialized
ERROR - 2011-05-26 22:55:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:55:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:44 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:44 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:44 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:55:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:55:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:55:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:55:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:55:44 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:44 --> Total execution time: 0.0272
DEBUG - 2011-05-26 22:55:44 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:44 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:44 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Controller Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:44 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:45 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:45 --> Total execution time: 0.5655
DEBUG - 2011-05-26 22:55:50 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:50 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:50 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Controller Class Initialized
ERROR - 2011-05-26 22:55:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:55:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:50 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:50 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:50 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:55:50 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:50 --> Total execution time: 0.0277
DEBUG - 2011-05-26 22:55:51 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:51 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:51 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Controller Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:51 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:51 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:51 --> Total execution time: 0.5642
DEBUG - 2011-05-26 22:55:58 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:58 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:58 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Controller Class Initialized
ERROR - 2011-05-26 22:55:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:55:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:58 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:58 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:55:58 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:55:58 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:58 --> Total execution time: 0.0269
DEBUG - 2011-05-26 22:55:58 --> Config Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:55:58 --> URI Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Router Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Output Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Input Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:55:58 --> Language Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Loader Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Controller Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Model Class Initialized
DEBUG - 2011-05-26 22:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:55:58 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:55:59 --> Final output sent to browser
DEBUG - 2011-05-26 22:55:59 --> Total execution time: 0.5645
DEBUG - 2011-05-26 22:56:04 --> Config Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:56:04 --> URI Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Router Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Output Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Input Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:56:04 --> Language Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Loader Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Controller Class Initialized
ERROR - 2011-05-26 22:56:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 22:56:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 22:56:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:56:04 --> Model Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Model Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:56:04 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:56:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 22:56:04 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:56:04 --> Final output sent to browser
DEBUG - 2011-05-26 22:56:04 --> Total execution time: 0.0336
DEBUG - 2011-05-26 22:56:04 --> Config Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:56:04 --> URI Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Router Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Output Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Input Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:56:04 --> Language Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Loader Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Controller Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Model Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Model Class Initialized
DEBUG - 2011-05-26 22:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:56:04 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:56:05 --> Final output sent to browser
DEBUG - 2011-05-26 22:56:05 --> Total execution time: 0.5565
DEBUG - 2011-05-26 22:57:18 --> Config Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:57:18 --> URI Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Router Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Output Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Input Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:57:18 --> Language Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Loader Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Controller Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Model Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Model Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Model Class Initialized
DEBUG - 2011-05-26 22:57:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:57:18 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:57:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 22:57:18 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:57:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:57:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:57:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:57:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:57:18 --> Final output sent to browser
DEBUG - 2011-05-26 22:57:18 --> Total execution time: 0.3327
DEBUG - 2011-05-26 22:57:38 --> Config Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Hooks Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Utf8 Class Initialized
DEBUG - 2011-05-26 22:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 22:57:38 --> URI Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Router Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Output Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Input Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 22:57:38 --> Language Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Loader Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Controller Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Model Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Model Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Model Class Initialized
DEBUG - 2011-05-26 22:57:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 22:57:38 --> Database Driver Class Initialized
DEBUG - 2011-05-26 22:57:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-26 22:57:38 --> Helper loaded: url_helper
DEBUG - 2011-05-26 22:57:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 22:57:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 22:57:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 22:57:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 22:57:38 --> Final output sent to browser
DEBUG - 2011-05-26 22:57:38 --> Total execution time: 0.0443
DEBUG - 2011-05-26 23:30:18 --> Config Class Initialized
DEBUG - 2011-05-26 23:30:18 --> Hooks Class Initialized
DEBUG - 2011-05-26 23:30:18 --> Utf8 Class Initialized
DEBUG - 2011-05-26 23:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 23:30:19 --> URI Class Initialized
DEBUG - 2011-05-26 23:30:19 --> Router Class Initialized
ERROR - 2011-05-26 23:30:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-26 23:56:13 --> Config Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Hooks Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Utf8 Class Initialized
DEBUG - 2011-05-26 23:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-26 23:56:13 --> URI Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Router Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Output Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Input Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-26 23:56:13 --> Language Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Loader Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Controller Class Initialized
ERROR - 2011-05-26 23:56:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-26 23:56:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-26 23:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 23:56:13 --> Model Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Model Class Initialized
DEBUG - 2011-05-26 23:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-26 23:56:13 --> Database Driver Class Initialized
DEBUG - 2011-05-26 23:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-26 23:56:13 --> Helper loaded: url_helper
DEBUG - 2011-05-26 23:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-26 23:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-26 23:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-26 23:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-26 23:56:13 --> Final output sent to browser
DEBUG - 2011-05-26 23:56:13 --> Total execution time: 0.4823

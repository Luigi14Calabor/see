<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-11 01:00:44 --> Config Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:00:44 --> URI Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Router Class Initialized
DEBUG - 2011-08-11 01:00:44 --> No URI present. Default controller set.
DEBUG - 2011-08-11 01:00:44 --> Output Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Input Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:00:44 --> Language Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Loader Class Initialized
DEBUG - 2011-08-11 01:00:44 --> Controller Class Initialized
DEBUG - 2011-08-11 01:00:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 01:00:44 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:00:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:00:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:00:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:00:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:00:44 --> Final output sent to browser
DEBUG - 2011-08-11 01:00:44 --> Total execution time: 0.0304
DEBUG - 2011-08-11 01:01:42 --> Config Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:01:42 --> URI Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Router Class Initialized
ERROR - 2011-08-11 01:01:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 01:01:42 --> Config Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:01:42 --> URI Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Router Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Output Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Input Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:01:42 --> Language Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Loader Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Controller Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Model Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Model Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Model Class Initialized
DEBUG - 2011-08-11 01:01:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:01:43 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:01:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:01:43 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:01:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:01:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:01:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:01:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:01:43 --> Final output sent to browser
DEBUG - 2011-08-11 01:01:43 --> Total execution time: 0.4107
DEBUG - 2011-08-11 01:07:29 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:29 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Router Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Output Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Input Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:07:29 --> Language Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Loader Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Controller Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:07:29 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:07:29 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:07:29 --> Final output sent to browser
DEBUG - 2011-08-11 01:07:29 --> Total execution time: 0.0546
DEBUG - 2011-08-11 01:07:31 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:31 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:31 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:31 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:31 --> Router Class Initialized
ERROR - 2011-08-11 01:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 01:07:31 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:31 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:31 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:31 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:31 --> Router Class Initialized
ERROR - 2011-08-11 01:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 01:07:52 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:52 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Router Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Output Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Input Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:07:52 --> Language Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Loader Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Controller Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:07:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:07:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:07:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:07:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:07:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:07:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:07:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:07:52 --> Final output sent to browser
DEBUG - 2011-08-11 01:07:52 --> Total execution time: 0.4414
DEBUG - 2011-08-11 01:07:53 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:53 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:53 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:53 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:53 --> Router Class Initialized
ERROR - 2011-08-11 01:07:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 01:07:54 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:54 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Router Class Initialized
ERROR - 2011-08-11 01:07:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 01:07:54 --> Config Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:07:54 --> URI Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Router Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Output Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Input Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:07:54 --> Language Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Loader Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Controller Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Model Class Initialized
DEBUG - 2011-08-11 01:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:07:54 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:07:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:07:54 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:07:54 --> Final output sent to browser
DEBUG - 2011-08-11 01:07:54 --> Total execution time: 0.0638
DEBUG - 2011-08-11 01:08:15 --> Config Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:08:15 --> URI Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Router Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Output Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Input Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:08:15 --> Language Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Loader Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Controller Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:08:15 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:08:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:08:15 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:08:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:08:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:08:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:08:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:08:15 --> Final output sent to browser
DEBUG - 2011-08-11 01:08:15 --> Total execution time: 0.3912
DEBUG - 2011-08-11 01:08:18 --> Config Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:08:18 --> URI Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Router Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Output Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Input Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:08:18 --> Language Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Loader Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Controller Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:08:18 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:08:18 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:08:18 --> Final output sent to browser
DEBUG - 2011-08-11 01:08:18 --> Total execution time: 0.0485
DEBUG - 2011-08-11 01:08:51 --> Config Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:08:51 --> URI Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Router Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Output Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Input Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:08:51 --> Language Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Loader Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Controller Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:08:51 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:08:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:08:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:08:52 --> Final output sent to browser
DEBUG - 2011-08-11 01:08:52 --> Total execution time: 0.5838
DEBUG - 2011-08-11 01:08:55 --> Config Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:08:55 --> URI Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Router Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Output Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Input Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:08:55 --> Language Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Loader Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Controller Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:08:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:08:55 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:08:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:08:55 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:08:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:08:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:08:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:08:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:08:55 --> Final output sent to browser
DEBUG - 2011-08-11 01:08:55 --> Total execution time: 0.0474
DEBUG - 2011-08-11 01:09:04 --> Config Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:09:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:09:04 --> URI Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Router Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Output Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Input Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:09:04 --> Language Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Loader Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Controller Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:09:04 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:09:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:09:04 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:09:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:09:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:09:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:09:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:09:04 --> Final output sent to browser
DEBUG - 2011-08-11 01:09:04 --> Total execution time: 0.2497
DEBUG - 2011-08-11 01:09:05 --> Config Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:09:05 --> URI Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Router Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Output Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Input Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:09:05 --> Language Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Loader Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Controller Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:09:05 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:09:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:09:05 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:09:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:09:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:09:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:09:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:09:05 --> Final output sent to browser
DEBUG - 2011-08-11 01:09:05 --> Total execution time: 0.0463
DEBUG - 2011-08-11 01:09:24 --> Config Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:09:24 --> URI Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Router Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Output Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Input Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:09:24 --> Language Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Loader Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Controller Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:09:25 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:09:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:09:25 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:09:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:09:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:09:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:09:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:09:25 --> Final output sent to browser
DEBUG - 2011-08-11 01:09:25 --> Total execution time: 0.0470
DEBUG - 2011-08-11 01:09:59 --> Config Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:09:59 --> URI Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Router Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Output Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Input Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:09:59 --> Language Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Loader Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Controller Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Model Class Initialized
DEBUG - 2011-08-11 01:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:10:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:10:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:10:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:10:00 --> Final output sent to browser
DEBUG - 2011-08-11 01:10:00 --> Total execution time: 0.2455
DEBUG - 2011-08-11 01:10:20 --> Config Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:10:20 --> URI Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Router Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Output Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Input Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:10:20 --> Language Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Loader Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Controller Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Model Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Model Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Model Class Initialized
DEBUG - 2011-08-11 01:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:10:20 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:10:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:10:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:10:21 --> Final output sent to browser
DEBUG - 2011-08-11 01:10:21 --> Total execution time: 0.1681
DEBUG - 2011-08-11 01:10:44 --> Config Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:10:44 --> URI Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Router Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Output Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Input Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:10:44 --> Language Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Loader Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Controller Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Model Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Model Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Model Class Initialized
DEBUG - 2011-08-11 01:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:10:44 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:10:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:10:44 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:10:44 --> Final output sent to browser
DEBUG - 2011-08-11 01:10:44 --> Total execution time: 0.0466
DEBUG - 2011-08-11 01:11:09 --> Config Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:11:09 --> URI Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Router Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Output Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Input Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:11:09 --> Language Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Loader Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Controller Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:11:09 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:11:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:11:09 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:11:09 --> Final output sent to browser
DEBUG - 2011-08-11 01:11:09 --> Total execution time: 0.2180
DEBUG - 2011-08-11 01:11:10 --> Config Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:11:10 --> URI Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Router Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Output Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Input Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:11:10 --> Language Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Loader Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Controller Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:11:10 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:11:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:11:11 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:11:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:11:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:11:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:11:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:11:11 --> Final output sent to browser
DEBUG - 2011-08-11 01:11:11 --> Total execution time: 0.0475
DEBUG - 2011-08-11 01:11:29 --> Config Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:11:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:11:29 --> URI Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Router Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Output Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Input Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:11:29 --> Language Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Loader Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Controller Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:11:29 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:11:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:11:29 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:11:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:11:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:11:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:11:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:11:29 --> Final output sent to browser
DEBUG - 2011-08-11 01:11:29 --> Total execution time: 0.4359
DEBUG - 2011-08-11 01:11:33 --> Config Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:11:33 --> URI Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Router Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Output Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Input Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:11:33 --> Language Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Loader Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Controller Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:11:33 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:11:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:11:33 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:11:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:11:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:11:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:11:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:11:33 --> Final output sent to browser
DEBUG - 2011-08-11 01:11:33 --> Total execution time: 0.0699
DEBUG - 2011-08-11 01:11:41 --> Config Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:11:41 --> URI Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Router Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Output Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Input Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:11:41 --> Language Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Loader Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Controller Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:11:41 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:11:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:11:41 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:11:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:11:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:11:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:11:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:11:41 --> Final output sent to browser
DEBUG - 2011-08-11 01:11:41 --> Total execution time: 0.3205
DEBUG - 2011-08-11 01:11:43 --> Config Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:11:43 --> URI Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Router Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Output Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Input Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:11:43 --> Language Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Loader Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Controller Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Model Class Initialized
DEBUG - 2011-08-11 01:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:11:43 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:11:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:11:43 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:11:43 --> Final output sent to browser
DEBUG - 2011-08-11 01:11:43 --> Total execution time: 0.0689
DEBUG - 2011-08-11 01:12:00 --> Config Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:12:00 --> URI Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Router Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Output Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Input Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:12:00 --> Language Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Loader Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Controller Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:12:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:12:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:12:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:12:00 --> Final output sent to browser
DEBUG - 2011-08-11 01:12:00 --> Total execution time: 0.2848
DEBUG - 2011-08-11 01:12:01 --> Config Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:12:01 --> URI Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Router Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Output Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Input Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:12:01 --> Language Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Loader Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Controller Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:12:01 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:12:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:12:01 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:12:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:12:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:12:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:12:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:12:01 --> Final output sent to browser
DEBUG - 2011-08-11 01:12:01 --> Total execution time: 0.1607
DEBUG - 2011-08-11 01:12:16 --> Config Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:12:16 --> URI Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Router Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Output Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Input Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:12:16 --> Language Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Loader Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Controller Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:12:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:12:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:12:17 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:12:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:12:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:12:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:12:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:12:17 --> Final output sent to browser
DEBUG - 2011-08-11 01:12:17 --> Total execution time: 0.6698
DEBUG - 2011-08-11 01:12:19 --> Config Class Initialized
DEBUG - 2011-08-11 01:12:19 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:12:19 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:12:20 --> URI Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Router Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Output Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Input Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:12:20 --> Language Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Loader Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Controller Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:12:20 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:12:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:12:20 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:12:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:12:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:12:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:12:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:12:20 --> Final output sent to browser
DEBUG - 2011-08-11 01:12:20 --> Total execution time: 0.0461
DEBUG - 2011-08-11 01:12:36 --> Config Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:12:36 --> URI Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Router Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Output Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Input Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:12:36 --> Language Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Loader Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Controller Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:12:36 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:12:36 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:12:36 --> Final output sent to browser
DEBUG - 2011-08-11 01:12:36 --> Total execution time: 0.2477
DEBUG - 2011-08-11 01:12:55 --> Config Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:12:55 --> URI Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Router Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Output Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Input Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:12:55 --> Language Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Loader Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Controller Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:12:55 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:12:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:12:55 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:12:55 --> Final output sent to browser
DEBUG - 2011-08-11 01:12:55 --> Total execution time: 0.3858
DEBUG - 2011-08-11 01:13:12 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:12 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:12 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:12 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:12 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:12 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:12 --> Total execution time: 0.4039
DEBUG - 2011-08-11 01:13:14 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:14 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:14 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:14 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:15 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:15 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:15 --> Total execution time: 0.0784
DEBUG - 2011-08-11 01:13:16 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:16 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:16 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:16 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:16 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:16 --> Total execution time: 0.0663
DEBUG - 2011-08-11 01:13:21 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:21 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:21 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:21 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:21 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:21 --> Total execution time: 0.0752
DEBUG - 2011-08-11 01:13:26 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:26 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:26 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:26 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:26 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:26 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:26 --> Total execution time: 0.5039
DEBUG - 2011-08-11 01:13:28 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:28 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:28 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:28 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:28 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:28 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:28 --> Total execution time: 0.0493
DEBUG - 2011-08-11 01:13:39 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:39 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:39 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:39 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:39 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:39 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:39 --> Total execution time: 0.2879
DEBUG - 2011-08-11 01:13:51 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:51 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:51 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:51 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:52 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:52 --> Total execution time: 0.6082
DEBUG - 2011-08-11 01:13:56 --> Config Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:13:56 --> URI Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Router Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Output Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Input Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:13:56 --> Language Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Loader Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Controller Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Model Class Initialized
DEBUG - 2011-08-11 01:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:13:56 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:13:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:13:56 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:13:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:13:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:13:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:13:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:13:56 --> Final output sent to browser
DEBUG - 2011-08-11 01:13:56 --> Total execution time: 0.0529
DEBUG - 2011-08-11 01:14:03 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:03 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:03 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:03 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:03 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:03 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:03 --> Total execution time: 0.0497
DEBUG - 2011-08-11 01:14:05 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:05 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:05 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:05 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:05 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:05 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:05 --> Total execution time: 0.3227
DEBUG - 2011-08-11 01:14:09 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:09 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:09 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:09 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:09 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:09 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:09 --> Total execution time: 0.1214
DEBUG - 2011-08-11 01:14:17 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:17 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:17 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:17 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:18 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:18 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:18 --> Total execution time: 0.5445
DEBUG - 2011-08-11 01:14:21 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:21 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:21 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:21 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:21 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:21 --> Total execution time: 0.2559
DEBUG - 2011-08-11 01:14:35 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:35 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:35 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:35 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:35 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:35 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:35 --> Total execution time: 0.0473
DEBUG - 2011-08-11 01:14:39 --> Config Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:14:39 --> URI Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Router Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Output Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Input Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:14:39 --> Language Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Loader Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Controller Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Model Class Initialized
DEBUG - 2011-08-11 01:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:14:39 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:14:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 01:14:39 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:14:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:14:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:14:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:14:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:14:39 --> Final output sent to browser
DEBUG - 2011-08-11 01:14:39 --> Total execution time: 0.0415
DEBUG - 2011-08-11 01:17:43 --> Config Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:17:43 --> URI Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Router Class Initialized
DEBUG - 2011-08-11 01:17:43 --> No URI present. Default controller set.
DEBUG - 2011-08-11 01:17:43 --> Output Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Input Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:17:43 --> Language Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Loader Class Initialized
DEBUG - 2011-08-11 01:17:43 --> Controller Class Initialized
DEBUG - 2011-08-11 01:17:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 01:17:43 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:17:43 --> Final output sent to browser
DEBUG - 2011-08-11 01:17:43 --> Total execution time: 0.0273
DEBUG - 2011-08-11 01:40:55 --> Config Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:40:55 --> URI Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Router Class Initialized
ERROR - 2011-08-11 01:40:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 01:40:55 --> Config Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 01:40:55 --> URI Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Router Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Output Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Input Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 01:40:55 --> Language Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Loader Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Controller Class Initialized
ERROR - 2011-08-11 01:40:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 01:40:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 01:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 01:40:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Model Class Initialized
DEBUG - 2011-08-11 01:40:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 01:40:56 --> Database Driver Class Initialized
DEBUG - 2011-08-11 01:40:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 01:40:56 --> Helper loaded: url_helper
DEBUG - 2011-08-11 01:40:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 01:40:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 01:40:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 01:40:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 01:40:56 --> Final output sent to browser
DEBUG - 2011-08-11 01:40:56 --> Total execution time: 0.6793
DEBUG - 2011-08-11 02:40:06 --> Config Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Hooks Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Utf8 Class Initialized
DEBUG - 2011-08-11 02:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 02:40:06 --> URI Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Router Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Output Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Input Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 02:40:06 --> Language Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Loader Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Controller Class Initialized
ERROR - 2011-08-11 02:40:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 02:40:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 02:40:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 02:40:06 --> Model Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Model Class Initialized
DEBUG - 2011-08-11 02:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 02:40:07 --> Database Driver Class Initialized
DEBUG - 2011-08-11 02:40:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 02:40:08 --> Helper loaded: url_helper
DEBUG - 2011-08-11 02:40:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 02:40:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 02:40:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 02:40:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 02:40:08 --> Final output sent to browser
DEBUG - 2011-08-11 02:40:08 --> Total execution time: 1.6799
DEBUG - 2011-08-11 02:40:08 --> Config Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-11 02:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 02:40:08 --> URI Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Router Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Output Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Input Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 02:40:08 --> Language Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Loader Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Controller Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Model Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Model Class Initialized
DEBUG - 2011-08-11 02:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 02:40:08 --> Database Driver Class Initialized
DEBUG - 2011-08-11 02:40:09 --> Final output sent to browser
DEBUG - 2011-08-11 02:40:09 --> Total execution time: 0.7988
DEBUG - 2011-08-11 02:40:10 --> Config Class Initialized
DEBUG - 2011-08-11 02:40:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 02:40:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 02:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 02:40:10 --> URI Class Initialized
DEBUG - 2011-08-11 02:40:10 --> Router Class Initialized
ERROR - 2011-08-11 02:40:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 02:40:10 --> Config Class Initialized
DEBUG - 2011-08-11 02:40:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 02:40:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 02:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 02:40:10 --> URI Class Initialized
DEBUG - 2011-08-11 02:40:10 --> Router Class Initialized
ERROR - 2011-08-11 02:40:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 02:40:49 --> Config Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Hooks Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Utf8 Class Initialized
DEBUG - 2011-08-11 02:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 02:40:49 --> URI Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Router Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Output Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Input Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 02:40:49 --> Language Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Loader Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Controller Class Initialized
ERROR - 2011-08-11 02:40:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 02:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 02:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 02:40:49 --> Model Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Model Class Initialized
DEBUG - 2011-08-11 02:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 02:40:49 --> Database Driver Class Initialized
DEBUG - 2011-08-11 02:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 02:40:49 --> Helper loaded: url_helper
DEBUG - 2011-08-11 02:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 02:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 02:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 02:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 02:40:49 --> Final output sent to browser
DEBUG - 2011-08-11 02:40:49 --> Total execution time: 0.0316
DEBUG - 2011-08-11 03:05:18 --> Config Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Hooks Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Utf8 Class Initialized
DEBUG - 2011-08-11 03:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 03:05:18 --> URI Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Router Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Output Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Input Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 03:05:18 --> Language Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Loader Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Controller Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Model Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Model Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 03:05:18 --> Database Driver Class Initialized
DEBUG - 2011-08-11 03:05:18 --> Final output sent to browser
DEBUG - 2011-08-11 03:05:18 --> Total execution time: 0.8417
DEBUG - 2011-08-11 04:15:56 --> Config Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Hooks Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Utf8 Class Initialized
DEBUG - 2011-08-11 04:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 04:15:56 --> URI Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Router Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Output Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Input Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 04:15:56 --> Language Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Loader Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Controller Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Model Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Model Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Model Class Initialized
DEBUG - 2011-08-11 04:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 04:15:57 --> Database Driver Class Initialized
DEBUG - 2011-08-11 04:16:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 04:16:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 04:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 04:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 04:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 04:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 04:16:00 --> Final output sent to browser
DEBUG - 2011-08-11 04:16:00 --> Total execution time: 3.6152
DEBUG - 2011-08-11 04:26:55 --> Config Class Initialized
DEBUG - 2011-08-11 04:26:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 04:26:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 04:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 04:26:55 --> URI Class Initialized
DEBUG - 2011-08-11 04:26:55 --> Router Class Initialized
ERROR - 2011-08-11 04:26:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 04:44:28 --> Config Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Hooks Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Utf8 Class Initialized
DEBUG - 2011-08-11 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 04:44:28 --> URI Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Router Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Output Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Input Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 04:44:28 --> Language Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Loader Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Controller Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Model Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Model Class Initialized
DEBUG - 2011-08-11 04:44:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 04:44:28 --> Database Driver Class Initialized
DEBUG - 2011-08-11 04:44:29 --> Final output sent to browser
DEBUG - 2011-08-11 04:44:29 --> Total execution time: 0.7935
DEBUG - 2011-08-11 06:09:09 --> Config Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:09:09 --> URI Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Router Class Initialized
DEBUG - 2011-08-11 06:09:09 --> No URI present. Default controller set.
DEBUG - 2011-08-11 06:09:09 --> Output Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Input Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:09:09 --> Language Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Loader Class Initialized
DEBUG - 2011-08-11 06:09:09 --> Controller Class Initialized
DEBUG - 2011-08-11 06:09:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 06:09:09 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:09:09 --> Final output sent to browser
DEBUG - 2011-08-11 06:09:09 --> Total execution time: 0.2463
DEBUG - 2011-08-11 06:30:36 --> Config Class Initialized
DEBUG - 2011-08-11 06:30:36 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:30:36 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:30:36 --> URI Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Router Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Output Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Input Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:30:37 --> Language Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Loader Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Controller Class Initialized
ERROR - 2011-08-11 06:30:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:30:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:30:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:30:37 --> Model Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Model Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:30:37 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Config Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:30:37 --> URI Class Initialized
DEBUG - 2011-08-11 06:30:37 --> Router Class Initialized
ERROR - 2011-08-11 06:30:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 06:30:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:30:37 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:30:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:30:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:30:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:30:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:30:37 --> Final output sent to browser
DEBUG - 2011-08-11 06:30:37 --> Total execution time: 0.9364
DEBUG - 2011-08-11 06:30:40 --> Config Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:30:40 --> URI Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Router Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Output Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Input Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:30:40 --> Language Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Loader Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Controller Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Model Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Model Class Initialized
DEBUG - 2011-08-11 06:30:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:30:40 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:30:41 --> Final output sent to browser
DEBUG - 2011-08-11 06:30:41 --> Total execution time: 0.7826
DEBUG - 2011-08-11 06:30:43 --> Config Class Initialized
DEBUG - 2011-08-11 06:30:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:30:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:30:43 --> URI Class Initialized
DEBUG - 2011-08-11 06:30:43 --> Router Class Initialized
ERROR - 2011-08-11 06:30:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:30:59 --> Config Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:30:59 --> URI Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Router Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Output Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Input Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:30:59 --> Language Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Loader Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Controller Class Initialized
ERROR - 2011-08-11 06:30:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:30:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:30:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:30:59 --> Model Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Model Class Initialized
DEBUG - 2011-08-11 06:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:30:59 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:30:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:30:59 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:30:59 --> Final output sent to browser
DEBUG - 2011-08-11 06:30:59 --> Total execution time: 0.0285
DEBUG - 2011-08-11 06:31:00 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:00 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:00 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Controller Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:01 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:01 --> Total execution time: 0.6783
DEBUG - 2011-08-11 06:31:03 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:03 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:03 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:03 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:03 --> Router Class Initialized
ERROR - 2011-08-11 06:31:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:10 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:10 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:10 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Controller Class Initialized
ERROR - 2011-08-11 06:31:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:31:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:31:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:10 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:10 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:31:10 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:10 --> Total execution time: 0.0472
DEBUG - 2011-08-11 06:31:11 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:11 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:11 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Controller Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:11 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:11 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:11 --> Total execution time: 0.6443
DEBUG - 2011-08-11 06:31:12 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:12 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:12 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Controller Class Initialized
ERROR - 2011-08-11 06:31:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:31:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:31:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:12 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:12 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:12 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:31:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:31:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:31:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:31:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:31:12 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:12 --> Total execution time: 0.0471
DEBUG - 2011-08-11 06:31:13 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:13 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:13 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:13 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:13 --> Router Class Initialized
ERROR - 2011-08-11 06:31:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:17 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:17 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:17 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Controller Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:17 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 06:31:19 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:31:19 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:19 --> Total execution time: 1.3097
DEBUG - 2011-08-11 06:31:19 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:19 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:19 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Controller Class Initialized
ERROR - 2011-08-11 06:31:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:31:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:19 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:19 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:19 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:31:19 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:19 --> Total execution time: 0.0512
DEBUG - 2011-08-11 06:31:20 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:20 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:20 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Controller Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:20 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:21 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:21 --> Total execution time: 0.6710
DEBUG - 2011-08-11 06:31:23 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:23 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:23 --> Router Class Initialized
ERROR - 2011-08-11 06:31:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:33 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:33 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:33 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:33 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:33 --> Router Class Initialized
ERROR - 2011-08-11 06:31:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:34 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:34 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:34 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:34 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:34 --> Router Class Initialized
ERROR - 2011-08-11 06:31:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:35 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:35 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:35 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:35 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:35 --> Router Class Initialized
ERROR - 2011-08-11 06:31:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:39 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:39 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:39 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:39 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:39 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:39 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:39 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:39 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:40 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:40 --> Controller Class Initialized
DEBUG - 2011-08-11 06:31:40 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:40 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:40 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:40 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 06:31:40 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:31:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:31:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:31:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:31:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:31:40 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:40 --> Total execution time: 0.0482
DEBUG - 2011-08-11 06:31:42 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:42 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:42 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:42 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:42 --> Router Class Initialized
ERROR - 2011-08-11 06:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:31:47 --> Config Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:31:47 --> URI Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Router Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Output Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Input Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:31:47 --> Language Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Loader Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Controller Class Initialized
ERROR - 2011-08-11 06:31:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:31:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:31:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:47 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Model Class Initialized
DEBUG - 2011-08-11 06:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:31:47 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:31:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:31:47 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:31:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:31:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:31:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:31:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:31:47 --> Final output sent to browser
DEBUG - 2011-08-11 06:31:47 --> Total execution time: 0.0675
DEBUG - 2011-08-11 06:45:49 --> Config Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:45:49 --> URI Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Router Class Initialized
DEBUG - 2011-08-11 06:45:49 --> No URI present. Default controller set.
DEBUG - 2011-08-11 06:45:49 --> Output Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Input Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:45:49 --> Language Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Loader Class Initialized
DEBUG - 2011-08-11 06:45:49 --> Controller Class Initialized
DEBUG - 2011-08-11 06:45:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 06:45:49 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:45:49 --> Final output sent to browser
DEBUG - 2011-08-11 06:45:49 --> Total execution time: 0.0415
DEBUG - 2011-08-11 06:45:51 --> Config Class Initialized
DEBUG - 2011-08-11 06:45:51 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:45:51 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:45:51 --> URI Class Initialized
DEBUG - 2011-08-11 06:45:51 --> Router Class Initialized
ERROR - 2011-08-11 06:45:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:45:59 --> Config Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:45:59 --> URI Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Router Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Output Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Input Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:45:59 --> Language Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Loader Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Controller Class Initialized
ERROR - 2011-08-11 06:45:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:45:59 --> Model Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Model Class Initialized
DEBUG - 2011-08-11 06:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:45:59 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:45:59 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:45:59 --> Final output sent to browser
DEBUG - 2011-08-11 06:45:59 --> Total execution time: 0.0369
DEBUG - 2011-08-11 06:46:00 --> Config Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:46:00 --> URI Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Router Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Output Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Input Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:46:00 --> Language Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Loader Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Controller Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Model Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Model Class Initialized
DEBUG - 2011-08-11 06:46:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:46:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:46:01 --> Final output sent to browser
DEBUG - 2011-08-11 06:46:01 --> Total execution time: 0.6172
DEBUG - 2011-08-11 06:46:02 --> Config Class Initialized
DEBUG - 2011-08-11 06:46:02 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:46:02 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:46:02 --> URI Class Initialized
DEBUG - 2011-08-11 06:46:02 --> Router Class Initialized
ERROR - 2011-08-11 06:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 06:46:22 --> Config Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:46:22 --> URI Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Router Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Output Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Input Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:46:22 --> Language Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Loader Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Controller Class Initialized
ERROR - 2011-08-11 06:46:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 06:46:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 06:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:46:22 --> Model Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Model Class Initialized
DEBUG - 2011-08-11 06:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:46:22 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 06:46:22 --> Helper loaded: url_helper
DEBUG - 2011-08-11 06:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 06:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 06:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 06:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 06:46:22 --> Final output sent to browser
DEBUG - 2011-08-11 06:46:22 --> Total execution time: 0.0424
DEBUG - 2011-08-11 06:46:23 --> Config Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:46:23 --> URI Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Router Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Output Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Input Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 06:46:23 --> Language Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Loader Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Controller Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Model Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Model Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 06:46:23 --> Database Driver Class Initialized
DEBUG - 2011-08-11 06:46:23 --> Final output sent to browser
DEBUG - 2011-08-11 06:46:23 --> Total execution time: 0.4969
DEBUG - 2011-08-11 06:46:27 --> Config Class Initialized
DEBUG - 2011-08-11 06:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 06:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 06:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 06:46:27 --> URI Class Initialized
DEBUG - 2011-08-11 06:46:27 --> Router Class Initialized
ERROR - 2011-08-11 06:46:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:28:17 --> Config Class Initialized
DEBUG - 2011-08-11 07:28:17 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:28:17 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:28:17 --> URI Class Initialized
DEBUG - 2011-08-11 07:28:17 --> Router Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Output Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Input Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:28:18 --> Language Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Loader Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Controller Class Initialized
ERROR - 2011-08-11 07:28:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:28:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:28:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:28:18 --> Model Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Model Class Initialized
DEBUG - 2011-08-11 07:28:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:28:18 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:28:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:28:18 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:28:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:28:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:28:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:28:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:28:18 --> Final output sent to browser
DEBUG - 2011-08-11 07:28:18 --> Total execution time: 0.2745
DEBUG - 2011-08-11 07:28:23 --> Config Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:28:23 --> URI Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Router Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Output Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Input Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:28:23 --> Language Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Loader Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Controller Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Model Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Model Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:28:23 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:28:23 --> Final output sent to browser
DEBUG - 2011-08-11 07:28:23 --> Total execution time: 0.6101
DEBUG - 2011-08-11 07:28:50 --> Config Class Initialized
DEBUG - 2011-08-11 07:28:50 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:28:50 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:28:50 --> URI Class Initialized
DEBUG - 2011-08-11 07:28:50 --> Router Class Initialized
ERROR - 2011-08-11 07:28:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:29:52 --> Config Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:29:52 --> URI Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Router Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Output Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Input Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:29:52 --> Language Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Loader Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Controller Class Initialized
ERROR - 2011-08-11 07:29:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:29:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:29:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:29:52 --> Model Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Model Class Initialized
DEBUG - 2011-08-11 07:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:29:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:29:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:29:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:29:52 --> Final output sent to browser
DEBUG - 2011-08-11 07:29:52 --> Total execution time: 0.5003
DEBUG - 2011-08-11 07:29:53 --> Config Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:29:53 --> URI Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Router Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Output Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Input Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:29:53 --> Language Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Loader Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Controller Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Model Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Model Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:29:53 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:29:53 --> Final output sent to browser
DEBUG - 2011-08-11 07:29:53 --> Total execution time: 0.5113
DEBUG - 2011-08-11 07:29:54 --> Config Class Initialized
DEBUG - 2011-08-11 07:29:54 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:29:54 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:29:54 --> URI Class Initialized
DEBUG - 2011-08-11 07:29:54 --> Router Class Initialized
ERROR - 2011-08-11 07:29:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:30:25 --> Config Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:30:25 --> URI Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Router Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Output Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Input Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:30:25 --> Language Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Loader Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Controller Class Initialized
ERROR - 2011-08-11 07:30:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:30:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:30:25 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:30:25 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:30:25 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:30:25 --> Final output sent to browser
DEBUG - 2011-08-11 07:30:25 --> Total execution time: 0.0306
DEBUG - 2011-08-11 07:30:26 --> Config Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:30:26 --> URI Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Router Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Output Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Input Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:30:26 --> Language Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Loader Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Controller Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:30:26 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:30:27 --> Final output sent to browser
DEBUG - 2011-08-11 07:30:27 --> Total execution time: 0.9162
DEBUG - 2011-08-11 07:30:28 --> Config Class Initialized
DEBUG - 2011-08-11 07:30:28 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:30:28 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:30:28 --> URI Class Initialized
DEBUG - 2011-08-11 07:30:28 --> Router Class Initialized
ERROR - 2011-08-11 07:30:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:30:41 --> Config Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:30:41 --> URI Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Router Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Output Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Input Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:30:41 --> Language Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Loader Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Controller Class Initialized
ERROR - 2011-08-11 07:30:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:30:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:30:41 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:30:41 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:30:41 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:30:41 --> Final output sent to browser
DEBUG - 2011-08-11 07:30:41 --> Total execution time: 0.0299
DEBUG - 2011-08-11 07:30:42 --> Config Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:30:42 --> URI Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Router Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Output Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Input Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:30:42 --> Language Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Loader Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Controller Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Model Class Initialized
DEBUG - 2011-08-11 07:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:30:42 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:30:43 --> Final output sent to browser
DEBUG - 2011-08-11 07:30:43 --> Total execution time: 0.5663
DEBUG - 2011-08-11 07:30:44 --> Config Class Initialized
DEBUG - 2011-08-11 07:30:44 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:30:44 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:30:44 --> URI Class Initialized
DEBUG - 2011-08-11 07:30:44 --> Router Class Initialized
ERROR - 2011-08-11 07:30:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:31:16 --> Config Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:31:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:31:16 --> URI Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Router Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Output Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Input Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:31:16 --> Language Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Loader Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Controller Class Initialized
ERROR - 2011-08-11 07:31:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:31:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:31:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:31:16 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:31:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:31:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:31:16 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:31:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:31:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:31:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:31:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:31:16 --> Final output sent to browser
DEBUG - 2011-08-11 07:31:16 --> Total execution time: 0.0279
DEBUG - 2011-08-11 07:31:17 --> Config Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:31:17 --> URI Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Router Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Output Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Input Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:31:17 --> Language Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Loader Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Controller Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:31:17 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:31:18 --> Final output sent to browser
DEBUG - 2011-08-11 07:31:18 --> Total execution time: 1.1826
DEBUG - 2011-08-11 07:31:19 --> Config Class Initialized
DEBUG - 2011-08-11 07:31:19 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:31:19 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:31:19 --> URI Class Initialized
DEBUG - 2011-08-11 07:31:19 --> Router Class Initialized
ERROR - 2011-08-11 07:31:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:31:40 --> Config Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:31:40 --> URI Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Router Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Output Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Input Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:31:40 --> Language Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Loader Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Controller Class Initialized
ERROR - 2011-08-11 07:31:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:31:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:31:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:31:40 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:31:40 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:31:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:31:40 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:31:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:31:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:31:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:31:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:31:40 --> Final output sent to browser
DEBUG - 2011-08-11 07:31:40 --> Total execution time: 0.0294
DEBUG - 2011-08-11 07:31:41 --> Config Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:31:41 --> URI Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Router Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Output Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Input Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:31:41 --> Language Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Loader Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Controller Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Model Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:31:41 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:31:41 --> Final output sent to browser
DEBUG - 2011-08-11 07:31:41 --> Total execution time: 0.6490
DEBUG - 2011-08-11 07:31:43 --> Config Class Initialized
DEBUG - 2011-08-11 07:31:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:31:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:31:43 --> URI Class Initialized
DEBUG - 2011-08-11 07:31:43 --> Router Class Initialized
ERROR - 2011-08-11 07:31:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:32:00 --> Config Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:32:00 --> URI Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Router Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Output Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Input Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:32:00 --> Language Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Loader Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Controller Class Initialized
ERROR - 2011-08-11 07:32:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:32:00 --> Model Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Model Class Initialized
DEBUG - 2011-08-11 07:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:32:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:32:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:32:00 --> Final output sent to browser
DEBUG - 2011-08-11 07:32:00 --> Total execution time: 0.0391
DEBUG - 2011-08-11 07:32:01 --> Config Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:32:01 --> URI Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Router Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Output Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Input Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:32:01 --> Language Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Loader Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Controller Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Model Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Model Class Initialized
DEBUG - 2011-08-11 07:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:32:01 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:32:07 --> Final output sent to browser
DEBUG - 2011-08-11 07:32:07 --> Total execution time: 5.6797
DEBUG - 2011-08-11 07:32:08 --> Config Class Initialized
DEBUG - 2011-08-11 07:32:08 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:32:08 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:32:08 --> URI Class Initialized
DEBUG - 2011-08-11 07:32:08 --> Router Class Initialized
ERROR - 2011-08-11 07:32:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 07:35:20 --> Config Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Hooks Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Utf8 Class Initialized
DEBUG - 2011-08-11 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 07:35:20 --> URI Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Router Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Output Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Input Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 07:35:20 --> Language Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Loader Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Controller Class Initialized
ERROR - 2011-08-11 07:35:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 07:35:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 07:35:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:35:20 --> Model Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Model Class Initialized
DEBUG - 2011-08-11 07:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 07:35:21 --> Database Driver Class Initialized
DEBUG - 2011-08-11 07:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 07:35:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 07:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 07:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 07:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 07:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 07:35:21 --> Final output sent to browser
DEBUG - 2011-08-11 07:35:21 --> Total execution time: 0.0286
DEBUG - 2011-08-11 08:02:24 --> Config Class Initialized
DEBUG - 2011-08-11 08:02:24 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:02:24 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:02:24 --> URI Class Initialized
DEBUG - 2011-08-11 08:02:24 --> Router Class Initialized
DEBUG - 2011-08-11 08:02:24 --> Output Class Initialized
DEBUG - 2011-08-11 08:02:25 --> Input Class Initialized
DEBUG - 2011-08-11 08:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:02:25 --> Language Class Initialized
DEBUG - 2011-08-11 08:02:25 --> Loader Class Initialized
DEBUG - 2011-08-11 08:02:25 --> Controller Class Initialized
ERROR - 2011-08-11 08:02:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 08:02:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 08:02:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 08:02:25 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:25 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:02:25 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:02:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 08:02:25 --> Helper loaded: url_helper
DEBUG - 2011-08-11 08:02:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 08:02:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 08:02:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 08:02:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 08:02:25 --> Final output sent to browser
DEBUG - 2011-08-11 08:02:25 --> Total execution time: 1.0322
DEBUG - 2011-08-11 08:02:26 --> Config Class Initialized
DEBUG - 2011-08-11 08:02:26 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:02:26 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:02:26 --> URI Class Initialized
DEBUG - 2011-08-11 08:02:26 --> Router Class Initialized
DEBUG - 2011-08-11 08:02:26 --> Output Class Initialized
DEBUG - 2011-08-11 08:02:26 --> Input Class Initialized
DEBUG - 2011-08-11 08:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:02:26 --> Language Class Initialized
DEBUG - 2011-08-11 08:02:27 --> Loader Class Initialized
DEBUG - 2011-08-11 08:02:27 --> Controller Class Initialized
DEBUG - 2011-08-11 08:02:27 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:27 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:02:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:02:27 --> Final output sent to browser
DEBUG - 2011-08-11 08:02:27 --> Total execution time: 1.0010
DEBUG - 2011-08-11 08:02:28 --> Config Class Initialized
DEBUG - 2011-08-11 08:02:28 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:02:28 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:02:28 --> URI Class Initialized
DEBUG - 2011-08-11 08:02:28 --> Router Class Initialized
ERROR - 2011-08-11 08:02:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:02:29 --> Config Class Initialized
DEBUG - 2011-08-11 08:02:29 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:02:29 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:02:29 --> URI Class Initialized
DEBUG - 2011-08-11 08:02:29 --> Router Class Initialized
ERROR - 2011-08-11 08:02:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:02:59 --> Config Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:02:59 --> URI Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Router Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Output Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Input Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:02:59 --> Language Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Loader Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Controller Class Initialized
ERROR - 2011-08-11 08:02:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 08:02:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 08:02:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 08:02:59 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:02:59 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:02:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 08:02:59 --> Helper loaded: url_helper
DEBUG - 2011-08-11 08:02:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 08:02:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 08:02:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 08:02:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 08:02:59 --> Final output sent to browser
DEBUG - 2011-08-11 08:02:59 --> Total execution time: 0.0461
DEBUG - 2011-08-11 08:02:59 --> Config Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:02:59 --> URI Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Router Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Output Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Input Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:02:59 --> Language Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Loader Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Controller Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Model Class Initialized
DEBUG - 2011-08-11 08:02:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:02:59 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:00 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Router Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Output Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Input Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:03:00 --> Language Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Loader Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Controller Class Initialized
ERROR - 2011-08-11 08:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 08:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 08:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 08:03:00 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:03:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 08:03:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 08:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 08:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 08:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 08:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 08:03:00 --> Final output sent to browser
DEBUG - 2011-08-11 08:03:00 --> Total execution time: 0.0310
DEBUG - 2011-08-11 08:03:00 --> Final output sent to browser
DEBUG - 2011-08-11 08:03:00 --> Total execution time: 0.5097
DEBUG - 2011-08-11 08:03:00 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:00 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:00 --> Router Class Initialized
ERROR - 2011-08-11 08:03:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:03:05 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:05 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:05 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:05 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:05 --> Router Class Initialized
ERROR - 2011-08-11 08:03:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:03:07 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:07 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Router Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Output Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Input Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:03:07 --> Language Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Loader Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Controller Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:03:07 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:03:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 08:03:08 --> Helper loaded: url_helper
DEBUG - 2011-08-11 08:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 08:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 08:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 08:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 08:03:08 --> Final output sent to browser
DEBUG - 2011-08-11 08:03:08 --> Total execution time: 0.2948
DEBUG - 2011-08-11 08:03:14 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:14 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:14 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:14 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:14 --> Router Class Initialized
ERROR - 2011-08-11 08:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:03:14 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:14 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:14 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:14 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:14 --> Router Class Initialized
ERROR - 2011-08-11 08:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:03:20 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:20 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Router Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Output Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Input Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 08:03:20 --> Language Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Loader Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Controller Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Model Class Initialized
DEBUG - 2011-08-11 08:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 08:03:20 --> Database Driver Class Initialized
DEBUG - 2011-08-11 08:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 08:03:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 08:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 08:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 08:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 08:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 08:03:21 --> Final output sent to browser
DEBUG - 2011-08-11 08:03:21 --> Total execution time: 0.5671
DEBUG - 2011-08-11 08:03:22 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:22 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:22 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:22 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:22 --> Router Class Initialized
ERROR - 2011-08-11 08:03:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:03:22 --> Config Class Initialized
DEBUG - 2011-08-11 08:03:22 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:03:22 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:03:22 --> URI Class Initialized
DEBUG - 2011-08-11 08:03:22 --> Router Class Initialized
ERROR - 2011-08-11 08:03:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 08:08:54 --> Config Class Initialized
DEBUG - 2011-08-11 08:08:54 --> Hooks Class Initialized
DEBUG - 2011-08-11 08:08:54 --> Utf8 Class Initialized
DEBUG - 2011-08-11 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 08:08:54 --> URI Class Initialized
DEBUG - 2011-08-11 08:08:54 --> Router Class Initialized
ERROR - 2011-08-11 08:08:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 09:41:52 --> Config Class Initialized
DEBUG - 2011-08-11 09:41:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 09:41:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 09:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 09:41:52 --> URI Class Initialized
DEBUG - 2011-08-11 09:41:52 --> Router Class Initialized
ERROR - 2011-08-11 09:41:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 11:16:43 --> Config Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:16:43 --> URI Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Router Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Output Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Input Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 11:16:43 --> Language Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Loader Class Initialized
DEBUG - 2011-08-11 11:16:43 --> Controller Class Initialized
ERROR - 2011-08-11 11:16:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 11:16:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 11:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 11:16:44 --> Model Class Initialized
DEBUG - 2011-08-11 11:16:44 --> Model Class Initialized
DEBUG - 2011-08-11 11:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 11:16:44 --> Database Driver Class Initialized
DEBUG - 2011-08-11 11:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 11:16:44 --> Helper loaded: url_helper
DEBUG - 2011-08-11 11:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 11:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 11:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 11:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 11:16:44 --> Final output sent to browser
DEBUG - 2011-08-11 11:16:44 --> Total execution time: 0.3489
DEBUG - 2011-08-11 11:16:47 --> Config Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:16:47 --> URI Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Router Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Output Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Input Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 11:16:47 --> Language Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Loader Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Controller Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Model Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Model Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 11:16:47 --> Database Driver Class Initialized
DEBUG - 2011-08-11 11:16:47 --> Final output sent to browser
DEBUG - 2011-08-11 11:16:47 --> Total execution time: 0.8364
DEBUG - 2011-08-11 11:26:42 --> Config Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:26:42 --> URI Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Router Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Output Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Input Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 11:26:42 --> Language Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Loader Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Controller Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Model Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Model Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Model Class Initialized
DEBUG - 2011-08-11 11:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 11:26:42 --> Database Driver Class Initialized
DEBUG - 2011-08-11 11:26:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 11:26:42 --> Helper loaded: url_helper
DEBUG - 2011-08-11 11:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 11:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 11:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 11:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 11:26:42 --> Final output sent to browser
DEBUG - 2011-08-11 11:26:42 --> Total execution time: 0.4583
DEBUG - 2011-08-11 11:26:43 --> Config Class Initialized
DEBUG - 2011-08-11 11:26:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:26:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:26:43 --> URI Class Initialized
DEBUG - 2011-08-11 11:26:43 --> Router Class Initialized
ERROR - 2011-08-11 11:26:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 11:28:14 --> Config Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:28:14 --> URI Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Router Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Output Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Input Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 11:28:14 --> Language Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Loader Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Controller Class Initialized
ERROR - 2011-08-11 11:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 11:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 11:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 11:28:14 --> Model Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Model Class Initialized
DEBUG - 2011-08-11 11:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 11:28:14 --> Database Driver Class Initialized
DEBUG - 2011-08-11 11:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 11:28:14 --> Helper loaded: url_helper
DEBUG - 2011-08-11 11:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 11:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 11:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 11:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 11:28:14 --> Final output sent to browser
DEBUG - 2011-08-11 11:28:14 --> Total execution time: 0.0297
DEBUG - 2011-08-11 11:28:16 --> Config Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:28:16 --> URI Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Router Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Output Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Input Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 11:28:16 --> Language Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Loader Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Controller Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Model Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Model Class Initialized
DEBUG - 2011-08-11 11:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 11:28:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 11:28:17 --> Final output sent to browser
DEBUG - 2011-08-11 11:28:17 --> Total execution time: 1.1560
DEBUG - 2011-08-11 11:28:23 --> Config Class Initialized
DEBUG - 2011-08-11 11:28:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:28:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:28:23 --> URI Class Initialized
DEBUG - 2011-08-11 11:28:23 --> Router Class Initialized
ERROR - 2011-08-11 11:28:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 11:28:23 --> Config Class Initialized
DEBUG - 2011-08-11 11:28:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 11:28:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 11:28:23 --> URI Class Initialized
DEBUG - 2011-08-11 11:28:23 --> Router Class Initialized
ERROR - 2011-08-11 11:28:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 12:22:26 --> Config Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:22:26 --> URI Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Router Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Output Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Input Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:22:26 --> Language Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Loader Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Controller Class Initialized
ERROR - 2011-08-11 12:22:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 12:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 12:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:22:26 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:22:26 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:22:26 --> Helper loaded: url_helper
DEBUG - 2011-08-11 12:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 12:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 12:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 12:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 12:22:26 --> Final output sent to browser
DEBUG - 2011-08-11 12:22:26 --> Total execution time: 0.1247
DEBUG - 2011-08-11 12:22:27 --> Config Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:22:27 --> URI Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Router Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Output Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Input Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:22:27 --> Language Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Loader Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Controller Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:22:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:22:28 --> Final output sent to browser
DEBUG - 2011-08-11 12:22:28 --> Total execution time: 0.6575
DEBUG - 2011-08-11 12:22:49 --> Config Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:22:49 --> URI Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Router Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Output Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Input Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:22:49 --> Language Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Loader Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Controller Class Initialized
ERROR - 2011-08-11 12:22:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 12:22:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 12:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:22:49 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:22:49 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:22:49 --> Helper loaded: url_helper
DEBUG - 2011-08-11 12:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 12:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 12:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 12:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 12:22:49 --> Final output sent to browser
DEBUG - 2011-08-11 12:22:49 --> Total execution time: 0.0293
DEBUG - 2011-08-11 12:22:50 --> Config Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:22:50 --> URI Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Router Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Output Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Input Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:22:50 --> Language Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Loader Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Controller Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:22:50 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:22:50 --> Final output sent to browser
DEBUG - 2011-08-11 12:22:50 --> Total execution time: 0.6030
DEBUG - 2011-08-11 12:22:57 --> Config Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:22:57 --> URI Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Router Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Output Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Input Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:22:57 --> Language Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Loader Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Controller Class Initialized
ERROR - 2011-08-11 12:22:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 12:22:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 12:22:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:22:57 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:22:57 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:22:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:22:57 --> Helper loaded: url_helper
DEBUG - 2011-08-11 12:22:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 12:22:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 12:22:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 12:22:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 12:22:57 --> Final output sent to browser
DEBUG - 2011-08-11 12:22:57 --> Total execution time: 0.0447
DEBUG - 2011-08-11 12:22:58 --> Config Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:22:58 --> URI Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Router Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Output Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Input Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:22:58 --> Language Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Loader Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Controller Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Model Class Initialized
DEBUG - 2011-08-11 12:22:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:22:58 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:22:59 --> Final output sent to browser
DEBUG - 2011-08-11 12:22:59 --> Total execution time: 0.5279
DEBUG - 2011-08-11 12:23:15 --> Config Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:23:15 --> URI Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Router Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Output Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Input Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:23:15 --> Language Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Loader Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Controller Class Initialized
ERROR - 2011-08-11 12:23:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 12:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 12:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:23:15 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:23:15 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:23:15 --> Helper loaded: url_helper
DEBUG - 2011-08-11 12:23:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 12:23:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 12:23:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 12:23:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 12:23:15 --> Final output sent to browser
DEBUG - 2011-08-11 12:23:15 --> Total execution time: 0.0291
DEBUG - 2011-08-11 12:23:16 --> Config Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:23:16 --> URI Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Router Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Output Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Input Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:23:16 --> Language Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Loader Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Controller Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:23:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:23:16 --> Final output sent to browser
DEBUG - 2011-08-11 12:23:16 --> Total execution time: 0.6511
DEBUG - 2011-08-11 12:23:27 --> Config Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:23:27 --> URI Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Router Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Output Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Input Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:23:27 --> Language Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Loader Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Controller Class Initialized
ERROR - 2011-08-11 12:23:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 12:23:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 12:23:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:23:27 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:23:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:23:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 12:23:27 --> Helper loaded: url_helper
DEBUG - 2011-08-11 12:23:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 12:23:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 12:23:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 12:23:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 12:23:27 --> Final output sent to browser
DEBUG - 2011-08-11 12:23:27 --> Total execution time: 0.0310
DEBUG - 2011-08-11 12:23:27 --> Config Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:23:27 --> URI Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Router Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Output Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Input Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:23:27 --> Language Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Loader Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Controller Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Model Class Initialized
DEBUG - 2011-08-11 12:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 12:23:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 12:23:28 --> Final output sent to browser
DEBUG - 2011-08-11 12:23:28 --> Total execution time: 0.6755
DEBUG - 2011-08-11 12:46:59 --> Config Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Hooks Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Utf8 Class Initialized
DEBUG - 2011-08-11 12:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 12:46:59 --> URI Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Router Class Initialized
DEBUG - 2011-08-11 12:46:59 --> No URI present. Default controller set.
DEBUG - 2011-08-11 12:46:59 --> Output Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Input Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 12:46:59 --> Language Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Loader Class Initialized
DEBUG - 2011-08-11 12:46:59 --> Controller Class Initialized
DEBUG - 2011-08-11 12:46:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 12:46:59 --> Helper loaded: url_helper
DEBUG - 2011-08-11 12:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 12:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 12:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 12:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 12:46:59 --> Final output sent to browser
DEBUG - 2011-08-11 12:46:59 --> Total execution time: 0.0578
DEBUG - 2011-08-11 13:02:49 --> Config Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Hooks Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Utf8 Class Initialized
DEBUG - 2011-08-11 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 13:02:49 --> URI Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Router Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Output Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Input Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 13:02:49 --> Language Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Loader Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Controller Class Initialized
ERROR - 2011-08-11 13:02:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 13:02:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 13:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 13:02:49 --> Model Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Model Class Initialized
DEBUG - 2011-08-11 13:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 13:02:49 --> Database Driver Class Initialized
DEBUG - 2011-08-11 13:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 13:02:49 --> Helper loaded: url_helper
DEBUG - 2011-08-11 13:02:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 13:02:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 13:02:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 13:02:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 13:02:49 --> Final output sent to browser
DEBUG - 2011-08-11 13:02:49 --> Total execution time: 0.1788
DEBUG - 2011-08-11 13:02:51 --> Config Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Hooks Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Utf8 Class Initialized
DEBUG - 2011-08-11 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 13:02:51 --> URI Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Router Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Output Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Input Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 13:02:51 --> Language Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Loader Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Controller Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Model Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Model Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 13:02:51 --> Database Driver Class Initialized
DEBUG - 2011-08-11 13:02:51 --> Final output sent to browser
DEBUG - 2011-08-11 13:02:51 --> Total execution time: 0.6477
DEBUG - 2011-08-11 13:02:53 --> Config Class Initialized
DEBUG - 2011-08-11 13:02:53 --> Hooks Class Initialized
DEBUG - 2011-08-11 13:02:53 --> Utf8 Class Initialized
DEBUG - 2011-08-11 13:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 13:02:53 --> URI Class Initialized
DEBUG - 2011-08-11 13:02:53 --> Router Class Initialized
ERROR - 2011-08-11 13:02:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 16:19:22 --> Config Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:19:22 --> URI Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Router Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Output Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Input Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:19:22 --> Language Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Loader Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Controller Class Initialized
ERROR - 2011-08-11 16:19:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 16:19:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 16:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 16:19:22 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:19:22 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 16:19:22 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:19:22 --> Final output sent to browser
DEBUG - 2011-08-11 16:19:22 --> Total execution time: 0.3075
DEBUG - 2011-08-11 16:19:23 --> Config Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:19:23 --> URI Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Router Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Output Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Input Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:19:23 --> Language Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Loader Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Controller Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:19:23 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:19:24 --> Final output sent to browser
DEBUG - 2011-08-11 16:19:24 --> Total execution time: 0.7058
DEBUG - 2011-08-11 16:19:25 --> Config Class Initialized
DEBUG - 2011-08-11 16:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:19:25 --> URI Class Initialized
DEBUG - 2011-08-11 16:19:25 --> Router Class Initialized
ERROR - 2011-08-11 16:19:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 16:19:25 --> Config Class Initialized
DEBUG - 2011-08-11 16:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:19:25 --> URI Class Initialized
DEBUG - 2011-08-11 16:19:25 --> Router Class Initialized
ERROR - 2011-08-11 16:19:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 16:19:52 --> Config Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:19:52 --> URI Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Router Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Output Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Input Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:19:52 --> Language Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Loader Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Controller Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Model Class Initialized
DEBUG - 2011-08-11 16:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:19:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:19:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 16:19:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:19:52 --> Final output sent to browser
DEBUG - 2011-08-11 16:19:52 --> Total execution time: 0.3138
DEBUG - 2011-08-11 16:20:13 --> Config Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:20:13 --> URI Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Router Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Output Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Input Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:20:13 --> Language Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Loader Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Controller Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:20:13 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:20:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 16:20:13 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:20:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:20:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:20:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:20:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:20:13 --> Final output sent to browser
DEBUG - 2011-08-11 16:20:13 --> Total execution time: 0.2270
DEBUG - 2011-08-11 16:20:21 --> Config Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:20:21 --> URI Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Router Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Output Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Input Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:20:21 --> Language Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Loader Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Controller Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:20:21 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 16:20:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:20:21 --> Final output sent to browser
DEBUG - 2011-08-11 16:20:21 --> Total execution time: 0.1948
DEBUG - 2011-08-11 16:20:32 --> Config Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:20:32 --> URI Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Router Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Output Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Input Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:20:32 --> Language Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Loader Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Controller Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:20:32 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 16:20:32 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:20:32 --> Final output sent to browser
DEBUG - 2011-08-11 16:20:32 --> Total execution time: 0.2264
DEBUG - 2011-08-11 16:20:55 --> Config Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:20:55 --> URI Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Router Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Output Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Input Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:20:55 --> Language Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Loader Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Controller Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Model Class Initialized
DEBUG - 2011-08-11 16:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:20:55 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:20:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 16:20:55 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:20:55 --> Final output sent to browser
DEBUG - 2011-08-11 16:20:55 --> Total execution time: 0.2470
DEBUG - 2011-08-11 16:21:17 --> Config Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Hooks Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Utf8 Class Initialized
DEBUG - 2011-08-11 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 16:21:17 --> URI Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Router Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Output Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Input Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 16:21:17 --> Language Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Loader Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Controller Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Model Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Model Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Model Class Initialized
DEBUG - 2011-08-11 16:21:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 16:21:17 --> Database Driver Class Initialized
DEBUG - 2011-08-11 16:21:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 16:21:17 --> Helper loaded: url_helper
DEBUG - 2011-08-11 16:21:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 16:21:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 16:21:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 16:21:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 16:21:17 --> Final output sent to browser
DEBUG - 2011-08-11 16:21:17 --> Total execution time: 0.0451
DEBUG - 2011-08-11 17:08:14 --> Config Class Initialized
DEBUG - 2011-08-11 17:08:14 --> Hooks Class Initialized
DEBUG - 2011-08-11 17:08:14 --> Utf8 Class Initialized
DEBUG - 2011-08-11 17:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 17:08:14 --> URI Class Initialized
DEBUG - 2011-08-11 17:08:14 --> Router Class Initialized
ERROR - 2011-08-11 17:08:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 17:08:15 --> Config Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Hooks Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Utf8 Class Initialized
DEBUG - 2011-08-11 17:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 17:08:15 --> URI Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Router Class Initialized
DEBUG - 2011-08-11 17:08:15 --> No URI present. Default controller set.
DEBUG - 2011-08-11 17:08:15 --> Output Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Input Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 17:08:15 --> Language Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Loader Class Initialized
DEBUG - 2011-08-11 17:08:15 --> Controller Class Initialized
DEBUG - 2011-08-11 17:08:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 17:08:15 --> Helper loaded: url_helper
DEBUG - 2011-08-11 17:08:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 17:08:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 17:08:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 17:08:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 17:08:15 --> Final output sent to browser
DEBUG - 2011-08-11 17:08:15 --> Total execution time: 0.0561
DEBUG - 2011-08-11 17:26:50 --> Config Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Hooks Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Utf8 Class Initialized
DEBUG - 2011-08-11 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 17:26:50 --> URI Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Router Class Initialized
ERROR - 2011-08-11 17:26:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 17:26:50 --> Config Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Hooks Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Utf8 Class Initialized
DEBUG - 2011-08-11 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 17:26:50 --> URI Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Router Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Output Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Input Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 17:26:50 --> Language Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Loader Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Controller Class Initialized
ERROR - 2011-08-11 17:26:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 17:26:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 17:26:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 17:26:50 --> Model Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Model Class Initialized
DEBUG - 2011-08-11 17:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 17:26:50 --> Database Driver Class Initialized
DEBUG - 2011-08-11 17:26:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 17:26:50 --> Helper loaded: url_helper
DEBUG - 2011-08-11 17:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 17:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 17:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 17:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 17:26:50 --> Final output sent to browser
DEBUG - 2011-08-11 17:26:50 --> Total execution time: 0.0306
DEBUG - 2011-08-11 17:28:21 --> Config Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Hooks Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Utf8 Class Initialized
DEBUG - 2011-08-11 17:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 17:28:21 --> URI Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Router Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Output Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Input Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 17:28:21 --> Language Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Loader Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Controller Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Model Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Model Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Model Class Initialized
DEBUG - 2011-08-11 17:28:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 17:28:21 --> Database Driver Class Initialized
DEBUG - 2011-08-11 17:28:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 17:28:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 17:28:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 17:28:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 17:28:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 17:28:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 17:28:21 --> Final output sent to browser
DEBUG - 2011-08-11 17:28:21 --> Total execution time: 0.2591
DEBUG - 2011-08-11 17:28:25 --> Config Class Initialized
DEBUG - 2011-08-11 17:28:25 --> Hooks Class Initialized
DEBUG - 2011-08-11 17:28:25 --> Utf8 Class Initialized
DEBUG - 2011-08-11 17:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 17:28:25 --> URI Class Initialized
DEBUG - 2011-08-11 17:28:25 --> Router Class Initialized
ERROR - 2011-08-11 17:28:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 18:14:08 --> Config Class Initialized
DEBUG - 2011-08-11 18:14:08 --> Hooks Class Initialized
DEBUG - 2011-08-11 18:14:08 --> Utf8 Class Initialized
DEBUG - 2011-08-11 18:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 18:14:08 --> URI Class Initialized
DEBUG - 2011-08-11 18:14:08 --> Router Class Initialized
ERROR - 2011-08-11 18:14:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 18:14:09 --> Config Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Hooks Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Utf8 Class Initialized
DEBUG - 2011-08-11 18:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 18:14:09 --> URI Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Router Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Output Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Input Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 18:14:09 --> Language Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Loader Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Controller Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Model Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Model Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Model Class Initialized
DEBUG - 2011-08-11 18:14:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 18:14:09 --> Database Driver Class Initialized
DEBUG - 2011-08-11 18:14:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 18:14:09 --> Helper loaded: url_helper
DEBUG - 2011-08-11 18:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 18:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 18:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 18:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 18:14:09 --> Final output sent to browser
DEBUG - 2011-08-11 18:14:09 --> Total execution time: 0.2943
DEBUG - 2011-08-11 18:14:10 --> Config Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 18:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 18:14:10 --> URI Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Router Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Output Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Input Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 18:14:10 --> Language Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Loader Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Controller Class Initialized
ERROR - 2011-08-11 18:14:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 18:14:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 18:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 18:14:10 --> Model Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Model Class Initialized
DEBUG - 2011-08-11 18:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 18:14:10 --> Database Driver Class Initialized
DEBUG - 2011-08-11 18:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 18:14:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 18:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 18:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 18:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 18:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 18:14:10 --> Final output sent to browser
DEBUG - 2011-08-11 18:14:10 --> Total execution time: 0.0293
DEBUG - 2011-08-11 18:39:45 --> Config Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Hooks Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Utf8 Class Initialized
DEBUG - 2011-08-11 18:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 18:39:45 --> URI Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Router Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Output Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Input Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 18:39:45 --> Language Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Loader Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Controller Class Initialized
ERROR - 2011-08-11 18:39:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 18:39:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 18:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 18:39:45 --> Model Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Model Class Initialized
DEBUG - 2011-08-11 18:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 18:39:45 --> Database Driver Class Initialized
DEBUG - 2011-08-11 18:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 18:39:45 --> Helper loaded: url_helper
DEBUG - 2011-08-11 18:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 18:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 18:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 18:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 18:39:45 --> Final output sent to browser
DEBUG - 2011-08-11 18:39:45 --> Total execution time: 0.0290
DEBUG - 2011-08-11 18:55:53 --> Config Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Hooks Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Utf8 Class Initialized
DEBUG - 2011-08-11 18:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 18:55:53 --> URI Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Router Class Initialized
DEBUG - 2011-08-11 18:55:53 --> No URI present. Default controller set.
DEBUG - 2011-08-11 18:55:53 --> Output Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Input Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 18:55:53 --> Language Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Loader Class Initialized
DEBUG - 2011-08-11 18:55:53 --> Controller Class Initialized
DEBUG - 2011-08-11 18:55:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 18:55:53 --> Helper loaded: url_helper
DEBUG - 2011-08-11 18:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 18:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 18:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 18:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 18:55:53 --> Final output sent to browser
DEBUG - 2011-08-11 18:55:53 --> Total execution time: 0.0120
DEBUG - 2011-08-11 19:01:12 --> Config Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Hooks Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Utf8 Class Initialized
DEBUG - 2011-08-11 19:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 19:01:12 --> URI Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Router Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Output Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Input Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 19:01:12 --> Language Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Loader Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Controller Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Model Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Model Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Model Class Initialized
DEBUG - 2011-08-11 19:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 19:01:12 --> Database Driver Class Initialized
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 19:01:13 --> Helper loaded: url_helper
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 19:01:13 --> Final output sent to browser
DEBUG - 2011-08-11 19:01:13 --> Total execution time: 0.4820
DEBUG - 2011-08-11 19:01:13 --> Config Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Hooks Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Utf8 Class Initialized
DEBUG - 2011-08-11 19:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 19:01:13 --> URI Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Router Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Output Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Input Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 19:01:13 --> Language Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Loader Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Controller Class Initialized
ERROR - 2011-08-11 19:01:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 19:01:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 19:01:13 --> Model Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Model Class Initialized
DEBUG - 2011-08-11 19:01:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 19:01:13 --> Database Driver Class Initialized
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 19:01:13 --> Helper loaded: url_helper
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 19:01:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 19:01:13 --> Final output sent to browser
DEBUG - 2011-08-11 19:01:13 --> Total execution time: 0.0288
DEBUG - 2011-08-11 19:47:20 --> Config Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Hooks Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Utf8 Class Initialized
DEBUG - 2011-08-11 19:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 19:47:20 --> URI Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Router Class Initialized
DEBUG - 2011-08-11 19:47:20 --> No URI present. Default controller set.
DEBUG - 2011-08-11 19:47:20 --> Output Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Input Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 19:47:20 --> Language Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Loader Class Initialized
DEBUG - 2011-08-11 19:47:20 --> Controller Class Initialized
DEBUG - 2011-08-11 19:47:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 19:47:20 --> Helper loaded: url_helper
DEBUG - 2011-08-11 19:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 19:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 19:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 19:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 19:47:20 --> Final output sent to browser
DEBUG - 2011-08-11 19:47:20 --> Total execution time: 0.3403
DEBUG - 2011-08-11 21:12:31 --> Config Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:12:31 --> URI Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Router Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Output Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Input Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:12:31 --> Language Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Loader Class Initialized
DEBUG - 2011-08-11 21:12:31 --> Controller Class Initialized
ERROR - 2011-08-11 21:12:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-11 21:12:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-11 21:12:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 21:12:32 --> Model Class Initialized
DEBUG - 2011-08-11 21:12:32 --> Model Class Initialized
DEBUG - 2011-08-11 21:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:12:32 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:12:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-11 21:12:33 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:12:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:12:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:12:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:12:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:12:33 --> Final output sent to browser
DEBUG - 2011-08-11 21:12:33 --> Total execution time: 2.7050
DEBUG - 2011-08-11 21:12:35 --> Config Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:12:35 --> URI Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Router Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Output Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Input Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:12:35 --> Language Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Loader Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Controller Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Model Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Model Class Initialized
DEBUG - 2011-08-11 21:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:12:35 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:12:37 --> Final output sent to browser
DEBUG - 2011-08-11 21:12:37 --> Total execution time: 2.3065
DEBUG - 2011-08-11 21:12:38 --> Config Class Initialized
DEBUG - 2011-08-11 21:12:38 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:12:38 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:12:38 --> URI Class Initialized
DEBUG - 2011-08-11 21:12:38 --> Router Class Initialized
ERROR - 2011-08-11 21:12:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 21:12:38 --> Config Class Initialized
DEBUG - 2011-08-11 21:12:38 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:12:38 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:12:38 --> URI Class Initialized
DEBUG - 2011-08-11 21:12:38 --> Router Class Initialized
ERROR - 2011-08-11 21:12:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 21:12:39 --> Config Class Initialized
DEBUG - 2011-08-11 21:12:39 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:12:39 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:12:39 --> URI Class Initialized
DEBUG - 2011-08-11 21:12:39 --> Router Class Initialized
ERROR - 2011-08-11 21:12:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 21:22:51 --> Config Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:22:51 --> URI Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Router Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Output Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Input Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:22:51 --> Language Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Loader Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Controller Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Model Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Model Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Model Class Initialized
DEBUG - 2011-08-11 21:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:22:51 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:22:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:22:51 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:22:51 --> Final output sent to browser
DEBUG - 2011-08-11 21:22:51 --> Total execution time: 0.2726
DEBUG - 2011-08-11 21:55:09 --> Config Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:55:09 --> URI Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Router Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Output Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Input Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:55:09 --> Language Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Loader Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Controller Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Model Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Model Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Model Class Initialized
DEBUG - 2011-08-11 21:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:55:09 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:55:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:55:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:55:10 --> Final output sent to browser
DEBUG - 2011-08-11 21:55:10 --> Total execution time: 0.2168
DEBUG - 2011-08-11 21:55:55 --> Config Class Initialized
DEBUG - 2011-08-11 21:55:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:55:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:55:55 --> URI Class Initialized
DEBUG - 2011-08-11 21:55:55 --> Router Class Initialized
ERROR - 2011-08-11 21:55:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 21:55:58 --> Config Class Initialized
DEBUG - 2011-08-11 21:55:58 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:55:58 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:55:58 --> URI Class Initialized
DEBUG - 2011-08-11 21:55:58 --> Router Class Initialized
ERROR - 2011-08-11 21:55:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-11 21:56:13 --> Config Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:56:13 --> URI Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Router Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Output Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Input Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:56:13 --> Language Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Loader Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Controller Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:56:13 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:56:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:56:13 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:56:13 --> Final output sent to browser
DEBUG - 2011-08-11 21:56:13 --> Total execution time: 0.2130
DEBUG - 2011-08-11 21:56:35 --> Config Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:56:35 --> URI Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Router Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Output Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Input Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:56:35 --> Language Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Loader Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Controller Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:56:35 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:56:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:56:35 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:56:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:56:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:56:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:56:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:56:35 --> Final output sent to browser
DEBUG - 2011-08-11 21:56:35 --> Total execution time: 0.1041
DEBUG - 2011-08-11 21:56:54 --> Config Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:56:54 --> URI Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Router Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Output Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Input Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:56:54 --> Language Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Loader Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Controller Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:56:54 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:56:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:56:55 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:56:55 --> Final output sent to browser
DEBUG - 2011-08-11 21:56:55 --> Total execution time: 0.3734
DEBUG - 2011-08-11 21:56:58 --> Config Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:56:58 --> URI Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Router Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Output Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Input Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:56:58 --> Language Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Loader Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Controller Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Model Class Initialized
DEBUG - 2011-08-11 21:56:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:56:58 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:56:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:56:58 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:56:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:56:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:56:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:56:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:56:58 --> Final output sent to browser
DEBUG - 2011-08-11 21:56:58 --> Total execution time: 0.0433
DEBUG - 2011-08-11 21:57:10 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:10 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:10 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:10 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:10 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:10 --> Total execution time: 0.4877
DEBUG - 2011-08-11 21:57:16 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:16 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:16 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:16 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:16 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:16 --> Total execution time: 0.0533
DEBUG - 2011-08-11 21:57:22 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:22 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:22 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:22 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:22 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:22 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:22 --> Total execution time: 0.2541
DEBUG - 2011-08-11 21:57:27 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:27 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:27 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:27 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:27 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:27 --> Total execution time: 0.0425
DEBUG - 2011-08-11 21:57:41 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:41 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:41 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:41 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:42 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:42 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:42 --> Total execution time: 0.6976
DEBUG - 2011-08-11 21:57:53 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:53 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:53 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:53 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:53 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:53 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:53 --> Total execution time: 0.0499
DEBUG - 2011-08-11 21:57:54 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:54 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:54 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:54 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:54 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:54 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:54 --> Total execution time: 0.0781
DEBUG - 2011-08-11 21:57:57 --> Config Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:57:57 --> URI Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Router Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Output Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Input Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:57:57 --> Language Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Loader Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Controller Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Model Class Initialized
DEBUG - 2011-08-11 21:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:57:58 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:57:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:57:58 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:57:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:57:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:57:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:57:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:57:58 --> Final output sent to browser
DEBUG - 2011-08-11 21:57:58 --> Total execution time: 0.2159
DEBUG - 2011-08-11 21:58:03 --> Config Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:58:03 --> URI Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Router Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Output Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Input Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:58:03 --> Language Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Loader Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Controller Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:58:03 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:58:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:58:03 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:58:03 --> Final output sent to browser
DEBUG - 2011-08-11 21:58:03 --> Total execution time: 0.0545
DEBUG - 2011-08-11 21:58:04 --> Config Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:58:04 --> URI Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Router Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Output Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Input Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:58:04 --> Language Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Loader Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Controller Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:58:04 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:58:04 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:58:04 --> Final output sent to browser
DEBUG - 2011-08-11 21:58:04 --> Total execution time: 0.0448
DEBUG - 2011-08-11 21:58:17 --> Config Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:58:17 --> URI Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Router Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Output Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Input Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:58:17 --> Language Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Loader Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Controller Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:58:17 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:58:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:58:17 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:58:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:58:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:58:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:58:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:58:17 --> Final output sent to browser
DEBUG - 2011-08-11 21:58:17 --> Total execution time: 0.2472
DEBUG - 2011-08-11 21:58:57 --> Config Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:58:57 --> URI Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Router Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Output Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Input Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:58:57 --> Language Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Loader Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Controller Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Model Class Initialized
DEBUG - 2011-08-11 21:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:58:57 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:58:57 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:58:57 --> Final output sent to browser
DEBUG - 2011-08-11 21:58:57 --> Total execution time: 0.2598
DEBUG - 2011-08-11 21:59:01 --> Config Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:59:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:59:01 --> URI Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Router Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Output Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Input Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:59:01 --> Language Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Loader Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Controller Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:59:01 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:59:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:59:01 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:59:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:59:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:59:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:59:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:59:01 --> Final output sent to browser
DEBUG - 2011-08-11 21:59:01 --> Total execution time: 0.0467
DEBUG - 2011-08-11 21:59:15 --> Config Class Initialized
DEBUG - 2011-08-11 21:59:15 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:59:15 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:59:15 --> URI Class Initialized
DEBUG - 2011-08-11 21:59:15 --> Router Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Output Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Input Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:59:16 --> Language Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Loader Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Controller Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:59:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:59:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:59:16 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:59:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:59:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:59:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:59:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:59:16 --> Final output sent to browser
DEBUG - 2011-08-11 21:59:16 --> Total execution time: 0.2652
DEBUG - 2011-08-11 21:59:25 --> Config Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:59:25 --> URI Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Router Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Output Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Input Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:59:25 --> Language Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Loader Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Controller Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:59:25 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:59:25 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:59:25 --> Final output sent to browser
DEBUG - 2011-08-11 21:59:25 --> Total execution time: 0.0477
DEBUG - 2011-08-11 21:59:27 --> Config Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:59:27 --> URI Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Router Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Output Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Input Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:59:27 --> Language Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Loader Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Controller Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:59:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:59:27 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:59:27 --> Final output sent to browser
DEBUG - 2011-08-11 21:59:27 --> Total execution time: 0.0833
DEBUG - 2011-08-11 21:59:27 --> Config Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Hooks Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Utf8 Class Initialized
DEBUG - 2011-08-11 21:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 21:59:27 --> URI Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Router Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Output Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Input Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 21:59:27 --> Language Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Loader Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Controller Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Model Class Initialized
DEBUG - 2011-08-11 21:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 21:59:27 --> Database Driver Class Initialized
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 21:59:27 --> Helper loaded: url_helper
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 21:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 21:59:27 --> Final output sent to browser
DEBUG - 2011-08-11 21:59:27 --> Total execution time: 0.0450
DEBUG - 2011-08-11 22:25:49 --> Config Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:25:49 --> URI Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Router Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Output Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Input Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:25:49 --> Language Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Loader Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Controller Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Model Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Model Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Model Class Initialized
DEBUG - 2011-08-11 22:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:25:49 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:25:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:25:49 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:25:49 --> Final output sent to browser
DEBUG - 2011-08-11 22:25:49 --> Total execution time: 0.2201
DEBUG - 2011-08-11 22:26:00 --> Config Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:26:00 --> URI Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Router Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Output Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Input Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:26:00 --> Language Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Loader Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Controller Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:26:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:26:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:26:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:26:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:26:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:26:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:26:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:26:00 --> Final output sent to browser
DEBUG - 2011-08-11 22:26:00 --> Total execution time: 0.2113
DEBUG - 2011-08-11 22:26:05 --> Config Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:26:05 --> URI Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Router Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Output Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Input Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:26:05 --> Language Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Loader Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Controller Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:26:05 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:26:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:26:05 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:26:05 --> Final output sent to browser
DEBUG - 2011-08-11 22:26:05 --> Total execution time: 0.1267
DEBUG - 2011-08-11 22:26:20 --> Config Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:26:20 --> URI Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Router Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Output Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Input Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:26:20 --> Language Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Loader Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Controller Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:26:20 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:26:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:26:21 --> Final output sent to browser
DEBUG - 2011-08-11 22:26:21 --> Total execution time: 0.2619
DEBUG - 2011-08-11 22:26:46 --> Config Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:26:46 --> URI Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Router Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Output Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Input Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:26:46 --> Language Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Loader Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Controller Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:26:46 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:26:46 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:26:46 --> Final output sent to browser
DEBUG - 2011-08-11 22:26:46 --> Total execution time: 0.0867
DEBUG - 2011-08-11 22:26:48 --> Config Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:26:48 --> URI Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Router Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Output Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Input Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:26:48 --> Language Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Loader Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Controller Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:26:48 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:26:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:26:48 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:26:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:26:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:26:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:26:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:26:48 --> Final output sent to browser
DEBUG - 2011-08-11 22:26:48 --> Total execution time: 0.0502
DEBUG - 2011-08-11 22:26:52 --> Config Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:26:52 --> URI Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Router Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Output Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Input Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:26:52 --> Language Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Loader Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Controller Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:26:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:26:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:26:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:26:52 --> Final output sent to browser
DEBUG - 2011-08-11 22:26:52 --> Total execution time: 0.0541
DEBUG - 2011-08-11 22:27:07 --> Config Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:27:07 --> URI Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Router Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Output Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Input Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:27:07 --> Language Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Loader Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Controller Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Model Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Model Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Model Class Initialized
DEBUG - 2011-08-11 22:27:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:27:07 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:27:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:27:07 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:27:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:27:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:27:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:27:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:27:07 --> Final output sent to browser
DEBUG - 2011-08-11 22:27:07 --> Total execution time: 0.1977
DEBUG - 2011-08-11 22:27:52 --> Config Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:27:52 --> URI Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Router Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Output Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Input Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:27:52 --> Language Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Loader Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Controller Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:27:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:27:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:27:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:27:52 --> Final output sent to browser
DEBUG - 2011-08-11 22:27:52 --> Total execution time: 0.0521
DEBUG - 2011-08-11 22:28:24 --> Config Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:28:24 --> URI Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Router Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Output Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Input Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:28:24 --> Language Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Loader Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Controller Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:28:24 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:28:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:28:24 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:28:24 --> Final output sent to browser
DEBUG - 2011-08-11 22:28:24 --> Total execution time: 0.1994
DEBUG - 2011-08-11 22:28:43 --> Config Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:28:43 --> URI Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Router Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Output Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Input Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:28:43 --> Language Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Loader Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Controller Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:28:43 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:28:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:28:43 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:28:43 --> Final output sent to browser
DEBUG - 2011-08-11 22:28:43 --> Total execution time: 0.2483
DEBUG - 2011-08-11 22:28:48 --> Config Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:28:48 --> URI Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Router Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Output Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Input Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:28:48 --> Language Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Loader Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Controller Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:28:48 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:28:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:28:48 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:28:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:28:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:28:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:28:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:28:48 --> Final output sent to browser
DEBUG - 2011-08-11 22:28:48 --> Total execution time: 0.0696
DEBUG - 2011-08-11 22:28:49 --> Config Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:28:49 --> URI Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Router Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Output Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Input Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:28:49 --> Language Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Loader Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Controller Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:28:49 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:28:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:28:49 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:28:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:28:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:28:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:28:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:28:49 --> Final output sent to browser
DEBUG - 2011-08-11 22:28:49 --> Total execution time: 0.0722
DEBUG - 2011-08-11 22:28:52 --> Config Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:28:52 --> URI Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Router Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Output Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Input Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:28:52 --> Language Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Loader Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Controller Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:28:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:28:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:28:52 --> Final output sent to browser
DEBUG - 2011-08-11 22:28:52 --> Total execution time: 0.0674
DEBUG - 2011-08-11 22:29:16 --> Config Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:29:16 --> URI Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Router Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Output Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Input Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:29:16 --> Language Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Loader Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Controller Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Model Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Model Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Model Class Initialized
DEBUG - 2011-08-11 22:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:29:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:29:16 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:29:16 --> Final output sent to browser
DEBUG - 2011-08-11 22:29:16 --> Total execution time: 0.2640
DEBUG - 2011-08-11 22:29:52 --> Config Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:29:52 --> URI Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Router Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Output Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Input Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:29:52 --> Language Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Loader Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Controller Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Model Class Initialized
DEBUG - 2011-08-11 22:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:29:52 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:29:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:29:52 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:29:52 --> Final output sent to browser
DEBUG - 2011-08-11 22:29:52 --> Total execution time: 0.3867
DEBUG - 2011-08-11 22:30:04 --> Config Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:30:04 --> URI Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Router Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Output Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Input Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:30:04 --> Language Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Loader Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Controller Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:30:04 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:30:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:30:04 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:30:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:30:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:30:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:30:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:30:04 --> Final output sent to browser
DEBUG - 2011-08-11 22:30:04 --> Total execution time: 0.0699
DEBUG - 2011-08-11 22:30:07 --> Config Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:30:07 --> URI Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Router Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Output Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Input Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:30:07 --> Language Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Loader Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Controller Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:30:07 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:30:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:30:07 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:30:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:30:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:30:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:30:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:30:07 --> Final output sent to browser
DEBUG - 2011-08-11 22:30:07 --> Total execution time: 0.0667
DEBUG - 2011-08-11 22:30:33 --> Config Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:30:33 --> URI Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Router Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Output Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Input Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:30:33 --> Language Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Loader Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Controller Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:30:33 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:30:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:30:34 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:30:34 --> Final output sent to browser
DEBUG - 2011-08-11 22:30:34 --> Total execution time: 0.2808
DEBUG - 2011-08-11 22:30:39 --> Config Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:30:39 --> URI Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Router Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Output Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Input Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:30:39 --> Language Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Loader Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Controller Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Model Class Initialized
DEBUG - 2011-08-11 22:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:30:39 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:30:39 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:30:39 --> Final output sent to browser
DEBUG - 2011-08-11 22:30:39 --> Total execution time: 0.0447
DEBUG - 2011-08-11 22:31:09 --> Config Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:31:09 --> URI Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Router Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Output Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Input Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:31:09 --> Language Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Loader Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Controller Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:31:09 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:31:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:31:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:31:10 --> Final output sent to browser
DEBUG - 2011-08-11 22:31:10 --> Total execution time: 0.2642
DEBUG - 2011-08-11 22:31:21 --> Config Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:31:21 --> URI Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Router Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Output Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Input Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:31:21 --> Language Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Loader Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Controller Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:31:21 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:31:21 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:31:21 --> Final output sent to browser
DEBUG - 2011-08-11 22:31:21 --> Total execution time: 0.0483
DEBUG - 2011-08-11 22:31:26 --> Config Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:31:26 --> URI Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Router Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Output Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Input Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:31:26 --> Language Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Loader Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Controller Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:31:26 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:31:27 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:31:27 --> Final output sent to browser
DEBUG - 2011-08-11 22:31:27 --> Total execution time: 0.2320
DEBUG - 2011-08-11 22:31:55 --> Config Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:31:55 --> URI Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Router Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Output Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Input Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:31:55 --> Language Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Loader Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Controller Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Model Class Initialized
DEBUG - 2011-08-11 22:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:31:55 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:31:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:31:55 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:31:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:31:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:31:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:31:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:31:55 --> Final output sent to browser
DEBUG - 2011-08-11 22:31:55 --> Total execution time: 0.0416
DEBUG - 2011-08-11 22:36:48 --> Config Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:36:48 --> URI Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Router Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Output Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Input Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:36:48 --> Language Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Loader Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Controller Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:36:48 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:36:48 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:36:48 --> Final output sent to browser
DEBUG - 2011-08-11 22:36:48 --> Total execution time: 0.2503
DEBUG - 2011-08-11 22:36:55 --> Config Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:36:55 --> URI Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Router Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Output Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Input Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:36:55 --> Language Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Loader Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Controller Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:36:55 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:36:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:36:55 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:36:55 --> Final output sent to browser
DEBUG - 2011-08-11 22:36:55 --> Total execution time: 0.0464
DEBUG - 2011-08-11 22:36:57 --> Config Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:36:57 --> URI Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Router Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Output Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Input Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:36:57 --> Language Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Loader Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Controller Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Model Class Initialized
DEBUG - 2011-08-11 22:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:36:57 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:36:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:36:57 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:36:57 --> Final output sent to browser
DEBUG - 2011-08-11 22:36:57 --> Total execution time: 0.0476
DEBUG - 2011-08-11 22:37:10 --> Config Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:37:10 --> URI Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Router Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Output Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Input Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:37:10 --> Language Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Loader Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Controller Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Model Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Model Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Model Class Initialized
DEBUG - 2011-08-11 22:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:37:10 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:37:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:37:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:37:10 --> Final output sent to browser
DEBUG - 2011-08-11 22:37:10 --> Total execution time: 0.1940
DEBUG - 2011-08-11 22:37:16 --> Config Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:37:16 --> URI Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Router Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Output Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Input Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:37:16 --> Language Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Loader Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Controller Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Model Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Model Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Model Class Initialized
DEBUG - 2011-08-11 22:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:37:16 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:37:16 --> Final output sent to browser
DEBUG - 2011-08-11 22:37:16 --> Total execution time: 0.0443
DEBUG - 2011-08-11 22:38:00 --> Config Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:38:00 --> URI Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Router Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Output Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Input Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:38:00 --> Language Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Loader Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Controller Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:38:00 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:38:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:38:00 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:38:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:38:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:38:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:38:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:38:00 --> Final output sent to browser
DEBUG - 2011-08-11 22:38:00 --> Total execution time: 0.2099
DEBUG - 2011-08-11 22:38:11 --> Config Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:38:11 --> URI Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Router Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Output Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Input Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:38:11 --> Language Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Loader Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Controller Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:38:11 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:38:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:38:11 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:38:11 --> Final output sent to browser
DEBUG - 2011-08-11 22:38:11 --> Total execution time: 0.0455
DEBUG - 2011-08-11 22:38:58 --> Config Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:38:58 --> URI Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Router Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Output Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Input Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:38:58 --> Language Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Loader Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Controller Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Model Class Initialized
DEBUG - 2011-08-11 22:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:38:58 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:38:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:38:58 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:38:58 --> Final output sent to browser
DEBUG - 2011-08-11 22:38:58 --> Total execution time: 0.2814
DEBUG - 2011-08-11 22:39:10 --> Config Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:39:10 --> URI Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Router Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Output Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Input Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:39:10 --> Language Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Loader Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Controller Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:39:10 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:39:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:39:10 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:39:10 --> Final output sent to browser
DEBUG - 2011-08-11 22:39:10 --> Total execution time: 0.0456
DEBUG - 2011-08-11 22:39:42 --> Config Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:39:42 --> URI Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Router Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Output Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Input Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:39:42 --> Language Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Loader Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Controller Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:39:42 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:39:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:39:42 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:39:42 --> Final output sent to browser
DEBUG - 2011-08-11 22:39:42 --> Total execution time: 0.3636
DEBUG - 2011-08-11 22:39:46 --> Config Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Hooks Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Utf8 Class Initialized
DEBUG - 2011-08-11 22:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 22:39:46 --> URI Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Router Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Output Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Input Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 22:39:46 --> Language Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Loader Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Controller Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Model Class Initialized
DEBUG - 2011-08-11 22:39:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-11 22:39:46 --> Database Driver Class Initialized
DEBUG - 2011-08-11 22:39:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-11 22:39:46 --> Helper loaded: url_helper
DEBUG - 2011-08-11 22:39:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 22:39:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 22:39:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 22:39:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 22:39:46 --> Final output sent to browser
DEBUG - 2011-08-11 22:39:46 --> Total execution time: 0.0435
DEBUG - 2011-08-11 23:13:23 --> Config Class Initialized
DEBUG - 2011-08-11 23:13:23 --> Hooks Class Initialized
DEBUG - 2011-08-11 23:13:23 --> Utf8 Class Initialized
DEBUG - 2011-08-11 23:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 23:13:23 --> URI Class Initialized
DEBUG - 2011-08-11 23:13:23 --> Router Class Initialized
ERROR - 2011-08-11 23:13:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-11 23:13:25 --> Config Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Hooks Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Utf8 Class Initialized
DEBUG - 2011-08-11 23:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-11 23:13:25 --> URI Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Router Class Initialized
DEBUG - 2011-08-11 23:13:25 --> No URI present. Default controller set.
DEBUG - 2011-08-11 23:13:25 --> Output Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Input Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-11 23:13:25 --> Language Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Loader Class Initialized
DEBUG - 2011-08-11 23:13:25 --> Controller Class Initialized
DEBUG - 2011-08-11 23:13:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-11 23:13:25 --> Helper loaded: url_helper
DEBUG - 2011-08-11 23:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-11 23:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-11 23:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-11 23:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-11 23:13:25 --> Final output sent to browser
DEBUG - 2011-08-11 23:13:25 --> Total execution time: 0.0667

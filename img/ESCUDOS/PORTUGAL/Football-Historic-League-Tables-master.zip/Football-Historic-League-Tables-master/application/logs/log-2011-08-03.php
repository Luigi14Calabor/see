<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-03 02:30:08 --> Config Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Hooks Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Utf8 Class Initialized
DEBUG - 2011-08-03 02:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 02:30:08 --> URI Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Router Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Output Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Input Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 02:30:08 --> Language Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Loader Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Controller Class Initialized
ERROR - 2011-08-03 02:30:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 02:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 02:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 02:30:08 --> Model Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Model Class Initialized
DEBUG - 2011-08-03 02:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 02:30:08 --> Database Driver Class Initialized
DEBUG - 2011-08-03 02:30:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 02:30:09 --> Helper loaded: url_helper
DEBUG - 2011-08-03 02:30:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 02:30:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 02:30:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 02:30:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 02:30:09 --> Final output sent to browser
DEBUG - 2011-08-03 02:30:09 --> Total execution time: 0.8350
DEBUG - 2011-08-03 02:30:24 --> Config Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Hooks Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Utf8 Class Initialized
DEBUG - 2011-08-03 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 02:30:24 --> URI Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Router Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Output Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Input Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 02:30:24 --> Language Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Loader Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Controller Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Model Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Model Class Initialized
DEBUG - 2011-08-03 02:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 02:30:24 --> Database Driver Class Initialized
DEBUG - 2011-08-03 02:30:33 --> Final output sent to browser
DEBUG - 2011-08-03 02:30:33 --> Total execution time: 8.5481
DEBUG - 2011-08-03 02:30:55 --> Config Class Initialized
DEBUG - 2011-08-03 02:30:55 --> Hooks Class Initialized
DEBUG - 2011-08-03 02:30:55 --> Utf8 Class Initialized
DEBUG - 2011-08-03 02:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 02:30:55 --> URI Class Initialized
DEBUG - 2011-08-03 02:30:55 --> Router Class Initialized
ERROR - 2011-08-03 02:30:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 02:41:41 --> Config Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Hooks Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Utf8 Class Initialized
DEBUG - 2011-08-03 02:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 02:41:41 --> URI Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Router Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Output Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Input Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 02:41:41 --> Language Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Loader Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Controller Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-03 02:41:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 02:41:41 --> Database Driver Class Initialized
DEBUG - 2011-08-03 02:41:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 02:41:43 --> Helper loaded: url_helper
DEBUG - 2011-08-03 02:41:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 02:41:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 02:41:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 02:41:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 02:41:43 --> Final output sent to browser
DEBUG - 2011-08-03 02:41:43 --> Total execution time: 2.1405
DEBUG - 2011-08-03 06:16:41 --> Config Class Initialized
DEBUG - 2011-08-03 06:16:41 --> Hooks Class Initialized
DEBUG - 2011-08-03 06:16:41 --> Utf8 Class Initialized
DEBUG - 2011-08-03 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 06:16:41 --> URI Class Initialized
DEBUG - 2011-08-03 06:16:41 --> Router Class Initialized
ERROR - 2011-08-03 06:16:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-03 06:16:43 --> Config Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Hooks Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Utf8 Class Initialized
DEBUG - 2011-08-03 06:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 06:16:43 --> URI Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Router Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Output Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Input Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 06:16:43 --> Language Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Loader Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Controller Class Initialized
ERROR - 2011-08-03 06:16:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 06:16:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 06:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 06:16:43 --> Model Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Model Class Initialized
DEBUG - 2011-08-03 06:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 06:16:43 --> Database Driver Class Initialized
DEBUG - 2011-08-03 06:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 06:16:44 --> Helper loaded: url_helper
DEBUG - 2011-08-03 06:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 06:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 06:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 06:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 06:16:44 --> Final output sent to browser
DEBUG - 2011-08-03 06:16:44 --> Total execution time: 1.3026
DEBUG - 2011-08-03 06:18:31 --> Config Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Hooks Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Utf8 Class Initialized
DEBUG - 2011-08-03 06:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 06:18:31 --> URI Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Router Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Output Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Input Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 06:18:31 --> Language Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Loader Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Controller Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Model Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Model Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Model Class Initialized
DEBUG - 2011-08-03 06:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 06:18:31 --> Database Driver Class Initialized
DEBUG - 2011-08-03 06:18:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 06:18:35 --> Helper loaded: url_helper
DEBUG - 2011-08-03 06:18:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 06:18:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 06:18:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 06:18:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 06:18:35 --> Final output sent to browser
DEBUG - 2011-08-03 06:18:35 --> Total execution time: 3.9064
DEBUG - 2011-08-03 07:04:35 --> Config Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:04:35 --> URI Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Router Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Output Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Input Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:04:35 --> Language Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Loader Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Controller Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:04:35 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:04:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:04:35 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:04:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:04:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:04:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:04:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:04:35 --> Final output sent to browser
DEBUG - 2011-08-03 07:04:35 --> Total execution time: 0.5916
DEBUG - 2011-08-03 07:04:36 --> Config Class Initialized
DEBUG - 2011-08-03 07:04:36 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:04:36 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:04:36 --> URI Class Initialized
DEBUG - 2011-08-03 07:04:36 --> Router Class Initialized
ERROR - 2011-08-03 07:04:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:04:53 --> Config Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:04:53 --> URI Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Router Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Output Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Input Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:04:53 --> Language Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Loader Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Controller Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:04:53 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:04:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:04:54 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:04:54 --> Final output sent to browser
DEBUG - 2011-08-03 07:04:54 --> Total execution time: 1.1246
DEBUG - 2011-08-03 07:04:55 --> Config Class Initialized
DEBUG - 2011-08-03 07:04:55 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:04:55 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:04:55 --> URI Class Initialized
DEBUG - 2011-08-03 07:04:55 --> Router Class Initialized
ERROR - 2011-08-03 07:04:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:04:57 --> Config Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:04:57 --> URI Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Router Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Output Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Input Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:04:57 --> Language Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Loader Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Controller Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Model Class Initialized
DEBUG - 2011-08-03 07:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:04:57 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:04:57 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:04:57 --> Final output sent to browser
DEBUG - 2011-08-03 07:04:57 --> Total execution time: 0.0963
DEBUG - 2011-08-03 07:05:06 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:06 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Router Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Output Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Input Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:05:06 --> Language Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Loader Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Controller Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:05:06 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:05:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:05:07 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:05:07 --> Final output sent to browser
DEBUG - 2011-08-03 07:05:07 --> Total execution time: 0.5867
DEBUG - 2011-08-03 07:05:07 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:07 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:07 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:07 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:07 --> Router Class Initialized
ERROR - 2011-08-03 07:05:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:05:11 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:11 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Router Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Output Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Input Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:05:11 --> Language Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Loader Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Controller Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:05:11 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:05:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:05:11 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:05:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:05:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:05:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:05:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:05:11 --> Final output sent to browser
DEBUG - 2011-08-03 07:05:11 --> Total execution time: 0.0694
DEBUG - 2011-08-03 07:05:26 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:26 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Router Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Output Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Input Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:05:26 --> Language Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Loader Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Controller Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:05:26 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:05:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:05:26 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:05:26 --> Final output sent to browser
DEBUG - 2011-08-03 07:05:26 --> Total execution time: 0.5009
DEBUG - 2011-08-03 07:05:27 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:27 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:27 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:27 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:27 --> Router Class Initialized
ERROR - 2011-08-03 07:05:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:05:28 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:28 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Router Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Output Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Input Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:05:28 --> Language Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Loader Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Controller Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:05:28 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:05:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:05:28 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:05:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:05:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:05:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:05:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:05:28 --> Final output sent to browser
DEBUG - 2011-08-03 07:05:28 --> Total execution time: 0.1225
DEBUG - 2011-08-03 07:05:42 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:42 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Router Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Output Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Input Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:05:42 --> Language Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Loader Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Controller Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:05:42 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:05:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:05:42 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:05:42 --> Final output sent to browser
DEBUG - 2011-08-03 07:05:42 --> Total execution time: 0.3691
DEBUG - 2011-08-03 07:05:43 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:43 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Router Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Output Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Input Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:05:43 --> Language Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Loader Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Controller Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Model Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:05:43 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Config Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:05:43 --> URI Class Initialized
DEBUG - 2011-08-03 07:05:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:05:43 --> Router Class Initialized
ERROR - 2011-08-03 07:05:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:05:43 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:05:43 --> Final output sent to browser
DEBUG - 2011-08-03 07:05:43 --> Total execution time: 0.1054
DEBUG - 2011-08-03 07:06:02 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:02 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:02 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:02 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:03 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:03 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:03 --> Total execution time: 0.7634
DEBUG - 2011-08-03 07:06:03 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:03 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:04 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:04 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:04 --> Router Class Initialized
ERROR - 2011-08-03 07:06:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:06:05 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:05 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:05 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:05 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:05 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:05 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:05 --> Total execution time: 0.1035
DEBUG - 2011-08-03 07:06:26 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:26 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:26 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:27 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:27 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:27 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:27 --> Total execution time: 0.8707
DEBUG - 2011-08-03 07:06:28 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:28 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:28 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:28 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:28 --> Router Class Initialized
ERROR - 2011-08-03 07:06:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:06:31 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:31 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:31 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:31 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:31 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:31 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:31 --> Total execution time: 0.1206
DEBUG - 2011-08-03 07:06:36 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:36 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:36 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:36 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:37 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:37 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:37 --> Total execution time: 1.2656
DEBUG - 2011-08-03 07:06:38 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:38 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:38 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:38 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:38 --> Router Class Initialized
ERROR - 2011-08-03 07:06:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:06:39 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:39 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:39 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:39 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:40 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:40 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:40 --> Total execution time: 0.2599
DEBUG - 2011-08-03 07:06:53 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:53 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:53 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:53 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:54 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:54 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:54 --> Total execution time: 0.3834
DEBUG - 2011-08-03 07:06:54 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:54 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:54 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:54 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:54 --> Router Class Initialized
ERROR - 2011-08-03 07:06:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:06:56 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:56 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:56 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:56 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:06:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:06:56 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:06:56 --> Final output sent to browser
DEBUG - 2011-08-03 07:06:56 --> Total execution time: 0.1082
DEBUG - 2011-08-03 07:06:58 --> Config Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:06:58 --> URI Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Router Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Output Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Input Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:06:58 --> Language Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Loader Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Controller Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Model Class Initialized
DEBUG - 2011-08-03 07:06:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:06:58 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:00 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:00 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:00 --> Total execution time: 1.1642
DEBUG - 2011-08-03 07:07:00 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:00 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:00 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:00 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:00 --> Router Class Initialized
ERROR - 2011-08-03 07:07:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:07:10 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:10 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Router Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Output Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Input Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:07:10 --> Language Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Loader Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Controller Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:07:10 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:11 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:11 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:11 --> Total execution time: 0.6608
DEBUG - 2011-08-03 07:07:12 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:12 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:12 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:12 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:12 --> Router Class Initialized
ERROR - 2011-08-03 07:07:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:07:17 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:17 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Router Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Output Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Input Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:07:17 --> Language Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Loader Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Controller Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:07:17 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:18 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:18 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:18 --> Total execution time: 0.3087
DEBUG - 2011-08-03 07:07:18 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:18 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:18 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:18 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:18 --> Router Class Initialized
ERROR - 2011-08-03 07:07:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:07:30 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:30 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Router Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Output Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Input Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:07:30 --> Language Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Loader Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Controller Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:07:30 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:30 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:30 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:30 --> Total execution time: 0.2613
DEBUG - 2011-08-03 07:07:31 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:31 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:31 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:31 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:31 --> Router Class Initialized
ERROR - 2011-08-03 07:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:07:37 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:37 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Router Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Output Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Input Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:07:37 --> Language Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Loader Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Controller Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:07:37 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:37 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:37 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:37 --> Total execution time: 0.2814
DEBUG - 2011-08-03 07:07:39 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:39 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:39 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:39 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:39 --> Router Class Initialized
ERROR - 2011-08-03 07:07:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:07:46 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:46 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Router Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Output Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Input Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:07:46 --> Language Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Loader Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Controller Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:07:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:47 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:47 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:47 --> Total execution time: 0.3136
DEBUG - 2011-08-03 07:07:47 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:47 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:47 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:47 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:47 --> Router Class Initialized
ERROR - 2011-08-03 07:07:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:07:55 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:55 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Router Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Output Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Input Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:07:55 --> Language Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Loader Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Controller Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Model Class Initialized
DEBUG - 2011-08-03 07:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:07:55 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:07:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:07:55 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:07:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:07:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:07:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:07:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:07:55 --> Final output sent to browser
DEBUG - 2011-08-03 07:07:55 --> Total execution time: 0.0458
DEBUG - 2011-08-03 07:07:56 --> Config Class Initialized
DEBUG - 2011-08-03 07:07:56 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:07:56 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:07:56 --> URI Class Initialized
DEBUG - 2011-08-03 07:07:56 --> Router Class Initialized
ERROR - 2011-08-03 07:07:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:08:01 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:01 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Router Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Output Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Input Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:08:01 --> Language Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Loader Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Controller Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:08:01 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:08:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:08:03 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:08:03 --> Final output sent to browser
DEBUG - 2011-08-03 07:08:03 --> Total execution time: 1.4759
DEBUG - 2011-08-03 07:08:03 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:03 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:03 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:03 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:03 --> Router Class Initialized
ERROR - 2011-08-03 07:08:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:08:09 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:09 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Router Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Output Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Input Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:08:09 --> Language Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Loader Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Controller Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:08:09 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:08:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:08:10 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:08:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:08:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:08:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:08:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:08:10 --> Final output sent to browser
DEBUG - 2011-08-03 07:08:10 --> Total execution time: 1.0408
DEBUG - 2011-08-03 07:08:11 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:11 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:11 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:11 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:11 --> Router Class Initialized
ERROR - 2011-08-03 07:08:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:08:21 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:21 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Router Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Output Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Input Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:08:21 --> Language Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Loader Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Controller Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:08:21 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:08:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:08:22 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:08:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:08:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:08:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:08:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:08:22 --> Final output sent to browser
DEBUG - 2011-08-03 07:08:22 --> Total execution time: 0.3615
DEBUG - 2011-08-03 07:08:23 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:23 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:23 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:23 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:23 --> Router Class Initialized
ERROR - 2011-08-03 07:08:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 07:08:54 --> Config Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:08:54 --> URI Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Router Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Output Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Input Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:08:54 --> Language Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Loader Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Controller Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Model Class Initialized
DEBUG - 2011-08-03 07:08:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:08:54 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:08:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:08:54 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:08:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:08:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:08:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:08:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:08:54 --> Final output sent to browser
DEBUG - 2011-08-03 07:08:54 --> Total execution time: 0.0908
DEBUG - 2011-08-03 07:10:14 --> Config Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:10:14 --> URI Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Router Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Output Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Input Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:10:14 --> Language Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Loader Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Controller Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:10:14 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:10:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:10:14 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:10:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:10:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:10:14 --> Final output sent to browser
DEBUG - 2011-08-03 07:10:14 --> Total execution time: 0.0798
DEBUG - 2011-08-03 07:10:34 --> Config Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:10:34 --> URI Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Router Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Output Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Input Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:10:34 --> Language Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Loader Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Controller Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:10:34 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:10:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:10:34 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:10:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:10:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:10:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:10:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:10:34 --> Final output sent to browser
DEBUG - 2011-08-03 07:10:34 --> Total execution time: 0.1371
DEBUG - 2011-08-03 07:10:38 --> Config Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:10:38 --> URI Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Router Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Output Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Input Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:10:38 --> Language Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Loader Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Controller Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:10:38 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:10:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:10:38 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:10:38 --> Final output sent to browser
DEBUG - 2011-08-03 07:10:38 --> Total execution time: 0.0520
DEBUG - 2011-08-03 07:10:43 --> Config Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:10:43 --> URI Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Router Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Output Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Input Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:10:43 --> Language Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Loader Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Controller Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:10:43 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:10:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:10:43 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:10:43 --> Final output sent to browser
DEBUG - 2011-08-03 07:10:43 --> Total execution time: 0.0609
DEBUG - 2011-08-03 07:10:46 --> Config Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:10:46 --> URI Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Router Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Output Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Input Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:10:46 --> Language Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Loader Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Controller Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Model Class Initialized
DEBUG - 2011-08-03 07:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:10:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:10:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:10:46 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:10:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:10:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:10:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:10:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:10:46 --> Final output sent to browser
DEBUG - 2011-08-03 07:10:46 --> Total execution time: 0.0674
DEBUG - 2011-08-03 07:11:00 --> Config Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:11:00 --> URI Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Router Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Output Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Input Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:11:00 --> Language Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Loader Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Controller Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:11:00 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:11:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:11:00 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:11:00 --> Final output sent to browser
DEBUG - 2011-08-03 07:11:00 --> Total execution time: 0.0442
DEBUG - 2011-08-03 07:11:08 --> Config Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:11:08 --> URI Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Router Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Output Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Input Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:11:08 --> Language Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Loader Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Controller Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:11:08 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:11:08 --> Final output sent to browser
DEBUG - 2011-08-03 07:11:08 --> Total execution time: 0.1337
DEBUG - 2011-08-03 07:11:21 --> Config Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:11:21 --> URI Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Router Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Output Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Input Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:11:21 --> Language Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Loader Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Controller Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Model Class Initialized
DEBUG - 2011-08-03 07:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:11:21 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:11:21 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:11:21 --> Final output sent to browser
DEBUG - 2011-08-03 07:11:21 --> Total execution time: 0.0452
DEBUG - 2011-08-03 07:58:02 --> Config Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:58:02 --> URI Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Router Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Output Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Input Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:58:02 --> Language Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Loader Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Controller Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Model Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Model Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Model Class Initialized
DEBUG - 2011-08-03 07:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:58:02 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Config Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:58:03 --> URI Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Router Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Output Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Input Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 07:58:03 --> Language Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Loader Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Controller Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Model Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Model Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Model Class Initialized
DEBUG - 2011-08-03 07:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 07:58:03 --> Database Driver Class Initialized
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 07:58:04 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:58:04 --> Helper loaded: url_helper
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 07:58:04 --> Final output sent to browser
DEBUG - 2011-08-03 07:58:04 --> Final output sent to browser
DEBUG - 2011-08-03 07:58:04 --> Total execution time: 0.2179
DEBUG - 2011-08-03 07:58:04 --> Total execution time: 1.6988
DEBUG - 2011-08-03 07:58:13 --> Config Class Initialized
DEBUG - 2011-08-03 07:58:13 --> Hooks Class Initialized
DEBUG - 2011-08-03 07:58:13 --> Utf8 Class Initialized
DEBUG - 2011-08-03 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 07:58:13 --> URI Class Initialized
DEBUG - 2011-08-03 07:58:13 --> Router Class Initialized
ERROR - 2011-08-03 07:58:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:13:21 --> Config Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:13:21 --> URI Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Router Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Output Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Input Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:13:21 --> Language Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Loader Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Controller Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Model Class Initialized
DEBUG - 2011-08-03 09:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:13:21 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:13:22 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:13:22 --> Final output sent to browser
DEBUG - 2011-08-03 09:13:22 --> Total execution time: 0.3874
DEBUG - 2011-08-03 09:13:26 --> Config Class Initialized
DEBUG - 2011-08-03 09:13:26 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:13:26 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:13:26 --> URI Class Initialized
DEBUG - 2011-08-03 09:13:26 --> Router Class Initialized
ERROR - 2011-08-03 09:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:13:27 --> Config Class Initialized
DEBUG - 2011-08-03 09:13:27 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:13:27 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:13:27 --> URI Class Initialized
DEBUG - 2011-08-03 09:13:27 --> Router Class Initialized
ERROR - 2011-08-03 09:13:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:13:34 --> Config Class Initialized
DEBUG - 2011-08-03 09:13:34 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:13:34 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:13:34 --> URI Class Initialized
DEBUG - 2011-08-03 09:13:34 --> Router Class Initialized
ERROR - 2011-08-03 09:13:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-03 09:35:48 --> Config Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:35:48 --> URI Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Router Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Output Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Input Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:35:48 --> Language Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Loader Class Initialized
DEBUG - 2011-08-03 09:35:48 --> Controller Class Initialized
ERROR - 2011-08-03 09:35:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:35:49 --> Model Class Initialized
DEBUG - 2011-08-03 09:35:49 --> Model Class Initialized
DEBUG - 2011-08-03 09:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:35:49 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:35:49 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:35:49 --> Final output sent to browser
DEBUG - 2011-08-03 09:35:49 --> Total execution time: 0.5628
DEBUG - 2011-08-03 09:35:49 --> Config Class Initialized
DEBUG - 2011-08-03 09:35:49 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:35:49 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:35:49 --> URI Class Initialized
DEBUG - 2011-08-03 09:35:49 --> Router Class Initialized
ERROR - 2011-08-03 09:35:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:35:50 --> Config Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:35:50 --> URI Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Router Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Output Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Input Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:35:50 --> Language Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Loader Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Controller Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Model Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Model Class Initialized
DEBUG - 2011-08-03 09:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:35:50 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:35:51 --> Final output sent to browser
DEBUG - 2011-08-03 09:35:51 --> Total execution time: 0.9968
DEBUG - 2011-08-03 09:39:51 --> Config Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:39:51 --> URI Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Router Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Output Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Input Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:39:51 --> Language Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Loader Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Controller Class Initialized
ERROR - 2011-08-03 09:39:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:39:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:39:51 --> Model Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Model Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:39:51 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:39:51 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:39:51 --> Final output sent to browser
DEBUG - 2011-08-03 09:39:51 --> Total execution time: 0.0922
DEBUG - 2011-08-03 09:39:51 --> Config Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:39:51 --> URI Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Router Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Output Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Input Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:39:51 --> Language Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Loader Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Controller Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Model Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Model Class Initialized
DEBUG - 2011-08-03 09:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:39:51 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:39:52 --> Final output sent to browser
DEBUG - 2011-08-03 09:39:52 --> Total execution time: 0.7351
DEBUG - 2011-08-03 09:39:54 --> Config Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:39:54 --> URI Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Router Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Output Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Input Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:39:54 --> Language Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Loader Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Controller Class Initialized
ERROR - 2011-08-03 09:39:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:39:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:39:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:39:54 --> Model Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Model Class Initialized
DEBUG - 2011-08-03 09:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:39:54 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:39:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:39:54 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:39:54 --> Final output sent to browser
DEBUG - 2011-08-03 09:39:54 --> Total execution time: 0.1002
DEBUG - 2011-08-03 09:40:52 --> Config Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:40:52 --> URI Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Router Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Output Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Input Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:40:52 --> Language Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Loader Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Controller Class Initialized
ERROR - 2011-08-03 09:40:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:40:52 --> Model Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Model Class Initialized
DEBUG - 2011-08-03 09:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:40:52 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:40:52 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:40:52 --> Final output sent to browser
DEBUG - 2011-08-03 09:40:52 --> Total execution time: 0.0650
DEBUG - 2011-08-03 09:40:53 --> Config Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:40:53 --> URI Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Router Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Output Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Input Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:40:53 --> Language Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Loader Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Controller Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Model Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Model Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:40:53 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Config Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:40:53 --> URI Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Router Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Output Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Input Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:40:53 --> Language Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Loader Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Controller Class Initialized
ERROR - 2011-08-03 09:40:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:40:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:40:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:40:53 --> Model Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Model Class Initialized
DEBUG - 2011-08-03 09:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:40:53 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:40:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:40:53 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:40:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:40:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:40:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:40:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:40:53 --> Final output sent to browser
DEBUG - 2011-08-03 09:40:53 --> Total execution time: 0.1022
DEBUG - 2011-08-03 09:40:54 --> Final output sent to browser
DEBUG - 2011-08-03 09:40:54 --> Total execution time: 0.8254
DEBUG - 2011-08-03 09:41:11 --> Config Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:41:11 --> URI Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Router Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Output Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Input Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:41:11 --> Language Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Loader Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Controller Class Initialized
ERROR - 2011-08-03 09:41:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:41:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:41:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:41:11 --> Model Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Model Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:41:11 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:41:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:41:11 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:41:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:41:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:41:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:41:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:41:11 --> Final output sent to browser
DEBUG - 2011-08-03 09:41:11 --> Total execution time: 0.1475
DEBUG - 2011-08-03 09:41:11 --> Config Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:41:11 --> URI Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Router Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Output Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Input Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:41:11 --> Language Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Loader Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Controller Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Model Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Model Class Initialized
DEBUG - 2011-08-03 09:41:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:41:11 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Config Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:41:12 --> URI Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Router Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Output Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Input Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:41:12 --> Language Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Loader Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Controller Class Initialized
ERROR - 2011-08-03 09:41:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 09:41:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 09:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:41:12 --> Model Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Model Class Initialized
DEBUG - 2011-08-03 09:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:41:12 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 09:41:12 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:41:12 --> Final output sent to browser
DEBUG - 2011-08-03 09:41:12 --> Total execution time: 0.1571
DEBUG - 2011-08-03 09:41:13 --> Final output sent to browser
DEBUG - 2011-08-03 09:41:13 --> Total execution time: 2.0552
DEBUG - 2011-08-03 09:45:46 --> Config Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:45:46 --> URI Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Router Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Output Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Input Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:45:46 --> Language Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Loader Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Controller Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:45:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:45:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:45:46 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:45:46 --> Final output sent to browser
DEBUG - 2011-08-03 09:45:46 --> Total execution time: 0.2377
DEBUG - 2011-08-03 09:45:49 --> Config Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:45:49 --> URI Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Router Class Initialized
ERROR - 2011-08-03 09:45:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:45:49 --> Config Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:45:49 --> URI Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Router Class Initialized
ERROR - 2011-08-03 09:45:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:45:49 --> Config Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:45:49 --> URI Class Initialized
DEBUG - 2011-08-03 09:45:49 --> Router Class Initialized
ERROR - 2011-08-03 09:45:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 09:45:57 --> Config Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:45:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:45:57 --> URI Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Router Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Output Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Input Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:45:57 --> Language Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Loader Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Controller Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Model Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Model Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Model Class Initialized
DEBUG - 2011-08-03 09:45:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:45:57 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:45:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:45:57 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:45:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:45:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:45:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:45:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:45:57 --> Final output sent to browser
DEBUG - 2011-08-03 09:45:57 --> Total execution time: 0.2618
DEBUG - 2011-08-03 09:46:34 --> Config Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:46:34 --> URI Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Router Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Output Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Input Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:46:34 --> Language Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Loader Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Controller Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Model Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Model Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Model Class Initialized
DEBUG - 2011-08-03 09:46:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:46:34 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:46:35 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:46:35 --> Final output sent to browser
DEBUG - 2011-08-03 09:46:35 --> Total execution time: 0.8233
DEBUG - 2011-08-03 09:46:46 --> Config Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:46:46 --> URI Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Router Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Output Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Input Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:46:46 --> Language Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Loader Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Controller Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:46:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:46:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:46:47 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:46:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:46:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:46:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:46:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:46:47 --> Final output sent to browser
DEBUG - 2011-08-03 09:46:47 --> Total execution time: 0.2230
DEBUG - 2011-08-03 09:47:13 --> Config Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:47:13 --> URI Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Router Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Output Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Input Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:47:13 --> Language Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Loader Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Controller Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Model Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Model Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Model Class Initialized
DEBUG - 2011-08-03 09:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:47:13 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:47:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:47:14 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:47:14 --> Final output sent to browser
DEBUG - 2011-08-03 09:47:14 --> Total execution time: 1.6094
DEBUG - 2011-08-03 09:47:48 --> Config Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:47:48 --> URI Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Router Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Output Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Input Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:47:48 --> Language Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Loader Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Controller Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Model Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Model Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Model Class Initialized
DEBUG - 2011-08-03 09:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:47:48 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:47:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:47:49 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:47:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:47:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:47:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:47:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:47:49 --> Final output sent to browser
DEBUG - 2011-08-03 09:47:49 --> Total execution time: 0.6942
DEBUG - 2011-08-03 09:48:01 --> Config Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:48:01 --> URI Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Router Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Output Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Input Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:48:01 --> Language Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Loader Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Controller Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:48:01 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:48:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:48:01 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:48:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:48:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:48:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:48:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:48:01 --> Final output sent to browser
DEBUG - 2011-08-03 09:48:01 --> Total execution time: 0.0692
DEBUG - 2011-08-03 09:48:09 --> Config Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:48:09 --> URI Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Router Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Output Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Input Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:48:09 --> Language Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Loader Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Controller Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:48:09 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:48:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:48:09 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:48:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:48:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:48:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:48:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:48:09 --> Final output sent to browser
DEBUG - 2011-08-03 09:48:09 --> Total execution time: 0.3772
DEBUG - 2011-08-03 09:48:18 --> Config Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:48:18 --> URI Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Router Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Output Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Input Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:48:18 --> Language Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Loader Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Controller Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:48:18 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:48:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:48:18 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:48:18 --> Final output sent to browser
DEBUG - 2011-08-03 09:48:18 --> Total execution time: 0.0721
DEBUG - 2011-08-03 09:48:25 --> Config Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:48:25 --> URI Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Router Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Output Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Input Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:48:25 --> Language Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Loader Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Controller Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:48:25 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:48:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:48:25 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:48:25 --> Final output sent to browser
DEBUG - 2011-08-03 09:48:25 --> Total execution time: 0.0527
DEBUG - 2011-08-03 09:48:39 --> Config Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:48:39 --> URI Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Router Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Output Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Input Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:48:39 --> Language Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Loader Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Controller Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Model Class Initialized
DEBUG - 2011-08-03 09:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:48:39 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:48:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:48:39 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:48:39 --> Final output sent to browser
DEBUG - 2011-08-03 09:48:39 --> Total execution time: 0.3256
DEBUG - 2011-08-03 09:49:00 --> Config Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:49:00 --> URI Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Router Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Output Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Input Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:49:00 --> Language Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Loader Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Controller Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:49:00 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:49:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:49:00 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:49:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:49:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:49:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:49:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:49:00 --> Final output sent to browser
DEBUG - 2011-08-03 09:49:00 --> Total execution time: 0.2397
DEBUG - 2011-08-03 09:49:13 --> Config Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:49:13 --> URI Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Router Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Output Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Input Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:49:13 --> Language Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Loader Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Controller Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:49:13 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:49:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:49:13 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:49:13 --> Final output sent to browser
DEBUG - 2011-08-03 09:49:13 --> Total execution time: 0.8502
DEBUG - 2011-08-03 09:49:26 --> Config Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:49:26 --> URI Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Router Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Output Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Input Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:49:26 --> Language Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Loader Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Controller Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:49:26 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:49:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:49:27 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:49:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:49:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:49:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:49:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:49:27 --> Final output sent to browser
DEBUG - 2011-08-03 09:49:27 --> Total execution time: 0.7954
DEBUG - 2011-08-03 09:49:36 --> Config Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:49:36 --> URI Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Router Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Output Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Input Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:49:36 --> Language Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Loader Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Controller Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:49:36 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:49:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:49:36 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:49:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:49:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:49:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:49:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:49:36 --> Final output sent to browser
DEBUG - 2011-08-03 09:49:36 --> Total execution time: 0.2694
DEBUG - 2011-08-03 09:49:46 --> Config Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:49:46 --> URI Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Router Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Output Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Input Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:49:46 --> Language Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Loader Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Controller Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:49:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:49:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:49:46 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:49:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:49:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:49:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:49:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:49:46 --> Final output sent to browser
DEBUG - 2011-08-03 09:49:46 --> Total execution time: 0.2198
DEBUG - 2011-08-03 09:49:54 --> Config Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:49:54 --> URI Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Router Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Output Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Input Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:49:54 --> Language Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Loader Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Controller Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Model Class Initialized
DEBUG - 2011-08-03 09:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:49:54 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:49:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:49:54 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:49:54 --> Final output sent to browser
DEBUG - 2011-08-03 09:49:54 --> Total execution time: 0.2311
DEBUG - 2011-08-03 09:50:05 --> Config Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:50:05 --> URI Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Router Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Output Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Input Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:50:05 --> Language Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Loader Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Controller Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:50:05 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:50:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:50:05 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:50:05 --> Final output sent to browser
DEBUG - 2011-08-03 09:50:05 --> Total execution time: 0.2633
DEBUG - 2011-08-03 09:50:16 --> Config Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:50:16 --> URI Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Router Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Output Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Input Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:50:16 --> Language Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Loader Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Controller Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:50:16 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:50:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:50:16 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:50:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:50:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:50:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:50:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:50:16 --> Final output sent to browser
DEBUG - 2011-08-03 09:50:16 --> Total execution time: 0.2072
DEBUG - 2011-08-03 09:50:25 --> Config Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:50:25 --> URI Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Router Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Output Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Input Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:50:25 --> Language Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Loader Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Controller Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:50:25 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:50:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:50:25 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:50:25 --> Final output sent to browser
DEBUG - 2011-08-03 09:50:25 --> Total execution time: 0.0702
DEBUG - 2011-08-03 09:50:41 --> Config Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Hooks Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Utf8 Class Initialized
DEBUG - 2011-08-03 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 09:50:41 --> URI Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Router Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Output Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Input Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 09:50:41 --> Language Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Loader Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Controller Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Model Class Initialized
DEBUG - 2011-08-03 09:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 09:50:41 --> Database Driver Class Initialized
DEBUG - 2011-08-03 09:50:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 09:50:41 --> Helper loaded: url_helper
DEBUG - 2011-08-03 09:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 09:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 09:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 09:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 09:50:41 --> Final output sent to browser
DEBUG - 2011-08-03 09:50:41 --> Total execution time: 0.0521
DEBUG - 2011-08-03 10:11:42 --> Config Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Hooks Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Utf8 Class Initialized
DEBUG - 2011-08-03 10:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 10:11:42 --> URI Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Router Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Output Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Input Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 10:11:42 --> Language Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Loader Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Controller Class Initialized
ERROR - 2011-08-03 10:11:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 10:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 10:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 10:11:42 --> Model Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Model Class Initialized
DEBUG - 2011-08-03 10:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 10:11:42 --> Database Driver Class Initialized
DEBUG - 2011-08-03 10:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 10:11:42 --> Helper loaded: url_helper
DEBUG - 2011-08-03 10:11:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 10:11:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 10:11:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 10:11:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 10:11:42 --> Final output sent to browser
DEBUG - 2011-08-03 10:11:42 --> Total execution time: 0.0530
DEBUG - 2011-08-03 10:11:46 --> Config Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 10:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 10:11:46 --> URI Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Router Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Output Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Input Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 10:11:46 --> Language Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Loader Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Controller Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Model Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Model Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 10:11:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 10:11:46 --> Final output sent to browser
DEBUG - 2011-08-03 10:11:46 --> Total execution time: 0.5890
DEBUG - 2011-08-03 12:06:46 --> Config Class Initialized
DEBUG - 2011-08-03 12:06:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 12:06:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 12:06:46 --> URI Class Initialized
DEBUG - 2011-08-03 12:06:46 --> Router Class Initialized
ERROR - 2011-08-03 12:06:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-03 12:06:47 --> Config Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-03 12:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 12:06:47 --> URI Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Router Class Initialized
DEBUG - 2011-08-03 12:06:47 --> No URI present. Default controller set.
DEBUG - 2011-08-03 12:06:47 --> Output Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Input Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 12:06:47 --> Language Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Loader Class Initialized
DEBUG - 2011-08-03 12:06:47 --> Controller Class Initialized
DEBUG - 2011-08-03 12:06:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-03 12:06:47 --> Helper loaded: url_helper
DEBUG - 2011-08-03 12:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 12:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 12:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 12:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 12:06:47 --> Final output sent to browser
DEBUG - 2011-08-03 12:06:47 --> Total execution time: 0.1520
DEBUG - 2011-08-03 12:06:48 --> Config Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Hooks Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Utf8 Class Initialized
DEBUG - 2011-08-03 12:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 12:06:48 --> URI Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Router Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Output Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Input Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 12:06:48 --> Language Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Loader Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Controller Class Initialized
ERROR - 2011-08-03 12:06:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 12:06:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 12:06:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 12:06:48 --> Model Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Model Class Initialized
DEBUG - 2011-08-03 12:06:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 12:06:48 --> Database Driver Class Initialized
DEBUG - 2011-08-03 12:06:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 12:06:48 --> Helper loaded: url_helper
DEBUG - 2011-08-03 12:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 12:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 12:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 12:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 12:06:48 --> Final output sent to browser
DEBUG - 2011-08-03 12:06:48 --> Total execution time: 0.0580
DEBUG - 2011-08-03 12:06:49 --> Config Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Hooks Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Utf8 Class Initialized
DEBUG - 2011-08-03 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 12:06:49 --> URI Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Router Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Output Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Input Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 12:06:49 --> Language Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Loader Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Controller Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Model Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Model Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Model Class Initialized
DEBUG - 2011-08-03 12:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 12:06:49 --> Database Driver Class Initialized
DEBUG - 2011-08-03 12:06:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 12:06:50 --> Helper loaded: url_helper
DEBUG - 2011-08-03 12:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 12:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 12:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 12:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 12:06:50 --> Final output sent to browser
DEBUG - 2011-08-03 12:06:50 --> Total execution time: 0.4498
DEBUG - 2011-08-03 16:42:30 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:30 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Router Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Output Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Input Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 16:42:30 --> Language Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Loader Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Controller Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 16:42:30 --> Database Driver Class Initialized
DEBUG - 2011-08-03 16:42:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 16:42:30 --> Helper loaded: url_helper
DEBUG - 2011-08-03 16:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 16:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 16:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 16:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 16:42:30 --> Final output sent to browser
DEBUG - 2011-08-03 16:42:30 --> Total execution time: 0.4992
DEBUG - 2011-08-03 16:42:34 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:34 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:34 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:34 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:34 --> Router Class Initialized
ERROR - 2011-08-03 16:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 16:42:34 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:34 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:34 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:34 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:34 --> Router Class Initialized
ERROR - 2011-08-03 16:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 16:42:35 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:35 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:35 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:35 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:35 --> Router Class Initialized
ERROR - 2011-08-03 16:42:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 16:42:45 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:45 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Router Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Output Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Input Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 16:42:45 --> Language Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Loader Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Controller Class Initialized
ERROR - 2011-08-03 16:42:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-03 16:42:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-03 16:42:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 16:42:45 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 16:42:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 16:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-03 16:42:46 --> Helper loaded: url_helper
DEBUG - 2011-08-03 16:42:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 16:42:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 16:42:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 16:42:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 16:42:46 --> Final output sent to browser
DEBUG - 2011-08-03 16:42:46 --> Total execution time: 0.0960
DEBUG - 2011-08-03 16:42:46 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:46 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Router Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Output Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Input Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 16:42:46 --> Language Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Loader Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Controller Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Model Class Initialized
DEBUG - 2011-08-03 16:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 16:42:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 16:42:47 --> Final output sent to browser
DEBUG - 2011-08-03 16:42:47 --> Total execution time: 0.6449
DEBUG - 2011-08-03 16:42:59 --> Config Class Initialized
DEBUG - 2011-08-03 16:42:59 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:42:59 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:42:59 --> URI Class Initialized
DEBUG - 2011-08-03 16:42:59 --> Router Class Initialized
ERROR - 2011-08-03 16:42:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-03 16:43:00 --> Config Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Hooks Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Utf8 Class Initialized
DEBUG - 2011-08-03 16:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 16:43:00 --> URI Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Router Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Output Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Input Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 16:43:00 --> Language Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Loader Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Controller Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Model Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Model Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Model Class Initialized
DEBUG - 2011-08-03 16:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 16:43:00 --> Database Driver Class Initialized
DEBUG - 2011-08-03 16:43:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 16:43:00 --> Helper loaded: url_helper
DEBUG - 2011-08-03 16:43:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 16:43:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 16:43:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 16:43:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 16:43:00 --> Final output sent to browser
DEBUG - 2011-08-03 16:43:00 --> Total execution time: 0.0449
DEBUG - 2011-08-03 18:44:48 --> Config Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:44:48 --> URI Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Router Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Output Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Input Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:44:48 --> Language Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Loader Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Controller Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Model Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Model Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Model Class Initialized
DEBUG - 2011-08-03 18:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:44:48 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:44:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:44:49 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:44:49 --> Final output sent to browser
DEBUG - 2011-08-03 18:44:49 --> Total execution time: 0.3176
DEBUG - 2011-08-03 18:44:52 --> Config Class Initialized
DEBUG - 2011-08-03 18:44:52 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:44:52 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:44:52 --> URI Class Initialized
DEBUG - 2011-08-03 18:44:52 --> Router Class Initialized
ERROR - 2011-08-03 18:44:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:44:59 --> Config Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:44:59 --> URI Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Router Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Output Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Input Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:44:59 --> Language Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Loader Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Controller Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Model Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Model Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Model Class Initialized
DEBUG - 2011-08-03 18:44:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:44:59 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:44:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:44:59 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:44:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:44:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:44:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:44:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:44:59 --> Final output sent to browser
DEBUG - 2011-08-03 18:44:59 --> Total execution time: 0.2424
DEBUG - 2011-08-03 18:45:01 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:01 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:01 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:01 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:01 --> Router Class Initialized
ERROR - 2011-08-03 18:45:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:13 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:13 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:13 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:13 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:13 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:13 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:13 --> Total execution time: 0.4582
DEBUG - 2011-08-03 18:45:15 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:15 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:15 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:15 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:15 --> Router Class Initialized
ERROR - 2011-08-03 18:45:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:20 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:20 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:20 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:20 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:20 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:20 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:20 --> Total execution time: 0.1973
DEBUG - 2011-08-03 18:45:22 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:22 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:22 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:22 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:22 --> Router Class Initialized
ERROR - 2011-08-03 18:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:23 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:23 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:23 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:23 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:23 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:23 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:23 --> Total execution time: 0.0443
DEBUG - 2011-08-03 18:45:24 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:24 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:24 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:24 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:24 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:24 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:24 --> Total execution time: 0.0449
DEBUG - 2011-08-03 18:45:27 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:27 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:27 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:27 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:27 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:27 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:27 --> Total execution time: 0.2981
DEBUG - 2011-08-03 18:45:28 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:28 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:28 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:28 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:28 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:28 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:28 --> Total execution time: 0.0505
DEBUG - 2011-08-03 18:45:28 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:28 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:28 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:29 --> Router Class Initialized
ERROR - 2011-08-03 18:45:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:32 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:32 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:32 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:32 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:33 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:33 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:33 --> Total execution time: 0.4667
DEBUG - 2011-08-03 18:45:34 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:34 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:34 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:34 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:34 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:34 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:34 --> Total execution time: 0.0454
DEBUG - 2011-08-03 18:45:35 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:35 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:35 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:35 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:35 --> Router Class Initialized
ERROR - 2011-08-03 18:45:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:40 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:40 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:40 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:40 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:41 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:41 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:41 --> Total execution time: 0.2488
DEBUG - 2011-08-03 18:45:42 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:42 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Router Class Initialized
ERROR - 2011-08-03 18:45:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:42 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:42 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:42 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:42 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:42 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:42 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:42 --> Total execution time: 0.0899
DEBUG - 2011-08-03 18:45:46 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:46 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:46 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:46 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:46 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:46 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:46 --> Total execution time: 0.2195
DEBUG - 2011-08-03 18:45:47 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:47 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:47 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:47 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:47 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:47 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:47 --> Total execution time: 0.0474
DEBUG - 2011-08-03 18:45:48 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:48 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:48 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:48 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:48 --> Router Class Initialized
ERROR - 2011-08-03 18:45:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:53 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:53 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:53 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:53 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:53 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:53 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:53 --> Total execution time: 0.4184
DEBUG - 2011-08-03 18:45:55 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:55 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:55 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:55 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:55 --> Router Class Initialized
ERROR - 2011-08-03 18:45:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:55 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:55 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:55 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:55 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:55 --> Router Class Initialized
ERROR - 2011-08-03 18:45:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-03 18:45:56 --> Config Class Initialized
DEBUG - 2011-08-03 18:45:56 --> Hooks Class Initialized
DEBUG - 2011-08-03 18:45:56 --> Utf8 Class Initialized
DEBUG - 2011-08-03 18:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 18:45:56 --> URI Class Initialized
DEBUG - 2011-08-03 18:45:56 --> Router Class Initialized
DEBUG - 2011-08-03 18:45:56 --> Output Class Initialized
DEBUG - 2011-08-03 18:45:56 --> Input Class Initialized
DEBUG - 2011-08-03 18:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 18:45:56 --> Language Class Initialized
DEBUG - 2011-08-03 18:45:57 --> Loader Class Initialized
DEBUG - 2011-08-03 18:45:57 --> Controller Class Initialized
DEBUG - 2011-08-03 18:45:57 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:57 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:57 --> Model Class Initialized
DEBUG - 2011-08-03 18:45:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 18:45:57 --> Database Driver Class Initialized
DEBUG - 2011-08-03 18:45:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 18:45:57 --> Helper loaded: url_helper
DEBUG - 2011-08-03 18:45:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 18:45:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 18:45:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 18:45:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 18:45:57 --> Final output sent to browser
DEBUG - 2011-08-03 18:45:57 --> Total execution time: 0.0467
DEBUG - 2011-08-03 21:29:24 --> Config Class Initialized
DEBUG - 2011-08-03 21:29:24 --> Hooks Class Initialized
DEBUG - 2011-08-03 21:29:24 --> Utf8 Class Initialized
DEBUG - 2011-08-03 21:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 21:29:24 --> URI Class Initialized
DEBUG - 2011-08-03 21:29:24 --> Router Class Initialized
ERROR - 2011-08-03 21:29:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-03 22:35:11 --> Config Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Hooks Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Utf8 Class Initialized
DEBUG - 2011-08-03 22:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-03 22:35:11 --> URI Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Router Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Output Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Input Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-03 22:35:11 --> Language Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Loader Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Controller Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Model Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Model Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Model Class Initialized
DEBUG - 2011-08-03 22:35:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-03 22:35:11 --> Database Driver Class Initialized
DEBUG - 2011-08-03 22:35:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-03 22:35:12 --> Helper loaded: url_helper
DEBUG - 2011-08-03 22:35:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-03 22:35:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-03 22:35:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-03 22:35:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-03 22:35:12 --> Final output sent to browser
DEBUG - 2011-08-03 22:35:12 --> Total execution time: 1.2888

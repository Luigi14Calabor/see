<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-21 00:19:28 --> Config Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:19:28 --> URI Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Router Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Output Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Input Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:19:28 --> Language Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Loader Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Controller Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Model Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Model Class Initialized
DEBUG - 2011-04-21 00:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:19:28 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:19:29 --> Final output sent to browser
DEBUG - 2011-04-21 00:19:29 --> Total execution time: 1.1302
DEBUG - 2011-04-21 00:34:41 --> Config Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:34:41 --> URI Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Router Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Output Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Input Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:34:41 --> Language Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Loader Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Controller Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:34:41 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:34:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 00:34:42 --> Helper loaded: url_helper
DEBUG - 2011-04-21 00:34:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 00:34:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 00:34:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 00:34:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 00:34:42 --> Final output sent to browser
DEBUG - 2011-04-21 00:34:42 --> Total execution time: 0.4938
DEBUG - 2011-04-21 00:34:44 --> Config Class Initialized
DEBUG - 2011-04-21 00:34:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:34:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:34:44 --> URI Class Initialized
DEBUG - 2011-04-21 00:34:44 --> Router Class Initialized
ERROR - 2011-04-21 00:34:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 00:34:45 --> Config Class Initialized
DEBUG - 2011-04-21 00:34:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:34:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:34:45 --> URI Class Initialized
DEBUG - 2011-04-21 00:34:45 --> Router Class Initialized
ERROR - 2011-04-21 00:34:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 00:34:57 --> Config Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:34:57 --> URI Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Router Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Output Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Input Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:34:57 --> Language Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Loader Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Controller Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:34:57 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 00:34:57 --> Helper loaded: url_helper
DEBUG - 2011-04-21 00:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 00:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 00:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 00:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 00:34:57 --> Final output sent to browser
DEBUG - 2011-04-21 00:34:57 --> Total execution time: 0.1964
DEBUG - 2011-04-21 00:34:59 --> Config Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:34:59 --> URI Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Router Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Output Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Input Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:34:59 --> Language Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Loader Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Controller Class Initialized
ERROR - 2011-04-21 00:34:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 00:34:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 00:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 00:34:59 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Model Class Initialized
DEBUG - 2011-04-21 00:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:34:59 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 00:34:59 --> Helper loaded: url_helper
DEBUG - 2011-04-21 00:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 00:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 00:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 00:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 00:34:59 --> Final output sent to browser
DEBUG - 2011-04-21 00:34:59 --> Total execution time: 0.0824
DEBUG - 2011-04-21 00:35:01 --> Config Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:35:01 --> URI Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Router Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Output Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Input Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:35:01 --> Language Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Loader Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Controller Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:35:01 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:35:02 --> Final output sent to browser
DEBUG - 2011-04-21 00:35:02 --> Total execution time: 0.6155
DEBUG - 2011-04-21 00:35:19 --> Config Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:35:19 --> URI Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Router Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Output Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Input Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:35:19 --> Language Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Loader Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Controller Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:35:19 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:35:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 00:35:19 --> Helper loaded: url_helper
DEBUG - 2011-04-21 00:35:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 00:35:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 00:35:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 00:35:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 00:35:19 --> Final output sent to browser
DEBUG - 2011-04-21 00:35:19 --> Total execution time: 0.2793
DEBUG - 2011-04-21 00:35:20 --> Config Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Hooks Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Utf8 Class Initialized
DEBUG - 2011-04-21 00:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 00:35:20 --> URI Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Router Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Output Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Input Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 00:35:20 --> Language Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Loader Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Controller Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Model Class Initialized
DEBUG - 2011-04-21 00:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 00:35:20 --> Database Driver Class Initialized
DEBUG - 2011-04-21 00:35:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 00:35:20 --> Helper loaded: url_helper
DEBUG - 2011-04-21 00:35:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 00:35:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 00:35:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 00:35:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 00:35:20 --> Final output sent to browser
DEBUG - 2011-04-21 00:35:20 --> Total execution time: 0.0530
DEBUG - 2011-04-21 02:04:28 --> Config Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:04:28 --> URI Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Router Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Output Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Input Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:04:28 --> Language Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Loader Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Controller Class Initialized
ERROR - 2011-04-21 02:04:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:04:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:04:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:04:28 --> Model Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Model Class Initialized
DEBUG - 2011-04-21 02:04:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:04:28 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:04:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:04:29 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:04:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:04:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:04:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:04:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:04:29 --> Final output sent to browser
DEBUG - 2011-04-21 02:04:29 --> Total execution time: 0.8729
DEBUG - 2011-04-21 02:04:30 --> Config Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:04:30 --> URI Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Router Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Output Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Input Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:04:30 --> Language Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Loader Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Controller Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Model Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Model Class Initialized
DEBUG - 2011-04-21 02:04:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:04:30 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:04:31 --> Final output sent to browser
DEBUG - 2011-04-21 02:04:31 --> Total execution time: 1.0749
DEBUG - 2011-04-21 02:04:32 --> Config Class Initialized
DEBUG - 2011-04-21 02:04:32 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:04:32 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:04:32 --> URI Class Initialized
DEBUG - 2011-04-21 02:04:32 --> Router Class Initialized
ERROR - 2011-04-21 02:04:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 02:05:51 --> Config Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:05:51 --> URI Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Router Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Output Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Input Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:05:51 --> Language Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Loader Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Controller Class Initialized
ERROR - 2011-04-21 02:05:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:05:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:05:51 --> Model Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Model Class Initialized
DEBUG - 2011-04-21 02:05:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:05:51 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:05:51 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:05:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:05:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:05:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:05:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:05:51 --> Final output sent to browser
DEBUG - 2011-04-21 02:05:51 --> Total execution time: 0.0313
DEBUG - 2011-04-21 02:05:52 --> Config Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:05:52 --> URI Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Router Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Output Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Input Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:05:52 --> Language Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Loader Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Controller Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Model Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Model Class Initialized
DEBUG - 2011-04-21 02:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:05:52 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:05:53 --> Final output sent to browser
DEBUG - 2011-04-21 02:05:53 --> Total execution time: 1.3697
DEBUG - 2011-04-21 02:05:54 --> Config Class Initialized
DEBUG - 2011-04-21 02:05:54 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:05:54 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:05:54 --> URI Class Initialized
DEBUG - 2011-04-21 02:05:54 --> Router Class Initialized
ERROR - 2011-04-21 02:05:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 02:06:44 --> Config Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:06:44 --> URI Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Router Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Output Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Input Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:06:44 --> Language Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Loader Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Controller Class Initialized
ERROR - 2011-04-21 02:06:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:06:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:06:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:06:44 --> Model Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Model Class Initialized
DEBUG - 2011-04-21 02:06:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:06:44 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:06:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:06:44 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:06:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:06:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:06:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:06:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:06:44 --> Final output sent to browser
DEBUG - 2011-04-21 02:06:44 --> Total execution time: 0.0326
DEBUG - 2011-04-21 02:06:45 --> Config Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:06:45 --> URI Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Router Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Output Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Input Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:06:45 --> Language Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Loader Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Controller Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Model Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Model Class Initialized
DEBUG - 2011-04-21 02:06:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:06:45 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:06:46 --> Final output sent to browser
DEBUG - 2011-04-21 02:06:46 --> Total execution time: 0.6905
DEBUG - 2011-04-21 02:06:48 --> Config Class Initialized
DEBUG - 2011-04-21 02:06:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:06:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:06:48 --> URI Class Initialized
DEBUG - 2011-04-21 02:06:48 --> Router Class Initialized
ERROR - 2011-04-21 02:06:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 02:55:27 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:27 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:27 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:28 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Router Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Output Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Input Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:55:28 --> Language Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Loader Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Controller Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:55:28 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:55:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 02:55:36 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:55:36 --> Final output sent to browser
DEBUG - 2011-04-21 02:55:36 --> Total execution time: 9.0404
DEBUG - 2011-04-21 02:55:36 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:36 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Router Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Output Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Input Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:55:36 --> Language Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Loader Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Controller Class Initialized
ERROR - 2011-04-21 02:55:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:55:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:55:36 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:55:36 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:55:36 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:55:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:55:36 --> Final output sent to browser
DEBUG - 2011-04-21 02:55:36 --> Total execution time: 0.3978
DEBUG - 2011-04-21 02:55:38 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:38 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Router Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Output Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Input Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:55:38 --> Language Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Loader Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Controller Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:55:38 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:55:44 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:44 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:44 --> Router Class Initialized
ERROR - 2011-04-21 02:55:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 02:55:45 --> Final output sent to browser
DEBUG - 2011-04-21 02:55:45 --> Total execution time: 7.1851
DEBUG - 2011-04-21 02:55:46 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:46 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:46 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:46 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:46 --> Router Class Initialized
ERROR - 2011-04-21 02:55:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 02:55:54 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:54 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Router Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Output Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Input Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:55:54 --> Language Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Loader Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Controller Class Initialized
ERROR - 2011-04-21 02:55:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:55:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:55:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:55:54 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:55:54 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:55:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:55:54 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:55:54 --> Final output sent to browser
DEBUG - 2011-04-21 02:55:54 --> Total execution time: 0.0318
DEBUG - 2011-04-21 02:55:55 --> Config Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:55:55 --> URI Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Router Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Output Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Input Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:55:55 --> Language Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Loader Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Controller Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Model Class Initialized
DEBUG - 2011-04-21 02:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:55:55 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:56:02 --> Final output sent to browser
DEBUG - 2011-04-21 02:56:02 --> Total execution time: 7.4306
DEBUG - 2011-04-21 02:57:10 --> Config Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:57:10 --> URI Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Router Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Output Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Input Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:57:10 --> Language Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Loader Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Controller Class Initialized
ERROR - 2011-04-21 02:57:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:57:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:57:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:57:10 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:57:10 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:57:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:57:10 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:57:10 --> Final output sent to browser
DEBUG - 2011-04-21 02:57:10 --> Total execution time: 0.1179
DEBUG - 2011-04-21 02:57:11 --> Config Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:57:11 --> URI Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Router Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Output Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Input Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:57:11 --> Language Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Loader Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Controller Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:57:12 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:57:12 --> Final output sent to browser
DEBUG - 2011-04-21 02:57:12 --> Total execution time: 0.9611
DEBUG - 2011-04-21 02:57:48 --> Config Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:57:48 --> URI Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Router Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Output Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Input Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:57:48 --> Language Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Loader Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Controller Class Initialized
ERROR - 2011-04-21 02:57:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:57:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:57:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:57:48 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:57:48 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:57:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:57:48 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:57:48 --> Final output sent to browser
DEBUG - 2011-04-21 02:57:48 --> Total execution time: 0.0848
DEBUG - 2011-04-21 02:57:48 --> Config Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:57:48 --> URI Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Router Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Output Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Input Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:57:48 --> Language Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Loader Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Controller Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Model Class Initialized
DEBUG - 2011-04-21 02:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:57:49 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:57:51 --> Final output sent to browser
DEBUG - 2011-04-21 02:57:51 --> Total execution time: 2.9085
DEBUG - 2011-04-21 02:59:05 --> Config Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:59:05 --> URI Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Router Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Output Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Input Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:59:05 --> Language Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Loader Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Controller Class Initialized
ERROR - 2011-04-21 02:59:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:59:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:59:05 --> Model Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Model Class Initialized
DEBUG - 2011-04-21 02:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:59:05 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:59:05 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:59:05 --> Final output sent to browser
DEBUG - 2011-04-21 02:59:05 --> Total execution time: 0.0363
DEBUG - 2011-04-21 02:59:07 --> Config Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:59:07 --> URI Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Router Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Output Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Input Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:59:07 --> Language Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Loader Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Controller Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Model Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Model Class Initialized
DEBUG - 2011-04-21 02:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:59:07 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:59:08 --> Config Class Initialized
DEBUG - 2011-04-21 02:59:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:59:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:59:08 --> URI Class Initialized
DEBUG - 2011-04-21 02:59:08 --> Router Class Initialized
ERROR - 2011-04-21 02:59:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 02:59:09 --> Config Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 02:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 02:59:09 --> URI Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Router Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Output Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Input Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 02:59:09 --> Language Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Loader Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Controller Class Initialized
ERROR - 2011-04-21 02:59:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 02:59:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 02:59:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:59:09 --> Model Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Model Class Initialized
DEBUG - 2011-04-21 02:59:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 02:59:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 02:59:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 02:59:09 --> Helper loaded: url_helper
DEBUG - 2011-04-21 02:59:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 02:59:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 02:59:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 02:59:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 02:59:09 --> Final output sent to browser
DEBUG - 2011-04-21 02:59:09 --> Total execution time: 0.0589
DEBUG - 2011-04-21 02:59:09 --> Final output sent to browser
DEBUG - 2011-04-21 02:59:09 --> Total execution time: 2.3928
DEBUG - 2011-04-21 03:00:21 --> Config Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:00:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:00:21 --> URI Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Router Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Output Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Input Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:00:21 --> Language Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Loader Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Controller Class Initialized
ERROR - 2011-04-21 03:00:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:00:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:00:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:00:21 --> Model Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Model Class Initialized
DEBUG - 2011-04-21 03:00:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:00:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:00:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:00:21 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:00:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:00:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:00:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:00:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:00:21 --> Final output sent to browser
DEBUG - 2011-04-21 03:00:21 --> Total execution time: 0.0633
DEBUG - 2011-04-21 03:00:22 --> Config Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:00:22 --> URI Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Router Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Output Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Input Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:00:22 --> Language Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Loader Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Controller Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Model Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Model Class Initialized
DEBUG - 2011-04-21 03:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:00:22 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:00:35 --> Final output sent to browser
DEBUG - 2011-04-21 03:00:35 --> Total execution time: 13.0662
DEBUG - 2011-04-21 03:00:40 --> Config Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:00:40 --> URI Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Router Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Output Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Input Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:00:40 --> Language Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Loader Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Controller Class Initialized
ERROR - 2011-04-21 03:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:00:40 --> Model Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Model Class Initialized
DEBUG - 2011-04-21 03:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:00:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:00:40 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:00:40 --> Final output sent to browser
DEBUG - 2011-04-21 03:00:40 --> Total execution time: 0.0314
DEBUG - 2011-04-21 03:01:35 --> Config Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:01:35 --> URI Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Router Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Output Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Input Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:01:35 --> Language Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Loader Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Controller Class Initialized
ERROR - 2011-04-21 03:01:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:01:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:01:35 --> Model Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Model Class Initialized
DEBUG - 2011-04-21 03:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:01:35 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:01:35 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:01:35 --> Final output sent to browser
DEBUG - 2011-04-21 03:01:35 --> Total execution time: 0.0349
DEBUG - 2011-04-21 03:01:36 --> Config Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:01:36 --> URI Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Router Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Output Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Input Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:01:36 --> Language Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Loader Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Controller Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Model Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Model Class Initialized
DEBUG - 2011-04-21 03:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:01:36 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:01:37 --> Final output sent to browser
DEBUG - 2011-04-21 03:01:37 --> Total execution time: 0.5158
DEBUG - 2011-04-21 03:02:07 --> Config Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:02:07 --> URI Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Router Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Output Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Input Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:02:07 --> Language Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Loader Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Controller Class Initialized
ERROR - 2011-04-21 03:02:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:02:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:02:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:02:07 --> Model Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Model Class Initialized
DEBUG - 2011-04-21 03:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:02:07 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:02:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:02:07 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:02:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:02:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:02:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:02:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:02:07 --> Final output sent to browser
DEBUG - 2011-04-21 03:02:07 --> Total execution time: 0.0532
DEBUG - 2011-04-21 03:02:08 --> Config Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:02:08 --> URI Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Router Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Output Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Input Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:02:08 --> Language Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Loader Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Controller Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Model Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Model Class Initialized
DEBUG - 2011-04-21 03:02:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:02:08 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:02:09 --> Final output sent to browser
DEBUG - 2011-04-21 03:02:09 --> Total execution time: 0.7566
DEBUG - 2011-04-21 03:03:22 --> Config Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:03:22 --> URI Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Router Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Output Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Input Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:03:22 --> Language Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Loader Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Controller Class Initialized
ERROR - 2011-04-21 03:03:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:03:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:03:22 --> Model Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Model Class Initialized
DEBUG - 2011-04-21 03:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:03:22 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:03:22 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:03:22 --> Final output sent to browser
DEBUG - 2011-04-21 03:03:22 --> Total execution time: 0.0918
DEBUG - 2011-04-21 03:03:23 --> Config Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:03:23 --> URI Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Router Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Output Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Input Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:03:23 --> Language Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Loader Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Controller Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Model Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Model Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:03:23 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:03:23 --> Final output sent to browser
DEBUG - 2011-04-21 03:03:23 --> Total execution time: 0.6657
DEBUG - 2011-04-21 03:17:42 --> Config Class Initialized
DEBUG - 2011-04-21 03:17:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:17:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:17:42 --> URI Class Initialized
DEBUG - 2011-04-21 03:17:42 --> Router Class Initialized
DEBUG - 2011-04-21 03:17:42 --> No URI present. Default controller set.
DEBUG - 2011-04-21 03:17:42 --> Output Class Initialized
DEBUG - 2011-04-21 03:17:42 --> Input Class Initialized
DEBUG - 2011-04-21 03:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:17:43 --> Language Class Initialized
DEBUG - 2011-04-21 03:17:43 --> Loader Class Initialized
DEBUG - 2011-04-21 03:17:43 --> Controller Class Initialized
DEBUG - 2011-04-21 03:17:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 03:17:44 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:17:44 --> Final output sent to browser
DEBUG - 2011-04-21 03:17:44 --> Total execution time: 2.6838
DEBUG - 2011-04-21 03:17:48 --> Config Class Initialized
DEBUG - 2011-04-21 03:17:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:17:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:17:48 --> URI Class Initialized
DEBUG - 2011-04-21 03:17:48 --> Router Class Initialized
ERROR - 2011-04-21 03:17:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 03:17:49 --> Config Class Initialized
DEBUG - 2011-04-21 03:17:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:17:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:17:49 --> URI Class Initialized
DEBUG - 2011-04-21 03:17:49 --> Router Class Initialized
ERROR - 2011-04-21 03:17:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 03:17:50 --> Config Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:17:50 --> URI Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Router Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Output Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Input Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:17:50 --> Language Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Loader Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Controller Class Initialized
ERROR - 2011-04-21 03:17:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:17:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:17:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:17:50 --> Model Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Model Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:17:50 --> Config Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:17:50 --> URI Class Initialized
DEBUG - 2011-04-21 03:17:50 --> Router Class Initialized
ERROR - 2011-04-21 03:17:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 03:17:50 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:17:51 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:17:51 --> Final output sent to browser
DEBUG - 2011-04-21 03:17:51 --> Total execution time: 0.7190
DEBUG - 2011-04-21 03:17:52 --> Config Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:17:52 --> URI Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Router Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Output Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Input Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:17:52 --> Language Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Loader Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Controller Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Model Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Model Class Initialized
DEBUG - 2011-04-21 03:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:17:52 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:17:54 --> Final output sent to browser
DEBUG - 2011-04-21 03:17:54 --> Total execution time: 1.9074
DEBUG - 2011-04-21 03:18:18 --> Config Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:18:18 --> URI Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Router Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Output Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Input Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:18:18 --> Language Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Loader Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Controller Class Initialized
ERROR - 2011-04-21 03:18:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:18:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:18:18 --> Model Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Model Class Initialized
DEBUG - 2011-04-21 03:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:18:18 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:18:18 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:18:18 --> Final output sent to browser
DEBUG - 2011-04-21 03:18:18 --> Total execution time: 0.1916
DEBUG - 2011-04-21 03:18:20 --> Config Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:18:20 --> URI Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Router Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Output Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Input Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:18:20 --> Language Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Loader Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Controller Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Model Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Model Class Initialized
DEBUG - 2011-04-21 03:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:18:20 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:18:23 --> Final output sent to browser
DEBUG - 2011-04-21 03:18:23 --> Total execution time: 3.9592
DEBUG - 2011-04-21 03:19:10 --> Config Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:19:10 --> URI Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Router Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Output Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Input Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:19:10 --> Language Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Loader Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Controller Class Initialized
ERROR - 2011-04-21 03:19:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:19:10 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:19:10 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:19:10 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:19:10 --> Final output sent to browser
DEBUG - 2011-04-21 03:19:10 --> Total execution time: 0.0454
DEBUG - 2011-04-21 03:19:11 --> Config Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:19:11 --> URI Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Router Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Output Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Input Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:19:11 --> Language Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Loader Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Controller Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:19:11 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:19:13 --> Final output sent to browser
DEBUG - 2011-04-21 03:19:13 --> Total execution time: 1.4564
DEBUG - 2011-04-21 03:19:39 --> Config Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:19:39 --> URI Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Router Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Output Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Input Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:19:39 --> Language Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Loader Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Controller Class Initialized
ERROR - 2011-04-21 03:19:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:19:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:19:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:19:39 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:19:39 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:19:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:19:39 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:19:39 --> Final output sent to browser
DEBUG - 2011-04-21 03:19:39 --> Total execution time: 0.0988
DEBUG - 2011-04-21 03:19:40 --> Config Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:19:40 --> URI Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Router Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Output Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Input Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:19:40 --> Language Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Loader Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Controller Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Model Class Initialized
DEBUG - 2011-04-21 03:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:19:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:19:42 --> Final output sent to browser
DEBUG - 2011-04-21 03:19:42 --> Total execution time: 1.3403
DEBUG - 2011-04-21 03:20:07 --> Config Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:20:07 --> URI Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Router Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Output Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Input Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:20:07 --> Language Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Loader Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Controller Class Initialized
ERROR - 2011-04-21 03:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:20:07 --> Model Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Model Class Initialized
DEBUG - 2011-04-21 03:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:20:07 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:20:07 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:20:07 --> Final output sent to browser
DEBUG - 2011-04-21 03:20:07 --> Total execution time: 0.0875
DEBUG - 2011-04-21 03:20:09 --> Config Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:20:09 --> URI Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Router Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Output Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Input Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:20:09 --> Language Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Loader Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Controller Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Model Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Model Class Initialized
DEBUG - 2011-04-21 03:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:20:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:20:10 --> Final output sent to browser
DEBUG - 2011-04-21 03:20:10 --> Total execution time: 1.2955
DEBUG - 2011-04-21 03:25:29 --> Config Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:25:29 --> URI Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Router Class Initialized
DEBUG - 2011-04-21 03:25:29 --> No URI present. Default controller set.
DEBUG - 2011-04-21 03:25:29 --> Output Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Input Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:25:29 --> Language Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Loader Class Initialized
DEBUG - 2011-04-21 03:25:29 --> Controller Class Initialized
DEBUG - 2011-04-21 03:25:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 03:25:29 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:25:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:25:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:25:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:25:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:25:29 --> Final output sent to browser
DEBUG - 2011-04-21 03:25:29 --> Total execution time: 0.0709
DEBUG - 2011-04-21 03:53:40 --> Config Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:53:40 --> URI Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Router Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Output Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Input Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:53:40 --> Language Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Loader Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Controller Class Initialized
ERROR - 2011-04-21 03:53:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:53:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:53:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:53:40 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:53:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:53:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:53:40 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:53:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:53:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:53:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:53:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:53:40 --> Final output sent to browser
DEBUG - 2011-04-21 03:53:40 --> Total execution time: 0.5590
DEBUG - 2011-04-21 03:53:42 --> Config Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:53:42 --> URI Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Router Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Output Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Input Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:53:42 --> Language Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Loader Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Controller Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:53:42 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:53:42 --> Final output sent to browser
DEBUG - 2011-04-21 03:53:42 --> Total execution time: 0.7981
DEBUG - 2011-04-21 03:53:44 --> Config Class Initialized
DEBUG - 2011-04-21 03:53:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:53:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:53:44 --> URI Class Initialized
DEBUG - 2011-04-21 03:53:44 --> Router Class Initialized
ERROR - 2011-04-21 03:53:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 03:53:46 --> Config Class Initialized
DEBUG - 2011-04-21 03:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:53:46 --> URI Class Initialized
DEBUG - 2011-04-21 03:53:46 --> Router Class Initialized
ERROR - 2011-04-21 03:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 03:53:48 --> Config Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:53:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:53:48 --> URI Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Router Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Output Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Input Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:53:48 --> Language Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Loader Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Controller Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Model Class Initialized
DEBUG - 2011-04-21 03:53:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:53:48 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:53:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 03:53:49 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:53:49 --> Final output sent to browser
DEBUG - 2011-04-21 03:53:49 --> Total execution time: 0.6508
DEBUG - 2011-04-21 03:54:37 --> Config Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:54:37 --> URI Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Router Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Output Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Input Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:54:37 --> Language Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Loader Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Controller Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Model Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Model Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Model Class Initialized
DEBUG - 2011-04-21 03:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:54:37 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:54:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 03:54:38 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:54:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:54:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:54:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:54:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:54:38 --> Final output sent to browser
DEBUG - 2011-04-21 03:54:38 --> Total execution time: 0.6399
DEBUG - 2011-04-21 03:55:09 --> Config Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:55:09 --> URI Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Router Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Output Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Input Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:55:09 --> Language Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Loader Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Controller Class Initialized
ERROR - 2011-04-21 03:55:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:55:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:55:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:55:09 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:55:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:55:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:55:09 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:55:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:55:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:55:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:55:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:55:09 --> Final output sent to browser
DEBUG - 2011-04-21 03:55:09 --> Total execution time: 0.0278
DEBUG - 2011-04-21 03:55:10 --> Config Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:55:10 --> URI Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Router Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Output Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Input Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:55:10 --> Language Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Loader Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Controller Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:55:10 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:55:17 --> Final output sent to browser
DEBUG - 2011-04-21 03:55:17 --> Total execution time: 7.2784
DEBUG - 2011-04-21 03:55:37 --> Config Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:55:37 --> URI Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Router Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Output Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Input Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:55:37 --> Language Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Loader Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Controller Class Initialized
ERROR - 2011-04-21 03:55:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:55:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:55:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:55:37 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:55:37 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:55:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:55:37 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:55:37 --> Final output sent to browser
DEBUG - 2011-04-21 03:55:37 --> Total execution time: 0.0305
DEBUG - 2011-04-21 03:55:38 --> Config Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:55:38 --> URI Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Router Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Output Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Input Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:55:38 --> Language Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Loader Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Controller Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Model Class Initialized
DEBUG - 2011-04-21 03:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:55:38 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:55:42 --> Final output sent to browser
DEBUG - 2011-04-21 03:55:42 --> Total execution time: 4.0355
DEBUG - 2011-04-21 03:57:49 --> Config Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:57:49 --> URI Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Router Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Output Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Input Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:57:49 --> Language Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Loader Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Controller Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Model Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Model Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Model Class Initialized
DEBUG - 2011-04-21 03:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:57:49 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:57:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 03:57:49 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:57:49 --> Final output sent to browser
DEBUG - 2011-04-21 03:57:49 --> Total execution time: 0.1967
DEBUG - 2011-04-21 03:58:13 --> Config Class Initialized
DEBUG - 2011-04-21 03:58:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:58:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:58:14 --> URI Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Router Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Output Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Input Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:58:14 --> Language Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Loader Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Controller Class Initialized
ERROR - 2011-04-21 03:58:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:58:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:58:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:58:14 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:58:14 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:58:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:58:14 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:58:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:58:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:58:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:58:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:58:14 --> Final output sent to browser
DEBUG - 2011-04-21 03:58:14 --> Total execution time: 0.0513
DEBUG - 2011-04-21 03:58:15 --> Config Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:58:15 --> URI Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Router Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Output Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Input Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:58:15 --> Language Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Loader Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Controller Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:58:15 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:58:16 --> Final output sent to browser
DEBUG - 2011-04-21 03:58:16 --> Total execution time: 0.7619
DEBUG - 2011-04-21 03:58:23 --> Config Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:58:23 --> URI Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Router Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Output Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Input Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:58:23 --> Language Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Loader Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Controller Class Initialized
ERROR - 2011-04-21 03:58:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 03:58:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 03:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:58:23 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:58:23 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 03:58:23 --> Helper loaded: url_helper
DEBUG - 2011-04-21 03:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 03:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 03:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 03:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 03:58:23 --> Final output sent to browser
DEBUG - 2011-04-21 03:58:23 --> Total execution time: 0.0314
DEBUG - 2011-04-21 03:58:24 --> Config Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Hooks Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Utf8 Class Initialized
DEBUG - 2011-04-21 03:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 03:58:24 --> URI Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Router Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Output Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Input Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 03:58:24 --> Language Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Loader Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Controller Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Model Class Initialized
DEBUG - 2011-04-21 03:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 03:58:24 --> Database Driver Class Initialized
DEBUG - 2011-04-21 03:58:25 --> Final output sent to browser
DEBUG - 2011-04-21 03:58:25 --> Total execution time: 0.6430
DEBUG - 2011-04-21 04:06:51 --> Config Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:06:51 --> URI Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Router Class Initialized
ERROR - 2011-04-21 04:06:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 04:06:51 --> Config Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:06:51 --> URI Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Router Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Output Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Input Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:06:51 --> Language Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Loader Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Controller Class Initialized
ERROR - 2011-04-21 04:06:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 04:06:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 04:06:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:06:51 --> Model Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Model Class Initialized
DEBUG - 2011-04-21 04:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:06:51 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:06:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:06:52 --> Helper loaded: url_helper
DEBUG - 2011-04-21 04:06:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 04:06:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 04:06:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 04:06:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 04:06:52 --> Final output sent to browser
DEBUG - 2011-04-21 04:06:52 --> Total execution time: 0.4977
DEBUG - 2011-04-21 04:21:41 --> Config Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:21:41 --> URI Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Router Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Output Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Input Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:21:41 --> Language Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Loader Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Controller Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Model Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Model Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Model Class Initialized
DEBUG - 2011-04-21 04:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:21:41 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:21:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 04:21:41 --> Helper loaded: url_helper
DEBUG - 2011-04-21 04:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 04:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 04:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 04:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 04:21:41 --> Final output sent to browser
DEBUG - 2011-04-21 04:21:41 --> Total execution time: 0.3833
DEBUG - 2011-04-21 04:21:42 --> Config Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:21:42 --> URI Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Router Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Output Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Input Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:21:42 --> Language Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Loader Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Controller Class Initialized
ERROR - 2011-04-21 04:21:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 04:21:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 04:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:21:42 --> Model Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Model Class Initialized
DEBUG - 2011-04-21 04:21:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:21:42 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:21:42 --> Helper loaded: url_helper
DEBUG - 2011-04-21 04:21:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 04:21:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 04:21:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 04:21:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 04:21:42 --> Final output sent to browser
DEBUG - 2011-04-21 04:21:42 --> Total execution time: 0.1140
DEBUG - 2011-04-21 04:32:08 --> Config Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:32:08 --> URI Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Router Class Initialized
ERROR - 2011-04-21 04:32:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 04:32:08 --> Config Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:32:08 --> URI Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Router Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Output Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Input Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:32:08 --> Language Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Loader Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Controller Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Model Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Model Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Model Class Initialized
DEBUG - 2011-04-21 04:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:32:08 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:32:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 04:32:21 --> Helper loaded: url_helper
DEBUG - 2011-04-21 04:32:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 04:32:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 04:32:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 04:32:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 04:32:21 --> Final output sent to browser
DEBUG - 2011-04-21 04:32:21 --> Total execution time: 13.1809
DEBUG - 2011-04-21 04:42:19 --> Config Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:42:19 --> URI Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Router Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Output Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Input Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:42:19 --> Language Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Loader Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Controller Class Initialized
ERROR - 2011-04-21 04:42:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 04:42:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 04:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:42:19 --> Model Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Model Class Initialized
DEBUG - 2011-04-21 04:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:42:19 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:42:19 --> Helper loaded: url_helper
DEBUG - 2011-04-21 04:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 04:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 04:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 04:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 04:42:19 --> Final output sent to browser
DEBUG - 2011-04-21 04:42:19 --> Total execution time: 0.3504
DEBUG - 2011-04-21 04:42:40 --> Config Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:42:40 --> URI Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Router Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Output Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Input Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:42:40 --> Language Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Loader Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Controller Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Model Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Model Class Initialized
DEBUG - 2011-04-21 04:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:42:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:42:41 --> Final output sent to browser
DEBUG - 2011-04-21 04:42:41 --> Total execution time: 0.6828
DEBUG - 2011-04-21 04:43:53 --> Config Class Initialized
DEBUG - 2011-04-21 04:43:53 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:43:53 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:43:53 --> URI Class Initialized
DEBUG - 2011-04-21 04:43:53 --> Router Class Initialized
ERROR - 2011-04-21 04:43:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 04:44:06 --> Config Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:44:06 --> URI Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Router Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Output Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Input Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:44:06 --> Language Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Loader Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Controller Class Initialized
ERROR - 2011-04-21 04:44:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 04:44:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 04:44:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:44:06 --> Model Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Model Class Initialized
DEBUG - 2011-04-21 04:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:44:06 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:44:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 04:44:06 --> Helper loaded: url_helper
DEBUG - 2011-04-21 04:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 04:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 04:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 04:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 04:44:06 --> Final output sent to browser
DEBUG - 2011-04-21 04:44:06 --> Total execution time: 0.2526
DEBUG - 2011-04-21 04:44:08 --> Config Class Initialized
DEBUG - 2011-04-21 04:44:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:44:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:44:08 --> URI Class Initialized
DEBUG - 2011-04-21 04:44:08 --> Router Class Initialized
ERROR - 2011-04-21 04:44:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 04:45:30 --> Config Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Hooks Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Utf8 Class Initialized
DEBUG - 2011-04-21 04:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 04:45:30 --> URI Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Router Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Output Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Input Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 04:45:30 --> Language Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Loader Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Controller Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Model Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Model Class Initialized
DEBUG - 2011-04-21 04:45:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 04:45:30 --> Database Driver Class Initialized
DEBUG - 2011-04-21 04:45:33 --> Final output sent to browser
DEBUG - 2011-04-21 04:45:33 --> Total execution time: 3.1702
DEBUG - 2011-04-21 05:40:17 --> Config Class Initialized
DEBUG - 2011-04-21 05:40:17 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:40:17 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:40:17 --> URI Class Initialized
DEBUG - 2011-04-21 05:40:17 --> Router Class Initialized
DEBUG - 2011-04-21 05:40:18 --> Output Class Initialized
DEBUG - 2011-04-21 05:40:18 --> Input Class Initialized
DEBUG - 2011-04-21 05:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:40:18 --> Language Class Initialized
DEBUG - 2011-04-21 05:40:18 --> Loader Class Initialized
DEBUG - 2011-04-21 05:40:18 --> Controller Class Initialized
ERROR - 2011-04-21 05:40:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:40:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:40:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:40:19 --> Model Class Initialized
DEBUG - 2011-04-21 05:40:19 --> Model Class Initialized
DEBUG - 2011-04-21 05:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:40:20 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:40:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:40:22 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:40:22 --> Final output sent to browser
DEBUG - 2011-04-21 05:40:22 --> Total execution time: 5.1485
DEBUG - 2011-04-21 05:40:25 --> Config Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:40:25 --> URI Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Router Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Output Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Input Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:40:25 --> Language Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Loader Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Controller Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Model Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Model Class Initialized
DEBUG - 2011-04-21 05:40:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:40:25 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:40:26 --> Final output sent to browser
DEBUG - 2011-04-21 05:40:26 --> Total execution time: 1.2518
DEBUG - 2011-04-21 05:49:24 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:24 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Router Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Output Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Input Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:49:24 --> Language Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Loader Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Controller Class Initialized
ERROR - 2011-04-21 05:49:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:49:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:49:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:49:24 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:49:24 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:49:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:49:24 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:49:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:49:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:49:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:49:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:49:24 --> Final output sent to browser
DEBUG - 2011-04-21 05:49:24 --> Total execution time: 0.2573
DEBUG - 2011-04-21 05:49:25 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:25 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Router Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Output Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Input Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:49:25 --> Language Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Loader Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Controller Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:49:25 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:49:26 --> Final output sent to browser
DEBUG - 2011-04-21 05:49:26 --> Total execution time: 0.6610
DEBUG - 2011-04-21 05:49:27 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:27 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:27 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:27 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:27 --> Router Class Initialized
ERROR - 2011-04-21 05:49:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 05:49:28 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:28 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:28 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:28 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:28 --> Router Class Initialized
ERROR - 2011-04-21 05:49:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 05:49:28 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:28 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:28 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:28 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:28 --> Router Class Initialized
ERROR - 2011-04-21 05:49:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 05:49:41 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:41 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Router Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Output Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Input Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:49:41 --> Language Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Loader Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Controller Class Initialized
ERROR - 2011-04-21 05:49:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:49:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:49:41 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:49:41 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:49:41 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:49:41 --> Final output sent to browser
DEBUG - 2011-04-21 05:49:41 --> Total execution time: 0.1013
DEBUG - 2011-04-21 05:49:42 --> Config Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:49:42 --> URI Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Router Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Output Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Input Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:49:42 --> Language Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Loader Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Controller Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Model Class Initialized
DEBUG - 2011-04-21 05:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:49:42 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:49:43 --> Final output sent to browser
DEBUG - 2011-04-21 05:49:43 --> Total execution time: 0.8194
DEBUG - 2011-04-21 05:50:07 --> Config Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:50:07 --> URI Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Router Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Output Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Input Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:50:07 --> Language Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Loader Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Controller Class Initialized
ERROR - 2011-04-21 05:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:07 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:50:07 --> Final output sent to browser
DEBUG - 2011-04-21 05:50:07 --> Total execution time: 0.0310
DEBUG - 2011-04-21 05:50:08 --> Config Class Initialized
DEBUG - 2011-04-21 05:50:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:50:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:50:08 --> URI Class Initialized
DEBUG - 2011-04-21 05:50:08 --> Router Class Initialized
DEBUG - 2011-04-21 05:50:08 --> Output Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Input Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:50:09 --> Language Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Loader Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Controller Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:50:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:50:09 --> Final output sent to browser
DEBUG - 2011-04-21 05:50:09 --> Total execution time: 1.4706
DEBUG - 2011-04-21 05:50:12 --> Config Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:50:12 --> URI Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Router Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Output Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Input Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:50:12 --> Language Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Loader Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Controller Class Initialized
ERROR - 2011-04-21 05:50:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:50:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:50:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:12 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:50:12 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:50:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:12 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:50:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:50:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:50:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:50:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:50:12 --> Final output sent to browser
DEBUG - 2011-04-21 05:50:12 --> Total execution time: 0.0376
DEBUG - 2011-04-21 05:50:14 --> Config Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:50:14 --> URI Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Router Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Output Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Input Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:50:14 --> Language Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Loader Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Controller Class Initialized
ERROR - 2011-04-21 05:50:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:50:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:14 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:50:14 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:14 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:50:14 --> Final output sent to browser
DEBUG - 2011-04-21 05:50:14 --> Total execution time: 0.0332
DEBUG - 2011-04-21 05:50:43 --> Config Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:50:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:50:43 --> URI Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Router Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Output Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Input Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:50:43 --> Language Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Loader Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Controller Class Initialized
ERROR - 2011-04-21 05:50:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:50:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:50:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:43 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:50:43 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:50:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:50:43 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:50:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:50:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:50:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:50:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:50:43 --> Final output sent to browser
DEBUG - 2011-04-21 05:50:43 --> Total execution time: 0.0280
DEBUG - 2011-04-21 05:50:44 --> Config Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:50:44 --> URI Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Router Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Output Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Input Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:50:44 --> Language Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Loader Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Controller Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Model Class Initialized
DEBUG - 2011-04-21 05:50:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:50:44 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:50:45 --> Final output sent to browser
DEBUG - 2011-04-21 05:50:45 --> Total execution time: 0.6856
DEBUG - 2011-04-21 05:51:00 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:00 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:00 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Controller Class Initialized
ERROR - 2011-04-21 05:51:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:51:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:51:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:00 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:00 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:00 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:51:00 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:00 --> Total execution time: 0.0570
DEBUG - 2011-04-21 05:51:01 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:01 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:01 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Controller Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:01 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:01 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:01 --> Total execution time: 0.6952
DEBUG - 2011-04-21 05:51:12 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:12 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:12 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Controller Class Initialized
ERROR - 2011-04-21 05:51:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:51:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:12 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:12 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:12 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:51:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:51:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:51:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:51:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:51:12 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:12 --> Total execution time: 0.1370
DEBUG - 2011-04-21 05:51:13 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:13 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:13 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Controller Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:13 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:14 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:14 --> Total execution time: 1.5520
DEBUG - 2011-04-21 05:51:29 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:29 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:29 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Controller Class Initialized
ERROR - 2011-04-21 05:51:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:51:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:51:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:29 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:29 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:29 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:51:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:51:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:51:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:51:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:51:29 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:29 --> Total execution time: 0.0352
DEBUG - 2011-04-21 05:51:30 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:30 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:30 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Controller Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:30 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:31 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:31 --> Total execution time: 1.0745
DEBUG - 2011-04-21 05:51:32 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:32 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:32 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Controller Class Initialized
ERROR - 2011-04-21 05:51:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:51:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:51:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:32 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:33 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:33 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:51:33 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:33 --> Total execution time: 0.0335
DEBUG - 2011-04-21 05:51:47 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:47 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:47 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Controller Class Initialized
ERROR - 2011-04-21 05:51:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:51:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:47 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:47 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:51:47 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:51:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:51:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:51:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:51:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:51:47 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:47 --> Total execution time: 0.0760
DEBUG - 2011-04-21 05:51:48 --> Config Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:51:48 --> URI Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Router Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Output Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Input Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:51:48 --> Language Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Loader Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Controller Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Model Class Initialized
DEBUG - 2011-04-21 05:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:51:48 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:51:49 --> Final output sent to browser
DEBUG - 2011-04-21 05:51:49 --> Total execution time: 0.5963
DEBUG - 2011-04-21 05:52:02 --> Config Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:52:02 --> URI Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Router Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Output Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Input Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:52:02 --> Language Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Loader Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Controller Class Initialized
ERROR - 2011-04-21 05:52:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 05:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 05:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:52:02 --> Model Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Model Class Initialized
DEBUG - 2011-04-21 05:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:52:02 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 05:52:02 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:52:02 --> Final output sent to browser
DEBUG - 2011-04-21 05:52:02 --> Total execution time: 0.0333
DEBUG - 2011-04-21 05:52:03 --> Config Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:52:03 --> URI Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Router Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Output Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Input Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:52:03 --> Language Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Loader Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Controller Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Model Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Model Class Initialized
DEBUG - 2011-04-21 05:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:52:03 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:52:04 --> Final output sent to browser
DEBUG - 2011-04-21 05:52:04 --> Total execution time: 1.1147
DEBUG - 2011-04-21 05:58:05 --> Config Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:58:05 --> URI Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Router Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Output Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Input Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 05:58:05 --> Language Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Loader Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Controller Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Model Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Model Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Model Class Initialized
DEBUG - 2011-04-21 05:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 05:58:05 --> Database Driver Class Initialized
DEBUG - 2011-04-21 05:58:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 05:58:06 --> Helper loaded: url_helper
DEBUG - 2011-04-21 05:58:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 05:58:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 05:58:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 05:58:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 05:58:06 --> Final output sent to browser
DEBUG - 2011-04-21 05:58:06 --> Total execution time: 0.8699
DEBUG - 2011-04-21 05:58:39 --> Config Class Initialized
DEBUG - 2011-04-21 05:58:39 --> Hooks Class Initialized
DEBUG - 2011-04-21 05:58:39 --> Utf8 Class Initialized
DEBUG - 2011-04-21 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 05:58:39 --> URI Class Initialized
DEBUG - 2011-04-21 05:58:39 --> Router Class Initialized
ERROR - 2011-04-21 05:58:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 07:53:14 --> Config Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Hooks Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Utf8 Class Initialized
DEBUG - 2011-04-21 07:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 07:53:14 --> URI Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Router Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Output Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Input Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 07:53:14 --> Language Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Loader Class Initialized
DEBUG - 2011-04-21 07:53:14 --> Controller Class Initialized
ERROR - 2011-04-21 07:53:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 07:53:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 07:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 07:53:14 --> Model Class Initialized
DEBUG - 2011-04-21 07:53:15 --> Model Class Initialized
DEBUG - 2011-04-21 07:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 07:53:15 --> Database Driver Class Initialized
DEBUG - 2011-04-21 07:53:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 07:53:15 --> Helper loaded: url_helper
DEBUG - 2011-04-21 07:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 07:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 07:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 07:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 07:53:15 --> Final output sent to browser
DEBUG - 2011-04-21 07:53:15 --> Total execution time: 0.4940
DEBUG - 2011-04-21 07:53:17 --> Config Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Hooks Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Utf8 Class Initialized
DEBUG - 2011-04-21 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 07:53:17 --> URI Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Router Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Output Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Input Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 07:53:17 --> Language Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Loader Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Controller Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Model Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Model Class Initialized
DEBUG - 2011-04-21 07:53:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 07:53:17 --> Database Driver Class Initialized
DEBUG - 2011-04-21 07:53:18 --> Final output sent to browser
DEBUG - 2011-04-21 07:53:18 --> Total execution time: 0.7896
DEBUG - 2011-04-21 08:49:29 --> Config Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:49:29 --> URI Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Router Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Output Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Input Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:49:29 --> Language Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Loader Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Controller Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Model Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Model Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Model Class Initialized
DEBUG - 2011-04-21 08:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:49:29 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:49:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 08:49:29 --> Helper loaded: url_helper
DEBUG - 2011-04-21 08:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 08:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 08:49:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 08:49:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 08:49:30 --> Final output sent to browser
DEBUG - 2011-04-21 08:49:30 --> Total execution time: 0.8939
DEBUG - 2011-04-21 08:49:45 --> Config Class Initialized
DEBUG - 2011-04-21 08:49:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:49:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:49:45 --> URI Class Initialized
DEBUG - 2011-04-21 08:49:45 --> Router Class Initialized
ERROR - 2011-04-21 08:49:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 08:52:39 --> Config Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:52:39 --> URI Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Router Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Output Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Input Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:52:39 --> Language Class Initialized
DEBUG - 2011-04-21 08:52:39 --> Loader Class Initialized
DEBUG - 2011-04-21 08:52:40 --> Controller Class Initialized
ERROR - 2011-04-21 08:52:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 08:52:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 08:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:52:40 --> Model Class Initialized
DEBUG - 2011-04-21 08:52:40 --> Model Class Initialized
DEBUG - 2011-04-21 08:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:52:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:52:40 --> Helper loaded: url_helper
DEBUG - 2011-04-21 08:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 08:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 08:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 08:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 08:52:40 --> Final output sent to browser
DEBUG - 2011-04-21 08:52:40 --> Total execution time: 0.7413
DEBUG - 2011-04-21 08:52:42 --> Config Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:52:42 --> URI Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Router Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Output Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Input Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:52:42 --> Language Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Loader Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Controller Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Model Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Model Class Initialized
DEBUG - 2011-04-21 08:52:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:52:42 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:52:43 --> Final output sent to browser
DEBUG - 2011-04-21 08:52:43 --> Total execution time: 1.1876
DEBUG - 2011-04-21 08:52:49 --> Config Class Initialized
DEBUG - 2011-04-21 08:52:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:52:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:52:49 --> URI Class Initialized
DEBUG - 2011-04-21 08:52:49 --> Router Class Initialized
ERROR - 2011-04-21 08:52:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 08:59:01 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:01 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:01 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:01 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:01 --> Router Class Initialized
ERROR - 2011-04-21 08:59:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 08:59:18 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:18 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Router Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Output Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Input Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:59:18 --> Language Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Loader Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Controller Class Initialized
ERROR - 2011-04-21 08:59:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 08:59:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 08:59:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:59:18 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:59:18 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:59:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:59:18 --> Helper loaded: url_helper
DEBUG - 2011-04-21 08:59:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 08:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 08:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 08:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 08:59:18 --> Final output sent to browser
DEBUG - 2011-04-21 08:59:18 --> Total execution time: 0.1869
DEBUG - 2011-04-21 08:59:21 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:21 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Router Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Output Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Input Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:59:21 --> Language Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Loader Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Controller Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:59:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:59:21 --> Final output sent to browser
DEBUG - 2011-04-21 08:59:21 --> Total execution time: 0.7559
DEBUG - 2011-04-21 08:59:28 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:28 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:28 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:28 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:28 --> Router Class Initialized
ERROR - 2011-04-21 08:59:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 08:59:36 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:36 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Router Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Output Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Input Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:59:36 --> Language Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Loader Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Controller Class Initialized
ERROR - 2011-04-21 08:59:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 08:59:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 08:59:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:59:36 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:59:36 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:59:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:59:36 --> Helper loaded: url_helper
DEBUG - 2011-04-21 08:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 08:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 08:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 08:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 08:59:36 --> Final output sent to browser
DEBUG - 2011-04-21 08:59:36 --> Total execution time: 0.0301
DEBUG - 2011-04-21 08:59:40 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:40 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Router Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Output Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Input Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:59:40 --> Language Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Loader Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Controller Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:59:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:59:40 --> Final output sent to browser
DEBUG - 2011-04-21 08:59:40 --> Total execution time: 0.5840
DEBUG - 2011-04-21 08:59:47 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:47 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:47 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:47 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:47 --> Router Class Initialized
ERROR - 2011-04-21 08:59:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 08:59:48 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:48 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Router Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Output Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Input Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:59:48 --> Language Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Loader Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Controller Class Initialized
ERROR - 2011-04-21 08:59:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 08:59:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 08:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:59:48 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:59:48 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 08:59:48 --> Helper loaded: url_helper
DEBUG - 2011-04-21 08:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 08:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 08:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 08:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 08:59:48 --> Final output sent to browser
DEBUG - 2011-04-21 08:59:48 --> Total execution time: 0.0830
DEBUG - 2011-04-21 08:59:49 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:49 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Router Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Output Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Input Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 08:59:49 --> Language Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Loader Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Controller Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Model Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 08:59:49 --> Database Driver Class Initialized
DEBUG - 2011-04-21 08:59:49 --> Final output sent to browser
DEBUG - 2011-04-21 08:59:49 --> Total execution time: 0.5189
DEBUG - 2011-04-21 08:59:55 --> Config Class Initialized
DEBUG - 2011-04-21 08:59:55 --> Hooks Class Initialized
DEBUG - 2011-04-21 08:59:55 --> Utf8 Class Initialized
DEBUG - 2011-04-21 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 08:59:55 --> URI Class Initialized
DEBUG - 2011-04-21 08:59:55 --> Router Class Initialized
ERROR - 2011-04-21 08:59:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:12:02 --> Config Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:12:02 --> URI Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Router Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Output Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Input Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:12:02 --> Language Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Loader Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Controller Class Initialized
ERROR - 2011-04-21 09:12:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:12:02 --> Model Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Model Class Initialized
DEBUG - 2011-04-21 09:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:12:02 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:12:02 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:12:03 --> Final output sent to browser
DEBUG - 2011-04-21 09:12:03 --> Total execution time: 0.5974
DEBUG - 2011-04-21 09:12:04 --> Config Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:12:04 --> URI Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Router Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Output Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Input Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:12:04 --> Language Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Loader Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Controller Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Model Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Model Class Initialized
DEBUG - 2011-04-21 09:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:12:04 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:12:05 --> Final output sent to browser
DEBUG - 2011-04-21 09:12:05 --> Total execution time: 0.5929
DEBUG - 2011-04-21 09:12:07 --> Config Class Initialized
DEBUG - 2011-04-21 09:12:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:12:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:12:07 --> URI Class Initialized
DEBUG - 2011-04-21 09:12:07 --> Router Class Initialized
ERROR - 2011-04-21 09:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:12:08 --> Config Class Initialized
DEBUG - 2011-04-21 09:12:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:12:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:12:08 --> URI Class Initialized
DEBUG - 2011-04-21 09:12:08 --> Router Class Initialized
ERROR - 2011-04-21 09:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:14:29 --> Config Class Initialized
DEBUG - 2011-04-21 09:14:29 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:14:29 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:14:29 --> URI Class Initialized
DEBUG - 2011-04-21 09:14:29 --> Router Class Initialized
ERROR - 2011-04-21 09:14:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 09:15:19 --> Config Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:15:19 --> URI Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Router Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Output Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Input Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:15:19 --> Language Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Loader Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Controller Class Initialized
ERROR - 2011-04-21 09:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:15:19 --> Model Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Model Class Initialized
DEBUG - 2011-04-21 09:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:15:19 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:15:20 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:15:20 --> Final output sent to browser
DEBUG - 2011-04-21 09:15:20 --> Total execution time: 1.5024
DEBUG - 2011-04-21 09:20:10 --> Config Class Initialized
DEBUG - 2011-04-21 09:20:10 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:20:10 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:20:10 --> URI Class Initialized
DEBUG - 2011-04-21 09:20:11 --> Router Class Initialized
DEBUG - 2011-04-21 09:20:11 --> Output Class Initialized
DEBUG - 2011-04-21 09:20:11 --> Input Class Initialized
DEBUG - 2011-04-21 09:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:20:11 --> Language Class Initialized
DEBUG - 2011-04-21 09:20:11 --> Loader Class Initialized
DEBUG - 2011-04-21 09:20:11 --> Controller Class Initialized
ERROR - 2011-04-21 09:20:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:20:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:20:12 --> Model Class Initialized
DEBUG - 2011-04-21 09:20:12 --> Model Class Initialized
DEBUG - 2011-04-21 09:20:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:20:12 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:20:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:20:12 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:20:12 --> Final output sent to browser
DEBUG - 2011-04-21 09:20:12 --> Total execution time: 1.9824
DEBUG - 2011-04-21 09:36:35 --> Config Class Initialized
DEBUG - 2011-04-21 09:36:35 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:36:35 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:36:35 --> URI Class Initialized
DEBUG - 2011-04-21 09:36:35 --> Router Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Output Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Input Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:36:36 --> Language Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Loader Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Controller Class Initialized
ERROR - 2011-04-21 09:36:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:36:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:36:36 --> Model Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Model Class Initialized
DEBUG - 2011-04-21 09:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:36:36 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:36:37 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:36:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:36:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:36:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:36:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:36:37 --> Final output sent to browser
DEBUG - 2011-04-21 09:36:37 --> Total execution time: 3.7376
DEBUG - 2011-04-21 09:36:39 --> Config Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:36:39 --> URI Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Router Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Output Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Input Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:36:39 --> Language Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Loader Class Initialized
DEBUG - 2011-04-21 09:36:39 --> Controller Class Initialized
DEBUG - 2011-04-21 09:36:40 --> Model Class Initialized
DEBUG - 2011-04-21 09:36:40 --> Model Class Initialized
DEBUG - 2011-04-21 09:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:36:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:36:40 --> Final output sent to browser
DEBUG - 2011-04-21 09:36:40 --> Total execution time: 1.0010
DEBUG - 2011-04-21 09:36:42 --> Config Class Initialized
DEBUG - 2011-04-21 09:36:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:36:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:36:42 --> URI Class Initialized
DEBUG - 2011-04-21 09:36:42 --> Router Class Initialized
ERROR - 2011-04-21 09:36:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:37:07 --> Config Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:37:07 --> URI Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Router Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Output Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Input Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:37:07 --> Language Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Loader Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Controller Class Initialized
ERROR - 2011-04-21 09:37:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:37:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:37:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:37:07 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:37:07 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:37:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:37:07 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:37:07 --> Final output sent to browser
DEBUG - 2011-04-21 09:37:07 --> Total execution time: 0.0308
DEBUG - 2011-04-21 09:37:08 --> Config Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:37:08 --> URI Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Router Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Output Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Input Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:37:08 --> Language Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Loader Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Controller Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:37:08 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:37:09 --> Final output sent to browser
DEBUG - 2011-04-21 09:37:09 --> Total execution time: 0.6310
DEBUG - 2011-04-21 09:37:10 --> Config Class Initialized
DEBUG - 2011-04-21 09:37:10 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:37:10 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:37:10 --> URI Class Initialized
DEBUG - 2011-04-21 09:37:10 --> Router Class Initialized
ERROR - 2011-04-21 09:37:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:37:49 --> Config Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:37:49 --> URI Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Router Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Output Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Input Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:37:49 --> Language Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Loader Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Controller Class Initialized
ERROR - 2011-04-21 09:37:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:37:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:37:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:37:49 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:37:49 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:37:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:37:49 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:37:49 --> Final output sent to browser
DEBUG - 2011-04-21 09:37:49 --> Total execution time: 0.0355
DEBUG - 2011-04-21 09:37:51 --> Config Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:37:51 --> URI Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Router Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Output Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Input Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:37:51 --> Language Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Loader Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Controller Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Model Class Initialized
DEBUG - 2011-04-21 09:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:37:51 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:37:52 --> Final output sent to browser
DEBUG - 2011-04-21 09:37:52 --> Total execution time: 0.6352
DEBUG - 2011-04-21 09:37:53 --> Config Class Initialized
DEBUG - 2011-04-21 09:37:53 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:37:53 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:37:53 --> URI Class Initialized
DEBUG - 2011-04-21 09:37:53 --> Router Class Initialized
ERROR - 2011-04-21 09:37:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:38:19 --> Config Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:38:19 --> URI Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Router Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Output Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Input Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:38:19 --> Language Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Loader Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Controller Class Initialized
ERROR - 2011-04-21 09:38:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:38:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:38:19 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:38:19 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:38:19 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:38:19 --> Final output sent to browser
DEBUG - 2011-04-21 09:38:19 --> Total execution time: 0.0355
DEBUG - 2011-04-21 09:38:21 --> Config Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:38:21 --> URI Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Router Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Output Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Input Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:38:21 --> Language Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Loader Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Controller Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:38:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:38:22 --> Final output sent to browser
DEBUG - 2011-04-21 09:38:22 --> Total execution time: 0.5570
DEBUG - 2011-04-21 09:38:23 --> Config Class Initialized
DEBUG - 2011-04-21 09:38:23 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:38:23 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:38:23 --> URI Class Initialized
DEBUG - 2011-04-21 09:38:23 --> Router Class Initialized
ERROR - 2011-04-21 09:38:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:38:42 --> Config Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:38:42 --> URI Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Router Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Output Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Input Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:38:42 --> Language Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Loader Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Controller Class Initialized
ERROR - 2011-04-21 09:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:38:42 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:38:42 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:38:42 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:38:42 --> Final output sent to browser
DEBUG - 2011-04-21 09:38:42 --> Total execution time: 0.0297
DEBUG - 2011-04-21 09:38:43 --> Config Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:38:43 --> URI Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Router Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Output Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Input Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:38:43 --> Language Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Loader Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Controller Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Model Class Initialized
DEBUG - 2011-04-21 09:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:38:43 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:38:44 --> Final output sent to browser
DEBUG - 2011-04-21 09:38:44 --> Total execution time: 0.6022
DEBUG - 2011-04-21 09:38:45 --> Config Class Initialized
DEBUG - 2011-04-21 09:38:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:38:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:38:45 --> URI Class Initialized
DEBUG - 2011-04-21 09:38:45 --> Router Class Initialized
ERROR - 2011-04-21 09:38:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:39:10 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:10 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:10 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Controller Class Initialized
ERROR - 2011-04-21 09:39:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:39:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:10 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:10 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:10 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:39:10 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:10 --> Total execution time: 0.0302
DEBUG - 2011-04-21 09:39:12 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:12 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:12 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Controller Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:12 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:12 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:12 --> Total execution time: 0.5248
DEBUG - 2011-04-21 09:39:14 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:14 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:14 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:14 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:14 --> Router Class Initialized
ERROR - 2011-04-21 09:39:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:39:29 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:29 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:29 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Controller Class Initialized
ERROR - 2011-04-21 09:39:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:39:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:29 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:29 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:29 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:39:29 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:29 --> Total execution time: 0.0400
DEBUG - 2011-04-21 09:39:31 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:31 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:31 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Controller Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:31 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:31 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:31 --> Total execution time: 0.4527
DEBUG - 2011-04-21 09:39:33 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:33 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:33 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:33 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:33 --> Router Class Initialized
ERROR - 2011-04-21 09:39:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:39:36 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:36 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:36 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Controller Class Initialized
ERROR - 2011-04-21 09:39:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:39:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:36 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:36 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:36 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:39:36 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:36 --> Total execution time: 0.0546
DEBUG - 2011-04-21 09:39:37 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:37 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:37 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Controller Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:37 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:38 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Router Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Output Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Input Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:39:38 --> Language Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Loader Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Controller Class Initialized
ERROR - 2011-04-21 09:39:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:39:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:39:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:38 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Model Class Initialized
DEBUG - 2011-04-21 09:39:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:39:38 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:39:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:39:38 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:39:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:39:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:39:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:39:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:39:38 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:38 --> Total execution time: 0.0332
DEBUG - 2011-04-21 09:39:43 --> Final output sent to browser
DEBUG - 2011-04-21 09:39:43 --> Total execution time: 5.6122
DEBUG - 2011-04-21 09:39:44 --> Config Class Initialized
DEBUG - 2011-04-21 09:39:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:39:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:39:44 --> URI Class Initialized
DEBUG - 2011-04-21 09:39:44 --> Router Class Initialized
ERROR - 2011-04-21 09:39:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:40:01 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:01 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:01 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Controller Class Initialized
ERROR - 2011-04-21 09:40:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:40:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:01 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:01 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:01 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:40:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:40:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:40:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:40:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:40:01 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:01 --> Total execution time: 0.0352
DEBUG - 2011-04-21 09:40:03 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:03 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:03 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Controller Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:03 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:04 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:04 --> Total execution time: 0.6151
DEBUG - 2011-04-21 09:40:08 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:08 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:08 --> Router Class Initialized
ERROR - 2011-04-21 09:40:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:40:17 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:17 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:17 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Controller Class Initialized
ERROR - 2011-04-21 09:40:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:40:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:17 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:17 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:17 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:40:17 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:17 --> Total execution time: 0.2343
DEBUG - 2011-04-21 09:40:21 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:21 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:21 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Controller Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:22 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:23 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:23 --> Total execution time: 1.2937
DEBUG - 2011-04-21 09:40:26 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:26 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:26 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:26 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:26 --> Router Class Initialized
ERROR - 2011-04-21 09:40:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:40:49 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:49 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:49 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:49 --> Controller Class Initialized
ERROR - 2011-04-21 09:40:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:40:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:50 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:50 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:50 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:50 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:40:50 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:50 --> Total execution time: 0.1177
DEBUG - 2011-04-21 09:40:51 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:51 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:51 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Controller Class Initialized
ERROR - 2011-04-21 09:40:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:40:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:40:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:51 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:51 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:40:51 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:40:51 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:51 --> Total execution time: 0.1060
DEBUG - 2011-04-21 09:40:53 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:53 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Router Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Output Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Input Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:40:53 --> Language Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Loader Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Controller Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Model Class Initialized
DEBUG - 2011-04-21 09:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:40:53 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:40:54 --> Final output sent to browser
DEBUG - 2011-04-21 09:40:54 --> Total execution time: 1.0470
DEBUG - 2011-04-21 09:40:59 --> Config Class Initialized
DEBUG - 2011-04-21 09:40:59 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:40:59 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:40:59 --> URI Class Initialized
DEBUG - 2011-04-21 09:40:59 --> Router Class Initialized
ERROR - 2011-04-21 09:40:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:41:05 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:05 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:05 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Controller Class Initialized
ERROR - 2011-04-21 09:41:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:41:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:41:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:05 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:05 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:05 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:41:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:41:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:41:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:41:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:41:05 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:05 --> Total execution time: 0.0314
DEBUG - 2011-04-21 09:41:06 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:06 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:06 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Controller Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:06 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:06 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:06 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Controller Class Initialized
ERROR - 2011-04-21 09:41:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:06 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:06 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:06 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:41:06 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:06 --> Total execution time: 0.0345
DEBUG - 2011-04-21 09:41:07 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:07 --> Total execution time: 0.5323
DEBUG - 2011-04-21 09:41:09 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:09 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:09 --> Router Class Initialized
ERROR - 2011-04-21 09:41:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:41:18 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:18 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:18 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Controller Class Initialized
ERROR - 2011-04-21 09:41:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:41:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:41:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:18 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:18 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:18 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:41:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:41:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:41:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:41:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:41:18 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:18 --> Total execution time: 0.0431
DEBUG - 2011-04-21 09:41:20 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:20 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:20 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Controller Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:20 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:20 --> Total execution time: 0.5519
DEBUG - 2011-04-21 09:41:20 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:20 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:20 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Controller Class Initialized
ERROR - 2011-04-21 09:41:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:41:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:41:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:20 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:20 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:21 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:41:21 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:21 --> Total execution time: 0.0352
DEBUG - 2011-04-21 09:41:25 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:25 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:25 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:25 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:25 --> Router Class Initialized
ERROR - 2011-04-21 09:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:41:32 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:32 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:32 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Controller Class Initialized
ERROR - 2011-04-21 09:41:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:41:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:32 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:32 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:41:33 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:41:33 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:33 --> Total execution time: 0.0598
DEBUG - 2011-04-21 09:41:35 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:35 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Router Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Output Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Input Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:41:35 --> Language Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Loader Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Controller Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Model Class Initialized
DEBUG - 2011-04-21 09:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:41:35 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:41:36 --> Final output sent to browser
DEBUG - 2011-04-21 09:41:36 --> Total execution time: 1.1722
DEBUG - 2011-04-21 09:41:38 --> Config Class Initialized
DEBUG - 2011-04-21 09:41:38 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:41:38 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:41:38 --> URI Class Initialized
DEBUG - 2011-04-21 09:41:38 --> Router Class Initialized
ERROR - 2011-04-21 09:41:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:57:01 --> Config Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:57:01 --> URI Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Router Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Output Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Input Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:57:01 --> Language Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Loader Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Controller Class Initialized
ERROR - 2011-04-21 09:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:57:01 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:57:01 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:57:01 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:57:01 --> Final output sent to browser
DEBUG - 2011-04-21 09:57:01 --> Total execution time: 0.6276
DEBUG - 2011-04-21 09:57:02 --> Config Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:57:02 --> URI Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Router Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Output Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Input Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:57:02 --> Language Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Loader Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Controller Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:57:02 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Config Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:57:03 --> URI Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Router Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Output Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Input Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:57:03 --> Language Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Loader Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Controller Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:57:03 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 09:57:03 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:57:03 --> Final output sent to browser
DEBUG - 2011-04-21 09:57:03 --> Total execution time: 0.4017
DEBUG - 2011-04-21 09:57:03 --> Final output sent to browser
DEBUG - 2011-04-21 09:57:03 --> Total execution time: 0.8404
DEBUG - 2011-04-21 09:57:07 --> Config Class Initialized
DEBUG - 2011-04-21 09:57:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:57:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:57:07 --> URI Class Initialized
DEBUG - 2011-04-21 09:57:07 --> Router Class Initialized
ERROR - 2011-04-21 09:57:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 09:57:58 --> Config Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:57:58 --> URI Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Router Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Output Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Input Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:57:58 --> Language Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Loader Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Controller Class Initialized
ERROR - 2011-04-21 09:57:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:57:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:57:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:57:58 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:57:58 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:57:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:57:58 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:57:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:57:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:57:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:57:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:57:58 --> Final output sent to browser
DEBUG - 2011-04-21 09:57:58 --> Total execution time: 0.0381
DEBUG - 2011-04-21 09:57:58 --> Config Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:57:58 --> URI Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Router Class Initialized
DEBUG - 2011-04-21 09:57:58 --> Output Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Input Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:57:59 --> Language Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Loader Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Controller Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Model Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:57:59 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:57:59 --> Final output sent to browser
DEBUG - 2011-04-21 09:57:59 --> Total execution time: 0.6403
DEBUG - 2011-04-21 09:58:15 --> Config Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:58:15 --> URI Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Router Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Output Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Input Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:58:15 --> Language Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Loader Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Controller Class Initialized
ERROR - 2011-04-21 09:58:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:58:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:58:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:58:15 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:58:15 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:58:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:58:15 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:58:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:58:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:58:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:58:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:58:15 --> Final output sent to browser
DEBUG - 2011-04-21 09:58:15 --> Total execution time: 0.0654
DEBUG - 2011-04-21 09:58:17 --> Config Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:58:17 --> URI Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Router Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Output Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Input Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:58:17 --> Language Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Loader Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Controller Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:58:17 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:58:18 --> Final output sent to browser
DEBUG - 2011-04-21 09:58:18 --> Total execution time: 0.5771
DEBUG - 2011-04-21 09:58:41 --> Config Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:58:41 --> URI Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Router Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Output Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Input Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:58:41 --> Language Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Loader Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Controller Class Initialized
ERROR - 2011-04-21 09:58:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 09:58:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 09:58:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:58:41 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:58:41 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:58:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 09:58:41 --> Helper loaded: url_helper
DEBUG - 2011-04-21 09:58:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 09:58:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 09:58:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 09:58:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 09:58:41 --> Final output sent to browser
DEBUG - 2011-04-21 09:58:41 --> Total execution time: 0.0336
DEBUG - 2011-04-21 09:58:42 --> Config Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Hooks Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Utf8 Class Initialized
DEBUG - 2011-04-21 09:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 09:58:42 --> URI Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Router Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Output Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Input Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 09:58:42 --> Language Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Loader Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Controller Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Model Class Initialized
DEBUG - 2011-04-21 09:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 09:58:42 --> Database Driver Class Initialized
DEBUG - 2011-04-21 09:58:43 --> Final output sent to browser
DEBUG - 2011-04-21 09:58:43 --> Total execution time: 0.5173
DEBUG - 2011-04-21 10:05:47 --> Config Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:05:47 --> URI Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Router Class Initialized
ERROR - 2011-04-21 10:05:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 10:05:47 --> Config Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:05:47 --> URI Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Router Class Initialized
DEBUG - 2011-04-21 10:05:47 --> No URI present. Default controller set.
DEBUG - 2011-04-21 10:05:47 --> Output Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Input Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:05:47 --> Language Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Loader Class Initialized
DEBUG - 2011-04-21 10:05:47 --> Controller Class Initialized
DEBUG - 2011-04-21 10:05:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 10:05:47 --> Helper loaded: url_helper
DEBUG - 2011-04-21 10:05:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 10:05:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 10:05:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 10:05:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 10:05:47 --> Final output sent to browser
DEBUG - 2011-04-21 10:05:47 --> Total execution time: 0.1311
DEBUG - 2011-04-21 10:28:47 --> Config Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:28:47 --> URI Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Router Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Output Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Input Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:28:47 --> Language Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Loader Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Controller Class Initialized
ERROR - 2011-04-21 10:28:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 10:28:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 10:28:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 10:28:47 --> Model Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Model Class Initialized
DEBUG - 2011-04-21 10:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 10:28:47 --> Database Driver Class Initialized
DEBUG - 2011-04-21 10:28:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 10:28:47 --> Helper loaded: url_helper
DEBUG - 2011-04-21 10:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 10:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 10:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 10:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 10:28:47 --> Final output sent to browser
DEBUG - 2011-04-21 10:28:47 --> Total execution time: 0.4057
DEBUG - 2011-04-21 10:28:48 --> Config Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:28:48 --> URI Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Router Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Output Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Input Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:28:48 --> Language Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Loader Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Controller Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Model Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Model Class Initialized
DEBUG - 2011-04-21 10:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 10:28:48 --> Database Driver Class Initialized
DEBUG - 2011-04-21 10:28:49 --> Final output sent to browser
DEBUG - 2011-04-21 10:28:49 --> Total execution time: 0.8653
DEBUG - 2011-04-21 10:28:50 --> Config Class Initialized
DEBUG - 2011-04-21 10:28:50 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:28:50 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:28:50 --> URI Class Initialized
DEBUG - 2011-04-21 10:28:50 --> Router Class Initialized
ERROR - 2011-04-21 10:28:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 10:28:50 --> Config Class Initialized
DEBUG - 2011-04-21 10:28:50 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:28:50 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:28:50 --> URI Class Initialized
DEBUG - 2011-04-21 10:28:50 --> Router Class Initialized
ERROR - 2011-04-21 10:28:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 10:28:51 --> Config Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:28:51 --> URI Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Router Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Output Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Input Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:28:51 --> Language Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Loader Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Controller Class Initialized
ERROR - 2011-04-21 10:28:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 10:28:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 10:28:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 10:28:51 --> Model Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Model Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 10:28:51 --> Database Driver Class Initialized
DEBUG - 2011-04-21 10:28:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 10:28:51 --> Helper loaded: url_helper
DEBUG - 2011-04-21 10:28:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 10:28:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 10:28:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 10:28:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 10:28:51 --> Final output sent to browser
DEBUG - 2011-04-21 10:28:51 --> Total execution time: 0.0412
DEBUG - 2011-04-21 10:28:51 --> Config Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:28:51 --> URI Class Initialized
DEBUG - 2011-04-21 10:28:51 --> Router Class Initialized
ERROR - 2011-04-21 10:28:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 10:31:08 --> Config Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:31:08 --> URI Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Router Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Output Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Input Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:31:08 --> Language Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Loader Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Controller Class Initialized
ERROR - 2011-04-21 10:31:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 10:31:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 10:31:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 10:31:08 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 10:31:08 --> Database Driver Class Initialized
DEBUG - 2011-04-21 10:31:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 10:31:08 --> Helper loaded: url_helper
DEBUG - 2011-04-21 10:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 10:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 10:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 10:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 10:31:08 --> Final output sent to browser
DEBUG - 2011-04-21 10:31:08 --> Total execution time: 0.0366
DEBUG - 2011-04-21 10:31:09 --> Config Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:31:09 --> URI Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Router Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Output Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Input Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:31:09 --> Language Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Loader Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Controller Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 10:31:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 10:31:10 --> Final output sent to browser
DEBUG - 2011-04-21 10:31:10 --> Total execution time: 0.7219
DEBUG - 2011-04-21 10:31:13 --> Config Class Initialized
DEBUG - 2011-04-21 10:31:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:31:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:31:13 --> URI Class Initialized
DEBUG - 2011-04-21 10:31:13 --> Router Class Initialized
ERROR - 2011-04-21 10:31:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 10:31:13 --> Config Class Initialized
DEBUG - 2011-04-21 10:31:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:31:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:31:13 --> URI Class Initialized
DEBUG - 2011-04-21 10:31:13 --> Router Class Initialized
ERROR - 2011-04-21 10:31:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 10:31:34 --> Config Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Hooks Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Utf8 Class Initialized
DEBUG - 2011-04-21 10:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 10:31:34 --> URI Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Router Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Output Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Input Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 10:31:34 --> Language Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Loader Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Controller Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Model Class Initialized
DEBUG - 2011-04-21 10:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 10:31:34 --> Database Driver Class Initialized
DEBUG - 2011-04-21 10:31:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 10:31:35 --> Helper loaded: url_helper
DEBUG - 2011-04-21 10:31:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 10:31:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 10:31:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 10:31:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 10:31:35 --> Final output sent to browser
DEBUG - 2011-04-21 10:31:35 --> Total execution time: 0.8505
DEBUG - 2011-04-21 11:11:09 --> Config Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:11:09 --> URI Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Router Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Output Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Input Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 11:11:09 --> Language Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Loader Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Controller Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 11:11:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 11:11:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 11:11:10 --> Helper loaded: url_helper
DEBUG - 2011-04-21 11:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 11:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 11:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 11:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 11:11:10 --> Final output sent to browser
DEBUG - 2011-04-21 11:11:10 --> Total execution time: 0.7405
DEBUG - 2011-04-21 11:11:13 --> Config Class Initialized
DEBUG - 2011-04-21 11:11:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:11:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:11:13 --> URI Class Initialized
DEBUG - 2011-04-21 11:11:13 --> Router Class Initialized
ERROR - 2011-04-21 11:11:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 11:11:21 --> Config Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:11:21 --> URI Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Router Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Output Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Input Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 11:11:21 --> Language Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Loader Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Controller Class Initialized
ERROR - 2011-04-21 11:11:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 11:11:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 11:11:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 11:11:21 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 11:11:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 11:11:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 11:11:21 --> Helper loaded: url_helper
DEBUG - 2011-04-21 11:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 11:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 11:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 11:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 11:11:21 --> Final output sent to browser
DEBUG - 2011-04-21 11:11:21 --> Total execution time: 0.1295
DEBUG - 2011-04-21 11:11:22 --> Config Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:11:22 --> URI Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Router Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Output Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Input Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 11:11:22 --> Language Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Loader Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Controller Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Model Class Initialized
DEBUG - 2011-04-21 11:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 11:11:22 --> Database Driver Class Initialized
DEBUG - 2011-04-21 11:11:23 --> Final output sent to browser
DEBUG - 2011-04-21 11:11:23 --> Total execution time: 1.2155
DEBUG - 2011-04-21 11:11:24 --> Config Class Initialized
DEBUG - 2011-04-21 11:11:24 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:11:24 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:11:24 --> URI Class Initialized
DEBUG - 2011-04-21 11:11:24 --> Router Class Initialized
ERROR - 2011-04-21 11:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 11:27:30 --> Config Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:27:30 --> URI Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Router Class Initialized
DEBUG - 2011-04-21 11:27:30 --> No URI present. Default controller set.
DEBUG - 2011-04-21 11:27:30 --> Output Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Input Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 11:27:30 --> Language Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Loader Class Initialized
DEBUG - 2011-04-21 11:27:30 --> Controller Class Initialized
DEBUG - 2011-04-21 11:27:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 11:27:31 --> Helper loaded: url_helper
DEBUG - 2011-04-21 11:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 11:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 11:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 11:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 11:27:31 --> Final output sent to browser
DEBUG - 2011-04-21 11:27:31 --> Total execution time: 0.0765
DEBUG - 2011-04-21 11:27:31 --> Config Class Initialized
DEBUG - 2011-04-21 11:27:31 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:27:31 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:27:31 --> URI Class Initialized
DEBUG - 2011-04-21 11:27:31 --> Router Class Initialized
ERROR - 2011-04-21 11:27:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 11:43:06 --> Config Class Initialized
DEBUG - 2011-04-21 11:43:06 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:43:06 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:43:06 --> URI Class Initialized
DEBUG - 2011-04-21 11:43:06 --> Router Class Initialized
ERROR - 2011-04-21 11:43:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 11:44:19 --> Config Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:44:19 --> URI Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Router Class Initialized
DEBUG - 2011-04-21 11:44:19 --> No URI present. Default controller set.
DEBUG - 2011-04-21 11:44:19 --> Output Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Input Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 11:44:19 --> Language Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Loader Class Initialized
DEBUG - 2011-04-21 11:44:19 --> Controller Class Initialized
DEBUG - 2011-04-21 11:44:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 11:44:19 --> Helper loaded: url_helper
DEBUG - 2011-04-21 11:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 11:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 11:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 11:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 11:44:19 --> Final output sent to browser
DEBUG - 2011-04-21 11:44:19 --> Total execution time: 0.1151
DEBUG - 2011-04-21 11:59:02 --> Config Class Initialized
DEBUG - 2011-04-21 11:59:02 --> Hooks Class Initialized
DEBUG - 2011-04-21 11:59:02 --> Utf8 Class Initialized
DEBUG - 2011-04-21 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 11:59:02 --> URI Class Initialized
DEBUG - 2011-04-21 11:59:02 --> Router Class Initialized
ERROR - 2011-04-21 11:59:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 12:11:33 --> Config Class Initialized
DEBUG - 2011-04-21 12:11:33 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:11:33 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:11:33 --> URI Class Initialized
DEBUG - 2011-04-21 12:11:33 --> Router Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Output Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Input Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 12:11:34 --> Language Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Loader Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Controller Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Model Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Model Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Model Class Initialized
DEBUG - 2011-04-21 12:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 12:11:34 --> Database Driver Class Initialized
DEBUG - 2011-04-21 12:11:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 12:11:34 --> Helper loaded: url_helper
DEBUG - 2011-04-21 12:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 12:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 12:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 12:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 12:11:34 --> Final output sent to browser
DEBUG - 2011-04-21 12:11:34 --> Total execution time: 0.9599
DEBUG - 2011-04-21 12:11:35 --> Config Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:11:35 --> URI Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Router Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Output Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Input Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 12:11:35 --> Language Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Loader Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Controller Class Initialized
ERROR - 2011-04-21 12:11:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 12:11:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 12:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 12:11:35 --> Model Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Model Class Initialized
DEBUG - 2011-04-21 12:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 12:11:35 --> Database Driver Class Initialized
DEBUG - 2011-04-21 12:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 12:11:36 --> Helper loaded: url_helper
DEBUG - 2011-04-21 12:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 12:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 12:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 12:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 12:11:36 --> Final output sent to browser
DEBUG - 2011-04-21 12:11:36 --> Total execution time: 0.1689
DEBUG - 2011-04-21 12:16:01 --> Config Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:16:01 --> URI Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Router Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Output Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Input Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 12:16:01 --> Language Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Loader Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Controller Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Model Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Model Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Model Class Initialized
DEBUG - 2011-04-21 12:16:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 12:16:01 --> Database Driver Class Initialized
DEBUG - 2011-04-21 12:16:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 12:16:02 --> Helper loaded: url_helper
DEBUG - 2011-04-21 12:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 12:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 12:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 12:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 12:16:02 --> Final output sent to browser
DEBUG - 2011-04-21 12:16:02 --> Total execution time: 0.5286
DEBUG - 2011-04-21 12:16:11 --> Config Class Initialized
DEBUG - 2011-04-21 12:16:11 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:16:11 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:16:11 --> URI Class Initialized
DEBUG - 2011-04-21 12:16:11 --> Router Class Initialized
ERROR - 2011-04-21 12:16:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 12:18:14 --> Config Class Initialized
DEBUG - 2011-04-21 12:18:14 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:18:14 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:18:14 --> URI Class Initialized
DEBUG - 2011-04-21 12:18:14 --> Router Class Initialized
ERROR - 2011-04-21 12:18:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 12:23:49 --> Config Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:23:49 --> URI Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Router Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Output Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Input Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 12:23:49 --> Language Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Loader Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Controller Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Model Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Model Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Model Class Initialized
DEBUG - 2011-04-21 12:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 12:23:49 --> Database Driver Class Initialized
DEBUG - 2011-04-21 12:23:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 12:23:49 --> Helper loaded: url_helper
DEBUG - 2011-04-21 12:23:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 12:23:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 12:23:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 12:23:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 12:23:49 --> Final output sent to browser
DEBUG - 2011-04-21 12:23:49 --> Total execution time: 0.1051
DEBUG - 2011-04-21 12:46:36 --> Config Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:46:36 --> URI Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Router Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Output Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Input Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 12:46:36 --> Language Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Loader Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Controller Class Initialized
ERROR - 2011-04-21 12:46:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 12:46:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 12:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 12:46:36 --> Model Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Model Class Initialized
DEBUG - 2011-04-21 12:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 12:46:36 --> Database Driver Class Initialized
DEBUG - 2011-04-21 12:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 12:46:36 --> Helper loaded: url_helper
DEBUG - 2011-04-21 12:46:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 12:46:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 12:46:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 12:46:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 12:46:36 --> Final output sent to browser
DEBUG - 2011-04-21 12:46:36 --> Total execution time: 0.2343
DEBUG - 2011-04-21 12:46:40 --> Config Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Hooks Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Utf8 Class Initialized
DEBUG - 2011-04-21 12:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 12:46:40 --> URI Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Router Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Output Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Input Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 12:46:40 --> Language Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Loader Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Controller Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Model Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Model Class Initialized
DEBUG - 2011-04-21 12:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 12:46:40 --> Database Driver Class Initialized
DEBUG - 2011-04-21 12:46:41 --> Final output sent to browser
DEBUG - 2011-04-21 12:46:41 --> Total execution time: 0.8701
DEBUG - 2011-04-21 13:37:18 --> Config Class Initialized
DEBUG - 2011-04-21 13:37:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 13:37:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 13:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 13:37:19 --> URI Class Initialized
DEBUG - 2011-04-21 13:37:19 --> Router Class Initialized
DEBUG - 2011-04-21 13:37:20 --> Output Class Initialized
DEBUG - 2011-04-21 13:37:20 --> Input Class Initialized
DEBUG - 2011-04-21 13:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 13:37:20 --> Language Class Initialized
DEBUG - 2011-04-21 13:37:20 --> Loader Class Initialized
DEBUG - 2011-04-21 13:37:20 --> Controller Class Initialized
DEBUG - 2011-04-21 13:37:21 --> Model Class Initialized
DEBUG - 2011-04-21 13:37:21 --> Model Class Initialized
DEBUG - 2011-04-21 13:37:21 --> Model Class Initialized
DEBUG - 2011-04-21 13:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 13:37:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 13:37:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 13:37:25 --> Helper loaded: url_helper
DEBUG - 2011-04-21 13:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 13:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 13:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 13:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 13:37:25 --> Final output sent to browser
DEBUG - 2011-04-21 13:37:25 --> Total execution time: 7.5078
DEBUG - 2011-04-21 13:37:26 --> Config Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Hooks Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Utf8 Class Initialized
DEBUG - 2011-04-21 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 13:37:26 --> URI Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Router Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Output Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Input Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 13:37:26 --> Language Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Loader Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Controller Class Initialized
ERROR - 2011-04-21 13:37:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 13:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 13:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 13:37:26 --> Model Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Model Class Initialized
DEBUG - 2011-04-21 13:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 13:37:26 --> Database Driver Class Initialized
DEBUG - 2011-04-21 13:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 13:37:26 --> Helper loaded: url_helper
DEBUG - 2011-04-21 13:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 13:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 13:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 13:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 13:37:26 --> Final output sent to browser
DEBUG - 2011-04-21 13:37:26 --> Total execution time: 0.2263
DEBUG - 2011-04-21 14:39:08 --> Config Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 14:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 14:39:08 --> URI Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Router Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Output Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Input Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 14:39:08 --> Language Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Loader Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Controller Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Model Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Model Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Model Class Initialized
DEBUG - 2011-04-21 14:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 14:39:08 --> Database Driver Class Initialized
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 14:39:09 --> Helper loaded: url_helper
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 14:39:09 --> Final output sent to browser
DEBUG - 2011-04-21 14:39:09 --> Total execution time: 0.6143
DEBUG - 2011-04-21 14:39:09 --> Config Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Hooks Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Utf8 Class Initialized
DEBUG - 2011-04-21 14:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 14:39:09 --> URI Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Router Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Output Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Input Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 14:39:09 --> Language Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Loader Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Controller Class Initialized
ERROR - 2011-04-21 14:39:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 14:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 14:39:09 --> Model Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Model Class Initialized
DEBUG - 2011-04-21 14:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 14:39:09 --> Database Driver Class Initialized
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 14:39:09 --> Helper loaded: url_helper
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 14:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 14:39:09 --> Final output sent to browser
DEBUG - 2011-04-21 14:39:09 --> Total execution time: 0.1074
DEBUG - 2011-04-21 14:45:55 --> Config Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Hooks Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Utf8 Class Initialized
DEBUG - 2011-04-21 14:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 14:45:55 --> URI Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Router Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Output Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Input Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 14:45:55 --> Language Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Loader Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Controller Class Initialized
ERROR - 2011-04-21 14:45:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 14:45:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 14:45:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 14:45:55 --> Model Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Model Class Initialized
DEBUG - 2011-04-21 14:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 14:45:55 --> Database Driver Class Initialized
DEBUG - 2011-04-21 14:45:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 14:45:55 --> Helper loaded: url_helper
DEBUG - 2011-04-21 14:45:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 14:45:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 14:45:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 14:45:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 14:45:55 --> Final output sent to browser
DEBUG - 2011-04-21 14:45:55 --> Total execution time: 0.1208
DEBUG - 2011-04-21 14:45:56 --> Config Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Hooks Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Utf8 Class Initialized
DEBUG - 2011-04-21 14:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 14:45:56 --> URI Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Router Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Output Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Input Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 14:45:56 --> Language Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Loader Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Controller Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Model Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Model Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 14:45:56 --> Database Driver Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Config Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Hooks Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Utf8 Class Initialized
DEBUG - 2011-04-21 14:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 14:45:56 --> URI Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Router Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Output Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Input Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 14:45:56 --> Language Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Loader Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Controller Class Initialized
ERROR - 2011-04-21 14:45:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 14:45:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 14:45:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 14:45:56 --> Model Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Model Class Initialized
DEBUG - 2011-04-21 14:45:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 14:45:56 --> Database Driver Class Initialized
DEBUG - 2011-04-21 14:45:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 14:45:56 --> Helper loaded: url_helper
DEBUG - 2011-04-21 14:45:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 14:45:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 14:45:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 14:45:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 14:45:56 --> Final output sent to browser
DEBUG - 2011-04-21 14:45:56 --> Total execution time: 0.0288
DEBUG - 2011-04-21 14:45:57 --> Final output sent to browser
DEBUG - 2011-04-21 14:45:57 --> Total execution time: 0.5554
DEBUG - 2011-04-21 14:45:58 --> Config Class Initialized
DEBUG - 2011-04-21 14:45:58 --> Hooks Class Initialized
DEBUG - 2011-04-21 14:45:58 --> Utf8 Class Initialized
DEBUG - 2011-04-21 14:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 14:45:58 --> URI Class Initialized
DEBUG - 2011-04-21 14:45:58 --> Router Class Initialized
ERROR - 2011-04-21 14:45:58 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-04-21 15:13:03 --> Config Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Hooks Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Utf8 Class Initialized
DEBUG - 2011-04-21 15:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 15:13:03 --> URI Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Router Class Initialized
DEBUG - 2011-04-21 15:13:03 --> No URI present. Default controller set.
DEBUG - 2011-04-21 15:13:03 --> Output Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Input Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 15:13:03 --> Language Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Loader Class Initialized
DEBUG - 2011-04-21 15:13:03 --> Controller Class Initialized
DEBUG - 2011-04-21 15:13:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 15:13:03 --> Helper loaded: url_helper
DEBUG - 2011-04-21 15:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 15:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 15:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 15:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 15:13:03 --> Final output sent to browser
DEBUG - 2011-04-21 15:13:03 --> Total execution time: 0.1565
DEBUG - 2011-04-21 16:18:57 --> Config Class Initialized
DEBUG - 2011-04-21 16:18:57 --> Hooks Class Initialized
DEBUG - 2011-04-21 16:18:57 --> Utf8 Class Initialized
DEBUG - 2011-04-21 16:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 16:18:57 --> URI Class Initialized
DEBUG - 2011-04-21 16:18:57 --> Router Class Initialized
ERROR - 2011-04-21 16:18:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 16:18:58 --> Config Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Hooks Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Utf8 Class Initialized
DEBUG - 2011-04-21 16:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 16:18:58 --> URI Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Router Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Output Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Input Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 16:18:58 --> Language Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Loader Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Controller Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Model Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Model Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Model Class Initialized
DEBUG - 2011-04-21 16:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 16:18:58 --> Database Driver Class Initialized
DEBUG - 2011-04-21 16:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 16:18:58 --> Helper loaded: url_helper
DEBUG - 2011-04-21 16:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 16:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 16:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 16:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 16:18:58 --> Final output sent to browser
DEBUG - 2011-04-21 16:18:58 --> Total execution time: 0.7767
DEBUG - 2011-04-21 16:47:54 --> Config Class Initialized
DEBUG - 2011-04-21 16:47:54 --> Hooks Class Initialized
DEBUG - 2011-04-21 16:47:54 --> Utf8 Class Initialized
DEBUG - 2011-04-21 16:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 16:47:54 --> URI Class Initialized
DEBUG - 2011-04-21 16:47:54 --> Router Class Initialized
ERROR - 2011-04-21 16:47:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 16:47:55 --> Config Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-21 16:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 16:47:55 --> URI Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Router Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Output Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Input Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 16:47:55 --> Language Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Loader Class Initialized
DEBUG - 2011-04-21 16:47:55 --> Controller Class Initialized
ERROR - 2011-04-21 16:47:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 16:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 16:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 16:47:55 --> Model Class Initialized
DEBUG - 2011-04-21 16:47:56 --> Model Class Initialized
DEBUG - 2011-04-21 16:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 16:47:56 --> Database Driver Class Initialized
DEBUG - 2011-04-21 16:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 16:47:56 --> Helper loaded: url_helper
DEBUG - 2011-04-21 16:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 16:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 16:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 16:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 16:47:56 --> Final output sent to browser
DEBUG - 2011-04-21 16:47:56 --> Total execution time: 0.2625
DEBUG - 2011-04-21 17:00:45 --> Config Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:00:45 --> URI Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Router Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Output Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Input Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:00:45 --> Language Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Loader Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Controller Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Model Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Model Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Model Class Initialized
DEBUG - 2011-04-21 17:00:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:00:45 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:00:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 17:00:45 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:00:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:00:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:00:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:00:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:00:45 --> Final output sent to browser
DEBUG - 2011-04-21 17:00:45 --> Total execution time: 0.3376
DEBUG - 2011-04-21 17:53:35 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:35 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:35 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Controller Class Initialized
ERROR - 2011-04-21 17:53:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 17:53:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 17:53:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:35 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:35 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:35 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:53:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:53:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:53:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:53:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:53:35 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:35 --> Total execution time: 0.3152
DEBUG - 2011-04-21 17:53:37 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:37 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:37 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Controller Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:37 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:37 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:37 --> Total execution time: 0.6633
DEBUG - 2011-04-21 17:53:38 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:38 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:38 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:38 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:38 --> Router Class Initialized
ERROR - 2011-04-21 17:53:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 17:53:43 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:43 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:43 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Controller Class Initialized
ERROR - 2011-04-21 17:53:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 17:53:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 17:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:43 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:43 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:43 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:53:43 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:43 --> Total execution time: 0.0291
DEBUG - 2011-04-21 17:53:44 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:44 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:44 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Controller Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:44 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:44 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:44 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Controller Class Initialized
ERROR - 2011-04-21 17:53:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 17:53:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 17:53:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:44 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:44 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:44 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:53:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:53:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:53:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:53:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:53:44 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:44 --> Total execution time: 0.0283
DEBUG - 2011-04-21 17:53:44 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:44 --> Total execution time: 0.5945
DEBUG - 2011-04-21 17:53:46 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:46 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:46 --> Router Class Initialized
ERROR - 2011-04-21 17:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 17:53:56 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:56 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:56 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Controller Class Initialized
ERROR - 2011-04-21 17:53:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 17:53:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 17:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:56 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:56 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:53:56 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:53:56 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:56 --> Total execution time: 0.1049
DEBUG - 2011-04-21 17:53:57 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:57 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Router Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Output Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Input Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:53:57 --> Language Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Loader Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Controller Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Model Class Initialized
DEBUG - 2011-04-21 17:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:53:57 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:53:58 --> Final output sent to browser
DEBUG - 2011-04-21 17:53:58 --> Total execution time: 0.9665
DEBUG - 2011-04-21 17:53:59 --> Config Class Initialized
DEBUG - 2011-04-21 17:53:59 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:53:59 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:53:59 --> URI Class Initialized
DEBUG - 2011-04-21 17:53:59 --> Router Class Initialized
ERROR - 2011-04-21 17:53:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 17:54:05 --> Config Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:54:05 --> URI Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Router Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Output Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Input Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:54:05 --> Language Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Loader Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Controller Class Initialized
ERROR - 2011-04-21 17:54:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 17:54:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 17:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:54:05 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:54:05 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:54:05 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:54:05 --> Final output sent to browser
DEBUG - 2011-04-21 17:54:05 --> Total execution time: 0.0377
DEBUG - 2011-04-21 17:54:06 --> Config Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:54:06 --> URI Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Router Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Output Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Input Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:54:06 --> Language Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Loader Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Controller Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:54:06 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:54:07 --> Final output sent to browser
DEBUG - 2011-04-21 17:54:07 --> Total execution time: 0.6363
DEBUG - 2011-04-21 17:54:08 --> Config Class Initialized
DEBUG - 2011-04-21 17:54:08 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:54:08 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:54:08 --> URI Class Initialized
DEBUG - 2011-04-21 17:54:08 --> Router Class Initialized
ERROR - 2011-04-21 17:54:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 17:54:12 --> Config Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:54:12 --> URI Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Router Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Output Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Input Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:54:12 --> Language Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Loader Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Controller Class Initialized
ERROR - 2011-04-21 17:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 17:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 17:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:54:12 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:54:12 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 17:54:12 --> Helper loaded: url_helper
DEBUG - 2011-04-21 17:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 17:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 17:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 17:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 17:54:12 --> Final output sent to browser
DEBUG - 2011-04-21 17:54:12 --> Total execution time: 0.0795
DEBUG - 2011-04-21 17:54:13 --> Config Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:54:13 --> URI Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Router Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Output Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Input Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 17:54:13 --> Language Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Loader Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Controller Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Model Class Initialized
DEBUG - 2011-04-21 17:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 17:54:13 --> Database Driver Class Initialized
DEBUG - 2011-04-21 17:54:14 --> Final output sent to browser
DEBUG - 2011-04-21 17:54:14 --> Total execution time: 0.5501
DEBUG - 2011-04-21 17:54:15 --> Config Class Initialized
DEBUG - 2011-04-21 17:54:15 --> Hooks Class Initialized
DEBUG - 2011-04-21 17:54:15 --> Utf8 Class Initialized
DEBUG - 2011-04-21 17:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 17:54:15 --> URI Class Initialized
DEBUG - 2011-04-21 17:54:15 --> Router Class Initialized
ERROR - 2011-04-21 17:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 19:17:33 --> Config Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Hooks Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Utf8 Class Initialized
DEBUG - 2011-04-21 19:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 19:17:33 --> URI Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Router Class Initialized
DEBUG - 2011-04-21 19:17:33 --> No URI present. Default controller set.
DEBUG - 2011-04-21 19:17:33 --> Output Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Input Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 19:17:33 --> Language Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Loader Class Initialized
DEBUG - 2011-04-21 19:17:33 --> Controller Class Initialized
DEBUG - 2011-04-21 19:17:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 19:17:33 --> Helper loaded: url_helper
DEBUG - 2011-04-21 19:17:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 19:17:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 19:17:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 19:17:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 19:17:33 --> Final output sent to browser
DEBUG - 2011-04-21 19:17:33 --> Total execution time: 0.3365
DEBUG - 2011-04-21 19:17:34 --> Config Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Hooks Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Utf8 Class Initialized
DEBUG - 2011-04-21 19:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 19:17:34 --> URI Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Router Class Initialized
DEBUG - 2011-04-21 19:17:34 --> No URI present. Default controller set.
DEBUG - 2011-04-21 19:17:34 --> Output Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Input Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 19:17:34 --> Language Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Loader Class Initialized
DEBUG - 2011-04-21 19:17:34 --> Controller Class Initialized
DEBUG - 2011-04-21 19:17:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-21 19:17:34 --> Helper loaded: url_helper
DEBUG - 2011-04-21 19:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 19:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 19:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 19:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 19:17:34 --> Final output sent to browser
DEBUG - 2011-04-21 19:17:34 --> Total execution time: 0.0891
DEBUG - 2011-04-21 19:32:13 --> Config Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 19:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 19:32:13 --> URI Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Router Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Output Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Input Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 19:32:13 --> Language Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Loader Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Controller Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Model Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Model Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Model Class Initialized
DEBUG - 2011-04-21 19:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 19:32:13 --> Database Driver Class Initialized
DEBUG - 2011-04-21 19:32:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 19:32:13 --> Helper loaded: url_helper
DEBUG - 2011-04-21 19:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 19:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 19:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 19:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 19:32:13 --> Final output sent to browser
DEBUG - 2011-04-21 19:32:13 --> Total execution time: 0.3550
DEBUG - 2011-04-21 19:32:15 --> Config Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Hooks Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Utf8 Class Initialized
DEBUG - 2011-04-21 19:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 19:32:15 --> URI Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Router Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Output Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Input Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 19:32:15 --> Language Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Loader Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Controller Class Initialized
ERROR - 2011-04-21 19:32:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 19:32:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 19:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 19:32:15 --> Model Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Model Class Initialized
DEBUG - 2011-04-21 19:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 19:32:15 --> Database Driver Class Initialized
DEBUG - 2011-04-21 19:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 19:32:15 --> Helper loaded: url_helper
DEBUG - 2011-04-21 19:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 19:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 19:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 19:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 19:32:15 --> Final output sent to browser
DEBUG - 2011-04-21 19:32:15 --> Total execution time: 0.0916
DEBUG - 2011-04-21 20:15:25 --> Config Class Initialized
DEBUG - 2011-04-21 20:15:25 --> Hooks Class Initialized
DEBUG - 2011-04-21 20:15:26 --> Utf8 Class Initialized
DEBUG - 2011-04-21 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 20:15:26 --> URI Class Initialized
DEBUG - 2011-04-21 20:15:26 --> Router Class Initialized
DEBUG - 2011-04-21 20:15:27 --> Output Class Initialized
DEBUG - 2011-04-21 20:15:28 --> Input Class Initialized
DEBUG - 2011-04-21 20:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 20:15:28 --> Language Class Initialized
DEBUG - 2011-04-21 20:15:28 --> Loader Class Initialized
DEBUG - 2011-04-21 20:15:28 --> Controller Class Initialized
DEBUG - 2011-04-21 20:15:29 --> Model Class Initialized
DEBUG - 2011-04-21 20:15:29 --> Model Class Initialized
DEBUG - 2011-04-21 20:15:29 --> Model Class Initialized
DEBUG - 2011-04-21 20:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 20:15:29 --> Database Driver Class Initialized
DEBUG - 2011-04-21 20:15:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 20:15:30 --> Helper loaded: url_helper
DEBUG - 2011-04-21 20:15:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 20:15:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 20:15:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 20:15:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 20:15:30 --> Final output sent to browser
DEBUG - 2011-04-21 20:15:30 --> Total execution time: 5.3356
DEBUG - 2011-04-21 20:15:31 --> Config Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Hooks Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Utf8 Class Initialized
DEBUG - 2011-04-21 20:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 20:15:31 --> URI Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Router Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Output Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Input Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 20:15:31 --> Language Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Loader Class Initialized
DEBUG - 2011-04-21 20:15:31 --> Controller Class Initialized
ERROR - 2011-04-21 20:15:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 20:15:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 20:15:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 20:15:32 --> Model Class Initialized
DEBUG - 2011-04-21 20:15:32 --> Model Class Initialized
DEBUG - 2011-04-21 20:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 20:15:32 --> Database Driver Class Initialized
DEBUG - 2011-04-21 20:15:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 20:15:32 --> Helper loaded: url_helper
DEBUG - 2011-04-21 20:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 20:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 20:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 20:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 20:15:32 --> Final output sent to browser
DEBUG - 2011-04-21 20:15:32 --> Total execution time: 0.6687
DEBUG - 2011-04-21 21:24:41 --> Config Class Initialized
DEBUG - 2011-04-21 21:24:41 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:24:41 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:24:41 --> URI Class Initialized
DEBUG - 2011-04-21 21:24:41 --> Router Class Initialized
ERROR - 2011-04-21 21:24:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-21 21:39:13 --> Config Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:39:13 --> URI Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Router Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Output Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Input Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:39:13 --> Language Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Loader Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Controller Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Model Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Model Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Model Class Initialized
DEBUG - 2011-04-21 21:39:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:39:13 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:39:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 21:39:14 --> Helper loaded: url_helper
DEBUG - 2011-04-21 21:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 21:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 21:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 21:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 21:39:14 --> Final output sent to browser
DEBUG - 2011-04-21 21:39:14 --> Total execution time: 0.5489
DEBUG - 2011-04-21 21:39:15 --> Config Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:39:15 --> URI Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Router Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Output Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Input Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:39:15 --> Language Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Loader Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Controller Class Initialized
ERROR - 2011-04-21 21:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 21:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 21:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 21:39:15 --> Model Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Model Class Initialized
DEBUG - 2011-04-21 21:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:39:15 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 21:39:15 --> Helper loaded: url_helper
DEBUG - 2011-04-21 21:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 21:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 21:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 21:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 21:39:15 --> Final output sent to browser
DEBUG - 2011-04-21 21:39:15 --> Total execution time: 0.0941
DEBUG - 2011-04-21 21:40:21 --> Config Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:40:21 --> URI Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Router Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Output Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Input Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:40:21 --> Language Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Loader Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Controller Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:40:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 21:40:21 --> Helper loaded: url_helper
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 21:40:21 --> Final output sent to browser
DEBUG - 2011-04-21 21:40:21 --> Total execution time: 0.0592
DEBUG - 2011-04-21 21:40:21 --> Config Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:40:21 --> URI Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Router Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Output Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Input Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:40:21 --> Language Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Loader Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Controller Class Initialized
ERROR - 2011-04-21 21:40:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 21:40:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 21:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Model Class Initialized
DEBUG - 2011-04-21 21:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:40:21 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 21:40:21 --> Helper loaded: url_helper
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 21:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 21:40:21 --> Final output sent to browser
DEBUG - 2011-04-21 21:40:21 --> Total execution time: 0.0318
DEBUG - 2011-04-21 21:41:43 --> Config Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:41:43 --> URI Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Router Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Output Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Input Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:41:43 --> Language Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Loader Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Controller Class Initialized
ERROR - 2011-04-21 21:41:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 21:41:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 21:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 21:41:43 --> Model Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Model Class Initialized
DEBUG - 2011-04-21 21:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:41:43 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 21:41:43 --> Helper loaded: url_helper
DEBUG - 2011-04-21 21:41:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 21:41:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 21:41:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 21:41:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 21:41:43 --> Final output sent to browser
DEBUG - 2011-04-21 21:41:43 --> Total execution time: 0.1096
DEBUG - 2011-04-21 21:41:45 --> Config Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:41:45 --> URI Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Router Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Output Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Input Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:41:45 --> Language Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Loader Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Controller Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Model Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Model Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:41:45 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:41:45 --> Final output sent to browser
DEBUG - 2011-04-21 21:41:45 --> Total execution time: 0.9191
DEBUG - 2011-04-21 21:41:51 --> Config Class Initialized
DEBUG - 2011-04-21 21:41:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:41:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:41:51 --> URI Class Initialized
DEBUG - 2011-04-21 21:41:51 --> Router Class Initialized
ERROR - 2011-04-21 21:41:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 21:46:07 --> Config Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Hooks Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Utf8 Class Initialized
DEBUG - 2011-04-21 21:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 21:46:07 --> URI Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Router Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Output Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Input Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 21:46:07 --> Language Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Loader Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Controller Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Model Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Model Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Model Class Initialized
DEBUG - 2011-04-21 21:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 21:46:07 --> Database Driver Class Initialized
DEBUG - 2011-04-21 21:46:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 21:46:07 --> Helper loaded: url_helper
DEBUG - 2011-04-21 21:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 21:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 21:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 21:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 21:46:07 --> Final output sent to browser
DEBUG - 2011-04-21 21:46:07 --> Total execution time: 0.0711
DEBUG - 2011-04-21 22:36:19 --> Config Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Hooks Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Utf8 Class Initialized
DEBUG - 2011-04-21 22:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 22:36:19 --> URI Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Router Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Output Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Input Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 22:36:19 --> Language Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Loader Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Controller Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Model Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Model Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Model Class Initialized
DEBUG - 2011-04-21 22:36:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 22:36:19 --> Database Driver Class Initialized
DEBUG - 2011-04-21 22:36:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-21 22:36:19 --> Helper loaded: url_helper
DEBUG - 2011-04-21 22:36:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 22:36:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 22:36:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 22:36:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 22:36:19 --> Final output sent to browser
DEBUG - 2011-04-21 22:36:19 --> Total execution time: 0.5324
DEBUG - 2011-04-21 22:36:23 --> Config Class Initialized
DEBUG - 2011-04-21 22:36:23 --> Hooks Class Initialized
DEBUG - 2011-04-21 22:36:23 --> Utf8 Class Initialized
DEBUG - 2011-04-21 22:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 22:36:23 --> URI Class Initialized
DEBUG - 2011-04-21 22:36:23 --> Router Class Initialized
ERROR - 2011-04-21 22:36:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-21 23:32:45 --> Config Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Hooks Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Utf8 Class Initialized
DEBUG - 2011-04-21 23:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 23:32:45 --> URI Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Router Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Output Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Input Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 23:32:45 --> Language Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Loader Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Controller Class Initialized
ERROR - 2011-04-21 23:32:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-21 23:32:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-21 23:32:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 23:32:45 --> Model Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Model Class Initialized
DEBUG - 2011-04-21 23:32:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 23:32:46 --> Database Driver Class Initialized
DEBUG - 2011-04-21 23:32:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-21 23:32:46 --> Helper loaded: url_helper
DEBUG - 2011-04-21 23:32:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-21 23:32:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-21 23:32:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-21 23:32:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-21 23:32:46 --> Final output sent to browser
DEBUG - 2011-04-21 23:32:46 --> Total execution time: 0.9828
DEBUG - 2011-04-21 23:32:48 --> Config Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Hooks Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Utf8 Class Initialized
DEBUG - 2011-04-21 23:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 23:32:48 --> URI Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Router Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Output Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Input Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-21 23:32:48 --> Language Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Loader Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Controller Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Model Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Model Class Initialized
DEBUG - 2011-04-21 23:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-21 23:32:48 --> Database Driver Class Initialized
DEBUG - 2011-04-21 23:32:49 --> Final output sent to browser
DEBUG - 2011-04-21 23:32:49 --> Total execution time: 1.6314
DEBUG - 2011-04-21 23:32:51 --> Config Class Initialized
DEBUG - 2011-04-21 23:32:51 --> Hooks Class Initialized
DEBUG - 2011-04-21 23:32:51 --> Utf8 Class Initialized
DEBUG - 2011-04-21 23:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-21 23:32:51 --> URI Class Initialized
DEBUG - 2011-04-21 23:32:51 --> Router Class Initialized
ERROR - 2011-04-21 23:32:51 --> 404 Page Not Found --> favicon.ico

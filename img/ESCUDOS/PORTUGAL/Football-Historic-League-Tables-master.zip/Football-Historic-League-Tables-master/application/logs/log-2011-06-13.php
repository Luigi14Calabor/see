<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-13 01:09:08 --> Config Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:09:08 --> URI Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Router Class Initialized
ERROR - 2011-06-13 01:09:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 01:09:08 --> Config Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:09:08 --> URI Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Router Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Output Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Input Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:09:08 --> Language Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Loader Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Controller Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Model Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Model Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Model Class Initialized
DEBUG - 2011-06-13 01:09:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 01:09:08 --> Database Driver Class Initialized
DEBUG - 2011-06-13 01:09:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 01:09:08 --> Helper loaded: url_helper
DEBUG - 2011-06-13 01:09:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 01:09:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 01:09:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 01:09:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 01:09:08 --> Final output sent to browser
DEBUG - 2011-06-13 01:09:08 --> Total execution time: 0.4852
DEBUG - 2011-06-13 01:09:39 --> Config Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:09:39 --> URI Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Router Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Output Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Input Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:09:39 --> Language Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Loader Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Controller Class Initialized
ERROR - 2011-06-13 01:09:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 01:09:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 01:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 01:09:39 --> Model Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Model Class Initialized
DEBUG - 2011-06-13 01:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 01:09:39 --> Database Driver Class Initialized
DEBUG - 2011-06-13 01:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 01:09:39 --> Helper loaded: url_helper
DEBUG - 2011-06-13 01:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 01:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 01:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 01:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 01:09:39 --> Final output sent to browser
DEBUG - 2011-06-13 01:09:39 --> Total execution time: 0.0891
DEBUG - 2011-06-13 01:18:30 --> Config Class Initialized
DEBUG - 2011-06-13 01:18:30 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:18:30 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:18:30 --> URI Class Initialized
DEBUG - 2011-06-13 01:18:30 --> Router Class Initialized
ERROR - 2011-06-13 01:18:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 01:19:06 --> Config Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:19:06 --> URI Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Router Class Initialized
DEBUG - 2011-06-13 01:19:06 --> No URI present. Default controller set.
DEBUG - 2011-06-13 01:19:06 --> Output Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Input Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:19:06 --> Language Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Loader Class Initialized
DEBUG - 2011-06-13 01:19:06 --> Controller Class Initialized
DEBUG - 2011-06-13 01:19:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-13 01:19:06 --> Helper loaded: url_helper
DEBUG - 2011-06-13 01:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 01:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 01:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 01:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 01:19:06 --> Final output sent to browser
DEBUG - 2011-06-13 01:19:06 --> Total execution time: 0.0554
DEBUG - 2011-06-13 01:34:10 --> Config Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:34:10 --> URI Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Router Class Initialized
ERROR - 2011-06-13 01:34:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 01:34:10 --> Config Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:34:10 --> URI Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Router Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Output Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Input Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:34:10 --> Language Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Loader Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Controller Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Model Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Model Class Initialized
DEBUG - 2011-06-13 01:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 01:34:10 --> Database Driver Class Initialized
DEBUG - 2011-06-13 01:34:13 --> Final output sent to browser
DEBUG - 2011-06-13 01:34:13 --> Total execution time: 2.5874
DEBUG - 2011-06-13 01:56:36 --> Config Class Initialized
DEBUG - 2011-06-13 01:56:36 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:56:36 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:56:36 --> URI Class Initialized
DEBUG - 2011-06-13 01:56:36 --> Router Class Initialized
DEBUG - 2011-06-13 01:56:36 --> Output Class Initialized
DEBUG - 2011-06-13 01:56:36 --> Input Class Initialized
DEBUG - 2011-06-13 01:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:56:36 --> Language Class Initialized
DEBUG - 2011-06-13 01:56:37 --> Loader Class Initialized
DEBUG - 2011-06-13 01:56:37 --> Controller Class Initialized
ERROR - 2011-06-13 01:56:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 01:56:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 01:56:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 01:56:37 --> Model Class Initialized
DEBUG - 2011-06-13 01:56:37 --> Model Class Initialized
DEBUG - 2011-06-13 01:56:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 01:56:37 --> Database Driver Class Initialized
DEBUG - 2011-06-13 01:56:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 01:56:39 --> Helper loaded: url_helper
DEBUG - 2011-06-13 01:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 01:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 01:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 01:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 01:56:40 --> Final output sent to browser
DEBUG - 2011-06-13 01:56:40 --> Total execution time: 3.6967
DEBUG - 2011-06-13 01:56:41 --> Config Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:56:41 --> URI Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Router Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Output Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Input Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:56:41 --> Language Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Loader Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Controller Class Initialized
DEBUG - 2011-06-13 01:56:41 --> Model Class Initialized
DEBUG - 2011-06-13 01:56:42 --> Model Class Initialized
DEBUG - 2011-06-13 01:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 01:56:42 --> Database Driver Class Initialized
DEBUG - 2011-06-13 01:56:43 --> Final output sent to browser
DEBUG - 2011-06-13 01:56:43 --> Total execution time: 1.6574
DEBUG - 2011-06-13 01:57:10 --> Config Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Hooks Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Utf8 Class Initialized
DEBUG - 2011-06-13 01:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 01:57:10 --> URI Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Router Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Output Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Input Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 01:57:10 --> Language Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Loader Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Controller Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Model Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Model Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Model Class Initialized
DEBUG - 2011-06-13 01:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 01:57:10 --> Database Driver Class Initialized
DEBUG - 2011-06-13 01:57:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 01:57:13 --> Helper loaded: url_helper
DEBUG - 2011-06-13 01:57:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 01:57:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 01:57:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 01:57:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 01:57:13 --> Final output sent to browser
DEBUG - 2011-06-13 01:57:13 --> Total execution time: 2.5943
DEBUG - 2011-06-13 03:04:16 --> Config Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Hooks Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Utf8 Class Initialized
DEBUG - 2011-06-13 03:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 03:04:16 --> URI Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Router Class Initialized
DEBUG - 2011-06-13 03:04:16 --> No URI present. Default controller set.
DEBUG - 2011-06-13 03:04:16 --> Output Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Input Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 03:04:16 --> Language Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Loader Class Initialized
DEBUG - 2011-06-13 03:04:16 --> Controller Class Initialized
DEBUG - 2011-06-13 03:04:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-13 03:04:16 --> Helper loaded: url_helper
DEBUG - 2011-06-13 03:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 03:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 03:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 03:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 03:04:16 --> Final output sent to browser
DEBUG - 2011-06-13 03:04:16 --> Total execution time: 0.3485
DEBUG - 2011-06-13 05:08:36 --> Config Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Hooks Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Utf8 Class Initialized
DEBUG - 2011-06-13 05:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 05:08:36 --> URI Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Router Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Output Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Input Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 05:08:36 --> Language Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Loader Class Initialized
DEBUG - 2011-06-13 05:08:36 --> Controller Class Initialized
ERROR - 2011-06-13 05:08:36 --> 404 Page Not Found --> snakes/image%3Fcode%3Deng12010
DEBUG - 2011-06-13 05:24:41 --> Config Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 05:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 05:24:41 --> URI Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Router Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Output Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Input Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 05:24:41 --> Language Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Loader Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Controller Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Model Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Model Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Model Class Initialized
DEBUG - 2011-06-13 05:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 05:24:41 --> Database Driver Class Initialized
DEBUG - 2011-06-13 05:24:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 05:24:42 --> Helper loaded: url_helper
DEBUG - 2011-06-13 05:24:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 05:24:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 05:24:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 05:24:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 05:24:42 --> Final output sent to browser
DEBUG - 2011-06-13 05:24:42 --> Total execution time: 1.3309
DEBUG - 2011-06-13 07:07:09 --> Config Class Initialized
DEBUG - 2011-06-13 07:07:09 --> Hooks Class Initialized
DEBUG - 2011-06-13 07:07:09 --> Utf8 Class Initialized
DEBUG - 2011-06-13 07:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 07:07:09 --> URI Class Initialized
DEBUG - 2011-06-13 07:07:09 --> Router Class Initialized
ERROR - 2011-06-13 07:07:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 09:01:37 --> Config Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Hooks Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Utf8 Class Initialized
DEBUG - 2011-06-13 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 09:01:37 --> URI Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Router Class Initialized
DEBUG - 2011-06-13 09:01:37 --> No URI present. Default controller set.
DEBUG - 2011-06-13 09:01:37 --> Output Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Input Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 09:01:37 --> Language Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Loader Class Initialized
DEBUG - 2011-06-13 09:01:37 --> Controller Class Initialized
DEBUG - 2011-06-13 09:01:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-13 09:01:37 --> Helper loaded: url_helper
DEBUG - 2011-06-13 09:01:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 09:01:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 09:01:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 09:01:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 09:01:37 --> Final output sent to browser
DEBUG - 2011-06-13 09:01:37 --> Total execution time: 0.4391
DEBUG - 2011-06-13 09:30:13 --> Config Class Initialized
DEBUG - 2011-06-13 09:30:13 --> Hooks Class Initialized
DEBUG - 2011-06-13 09:30:13 --> Utf8 Class Initialized
DEBUG - 2011-06-13 09:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 09:30:13 --> URI Class Initialized
DEBUG - 2011-06-13 09:30:13 --> Router Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Output Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Input Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 09:30:14 --> Language Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Loader Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Controller Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Model Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Model Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Model Class Initialized
DEBUG - 2011-06-13 09:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 09:30:14 --> Database Driver Class Initialized
DEBUG - 2011-06-13 09:30:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 09:30:15 --> Helper loaded: url_helper
DEBUG - 2011-06-13 09:30:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 09:30:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 09:30:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 09:30:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 09:30:15 --> Final output sent to browser
DEBUG - 2011-06-13 09:30:15 --> Total execution time: 1.6181
DEBUG - 2011-06-13 09:30:16 --> Config Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Hooks Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Utf8 Class Initialized
DEBUG - 2011-06-13 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 09:30:16 --> URI Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Router Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Output Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Input Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 09:30:16 --> Language Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Loader Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Controller Class Initialized
ERROR - 2011-06-13 09:30:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 09:30:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 09:30:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 09:30:16 --> Model Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Model Class Initialized
DEBUG - 2011-06-13 09:30:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 09:30:16 --> Database Driver Class Initialized
DEBUG - 2011-06-13 09:30:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 09:30:16 --> Helper loaded: url_helper
DEBUG - 2011-06-13 09:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 09:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 09:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 09:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 09:30:16 --> Final output sent to browser
DEBUG - 2011-06-13 09:30:16 --> Total execution time: 0.1301
DEBUG - 2011-06-13 09:58:23 --> Config Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Hooks Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Utf8 Class Initialized
DEBUG - 2011-06-13 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 09:58:23 --> URI Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Router Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Output Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Input Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 09:58:23 --> Language Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Loader Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Controller Class Initialized
ERROR - 2011-06-13 09:58:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 09:58:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 09:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 09:58:23 --> Model Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Model Class Initialized
DEBUG - 2011-06-13 09:58:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 09:58:23 --> Database Driver Class Initialized
DEBUG - 2011-06-13 09:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 09:58:23 --> Helper loaded: url_helper
DEBUG - 2011-06-13 09:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 09:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 09:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 09:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 09:58:23 --> Final output sent to browser
DEBUG - 2011-06-13 09:58:23 --> Total execution time: 0.5067
DEBUG - 2011-06-13 09:58:39 --> Config Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Hooks Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Utf8 Class Initialized
DEBUG - 2011-06-13 09:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 09:58:39 --> URI Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Router Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Output Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Input Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 09:58:39 --> Language Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Loader Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Controller Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Model Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Model Class Initialized
DEBUG - 2011-06-13 09:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 09:58:39 --> Database Driver Class Initialized
DEBUG - 2011-06-13 09:58:40 --> Final output sent to browser
DEBUG - 2011-06-13 09:58:40 --> Total execution time: 0.7174
DEBUG - 2011-06-13 09:58:41 --> Config Class Initialized
DEBUG - 2011-06-13 09:58:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 09:58:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 09:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 09:58:41 --> URI Class Initialized
DEBUG - 2011-06-13 09:58:41 --> Router Class Initialized
ERROR - 2011-06-13 09:58:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 10:27:28 --> Config Class Initialized
DEBUG - 2011-06-13 10:27:28 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:27:28 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:27:28 --> URI Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Router Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Output Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Input Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:27:29 --> Language Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Loader Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Controller Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:27:29 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:27:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 10:27:29 --> Helper loaded: url_helper
DEBUG - 2011-06-13 10:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 10:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 10:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 10:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 10:27:29 --> Final output sent to browser
DEBUG - 2011-06-13 10:27:29 --> Total execution time: 0.7204
DEBUG - 2011-06-13 10:27:32 --> Config Class Initialized
DEBUG - 2011-06-13 10:27:32 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:27:32 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:27:32 --> URI Class Initialized
DEBUG - 2011-06-13 10:27:32 --> Router Class Initialized
ERROR - 2011-06-13 10:27:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 10:27:32 --> Config Class Initialized
DEBUG - 2011-06-13 10:27:32 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:27:32 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:27:32 --> URI Class Initialized
DEBUG - 2011-06-13 10:27:32 --> Router Class Initialized
ERROR - 2011-06-13 10:27:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 10:27:39 --> Config Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:27:39 --> URI Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Router Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Output Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Input Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:27:39 --> Language Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Loader Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Controller Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:27:39 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:27:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 10:27:39 --> Helper loaded: url_helper
DEBUG - 2011-06-13 10:27:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 10:27:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 10:27:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 10:27:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 10:27:39 --> Final output sent to browser
DEBUG - 2011-06-13 10:27:39 --> Total execution time: 0.2736
DEBUG - 2011-06-13 10:27:41 --> Config Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:27:41 --> URI Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Router Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Output Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Input Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:27:41 --> Language Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Loader Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Controller Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Model Class Initialized
DEBUG - 2011-06-13 10:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:27:41 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:27:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 10:27:41 --> Helper loaded: url_helper
DEBUG - 2011-06-13 10:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 10:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 10:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 10:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 10:27:41 --> Final output sent to browser
DEBUG - 2011-06-13 10:27:41 --> Total execution time: 0.1012
DEBUG - 2011-06-13 10:28:02 --> Config Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:28:02 --> URI Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Router Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Output Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Input Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:28:02 --> Language Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Loader Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Controller Class Initialized
ERROR - 2011-06-13 10:28:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 10:28:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 10:28:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 10:28:02 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:28:02 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:28:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 10:28:02 --> Helper loaded: url_helper
DEBUG - 2011-06-13 10:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 10:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 10:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 10:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 10:28:02 --> Final output sent to browser
DEBUG - 2011-06-13 10:28:02 --> Total execution time: 0.1102
DEBUG - 2011-06-13 10:28:03 --> Config Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:28:03 --> URI Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Router Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Output Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Input Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:28:03 --> Language Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Loader Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Controller Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:28:03 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:28:03 --> Final output sent to browser
DEBUG - 2011-06-13 10:28:03 --> Total execution time: 0.7070
DEBUG - 2011-06-13 10:28:16 --> Config Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:28:16 --> URI Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Router Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Output Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Input Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:28:16 --> Language Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Loader Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Controller Class Initialized
ERROR - 2011-06-13 10:28:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 10:28:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 10:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 10:28:16 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:28:16 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 10:28:16 --> Helper loaded: url_helper
DEBUG - 2011-06-13 10:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 10:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 10:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 10:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 10:28:16 --> Final output sent to browser
DEBUG - 2011-06-13 10:28:16 --> Total execution time: 0.0510
DEBUG - 2011-06-13 10:28:17 --> Config Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Hooks Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Utf8 Class Initialized
DEBUG - 2011-06-13 10:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 10:28:17 --> URI Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Router Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Output Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Input Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 10:28:17 --> Language Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Loader Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Controller Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Model Class Initialized
DEBUG - 2011-06-13 10:28:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 10:28:17 --> Database Driver Class Initialized
DEBUG - 2011-06-13 10:28:18 --> Final output sent to browser
DEBUG - 2011-06-13 10:28:18 --> Total execution time: 0.8240
DEBUG - 2011-06-13 12:12:22 --> Config Class Initialized
DEBUG - 2011-06-13 12:12:22 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:12:22 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:12:22 --> URI Class Initialized
DEBUG - 2011-06-13 12:12:22 --> Router Class Initialized
ERROR - 2011-06-13 12:12:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 12:12:23 --> Config Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:12:23 --> URI Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Router Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Output Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Input Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 12:12:23 --> Language Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Loader Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Controller Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Model Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Model Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Model Class Initialized
DEBUG - 2011-06-13 12:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 12:12:23 --> Database Driver Class Initialized
DEBUG - 2011-06-13 12:12:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 12:12:24 --> Helper loaded: url_helper
DEBUG - 2011-06-13 12:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 12:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 12:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 12:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 12:12:24 --> Final output sent to browser
DEBUG - 2011-06-13 12:12:24 --> Total execution time: 0.8563
DEBUG - 2011-06-13 12:12:54 --> Config Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:12:54 --> URI Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Router Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Output Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Input Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 12:12:54 --> Language Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Loader Class Initialized
DEBUG - 2011-06-13 12:12:54 --> Controller Class Initialized
ERROR - 2011-06-13 12:12:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 12:12:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 12:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 12:12:55 --> Model Class Initialized
DEBUG - 2011-06-13 12:12:55 --> Model Class Initialized
DEBUG - 2011-06-13 12:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 12:12:55 --> Database Driver Class Initialized
DEBUG - 2011-06-13 12:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 12:12:55 --> Helper loaded: url_helper
DEBUG - 2011-06-13 12:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 12:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 12:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 12:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 12:12:55 --> Final output sent to browser
DEBUG - 2011-06-13 12:12:55 --> Total execution time: 0.1973
DEBUG - 2011-06-13 12:24:51 --> Config Class Initialized
DEBUG - 2011-06-13 12:24:51 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:24:52 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:24:52 --> URI Class Initialized
DEBUG - 2011-06-13 12:24:52 --> Router Class Initialized
DEBUG - 2011-06-13 12:24:53 --> Output Class Initialized
DEBUG - 2011-06-13 12:24:53 --> Input Class Initialized
DEBUG - 2011-06-13 12:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 12:24:53 --> Language Class Initialized
DEBUG - 2011-06-13 12:24:53 --> Loader Class Initialized
DEBUG - 2011-06-13 12:24:53 --> Controller Class Initialized
ERROR - 2011-06-13 12:24:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 12:24:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 12:24:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 12:24:53 --> Model Class Initialized
DEBUG - 2011-06-13 12:24:53 --> Model Class Initialized
DEBUG - 2011-06-13 12:24:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 12:24:54 --> Database Driver Class Initialized
DEBUG - 2011-06-13 12:24:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 12:24:54 --> Helper loaded: url_helper
DEBUG - 2011-06-13 12:24:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 12:24:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 12:24:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 12:24:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 12:24:54 --> Final output sent to browser
DEBUG - 2011-06-13 12:24:54 --> Total execution time: 4.2329
DEBUG - 2011-06-13 12:24:56 --> Config Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:24:56 --> URI Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Router Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Output Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Input Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 12:24:56 --> Language Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Loader Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Controller Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Model Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Model Class Initialized
DEBUG - 2011-06-13 12:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 12:24:56 --> Database Driver Class Initialized
DEBUG - 2011-06-13 12:24:57 --> Final output sent to browser
DEBUG - 2011-06-13 12:24:57 --> Total execution time: 0.7161
DEBUG - 2011-06-13 12:40:51 --> Config Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:40:51 --> URI Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Router Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Output Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Input Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 12:40:51 --> Language Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Loader Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Controller Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Model Class Initialized
DEBUG - 2011-06-13 12:40:51 --> Model Class Initialized
DEBUG - 2011-06-13 12:40:52 --> Model Class Initialized
DEBUG - 2011-06-13 12:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 12:40:52 --> Database Driver Class Initialized
DEBUG - 2011-06-13 12:40:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 12:40:52 --> Helper loaded: url_helper
DEBUG - 2011-06-13 12:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 12:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 12:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 12:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 12:40:52 --> Final output sent to browser
DEBUG - 2011-06-13 12:40:52 --> Total execution time: 1.1901
DEBUG - 2011-06-13 12:40:53 --> Config Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Hooks Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Utf8 Class Initialized
DEBUG - 2011-06-13 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 12:40:53 --> URI Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Router Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Output Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Input Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 12:40:53 --> Language Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Loader Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Controller Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Model Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Model Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Model Class Initialized
DEBUG - 2011-06-13 12:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 12:40:53 --> Database Driver Class Initialized
DEBUG - 2011-06-13 12:40:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 12:40:53 --> Helper loaded: url_helper
DEBUG - 2011-06-13 12:40:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 12:40:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 12:40:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 12:40:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 12:40:53 --> Final output sent to browser
DEBUG - 2011-06-13 12:40:53 --> Total execution time: 0.0525
DEBUG - 2011-06-13 13:47:30 --> Config Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:47:30 --> URI Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Router Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Output Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Input Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 13:47:30 --> Language Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Loader Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Controller Class Initialized
ERROR - 2011-06-13 13:47:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 13:47:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 13:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 13:47:30 --> Model Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Model Class Initialized
DEBUG - 2011-06-13 13:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 13:47:30 --> Database Driver Class Initialized
DEBUG - 2011-06-13 13:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 13:47:30 --> Helper loaded: url_helper
DEBUG - 2011-06-13 13:47:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 13:47:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 13:47:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 13:47:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 13:47:30 --> Final output sent to browser
DEBUG - 2011-06-13 13:47:30 --> Total execution time: 0.3949
DEBUG - 2011-06-13 13:48:03 --> Config Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:48:03 --> URI Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Router Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Output Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Input Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 13:48:03 --> Language Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Loader Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Controller Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Model Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Model Class Initialized
DEBUG - 2011-06-13 13:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 13:48:03 --> Database Driver Class Initialized
DEBUG - 2011-06-13 13:48:04 --> Final output sent to browser
DEBUG - 2011-06-13 13:48:04 --> Total execution time: 1.6923
DEBUG - 2011-06-13 13:48:31 --> Config Class Initialized
DEBUG - 2011-06-13 13:48:31 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:48:31 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:48:31 --> URI Class Initialized
DEBUG - 2011-06-13 13:48:31 --> Router Class Initialized
ERROR - 2011-06-13 13:48:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 13:48:35 --> Config Class Initialized
DEBUG - 2011-06-13 13:48:35 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:48:35 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:48:35 --> URI Class Initialized
DEBUG - 2011-06-13 13:48:35 --> Router Class Initialized
ERROR - 2011-06-13 13:48:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 13:49:10 --> Config Class Initialized
DEBUG - 2011-06-13 13:49:10 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:49:10 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:49:10 --> URI Class Initialized
DEBUG - 2011-06-13 13:49:10 --> Router Class Initialized
ERROR - 2011-06-13 13:49:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 13:49:18 --> Config Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:49:18 --> URI Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Router Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Output Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Input Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 13:49:18 --> Language Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Loader Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Controller Class Initialized
ERROR - 2011-06-13 13:49:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 13:49:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 13:49:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 13:49:18 --> Model Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Model Class Initialized
DEBUG - 2011-06-13 13:49:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 13:49:18 --> Database Driver Class Initialized
DEBUG - 2011-06-13 13:49:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 13:49:19 --> Helper loaded: url_helper
DEBUG - 2011-06-13 13:49:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 13:49:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 13:49:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 13:49:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 13:49:19 --> Final output sent to browser
DEBUG - 2011-06-13 13:49:19 --> Total execution time: 0.0974
DEBUG - 2011-06-13 13:49:20 --> Config Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Hooks Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Utf8 Class Initialized
DEBUG - 2011-06-13 13:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 13:49:20 --> URI Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Router Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Output Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Input Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 13:49:20 --> Language Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Loader Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Controller Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Model Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Model Class Initialized
DEBUG - 2011-06-13 13:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 13:49:20 --> Database Driver Class Initialized
DEBUG - 2011-06-13 13:49:22 --> Final output sent to browser
DEBUG - 2011-06-13 13:49:22 --> Total execution time: 1.1691
DEBUG - 2011-06-13 14:06:20 --> Config Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Hooks Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Utf8 Class Initialized
DEBUG - 2011-06-13 14:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 14:06:20 --> URI Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Router Class Initialized
DEBUG - 2011-06-13 14:06:20 --> No URI present. Default controller set.
DEBUG - 2011-06-13 14:06:20 --> Output Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Input Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 14:06:20 --> Language Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Loader Class Initialized
DEBUG - 2011-06-13 14:06:20 --> Controller Class Initialized
DEBUG - 2011-06-13 14:06:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-13 14:06:20 --> Helper loaded: url_helper
DEBUG - 2011-06-13 14:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 14:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 14:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 14:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 14:06:20 --> Final output sent to browser
DEBUG - 2011-06-13 14:06:20 --> Total execution time: 0.1881
DEBUG - 2011-06-13 14:56:08 --> Config Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Hooks Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Utf8 Class Initialized
DEBUG - 2011-06-13 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 14:56:08 --> URI Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Router Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Output Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Input Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 14:56:08 --> Language Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Loader Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Controller Class Initialized
ERROR - 2011-06-13 14:56:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 14:56:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 14:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 14:56:08 --> Model Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Model Class Initialized
DEBUG - 2011-06-13 14:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 14:56:08 --> Database Driver Class Initialized
DEBUG - 2011-06-13 14:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 14:56:08 --> Helper loaded: url_helper
DEBUG - 2011-06-13 14:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 14:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 14:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 14:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 14:56:08 --> Final output sent to browser
DEBUG - 2011-06-13 14:56:08 --> Total execution time: 0.4215
DEBUG - 2011-06-13 15:24:01 --> Config Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Hooks Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Utf8 Class Initialized
DEBUG - 2011-06-13 15:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 15:24:01 --> URI Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Router Class Initialized
ERROR - 2011-06-13 15:24:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 15:24:01 --> Config Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Hooks Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Utf8 Class Initialized
DEBUG - 2011-06-13 15:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 15:24:01 --> URI Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Router Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Output Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Input Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 15:24:01 --> Language Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Loader Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Controller Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Model Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Model Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Model Class Initialized
DEBUG - 2011-06-13 15:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 15:24:02 --> Database Driver Class Initialized
DEBUG - 2011-06-13 15:24:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 15:24:02 --> Helper loaded: url_helper
DEBUG - 2011-06-13 15:24:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 15:24:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 15:24:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 15:24:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 15:24:02 --> Final output sent to browser
DEBUG - 2011-06-13 15:24:02 --> Total execution time: 0.8106
DEBUG - 2011-06-13 15:24:03 --> Config Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Hooks Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Utf8 Class Initialized
DEBUG - 2011-06-13 15:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 15:24:03 --> URI Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Router Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Output Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Input Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 15:24:03 --> Language Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Loader Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Controller Class Initialized
ERROR - 2011-06-13 15:24:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 15:24:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 15:24:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 15:24:03 --> Model Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Model Class Initialized
DEBUG - 2011-06-13 15:24:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 15:24:03 --> Database Driver Class Initialized
DEBUG - 2011-06-13 15:24:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 15:24:03 --> Helper loaded: url_helper
DEBUG - 2011-06-13 15:24:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 15:24:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 15:24:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 15:24:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 15:24:03 --> Final output sent to browser
DEBUG - 2011-06-13 15:24:03 --> Total execution time: 0.0624
DEBUG - 2011-06-13 15:31:35 --> Config Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Hooks Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Utf8 Class Initialized
DEBUG - 2011-06-13 15:31:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 15:31:35 --> URI Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Router Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Output Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Input Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 15:31:35 --> Language Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Loader Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Controller Class Initialized
ERROR - 2011-06-13 15:31:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 15:31:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 15:31:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 15:31:35 --> Model Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Model Class Initialized
DEBUG - 2011-06-13 15:31:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 15:31:35 --> Database Driver Class Initialized
DEBUG - 2011-06-13 15:31:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 15:31:35 --> Helper loaded: url_helper
DEBUG - 2011-06-13 15:31:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 15:31:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 15:31:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 15:31:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 15:31:35 --> Final output sent to browser
DEBUG - 2011-06-13 15:31:35 --> Total execution time: 0.1305
DEBUG - 2011-06-13 15:31:44 --> Config Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Hooks Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Utf8 Class Initialized
DEBUG - 2011-06-13 15:31:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 15:31:44 --> URI Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Router Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Output Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Input Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 15:31:44 --> Language Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Loader Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Controller Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Model Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Model Class Initialized
DEBUG - 2011-06-13 15:31:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 15:31:44 --> Database Driver Class Initialized
DEBUG - 2011-06-13 15:31:45 --> Final output sent to browser
DEBUG - 2011-06-13 15:31:45 --> Total execution time: 0.7368
DEBUG - 2011-06-13 15:31:47 --> Config Class Initialized
DEBUG - 2011-06-13 15:31:47 --> Hooks Class Initialized
DEBUG - 2011-06-13 15:31:47 --> Utf8 Class Initialized
DEBUG - 2011-06-13 15:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 15:31:47 --> URI Class Initialized
DEBUG - 2011-06-13 15:31:47 --> Router Class Initialized
ERROR - 2011-06-13 15:31:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 16:13:40 --> Config Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Hooks Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Utf8 Class Initialized
DEBUG - 2011-06-13 16:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 16:13:40 --> URI Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Router Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Output Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Input Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 16:13:40 --> Language Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Loader Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Controller Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Model Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Model Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Model Class Initialized
DEBUG - 2011-06-13 16:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 16:13:40 --> Database Driver Class Initialized
DEBUG - 2011-06-13 16:13:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 16:13:41 --> Helper loaded: url_helper
DEBUG - 2011-06-13 16:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 16:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 16:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 16:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 16:13:41 --> Final output sent to browser
DEBUG - 2011-06-13 16:13:41 --> Total execution time: 0.7449
DEBUG - 2011-06-13 16:13:42 --> Config Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Hooks Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Utf8 Class Initialized
DEBUG - 2011-06-13 16:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 16:13:42 --> URI Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Router Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Output Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Input Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 16:13:42 --> Language Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Loader Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Controller Class Initialized
ERROR - 2011-06-13 16:13:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 16:13:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 16:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 16:13:42 --> Model Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Model Class Initialized
DEBUG - 2011-06-13 16:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 16:13:42 --> Database Driver Class Initialized
DEBUG - 2011-06-13 16:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 16:13:42 --> Helper loaded: url_helper
DEBUG - 2011-06-13 16:13:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 16:13:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 16:13:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 16:13:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 16:13:42 --> Final output sent to browser
DEBUG - 2011-06-13 16:13:42 --> Total execution time: 0.1146
DEBUG - 2011-06-13 21:44:37 --> Config Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Hooks Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Utf8 Class Initialized
DEBUG - 2011-06-13 21:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 21:44:37 --> URI Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Router Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Output Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Input Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 21:44:37 --> Language Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Loader Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Controller Class Initialized
ERROR - 2011-06-13 21:44:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 21:44:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 21:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 21:44:37 --> Model Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Model Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 21:44:37 --> Database Driver Class Initialized
DEBUG - 2011-06-13 21:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 21:44:37 --> Helper loaded: url_helper
DEBUG - 2011-06-13 21:44:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 21:44:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 21:44:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 21:44:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 21:44:37 --> Final output sent to browser
DEBUG - 2011-06-13 21:44:37 --> Total execution time: 0.4077
DEBUG - 2011-06-13 21:44:37 --> Config Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Hooks Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Utf8 Class Initialized
DEBUG - 2011-06-13 21:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 21:44:37 --> URI Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Router Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Output Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Input Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 21:44:37 --> Language Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Loader Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Controller Class Initialized
DEBUG - 2011-06-13 21:44:37 --> Model Class Initialized
DEBUG - 2011-06-13 21:44:38 --> Model Class Initialized
DEBUG - 2011-06-13 21:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 21:44:38 --> Database Driver Class Initialized
DEBUG - 2011-06-13 21:44:38 --> Final output sent to browser
DEBUG - 2011-06-13 21:44:38 --> Total execution time: 0.9867
DEBUG - 2011-06-13 21:44:41 --> Config Class Initialized
DEBUG - 2011-06-13 21:44:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 21:44:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 21:44:41 --> URI Class Initialized
DEBUG - 2011-06-13 21:44:41 --> Router Class Initialized
ERROR - 2011-06-13 21:44:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 21:44:41 --> Config Class Initialized
DEBUG - 2011-06-13 21:44:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 21:44:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 21:44:41 --> URI Class Initialized
DEBUG - 2011-06-13 21:44:41 --> Router Class Initialized
ERROR - 2011-06-13 21:44:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 22:21:28 --> Config Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Hooks Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Utf8 Class Initialized
DEBUG - 2011-06-13 22:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 22:21:28 --> URI Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Router Class Initialized
DEBUG - 2011-06-13 22:21:28 --> No URI present. Default controller set.
DEBUG - 2011-06-13 22:21:28 --> Output Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Input Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 22:21:28 --> Language Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Loader Class Initialized
DEBUG - 2011-06-13 22:21:28 --> Controller Class Initialized
DEBUG - 2011-06-13 22:21:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-13 22:21:28 --> Helper loaded: url_helper
DEBUG - 2011-06-13 22:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 22:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 22:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 22:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 22:21:28 --> Final output sent to browser
DEBUG - 2011-06-13 22:21:28 --> Total execution time: 0.2666
DEBUG - 2011-06-13 23:01:47 --> Config Class Initialized
DEBUG - 2011-06-13 23:01:47 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:01:47 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:01:47 --> URI Class Initialized
DEBUG - 2011-06-13 23:01:47 --> Router Class Initialized
DEBUG - 2011-06-13 23:01:48 --> Output Class Initialized
DEBUG - 2011-06-13 23:01:48 --> Config Class Initialized
DEBUG - 2011-06-13 23:01:48 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:01:48 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:01:48 --> URI Class Initialized
DEBUG - 2011-06-13 23:01:48 --> Router Class Initialized
DEBUG - 2011-06-13 23:01:49 --> Output Class Initialized
DEBUG - 2011-06-13 23:01:49 --> Input Class Initialized
DEBUG - 2011-06-13 23:01:49 --> Input Class Initialized
DEBUG - 2011-06-13 23:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:01:49 --> Language Class Initialized
DEBUG - 2011-06-13 23:01:49 --> Language Class Initialized
DEBUG - 2011-06-13 23:01:50 --> Loader Class Initialized
DEBUG - 2011-06-13 23:01:50 --> Loader Class Initialized
DEBUG - 2011-06-13 23:01:50 --> Controller Class Initialized
DEBUG - 2011-06-13 23:01:50 --> Controller Class Initialized
DEBUG - 2011-06-13 23:01:50 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:50 --> Model Class Initialized
ERROR - 2011-06-13 23:01:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:01:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:01:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:01:51 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:51 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:51 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:01:51 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:01:51 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:01:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:01:52 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:01:53 --> Final output sent to browser
DEBUG - 2011-06-13 23:01:53 --> Total execution time: 4.2767
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 23:01:53 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:01:53 --> Final output sent to browser
DEBUG - 2011-06-13 23:01:53 --> Total execution time: 5.4808
DEBUG - 2011-06-13 23:01:55 --> Config Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:01:55 --> URI Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Router Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Output Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Input Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:01:55 --> Language Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Loader Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Controller Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:01:55 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Final output sent to browser
DEBUG - 2011-06-13 23:01:56 --> Total execution time: 1.0893
DEBUG - 2011-06-13 23:01:56 --> Config Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:01:56 --> URI Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Router Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Output Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Input Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:01:56 --> Language Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Loader Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Controller Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Model Class Initialized
DEBUG - 2011-06-13 23:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:01:56 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:01:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-13 23:01:56 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:01:56 --> Final output sent to browser
DEBUG - 2011-06-13 23:01:56 --> Total execution time: 0.0896
DEBUG - 2011-06-13 23:01:58 --> Config Class Initialized
DEBUG - 2011-06-13 23:01:58 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:01:58 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:01:58 --> URI Class Initialized
DEBUG - 2011-06-13 23:01:58 --> Router Class Initialized
ERROR - 2011-06-13 23:01:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:01:59 --> Config Class Initialized
DEBUG - 2011-06-13 23:01:59 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:01:59 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:01:59 --> URI Class Initialized
DEBUG - 2011-06-13 23:01:59 --> Router Class Initialized
ERROR - 2011-06-13 23:01:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:04:45 --> Config Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:04:45 --> URI Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Router Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Output Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Input Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:04:45 --> Language Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Loader Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Controller Class Initialized
ERROR - 2011-06-13 23:04:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:04:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:04:45 --> Model Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Model Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:04:45 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:04:45 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:04:45 --> Final output sent to browser
DEBUG - 2011-06-13 23:04:45 --> Total execution time: 0.0599
DEBUG - 2011-06-13 23:04:45 --> Config Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:04:45 --> URI Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Router Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Output Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Input Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:04:45 --> Language Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Loader Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Controller Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Model Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Model Class Initialized
DEBUG - 2011-06-13 23:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:04:45 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:04:46 --> Final output sent to browser
DEBUG - 2011-06-13 23:04:46 --> Total execution time: 0.6174
DEBUG - 2011-06-13 23:04:48 --> Config Class Initialized
DEBUG - 2011-06-13 23:04:48 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:04:48 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:04:48 --> URI Class Initialized
DEBUG - 2011-06-13 23:04:48 --> Router Class Initialized
ERROR - 2011-06-13 23:04:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:05:50 --> Config Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:05:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:05:50 --> URI Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Router Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Output Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Input Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:05:50 --> Language Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Loader Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Controller Class Initialized
ERROR - 2011-06-13 23:05:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:05:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:05:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:05:50 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:05:50 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:05:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:05:50 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:05:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:05:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:05:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:05:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:05:50 --> Final output sent to browser
DEBUG - 2011-06-13 23:05:50 --> Total execution time: 0.0287
DEBUG - 2011-06-13 23:05:51 --> Config Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:05:51 --> URI Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Router Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Output Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Input Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:05:51 --> Language Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Loader Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Controller Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:05:51 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:05:51 --> Final output sent to browser
DEBUG - 2011-06-13 23:05:51 --> Total execution time: 0.5448
DEBUG - 2011-06-13 23:05:53 --> Config Class Initialized
DEBUG - 2011-06-13 23:05:53 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:05:53 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:05:53 --> URI Class Initialized
DEBUG - 2011-06-13 23:05:53 --> Router Class Initialized
ERROR - 2011-06-13 23:05:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:05:57 --> Config Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:05:57 --> URI Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Router Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Output Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Input Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:05:57 --> Language Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Loader Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Controller Class Initialized
ERROR - 2011-06-13 23:05:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:05:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:05:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:05:57 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:05:57 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:05:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:05:57 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:05:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:05:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:05:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:05:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:05:57 --> Final output sent to browser
DEBUG - 2011-06-13 23:05:57 --> Total execution time: 0.0636
DEBUG - 2011-06-13 23:05:58 --> Config Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:05:58 --> URI Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Router Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Output Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Input Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:05:58 --> Language Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Loader Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Controller Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Model Class Initialized
DEBUG - 2011-06-13 23:05:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:05:58 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:05:59 --> Final output sent to browser
DEBUG - 2011-06-13 23:05:59 --> Total execution time: 0.6619
DEBUG - 2011-06-13 23:06:00 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:00 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:00 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:00 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:00 --> Router Class Initialized
ERROR - 2011-06-13 23:06:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:06:03 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:03 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:03 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Controller Class Initialized
ERROR - 2011-06-13 23:06:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:06:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:06:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:03 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:03 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:03 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:06:03 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:03 --> Total execution time: 0.0275
DEBUG - 2011-06-13 23:06:04 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:04 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:04 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Controller Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:04 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:06 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:06 --> Total execution time: 1.2535
DEBUG - 2011-06-13 23:06:07 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:07 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:07 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:07 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:07 --> Router Class Initialized
ERROR - 2011-06-13 23:06:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:06:18 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:18 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:18 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Controller Class Initialized
ERROR - 2011-06-13 23:06:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:18 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:18 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:18 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:06:18 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:18 --> Total execution time: 0.0274
DEBUG - 2011-06-13 23:06:18 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:18 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:18 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Controller Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:18 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:18 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:18 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Controller Class Initialized
ERROR - 2011-06-13 23:06:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:18 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:18 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:18 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:06:18 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:18 --> Total execution time: 0.0280
DEBUG - 2011-06-13 23:06:19 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:19 --> Total execution time: 0.5353
DEBUG - 2011-06-13 23:06:21 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:21 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:21 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:21 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:21 --> Router Class Initialized
ERROR - 2011-06-13 23:06:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:06:24 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:24 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:24 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Controller Class Initialized
ERROR - 2011-06-13 23:06:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:06:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:06:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:24 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:24 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:24 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:06:24 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:24 --> Total execution time: 0.0295
DEBUG - 2011-06-13 23:06:24 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:24 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:24 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Controller Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:24 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:25 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:25 --> Total execution time: 0.6014
DEBUG - 2011-06-13 23:06:27 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:27 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:27 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:27 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:27 --> Router Class Initialized
ERROR - 2011-06-13 23:06:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:06:38 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:38 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:38 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Controller Class Initialized
ERROR - 2011-06-13 23:06:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:06:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:06:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:38 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:38 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:06:38 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:06:38 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:38 --> Total execution time: 0.0332
DEBUG - 2011-06-13 23:06:38 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:38 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Router Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Output Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Input Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:06:38 --> Language Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Loader Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Controller Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Model Class Initialized
DEBUG - 2011-06-13 23:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:06:38 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:06:39 --> Final output sent to browser
DEBUG - 2011-06-13 23:06:39 --> Total execution time: 0.6528
DEBUG - 2011-06-13 23:06:41 --> Config Class Initialized
DEBUG - 2011-06-13 23:06:41 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:06:41 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:06:41 --> URI Class Initialized
DEBUG - 2011-06-13 23:06:41 --> Router Class Initialized
ERROR - 2011-06-13 23:06:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-13 23:34:09 --> Config Class Initialized
DEBUG - 2011-06-13 23:34:09 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:34:09 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:34:09 --> URI Class Initialized
DEBUG - 2011-06-13 23:34:09 --> Router Class Initialized
ERROR - 2011-06-13 23:34:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-13 23:50:47 --> Config Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Hooks Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Utf8 Class Initialized
DEBUG - 2011-06-13 23:50:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-13 23:50:47 --> URI Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Router Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Output Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Input Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-13 23:50:47 --> Language Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Loader Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Controller Class Initialized
ERROR - 2011-06-13 23:50:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-13 23:50:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-13 23:50:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:50:47 --> Model Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Model Class Initialized
DEBUG - 2011-06-13 23:50:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-13 23:50:47 --> Database Driver Class Initialized
DEBUG - 2011-06-13 23:50:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-13 23:50:47 --> Helper loaded: url_helper
DEBUG - 2011-06-13 23:50:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-13 23:50:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-13 23:50:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-13 23:50:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-13 23:50:47 --> Final output sent to browser
DEBUG - 2011-06-13 23:50:47 --> Total execution time: 0.2510

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-08 00:05:09 --> Config Class Initialized
DEBUG - 2011-08-08 00:05:09 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:05:09 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:05:09 --> URI Class Initialized
DEBUG - 2011-08-08 00:05:09 --> Router Class Initialized
ERROR - 2011-08-08 00:05:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 00:54:12 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:12 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:12 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Controller Class Initialized
ERROR - 2011-08-08 00:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 00:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 00:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:12 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:12 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:12 --> Helper loaded: url_helper
DEBUG - 2011-08-08 00:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 00:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 00:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 00:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 00:54:12 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:12 --> Total execution time: 0.0802
DEBUG - 2011-08-08 00:54:12 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:12 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:12 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Controller Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:12 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:13 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:13 --> Total execution time: 0.6639
DEBUG - 2011-08-08 00:54:15 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:15 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:15 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:15 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:15 --> Router Class Initialized
ERROR - 2011-08-08 00:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 00:54:15 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:15 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:15 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:15 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:15 --> Router Class Initialized
ERROR - 2011-08-08 00:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 00:54:16 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:16 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:16 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:16 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:16 --> Router Class Initialized
ERROR - 2011-08-08 00:54:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 00:54:25 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:25 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:25 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Controller Class Initialized
ERROR - 2011-08-08 00:54:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 00:54:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 00:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:25 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:25 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:25 --> Helper loaded: url_helper
DEBUG - 2011-08-08 00:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 00:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 00:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 00:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 00:54:25 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:25 --> Total execution time: 0.0433
DEBUG - 2011-08-08 00:54:25 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:25 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:25 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Controller Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:25 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:26 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:26 --> Total execution time: 0.8104
DEBUG - 2011-08-08 00:54:39 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:39 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:39 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Controller Class Initialized
ERROR - 2011-08-08 00:54:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 00:54:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 00:54:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:39 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:39 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:39 --> Helper loaded: url_helper
DEBUG - 2011-08-08 00:54:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 00:54:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 00:54:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 00:54:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 00:54:39 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:39 --> Total execution time: 0.0267
DEBUG - 2011-08-08 00:54:39 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:39 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:39 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Controller Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:39 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:40 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:40 --> Total execution time: 0.5648
DEBUG - 2011-08-08 00:54:46 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:46 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:46 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Controller Class Initialized
ERROR - 2011-08-08 00:54:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 00:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 00:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:46 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:46 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:54:46 --> Helper loaded: url_helper
DEBUG - 2011-08-08 00:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 00:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 00:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 00:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 00:54:46 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:46 --> Total execution time: 0.0314
DEBUG - 2011-08-08 00:54:46 --> Config Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:54:46 --> URI Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Router Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Output Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Input Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:54:46 --> Language Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Loader Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Controller Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Model Class Initialized
DEBUG - 2011-08-08 00:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:54:46 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:54:47 --> Final output sent to browser
DEBUG - 2011-08-08 00:54:47 --> Total execution time: 0.6754
DEBUG - 2011-08-08 00:55:05 --> Config Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Hooks Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Utf8 Class Initialized
DEBUG - 2011-08-08 00:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 00:55:05 --> URI Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Router Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Output Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Input Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 00:55:05 --> Language Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Loader Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Controller Class Initialized
ERROR - 2011-08-08 00:55:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 00:55:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 00:55:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:55:05 --> Model Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Model Class Initialized
DEBUG - 2011-08-08 00:55:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 00:55:06 --> Database Driver Class Initialized
DEBUG - 2011-08-08 00:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 00:55:06 --> Helper loaded: url_helper
DEBUG - 2011-08-08 00:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 00:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 00:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 00:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 00:55:06 --> Final output sent to browser
DEBUG - 2011-08-08 00:55:06 --> Total execution time: 0.0616
DEBUG - 2011-08-08 01:12:45 --> Config Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Hooks Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Utf8 Class Initialized
DEBUG - 2011-08-08 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 01:12:45 --> URI Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Router Class Initialized
DEBUG - 2011-08-08 01:12:45 --> No URI present. Default controller set.
DEBUG - 2011-08-08 01:12:45 --> Config Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Output Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Hooks Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Utf8 Class Initialized
DEBUG - 2011-08-08 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 01:12:45 --> Input Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 01:12:45 --> URI Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Language Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Router Class Initialized
DEBUG - 2011-08-08 01:12:45 --> No URI present. Default controller set.
DEBUG - 2011-08-08 01:12:45 --> Output Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Input Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 01:12:45 --> Language Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Loader Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Loader Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Controller Class Initialized
DEBUG - 2011-08-08 01:12:45 --> Controller Class Initialized
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 01:12:45 --> Helper loaded: url_helper
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 01:12:45 --> Helper loaded: url_helper
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 01:12:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 01:12:45 --> Final output sent to browser
DEBUG - 2011-08-08 01:12:45 --> Total execution time: 0.0554
DEBUG - 2011-08-08 01:12:45 --> Final output sent to browser
DEBUG - 2011-08-08 01:12:45 --> Total execution time: 0.0474
DEBUG - 2011-08-08 02:05:27 --> Config Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Hooks Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Utf8 Class Initialized
DEBUG - 2011-08-08 02:05:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 02:05:27 --> URI Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Router Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Output Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Input Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 02:05:27 --> Language Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Loader Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Controller Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Model Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Model Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Model Class Initialized
DEBUG - 2011-08-08 02:05:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 02:05:27 --> Database Driver Class Initialized
DEBUG - 2011-08-08 02:05:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 02:05:28 --> Helper loaded: url_helper
DEBUG - 2011-08-08 02:05:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 02:05:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 02:05:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 02:05:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 02:05:28 --> Final output sent to browser
DEBUG - 2011-08-08 02:05:28 --> Total execution time: 1.1447
DEBUG - 2011-08-08 02:05:29 --> Config Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Hooks Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Utf8 Class Initialized
DEBUG - 2011-08-08 02:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 02:05:29 --> URI Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Router Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Output Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Input Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 02:05:29 --> Language Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Loader Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Controller Class Initialized
ERROR - 2011-08-08 02:05:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 02:05:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 02:05:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 02:05:29 --> Model Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Model Class Initialized
DEBUG - 2011-08-08 02:05:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 02:05:29 --> Database Driver Class Initialized
DEBUG - 2011-08-08 02:05:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 02:05:29 --> Helper loaded: url_helper
DEBUG - 2011-08-08 02:05:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 02:05:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 02:05:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 02:05:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 02:05:29 --> Final output sent to browser
DEBUG - 2011-08-08 02:05:29 --> Total execution time: 0.1433
DEBUG - 2011-08-08 02:09:32 --> Config Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Hooks Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Utf8 Class Initialized
DEBUG - 2011-08-08 02:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 02:09:32 --> URI Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Router Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Output Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Input Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 02:09:32 --> Language Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Loader Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Controller Class Initialized
ERROR - 2011-08-08 02:09:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 02:09:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 02:09:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 02:09:32 --> Model Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Model Class Initialized
DEBUG - 2011-08-08 02:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 02:09:32 --> Database Driver Class Initialized
DEBUG - 2011-08-08 02:09:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 02:09:32 --> Helper loaded: url_helper
DEBUG - 2011-08-08 02:09:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 02:09:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 02:09:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 02:09:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 02:09:32 --> Final output sent to browser
DEBUG - 2011-08-08 02:09:32 --> Total execution time: 0.0369
DEBUG - 2011-08-08 02:09:35 --> Config Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Hooks Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Utf8 Class Initialized
DEBUG - 2011-08-08 02:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 02:09:35 --> URI Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Router Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Output Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Input Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 02:09:35 --> Language Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Loader Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Controller Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Model Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Model Class Initialized
DEBUG - 2011-08-08 02:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 02:09:35 --> Database Driver Class Initialized
DEBUG - 2011-08-08 02:09:36 --> Final output sent to browser
DEBUG - 2011-08-08 02:09:36 --> Total execution time: 0.8485
DEBUG - 2011-08-08 02:57:21 --> Config Class Initialized
DEBUG - 2011-08-08 02:57:21 --> Hooks Class Initialized
DEBUG - 2011-08-08 02:57:21 --> Utf8 Class Initialized
DEBUG - 2011-08-08 02:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 02:57:21 --> URI Class Initialized
DEBUG - 2011-08-08 02:57:21 --> Router Class Initialized
DEBUG - 2011-08-08 02:57:21 --> Output Class Initialized
DEBUG - 2011-08-08 02:57:21 --> Input Class Initialized
DEBUG - 2011-08-08 02:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 02:57:21 --> Language Class Initialized
DEBUG - 2011-08-08 02:57:22 --> Loader Class Initialized
DEBUG - 2011-08-08 02:57:22 --> Controller Class Initialized
ERROR - 2011-08-08 02:57:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 02:57:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 02:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 02:57:22 --> Model Class Initialized
DEBUG - 2011-08-08 02:57:22 --> Model Class Initialized
DEBUG - 2011-08-08 02:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 02:57:23 --> Database Driver Class Initialized
DEBUG - 2011-08-08 02:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 02:57:30 --> Helper loaded: url_helper
DEBUG - 2011-08-08 02:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 02:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 02:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 02:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 02:57:30 --> Final output sent to browser
DEBUG - 2011-08-08 02:57:30 --> Total execution time: 9.2774
DEBUG - 2011-08-08 02:57:32 --> Config Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Hooks Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Utf8 Class Initialized
DEBUG - 2011-08-08 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 02:57:32 --> URI Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Router Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Output Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Input Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 02:57:32 --> Language Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Loader Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Controller Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Model Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Model Class Initialized
DEBUG - 2011-08-08 02:57:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 02:57:32 --> Database Driver Class Initialized
DEBUG - 2011-08-08 02:57:36 --> Final output sent to browser
DEBUG - 2011-08-08 02:57:36 --> Total execution time: 4.4665
DEBUG - 2011-08-08 04:02:05 --> Config Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:02:05 --> URI Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Router Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Output Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Input Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:02:05 --> Language Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Loader Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Controller Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Model Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Model Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Model Class Initialized
DEBUG - 2011-08-08 04:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:02:05 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:02:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 04:02:06 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:02:06 --> Final output sent to browser
DEBUG - 2011-08-08 04:02:06 --> Total execution time: 1.0830
DEBUG - 2011-08-08 04:02:07 --> Config Class Initialized
DEBUG - 2011-08-08 04:02:07 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:02:07 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:02:07 --> URI Class Initialized
DEBUG - 2011-08-08 04:02:07 --> Router Class Initialized
ERROR - 2011-08-08 04:02:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 04:40:10 --> Config Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:40:10 --> URI Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Router Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Output Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Input Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:40:10 --> Language Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Loader Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Controller Class Initialized
ERROR - 2011-08-08 04:40:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:40:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:40:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:40:10 --> Model Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Model Class Initialized
DEBUG - 2011-08-08 04:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:40:10 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:40:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:40:10 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:40:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:40:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:40:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:40:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:40:10 --> Final output sent to browser
DEBUG - 2011-08-08 04:40:10 --> Total execution time: 0.2089
DEBUG - 2011-08-08 04:40:11 --> Config Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:40:11 --> URI Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Router Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Output Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Input Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:40:11 --> Language Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Loader Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Controller Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Model Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Model Class Initialized
DEBUG - 2011-08-08 04:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:40:11 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:40:12 --> Final output sent to browser
DEBUG - 2011-08-08 04:40:12 --> Total execution time: 0.7432
DEBUG - 2011-08-08 04:40:17 --> Config Class Initialized
DEBUG - 2011-08-08 04:40:17 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:40:17 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:40:17 --> URI Class Initialized
DEBUG - 2011-08-08 04:40:17 --> Router Class Initialized
ERROR - 2011-08-08 04:40:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 04:40:17 --> Config Class Initialized
DEBUG - 2011-08-08 04:40:17 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:40:17 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:40:17 --> URI Class Initialized
DEBUG - 2011-08-08 04:40:17 --> Router Class Initialized
ERROR - 2011-08-08 04:40:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 04:41:00 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:00 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:00 --> No URI present. Default controller set.
DEBUG - 2011-08-08 04:41:00 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:00 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:00 --> Controller Class Initialized
DEBUG - 2011-08-08 04:41:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 04:41:00 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:41:00 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:00 --> Total execution time: 0.0518
DEBUG - 2011-08-08 04:41:21 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:21 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:21 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Controller Class Initialized
ERROR - 2011-08-08 04:41:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:41:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:21 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:21 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:21 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:41:21 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:21 --> Total execution time: 0.0291
DEBUG - 2011-08-08 04:41:22 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:22 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:22 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Controller Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:22 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:23 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:23 --> Total execution time: 0.7688
DEBUG - 2011-08-08 04:41:50 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:50 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:50 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Controller Class Initialized
ERROR - 2011-08-08 04:41:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:50 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:50 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:50 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:41:50 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:50 --> Total execution time: 0.0280
DEBUG - 2011-08-08 04:41:51 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:51 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:51 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Controller Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:52 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:52 --> Total execution time: 0.6861
DEBUG - 2011-08-08 04:41:52 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:52 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:52 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:52 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:52 --> Router Class Initialized
ERROR - 2011-08-08 04:41:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 04:41:53 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:53 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:53 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Controller Class Initialized
ERROR - 2011-08-08 04:41:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:53 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:53 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:53 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:41:53 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:53 --> Total execution time: 0.0303
DEBUG - 2011-08-08 04:41:58 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:58 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:58 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Controller Class Initialized
ERROR - 2011-08-08 04:41:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:41:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:58 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:58 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:41:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:41:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:41:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:41:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:41:58 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:58 --> Total execution time: 0.0275
DEBUG - 2011-08-08 04:41:58 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:58 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:58 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Controller Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:58 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:59 --> Total execution time: 0.5821
DEBUG - 2011-08-08 04:41:59 --> Config Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:41:59 --> URI Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Router Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Output Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Input Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:41:59 --> Language Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Loader Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Controller Class Initialized
ERROR - 2011-08-08 04:41:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:41:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:59 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Model Class Initialized
DEBUG - 2011-08-08 04:41:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:41:59 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:41:59 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:41:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:41:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:41:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:41:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:41:59 --> Final output sent to browser
DEBUG - 2011-08-08 04:41:59 --> Total execution time: 0.0280
DEBUG - 2011-08-08 04:42:29 --> Config Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:42:29 --> URI Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Router Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Output Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Input Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:42:29 --> Language Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Loader Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Controller Class Initialized
ERROR - 2011-08-08 04:42:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:42:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:42:29 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:42:29 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:42:29 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:42:29 --> Final output sent to browser
DEBUG - 2011-08-08 04:42:29 --> Total execution time: 0.0282
DEBUG - 2011-08-08 04:42:31 --> Config Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:42:31 --> URI Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Router Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Output Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Input Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:42:31 --> Language Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Loader Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Controller Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:42:31 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:42:31 --> Final output sent to browser
DEBUG - 2011-08-08 04:42:31 --> Total execution time: 0.5603
DEBUG - 2011-08-08 04:42:32 --> Config Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:42:32 --> URI Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Router Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Output Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Input Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:42:32 --> Language Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Loader Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Controller Class Initialized
ERROR - 2011-08-08 04:42:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:42:32 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:42:32 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:42:32 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:42:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:42:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:42:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:42:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:42:32 --> Final output sent to browser
DEBUG - 2011-08-08 04:42:32 --> Total execution time: 0.0393
DEBUG - 2011-08-08 04:42:51 --> Config Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:42:51 --> URI Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Router Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Output Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Input Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:42:51 --> Language Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Loader Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Controller Class Initialized
ERROR - 2011-08-08 04:42:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:42:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:42:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:42:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:42:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:42:51 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:42:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:42:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:42:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:42:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:42:51 --> Final output sent to browser
DEBUG - 2011-08-08 04:42:51 --> Total execution time: 0.0282
DEBUG - 2011-08-08 04:42:51 --> Config Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:42:51 --> URI Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Router Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Output Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Input Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:42:51 --> Language Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Loader Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Controller Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:42:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:42:52 --> Final output sent to browser
DEBUG - 2011-08-08 04:42:52 --> Total execution time: 0.5086
DEBUG - 2011-08-08 04:43:05 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:05 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:05 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:05 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:05 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:05 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:05 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:05 --> Total execution time: 0.0357
DEBUG - 2011-08-08 04:43:06 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:06 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:06 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Controller Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:06 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:07 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:07 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:07 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:07 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:07 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:07 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:07 --> Total execution time: 0.0329
DEBUG - 2011-08-08 04:43:07 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:07 --> Total execution time: 0.5396
DEBUG - 2011-08-08 04:43:25 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:25 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:25 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:25 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:25 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:25 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:25 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:25 --> Total execution time: 0.0296
DEBUG - 2011-08-08 04:43:25 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:25 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:25 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Controller Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:25 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:26 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:26 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:26 --> Total execution time: 0.5521
DEBUG - 2011-08-08 04:43:26 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:26 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:26 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:26 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:26 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:26 --> Total execution time: 0.0287
DEBUG - 2011-08-08 04:43:35 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:35 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:35 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:35 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:35 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:35 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:35 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:35 --> Total execution time: 0.0267
DEBUG - 2011-08-08 04:43:36 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:36 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:36 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Controller Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:36 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:36 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:36 --> Total execution time: 0.5662
DEBUG - 2011-08-08 04:43:51 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:51 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:51 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:51 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:51 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:51 --> Total execution time: 0.0279
DEBUG - 2011-08-08 04:43:52 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:52 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:52 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Controller Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:52 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Config Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:43:52 --> URI Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Router Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Output Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Input Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:43:52 --> Language Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Loader Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Controller Class Initialized
ERROR - 2011-08-08 04:43:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:43:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:43:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:52 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Model Class Initialized
DEBUG - 2011-08-08 04:43:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:43:52 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:43:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:43:52 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:43:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:43:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:43:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:43:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:43:52 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:52 --> Total execution time: 0.0439
DEBUG - 2011-08-08 04:43:53 --> Final output sent to browser
DEBUG - 2011-08-08 04:43:53 --> Total execution time: 1.0341
DEBUG - 2011-08-08 04:44:02 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:02 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:02 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Controller Class Initialized
ERROR - 2011-08-08 04:44:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:44:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:44:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:02 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:02 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:02 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:44:02 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:02 --> Total execution time: 0.0405
DEBUG - 2011-08-08 04:44:02 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:02 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:02 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Controller Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:02 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:03 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:03 --> Total execution time: 0.5410
DEBUG - 2011-08-08 04:44:20 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:20 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:20 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Controller Class Initialized
ERROR - 2011-08-08 04:44:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:44:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:20 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:20 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:20 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:44:20 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:20 --> Total execution time: 0.0326
DEBUG - 2011-08-08 04:44:20 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:20 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:20 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Controller Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:20 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:21 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:21 --> Total execution time: 0.6858
DEBUG - 2011-08-08 04:44:35 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:35 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:35 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Controller Class Initialized
ERROR - 2011-08-08 04:44:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:44:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:44:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:35 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:35 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:35 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:44:35 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:35 --> Total execution time: 0.0295
DEBUG - 2011-08-08 04:44:36 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:36 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:36 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Controller Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:36 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:36 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:36 --> Total execution time: 0.5121
DEBUG - 2011-08-08 04:44:44 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:44 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:44 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Controller Class Initialized
ERROR - 2011-08-08 04:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:44 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:44 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:44 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:44:44 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:44 --> Total execution time: 0.0330
DEBUG - 2011-08-08 04:44:46 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:46 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:46 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Controller Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:46 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:46 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:46 --> Total execution time: 0.4994
DEBUG - 2011-08-08 04:44:54 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:54 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:54 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Controller Class Initialized
ERROR - 2011-08-08 04:44:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:44:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:44:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:54 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:54 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:44:54 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:44:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:44:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:44:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:44:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:44:54 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:54 --> Total execution time: 0.0373
DEBUG - 2011-08-08 04:44:55 --> Config Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:44:55 --> URI Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Router Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Output Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Input Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:44:55 --> Language Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Loader Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Controller Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Model Class Initialized
DEBUG - 2011-08-08 04:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:44:55 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:44:56 --> Final output sent to browser
DEBUG - 2011-08-08 04:44:56 --> Total execution time: 0.5009
DEBUG - 2011-08-08 04:45:06 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:06 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:06 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Controller Class Initialized
ERROR - 2011-08-08 04:45:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:45:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:45:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:06 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:06 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:06 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:45:06 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:06 --> Total execution time: 0.0300
DEBUG - 2011-08-08 04:45:06 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:06 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:06 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Controller Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:07 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:07 --> Total execution time: 0.7412
DEBUG - 2011-08-08 04:45:07 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:07 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:07 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Controller Class Initialized
ERROR - 2011-08-08 04:45:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:45:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:07 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:07 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:07 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:45:07 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:07 --> Total execution time: 0.0302
DEBUG - 2011-08-08 04:45:39 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:39 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:39 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Controller Class Initialized
ERROR - 2011-08-08 04:45:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:45:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:39 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:39 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:39 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:45:39 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:39 --> Total execution time: 0.0320
DEBUG - 2011-08-08 04:45:40 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:40 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:40 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Controller Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:40 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:41 --> Total execution time: 0.8180
DEBUG - 2011-08-08 04:45:41 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:41 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:41 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Controller Class Initialized
ERROR - 2011-08-08 04:45:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:45:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:41 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:41 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:41 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:45:41 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:41 --> Total execution time: 0.0831
DEBUG - 2011-08-08 04:45:47 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:47 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:47 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Controller Class Initialized
ERROR - 2011-08-08 04:45:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:45:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:45:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:47 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:47 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:47 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:45:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:45:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:45:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:45:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:45:47 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:47 --> Total execution time: 0.0295
DEBUG - 2011-08-08 04:45:47 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:47 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:47 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Controller Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:47 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:48 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:48 --> Total execution time: 0.6554
DEBUG - 2011-08-08 04:45:58 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:58 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:58 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Controller Class Initialized
ERROR - 2011-08-08 04:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 04:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 04:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:58 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 04:45:58 --> Helper loaded: url_helper
DEBUG - 2011-08-08 04:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 04:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 04:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 04:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 04:45:58 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:58 --> Total execution time: 0.0277
DEBUG - 2011-08-08 04:45:58 --> Config Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Hooks Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Utf8 Class Initialized
DEBUG - 2011-08-08 04:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 04:45:58 --> URI Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Router Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Output Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Input Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 04:45:58 --> Language Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Loader Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Controller Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Model Class Initialized
DEBUG - 2011-08-08 04:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 04:45:58 --> Database Driver Class Initialized
DEBUG - 2011-08-08 04:45:59 --> Final output sent to browser
DEBUG - 2011-08-08 04:45:59 --> Total execution time: 0.5623
DEBUG - 2011-08-08 05:09:23 --> Config Class Initialized
DEBUG - 2011-08-08 05:09:23 --> Hooks Class Initialized
DEBUG - 2011-08-08 05:09:23 --> Utf8 Class Initialized
DEBUG - 2011-08-08 05:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 05:09:23 --> URI Class Initialized
DEBUG - 2011-08-08 05:09:23 --> Router Class Initialized
ERROR - 2011-08-08 05:09:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 05:45:36 --> Config Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Hooks Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Utf8 Class Initialized
DEBUG - 2011-08-08 05:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 05:45:36 --> URI Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Router Class Initialized
DEBUG - 2011-08-08 05:45:36 --> No URI present. Default controller set.
DEBUG - 2011-08-08 05:45:36 --> Output Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Input Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 05:45:36 --> Language Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Loader Class Initialized
DEBUG - 2011-08-08 05:45:36 --> Controller Class Initialized
DEBUG - 2011-08-08 05:45:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 05:45:36 --> Helper loaded: url_helper
DEBUG - 2011-08-08 05:45:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 05:45:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 05:45:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 05:45:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 05:45:36 --> Final output sent to browser
DEBUG - 2011-08-08 05:45:36 --> Total execution time: 0.1807
DEBUG - 2011-08-08 05:53:22 --> Config Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Hooks Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Utf8 Class Initialized
DEBUG - 2011-08-08 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 05:53:22 --> URI Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Router Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Output Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Input Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 05:53:22 --> Language Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Loader Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Controller Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Model Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Model Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Model Class Initialized
DEBUG - 2011-08-08 05:53:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 05:53:22 --> Database Driver Class Initialized
DEBUG - 2011-08-08 05:53:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 05:53:23 --> Helper loaded: url_helper
DEBUG - 2011-08-08 05:53:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 05:53:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 05:53:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 05:53:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 05:53:23 --> Final output sent to browser
DEBUG - 2011-08-08 05:53:23 --> Total execution time: 0.7426
DEBUG - 2011-08-08 05:55:13 --> Config Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Hooks Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Utf8 Class Initialized
DEBUG - 2011-08-08 05:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 05:55:13 --> URI Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Router Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Output Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Input Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 05:55:13 --> Language Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Loader Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Controller Class Initialized
ERROR - 2011-08-08 05:55:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 05:55:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 05:55:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 05:55:13 --> Model Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Model Class Initialized
DEBUG - 2011-08-08 05:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 05:55:13 --> Database Driver Class Initialized
DEBUG - 2011-08-08 05:55:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 05:55:13 --> Helper loaded: url_helper
DEBUG - 2011-08-08 05:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 05:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 05:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 05:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 05:55:13 --> Final output sent to browser
DEBUG - 2011-08-08 05:55:13 --> Total execution time: 0.1040
DEBUG - 2011-08-08 06:00:23 --> Config Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:00:23 --> URI Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Router Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Output Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Input Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:00:23 --> Language Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Loader Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Controller Class Initialized
ERROR - 2011-08-08 06:00:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:00:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:00:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:00:23 --> Model Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Model Class Initialized
DEBUG - 2011-08-08 06:00:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:00:23 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:00:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:00:23 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:00:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:00:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:00:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:00:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:00:23 --> Final output sent to browser
DEBUG - 2011-08-08 06:00:23 --> Total execution time: 0.0395
DEBUG - 2011-08-08 06:00:35 --> Config Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:00:35 --> URI Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Router Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Output Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Input Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:00:35 --> Language Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Loader Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Controller Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Model Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Model Class Initialized
DEBUG - 2011-08-08 06:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:00:35 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:00:36 --> Final output sent to browser
DEBUG - 2011-08-08 06:00:36 --> Total execution time: 0.6258
DEBUG - 2011-08-08 06:00:41 --> Config Class Initialized
DEBUG - 2011-08-08 06:00:41 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:00:41 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:00:41 --> URI Class Initialized
DEBUG - 2011-08-08 06:00:41 --> Router Class Initialized
ERROR - 2011-08-08 06:00:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:01:51 --> Config Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:01:51 --> URI Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Router Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Output Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Input Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:01:51 --> Language Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Loader Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Controller Class Initialized
ERROR - 2011-08-08 06:01:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:01:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:01:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:01:51 --> Model Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Model Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:01:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:01:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:01:51 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:01:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:01:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:01:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:01:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:01:51 --> Final output sent to browser
DEBUG - 2011-08-08 06:01:51 --> Total execution time: 0.0550
DEBUG - 2011-08-08 06:01:51 --> Config Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:01:51 --> URI Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Router Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Output Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Input Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:01:51 --> Language Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Loader Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Controller Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Model Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Model Class Initialized
DEBUG - 2011-08-08 06:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:01:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:01:52 --> Final output sent to browser
DEBUG - 2011-08-08 06:01:52 --> Total execution time: 0.5016
DEBUG - 2011-08-08 06:01:55 --> Config Class Initialized
DEBUG - 2011-08-08 06:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:01:55 --> URI Class Initialized
DEBUG - 2011-08-08 06:01:55 --> Router Class Initialized
ERROR - 2011-08-08 06:01:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:02:06 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:06 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:06 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Controller Class Initialized
ERROR - 2011-08-08 06:02:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:06 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:06 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:06 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:02:06 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:06 --> Total execution time: 0.0289
DEBUG - 2011-08-08 06:02:07 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:07 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:07 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Controller Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:07 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:07 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:07 --> Total execution time: 0.5878
DEBUG - 2011-08-08 06:02:09 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:09 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:09 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:09 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:09 --> Router Class Initialized
ERROR - 2011-08-08 06:02:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:02:21 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:21 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:21 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Controller Class Initialized
ERROR - 2011-08-08 06:02:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:02:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:21 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:21 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:21 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:02:21 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:21 --> Total execution time: 0.0283
DEBUG - 2011-08-08 06:02:25 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:25 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:25 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Controller Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:25 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:26 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:26 --> Total execution time: 0.7389
DEBUG - 2011-08-08 06:02:31 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:31 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:31 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:31 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:31 --> Router Class Initialized
ERROR - 2011-08-08 06:02:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:02:39 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:39 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:39 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Controller Class Initialized
ERROR - 2011-08-08 06:02:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:02:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:02:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:39 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:39 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:39 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:02:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:02:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:02:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:02:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:02:39 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:39 --> Total execution time: 0.0519
DEBUG - 2011-08-08 06:02:40 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:40 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:40 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Controller Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:40 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:40 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:40 --> Total execution time: 0.5215
DEBUG - 2011-08-08 06:02:42 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:42 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:42 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:42 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:42 --> Router Class Initialized
ERROR - 2011-08-08 06:02:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:02:46 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:46 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:46 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Controller Class Initialized
ERROR - 2011-08-08 06:02:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:02:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:46 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:46 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:02:46 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:02:46 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:46 --> Total execution time: 0.0270
DEBUG - 2011-08-08 06:02:48 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:48 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Router Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Output Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Input Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:02:48 --> Language Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Loader Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Controller Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Model Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:02:48 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:02:48 --> Final output sent to browser
DEBUG - 2011-08-08 06:02:48 --> Total execution time: 0.5006
DEBUG - 2011-08-08 06:02:52 --> Config Class Initialized
DEBUG - 2011-08-08 06:02:52 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:02:52 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:02:52 --> URI Class Initialized
DEBUG - 2011-08-08 06:02:52 --> Router Class Initialized
ERROR - 2011-08-08 06:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:03:00 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:00 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Router Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Output Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Input Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:03:00 --> Language Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Loader Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Controller Class Initialized
ERROR - 2011-08-08 06:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:03:00 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:03:00 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:03:00 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:03:00 --> Final output sent to browser
DEBUG - 2011-08-08 06:03:00 --> Total execution time: 0.0278
DEBUG - 2011-08-08 06:03:01 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:01 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Router Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Output Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Input Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:03:01 --> Language Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Loader Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Controller Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:03:01 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:03:01 --> Final output sent to browser
DEBUG - 2011-08-08 06:03:01 --> Total execution time: 0.4893
DEBUG - 2011-08-08 06:03:11 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:11 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:11 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:11 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:11 --> Router Class Initialized
ERROR - 2011-08-08 06:03:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 06:03:21 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:21 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Router Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Output Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Input Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:03:21 --> Language Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Loader Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Controller Class Initialized
ERROR - 2011-08-08 06:03:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:03:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:03:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:03:21 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:03:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:03:21 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:03:21 --> Final output sent to browser
DEBUG - 2011-08-08 06:03:21 --> Total execution time: 0.0292
DEBUG - 2011-08-08 06:03:21 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:21 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Router Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Output Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Input Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:03:21 --> Language Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Loader Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Controller Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:03:21 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:22 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Router Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Output Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Input Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 06:03:22 --> Language Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Loader Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Controller Class Initialized
ERROR - 2011-08-08 06:03:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 06:03:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 06:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:03:22 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Model Class Initialized
DEBUG - 2011-08-08 06:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 06:03:22 --> Database Driver Class Initialized
DEBUG - 2011-08-08 06:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 06:03:22 --> Helper loaded: url_helper
DEBUG - 2011-08-08 06:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 06:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 06:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 06:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 06:03:22 --> Final output sent to browser
DEBUG - 2011-08-08 06:03:22 --> Total execution time: 0.0279
DEBUG - 2011-08-08 06:03:22 --> Final output sent to browser
DEBUG - 2011-08-08 06:03:22 --> Total execution time: 0.6584
DEBUG - 2011-08-08 06:03:24 --> Config Class Initialized
DEBUG - 2011-08-08 06:03:24 --> Hooks Class Initialized
DEBUG - 2011-08-08 06:03:24 --> Utf8 Class Initialized
DEBUG - 2011-08-08 06:03:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 06:03:24 --> URI Class Initialized
DEBUG - 2011-08-08 06:03:24 --> Router Class Initialized
ERROR - 2011-08-08 06:03:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 08:49:22 --> Config Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Hooks Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Utf8 Class Initialized
DEBUG - 2011-08-08 08:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 08:49:22 --> URI Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Router Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Output Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Input Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 08:49:22 --> Language Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Loader Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Controller Class Initialized
ERROR - 2011-08-08 08:49:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 08:49:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 08:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 08:49:22 --> Model Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Model Class Initialized
DEBUG - 2011-08-08 08:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 08:49:22 --> Database Driver Class Initialized
DEBUG - 2011-08-08 08:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 08:49:22 --> Helper loaded: url_helper
DEBUG - 2011-08-08 08:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 08:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 08:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 08:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 08:49:22 --> Final output sent to browser
DEBUG - 2011-08-08 08:49:22 --> Total execution time: 0.3068
DEBUG - 2011-08-08 08:49:23 --> Config Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Hooks Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Utf8 Class Initialized
DEBUG - 2011-08-08 08:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 08:49:23 --> URI Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Router Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Output Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Input Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 08:49:23 --> Language Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Loader Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Controller Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Model Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Model Class Initialized
DEBUG - 2011-08-08 08:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 08:49:23 --> Database Driver Class Initialized
DEBUG - 2011-08-08 08:49:24 --> Final output sent to browser
DEBUG - 2011-08-08 08:49:24 --> Total execution time: 0.8698
DEBUG - 2011-08-08 08:49:27 --> Config Class Initialized
DEBUG - 2011-08-08 08:49:27 --> Hooks Class Initialized
DEBUG - 2011-08-08 08:49:27 --> Utf8 Class Initialized
DEBUG - 2011-08-08 08:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 08:49:27 --> URI Class Initialized
DEBUG - 2011-08-08 08:49:27 --> Router Class Initialized
ERROR - 2011-08-08 08:49:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 08:49:28 --> Config Class Initialized
DEBUG - 2011-08-08 08:49:28 --> Hooks Class Initialized
DEBUG - 2011-08-08 08:49:28 --> Utf8 Class Initialized
DEBUG - 2011-08-08 08:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 08:49:28 --> URI Class Initialized
DEBUG - 2011-08-08 08:49:28 --> Router Class Initialized
ERROR - 2011-08-08 08:49:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 10:36:03 --> Config Class Initialized
DEBUG - 2011-08-08 10:36:03 --> Hooks Class Initialized
DEBUG - 2011-08-08 10:36:03 --> Utf8 Class Initialized
DEBUG - 2011-08-08 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 10:36:03 --> URI Class Initialized
DEBUG - 2011-08-08 10:36:03 --> Router Class Initialized
ERROR - 2011-08-08 10:36:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 10:54:40 --> Config Class Initialized
DEBUG - 2011-08-08 10:54:40 --> Hooks Class Initialized
DEBUG - 2011-08-08 10:54:40 --> Utf8 Class Initialized
DEBUG - 2011-08-08 10:54:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 10:54:40 --> URI Class Initialized
DEBUG - 2011-08-08 10:54:40 --> Router Class Initialized
ERROR - 2011-08-08 10:54:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 10:55:20 --> Config Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Hooks Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Utf8 Class Initialized
DEBUG - 2011-08-08 10:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 10:55:20 --> URI Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Router Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Output Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Input Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 10:55:20 --> Language Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Loader Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Controller Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Model Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Model Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Model Class Initialized
DEBUG - 2011-08-08 10:55:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 10:55:20 --> Database Driver Class Initialized
DEBUG - 2011-08-08 10:55:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 10:55:20 --> Helper loaded: url_helper
DEBUG - 2011-08-08 10:55:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 10:55:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 10:55:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 10:55:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 10:55:20 --> Final output sent to browser
DEBUG - 2011-08-08 10:55:20 --> Total execution time: 0.6348
DEBUG - 2011-08-08 12:22:35 --> Config Class Initialized
DEBUG - 2011-08-08 12:22:35 --> Hooks Class Initialized
DEBUG - 2011-08-08 12:22:35 --> Utf8 Class Initialized
DEBUG - 2011-08-08 12:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 12:22:35 --> URI Class Initialized
DEBUG - 2011-08-08 12:22:35 --> Router Class Initialized
ERROR - 2011-08-08 12:22:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 14:57:04 --> Config Class Initialized
DEBUG - 2011-08-08 14:57:04 --> Hooks Class Initialized
DEBUG - 2011-08-08 14:57:04 --> Utf8 Class Initialized
DEBUG - 2011-08-08 14:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 14:57:04 --> URI Class Initialized
DEBUG - 2011-08-08 14:57:04 --> Router Class Initialized
ERROR - 2011-08-08 14:57:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 16:11:06 --> Config Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Hooks Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Utf8 Class Initialized
DEBUG - 2011-08-08 16:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 16:11:06 --> URI Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Router Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Output Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Input Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 16:11:06 --> Language Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Loader Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Controller Class Initialized
ERROR - 2011-08-08 16:11:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 16:11:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 16:11:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 16:11:06 --> Model Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Model Class Initialized
DEBUG - 2011-08-08 16:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 16:11:06 --> Database Driver Class Initialized
DEBUG - 2011-08-08 16:11:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 16:11:06 --> Helper loaded: url_helper
DEBUG - 2011-08-08 16:11:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 16:11:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 16:11:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 16:11:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 16:11:06 --> Final output sent to browser
DEBUG - 2011-08-08 16:11:06 --> Total execution time: 0.3454
DEBUG - 2011-08-08 17:31:51 --> Config Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:31:51 --> URI Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Router Class Initialized
DEBUG - 2011-08-08 17:31:51 --> No URI present. Default controller set.
DEBUG - 2011-08-08 17:31:51 --> Output Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Input Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 17:31:51 --> Language Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Loader Class Initialized
DEBUG - 2011-08-08 17:31:51 --> Controller Class Initialized
DEBUG - 2011-08-08 17:31:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 17:31:51 --> Helper loaded: url_helper
DEBUG - 2011-08-08 17:31:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 17:31:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 17:31:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 17:31:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 17:31:51 --> Final output sent to browser
DEBUG - 2011-08-08 17:31:51 --> Total execution time: 0.1158
DEBUG - 2011-08-08 17:31:55 --> Config Class Initialized
DEBUG - 2011-08-08 17:31:55 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:31:55 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:31:55 --> URI Class Initialized
DEBUG - 2011-08-08 17:31:55 --> Router Class Initialized
ERROR - 2011-08-08 17:31:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 17:32:00 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:00 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Router Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Output Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Input Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 17:32:00 --> Language Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Loader Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Controller Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 17:32:00 --> Database Driver Class Initialized
DEBUG - 2011-08-08 17:32:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 17:32:01 --> Helper loaded: url_helper
DEBUG - 2011-08-08 17:32:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 17:32:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 17:32:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 17:32:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 17:32:01 --> Final output sent to browser
DEBUG - 2011-08-08 17:32:01 --> Total execution time: 0.4792
DEBUG - 2011-08-08 17:32:02 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:02 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Router Class Initialized
ERROR - 2011-08-08 17:32:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 17:32:02 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:02 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Router Class Initialized
ERROR - 2011-08-08 17:32:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 17:32:02 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:02 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Router Class Initialized
DEBUG - 2011-08-08 17:32:02 --> No URI present. Default controller set.
DEBUG - 2011-08-08 17:32:02 --> Output Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Input Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 17:32:02 --> Language Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Loader Class Initialized
DEBUG - 2011-08-08 17:32:02 --> Controller Class Initialized
DEBUG - 2011-08-08 17:32:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 17:32:02 --> Helper loaded: url_helper
DEBUG - 2011-08-08 17:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 17:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 17:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 17:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 17:32:02 --> Final output sent to browser
DEBUG - 2011-08-08 17:32:02 --> Total execution time: 0.0126
DEBUG - 2011-08-08 17:32:17 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:17 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Router Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Output Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Input Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 17:32:17 --> Language Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Loader Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Controller Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 17:32:17 --> Database Driver Class Initialized
DEBUG - 2011-08-08 17:32:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 17:32:18 --> Helper loaded: url_helper
DEBUG - 2011-08-08 17:32:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 17:32:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 17:32:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 17:32:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 17:32:18 --> Final output sent to browser
DEBUG - 2011-08-08 17:32:18 --> Total execution time: 1.4059
DEBUG - 2011-08-08 17:32:19 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:19 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Router Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Output Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Input Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 17:32:19 --> Language Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Loader Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Controller Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Model Class Initialized
DEBUG - 2011-08-08 17:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 17:32:19 --> Database Driver Class Initialized
DEBUG - 2011-08-08 17:32:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 17:32:19 --> Helper loaded: url_helper
DEBUG - 2011-08-08 17:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 17:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 17:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 17:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 17:32:19 --> Final output sent to browser
DEBUG - 2011-08-08 17:32:19 --> Total execution time: 0.0438
DEBUG - 2011-08-08 17:32:20 --> Config Class Initialized
DEBUG - 2011-08-08 17:32:20 --> Hooks Class Initialized
DEBUG - 2011-08-08 17:32:20 --> Utf8 Class Initialized
DEBUG - 2011-08-08 17:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 17:32:20 --> URI Class Initialized
DEBUG - 2011-08-08 17:32:20 --> Router Class Initialized
ERROR - 2011-08-08 17:32:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 18:46:23 --> Config Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-08 18:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 18:46:23 --> URI Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Router Class Initialized
DEBUG - 2011-08-08 18:46:23 --> No URI present. Default controller set.
DEBUG - 2011-08-08 18:46:23 --> Output Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Input Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 18:46:23 --> Language Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Loader Class Initialized
DEBUG - 2011-08-08 18:46:23 --> Controller Class Initialized
DEBUG - 2011-08-08 18:46:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 18:46:23 --> Helper loaded: url_helper
DEBUG - 2011-08-08 18:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 18:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 18:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 18:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 18:46:23 --> Final output sent to browser
DEBUG - 2011-08-08 18:46:23 --> Total execution time: 0.0399
DEBUG - 2011-08-08 18:46:24 --> Config Class Initialized
DEBUG - 2011-08-08 18:46:24 --> Hooks Class Initialized
DEBUG - 2011-08-08 18:46:24 --> Utf8 Class Initialized
DEBUG - 2011-08-08 18:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 18:46:24 --> URI Class Initialized
DEBUG - 2011-08-08 18:46:24 --> Router Class Initialized
ERROR - 2011-08-08 18:46:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 19:18:21 --> Config Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Hooks Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Utf8 Class Initialized
DEBUG - 2011-08-08 19:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 19:18:21 --> URI Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Router Class Initialized
DEBUG - 2011-08-08 19:18:21 --> No URI present. Default controller set.
DEBUG - 2011-08-08 19:18:21 --> Output Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Input Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 19:18:21 --> Language Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Loader Class Initialized
DEBUG - 2011-08-08 19:18:21 --> Controller Class Initialized
DEBUG - 2011-08-08 19:18:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-08 19:18:21 --> Helper loaded: url_helper
DEBUG - 2011-08-08 19:18:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 19:18:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 19:18:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 19:18:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 19:18:21 --> Final output sent to browser
DEBUG - 2011-08-08 19:18:21 --> Total execution time: 0.0128
DEBUG - 2011-08-08 19:37:33 --> Config Class Initialized
DEBUG - 2011-08-08 19:37:33 --> Hooks Class Initialized
DEBUG - 2011-08-08 19:37:33 --> Utf8 Class Initialized
DEBUG - 2011-08-08 19:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 19:37:33 --> URI Class Initialized
DEBUG - 2011-08-08 19:37:33 --> Router Class Initialized
ERROR - 2011-08-08 19:37:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 20:47:52 --> Config Class Initialized
DEBUG - 2011-08-08 20:47:52 --> Hooks Class Initialized
DEBUG - 2011-08-08 20:47:52 --> Utf8 Class Initialized
DEBUG - 2011-08-08 20:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 20:47:52 --> URI Class Initialized
DEBUG - 2011-08-08 20:47:52 --> Router Class Initialized
ERROR - 2011-08-08 20:47:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-08 20:47:53 --> Config Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Hooks Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Utf8 Class Initialized
DEBUG - 2011-08-08 20:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 20:47:53 --> URI Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Router Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Output Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Input Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 20:47:53 --> Language Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Loader Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Controller Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Model Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Model Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Model Class Initialized
DEBUG - 2011-08-08 20:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 20:47:53 --> Database Driver Class Initialized
DEBUG - 2011-08-08 20:47:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 20:47:53 --> Helper loaded: url_helper
DEBUG - 2011-08-08 20:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 20:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 20:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 20:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 20:47:53 --> Final output sent to browser
DEBUG - 2011-08-08 20:47:53 --> Total execution time: 0.3885
DEBUG - 2011-08-08 21:17:41 --> Config Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:17:41 --> URI Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Router Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Output Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Input Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:17:41 --> Language Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Loader Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Controller Class Initialized
ERROR - 2011-08-08 21:17:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 21:17:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 21:17:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:17:41 --> Model Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Model Class Initialized
DEBUG - 2011-08-08 21:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:17:41 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:17:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:17:41 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:17:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:17:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:17:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:17:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:17:41 --> Final output sent to browser
DEBUG - 2011-08-08 21:17:41 --> Total execution time: 0.1275
DEBUG - 2011-08-08 21:17:42 --> Config Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:17:42 --> URI Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Router Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Output Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Input Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:17:42 --> Language Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Loader Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Controller Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Model Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Model Class Initialized
DEBUG - 2011-08-08 21:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:17:42 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:17:43 --> Final output sent to browser
DEBUG - 2011-08-08 21:17:43 --> Total execution time: 0.5987
DEBUG - 2011-08-08 21:17:44 --> Config Class Initialized
DEBUG - 2011-08-08 21:17:44 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:17:44 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:17:44 --> URI Class Initialized
DEBUG - 2011-08-08 21:17:44 --> Router Class Initialized
ERROR - 2011-08-08 21:17:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 21:17:45 --> Config Class Initialized
DEBUG - 2011-08-08 21:17:45 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:17:45 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:17:45 --> URI Class Initialized
DEBUG - 2011-08-08 21:17:45 --> Router Class Initialized
ERROR - 2011-08-08 21:17:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 21:17:45 --> Config Class Initialized
DEBUG - 2011-08-08 21:17:45 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:17:45 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:17:45 --> URI Class Initialized
DEBUG - 2011-08-08 21:17:45 --> Router Class Initialized
ERROR - 2011-08-08 21:17:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 21:18:54 --> Config Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:18:54 --> URI Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Router Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Output Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Input Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:18:54 --> Language Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Loader Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Controller Class Initialized
ERROR - 2011-08-08 21:18:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 21:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 21:18:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:18:54 --> Model Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Model Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:18:54 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:18:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:18:54 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:18:54 --> Final output sent to browser
DEBUG - 2011-08-08 21:18:54 --> Total execution time: 0.1681
DEBUG - 2011-08-08 21:18:54 --> Config Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:18:54 --> URI Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Router Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Output Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Input Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:18:54 --> Language Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Loader Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Controller Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Model Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Model Class Initialized
DEBUG - 2011-08-08 21:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:18:54 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:18:55 --> Final output sent to browser
DEBUG - 2011-08-08 21:18:55 --> Total execution time: 0.5682
DEBUG - 2011-08-08 21:19:07 --> Config Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:19:07 --> URI Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Router Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Output Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Input Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:19:07 --> Language Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Loader Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Controller Class Initialized
ERROR - 2011-08-08 21:19:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 21:19:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 21:19:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:19:07 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:19:07 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:19:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:19:07 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:19:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:19:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:19:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:19:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:19:07 --> Final output sent to browser
DEBUG - 2011-08-08 21:19:07 --> Total execution time: 0.0277
DEBUG - 2011-08-08 21:19:08 --> Config Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:19:08 --> URI Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Router Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Output Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Input Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:19:08 --> Language Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Loader Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Controller Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:19:08 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:19:09 --> Final output sent to browser
DEBUG - 2011-08-08 21:19:09 --> Total execution time: 0.7171
DEBUG - 2011-08-08 21:19:56 --> Config Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:19:56 --> URI Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Router Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Output Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Input Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:19:56 --> Language Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Loader Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Controller Class Initialized
ERROR - 2011-08-08 21:19:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 21:19:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 21:19:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:19:56 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:19:56 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:19:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:19:56 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:19:56 --> Final output sent to browser
DEBUG - 2011-08-08 21:19:56 --> Total execution time: 0.0818
DEBUG - 2011-08-08 21:19:57 --> Config Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:19:57 --> URI Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Router Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Output Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Input Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:19:57 --> Language Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Loader Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Controller Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Model Class Initialized
DEBUG - 2011-08-08 21:19:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:19:57 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:19:58 --> Final output sent to browser
DEBUG - 2011-08-08 21:19:58 --> Total execution time: 0.5474
DEBUG - 2011-08-08 21:33:20 --> Config Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:33:20 --> URI Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Router Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Output Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Input Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:33:20 --> Language Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Loader Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Controller Class Initialized
ERROR - 2011-08-08 21:33:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 21:33:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 21:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:33:20 --> Model Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Model Class Initialized
DEBUG - 2011-08-08 21:33:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:33:20 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:33:20 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:33:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:33:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:33:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:33:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:33:20 --> Final output sent to browser
DEBUG - 2011-08-08 21:33:20 --> Total execution time: 0.0344
DEBUG - 2011-08-08 21:49:52 --> Config Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:49:52 --> URI Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Router Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Output Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Input Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:49:52 --> Language Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Loader Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Controller Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Model Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Model Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Model Class Initialized
DEBUG - 2011-08-08 21:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:49:52 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:49:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-08 21:49:52 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:49:52 --> Final output sent to browser
DEBUG - 2011-08-08 21:49:52 --> Total execution time: 0.2516
DEBUG - 2011-08-08 21:49:57 --> Config Class Initialized
DEBUG - 2011-08-08 21:49:57 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:49:57 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:49:57 --> URI Class Initialized
DEBUG - 2011-08-08 21:49:57 --> Router Class Initialized
ERROR - 2011-08-08 21:49:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 21:49:58 --> Config Class Initialized
DEBUG - 2011-08-08 21:49:58 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:49:58 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:49:58 --> URI Class Initialized
DEBUG - 2011-08-08 21:49:58 --> Router Class Initialized
ERROR - 2011-08-08 21:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 21:58:08 --> Config Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Hooks Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Utf8 Class Initialized
DEBUG - 2011-08-08 21:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 21:58:08 --> URI Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Router Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Output Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Input Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 21:58:08 --> Language Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Loader Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Controller Class Initialized
ERROR - 2011-08-08 21:58:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 21:58:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 21:58:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:58:08 --> Model Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Model Class Initialized
DEBUG - 2011-08-08 21:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 21:58:08 --> Database Driver Class Initialized
DEBUG - 2011-08-08 21:58:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 21:58:08 --> Helper loaded: url_helper
DEBUG - 2011-08-08 21:58:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 21:58:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 21:58:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 21:58:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 21:58:08 --> Final output sent to browser
DEBUG - 2011-08-08 21:58:08 --> Total execution time: 0.0283
DEBUG - 2011-08-08 23:53:50 --> Config Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:53:50 --> URI Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Router Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Output Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Input Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:53:50 --> Language Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Loader Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Controller Class Initialized
ERROR - 2011-08-08 23:53:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:53:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:53:50 --> Model Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Model Class Initialized
DEBUG - 2011-08-08 23:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:53:50 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:53:50 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:53:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:53:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:53:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:53:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:53:50 --> Final output sent to browser
DEBUG - 2011-08-08 23:53:50 --> Total execution time: 0.0551
DEBUG - 2011-08-08 23:53:51 --> Config Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:53:51 --> URI Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Router Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Output Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Input Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:53:51 --> Language Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Loader Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Controller Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Model Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Model Class Initialized
DEBUG - 2011-08-08 23:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:53:51 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:53:53 --> Final output sent to browser
DEBUG - 2011-08-08 23:53:53 --> Total execution time: 1.6061
DEBUG - 2011-08-08 23:53:55 --> Config Class Initialized
DEBUG - 2011-08-08 23:53:55 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:53:55 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:53:55 --> URI Class Initialized
DEBUG - 2011-08-08 23:53:55 --> Router Class Initialized
ERROR - 2011-08-08 23:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 23:53:55 --> Config Class Initialized
DEBUG - 2011-08-08 23:53:55 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:53:55 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:53:55 --> URI Class Initialized
DEBUG - 2011-08-08 23:53:55 --> Router Class Initialized
ERROR - 2011-08-08 23:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-08 23:54:23 --> Config Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:54:23 --> URI Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Router Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Output Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Input Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:54:23 --> Language Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Loader Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Controller Class Initialized
ERROR - 2011-08-08 23:54:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:54:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:54:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:54:23 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:54:23 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:54:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:54:23 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:54:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:54:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:54:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:54:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:54:23 --> Final output sent to browser
DEBUG - 2011-08-08 23:54:23 --> Total execution time: 0.0280
DEBUG - 2011-08-08 23:54:23 --> Config Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:54:23 --> URI Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Router Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Output Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Input Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:54:23 --> Language Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Loader Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Controller Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:54:23 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:54:25 --> Final output sent to browser
DEBUG - 2011-08-08 23:54:25 --> Total execution time: 1.5938
DEBUG - 2011-08-08 23:54:38 --> Config Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:54:38 --> URI Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Router Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Output Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Input Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:54:38 --> Language Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Loader Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Controller Class Initialized
ERROR - 2011-08-08 23:54:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:54:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:54:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:54:38 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:54:38 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:54:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:54:38 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:54:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:54:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:54:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:54:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:54:38 --> Final output sent to browser
DEBUG - 2011-08-08 23:54:38 --> Total execution time: 0.0289
DEBUG - 2011-08-08 23:54:38 --> Config Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:54:38 --> URI Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Router Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Output Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Input Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:54:38 --> Language Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Loader Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Controller Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:54:38 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:54:40 --> Final output sent to browser
DEBUG - 2011-08-08 23:54:40 --> Total execution time: 1.4357
DEBUG - 2011-08-08 23:54:56 --> Config Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:54:56 --> URI Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Router Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Output Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Input Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:54:56 --> Language Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Loader Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Controller Class Initialized
ERROR - 2011-08-08 23:54:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:54:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:54:56 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:54:56 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:54:56 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:54:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:54:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:54:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:54:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:54:56 --> Final output sent to browser
DEBUG - 2011-08-08 23:54:56 --> Total execution time: 0.0483
DEBUG - 2011-08-08 23:54:56 --> Config Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:54:56 --> URI Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Router Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Output Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Input Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:54:56 --> Language Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Loader Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Controller Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Model Class Initialized
DEBUG - 2011-08-08 23:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:54:56 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:54:58 --> Final output sent to browser
DEBUG - 2011-08-08 23:54:58 --> Total execution time: 1.7545
DEBUG - 2011-08-08 23:55:45 --> Config Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:55:45 --> URI Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Router Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Output Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Input Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:55:45 --> Language Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Loader Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Controller Class Initialized
ERROR - 2011-08-08 23:55:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:55:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-08-08 23:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:55:45 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:55:45 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:55:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:55:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:55:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:55:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:55:45 --> Final output sent to browser
DEBUG - 2011-08-08 23:55:45 --> Total execution time: 0.0536
DEBUG - 2011-08-08 23:55:46 --> Config Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:55:46 --> URI Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Router Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Output Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Input Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:55:46 --> Language Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Loader Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Controller Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Model Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Model Class Initialized
DEBUG - 2011-08-08 23:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:55:46 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:55:47 --> Final output sent to browser
DEBUG - 2011-08-08 23:55:47 --> Total execution time: 1.1199
DEBUG - 2011-08-08 23:56:06 --> Config Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:56:06 --> URI Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Router Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Output Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Input Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:56:06 --> Language Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Loader Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Controller Class Initialized
ERROR - 2011-08-08 23:56:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:56:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:56:06 --> Model Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Model Class Initialized
DEBUG - 2011-08-08 23:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:56:06 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:56:06 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:56:06 --> Final output sent to browser
DEBUG - 2011-08-08 23:56:06 --> Total execution time: 0.0300
DEBUG - 2011-08-08 23:56:07 --> Config Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:56:07 --> URI Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Router Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Output Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Input Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:56:07 --> Language Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Loader Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Controller Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Model Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Model Class Initialized
DEBUG - 2011-08-08 23:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:56:07 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:56:08 --> Final output sent to browser
DEBUG - 2011-08-08 23:56:08 --> Total execution time: 1.0417
DEBUG - 2011-08-08 23:57:27 --> Config Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:57:27 --> URI Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Router Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Output Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Input Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:57:27 --> Language Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Loader Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Controller Class Initialized
ERROR - 2011-08-08 23:57:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:57:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:57:27 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:57:27 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:57:27 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:57:27 --> Final output sent to browser
DEBUG - 2011-08-08 23:57:27 --> Total execution time: 0.0275
DEBUG - 2011-08-08 23:57:27 --> Config Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:57:27 --> URI Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Router Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Output Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Input Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:57:27 --> Language Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Loader Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Controller Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:57:27 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:57:28 --> Final output sent to browser
DEBUG - 2011-08-08 23:57:28 --> Total execution time: 1.0145
DEBUG - 2011-08-08 23:57:42 --> Config Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:57:42 --> URI Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Router Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Output Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Input Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:57:42 --> Language Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Loader Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Controller Class Initialized
ERROR - 2011-08-08 23:57:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-08 23:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-08 23:57:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:57:42 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:57:42 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:57:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-08 23:57:42 --> Helper loaded: url_helper
DEBUG - 2011-08-08 23:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-08 23:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-08 23:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-08 23:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-08 23:57:42 --> Final output sent to browser
DEBUG - 2011-08-08 23:57:42 --> Total execution time: 0.0280
DEBUG - 2011-08-08 23:57:42 --> Config Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Hooks Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Utf8 Class Initialized
DEBUG - 2011-08-08 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-08 23:57:42 --> URI Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Router Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Output Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Input Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-08 23:57:42 --> Language Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Loader Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Controller Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Model Class Initialized
DEBUG - 2011-08-08 23:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-08 23:57:42 --> Database Driver Class Initialized
DEBUG - 2011-08-08 23:57:43 --> Final output sent to browser
DEBUG - 2011-08-08 23:57:43 --> Total execution time: 0.9219

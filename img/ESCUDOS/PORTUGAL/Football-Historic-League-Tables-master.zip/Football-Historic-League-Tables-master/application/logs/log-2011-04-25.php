<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-25 00:05:06 --> Config Class Initialized
DEBUG - 2011-04-25 00:05:06 --> Hooks Class Initialized
DEBUG - 2011-04-25 00:05:06 --> Utf8 Class Initialized
DEBUG - 2011-04-25 00:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 00:05:06 --> URI Class Initialized
DEBUG - 2011-04-25 00:05:06 --> Router Class Initialized
ERROR - 2011-04-25 00:05:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-25 00:05:54 --> Config Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Hooks Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Utf8 Class Initialized
DEBUG - 2011-04-25 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 00:05:54 --> URI Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Router Class Initialized
DEBUG - 2011-04-25 00:05:54 --> No URI present. Default controller set.
DEBUG - 2011-04-25 00:05:54 --> Output Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Input Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 00:05:54 --> Language Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Loader Class Initialized
DEBUG - 2011-04-25 00:05:54 --> Controller Class Initialized
DEBUG - 2011-04-25 00:05:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-25 00:05:54 --> Helper loaded: url_helper
DEBUG - 2011-04-25 00:05:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 00:05:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 00:05:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 00:05:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 00:05:54 --> Final output sent to browser
DEBUG - 2011-04-25 00:05:54 --> Total execution time: 0.3222
DEBUG - 2011-04-25 00:43:23 --> Config Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Hooks Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Utf8 Class Initialized
DEBUG - 2011-04-25 00:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 00:43:23 --> URI Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Router Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Output Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Input Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 00:43:23 --> Language Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Loader Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Controller Class Initialized
ERROR - 2011-04-25 00:43:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 00:43:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 00:43:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 00:43:23 --> Model Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Model Class Initialized
DEBUG - 2011-04-25 00:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 00:43:23 --> Database Driver Class Initialized
DEBUG - 2011-04-25 00:43:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 00:43:23 --> Helper loaded: url_helper
DEBUG - 2011-04-25 00:43:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 00:43:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 00:43:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 00:43:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 00:43:23 --> Final output sent to browser
DEBUG - 2011-04-25 00:43:23 --> Total execution time: 0.3814
DEBUG - 2011-04-25 00:43:27 --> Config Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 00:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 00:43:27 --> URI Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Router Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Output Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Input Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 00:43:27 --> Language Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Loader Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Controller Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Model Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Model Class Initialized
DEBUG - 2011-04-25 00:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 00:43:27 --> Database Driver Class Initialized
DEBUG - 2011-04-25 00:43:28 --> Final output sent to browser
DEBUG - 2011-04-25 00:43:28 --> Total execution time: 0.6192
DEBUG - 2011-04-25 00:43:30 --> Config Class Initialized
DEBUG - 2011-04-25 00:43:30 --> Hooks Class Initialized
DEBUG - 2011-04-25 00:43:30 --> Utf8 Class Initialized
DEBUG - 2011-04-25 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 00:43:30 --> URI Class Initialized
DEBUG - 2011-04-25 00:43:30 --> Router Class Initialized
ERROR - 2011-04-25 00:43:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 00:43:30 --> Config Class Initialized
DEBUG - 2011-04-25 00:43:30 --> Hooks Class Initialized
DEBUG - 2011-04-25 00:43:30 --> Utf8 Class Initialized
DEBUG - 2011-04-25 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 00:43:30 --> URI Class Initialized
DEBUG - 2011-04-25 00:43:30 --> Router Class Initialized
ERROR - 2011-04-25 00:43:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 01:03:19 --> Config Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Hooks Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Utf8 Class Initialized
DEBUG - 2011-04-25 01:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 01:03:19 --> URI Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Router Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Output Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Input Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 01:03:19 --> Language Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Loader Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Controller Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Model Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Model Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Model Class Initialized
DEBUG - 2011-04-25 01:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 01:03:19 --> Database Driver Class Initialized
DEBUG - 2011-04-25 01:03:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 01:03:19 --> Helper loaded: url_helper
DEBUG - 2011-04-25 01:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 01:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 01:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 01:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 01:03:19 --> Final output sent to browser
DEBUG - 2011-04-25 01:03:19 --> Total execution time: 0.7745
DEBUG - 2011-04-25 01:03:20 --> Config Class Initialized
DEBUG - 2011-04-25 01:03:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 01:03:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 01:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 01:03:20 --> URI Class Initialized
DEBUG - 2011-04-25 01:03:20 --> Router Class Initialized
DEBUG - 2011-04-25 01:03:20 --> Output Class Initialized
DEBUG - 2011-04-25 01:03:20 --> Input Class Initialized
DEBUG - 2011-04-25 01:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 01:03:20 --> Language Class Initialized
DEBUG - 2011-04-25 01:03:21 --> Loader Class Initialized
DEBUG - 2011-04-25 01:03:21 --> Controller Class Initialized
ERROR - 2011-04-25 01:03:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 01:03:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 01:03:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 01:03:21 --> Model Class Initialized
DEBUG - 2011-04-25 01:03:21 --> Model Class Initialized
DEBUG - 2011-04-25 01:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 01:03:21 --> Database Driver Class Initialized
DEBUG - 2011-04-25 01:03:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 01:03:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 01:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 01:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 01:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 01:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 01:03:21 --> Final output sent to browser
DEBUG - 2011-04-25 01:03:21 --> Total execution time: 0.0900
DEBUG - 2011-04-25 02:14:05 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:05 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:05 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:05 --> Controller Class Initialized
ERROR - 2011-04-25 02:14:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:14:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:06 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:06 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:06 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:14:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:14:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:14:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:14:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:14:07 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:07 --> Total execution time: 2.5033
DEBUG - 2011-04-25 02:14:10 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:10 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:10 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Controller Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:10 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:11 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:11 --> Total execution time: 1.6115
DEBUG - 2011-04-25 02:14:14 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:14 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:14 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:14 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:14 --> Router Class Initialized
ERROR - 2011-04-25 02:14:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 02:14:42 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:42 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:42 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Controller Class Initialized
ERROR - 2011-04-25 02:14:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:14:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:14:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:42 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:42 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:42 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:14:42 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:42 --> Total execution time: 0.0621
DEBUG - 2011-04-25 02:14:44 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:44 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:44 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Controller Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:44 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:45 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:45 --> Total execution time: 0.6034
DEBUG - 2011-04-25 02:14:53 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:53 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:53 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Controller Class Initialized
ERROR - 2011-04-25 02:14:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:14:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:53 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:53 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:53 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:14:53 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:53 --> Total execution time: 0.1079
DEBUG - 2011-04-25 02:14:54 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:54 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:54 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Controller Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:54 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Config Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:14:57 --> URI Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Router Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Output Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Input Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:14:57 --> Language Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Loader Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Controller Class Initialized
ERROR - 2011-04-25 02:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:57 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Model Class Initialized
DEBUG - 2011-04-25 02:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:14:57 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:14:57 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:14:57 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:57 --> Total execution time: 0.0287
DEBUG - 2011-04-25 02:14:57 --> Final output sent to browser
DEBUG - 2011-04-25 02:14:57 --> Total execution time: 2.9569
DEBUG - 2011-04-25 02:15:14 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:14 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:14 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Controller Class Initialized
ERROR - 2011-04-25 02:15:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:14 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:14 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:14 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:15:14 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:14 --> Total execution time: 0.0297
DEBUG - 2011-04-25 02:15:16 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:16 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:16 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Controller Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:17 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:17 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Controller Class Initialized
ERROR - 2011-04-25 02:15:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:15:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:15:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:17 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:17 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:17 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:15:17 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:17 --> Total execution time: 0.0267
DEBUG - 2011-04-25 02:15:18 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:18 --> Total execution time: 1.9592
DEBUG - 2011-04-25 02:15:20 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:20 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:20 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Controller Class Initialized
ERROR - 2011-04-25 02:15:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:15:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:20 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:20 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:20 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:15:20 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:20 --> Total execution time: 0.0292
DEBUG - 2011-04-25 02:15:22 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:22 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:22 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Controller Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:22 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:28 --> Total execution time: 6.6421
DEBUG - 2011-04-25 02:15:28 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:28 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:28 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Controller Class Initialized
ERROR - 2011-04-25 02:15:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:15:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:15:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:28 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:28 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:28 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:15:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:15:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:15:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:15:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:15:29 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:29 --> Total execution time: 0.1447
DEBUG - 2011-04-25 02:15:42 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:42 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:42 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Controller Class Initialized
ERROR - 2011-04-25 02:15:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:15:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:42 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:42 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:15:42 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:15:42 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:42 --> Total execution time: 0.0772
DEBUG - 2011-04-25 02:15:43 --> Config Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:15:43 --> URI Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Router Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Output Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Input Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:15:43 --> Language Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Loader Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Controller Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Model Class Initialized
DEBUG - 2011-04-25 02:15:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:15:43 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:15:44 --> Final output sent to browser
DEBUG - 2011-04-25 02:15:44 --> Total execution time: 0.6556
DEBUG - 2011-04-25 02:16:12 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:12 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:12 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Controller Class Initialized
ERROR - 2011-04-25 02:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:12 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:16:12 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:12 --> Total execution time: 0.0321
DEBUG - 2011-04-25 02:16:13 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:13 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:13 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Controller Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:13 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:14 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:14 --> Total execution time: 0.6164
DEBUG - 2011-04-25 02:16:21 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:21 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:21 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Controller Class Initialized
ERROR - 2011-04-25 02:16:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:16:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:21 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:21 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:16:21 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:21 --> Total execution time: 0.0932
DEBUG - 2011-04-25 02:16:23 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:23 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:23 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Controller Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:23 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:24 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:24 --> Total execution time: 0.7922
DEBUG - 2011-04-25 02:16:44 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:44 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:44 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Controller Class Initialized
ERROR - 2011-04-25 02:16:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:16:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:44 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:44 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:44 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:16:44 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:44 --> Total execution time: 0.0394
DEBUG - 2011-04-25 02:16:46 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:46 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:46 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Controller Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:46 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Config Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:16:47 --> URI Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Router Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Output Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Input Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 02:16:47 --> Language Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Loader Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Controller Class Initialized
ERROR - 2011-04-25 02:16:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 02:16:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 02:16:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:47 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Model Class Initialized
DEBUG - 2011-04-25 02:16:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 02:16:47 --> Database Driver Class Initialized
DEBUG - 2011-04-25 02:16:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 02:16:47 --> Helper loaded: url_helper
DEBUG - 2011-04-25 02:16:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 02:16:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 02:16:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 02:16:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 02:16:47 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:47 --> Total execution time: 0.0633
DEBUG - 2011-04-25 02:16:47 --> Final output sent to browser
DEBUG - 2011-04-25 02:16:47 --> Total execution time: 1.3138
DEBUG - 2011-04-25 02:20:21 --> Config Class Initialized
DEBUG - 2011-04-25 02:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 02:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 02:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 02:20:21 --> URI Class Initialized
DEBUG - 2011-04-25 02:20:21 --> Router Class Initialized
ERROR - 2011-04-25 02:20:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 03:19:02 --> Config Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:19:02 --> URI Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Router Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Output Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Input Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:19:02 --> Language Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Loader Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Controller Class Initialized
ERROR - 2011-04-25 03:19:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:19:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:19:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:19:02 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:19:02 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:19:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:19:02 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:19:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:19:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:19:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:19:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:19:02 --> Final output sent to browser
DEBUG - 2011-04-25 03:19:02 --> Total execution time: 0.2994
DEBUG - 2011-04-25 03:19:04 --> Config Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:19:04 --> URI Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Router Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Output Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Input Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:19:04 --> Language Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Loader Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Controller Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:19:04 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:19:05 --> Final output sent to browser
DEBUG - 2011-04-25 03:19:05 --> Total execution time: 0.8992
DEBUG - 2011-04-25 03:19:31 --> Config Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:19:31 --> URI Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Router Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Output Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Input Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:19:31 --> Language Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Loader Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Controller Class Initialized
ERROR - 2011-04-25 03:19:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:19:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:19:31 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:19:31 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:19:31 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:19:31 --> Final output sent to browser
DEBUG - 2011-04-25 03:19:31 --> Total execution time: 0.0783
DEBUG - 2011-04-25 03:19:32 --> Config Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:19:32 --> URI Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Router Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Output Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Input Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:19:32 --> Language Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Loader Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Controller Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:19:32 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:19:33 --> Final output sent to browser
DEBUG - 2011-04-25 03:19:33 --> Total execution time: 0.9779
DEBUG - 2011-04-25 03:19:47 --> Config Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:19:47 --> URI Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Router Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Output Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Input Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:19:47 --> Language Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Loader Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Controller Class Initialized
ERROR - 2011-04-25 03:19:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:19:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:19:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:19:47 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:19:47 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:19:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:19:47 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:19:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:19:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:19:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:19:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:19:47 --> Final output sent to browser
DEBUG - 2011-04-25 03:19:47 --> Total execution time: 0.0310
DEBUG - 2011-04-25 03:19:48 --> Config Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:19:48 --> URI Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Router Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Output Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Input Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:19:48 --> Language Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Loader Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Controller Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Model Class Initialized
DEBUG - 2011-04-25 03:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:19:48 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:19:49 --> Final output sent to browser
DEBUG - 2011-04-25 03:19:49 --> Total execution time: 0.6005
DEBUG - 2011-04-25 03:34:55 --> Config Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:34:55 --> URI Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Router Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Output Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Input Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:34:55 --> Language Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Loader Class Initialized
DEBUG - 2011-04-25 03:34:55 --> Controller Class Initialized
ERROR - 2011-04-25 03:34:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:34:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:34:56 --> Model Class Initialized
DEBUG - 2011-04-25 03:34:56 --> Model Class Initialized
DEBUG - 2011-04-25 03:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:34:56 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:34:56 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:34:56 --> Final output sent to browser
DEBUG - 2011-04-25 03:34:56 --> Total execution time: 1.3934
DEBUG - 2011-04-25 03:34:57 --> Config Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:34:57 --> URI Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Router Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Output Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Input Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:34:57 --> Language Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Loader Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Controller Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Model Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Model Class Initialized
DEBUG - 2011-04-25 03:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:34:57 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:34:58 --> Final output sent to browser
DEBUG - 2011-04-25 03:34:58 --> Total execution time: 0.6479
DEBUG - 2011-04-25 03:35:21 --> Config Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:35:21 --> URI Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Router Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Output Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Input Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:35:21 --> Language Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Loader Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Controller Class Initialized
ERROR - 2011-04-25 03:35:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:35:21 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:35:21 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:35:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:35:21 --> Final output sent to browser
DEBUG - 2011-04-25 03:35:21 --> Total execution time: 0.1809
DEBUG - 2011-04-25 03:35:22 --> Config Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:35:22 --> URI Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Router Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Output Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Input Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:35:22 --> Language Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Loader Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Controller Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:35:22 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:35:24 --> Final output sent to browser
DEBUG - 2011-04-25 03:35:24 --> Total execution time: 2.0551
DEBUG - 2011-04-25 03:35:29 --> Config Class Initialized
DEBUG - 2011-04-25 03:35:29 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:35:29 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:35:29 --> URI Class Initialized
DEBUG - 2011-04-25 03:35:29 --> Router Class Initialized
ERROR - 2011-04-25 03:35:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 03:35:34 --> Config Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:35:34 --> URI Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Router Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Output Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Input Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:35:34 --> Language Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Loader Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Controller Class Initialized
ERROR - 2011-04-25 03:35:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:35:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:35:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:35:34 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:35:34 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:35:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:35:34 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:35:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:35:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:35:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:35:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:35:34 --> Final output sent to browser
DEBUG - 2011-04-25 03:35:34 --> Total execution time: 0.0362
DEBUG - 2011-04-25 03:35:35 --> Config Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:35:35 --> URI Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Router Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Output Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Input Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:35:35 --> Language Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Loader Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Controller Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Model Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:35:35 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:35:35 --> Final output sent to browser
DEBUG - 2011-04-25 03:35:35 --> Total execution time: 0.5903
DEBUG - 2011-04-25 03:44:08 --> Config Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:44:08 --> URI Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Router Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Output Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Input Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:44:08 --> Language Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Loader Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Controller Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Model Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Model Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Model Class Initialized
DEBUG - 2011-04-25 03:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:44:08 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:44:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 03:44:10 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:44:10 --> Final output sent to browser
DEBUG - 2011-04-25 03:44:10 --> Total execution time: 2.4236
DEBUG - 2011-04-25 03:44:11 --> Config Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Hooks Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Utf8 Class Initialized
DEBUG - 2011-04-25 03:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 03:44:11 --> URI Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Router Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Output Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Input Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 03:44:11 --> Language Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Loader Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Controller Class Initialized
ERROR - 2011-04-25 03:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 03:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 03:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:44:11 --> Model Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Model Class Initialized
DEBUG - 2011-04-25 03:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 03:44:11 --> Database Driver Class Initialized
DEBUG - 2011-04-25 03:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 03:44:11 --> Helper loaded: url_helper
DEBUG - 2011-04-25 03:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 03:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 03:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 03:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 03:44:11 --> Final output sent to browser
DEBUG - 2011-04-25 03:44:11 --> Total execution time: 0.0420
DEBUG - 2011-04-25 05:26:25 --> Config Class Initialized
DEBUG - 2011-04-25 05:26:25 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:26:25 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:26:25 --> URI Class Initialized
DEBUG - 2011-04-25 05:26:25 --> Router Class Initialized
DEBUG - 2011-04-25 05:26:25 --> Output Class Initialized
DEBUG - 2011-04-25 05:26:25 --> Input Class Initialized
DEBUG - 2011-04-25 05:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:26:25 --> Language Class Initialized
DEBUG - 2011-04-25 05:26:26 --> Loader Class Initialized
DEBUG - 2011-04-25 05:26:26 --> Controller Class Initialized
DEBUG - 2011-04-25 05:26:26 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:26 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:26 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:26:26 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:26:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:26:26 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:26:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:26:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:26:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:26:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:26:26 --> Final output sent to browser
DEBUG - 2011-04-25 05:26:26 --> Total execution time: 1.0648
DEBUG - 2011-04-25 05:26:28 --> Config Class Initialized
DEBUG - 2011-04-25 05:26:28 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:26:28 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:26:28 --> URI Class Initialized
DEBUG - 2011-04-25 05:26:28 --> Router Class Initialized
ERROR - 2011-04-25 05:26:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 05:26:28 --> Config Class Initialized
DEBUG - 2011-04-25 05:26:28 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:26:28 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:26:28 --> URI Class Initialized
DEBUG - 2011-04-25 05:26:28 --> Router Class Initialized
ERROR - 2011-04-25 05:26:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 05:26:43 --> Config Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:26:43 --> URI Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Router Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Output Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Input Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:26:43 --> Language Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Loader Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Controller Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:26:43 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:26:43 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:26:43 --> Final output sent to browser
DEBUG - 2011-04-25 05:26:43 --> Total execution time: 0.2941
DEBUG - 2011-04-25 05:26:48 --> Config Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:26:48 --> URI Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Router Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Output Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Input Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:26:48 --> Language Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Loader Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Controller Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:26:48 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:26:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:26:48 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:26:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:26:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:26:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:26:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:26:48 --> Final output sent to browser
DEBUG - 2011-04-25 05:26:48 --> Total execution time: 0.2395
DEBUG - 2011-04-25 05:26:54 --> Config Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:26:54 --> URI Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Router Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Output Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Input Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:26:54 --> Language Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Loader Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Controller Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Model Class Initialized
DEBUG - 2011-04-25 05:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:26:54 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:26:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:26:55 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:26:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:26:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:26:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:26:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:26:55 --> Final output sent to browser
DEBUG - 2011-04-25 05:26:55 --> Total execution time: 0.2888
DEBUG - 2011-04-25 05:27:01 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:01 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:01 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:02 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:02 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:02 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:02 --> Total execution time: 0.2708
DEBUG - 2011-04-25 05:27:05 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:05 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:05 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:05 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:05 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:05 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:05 --> Total execution time: 0.0653
DEBUG - 2011-04-25 05:27:06 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:06 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:06 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:06 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:06 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:06 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:06 --> Total execution time: 0.0515
DEBUG - 2011-04-25 05:27:07 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:07 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:07 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:07 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:07 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:07 --> Total execution time: 0.0566
DEBUG - 2011-04-25 05:27:07 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:07 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:07 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:07 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:07 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:07 --> Total execution time: 0.0671
DEBUG - 2011-04-25 05:27:08 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:08 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:08 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:08 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:08 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:08 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:08 --> Total execution time: 0.8363
DEBUG - 2011-04-25 05:27:10 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:10 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:10 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:10 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:10 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:10 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:10 --> Total execution time: 0.0639
DEBUG - 2011-04-25 05:27:26 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:26 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:26 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:26 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:27 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:27 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:27 --> Total execution time: 0.3312
DEBUG - 2011-04-25 05:27:30 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:30 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:30 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:30 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:30 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:30 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:30 --> Total execution time: 0.0944
DEBUG - 2011-04-25 05:27:35 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:35 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:35 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:35 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:38 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:38 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:38 --> Total execution time: 3.3799
DEBUG - 2011-04-25 05:27:44 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:44 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:44 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:44 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:44 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:44 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:44 --> Total execution time: 0.0542
DEBUG - 2011-04-25 05:27:54 --> Config Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:27:54 --> URI Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Router Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Output Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Input Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:27:54 --> Language Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Loader Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Controller Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Model Class Initialized
DEBUG - 2011-04-25 05:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:27:54 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:27:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:27:59 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:27:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:27:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:27:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:27:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:27:59 --> Final output sent to browser
DEBUG - 2011-04-25 05:27:59 --> Total execution time: 4.9847
DEBUG - 2011-04-25 05:28:00 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:00 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:00 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:00 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:01 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:01 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:01 --> Total execution time: 0.2175
DEBUG - 2011-04-25 05:28:07 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:07 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:07 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:07 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:07 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:07 --> Total execution time: 0.4278
DEBUG - 2011-04-25 05:28:08 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:08 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:08 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:08 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:08 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:08 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:08 --> Total execution time: 0.0532
DEBUG - 2011-04-25 05:28:14 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:14 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:14 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:14 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:14 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:14 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:14 --> Total execution time: 0.2965
DEBUG - 2011-04-25 05:28:16 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:16 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:16 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:16 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:16 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:16 --> Total execution time: 0.0629
DEBUG - 2011-04-25 05:28:27 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:27 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:27 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:27 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:28 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:28 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:28 --> Total execution time: 0.4380
DEBUG - 2011-04-25 05:28:30 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:30 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:30 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:30 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:30 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:30 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:30 --> Total execution time: 0.0476
DEBUG - 2011-04-25 05:28:34 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:34 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:34 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:34 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:35 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:35 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:35 --> Total execution time: 0.4198
DEBUG - 2011-04-25 05:28:36 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:36 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:36 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:36 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:36 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:36 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:36 --> Total execution time: 0.0487
DEBUG - 2011-04-25 05:28:46 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:46 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:46 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:46 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:46 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:46 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:46 --> Total execution time: 0.4993
DEBUG - 2011-04-25 05:28:47 --> Config Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Hooks Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Utf8 Class Initialized
DEBUG - 2011-04-25 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 05:28:47 --> URI Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Router Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Output Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Input Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 05:28:47 --> Language Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Loader Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Controller Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Model Class Initialized
DEBUG - 2011-04-25 05:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 05:28:47 --> Database Driver Class Initialized
DEBUG - 2011-04-25 05:28:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 05:28:47 --> Helper loaded: url_helper
DEBUG - 2011-04-25 05:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 05:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 05:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 05:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 05:28:47 --> Final output sent to browser
DEBUG - 2011-04-25 05:28:47 --> Total execution time: 0.0550
DEBUG - 2011-04-25 06:47:10 --> Config Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Hooks Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Utf8 Class Initialized
DEBUG - 2011-04-25 06:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 06:47:10 --> URI Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Router Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Output Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Input Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 06:47:10 --> Language Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Loader Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Controller Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Model Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Model Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Model Class Initialized
DEBUG - 2011-04-25 06:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 06:47:10 --> Database Driver Class Initialized
DEBUG - 2011-04-25 06:47:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 06:47:11 --> Helper loaded: url_helper
DEBUG - 2011-04-25 06:47:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 06:47:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 06:47:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 06:47:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 06:47:11 --> Final output sent to browser
DEBUG - 2011-04-25 06:47:11 --> Total execution time: 0.5783
DEBUG - 2011-04-25 06:47:12 --> Config Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 06:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 06:47:12 --> URI Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Router Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Output Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Input Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 06:47:12 --> Language Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Loader Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Controller Class Initialized
ERROR - 2011-04-25 06:47:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 06:47:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 06:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 06:47:12 --> Model Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Model Class Initialized
DEBUG - 2011-04-25 06:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 06:47:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 06:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 06:47:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 06:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 06:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 06:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 06:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 06:47:12 --> Final output sent to browser
DEBUG - 2011-04-25 06:47:12 --> Total execution time: 0.0982
DEBUG - 2011-04-25 07:07:29 --> Config Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:07:29 --> URI Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Router Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Output Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Input Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 07:07:29 --> Language Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Loader Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Controller Class Initialized
ERROR - 2011-04-25 07:07:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 07:07:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 07:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 07:07:29 --> Model Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Model Class Initialized
DEBUG - 2011-04-25 07:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 07:07:30 --> Database Driver Class Initialized
DEBUG - 2011-04-25 07:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 07:07:30 --> Helper loaded: url_helper
DEBUG - 2011-04-25 07:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 07:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 07:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 07:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 07:07:30 --> Final output sent to browser
DEBUG - 2011-04-25 07:07:30 --> Total execution time: 0.3157
DEBUG - 2011-04-25 07:07:31 --> Config Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:07:31 --> URI Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Router Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Output Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Input Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 07:07:31 --> Language Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Loader Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Controller Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Model Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Model Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 07:07:31 --> Database Driver Class Initialized
DEBUG - 2011-04-25 07:07:31 --> Final output sent to browser
DEBUG - 2011-04-25 07:07:31 --> Total execution time: 0.6449
DEBUG - 2011-04-25 07:07:33 --> Config Class Initialized
DEBUG - 2011-04-25 07:07:33 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:07:33 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:07:33 --> URI Class Initialized
DEBUG - 2011-04-25 07:07:33 --> Router Class Initialized
ERROR - 2011-04-25 07:07:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 07:07:34 --> Config Class Initialized
DEBUG - 2011-04-25 07:07:34 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:07:34 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:07:34 --> URI Class Initialized
DEBUG - 2011-04-25 07:07:34 --> Router Class Initialized
ERROR - 2011-04-25 07:07:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 07:07:59 --> Config Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:07:59 --> URI Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Router Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Output Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Input Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 07:07:59 --> Language Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Loader Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Controller Class Initialized
ERROR - 2011-04-25 07:07:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 07:07:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 07:07:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 07:07:59 --> Model Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Model Class Initialized
DEBUG - 2011-04-25 07:07:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 07:07:59 --> Database Driver Class Initialized
DEBUG - 2011-04-25 07:07:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 07:07:59 --> Helper loaded: url_helper
DEBUG - 2011-04-25 07:07:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 07:07:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 07:07:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 07:07:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 07:07:59 --> Final output sent to browser
DEBUG - 2011-04-25 07:07:59 --> Total execution time: 0.0283
DEBUG - 2011-04-25 07:08:00 --> Config Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:08:00 --> URI Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Router Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Output Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Input Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 07:08:00 --> Language Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Loader Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Controller Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Model Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Model Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 07:08:00 --> Database Driver Class Initialized
DEBUG - 2011-04-25 07:08:00 --> Final output sent to browser
DEBUG - 2011-04-25 07:08:00 --> Total execution time: 0.5705
DEBUG - 2011-04-25 07:43:55 --> Config Class Initialized
DEBUG - 2011-04-25 07:43:55 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:43:55 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:43:55 --> URI Class Initialized
DEBUG - 2011-04-25 07:43:55 --> Router Class Initialized
ERROR - 2011-04-25 07:43:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-25 07:44:31 --> Config Class Initialized
DEBUG - 2011-04-25 07:44:31 --> Hooks Class Initialized
DEBUG - 2011-04-25 07:44:31 --> Utf8 Class Initialized
DEBUG - 2011-04-25 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 07:44:31 --> URI Class Initialized
DEBUG - 2011-04-25 07:44:31 --> Router Class Initialized
DEBUG - 2011-04-25 07:44:31 --> Output Class Initialized
DEBUG - 2011-04-25 07:44:31 --> Input Class Initialized
DEBUG - 2011-04-25 07:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 07:44:31 --> Language Class Initialized
DEBUG - 2011-04-25 07:44:32 --> Loader Class Initialized
DEBUG - 2011-04-25 07:44:32 --> Controller Class Initialized
DEBUG - 2011-04-25 07:44:32 --> Model Class Initialized
DEBUG - 2011-04-25 07:44:32 --> Model Class Initialized
DEBUG - 2011-04-25 07:44:32 --> Model Class Initialized
DEBUG - 2011-04-25 07:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 07:44:32 --> Database Driver Class Initialized
DEBUG - 2011-04-25 07:44:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 07:44:32 --> Helper loaded: url_helper
DEBUG - 2011-04-25 07:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 07:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 07:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 07:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 07:44:32 --> Final output sent to browser
DEBUG - 2011-04-25 07:44:32 --> Total execution time: 0.5623
DEBUG - 2011-04-25 08:15:27 --> Config Class Initialized
DEBUG - 2011-04-25 08:15:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:15:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:15:27 --> URI Class Initialized
DEBUG - 2011-04-25 08:15:27 --> Router Class Initialized
DEBUG - 2011-04-25 08:15:27 --> Output Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Input Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:15:28 --> Language Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Loader Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Controller Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Model Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Model Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Model Class Initialized
DEBUG - 2011-04-25 08:15:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:15:28 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:15:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:15:51 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:15:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:15:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:15:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:15:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:15:51 --> Final output sent to browser
DEBUG - 2011-04-25 08:15:51 --> Total execution time: 23.5520
DEBUG - 2011-04-25 08:15:53 --> Config Class Initialized
DEBUG - 2011-04-25 08:15:53 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:15:53 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:15:53 --> URI Class Initialized
DEBUG - 2011-04-25 08:15:53 --> Router Class Initialized
ERROR - 2011-04-25 08:15:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 08:24:25 --> Config Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:24:25 --> URI Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Router Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Output Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Input Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:24:25 --> Language Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Loader Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Controller Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:24:25 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:24:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:24:32 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:24:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:24:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:24:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:24:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:24:32 --> Final output sent to browser
DEBUG - 2011-04-25 08:24:32 --> Total execution time: 7.0214
DEBUG - 2011-04-25 08:24:37 --> Config Class Initialized
DEBUG - 2011-04-25 08:24:37 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:24:37 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:24:37 --> URI Class Initialized
DEBUG - 2011-04-25 08:24:37 --> Router Class Initialized
ERROR - 2011-04-25 08:24:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-25 08:24:38 --> Config Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:24:38 --> URI Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Router Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Output Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Input Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:24:38 --> Language Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Loader Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Controller Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:24:38 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:24:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:24:38 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:24:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:24:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:24:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:24:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:24:38 --> Final output sent to browser
DEBUG - 2011-04-25 08:24:38 --> Total execution time: 0.0822
DEBUG - 2011-04-25 08:24:57 --> Config Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:24:57 --> URI Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Router Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Output Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Input Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:24:57 --> Language Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Loader Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Controller Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:24:57 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:24:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:24:57 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:24:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:24:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:24:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:24:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:24:57 --> Final output sent to browser
DEBUG - 2011-04-25 08:24:57 --> Total execution time: 0.2721
DEBUG - 2011-04-25 08:24:58 --> Config Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:24:58 --> URI Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Router Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Output Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Input Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:24:58 --> Language Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Loader Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Controller Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Model Class Initialized
DEBUG - 2011-04-25 08:24:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:24:58 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:24:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:24:58 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:24:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:24:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:24:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:24:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:24:58 --> Final output sent to browser
DEBUG - 2011-04-25 08:24:58 --> Total execution time: 0.0424
DEBUG - 2011-04-25 08:25:05 --> Config Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:25:05 --> URI Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Router Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Output Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Input Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:25:05 --> Language Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Loader Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Controller Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:25:05 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:25:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:25:06 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:25:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:25:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:25:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:25:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:25:06 --> Final output sent to browser
DEBUG - 2011-04-25 08:25:06 --> Total execution time: 0.6718
DEBUG - 2011-04-25 08:25:07 --> Config Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:25:07 --> URI Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Router Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Output Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Input Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:25:07 --> Language Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Loader Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Controller Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:25:07 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:25:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:25:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:25:07 --> Final output sent to browser
DEBUG - 2011-04-25 08:25:07 --> Total execution time: 0.0450
DEBUG - 2011-04-25 08:25:12 --> Config Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:25:12 --> URI Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Router Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Output Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Input Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:25:12 --> Language Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Loader Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Controller Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:25:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:25:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:25:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:25:12 --> Final output sent to browser
DEBUG - 2011-04-25 08:25:12 --> Total execution time: 0.3603
DEBUG - 2011-04-25 08:25:15 --> Config Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:25:15 --> URI Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Router Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Output Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Input Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:25:15 --> Language Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Loader Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Controller Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:25:15 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:25:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:25:15 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:25:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:25:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:25:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:25:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:25:15 --> Final output sent to browser
DEBUG - 2011-04-25 08:25:15 --> Total execution time: 0.0431
DEBUG - 2011-04-25 08:25:21 --> Config Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:25:21 --> URI Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Router Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Output Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Input Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:25:21 --> Language Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Loader Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Controller Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:25:21 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:25:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:25:22 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:25:22 --> Final output sent to browser
DEBUG - 2011-04-25 08:25:22 --> Total execution time: 0.7105
DEBUG - 2011-04-25 08:25:23 --> Config Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:25:23 --> URI Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Router Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Output Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Input Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:25:23 --> Language Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Loader Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Controller Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Model Class Initialized
DEBUG - 2011-04-25 08:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:25:23 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:25:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:25:23 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:25:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:25:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:25:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:25:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:25:23 --> Final output sent to browser
DEBUG - 2011-04-25 08:25:23 --> Total execution time: 0.0528
DEBUG - 2011-04-25 08:26:20 --> Config Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:26:20 --> URI Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Router Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Output Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Input Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:26:20 --> Language Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Loader Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Controller Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:26:20 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:26:20 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:26:20 --> Final output sent to browser
DEBUG - 2011-04-25 08:26:20 --> Total execution time: 0.2207
DEBUG - 2011-04-25 08:26:21 --> Config Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:26:21 --> URI Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Router Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Output Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Input Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:26:21 --> Language Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Loader Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Controller Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:26:21 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:26:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:26:21 --> Final output sent to browser
DEBUG - 2011-04-25 08:26:21 --> Total execution time: 0.0663
DEBUG - 2011-04-25 08:26:45 --> Config Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:26:45 --> URI Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Router Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Output Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Input Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:26:45 --> Language Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Loader Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Controller Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:26:45 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:26:46 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:26:46 --> Final output sent to browser
DEBUG - 2011-04-25 08:26:46 --> Total execution time: 0.5281
DEBUG - 2011-04-25 08:26:50 --> Config Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Hooks Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Utf8 Class Initialized
DEBUG - 2011-04-25 08:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 08:26:50 --> URI Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Router Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Output Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Input Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 08:26:50 --> Language Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Loader Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Controller Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Model Class Initialized
DEBUG - 2011-04-25 08:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 08:26:50 --> Database Driver Class Initialized
DEBUG - 2011-04-25 08:26:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 08:26:50 --> Helper loaded: url_helper
DEBUG - 2011-04-25 08:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 08:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 08:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 08:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 08:26:50 --> Final output sent to browser
DEBUG - 2011-04-25 08:26:50 --> Total execution time: 0.0922
DEBUG - 2011-04-25 09:27:16 --> Config Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 09:27:16 --> URI Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Router Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Output Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Input Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 09:27:16 --> Language Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Loader Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Controller Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Model Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Model Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Model Class Initialized
DEBUG - 2011-04-25 09:27:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 09:27:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 09:27:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 09:27:17 --> Helper loaded: url_helper
DEBUG - 2011-04-25 09:27:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 09:27:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 09:27:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 09:27:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 09:27:17 --> Final output sent to browser
DEBUG - 2011-04-25 09:27:17 --> Total execution time: 0.7173
DEBUG - 2011-04-25 09:34:47 --> Config Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Hooks Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Utf8 Class Initialized
DEBUG - 2011-04-25 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 09:34:47 --> URI Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Router Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Output Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Input Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 09:34:47 --> Language Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Loader Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Controller Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Model Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Model Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Model Class Initialized
DEBUG - 2011-04-25 09:34:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 09:34:47 --> Database Driver Class Initialized
DEBUG - 2011-04-25 09:34:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 09:34:47 --> Helper loaded: url_helper
DEBUG - 2011-04-25 09:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 09:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 09:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 09:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 09:34:47 --> Final output sent to browser
DEBUG - 2011-04-25 09:34:47 --> Total execution time: 0.2170
DEBUG - 2011-04-25 09:34:49 --> Config Class Initialized
DEBUG - 2011-04-25 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-04-25 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-04-25 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 09:34:49 --> URI Class Initialized
DEBUG - 2011-04-25 09:34:49 --> Router Class Initialized
ERROR - 2011-04-25 09:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 09:34:50 --> Config Class Initialized
DEBUG - 2011-04-25 09:34:50 --> Hooks Class Initialized
DEBUG - 2011-04-25 09:34:50 --> Utf8 Class Initialized
DEBUG - 2011-04-25 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 09:34:50 --> URI Class Initialized
DEBUG - 2011-04-25 09:34:50 --> Router Class Initialized
ERROR - 2011-04-25 09:34:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 09:35:05 --> Config Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Hooks Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Utf8 Class Initialized
DEBUG - 2011-04-25 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 09:35:05 --> URI Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Router Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Output Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Input Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 09:35:05 --> Language Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Loader Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Controller Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Model Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Model Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Model Class Initialized
DEBUG - 2011-04-25 09:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 09:35:05 --> Database Driver Class Initialized
DEBUG - 2011-04-25 09:35:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 09:35:05 --> Helper loaded: url_helper
DEBUG - 2011-04-25 09:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 09:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 09:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 09:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 09:35:05 --> Final output sent to browser
DEBUG - 2011-04-25 09:35:05 --> Total execution time: 0.2747
DEBUG - 2011-04-25 10:02:49 --> Config Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:02:49 --> URI Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Router Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Output Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Input Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:02:49 --> Language Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Loader Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Controller Class Initialized
DEBUG - 2011-04-25 10:02:49 --> Model Class Initialized
DEBUG - 2011-04-25 10:02:50 --> Model Class Initialized
DEBUG - 2011-04-25 10:02:50 --> Model Class Initialized
DEBUG - 2011-04-25 10:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:02:50 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:02:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:02:50 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:02:50 --> Final output sent to browser
DEBUG - 2011-04-25 10:02:50 --> Total execution time: 0.8479
DEBUG - 2011-04-25 10:02:51 --> Config Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:02:51 --> URI Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Router Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Output Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Input Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:02:51 --> Language Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Loader Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Controller Class Initialized
ERROR - 2011-04-25 10:02:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 10:02:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 10:02:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 10:02:51 --> Model Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Model Class Initialized
DEBUG - 2011-04-25 10:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:02:51 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:02:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 10:02:51 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:02:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:02:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:02:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:02:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:02:51 --> Final output sent to browser
DEBUG - 2011-04-25 10:02:51 --> Total execution time: 0.2574
DEBUG - 2011-04-25 10:30:46 --> Config Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:30:46 --> URI Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Router Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Output Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Input Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:30:46 --> Language Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Loader Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Controller Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Model Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Model Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Model Class Initialized
DEBUG - 2011-04-25 10:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:30:46 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:30:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:30:47 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:30:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:30:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:30:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:30:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:30:47 --> Final output sent to browser
DEBUG - 2011-04-25 10:30:47 --> Total execution time: 1.1281
DEBUG - 2011-04-25 10:30:52 --> Config Class Initialized
DEBUG - 2011-04-25 10:30:52 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:30:52 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:30:52 --> URI Class Initialized
DEBUG - 2011-04-25 10:30:52 --> Router Class Initialized
ERROR - 2011-04-25 10:30:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:31:18 --> Config Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:31:18 --> URI Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Router Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Output Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Input Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:31:18 --> Language Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Loader Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Controller Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:31:18 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:31:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:31:19 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:31:19 --> Final output sent to browser
DEBUG - 2011-04-25 10:31:19 --> Total execution time: 1.0642
DEBUG - 2011-04-25 10:31:22 --> Config Class Initialized
DEBUG - 2011-04-25 10:31:22 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:31:22 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:31:22 --> URI Class Initialized
DEBUG - 2011-04-25 10:31:22 --> Router Class Initialized
ERROR - 2011-04-25 10:31:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:31:42 --> Config Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:31:42 --> URI Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Router Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Output Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Input Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:31:42 --> Language Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Loader Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Controller Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:31:42 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:31:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:31:42 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:31:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:31:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:31:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:31:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:31:42 --> Final output sent to browser
DEBUG - 2011-04-25 10:31:42 --> Total execution time: 0.3073
DEBUG - 2011-04-25 10:31:45 --> Config Class Initialized
DEBUG - 2011-04-25 10:31:45 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:31:45 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:31:45 --> URI Class Initialized
DEBUG - 2011-04-25 10:31:45 --> Router Class Initialized
ERROR - 2011-04-25 10:31:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:31:54 --> Config Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:31:54 --> URI Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Router Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Output Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Input Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:31:54 --> Language Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Loader Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Controller Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Model Class Initialized
DEBUG - 2011-04-25 10:31:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:31:54 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:31:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:31:54 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:31:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:31:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:31:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:31:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:31:54 --> Final output sent to browser
DEBUG - 2011-04-25 10:31:54 --> Total execution time: 0.0764
DEBUG - 2011-04-25 10:31:58 --> Config Class Initialized
DEBUG - 2011-04-25 10:31:58 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:31:58 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:31:58 --> URI Class Initialized
DEBUG - 2011-04-25 10:31:58 --> Router Class Initialized
ERROR - 2011-04-25 10:31:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:32:04 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:04 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:04 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:04 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:04 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:04 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:04 --> Total execution time: 0.0475
DEBUG - 2011-04-25 10:32:06 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:06 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:06 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:06 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:06 --> Router Class Initialized
ERROR - 2011-04-25 10:32:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:32:10 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:10 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:10 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:10 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:10 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:10 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:10 --> Total execution time: 0.1537
DEBUG - 2011-04-25 10:32:11 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:11 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:11 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:11 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:11 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:11 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:11 --> Total execution time: 0.4460
DEBUG - 2011-04-25 10:32:13 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:13 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:13 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:13 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:13 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:13 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:13 --> Total execution time: 0.0682
DEBUG - 2011-04-25 10:32:14 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:14 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:14 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:14 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:14 --> Router Class Initialized
ERROR - 2011-04-25 10:32:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:32:16 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:16 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:16 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:16 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:16 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:16 --> Total execution time: 0.0606
DEBUG - 2011-04-25 10:32:37 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:37 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:37 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:38 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:38 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:38 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:38 --> Total execution time: 0.5826
DEBUG - 2011-04-25 10:32:41 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:41 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Router Class Initialized
ERROR - 2011-04-25 10:32:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:32:41 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:41 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Router Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Output Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Input Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:32:41 --> Language Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Loader Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Controller Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Model Class Initialized
DEBUG - 2011-04-25 10:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:32:41 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:32:41 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:32:41 --> Final output sent to browser
DEBUG - 2011-04-25 10:32:41 --> Total execution time: 0.0721
DEBUG - 2011-04-25 10:32:53 --> Config Class Initialized
DEBUG - 2011-04-25 10:32:53 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:32:53 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:32:53 --> URI Class Initialized
DEBUG - 2011-04-25 10:32:53 --> Router Class Initialized
ERROR - 2011-04-25 10:32:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:33:33 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:33 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Router Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Output Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Input Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:33:33 --> Language Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Loader Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Controller Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:33:33 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:33:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:33:34 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:33:34 --> Final output sent to browser
DEBUG - 2011-04-25 10:33:34 --> Total execution time: 0.6253
DEBUG - 2011-04-25 10:33:36 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:36 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:36 --> Router Class Initialized
ERROR - 2011-04-25 10:33:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:33:41 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:41 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Router Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Output Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Input Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:33:41 --> Language Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Loader Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Controller Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:33:41 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:33:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:33:42 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:33:42 --> Final output sent to browser
DEBUG - 2011-04-25 10:33:42 --> Total execution time: 0.2127
DEBUG - 2011-04-25 10:33:43 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:43 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Router Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Output Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Input Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:33:43 --> Language Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Loader Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Controller Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:33:43 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:33:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:33:43 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:33:43 --> Final output sent to browser
DEBUG - 2011-04-25 10:33:43 --> Total execution time: 0.0465
DEBUG - 2011-04-25 10:33:44 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:44 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:44 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:44 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:44 --> Router Class Initialized
ERROR - 2011-04-25 10:33:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:33:45 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:45 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Router Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Output Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Input Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:33:45 --> Language Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Loader Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Controller Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:33:45 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:33:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:33:45 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:33:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:33:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:33:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:33:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:33:45 --> Final output sent to browser
DEBUG - 2011-04-25 10:33:45 --> Total execution time: 0.0897
DEBUG - 2011-04-25 10:33:53 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:53 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Router Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Output Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Input Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:33:53 --> Language Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Loader Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Controller Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:33:53 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:33:53 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:33:53 --> Final output sent to browser
DEBUG - 2011-04-25 10:33:53 --> Total execution time: 0.2076
DEBUG - 2011-04-25 10:33:55 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:55 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Router Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Output Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Input Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:33:55 --> Language Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Loader Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Controller Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Model Class Initialized
DEBUG - 2011-04-25 10:33:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:33:55 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:33:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:33:55 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:33:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:33:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:33:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:33:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:33:55 --> Final output sent to browser
DEBUG - 2011-04-25 10:33:55 --> Total execution time: 0.1026
DEBUG - 2011-04-25 10:33:56 --> Config Class Initialized
DEBUG - 2011-04-25 10:33:56 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:33:56 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:33:56 --> URI Class Initialized
DEBUG - 2011-04-25 10:33:56 --> Router Class Initialized
ERROR - 2011-04-25 10:33:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:34:07 --> Config Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:34:07 --> URI Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Router Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Output Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Input Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:34:07 --> Language Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Loader Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Controller Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:34:07 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:34:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:34:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:34:07 --> Final output sent to browser
DEBUG - 2011-04-25 10:34:07 --> Total execution time: 0.3221
DEBUG - 2011-04-25 10:34:09 --> Config Class Initialized
DEBUG - 2011-04-25 10:34:09 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:34:09 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:34:09 --> URI Class Initialized
DEBUG - 2011-04-25 10:34:09 --> Router Class Initialized
ERROR - 2011-04-25 10:34:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:34:17 --> Config Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:34:17 --> URI Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Router Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Output Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Input Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:34:17 --> Language Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Loader Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Controller Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:34:17 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:34:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:34:17 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:34:17 --> Final output sent to browser
DEBUG - 2011-04-25 10:34:17 --> Total execution time: 0.1106
DEBUG - 2011-04-25 10:34:17 --> Config Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:34:17 --> URI Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Router Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Output Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Input Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:34:17 --> Language Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Loader Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Controller Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:34:17 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:34:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:34:18 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:34:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:34:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:34:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:34:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:34:18 --> Final output sent to browser
DEBUG - 2011-04-25 10:34:18 --> Total execution time: 0.2664
DEBUG - 2011-04-25 10:34:19 --> Config Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:34:19 --> URI Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Router Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Output Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Input Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:34:19 --> Language Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Loader Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Controller Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Model Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:34:19 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:34:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:34:19 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:34:19 --> Final output sent to browser
DEBUG - 2011-04-25 10:34:19 --> Total execution time: 0.1057
DEBUG - 2011-04-25 10:34:19 --> Config Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:34:19 --> URI Class Initialized
DEBUG - 2011-04-25 10:34:19 --> Router Class Initialized
ERROR - 2011-04-25 10:34:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 10:36:42 --> Config Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Hooks Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Utf8 Class Initialized
DEBUG - 2011-04-25 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 10:36:42 --> URI Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Router Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Output Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Input Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 10:36:42 --> Language Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Loader Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Controller Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Model Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Model Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Model Class Initialized
DEBUG - 2011-04-25 10:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 10:36:42 --> Database Driver Class Initialized
DEBUG - 2011-04-25 10:36:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 10:36:42 --> Helper loaded: url_helper
DEBUG - 2011-04-25 10:36:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 10:36:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 10:36:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 10:36:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 10:36:42 --> Final output sent to browser
DEBUG - 2011-04-25 10:36:42 --> Total execution time: 0.0477
DEBUG - 2011-04-25 11:41:09 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:09 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Router Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Output Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Input Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:41:09 --> Language Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Loader Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Controller Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:41:09 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:41:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:41:10 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:41:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:41:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:41:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:41:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:41:10 --> Final output sent to browser
DEBUG - 2011-04-25 11:41:10 --> Total execution time: 1.4571
DEBUG - 2011-04-25 11:41:12 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:12 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:12 --> Router Class Initialized
ERROR - 2011-04-25 11:41:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:41:27 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:27 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Router Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Output Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Input Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:41:27 --> Language Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Loader Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Controller Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:41:27 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:41:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:41:28 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:41:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:41:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:41:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:41:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:41:28 --> Final output sent to browser
DEBUG - 2011-04-25 11:41:28 --> Total execution time: 0.7077
DEBUG - 2011-04-25 11:41:29 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:29 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:29 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:29 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:29 --> Router Class Initialized
ERROR - 2011-04-25 11:41:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:41:40 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:40 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:40 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:40 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:40 --> Router Class Initialized
DEBUG - 2011-04-25 11:41:40 --> Output Class Initialized
DEBUG - 2011-04-25 11:41:40 --> Input Class Initialized
DEBUG - 2011-04-25 11:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:41:40 --> Language Class Initialized
DEBUG - 2011-04-25 11:41:41 --> Loader Class Initialized
DEBUG - 2011-04-25 11:41:41 --> Controller Class Initialized
DEBUG - 2011-04-25 11:41:41 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:41 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:41 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:41:41 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:41:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:41:41 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:41:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:41:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:41:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:41:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:41:41 --> Final output sent to browser
DEBUG - 2011-04-25 11:41:41 --> Total execution time: 0.2352
DEBUG - 2011-04-25 11:41:42 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:42 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:42 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:42 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:42 --> Router Class Initialized
ERROR - 2011-04-25 11:41:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:41:56 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:56 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Router Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Output Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Input Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:41:56 --> Language Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Loader Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Controller Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Model Class Initialized
DEBUG - 2011-04-25 11:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:41:56 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:41:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:41:56 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:41:56 --> Final output sent to browser
DEBUG - 2011-04-25 11:41:56 --> Total execution time: 0.2185
DEBUG - 2011-04-25 11:41:57 --> Config Class Initialized
DEBUG - 2011-04-25 11:41:57 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:41:57 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:41:57 --> URI Class Initialized
DEBUG - 2011-04-25 11:41:57 --> Router Class Initialized
ERROR - 2011-04-25 11:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:42:08 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:08 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Router Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Output Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Input Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:42:08 --> Language Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Loader Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Controller Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:42:08 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:42:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:42:08 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:42:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:42:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:42:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:42:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:42:08 --> Final output sent to browser
DEBUG - 2011-04-25 11:42:08 --> Total execution time: 0.3174
DEBUG - 2011-04-25 11:42:09 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:09 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:09 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:09 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:09 --> Router Class Initialized
ERROR - 2011-04-25 11:42:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:42:19 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:19 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Router Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Output Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Input Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:42:19 --> Language Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Loader Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Controller Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:42:19 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:42:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:42:19 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:42:19 --> Final output sent to browser
DEBUG - 2011-04-25 11:42:19 --> Total execution time: 0.2816
DEBUG - 2011-04-25 11:42:20 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:20 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:20 --> Router Class Initialized
ERROR - 2011-04-25 11:42:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:42:43 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:43 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Router Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Output Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Input Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:42:43 --> Language Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Loader Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Controller Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:42:43 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:42:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:42:43 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:42:43 --> Final output sent to browser
DEBUG - 2011-04-25 11:42:43 --> Total execution time: 0.2089
DEBUG - 2011-04-25 11:42:44 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:44 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:44 --> Router Class Initialized
ERROR - 2011-04-25 11:42:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:42:54 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:54 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Router Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Output Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Input Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:42:54 --> Language Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Loader Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Controller Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Model Class Initialized
DEBUG - 2011-04-25 11:42:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:42:54 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:42:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:42:54 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:42:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:42:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:42:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:42:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:42:54 --> Final output sent to browser
DEBUG - 2011-04-25 11:42:54 --> Total execution time: 0.3190
DEBUG - 2011-04-25 11:42:56 --> Config Class Initialized
DEBUG - 2011-04-25 11:42:56 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:42:56 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:42:56 --> URI Class Initialized
DEBUG - 2011-04-25 11:42:56 --> Router Class Initialized
ERROR - 2011-04-25 11:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:43:21 --> Config Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:43:21 --> URI Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Router Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Output Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Input Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:43:21 --> Language Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Loader Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Controller Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Model Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Model Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Model Class Initialized
DEBUG - 2011-04-25 11:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:43:21 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:43:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:43:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:43:21 --> Final output sent to browser
DEBUG - 2011-04-25 11:43:21 --> Total execution time: 0.3195
DEBUG - 2011-04-25 11:43:23 --> Config Class Initialized
DEBUG - 2011-04-25 11:43:23 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:43:23 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:43:23 --> URI Class Initialized
DEBUG - 2011-04-25 11:43:23 --> Router Class Initialized
ERROR - 2011-04-25 11:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:43:35 --> Config Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:43:35 --> URI Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Router Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Output Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Input Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:43:35 --> Language Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Loader Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Controller Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Model Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Model Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Model Class Initialized
DEBUG - 2011-04-25 11:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:43:35 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:43:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:43:36 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:43:36 --> Final output sent to browser
DEBUG - 2011-04-25 11:43:36 --> Total execution time: 0.2770
DEBUG - 2011-04-25 11:43:37 --> Config Class Initialized
DEBUG - 2011-04-25 11:43:37 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:43:37 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:43:37 --> URI Class Initialized
DEBUG - 2011-04-25 11:43:37 --> Router Class Initialized
ERROR - 2011-04-25 11:43:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:44:20 --> Config Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:44:20 --> URI Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Router Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Output Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Input Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:44:20 --> Language Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Loader Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Controller Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:44:20 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:44:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:44:21 --> Final output sent to browser
DEBUG - 2011-04-25 11:44:21 --> Total execution time: 0.3782
DEBUG - 2011-04-25 11:44:22 --> Config Class Initialized
DEBUG - 2011-04-25 11:44:22 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:44:22 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:44:22 --> URI Class Initialized
DEBUG - 2011-04-25 11:44:22 --> Router Class Initialized
ERROR - 2011-04-25 11:44:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:44:37 --> Config Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:44:37 --> URI Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Router Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Output Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Input Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:44:37 --> Language Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Loader Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Controller Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:44:37 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:44:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:44:38 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:44:38 --> Final output sent to browser
DEBUG - 2011-04-25 11:44:38 --> Total execution time: 0.7686
DEBUG - 2011-04-25 11:44:39 --> Config Class Initialized
DEBUG - 2011-04-25 11:44:39 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:44:39 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:44:39 --> URI Class Initialized
DEBUG - 2011-04-25 11:44:39 --> Router Class Initialized
ERROR - 2011-04-25 11:44:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:44:49 --> Config Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:44:49 --> URI Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Router Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Output Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Input Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:44:49 --> Language Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Loader Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Controller Class Initialized
DEBUG - 2011-04-25 11:44:49 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:50 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:50 --> Model Class Initialized
DEBUG - 2011-04-25 11:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:44:50 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:44:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:44:50 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:44:50 --> Final output sent to browser
DEBUG - 2011-04-25 11:44:50 --> Total execution time: 0.7030
DEBUG - 2011-04-25 11:44:51 --> Config Class Initialized
DEBUG - 2011-04-25 11:44:51 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:44:51 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:44:51 --> URI Class Initialized
DEBUG - 2011-04-25 11:44:51 --> Router Class Initialized
ERROR - 2011-04-25 11:44:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:45:05 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:05 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Router Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Output Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Input Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:45:05 --> Language Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Loader Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Controller Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:45:05 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:45:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:45:05 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:45:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:45:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:45:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:45:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:45:05 --> Final output sent to browser
DEBUG - 2011-04-25 11:45:05 --> Total execution time: 0.1440
DEBUG - 2011-04-25 11:45:06 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:06 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:06 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:06 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:06 --> Router Class Initialized
ERROR - 2011-04-25 11:45:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:45:14 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:14 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Router Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Output Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Input Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:45:14 --> Language Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Loader Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Controller Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:45:14 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:45:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:45:15 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:45:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:45:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:45:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:45:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:45:15 --> Final output sent to browser
DEBUG - 2011-04-25 11:45:15 --> Total execution time: 0.5937
DEBUG - 2011-04-25 11:45:16 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:16 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:16 --> Router Class Initialized
ERROR - 2011-04-25 11:45:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:45:34 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:34 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Router Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Output Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Input Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:45:34 --> Language Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Loader Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Controller Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:45:34 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:45:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:45:35 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:45:35 --> Final output sent to browser
DEBUG - 2011-04-25 11:45:35 --> Total execution time: 0.2662
DEBUG - 2011-04-25 11:45:36 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:36 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:36 --> Router Class Initialized
ERROR - 2011-04-25 11:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:45:58 --> Config Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:45:58 --> URI Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Router Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Output Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Input Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:45:58 --> Language Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Loader Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Controller Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Model Class Initialized
DEBUG - 2011-04-25 11:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:45:58 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:45:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:45:59 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:45:59 --> Final output sent to browser
DEBUG - 2011-04-25 11:45:59 --> Total execution time: 0.3101
DEBUG - 2011-04-25 11:46:00 --> Config Class Initialized
DEBUG - 2011-04-25 11:46:00 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:46:00 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:46:00 --> URI Class Initialized
DEBUG - 2011-04-25 11:46:00 --> Router Class Initialized
ERROR - 2011-04-25 11:46:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:46:11 --> Config Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:46:11 --> URI Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Router Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Output Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Input Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:46:11 --> Language Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Loader Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Controller Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Model Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Model Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Model Class Initialized
DEBUG - 2011-04-25 11:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:46:11 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:46:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:46:11 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:46:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:46:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:46:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:46:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:46:11 --> Final output sent to browser
DEBUG - 2011-04-25 11:46:11 --> Total execution time: 0.2363
DEBUG - 2011-04-25 11:46:12 --> Config Class Initialized
DEBUG - 2011-04-25 11:46:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:46:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:46:12 --> URI Class Initialized
DEBUG - 2011-04-25 11:46:12 --> Router Class Initialized
ERROR - 2011-04-25 11:46:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:46:24 --> Config Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:46:24 --> URI Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Router Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Output Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Input Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:46:24 --> Language Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Loader Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Controller Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Model Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Model Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Model Class Initialized
DEBUG - 2011-04-25 11:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:46:24 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:46:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:46:25 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:46:25 --> Final output sent to browser
DEBUG - 2011-04-25 11:46:25 --> Total execution time: 0.2645
DEBUG - 2011-04-25 11:46:26 --> Config Class Initialized
DEBUG - 2011-04-25 11:46:26 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:46:26 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:46:26 --> URI Class Initialized
DEBUG - 2011-04-25 11:46:26 --> Router Class Initialized
ERROR - 2011-04-25 11:46:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:48:19 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:19 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Router Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Output Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Input Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:48:19 --> Language Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Loader Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Controller Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:48:19 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:48:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:48:20 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:48:20 --> Final output sent to browser
DEBUG - 2011-04-25 11:48:20 --> Total execution time: 0.8142
DEBUG - 2011-04-25 11:48:21 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:21 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:21 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:21 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:21 --> Router Class Initialized
ERROR - 2011-04-25 11:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:48:25 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:25 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Router Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Output Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Input Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:48:25 --> Language Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Loader Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Controller Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:48:25 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:48:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:48:25 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:48:25 --> Final output sent to browser
DEBUG - 2011-04-25 11:48:25 --> Total execution time: 0.3484
DEBUG - 2011-04-25 11:48:27 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:27 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:27 --> Router Class Initialized
ERROR - 2011-04-25 11:48:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:48:33 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:33 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Router Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Output Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Input Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:48:33 --> Language Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Loader Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Controller Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:48:33 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:48:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:48:33 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:48:33 --> Final output sent to browser
DEBUG - 2011-04-25 11:48:33 --> Total execution time: 0.2432
DEBUG - 2011-04-25 11:48:34 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:34 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:34 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:34 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:34 --> Router Class Initialized
ERROR - 2011-04-25 11:48:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 11:48:39 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:39 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Router Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Output Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Input Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 11:48:39 --> Language Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Loader Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Controller Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Model Class Initialized
DEBUG - 2011-04-25 11:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 11:48:39 --> Database Driver Class Initialized
DEBUG - 2011-04-25 11:48:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 11:48:39 --> Helper loaded: url_helper
DEBUG - 2011-04-25 11:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 11:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 11:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 11:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 11:48:39 --> Final output sent to browser
DEBUG - 2011-04-25 11:48:39 --> Total execution time: 0.2093
DEBUG - 2011-04-25 11:48:40 --> Config Class Initialized
DEBUG - 2011-04-25 11:48:40 --> Hooks Class Initialized
DEBUG - 2011-04-25 11:48:40 --> Utf8 Class Initialized
DEBUG - 2011-04-25 11:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 11:48:40 --> URI Class Initialized
DEBUG - 2011-04-25 11:48:40 --> Router Class Initialized
ERROR - 2011-04-25 11:48:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 12:09:36 --> Config Class Initialized
DEBUG - 2011-04-25 12:09:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:09:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:09:36 --> URI Class Initialized
DEBUG - 2011-04-25 12:09:36 --> Router Class Initialized
DEBUG - 2011-04-25 12:09:36 --> Output Class Initialized
DEBUG - 2011-04-25 12:09:36 --> Input Class Initialized
DEBUG - 2011-04-25 12:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:09:36 --> Language Class Initialized
DEBUG - 2011-04-25 12:09:37 --> Loader Class Initialized
DEBUG - 2011-04-25 12:09:37 --> Controller Class Initialized
ERROR - 2011-04-25 12:09:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 12:09:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 12:09:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:09:37 --> Model Class Initialized
DEBUG - 2011-04-25 12:09:37 --> Model Class Initialized
DEBUG - 2011-04-25 12:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:09:38 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:09:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:09:38 --> Helper loaded: url_helper
DEBUG - 2011-04-25 12:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 12:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 12:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 12:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 12:09:38 --> Final output sent to browser
DEBUG - 2011-04-25 12:09:38 --> Total execution time: 3.2885
DEBUG - 2011-04-25 12:10:08 --> Config Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:10:08 --> URI Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Router Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Output Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Input Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:10:08 --> Language Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Loader Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Controller Class Initialized
ERROR - 2011-04-25 12:10:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 12:10:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 12:10:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:10:08 --> Model Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Model Class Initialized
DEBUG - 2011-04-25 12:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:10:08 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:10:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:10:08 --> Helper loaded: url_helper
DEBUG - 2011-04-25 12:10:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 12:10:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 12:10:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 12:10:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 12:10:08 --> Final output sent to browser
DEBUG - 2011-04-25 12:10:08 --> Total execution time: 0.1684
DEBUG - 2011-04-25 12:26:11 --> Config Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:26:11 --> URI Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Router Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Output Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Input Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:26:11 --> Language Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Loader Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Controller Class Initialized
ERROR - 2011-04-25 12:26:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 12:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 12:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:26:11 --> Model Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Model Class Initialized
DEBUG - 2011-04-25 12:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:26:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:26:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 12:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 12:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 12:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 12:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 12:26:12 --> Final output sent to browser
DEBUG - 2011-04-25 12:26:12 --> Total execution time: 1.1388
DEBUG - 2011-04-25 12:26:20 --> Config Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:26:20 --> URI Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Router Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Output Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Input Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:26:20 --> Language Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Loader Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Controller Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Model Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Model Class Initialized
DEBUG - 2011-04-25 12:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:26:20 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:26:21 --> Final output sent to browser
DEBUG - 2011-04-25 12:26:21 --> Total execution time: 0.7502
DEBUG - 2011-04-25 12:48:09 --> Config Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:48:09 --> URI Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Router Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Output Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Input Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:48:09 --> Language Class Initialized
DEBUG - 2011-04-25 12:48:09 --> Loader Class Initialized
DEBUG - 2011-04-25 12:48:10 --> Controller Class Initialized
ERROR - 2011-04-25 12:48:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 12:48:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 12:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:48:10 --> Model Class Initialized
DEBUG - 2011-04-25 12:48:10 --> Model Class Initialized
DEBUG - 2011-04-25 12:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:48:10 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:48:10 --> Helper loaded: url_helper
DEBUG - 2011-04-25 12:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 12:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 12:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 12:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 12:48:10 --> Final output sent to browser
DEBUG - 2011-04-25 12:48:10 --> Total execution time: 1.0148
DEBUG - 2011-04-25 12:48:12 --> Config Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:48:12 --> URI Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Router Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Output Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Input Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:48:12 --> Language Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Loader Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Controller Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Model Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Model Class Initialized
DEBUG - 2011-04-25 12:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:48:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:48:13 --> Final output sent to browser
DEBUG - 2011-04-25 12:48:13 --> Total execution time: 1.2367
DEBUG - 2011-04-25 12:48:14 --> Config Class Initialized
DEBUG - 2011-04-25 12:48:14 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:48:14 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:48:14 --> URI Class Initialized
DEBUG - 2011-04-25 12:48:14 --> Router Class Initialized
ERROR - 2011-04-25 12:48:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 12:56:12 --> Config Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:56:12 --> URI Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Router Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Output Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Input Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:56:12 --> Language Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Loader Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Controller Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Model Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Model Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Model Class Initialized
DEBUG - 2011-04-25 12:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:56:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:56:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 12:56:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 12:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 12:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 12:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 12:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 12:56:12 --> Final output sent to browser
DEBUG - 2011-04-25 12:56:12 --> Total execution time: 0.6035
DEBUG - 2011-04-25 12:56:13 --> Config Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Hooks Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Utf8 Class Initialized
DEBUG - 2011-04-25 12:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 12:56:13 --> URI Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Router Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Output Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Input Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 12:56:13 --> Language Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Loader Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Controller Class Initialized
ERROR - 2011-04-25 12:56:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 12:56:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 12:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:56:13 --> Model Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Model Class Initialized
DEBUG - 2011-04-25 12:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 12:56:13 --> Database Driver Class Initialized
DEBUG - 2011-04-25 12:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 12:56:13 --> Helper loaded: url_helper
DEBUG - 2011-04-25 12:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 12:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 12:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 12:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 12:56:13 --> Final output sent to browser
DEBUG - 2011-04-25 12:56:13 --> Total execution time: 0.0465
DEBUG - 2011-04-25 14:51:32 --> Config Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Hooks Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Utf8 Class Initialized
DEBUG - 2011-04-25 14:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 14:51:32 --> URI Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Router Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Output Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Input Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 14:51:32 --> Language Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Loader Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Controller Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 14:51:32 --> Database Driver Class Initialized
DEBUG - 2011-04-25 14:51:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 14:51:33 --> Helper loaded: url_helper
DEBUG - 2011-04-25 14:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 14:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 14:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 14:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 14:51:33 --> Final output sent to browser
DEBUG - 2011-04-25 14:51:33 --> Total execution time: 0.4852
DEBUG - 2011-04-25 14:51:36 --> Config Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 14:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 14:51:36 --> URI Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Router Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Output Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Input Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 14:51:36 --> Language Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Loader Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Controller Class Initialized
ERROR - 2011-04-25 14:51:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 14:51:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 14:51:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 14:51:36 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 14:51:36 --> Database Driver Class Initialized
DEBUG - 2011-04-25 14:51:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 14:51:36 --> Helper loaded: url_helper
DEBUG - 2011-04-25 14:51:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 14:51:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 14:51:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 14:51:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 14:51:36 --> Final output sent to browser
DEBUG - 2011-04-25 14:51:36 --> Total execution time: 0.1179
DEBUG - 2011-04-25 14:51:38 --> Config Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Hooks Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Utf8 Class Initialized
DEBUG - 2011-04-25 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 14:51:38 --> URI Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Router Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Output Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Input Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 14:51:38 --> Language Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Loader Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Controller Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Model Class Initialized
DEBUG - 2011-04-25 14:51:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 14:51:38 --> Database Driver Class Initialized
DEBUG - 2011-04-25 14:51:39 --> Final output sent to browser
DEBUG - 2011-04-25 14:51:39 --> Total execution time: 0.7194
DEBUG - 2011-04-25 14:51:40 --> Config Class Initialized
DEBUG - 2011-04-25 14:51:40 --> Hooks Class Initialized
DEBUG - 2011-04-25 14:51:40 --> Utf8 Class Initialized
DEBUG - 2011-04-25 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 14:51:40 --> URI Class Initialized
DEBUG - 2011-04-25 14:51:40 --> Router Class Initialized
ERROR - 2011-04-25 14:51:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 14:51:41 --> Config Class Initialized
DEBUG - 2011-04-25 14:51:41 --> Hooks Class Initialized
DEBUG - 2011-04-25 14:51:41 --> Utf8 Class Initialized
DEBUG - 2011-04-25 14:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 14:51:41 --> URI Class Initialized
DEBUG - 2011-04-25 14:51:41 --> Router Class Initialized
ERROR - 2011-04-25 14:51:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 15:19:35 --> Config Class Initialized
DEBUG - 2011-04-25 15:19:35 --> Hooks Class Initialized
DEBUG - 2011-04-25 15:19:35 --> Utf8 Class Initialized
DEBUG - 2011-04-25 15:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 15:19:35 --> URI Class Initialized
DEBUG - 2011-04-25 15:19:35 --> Router Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Output Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Input Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 15:19:36 --> Language Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Loader Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Controller Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Model Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Model Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Model Class Initialized
DEBUG - 2011-04-25 15:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 15:19:36 --> Database Driver Class Initialized
DEBUG - 2011-04-25 15:19:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 15:19:36 --> Helper loaded: url_helper
DEBUG - 2011-04-25 15:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 15:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 15:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 15:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 15:19:36 --> Final output sent to browser
DEBUG - 2011-04-25 15:19:36 --> Total execution time: 0.4324
DEBUG - 2011-04-25 15:19:38 --> Config Class Initialized
DEBUG - 2011-04-25 15:19:38 --> Hooks Class Initialized
DEBUG - 2011-04-25 15:19:38 --> Utf8 Class Initialized
DEBUG - 2011-04-25 15:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 15:19:38 --> URI Class Initialized
DEBUG - 2011-04-25 15:19:38 --> Router Class Initialized
ERROR - 2011-04-25 15:19:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 15:19:39 --> Config Class Initialized
DEBUG - 2011-04-25 15:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-25 15:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-25 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 15:19:39 --> URI Class Initialized
DEBUG - 2011-04-25 15:19:39 --> Router Class Initialized
ERROR - 2011-04-25 15:19:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 15:19:39 --> Config Class Initialized
DEBUG - 2011-04-25 15:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-25 15:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-25 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 15:19:39 --> URI Class Initialized
DEBUG - 2011-04-25 15:19:39 --> Router Class Initialized
ERROR - 2011-04-25 15:19:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 15:38:49 --> Config Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Hooks Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Utf8 Class Initialized
DEBUG - 2011-04-25 15:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 15:38:49 --> URI Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Router Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Output Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Input Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 15:38:49 --> Language Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Loader Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Controller Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Model Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Model Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Model Class Initialized
DEBUG - 2011-04-25 15:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 15:38:49 --> Database Driver Class Initialized
DEBUG - 2011-04-25 15:38:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 15:38:49 --> Helper loaded: url_helper
DEBUG - 2011-04-25 15:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 15:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 15:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 15:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 15:38:49 --> Final output sent to browser
DEBUG - 2011-04-25 15:38:49 --> Total execution time: 0.4046
DEBUG - 2011-04-25 15:38:51 --> Config Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Hooks Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Utf8 Class Initialized
DEBUG - 2011-04-25 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 15:38:51 --> URI Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Router Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Output Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Input Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 15:38:51 --> Language Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Loader Class Initialized
DEBUG - 2011-04-25 15:38:51 --> Controller Class Initialized
ERROR - 2011-04-25 15:38:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 15:38:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 15:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 15:38:52 --> Model Class Initialized
DEBUG - 2011-04-25 15:38:52 --> Model Class Initialized
DEBUG - 2011-04-25 15:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 15:38:52 --> Database Driver Class Initialized
DEBUG - 2011-04-25 15:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 15:38:52 --> Helper loaded: url_helper
DEBUG - 2011-04-25 15:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 15:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 15:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 15:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 15:38:52 --> Final output sent to browser
DEBUG - 2011-04-25 15:38:52 --> Total execution time: 0.0955
DEBUG - 2011-04-25 16:10:12 --> Config Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:10:12 --> URI Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Router Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Output Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Input Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:10:12 --> Language Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Loader Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Controller Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Model Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Model Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Model Class Initialized
DEBUG - 2011-04-25 16:10:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:10:14 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:10:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 16:10:14 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:10:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:10:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:10:14 --> Final output sent to browser
DEBUG - 2011-04-25 16:10:14 --> Total execution time: 3.3225
DEBUG - 2011-04-25 16:13:18 --> Config Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:13:18 --> URI Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Router Class Initialized
ERROR - 2011-04-25 16:13:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-25 16:13:18 --> Config Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:13:18 --> URI Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Router Class Initialized
DEBUG - 2011-04-25 16:13:18 --> No URI present. Default controller set.
DEBUG - 2011-04-25 16:13:18 --> Output Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Input Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:13:18 --> Language Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Loader Class Initialized
DEBUG - 2011-04-25 16:13:18 --> Controller Class Initialized
DEBUG - 2011-04-25 16:13:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-25 16:13:18 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:13:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:13:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:13:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:13:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:13:18 --> Final output sent to browser
DEBUG - 2011-04-25 16:13:18 --> Total execution time: 0.1432
DEBUG - 2011-04-25 16:33:27 --> Config Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:33:27 --> URI Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Router Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Output Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Input Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:33:27 --> Language Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Loader Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Controller Class Initialized
ERROR - 2011-04-25 16:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 16:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 16:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:33:27 --> Model Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Model Class Initialized
DEBUG - 2011-04-25 16:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:33:27 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:33:27 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:33:27 --> Final output sent to browser
DEBUG - 2011-04-25 16:33:27 --> Total execution time: 0.2645
DEBUG - 2011-04-25 16:33:29 --> Config Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:33:29 --> URI Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Router Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Output Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Input Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:33:29 --> Language Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Loader Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Controller Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Model Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Model Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:33:29 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:33:29 --> Final output sent to browser
DEBUG - 2011-04-25 16:33:29 --> Total execution time: 0.6272
DEBUG - 2011-04-25 16:43:07 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:07 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:07 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Controller Class Initialized
ERROR - 2011-04-25 16:43:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 16:43:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 16:43:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:07 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:07 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:07 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:43:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:43:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:43:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:43:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:43:07 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:07 --> Total execution time: 0.1464
DEBUG - 2011-04-25 16:43:08 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:08 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:08 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Controller Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:08 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:09 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:09 --> Total execution time: 0.6746
DEBUG - 2011-04-25 16:43:16 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:16 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:16 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Controller Class Initialized
ERROR - 2011-04-25 16:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 16:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 16:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:16 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:16 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:43:16 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:16 --> Total execution time: 0.0306
DEBUG - 2011-04-25 16:43:16 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:16 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:16 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Controller Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:17 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:17 --> Total execution time: 0.6400
DEBUG - 2011-04-25 16:43:26 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:26 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:26 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Controller Class Initialized
ERROR - 2011-04-25 16:43:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 16:43:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 16:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:26 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:26 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:26 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:43:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:43:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:43:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:43:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:43:26 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:26 --> Total execution time: 0.0307
DEBUG - 2011-04-25 16:43:28 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:28 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:28 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Controller Class Initialized
ERROR - 2011-04-25 16:43:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 16:43:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:28 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:28 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:28 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:43:28 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:28 --> Total execution time: 0.0336
DEBUG - 2011-04-25 16:43:28 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:28 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:28 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Controller Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:28 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Config Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Hooks Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Utf8 Class Initialized
DEBUG - 2011-04-25 16:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 16:43:28 --> URI Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Router Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Output Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Input Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 16:43:28 --> Language Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Loader Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Controller Class Initialized
ERROR - 2011-04-25 16:43:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 16:43:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:28 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Model Class Initialized
DEBUG - 2011-04-25 16:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 16:43:28 --> Database Driver Class Initialized
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 16:43:28 --> Helper loaded: url_helper
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 16:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 16:43:28 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:28 --> Total execution time: 0.0335
DEBUG - 2011-04-25 16:43:29 --> Final output sent to browser
DEBUG - 2011-04-25 16:43:29 --> Total execution time: 0.5848
DEBUG - 2011-04-25 17:07:25 --> Config Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:07:26 --> URI Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Router Class Initialized
ERROR - 2011-04-25 17:07:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-25 17:07:26 --> Config Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:07:26 --> URI Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Router Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Output Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Input Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:07:26 --> Language Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Loader Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Controller Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Model Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Model Class Initialized
DEBUG - 2011-04-25 17:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:07:26 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Final output sent to browser
DEBUG - 2011-04-25 17:07:27 --> Total execution time: 0.8002
DEBUG - 2011-04-25 17:07:27 --> Config Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:07:27 --> URI Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Router Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Output Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Input Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:07:27 --> Language Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Loader Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Controller Class Initialized
ERROR - 2011-04-25 17:07:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 17:07:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 17:07:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 17:07:27 --> Model Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Model Class Initialized
DEBUG - 2011-04-25 17:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:07:27 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:07:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 17:07:27 --> Helper loaded: url_helper
DEBUG - 2011-04-25 17:07:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 17:07:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 17:07:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 17:07:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 17:07:27 --> Final output sent to browser
DEBUG - 2011-04-25 17:07:27 --> Total execution time: 0.0624
DEBUG - 2011-04-25 17:56:49 --> Config Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:56:49 --> URI Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Router Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Output Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Input Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:56:49 --> Language Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Loader Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Controller Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Model Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Model Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Model Class Initialized
DEBUG - 2011-04-25 17:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:56:49 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:56:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 17:56:50 --> Helper loaded: url_helper
DEBUG - 2011-04-25 17:56:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 17:56:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 17:56:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 17:56:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 17:56:50 --> Final output sent to browser
DEBUG - 2011-04-25 17:56:50 --> Total execution time: 0.7120
DEBUG - 2011-04-25 17:57:22 --> Config Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:57:22 --> URI Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Router Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Output Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Input Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:57:22 --> Language Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Loader Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Controller Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Model Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Model Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Model Class Initialized
DEBUG - 2011-04-25 17:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:57:22 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 17:57:22 --> Helper loaded: url_helper
DEBUG - 2011-04-25 17:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 17:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 17:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 17:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 17:57:22 --> Final output sent to browser
DEBUG - 2011-04-25 17:57:22 --> Total execution time: 0.0469
DEBUG - 2011-04-25 17:57:36 --> Config Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:57:36 --> URI Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Router Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Output Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Input Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:57:36 --> Language Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Loader Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Controller Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Model Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Model Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Model Class Initialized
DEBUG - 2011-04-25 17:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:57:36 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:57:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 17:57:36 --> Helper loaded: url_helper
DEBUG - 2011-04-25 17:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 17:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 17:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 17:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 17:57:36 --> Final output sent to browser
DEBUG - 2011-04-25 17:57:36 --> Total execution time: 0.2503
DEBUG - 2011-04-25 17:58:29 --> Config Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:58:29 --> URI Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Router Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Output Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Input Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:58:29 --> Language Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Loader Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Controller Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Model Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Model Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Model Class Initialized
DEBUG - 2011-04-25 17:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:58:29 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:58:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 17:58:29 --> Helper loaded: url_helper
DEBUG - 2011-04-25 17:58:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 17:58:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 17:58:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 17:58:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 17:58:29 --> Final output sent to browser
DEBUG - 2011-04-25 17:58:29 --> Total execution time: 0.2537
DEBUG - 2011-04-25 17:59:19 --> Config Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Hooks Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Utf8 Class Initialized
DEBUG - 2011-04-25 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 17:59:19 --> URI Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Router Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Output Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Input Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 17:59:19 --> Language Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Loader Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Controller Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Model Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Model Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Model Class Initialized
DEBUG - 2011-04-25 17:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 17:59:19 --> Database Driver Class Initialized
DEBUG - 2011-04-25 17:59:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 17:59:20 --> Helper loaded: url_helper
DEBUG - 2011-04-25 17:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 17:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 17:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 17:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 17:59:20 --> Final output sent to browser
DEBUG - 2011-04-25 17:59:20 --> Total execution time: 0.4541
DEBUG - 2011-04-25 18:00:01 --> Config Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:00:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:00:01 --> URI Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Router Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Output Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Input Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:00:01 --> Language Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Loader Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Controller Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:00:01 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:00:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:00:01 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:00:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:00:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:00:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:00:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:00:01 --> Final output sent to browser
DEBUG - 2011-04-25 18:00:01 --> Total execution time: 0.2154
DEBUG - 2011-04-25 18:00:13 --> Config Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:00:13 --> URI Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Router Class Initialized
DEBUG - 2011-04-25 18:00:13 --> No URI present. Default controller set.
DEBUG - 2011-04-25 18:00:13 --> Output Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Input Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:00:13 --> Language Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Loader Class Initialized
DEBUG - 2011-04-25 18:00:13 --> Controller Class Initialized
DEBUG - 2011-04-25 18:00:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-25 18:00:13 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:00:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:00:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:00:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:00:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:00:13 --> Final output sent to browser
DEBUG - 2011-04-25 18:00:13 --> Total execution time: 0.3953
DEBUG - 2011-04-25 18:00:15 --> Config Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:00:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:00:15 --> URI Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Router Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Output Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Input Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:00:15 --> Language Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Loader Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Controller Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:00:15 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:00:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:00:15 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:00:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:00:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:00:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:00:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:00:15 --> Final output sent to browser
DEBUG - 2011-04-25 18:00:15 --> Total execution time: 0.0447
DEBUG - 2011-04-25 18:00:16 --> Config Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:00:16 --> URI Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Router Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Output Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Input Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:00:16 --> Language Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Loader Class Initialized
DEBUG - 2011-04-25 18:00:16 --> Controller Class Initialized
ERROR - 2011-04-25 18:00:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 18:00:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 18:00:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 18:00:17 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:17 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:00:17 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:00:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 18:00:17 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:00:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:00:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:00:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:00:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:00:17 --> Final output sent to browser
DEBUG - 2011-04-25 18:00:17 --> Total execution time: 1.0431
DEBUG - 2011-04-25 18:00:39 --> Config Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:00:39 --> URI Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Router Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Output Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Input Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:00:39 --> Language Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Loader Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Controller Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Model Class Initialized
DEBUG - 2011-04-25 18:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:00:39 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:00:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:00:40 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:00:40 --> Final output sent to browser
DEBUG - 2011-04-25 18:00:40 --> Total execution time: 0.9526
DEBUG - 2011-04-25 18:01:35 --> Config Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:01:35 --> URI Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Router Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Output Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Input Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:01:35 --> Language Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Loader Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Controller Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Model Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Model Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Model Class Initialized
DEBUG - 2011-04-25 18:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:01:35 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:01:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:01:35 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:01:35 --> Final output sent to browser
DEBUG - 2011-04-25 18:01:35 --> Total execution time: 0.2236
DEBUG - 2011-04-25 18:02:12 --> Config Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:02:12 --> URI Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Router Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Output Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Input Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:02:12 --> Language Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Loader Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Controller Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:02:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:02:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:02:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:02:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:02:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:02:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:02:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:02:12 --> Final output sent to browser
DEBUG - 2011-04-25 18:02:12 --> Total execution time: 0.1891
DEBUG - 2011-04-25 18:02:15 --> Config Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:02:15 --> URI Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Router Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Output Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Input Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:02:15 --> Language Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Loader Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Controller Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:02:15 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:02:16 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:02:16 --> Final output sent to browser
DEBUG - 2011-04-25 18:02:16 --> Total execution time: 0.0722
DEBUG - 2011-04-25 18:02:39 --> Config Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:02:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:02:39 --> URI Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Router Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Output Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Input Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:02:39 --> Language Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Loader Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Controller Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:02:39 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:02:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:02:39 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:02:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:02:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:02:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:02:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:02:39 --> Final output sent to browser
DEBUG - 2011-04-25 18:02:39 --> Total execution time: 0.3421
DEBUG - 2011-04-25 18:02:43 --> Config Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:02:43 --> URI Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Router Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Output Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Input Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:02:43 --> Language Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Loader Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Controller Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Model Class Initialized
DEBUG - 2011-04-25 18:02:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:02:43 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:02:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:02:43 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:02:43 --> Final output sent to browser
DEBUG - 2011-04-25 18:02:43 --> Total execution time: 0.0717
DEBUG - 2011-04-25 18:03:16 --> Config Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:03:16 --> URI Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Router Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Output Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Input Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:03:16 --> Language Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Loader Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Controller Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Model Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Model Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Model Class Initialized
DEBUG - 2011-04-25 18:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:03:16 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:03:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:03:17 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:03:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:03:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:03:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:03:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:03:17 --> Final output sent to browser
DEBUG - 2011-04-25 18:03:17 --> Total execution time: 0.3285
DEBUG - 2011-04-25 18:03:20 --> Config Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:03:20 --> URI Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Router Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Output Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Input Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:03:20 --> Language Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Loader Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Controller Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Model Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Model Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Model Class Initialized
DEBUG - 2011-04-25 18:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:03:20 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:03:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:03:20 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:03:20 --> Final output sent to browser
DEBUG - 2011-04-25 18:03:20 --> Total execution time: 0.0707
DEBUG - 2011-04-25 18:20:25 --> Config Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:20:25 --> URI Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Router Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Output Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Input Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:20:25 --> Language Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Loader Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Controller Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Model Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Model Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Model Class Initialized
DEBUG - 2011-04-25 18:20:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:20:25 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:20:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 18:20:25 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:20:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:20:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:20:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:20:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:20:25 --> Final output sent to browser
DEBUG - 2011-04-25 18:20:25 --> Total execution time: 0.2931
DEBUG - 2011-04-25 18:20:47 --> Config Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Hooks Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Utf8 Class Initialized
DEBUG - 2011-04-25 18:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 18:20:47 --> URI Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Router Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Output Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Input Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 18:20:47 --> Language Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Loader Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Controller Class Initialized
ERROR - 2011-04-25 18:20:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 18:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 18:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 18:20:47 --> Model Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Model Class Initialized
DEBUG - 2011-04-25 18:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 18:20:47 --> Database Driver Class Initialized
DEBUG - 2011-04-25 18:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 18:20:47 --> Helper loaded: url_helper
DEBUG - 2011-04-25 18:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 18:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 18:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 18:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 18:20:47 --> Final output sent to browser
DEBUG - 2011-04-25 18:20:47 --> Total execution time: 0.0465
DEBUG - 2011-04-25 20:18:20 --> Config Class Initialized
DEBUG - 2011-04-25 20:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:18:20 --> URI Class Initialized
DEBUG - 2011-04-25 20:18:20 --> Router Class Initialized
DEBUG - 2011-04-25 20:18:21 --> No URI present. Default controller set.
DEBUG - 2011-04-25 20:18:21 --> Output Class Initialized
DEBUG - 2011-04-25 20:18:21 --> Input Class Initialized
DEBUG - 2011-04-25 20:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 20:18:21 --> Language Class Initialized
DEBUG - 2011-04-25 20:18:21 --> Loader Class Initialized
DEBUG - 2011-04-25 20:18:21 --> Controller Class Initialized
DEBUG - 2011-04-25 20:18:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-25 20:18:21 --> Helper loaded: url_helper
DEBUG - 2011-04-25 20:18:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 20:18:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 20:18:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 20:18:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 20:18:21 --> Final output sent to browser
DEBUG - 2011-04-25 20:18:21 --> Total execution time: 0.3066
DEBUG - 2011-04-25 20:18:24 --> Config Class Initialized
DEBUG - 2011-04-25 20:18:24 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:18:24 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:18:24 --> URI Class Initialized
DEBUG - 2011-04-25 20:18:24 --> Router Class Initialized
ERROR - 2011-04-25 20:18:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 20:18:27 --> Config Class Initialized
DEBUG - 2011-04-25 20:18:27 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:18:27 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:18:27 --> URI Class Initialized
DEBUG - 2011-04-25 20:18:27 --> Router Class Initialized
ERROR - 2011-04-25 20:18:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 20:18:47 --> Config Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:18:47 --> URI Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Router Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Output Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Input Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 20:18:47 --> Language Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Loader Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Controller Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Model Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Model Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Model Class Initialized
DEBUG - 2011-04-25 20:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 20:18:47 --> Database Driver Class Initialized
DEBUG - 2011-04-25 20:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 20:18:48 --> Helper loaded: url_helper
DEBUG - 2011-04-25 20:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 20:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 20:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 20:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 20:18:48 --> Final output sent to browser
DEBUG - 2011-04-25 20:18:48 --> Total execution time: 0.3523
DEBUG - 2011-04-25 20:48:38 --> Config Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:48:38 --> URI Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Router Class Initialized
ERROR - 2011-04-25 20:48:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-25 20:48:38 --> Config Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:48:38 --> URI Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Router Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Output Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Input Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 20:48:38 --> Language Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Loader Class Initialized
DEBUG - 2011-04-25 20:48:38 --> Controller Class Initialized
ERROR - 2011-04-25 20:48:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 20:48:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 20:48:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 20:48:39 --> Model Class Initialized
DEBUG - 2011-04-25 20:48:39 --> Model Class Initialized
DEBUG - 2011-04-25 20:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 20:48:39 --> Database Driver Class Initialized
DEBUG - 2011-04-25 20:48:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 20:48:39 --> Helper loaded: url_helper
DEBUG - 2011-04-25 20:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 20:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 20:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 20:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 20:48:39 --> Final output sent to browser
DEBUG - 2011-04-25 20:48:39 --> Total execution time: 0.7890
DEBUG - 2011-04-25 20:55:49 --> Config Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:55:49 --> URI Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Router Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Output Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Input Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 20:55:49 --> Language Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Loader Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Controller Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Model Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Model Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Model Class Initialized
DEBUG - 2011-04-25 20:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 20:55:49 --> Database Driver Class Initialized
DEBUG - 2011-04-25 20:55:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 20:55:49 --> Helper loaded: url_helper
DEBUG - 2011-04-25 20:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 20:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 20:55:50 --> Final output sent to browser
DEBUG - 2011-04-25 20:55:50 --> Total execution time: 0.4110
DEBUG - 2011-04-25 20:55:50 --> Config Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Hooks Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Utf8 Class Initialized
DEBUG - 2011-04-25 20:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 20:55:50 --> URI Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Router Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Output Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Input Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 20:55:50 --> Language Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Loader Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Controller Class Initialized
ERROR - 2011-04-25 20:55:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 20:55:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 20:55:50 --> Model Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Model Class Initialized
DEBUG - 2011-04-25 20:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 20:55:50 --> Database Driver Class Initialized
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 20:55:50 --> Helper loaded: url_helper
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 20:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 20:55:50 --> Final output sent to browser
DEBUG - 2011-04-25 20:55:50 --> Total execution time: 0.0318
DEBUG - 2011-04-25 21:08:12 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:12 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:12 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Controller Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:12 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 21:08:12 --> Helper loaded: url_helper
DEBUG - 2011-04-25 21:08:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 21:08:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 21:08:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 21:08:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 21:08:12 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:12 --> Total execution time: 0.0848
DEBUG - 2011-04-25 21:08:16 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:16 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:16 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:16 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:16 --> Router Class Initialized
ERROR - 2011-04-25 21:08:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 21:08:18 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:18 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:18 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:18 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:18 --> Router Class Initialized
ERROR - 2011-04-25 21:08:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 21:08:24 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:24 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:24 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Controller Class Initialized
ERROR - 2011-04-25 21:08:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 21:08:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 21:08:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 21:08:24 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:24 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 21:08:24 --> Helper loaded: url_helper
DEBUG - 2011-04-25 21:08:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 21:08:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 21:08:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 21:08:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 21:08:24 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:24 --> Total execution time: 0.0343
DEBUG - 2011-04-25 21:08:24 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:24 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:24 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Controller Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:24 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:25 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:25 --> Total execution time: 0.7563
DEBUG - 2011-04-25 21:08:42 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:42 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:42 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Controller Class Initialized
ERROR - 2011-04-25 21:08:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 21:08:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 21:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 21:08:42 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:42 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 21:08:42 --> Helper loaded: url_helper
DEBUG - 2011-04-25 21:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 21:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 21:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 21:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 21:08:42 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:42 --> Total execution time: 0.0303
DEBUG - 2011-04-25 21:08:43 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:43 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:43 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Controller Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:43 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:43 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:43 --> Total execution time: 0.6289
DEBUG - 2011-04-25 21:08:57 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:57 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:57 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Controller Class Initialized
ERROR - 2011-04-25 21:08:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 21:08:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 21:08:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 21:08:57 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:57 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 21:08:57 --> Helper loaded: url_helper
DEBUG - 2011-04-25 21:08:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 21:08:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 21:08:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 21:08:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 21:08:57 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:57 --> Total execution time: 0.0505
DEBUG - 2011-04-25 21:08:58 --> Config Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Hooks Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Utf8 Class Initialized
DEBUG - 2011-04-25 21:08:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 21:08:58 --> URI Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Router Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Output Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Input Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 21:08:58 --> Language Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Loader Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Controller Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Model Class Initialized
DEBUG - 2011-04-25 21:08:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 21:08:58 --> Database Driver Class Initialized
DEBUG - 2011-04-25 21:08:59 --> Final output sent to browser
DEBUG - 2011-04-25 21:08:59 --> Total execution time: 0.5857
DEBUG - 2011-04-25 22:56:58 --> Config Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Hooks Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Config Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Hooks Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Utf8 Class Initialized
DEBUG - 2011-04-25 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 22:56:58 --> Utf8 Class Initialized
DEBUG - 2011-04-25 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 22:56:58 --> URI Class Initialized
DEBUG - 2011-04-25 22:56:58 --> URI Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Router Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Router Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Output Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Output Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Input Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Input Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 22:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 22:56:58 --> Language Class Initialized
DEBUG - 2011-04-25 22:56:58 --> Language Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Loader Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Loader Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Controller Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Controller Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Model Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Model Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Model Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-04-25 22:56:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 22:56:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 22:56:59 --> Model Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Model Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 22:56:59 --> Database Driver Class Initialized
DEBUG - 2011-04-25 22:56:59 --> Database Driver Class Initialized
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 22:56:59 --> Helper loaded: url_helper
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 22:56:59 --> Final output sent to browser
DEBUG - 2011-04-25 22:56:59 --> Total execution time: 0.3311
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 22:56:59 --> Helper loaded: url_helper
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 22:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 22:56:59 --> Final output sent to browser
DEBUG - 2011-04-25 22:56:59 --> Total execution time: 0.5318
DEBUG - 2011-04-25 23:14:33 --> Config Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Hooks Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Utf8 Class Initialized
DEBUG - 2011-04-25 23:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 23:14:33 --> URI Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Router Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Output Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Input Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 23:14:33 --> Language Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Loader Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Controller Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Model Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Model Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Model Class Initialized
DEBUG - 2011-04-25 23:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 23:14:33 --> Database Driver Class Initialized
DEBUG - 2011-04-25 23:14:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 23:14:33 --> Helper loaded: url_helper
DEBUG - 2011-04-25 23:14:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 23:14:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 23:14:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 23:14:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 23:14:33 --> Final output sent to browser
DEBUG - 2011-04-25 23:14:33 --> Total execution time: 0.1358
DEBUG - 2011-04-25 23:14:36 --> Config Class Initialized
DEBUG - 2011-04-25 23:14:36 --> Hooks Class Initialized
DEBUG - 2011-04-25 23:14:36 --> Utf8 Class Initialized
DEBUG - 2011-04-25 23:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 23:14:36 --> URI Class Initialized
DEBUG - 2011-04-25 23:14:36 --> Router Class Initialized
ERROR - 2011-04-25 23:14:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 23:14:48 --> Config Class Initialized
DEBUG - 2011-04-25 23:14:48 --> Hooks Class Initialized
DEBUG - 2011-04-25 23:14:48 --> Utf8 Class Initialized
DEBUG - 2011-04-25 23:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 23:14:48 --> URI Class Initialized
DEBUG - 2011-04-25 23:14:48 --> Router Class Initialized
ERROR - 2011-04-25 23:14:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-25 23:32:31 --> Config Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Hooks Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Utf8 Class Initialized
DEBUG - 2011-04-25 23:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 23:32:31 --> URI Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Router Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Output Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Input Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 23:32:31 --> Language Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Loader Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Controller Class Initialized
DEBUG - 2011-04-25 23:32:31 --> Model Class Initialized
DEBUG - 2011-04-25 23:32:32 --> Model Class Initialized
DEBUG - 2011-04-25 23:32:32 --> Model Class Initialized
DEBUG - 2011-04-25 23:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 23:32:32 --> Database Driver Class Initialized
DEBUG - 2011-04-25 23:32:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-25 23:32:32 --> Helper loaded: url_helper
DEBUG - 2011-04-25 23:32:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 23:32:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 23:32:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 23:32:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 23:32:32 --> Final output sent to browser
DEBUG - 2011-04-25 23:32:32 --> Total execution time: 0.4160
DEBUG - 2011-04-25 23:32:33 --> Config Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Hooks Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Utf8 Class Initialized
DEBUG - 2011-04-25 23:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-25 23:32:33 --> URI Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Router Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Output Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Input Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-25 23:32:33 --> Language Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Loader Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Controller Class Initialized
ERROR - 2011-04-25 23:32:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-25 23:32:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-25 23:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 23:32:33 --> Model Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Model Class Initialized
DEBUG - 2011-04-25 23:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-25 23:32:33 --> Database Driver Class Initialized
DEBUG - 2011-04-25 23:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-25 23:32:33 --> Helper loaded: url_helper
DEBUG - 2011-04-25 23:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-25 23:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-25 23:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-25 23:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-25 23:32:33 --> Final output sent to browser
DEBUG - 2011-04-25 23:32:33 --> Total execution time: 0.0691

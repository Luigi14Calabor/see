<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-22 00:51:07 --> Config Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Hooks Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Utf8 Class Initialized
DEBUG - 2011-06-22 00:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 00:51:07 --> URI Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Router Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Output Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Input Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 00:51:07 --> Language Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Loader Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Controller Class Initialized
ERROR - 2011-06-22 00:51:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 00:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 00:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 00:51:07 --> Model Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Model Class Initialized
DEBUG - 2011-06-22 00:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 00:51:07 --> Database Driver Class Initialized
DEBUG - 2011-06-22 00:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 00:51:07 --> Helper loaded: url_helper
DEBUG - 2011-06-22 00:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 00:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 00:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 00:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 00:51:07 --> Final output sent to browser
DEBUG - 2011-06-22 00:51:07 --> Total execution time: 0.3898
DEBUG - 2011-06-22 05:48:39 --> Config Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Hooks Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Utf8 Class Initialized
DEBUG - 2011-06-22 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 05:48:39 --> URI Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Router Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Output Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Input Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 05:48:39 --> Language Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Loader Class Initialized
DEBUG - 2011-06-22 05:48:39 --> Controller Class Initialized
ERROR - 2011-06-22 05:48:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 05:48:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 05:48:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 05:48:40 --> Model Class Initialized
DEBUG - 2011-06-22 05:48:40 --> Model Class Initialized
DEBUG - 2011-06-22 05:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 05:48:40 --> Database Driver Class Initialized
DEBUG - 2011-06-22 05:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 05:48:40 --> Helper loaded: url_helper
DEBUG - 2011-06-22 05:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 05:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 05:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 05:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 05:48:40 --> Final output sent to browser
DEBUG - 2011-06-22 05:48:40 --> Total execution time: 0.6979
DEBUG - 2011-06-22 05:48:41 --> Config Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Hooks Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Utf8 Class Initialized
DEBUG - 2011-06-22 05:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 05:48:41 --> URI Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Router Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Output Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Input Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 05:48:41 --> Language Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Loader Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Controller Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Model Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Model Class Initialized
DEBUG - 2011-06-22 05:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 05:48:41 --> Database Driver Class Initialized
DEBUG - 2011-06-22 05:48:42 --> Final output sent to browser
DEBUG - 2011-06-22 05:48:42 --> Total execution time: 0.9295
DEBUG - 2011-06-22 05:48:43 --> Config Class Initialized
DEBUG - 2011-06-22 05:48:43 --> Hooks Class Initialized
DEBUG - 2011-06-22 05:48:43 --> Utf8 Class Initialized
DEBUG - 2011-06-22 05:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 05:48:43 --> URI Class Initialized
DEBUG - 2011-06-22 05:48:43 --> Router Class Initialized
ERROR - 2011-06-22 05:48:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:33:52 --> Config Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:33:52 --> URI Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Router Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Output Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Input Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:33:52 --> Language Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Loader Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Controller Class Initialized
ERROR - 2011-06-22 07:33:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:33:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:33:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:33:52 --> Model Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Model Class Initialized
DEBUG - 2011-06-22 07:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:33:52 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:33:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:33:52 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:33:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:33:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:33:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:33:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:33:52 --> Final output sent to browser
DEBUG - 2011-06-22 07:33:52 --> Total execution time: 0.3150
DEBUG - 2011-06-22 07:33:53 --> Config Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:33:53 --> URI Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Router Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Output Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Input Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:33:53 --> Language Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Loader Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Controller Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Model Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Model Class Initialized
DEBUG - 2011-06-22 07:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:33:53 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:33:54 --> Final output sent to browser
DEBUG - 2011-06-22 07:33:54 --> Total execution time: 0.7670
DEBUG - 2011-06-22 07:33:56 --> Config Class Initialized
DEBUG - 2011-06-22 07:33:56 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:33:56 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:33:56 --> URI Class Initialized
DEBUG - 2011-06-22 07:33:56 --> Router Class Initialized
ERROR - 2011-06-22 07:33:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:34:19 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:19 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Router Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Output Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Input Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:34:19 --> Language Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Loader Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Controller Class Initialized
ERROR - 2011-06-22 07:34:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:34:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:34:19 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:34:19 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:34:19 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:34:19 --> Final output sent to browser
DEBUG - 2011-06-22 07:34:19 --> Total execution time: 0.0348
DEBUG - 2011-06-22 07:34:20 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:20 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Router Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Output Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Input Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:34:20 --> Language Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Loader Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Controller Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:34:20 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:34:21 --> Final output sent to browser
DEBUG - 2011-06-22 07:34:21 --> Total execution time: 0.6694
DEBUG - 2011-06-22 07:34:22 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:22 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:22 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:22 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:22 --> Router Class Initialized
ERROR - 2011-06-22 07:34:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:34:38 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:38 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Router Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Output Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Input Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:34:38 --> Language Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Loader Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Controller Class Initialized
ERROR - 2011-06-22 07:34:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:34:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:34:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:34:38 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:34:38 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:34:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:34:38 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:34:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:34:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:34:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:34:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:34:38 --> Final output sent to browser
DEBUG - 2011-06-22 07:34:38 --> Total execution time: 0.0318
DEBUG - 2011-06-22 07:34:39 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:39 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Router Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Output Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Input Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:34:39 --> Language Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Loader Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Controller Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:34:39 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:34:39 --> Final output sent to browser
DEBUG - 2011-06-22 07:34:39 --> Total execution time: 0.6591
DEBUG - 2011-06-22 07:34:41 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:41 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:41 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:41 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:41 --> Router Class Initialized
ERROR - 2011-06-22 07:34:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:34:54 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:54 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Router Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Output Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Input Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:34:54 --> Language Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Loader Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Controller Class Initialized
ERROR - 2011-06-22 07:34:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:34:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:34:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:34:54 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:34:54 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:34:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:34:54 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:34:54 --> Final output sent to browser
DEBUG - 2011-06-22 07:34:54 --> Total execution time: 0.0303
DEBUG - 2011-06-22 07:34:55 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:55 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Router Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Output Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Input Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:34:55 --> Language Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Loader Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Controller Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Model Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:34:55 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:34:55 --> Final output sent to browser
DEBUG - 2011-06-22 07:34:55 --> Total execution time: 0.5568
DEBUG - 2011-06-22 07:34:57 --> Config Class Initialized
DEBUG - 2011-06-22 07:34:57 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:34:57 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:34:57 --> URI Class Initialized
DEBUG - 2011-06-22 07:34:57 --> Router Class Initialized
ERROR - 2011-06-22 07:34:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:35:06 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:06 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:06 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Controller Class Initialized
ERROR - 2011-06-22 07:35:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:35:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:35:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:06 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:06 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:06 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:35:06 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:06 --> Total execution time: 0.1058
DEBUG - 2011-06-22 07:35:07 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:07 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:07 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Controller Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:07 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:08 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:08 --> Total execution time: 0.7215
DEBUG - 2011-06-22 07:35:09 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:09 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:09 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:09 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:09 --> Router Class Initialized
ERROR - 2011-06-22 07:35:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:35:19 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:19 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:19 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Controller Class Initialized
ERROR - 2011-06-22 07:35:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:35:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:35:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:19 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:19 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:19 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:35:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:35:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:35:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:35:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:35:19 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:19 --> Total execution time: 0.0291
DEBUG - 2011-06-22 07:35:20 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:20 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:20 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Controller Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:20 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:21 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:21 --> Total execution time: 0.7588
DEBUG - 2011-06-22 07:35:22 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:22 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:22 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:22 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:22 --> Router Class Initialized
ERROR - 2011-06-22 07:35:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:35:32 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:32 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:32 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Controller Class Initialized
ERROR - 2011-06-22 07:35:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:35:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:32 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:32 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:32 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:35:32 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:32 --> Total execution time: 0.0286
DEBUG - 2011-06-22 07:35:33 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:33 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:33 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Controller Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:33 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:34 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:34 --> Total execution time: 1.2725
DEBUG - 2011-06-22 07:35:36 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:36 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:36 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:36 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:36 --> Router Class Initialized
ERROR - 2011-06-22 07:35:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:35:56 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:56 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:56 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Controller Class Initialized
ERROR - 2011-06-22 07:35:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:35:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:35:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:56 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:56 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:56 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:35:56 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:56 --> Total execution time: 0.0423
DEBUG - 2011-06-22 07:35:57 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:57 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:57 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Controller Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:57 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:57 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:57 --> Total execution time: 0.5630
DEBUG - 2011-06-22 07:35:58 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:58 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Router Class Initialized
ERROR - 2011-06-22 07:35:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-22 07:35:58 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:58 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Router Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Output Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Input Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 07:35:58 --> Language Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Loader Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Controller Class Initialized
ERROR - 2011-06-22 07:35:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 07:35:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 07:35:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:58 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Model Class Initialized
DEBUG - 2011-06-22 07:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 07:35:58 --> Database Driver Class Initialized
DEBUG - 2011-06-22 07:35:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 07:35:58 --> Helper loaded: url_helper
DEBUG - 2011-06-22 07:35:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 07:35:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 07:35:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 07:35:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 07:35:58 --> Final output sent to browser
DEBUG - 2011-06-22 07:35:58 --> Total execution time: 0.0270
DEBUG - 2011-06-22 07:35:59 --> Config Class Initialized
DEBUG - 2011-06-22 07:35:59 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:35:59 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:35:59 --> URI Class Initialized
DEBUG - 2011-06-22 07:35:59 --> Router Class Initialized
ERROR - 2011-06-22 07:35:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 07:54:12 --> Config Class Initialized
DEBUG - 2011-06-22 07:54:12 --> Hooks Class Initialized
DEBUG - 2011-06-22 07:54:12 --> Utf8 Class Initialized
DEBUG - 2011-06-22 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 07:54:12 --> URI Class Initialized
DEBUG - 2011-06-22 07:54:12 --> Router Class Initialized
ERROR - 2011-06-22 07:54:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-22 09:47:54 --> Config Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Hooks Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Utf8 Class Initialized
DEBUG - 2011-06-22 09:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 09:47:54 --> URI Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Router Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Output Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Input Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 09:47:54 --> Language Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Loader Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Controller Class Initialized
ERROR - 2011-06-22 09:47:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 09:47:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 09:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 09:47:54 --> Model Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Model Class Initialized
DEBUG - 2011-06-22 09:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 09:47:54 --> Database Driver Class Initialized
DEBUG - 2011-06-22 09:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 09:47:54 --> Helper loaded: url_helper
DEBUG - 2011-06-22 09:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 09:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 09:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 09:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 09:47:54 --> Final output sent to browser
DEBUG - 2011-06-22 09:47:54 --> Total execution time: 0.3451
DEBUG - 2011-06-22 11:22:39 --> Config Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Hooks Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Utf8 Class Initialized
DEBUG - 2011-06-22 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 11:22:39 --> URI Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Router Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Output Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Input Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 11:22:39 --> Language Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Loader Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Controller Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Model Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Model Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Model Class Initialized
DEBUG - 2011-06-22 11:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 11:22:39 --> Database Driver Class Initialized
DEBUG - 2011-06-22 11:22:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 11:22:40 --> Helper loaded: url_helper
DEBUG - 2011-06-22 11:22:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 11:22:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 11:22:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 11:22:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 11:22:40 --> Final output sent to browser
DEBUG - 2011-06-22 11:22:40 --> Total execution time: 0.8953
DEBUG - 2011-06-22 11:22:53 --> Config Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Hooks Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Utf8 Class Initialized
DEBUG - 2011-06-22 11:22:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 11:22:53 --> URI Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Router Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Output Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Input Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 11:22:53 --> Language Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Loader Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Controller Class Initialized
ERROR - 2011-06-22 11:22:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 11:22:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 11:22:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 11:22:53 --> Model Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Model Class Initialized
DEBUG - 2011-06-22 11:22:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 11:22:53 --> Database Driver Class Initialized
DEBUG - 2011-06-22 11:22:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 11:22:53 --> Helper loaded: url_helper
DEBUG - 2011-06-22 11:22:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 11:22:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 11:22:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 11:22:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 11:22:53 --> Final output sent to browser
DEBUG - 2011-06-22 11:22:53 --> Total execution time: 0.0865
DEBUG - 2011-06-22 12:34:21 --> Config Class Initialized
DEBUG - 2011-06-22 12:34:21 --> Hooks Class Initialized
DEBUG - 2011-06-22 12:34:21 --> Utf8 Class Initialized
DEBUG - 2011-06-22 12:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 12:34:21 --> URI Class Initialized
DEBUG - 2011-06-22 12:34:21 --> Router Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Output Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Input Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 12:34:22 --> Language Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Loader Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Controller Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Model Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Model Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Model Class Initialized
DEBUG - 2011-06-22 12:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 12:34:22 --> Database Driver Class Initialized
DEBUG - 2011-06-22 12:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 12:34:22 --> Helper loaded: url_helper
DEBUG - 2011-06-22 12:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 12:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 12:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 12:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 12:34:22 --> Final output sent to browser
DEBUG - 2011-06-22 12:34:22 --> Total execution time: 0.9406
DEBUG - 2011-06-22 12:34:27 --> Config Class Initialized
DEBUG - 2011-06-22 12:34:27 --> Hooks Class Initialized
DEBUG - 2011-06-22 12:34:27 --> Utf8 Class Initialized
DEBUG - 2011-06-22 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 12:34:27 --> URI Class Initialized
DEBUG - 2011-06-22 12:34:27 --> Router Class Initialized
ERROR - 2011-06-22 12:34:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 12:34:29 --> Config Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Hooks Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Utf8 Class Initialized
DEBUG - 2011-06-22 12:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 12:34:29 --> URI Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Router Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Output Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Input Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 12:34:29 --> Language Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Loader Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Controller Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Model Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Model Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Model Class Initialized
DEBUG - 2011-06-22 12:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 12:34:29 --> Database Driver Class Initialized
DEBUG - 2011-06-22 12:34:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 12:34:29 --> Helper loaded: url_helper
DEBUG - 2011-06-22 12:34:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 12:34:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 12:34:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 12:34:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 12:34:29 --> Final output sent to browser
DEBUG - 2011-06-22 12:34:29 --> Total execution time: 0.0706
DEBUG - 2011-06-22 13:23:44 --> Config Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Hooks Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Utf8 Class Initialized
DEBUG - 2011-06-22 13:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 13:23:44 --> URI Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Router Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Output Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Input Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 13:23:44 --> Language Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Loader Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Controller Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Model Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Model Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Model Class Initialized
DEBUG - 2011-06-22 13:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 13:23:44 --> Database Driver Class Initialized
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 13:23:45 --> Helper loaded: url_helper
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 13:23:45 --> Final output sent to browser
DEBUG - 2011-06-22 13:23:45 --> Total execution time: 0.8241
DEBUG - 2011-06-22 13:23:45 --> Config Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Hooks Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Utf8 Class Initialized
DEBUG - 2011-06-22 13:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 13:23:45 --> URI Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Router Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Output Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Input Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 13:23:45 --> Language Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Loader Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Controller Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Model Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Model Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Model Class Initialized
DEBUG - 2011-06-22 13:23:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 13:23:45 --> Database Driver Class Initialized
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 13:23:45 --> Helper loaded: url_helper
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 13:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 13:23:45 --> Final output sent to browser
DEBUG - 2011-06-22 13:23:45 --> Total execution time: 0.0438
DEBUG - 2011-06-22 13:23:47 --> Config Class Initialized
DEBUG - 2011-06-22 13:23:47 --> Hooks Class Initialized
DEBUG - 2011-06-22 13:23:47 --> Utf8 Class Initialized
DEBUG - 2011-06-22 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 13:23:47 --> URI Class Initialized
DEBUG - 2011-06-22 13:23:47 --> Router Class Initialized
ERROR - 2011-06-22 13:23:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 14:11:09 --> Config Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Hooks Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Utf8 Class Initialized
DEBUG - 2011-06-22 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 14:11:09 --> URI Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Router Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Output Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Input Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 14:11:09 --> Language Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Loader Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Controller Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Model Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Model Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Model Class Initialized
DEBUG - 2011-06-22 14:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 14:11:09 --> Database Driver Class Initialized
DEBUG - 2011-06-22 14:11:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 14:11:09 --> Helper loaded: url_helper
DEBUG - 2011-06-22 14:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 14:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 14:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 14:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 14:11:09 --> Final output sent to browser
DEBUG - 2011-06-22 14:11:09 --> Total execution time: 0.6456
DEBUG - 2011-06-22 14:11:10 --> Config Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Hooks Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Utf8 Class Initialized
DEBUG - 2011-06-22 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 14:11:10 --> URI Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Router Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Output Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Input Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 14:11:10 --> Language Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Loader Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Controller Class Initialized
ERROR - 2011-06-22 14:11:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 14:11:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 14:11:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 14:11:10 --> Model Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Model Class Initialized
DEBUG - 2011-06-22 14:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 14:11:10 --> Database Driver Class Initialized
DEBUG - 2011-06-22 14:11:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 14:11:10 --> Helper loaded: url_helper
DEBUG - 2011-06-22 14:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 14:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 14:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 14:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 14:11:10 --> Final output sent to browser
DEBUG - 2011-06-22 14:11:10 --> Total execution time: 0.0929
DEBUG - 2011-06-22 14:41:12 --> Config Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Config Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Hooks Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Hooks Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Utf8 Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Utf8 Class Initialized
DEBUG - 2011-06-22 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 14:41:12 --> URI Class Initialized
DEBUG - 2011-06-22 14:41:12 --> URI Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Router Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Router Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Output Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Output Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Input Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Input Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 14:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 14:41:12 --> Language Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Language Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Loader Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Loader Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Controller Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Controller Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Model Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Model Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Model Class Initialized
ERROR - 2011-06-22 14:41:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 14:41:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 14:41:12 --> Model Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Model Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 14:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 14:41:12 --> Database Driver Class Initialized
DEBUG - 2011-06-22 14:41:12 --> Database Driver Class Initialized
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 14:41:12 --> Helper loaded: url_helper
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 14:41:12 --> Final output sent to browser
DEBUG - 2011-06-22 14:41:12 --> Total execution time: 0.3574
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 14:41:12 --> Helper loaded: url_helper
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 14:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 14:41:12 --> Final output sent to browser
DEBUG - 2011-06-22 14:41:12 --> Total execution time: 0.4738
DEBUG - 2011-06-22 15:04:20 --> Config Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Hooks Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Utf8 Class Initialized
DEBUG - 2011-06-22 15:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 15:04:20 --> URI Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Router Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Output Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Input Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 15:04:20 --> Language Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Loader Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Controller Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Model Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Model Class Initialized
DEBUG - 2011-06-22 15:04:20 --> Model Class Initialized
DEBUG - 2011-06-22 15:04:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 15:04:21 --> Database Driver Class Initialized
DEBUG - 2011-06-22 15:04:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 15:04:21 --> Helper loaded: url_helper
DEBUG - 2011-06-22 15:04:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 15:04:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 15:04:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 15:04:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 15:04:21 --> Final output sent to browser
DEBUG - 2011-06-22 15:04:21 --> Total execution time: 0.3977
DEBUG - 2011-06-22 15:04:22 --> Config Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Hooks Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Utf8 Class Initialized
DEBUG - 2011-06-22 15:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 15:04:22 --> URI Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Router Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Output Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Input Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 15:04:22 --> Language Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Loader Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Controller Class Initialized
ERROR - 2011-06-22 15:04:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 15:04:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 15:04:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 15:04:22 --> Model Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Model Class Initialized
DEBUG - 2011-06-22 15:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 15:04:22 --> Database Driver Class Initialized
DEBUG - 2011-06-22 15:04:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 15:04:22 --> Helper loaded: url_helper
DEBUG - 2011-06-22 15:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 15:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 15:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 15:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 15:04:22 --> Final output sent to browser
DEBUG - 2011-06-22 15:04:22 --> Total execution time: 0.0809
DEBUG - 2011-06-22 15:56:01 --> Config Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Hooks Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Utf8 Class Initialized
DEBUG - 2011-06-22 15:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 15:56:01 --> URI Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Router Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Output Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Input Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 15:56:01 --> Language Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Loader Class Initialized
DEBUG - 2011-06-22 15:56:01 --> Controller Class Initialized
DEBUG - 2011-06-22 15:56:02 --> Model Class Initialized
DEBUG - 2011-06-22 15:56:02 --> Model Class Initialized
DEBUG - 2011-06-22 15:56:02 --> Model Class Initialized
DEBUG - 2011-06-22 15:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 15:56:02 --> Database Driver Class Initialized
DEBUG - 2011-06-22 15:56:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 15:56:02 --> Helper loaded: url_helper
DEBUG - 2011-06-22 15:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 15:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 15:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 15:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 15:56:02 --> Final output sent to browser
DEBUG - 2011-06-22 15:56:02 --> Total execution time: 0.8954
DEBUG - 2011-06-22 15:56:03 --> Config Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Hooks Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Utf8 Class Initialized
DEBUG - 2011-06-22 15:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 15:56:03 --> URI Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Router Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Output Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Input Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 15:56:03 --> Language Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Loader Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Controller Class Initialized
ERROR - 2011-06-22 15:56:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 15:56:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 15:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 15:56:03 --> Model Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Model Class Initialized
DEBUG - 2011-06-22 15:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 15:56:03 --> Database Driver Class Initialized
DEBUG - 2011-06-22 15:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 15:56:03 --> Helper loaded: url_helper
DEBUG - 2011-06-22 15:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 15:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 15:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 15:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 15:56:03 --> Final output sent to browser
DEBUG - 2011-06-22 15:56:03 --> Total execution time: 0.0784
DEBUG - 2011-06-22 16:48:09 --> Config Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Hooks Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Utf8 Class Initialized
DEBUG - 2011-06-22 16:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 16:48:09 --> URI Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Router Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Output Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Input Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 16:48:09 --> Language Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Loader Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Controller Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Model Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Model Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Model Class Initialized
DEBUG - 2011-06-22 16:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 16:48:09 --> Database Driver Class Initialized
DEBUG - 2011-06-22 16:48:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 16:48:09 --> Helper loaded: url_helper
DEBUG - 2011-06-22 16:48:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 16:48:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 16:48:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 16:48:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 16:48:09 --> Final output sent to browser
DEBUG - 2011-06-22 16:48:09 --> Total execution time: 0.7058
DEBUG - 2011-06-22 16:48:10 --> Config Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Hooks Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Utf8 Class Initialized
DEBUG - 2011-06-22 16:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 16:48:10 --> URI Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Router Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Output Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Input Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 16:48:10 --> Language Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Loader Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Controller Class Initialized
ERROR - 2011-06-22 16:48:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 16:48:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 16:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 16:48:10 --> Model Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Model Class Initialized
DEBUG - 2011-06-22 16:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 16:48:10 --> Database Driver Class Initialized
DEBUG - 2011-06-22 16:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 16:48:10 --> Helper loaded: url_helper
DEBUG - 2011-06-22 16:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 16:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 16:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 16:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 16:48:10 --> Final output sent to browser
DEBUG - 2011-06-22 16:48:10 --> Total execution time: 0.1128
DEBUG - 2011-06-22 16:58:49 --> Config Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Hooks Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Utf8 Class Initialized
DEBUG - 2011-06-22 16:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 16:58:49 --> URI Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Router Class Initialized
ERROR - 2011-06-22 16:58:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-22 16:58:49 --> Config Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Hooks Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Utf8 Class Initialized
DEBUG - 2011-06-22 16:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 16:58:49 --> URI Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Router Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Output Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Input Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 16:58:49 --> Language Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Loader Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Controller Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Model Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Model Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Model Class Initialized
DEBUG - 2011-06-22 16:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 16:58:49 --> Database Driver Class Initialized
DEBUG - 2011-06-22 16:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 16:58:49 --> Helper loaded: url_helper
DEBUG - 2011-06-22 16:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 16:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 16:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 16:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 16:58:49 --> Final output sent to browser
DEBUG - 2011-06-22 16:58:49 --> Total execution time: 0.1282
DEBUG - 2011-06-22 17:53:00 --> Config Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Hooks Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Utf8 Class Initialized
DEBUG - 2011-06-22 17:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 17:53:00 --> URI Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Router Class Initialized
ERROR - 2011-06-22 17:53:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-22 17:53:00 --> Config Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Hooks Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Utf8 Class Initialized
DEBUG - 2011-06-22 17:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 17:53:00 --> URI Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Router Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Output Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Input Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 17:53:00 --> Language Class Initialized
DEBUG - 2011-06-22 17:53:00 --> Loader Class Initialized
DEBUG - 2011-06-22 17:53:01 --> Controller Class Initialized
ERROR - 2011-06-22 17:53:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 17:53:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 17:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 17:53:01 --> Model Class Initialized
DEBUG - 2011-06-22 17:53:01 --> Model Class Initialized
DEBUG - 2011-06-22 17:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 17:53:01 --> Database Driver Class Initialized
DEBUG - 2011-06-22 17:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 17:53:01 --> Helper loaded: url_helper
DEBUG - 2011-06-22 17:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 17:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 17:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 17:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 17:53:01 --> Final output sent to browser
DEBUG - 2011-06-22 17:53:01 --> Total execution time: 0.6075
DEBUG - 2011-06-22 17:58:01 --> Config Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Hooks Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Utf8 Class Initialized
DEBUG - 2011-06-22 17:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 17:58:01 --> URI Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Router Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Output Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Input Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 17:58:01 --> Language Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Loader Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Controller Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Model Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Model Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Model Class Initialized
DEBUG - 2011-06-22 17:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 17:58:01 --> Database Driver Class Initialized
DEBUG - 2011-06-22 17:58:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 17:58:01 --> Helper loaded: url_helper
DEBUG - 2011-06-22 17:58:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 17:58:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 17:58:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 17:58:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 17:58:01 --> Final output sent to browser
DEBUG - 2011-06-22 17:58:01 --> Total execution time: 0.3910
DEBUG - 2011-06-22 17:58:02 --> Config Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Hooks Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Utf8 Class Initialized
DEBUG - 2011-06-22 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 17:58:02 --> URI Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Router Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Output Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Input Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 17:58:02 --> Language Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Loader Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Controller Class Initialized
ERROR - 2011-06-22 17:58:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 17:58:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 17:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 17:58:02 --> Model Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Model Class Initialized
DEBUG - 2011-06-22 17:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 17:58:02 --> Database Driver Class Initialized
DEBUG - 2011-06-22 17:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 17:58:02 --> Helper loaded: url_helper
DEBUG - 2011-06-22 17:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 17:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 17:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 17:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 17:58:02 --> Final output sent to browser
DEBUG - 2011-06-22 17:58:02 --> Total execution time: 0.0310
DEBUG - 2011-06-22 18:09:21 --> Config Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:09:21 --> URI Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Router Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Output Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Input Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:09:21 --> Language Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Loader Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Controller Class Initialized
DEBUG - 2011-06-22 18:09:21 --> Model Class Initialized
DEBUG - 2011-06-22 18:09:22 --> Model Class Initialized
DEBUG - 2011-06-22 18:09:22 --> Model Class Initialized
DEBUG - 2011-06-22 18:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:09:22 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:09:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-22 18:09:22 --> Helper loaded: url_helper
DEBUG - 2011-06-22 18:09:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 18:09:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 18:09:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 18:09:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 18:09:22 --> Final output sent to browser
DEBUG - 2011-06-22 18:09:22 --> Total execution time: 0.5165
DEBUG - 2011-06-22 18:18:55 --> Config Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:18:55 --> URI Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Router Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Output Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Input Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:18:55 --> Language Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Loader Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Controller Class Initialized
ERROR - 2011-06-22 18:18:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 18:18:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 18:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:18:55 --> Model Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Model Class Initialized
DEBUG - 2011-06-22 18:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:18:55 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:18:55 --> Helper loaded: url_helper
DEBUG - 2011-06-22 18:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 18:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 18:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 18:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 18:18:55 --> Final output sent to browser
DEBUG - 2011-06-22 18:18:55 --> Total execution time: 0.0817
DEBUG - 2011-06-22 18:18:56 --> Config Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:18:56 --> URI Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Router Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Output Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Input Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:18:56 --> Language Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Loader Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Controller Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Model Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Model Class Initialized
DEBUG - 2011-06-22 18:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:18:56 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:18:57 --> Final output sent to browser
DEBUG - 2011-06-22 18:18:57 --> Total execution time: 0.5262
DEBUG - 2011-06-22 18:18:58 --> Config Class Initialized
DEBUG - 2011-06-22 18:18:58 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:18:58 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:18:58 --> URI Class Initialized
DEBUG - 2011-06-22 18:18:58 --> Router Class Initialized
ERROR - 2011-06-22 18:18:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 18:19:06 --> Config Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:19:06 --> URI Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Router Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Output Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Input Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:19:06 --> Language Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Loader Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Controller Class Initialized
ERROR - 2011-06-22 18:19:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 18:19:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 18:19:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:19:06 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:19:06 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:19:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:19:06 --> Helper loaded: url_helper
DEBUG - 2011-06-22 18:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 18:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 18:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 18:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 18:19:06 --> Final output sent to browser
DEBUG - 2011-06-22 18:19:06 --> Total execution time: 0.0273
DEBUG - 2011-06-22 18:19:11 --> Config Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:19:11 --> URI Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Router Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Output Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Input Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:19:11 --> Language Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Loader Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Controller Class Initialized
ERROR - 2011-06-22 18:19:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 18:19:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 18:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:19:11 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:19:11 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:19:11 --> Helper loaded: url_helper
DEBUG - 2011-06-22 18:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 18:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 18:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 18:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 18:19:11 --> Final output sent to browser
DEBUG - 2011-06-22 18:19:11 --> Total execution time: 0.0340
DEBUG - 2011-06-22 18:19:11 --> Config Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:19:11 --> URI Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Router Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Output Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Input Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:19:11 --> Language Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Loader Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Controller Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:19:11 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:19:12 --> Final output sent to browser
DEBUG - 2011-06-22 18:19:12 --> Total execution time: 0.5436
DEBUG - 2011-06-22 18:19:18 --> Config Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Hooks Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Utf8 Class Initialized
DEBUG - 2011-06-22 18:19:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 18:19:18 --> URI Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Router Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Output Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Input Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 18:19:18 --> Language Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Loader Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Controller Class Initialized
ERROR - 2011-06-22 18:19:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 18:19:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 18:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:19:18 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Model Class Initialized
DEBUG - 2011-06-22 18:19:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 18:19:18 --> Database Driver Class Initialized
DEBUG - 2011-06-22 18:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 18:19:18 --> Helper loaded: url_helper
DEBUG - 2011-06-22 18:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 18:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 18:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 18:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 18:19:18 --> Final output sent to browser
DEBUG - 2011-06-22 18:19:18 --> Total execution time: 0.0287
DEBUG - 2011-06-22 19:02:54 --> Config Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:02:54 --> URI Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Router Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Output Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Input Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 19:02:54 --> Language Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Loader Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Controller Class Initialized
ERROR - 2011-06-22 19:02:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 19:02:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 19:02:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 19:02:54 --> Model Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Model Class Initialized
DEBUG - 2011-06-22 19:02:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 19:02:54 --> Database Driver Class Initialized
DEBUG - 2011-06-22 19:02:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 19:02:54 --> Helper loaded: url_helper
DEBUG - 2011-06-22 19:02:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 19:02:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 19:02:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 19:02:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 19:02:54 --> Final output sent to browser
DEBUG - 2011-06-22 19:02:54 --> Total execution time: 0.2831
DEBUG - 2011-06-22 19:02:56 --> Config Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:02:56 --> URI Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Router Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Output Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Input Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 19:02:56 --> Language Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Loader Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Controller Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Model Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Model Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 19:02:56 --> Database Driver Class Initialized
DEBUG - 2011-06-22 19:02:56 --> Final output sent to browser
DEBUG - 2011-06-22 19:02:56 --> Total execution time: 0.6201
DEBUG - 2011-06-22 19:02:58 --> Config Class Initialized
DEBUG - 2011-06-22 19:02:58 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:02:58 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:02:58 --> URI Class Initialized
DEBUG - 2011-06-22 19:02:58 --> Router Class Initialized
ERROR - 2011-06-22 19:02:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 19:05:11 --> Config Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:05:11 --> URI Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Router Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Output Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Input Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 19:05:11 --> Language Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Loader Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Controller Class Initialized
ERROR - 2011-06-22 19:05:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-22 19:05:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-22 19:05:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 19:05:11 --> Model Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Model Class Initialized
DEBUG - 2011-06-22 19:05:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 19:05:11 --> Database Driver Class Initialized
DEBUG - 2011-06-22 19:05:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-22 19:05:11 --> Helper loaded: url_helper
DEBUG - 2011-06-22 19:05:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-22 19:05:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-22 19:05:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-22 19:05:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-22 19:05:11 --> Final output sent to browser
DEBUG - 2011-06-22 19:05:11 --> Total execution time: 0.0277
DEBUG - 2011-06-22 19:05:12 --> Config Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:05:12 --> URI Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Router Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Output Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Input Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-22 19:05:12 --> Language Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Loader Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Controller Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Model Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Model Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-22 19:05:12 --> Database Driver Class Initialized
DEBUG - 2011-06-22 19:05:12 --> Final output sent to browser
DEBUG - 2011-06-22 19:05:12 --> Total execution time: 0.5053
DEBUG - 2011-06-22 19:05:15 --> Config Class Initialized
DEBUG - 2011-06-22 19:05:15 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:05:15 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:05:15 --> URI Class Initialized
DEBUG - 2011-06-22 19:05:15 --> Router Class Initialized
ERROR - 2011-06-22 19:05:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 19:05:15 --> Config Class Initialized
DEBUG - 2011-06-22 19:05:15 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:05:15 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:05:15 --> URI Class Initialized
DEBUG - 2011-06-22 19:05:15 --> Router Class Initialized
ERROR - 2011-06-22 19:05:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-22 19:05:16 --> Config Class Initialized
DEBUG - 2011-06-22 19:05:16 --> Hooks Class Initialized
DEBUG - 2011-06-22 19:05:16 --> Utf8 Class Initialized
DEBUG - 2011-06-22 19:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-22 19:05:16 --> URI Class Initialized
DEBUG - 2011-06-22 19:05:16 --> Router Class Initialized
ERROR - 2011-06-22 19:05:16 --> 404 Page Not Found --> favicon.ico

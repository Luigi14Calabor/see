<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-04 02:11:56 --> Config Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Hooks Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Utf8 Class Initialized
DEBUG - 2011-06-04 02:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 02:11:56 --> URI Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Router Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Output Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Input Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 02:11:56 --> Language Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Loader Class Initialized
DEBUG - 2011-06-04 02:11:56 --> Controller Class Initialized
ERROR - 2011-06-04 02:11:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 02:11:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 02:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 02:11:57 --> Model Class Initialized
DEBUG - 2011-06-04 02:11:57 --> Model Class Initialized
DEBUG - 2011-06-04 02:11:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 02:11:57 --> Database Driver Class Initialized
DEBUG - 2011-06-04 02:12:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 02:12:00 --> Helper loaded: url_helper
DEBUG - 2011-06-04 02:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 02:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 02:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 02:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 02:12:00 --> Final output sent to browser
DEBUG - 2011-06-04 02:12:00 --> Total execution time: 4.7828
DEBUG - 2011-06-04 02:12:02 --> Config Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Hooks Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Utf8 Class Initialized
DEBUG - 2011-06-04 02:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 02:12:02 --> URI Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Router Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Output Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Input Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 02:12:02 --> Language Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Loader Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Controller Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Model Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Model Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 02:12:02 --> Database Driver Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Config Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Hooks Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Utf8 Class Initialized
DEBUG - 2011-06-04 02:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 02:12:02 --> URI Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Router Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Output Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Input Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 02:12:02 --> Language Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Loader Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Controller Class Initialized
ERROR - 2011-06-04 02:12:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 02:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 02:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 02:12:02 --> Model Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Model Class Initialized
DEBUG - 2011-06-04 02:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 02:12:02 --> Database Driver Class Initialized
DEBUG - 2011-06-04 02:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 02:12:02 --> Helper loaded: url_helper
DEBUG - 2011-06-04 02:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 02:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 02:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 02:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 02:12:02 --> Final output sent to browser
DEBUG - 2011-06-04 02:12:02 --> Total execution time: 0.0272
DEBUG - 2011-06-04 02:12:06 --> Final output sent to browser
DEBUG - 2011-06-04 02:12:06 --> Total execution time: 4.5370
DEBUG - 2011-06-04 02:12:08 --> Config Class Initialized
DEBUG - 2011-06-04 02:12:08 --> Hooks Class Initialized
DEBUG - 2011-06-04 02:12:08 --> Utf8 Class Initialized
DEBUG - 2011-06-04 02:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 02:12:08 --> URI Class Initialized
DEBUG - 2011-06-04 02:12:08 --> Router Class Initialized
ERROR - 2011-06-04 02:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 02:12:08 --> Config Class Initialized
DEBUG - 2011-06-04 02:12:08 --> Hooks Class Initialized
DEBUG - 2011-06-04 02:12:08 --> Utf8 Class Initialized
DEBUG - 2011-06-04 02:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 02:12:08 --> URI Class Initialized
DEBUG - 2011-06-04 02:12:08 --> Router Class Initialized
ERROR - 2011-06-04 02:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 02:12:11 --> Config Class Initialized
DEBUG - 2011-06-04 02:12:11 --> Hooks Class Initialized
DEBUG - 2011-06-04 02:12:11 --> Utf8 Class Initialized
DEBUG - 2011-06-04 02:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 02:12:11 --> URI Class Initialized
DEBUG - 2011-06-04 02:12:11 --> Router Class Initialized
ERROR - 2011-06-04 02:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 03:35:55 --> Config Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Hooks Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Utf8 Class Initialized
DEBUG - 2011-06-04 03:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 03:35:55 --> URI Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Router Class Initialized
ERROR - 2011-06-04 03:35:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 03:35:55 --> Config Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Hooks Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Utf8 Class Initialized
DEBUG - 2011-06-04 03:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 03:35:55 --> URI Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Router Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Output Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Input Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 03:35:55 --> Language Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Loader Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Controller Class Initialized
ERROR - 2011-06-04 03:35:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 03:35:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 03:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 03:35:55 --> Model Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Model Class Initialized
DEBUG - 2011-06-04 03:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 03:35:55 --> Database Driver Class Initialized
DEBUG - 2011-06-04 03:35:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 03:35:56 --> Helper loaded: url_helper
DEBUG - 2011-06-04 03:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 03:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 03:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 03:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 03:35:56 --> Final output sent to browser
DEBUG - 2011-06-04 03:35:56 --> Total execution time: 0.6836
DEBUG - 2011-06-04 04:14:56 --> Config Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Hooks Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Utf8 Class Initialized
DEBUG - 2011-06-04 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 04:14:56 --> URI Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Router Class Initialized
DEBUG - 2011-06-04 04:14:56 --> No URI present. Default controller set.
DEBUG - 2011-06-04 04:14:56 --> Output Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Input Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 04:14:56 --> Language Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Loader Class Initialized
DEBUG - 2011-06-04 04:14:56 --> Controller Class Initialized
DEBUG - 2011-06-04 04:14:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-04 04:14:56 --> Helper loaded: url_helper
DEBUG - 2011-06-04 04:14:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 04:14:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 04:14:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 04:14:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 04:14:56 --> Final output sent to browser
DEBUG - 2011-06-04 04:14:56 --> Total execution time: 0.3602
DEBUG - 2011-06-04 05:18:05 --> Config Class Initialized
DEBUG - 2011-06-04 05:18:05 --> Hooks Class Initialized
DEBUG - 2011-06-04 05:18:05 --> Utf8 Class Initialized
DEBUG - 2011-06-04 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 05:18:05 --> URI Class Initialized
DEBUG - 2011-06-04 05:18:05 --> Router Class Initialized
ERROR - 2011-06-04 05:18:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 05:18:06 --> Config Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Hooks Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Utf8 Class Initialized
DEBUG - 2011-06-04 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 05:18:06 --> URI Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Router Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Output Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Input Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 05:18:06 --> Language Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Loader Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Controller Class Initialized
ERROR - 2011-06-04 05:18:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 05:18:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 05:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 05:18:06 --> Model Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Model Class Initialized
DEBUG - 2011-06-04 05:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 05:18:06 --> Database Driver Class Initialized
DEBUG - 2011-06-04 05:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 05:18:07 --> Helper loaded: url_helper
DEBUG - 2011-06-04 05:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 05:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 05:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 05:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 05:18:07 --> Final output sent to browser
DEBUG - 2011-06-04 05:18:07 --> Total execution time: 1.0555
DEBUG - 2011-06-04 05:41:49 --> Config Class Initialized
DEBUG - 2011-06-04 05:41:49 --> Hooks Class Initialized
DEBUG - 2011-06-04 05:41:49 --> Utf8 Class Initialized
DEBUG - 2011-06-04 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 05:41:49 --> URI Class Initialized
DEBUG - 2011-06-04 05:41:49 --> Router Class Initialized
DEBUG - 2011-06-04 05:41:49 --> Output Class Initialized
DEBUG - 2011-06-04 05:41:49 --> Input Class Initialized
DEBUG - 2011-06-04 05:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 05:41:49 --> Language Class Initialized
DEBUG - 2011-06-04 05:41:50 --> Loader Class Initialized
DEBUG - 2011-06-04 05:41:50 --> Controller Class Initialized
DEBUG - 2011-06-04 05:41:50 --> Model Class Initialized
DEBUG - 2011-06-04 05:41:50 --> Model Class Initialized
DEBUG - 2011-06-04 05:41:50 --> Model Class Initialized
DEBUG - 2011-06-04 05:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 05:41:50 --> Database Driver Class Initialized
DEBUG - 2011-06-04 05:41:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-04 05:41:50 --> Helper loaded: url_helper
DEBUG - 2011-06-04 05:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 05:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 05:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 05:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 05:41:50 --> Final output sent to browser
DEBUG - 2011-06-04 05:41:50 --> Total execution time: 0.8391
DEBUG - 2011-06-04 05:41:51 --> Config Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Hooks Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Utf8 Class Initialized
DEBUG - 2011-06-04 05:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 05:41:51 --> URI Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Router Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Output Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Input Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 05:41:51 --> Language Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Loader Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Controller Class Initialized
ERROR - 2011-06-04 05:41:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 05:41:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 05:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 05:41:51 --> Model Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Model Class Initialized
DEBUG - 2011-06-04 05:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 05:41:51 --> Database Driver Class Initialized
DEBUG - 2011-06-04 05:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 05:41:51 --> Helper loaded: url_helper
DEBUG - 2011-06-04 05:41:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 05:41:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 05:41:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 05:41:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 05:41:51 --> Final output sent to browser
DEBUG - 2011-06-04 05:41:51 --> Total execution time: 0.1122
DEBUG - 2011-06-04 06:16:00 --> Config Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:16:00 --> URI Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Router Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Output Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Input Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:16:00 --> Language Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Loader Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Controller Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Model Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Model Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:16:00 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:16:00 --> Final output sent to browser
DEBUG - 2011-06-04 06:16:00 --> Total execution time: 0.9551
DEBUG - 2011-06-04 06:39:11 --> Config Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:39:11 --> URI Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Router Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Output Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Input Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:39:11 --> Language Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Loader Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Controller Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Model Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Model Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Model Class Initialized
DEBUG - 2011-06-04 06:39:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:39:11 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-04 06:39:12 --> Helper loaded: url_helper
DEBUG - 2011-06-04 06:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 06:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 06:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 06:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 06:39:12 --> Final output sent to browser
DEBUG - 2011-06-04 06:39:12 --> Total execution time: 0.6237
DEBUG - 2011-06-04 06:39:14 --> Config Class Initialized
DEBUG - 2011-06-04 06:39:14 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:39:14 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:39:14 --> URI Class Initialized
DEBUG - 2011-06-04 06:39:14 --> Router Class Initialized
ERROR - 2011-06-04 06:39:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 06:52:02 --> Config Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:52:02 --> URI Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Router Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Output Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Input Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:52:02 --> Language Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Loader Class Initialized
DEBUG - 2011-06-04 06:52:02 --> Controller Class Initialized
ERROR - 2011-06-04 06:52:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 06:52:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 06:52:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:52:03 --> Model Class Initialized
DEBUG - 2011-06-04 06:52:03 --> Model Class Initialized
DEBUG - 2011-06-04 06:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:52:03 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:52:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:52:03 --> Helper loaded: url_helper
DEBUG - 2011-06-04 06:52:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 06:52:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 06:52:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 06:52:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 06:52:03 --> Final output sent to browser
DEBUG - 2011-06-04 06:52:03 --> Total execution time: 0.3643
DEBUG - 2011-06-04 06:52:04 --> Config Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:52:04 --> URI Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Router Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Output Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Input Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:52:04 --> Language Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Loader Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Controller Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Model Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Model Class Initialized
DEBUG - 2011-06-04 06:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:52:04 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:52:05 --> Final output sent to browser
DEBUG - 2011-06-04 06:52:05 --> Total execution time: 0.8716
DEBUG - 2011-06-04 06:52:06 --> Config Class Initialized
DEBUG - 2011-06-04 06:52:06 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:52:06 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:52:06 --> URI Class Initialized
DEBUG - 2011-06-04 06:52:06 --> Router Class Initialized
ERROR - 2011-06-04 06:52:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 06:53:01 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:01 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Router Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Output Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Input Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:53:01 --> Language Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Loader Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Controller Class Initialized
ERROR - 2011-06-04 06:53:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 06:53:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 06:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:53:01 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:53:01 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:53:01 --> Helper loaded: url_helper
DEBUG - 2011-06-04 06:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 06:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 06:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 06:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 06:53:01 --> Final output sent to browser
DEBUG - 2011-06-04 06:53:01 --> Total execution time: 0.0922
DEBUG - 2011-06-04 06:53:02 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:02 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Router Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Output Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Input Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:53:02 --> Language Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Loader Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Controller Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:53:02 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:02 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Router Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Output Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Input Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:53:02 --> Language Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Loader Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Controller Class Initialized
ERROR - 2011-06-04 06:53:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 06:53:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 06:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:53:02 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:53:02 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:53:02 --> Helper loaded: url_helper
DEBUG - 2011-06-04 06:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 06:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 06:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 06:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 06:53:02 --> Final output sent to browser
DEBUG - 2011-06-04 06:53:02 --> Total execution time: 0.0302
DEBUG - 2011-06-04 06:53:03 --> Final output sent to browser
DEBUG - 2011-06-04 06:53:03 --> Total execution time: 0.6753
DEBUG - 2011-06-04 06:53:04 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:04 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:04 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:04 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:04 --> Router Class Initialized
ERROR - 2011-06-04 06:53:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 06:53:30 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:30 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Router Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Output Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Input Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:53:30 --> Language Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Loader Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Controller Class Initialized
ERROR - 2011-06-04 06:53:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 06:53:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 06:53:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:53:30 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:53:30 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:53:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:53:30 --> Helper loaded: url_helper
DEBUG - 2011-06-04 06:53:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 06:53:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 06:53:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 06:53:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 06:53:30 --> Final output sent to browser
DEBUG - 2011-06-04 06:53:30 --> Total execution time: 0.0290
DEBUG - 2011-06-04 06:53:31 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:31 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Router Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Output Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Input Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:53:31 --> Language Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Loader Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Controller Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Model Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:53:31 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:53:31 --> Final output sent to browser
DEBUG - 2011-06-04 06:53:31 --> Total execution time: 0.6268
DEBUG - 2011-06-04 06:53:33 --> Config Class Initialized
DEBUG - 2011-06-04 06:53:33 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:53:33 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:53:33 --> URI Class Initialized
DEBUG - 2011-06-04 06:53:33 --> Router Class Initialized
ERROR - 2011-06-04 06:53:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 06:54:33 --> Config Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:54:33 --> URI Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Router Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Output Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Input Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:54:33 --> Language Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Loader Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Controller Class Initialized
ERROR - 2011-06-04 06:54:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 06:54:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 06:54:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:54:33 --> Model Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Model Class Initialized
DEBUG - 2011-06-04 06:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:54:33 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:54:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 06:54:33 --> Helper loaded: url_helper
DEBUG - 2011-06-04 06:54:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 06:54:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 06:54:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 06:54:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 06:54:33 --> Final output sent to browser
DEBUG - 2011-06-04 06:54:33 --> Total execution time: 0.0284
DEBUG - 2011-06-04 06:54:34 --> Config Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:54:34 --> URI Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Router Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Output Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Input Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 06:54:34 --> Language Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Loader Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Controller Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Model Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Model Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 06:54:34 --> Database Driver Class Initialized
DEBUG - 2011-06-04 06:54:34 --> Final output sent to browser
DEBUG - 2011-06-04 06:54:34 --> Total execution time: 0.5319
DEBUG - 2011-06-04 06:54:38 --> Config Class Initialized
DEBUG - 2011-06-04 06:54:38 --> Hooks Class Initialized
DEBUG - 2011-06-04 06:54:38 --> Utf8 Class Initialized
DEBUG - 2011-06-04 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 06:54:38 --> URI Class Initialized
DEBUG - 2011-06-04 06:54:38 --> Router Class Initialized
ERROR - 2011-06-04 06:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-04 12:00:36 --> Config Class Initialized
DEBUG - 2011-06-04 12:00:36 --> Hooks Class Initialized
DEBUG - 2011-06-04 12:00:36 --> Utf8 Class Initialized
DEBUG - 2011-06-04 12:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 12:00:36 --> URI Class Initialized
DEBUG - 2011-06-04 12:00:36 --> Router Class Initialized
ERROR - 2011-06-04 12:00:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 12:00:37 --> Config Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Hooks Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Utf8 Class Initialized
DEBUG - 2011-06-04 12:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 12:00:37 --> URI Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Router Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Output Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Input Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 12:00:37 --> Language Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Loader Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Controller Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Model Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Model Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Model Class Initialized
DEBUG - 2011-06-04 12:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 12:00:37 --> Database Driver Class Initialized
DEBUG - 2011-06-04 12:00:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-04 12:00:37 --> Helper loaded: url_helper
DEBUG - 2011-06-04 12:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 12:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 12:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 12:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 12:00:37 --> Final output sent to browser
DEBUG - 2011-06-04 12:00:37 --> Total execution time: 0.6031
DEBUG - 2011-06-04 12:01:08 --> Config Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Hooks Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Utf8 Class Initialized
DEBUG - 2011-06-04 12:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 12:01:08 --> URI Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Router Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Output Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Input Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 12:01:08 --> Language Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Loader Class Initialized
DEBUG - 2011-06-04 12:01:08 --> Controller Class Initialized
ERROR - 2011-06-04 12:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 12:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 12:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 12:01:09 --> Model Class Initialized
DEBUG - 2011-06-04 12:01:09 --> Model Class Initialized
DEBUG - 2011-06-04 12:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 12:01:09 --> Database Driver Class Initialized
DEBUG - 2011-06-04 12:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 12:01:09 --> Helper loaded: url_helper
DEBUG - 2011-06-04 12:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 12:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 12:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 12:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 12:01:09 --> Final output sent to browser
DEBUG - 2011-06-04 12:01:09 --> Total execution time: 0.6999
DEBUG - 2011-06-04 12:31:32 --> Config Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Hooks Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Utf8 Class Initialized
DEBUG - 2011-06-04 12:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 12:31:32 --> URI Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Router Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Output Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Input Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 12:31:32 --> Language Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Loader Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Controller Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Model Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Model Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Model Class Initialized
DEBUG - 2011-06-04 12:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 12:31:32 --> Database Driver Class Initialized
DEBUG - 2011-06-04 12:31:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-04 12:31:33 --> Helper loaded: url_helper
DEBUG - 2011-06-04 12:31:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 12:31:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 12:31:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 12:31:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 12:31:33 --> Final output sent to browser
DEBUG - 2011-06-04 12:31:33 --> Total execution time: 0.7797
DEBUG - 2011-06-04 13:38:57 --> Config Class Initialized
DEBUG - 2011-06-04 13:38:57 --> Hooks Class Initialized
DEBUG - 2011-06-04 13:38:57 --> Utf8 Class Initialized
DEBUG - 2011-06-04 13:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 13:38:57 --> URI Class Initialized
DEBUG - 2011-06-04 13:38:57 --> Router Class Initialized
ERROR - 2011-06-04 13:38:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 13:38:58 --> Config Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Hooks Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Utf8 Class Initialized
DEBUG - 2011-06-04 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 13:38:58 --> URI Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Router Class Initialized
DEBUG - 2011-06-04 13:38:58 --> No URI present. Default controller set.
DEBUG - 2011-06-04 13:38:58 --> Output Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Input Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 13:38:58 --> Language Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Loader Class Initialized
DEBUG - 2011-06-04 13:38:58 --> Controller Class Initialized
DEBUG - 2011-06-04 13:38:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-04 13:38:58 --> Helper loaded: url_helper
DEBUG - 2011-06-04 13:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 13:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 13:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 13:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 13:38:58 --> Final output sent to browser
DEBUG - 2011-06-04 13:38:58 --> Total execution time: 0.1923
DEBUG - 2011-06-04 13:55:22 --> Config Class Initialized
DEBUG - 2011-06-04 13:55:22 --> Hooks Class Initialized
DEBUG - 2011-06-04 13:55:22 --> Utf8 Class Initialized
DEBUG - 2011-06-04 13:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 13:55:23 --> URI Class Initialized
DEBUG - 2011-06-04 13:55:23 --> Router Class Initialized
DEBUG - 2011-06-04 13:55:24 --> No URI present. Default controller set.
DEBUG - 2011-06-04 13:55:24 --> Output Class Initialized
DEBUG - 2011-06-04 13:55:24 --> Input Class Initialized
DEBUG - 2011-06-04 13:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 13:55:24 --> Language Class Initialized
DEBUG - 2011-06-04 13:55:24 --> Loader Class Initialized
DEBUG - 2011-06-04 13:55:24 --> Controller Class Initialized
DEBUG - 2011-06-04 13:55:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-04 13:55:24 --> Helper loaded: url_helper
DEBUG - 2011-06-04 13:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 13:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 13:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 13:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 13:55:24 --> Final output sent to browser
DEBUG - 2011-06-04 13:55:24 --> Total execution time: 2.5322
DEBUG - 2011-06-04 15:58:09 --> Config Class Initialized
DEBUG - 2011-06-04 15:58:09 --> Hooks Class Initialized
DEBUG - 2011-06-04 15:58:09 --> Utf8 Class Initialized
DEBUG - 2011-06-04 15:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 15:58:09 --> URI Class Initialized
DEBUG - 2011-06-04 15:58:09 --> Router Class Initialized
ERROR - 2011-06-04 15:58:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 16:24:32 --> Config Class Initialized
DEBUG - 2011-06-04 16:24:32 --> Hooks Class Initialized
DEBUG - 2011-06-04 16:24:32 --> Utf8 Class Initialized
DEBUG - 2011-06-04 16:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 16:24:33 --> URI Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Router Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Output Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Input Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 16:24:33 --> Language Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Loader Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Controller Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Model Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Model Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Model Class Initialized
DEBUG - 2011-06-04 16:24:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 16:24:33 --> Database Driver Class Initialized
DEBUG - 2011-06-04 16:24:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-04 16:24:34 --> Helper loaded: url_helper
DEBUG - 2011-06-04 16:24:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 16:24:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 16:24:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 16:24:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 16:24:34 --> Final output sent to browser
DEBUG - 2011-06-04 16:24:34 --> Total execution time: 1.4753
DEBUG - 2011-06-04 17:00:57 --> Config Class Initialized
DEBUG - 2011-06-04 17:00:57 --> Hooks Class Initialized
DEBUG - 2011-06-04 17:00:57 --> Utf8 Class Initialized
DEBUG - 2011-06-04 17:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 17:00:57 --> URI Class Initialized
DEBUG - 2011-06-04 17:00:57 --> Router Class Initialized
ERROR - 2011-06-04 17:00:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 17:20:39 --> Config Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Hooks Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Utf8 Class Initialized
DEBUG - 2011-06-04 17:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 17:20:39 --> URI Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Router Class Initialized
DEBUG - 2011-06-04 17:20:39 --> No URI present. Default controller set.
DEBUG - 2011-06-04 17:20:39 --> Output Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Input Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 17:20:39 --> Language Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Loader Class Initialized
DEBUG - 2011-06-04 17:20:39 --> Controller Class Initialized
DEBUG - 2011-06-04 17:20:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-04 17:20:39 --> Helper loaded: url_helper
DEBUG - 2011-06-04 17:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 17:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 17:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 17:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 17:20:39 --> Final output sent to browser
DEBUG - 2011-06-04 17:20:39 --> Total execution time: 0.3242
DEBUG - 2011-06-04 19:20:04 --> Config Class Initialized
DEBUG - 2011-06-04 19:20:04 --> Hooks Class Initialized
DEBUG - 2011-06-04 19:20:04 --> Utf8 Class Initialized
DEBUG - 2011-06-04 19:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 19:20:04 --> URI Class Initialized
DEBUG - 2011-06-04 19:20:04 --> Router Class Initialized
ERROR - 2011-06-04 19:20:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-04 19:20:07 --> Config Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Hooks Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Utf8 Class Initialized
DEBUG - 2011-06-04 19:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-04 19:20:07 --> URI Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Router Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Output Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Input Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-04 19:20:07 --> Language Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Loader Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Controller Class Initialized
ERROR - 2011-06-04 19:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-04 19:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-04 19:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 19:20:07 --> Model Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Model Class Initialized
DEBUG - 2011-06-04 19:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-04 19:20:07 --> Database Driver Class Initialized
DEBUG - 2011-06-04 19:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-04 19:20:07 --> Helper loaded: url_helper
DEBUG - 2011-06-04 19:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-04 19:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-04 19:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-04 19:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-04 19:20:07 --> Final output sent to browser
DEBUG - 2011-06-04 19:20:07 --> Total execution time: 0.5892

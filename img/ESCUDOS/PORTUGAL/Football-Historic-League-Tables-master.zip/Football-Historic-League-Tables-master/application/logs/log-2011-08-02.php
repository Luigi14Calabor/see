<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-02 04:29:39 --> Config Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Hooks Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Utf8 Class Initialized
DEBUG - 2011-08-02 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 04:29:39 --> URI Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Router Class Initialized
DEBUG - 2011-08-02 04:29:39 --> No URI present. Default controller set.
DEBUG - 2011-08-02 04:29:39 --> Output Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Input Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 04:29:39 --> Language Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Loader Class Initialized
DEBUG - 2011-08-02 04:29:39 --> Controller Class Initialized
DEBUG - 2011-08-02 04:29:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-02 04:29:39 --> Helper loaded: url_helper
DEBUG - 2011-08-02 04:29:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 04:29:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 04:29:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 04:29:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 04:29:39 --> Final output sent to browser
DEBUG - 2011-08-02 04:29:39 --> Total execution time: 0.1716
DEBUG - 2011-08-02 05:56:54 --> Config Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Hooks Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Utf8 Class Initialized
DEBUG - 2011-08-02 05:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 05:56:54 --> URI Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Router Class Initialized
DEBUG - 2011-08-02 05:56:54 --> No URI present. Default controller set.
DEBUG - 2011-08-02 05:56:54 --> Output Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Input Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 05:56:54 --> Language Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Loader Class Initialized
DEBUG - 2011-08-02 05:56:54 --> Controller Class Initialized
DEBUG - 2011-08-02 05:56:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-02 05:56:54 --> Helper loaded: url_helper
DEBUG - 2011-08-02 05:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 05:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 05:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 05:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 05:56:54 --> Final output sent to browser
DEBUG - 2011-08-02 05:56:54 --> Total execution time: 0.1671
DEBUG - 2011-08-02 06:04:07 --> Config Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Hooks Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Utf8 Class Initialized
DEBUG - 2011-08-02 06:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 06:04:07 --> URI Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Router Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Output Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Input Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 06:04:07 --> Language Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Loader Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Controller Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Model Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Model Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Model Class Initialized
DEBUG - 2011-08-02 06:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 06:04:07 --> Database Driver Class Initialized
DEBUG - 2011-08-02 06:04:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 06:04:08 --> Helper loaded: url_helper
DEBUG - 2011-08-02 06:04:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 06:04:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 06:04:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 06:04:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 06:04:08 --> Final output sent to browser
DEBUG - 2011-08-02 06:04:08 --> Total execution time: 1.0464
DEBUG - 2011-08-02 07:09:55 --> Config Class Initialized
DEBUG - 2011-08-02 07:09:55 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:09:55 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:09:55 --> URI Class Initialized
DEBUG - 2011-08-02 07:09:55 --> Router Class Initialized
ERROR - 2011-08-02 07:09:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-02 07:10:16 --> Config Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:10:16 --> URI Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Router Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Output Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Input Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:10:16 --> Language Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Loader Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Controller Class Initialized
ERROR - 2011-08-02 07:10:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-02 07:10:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-02 07:10:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 07:10:16 --> Model Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Model Class Initialized
DEBUG - 2011-08-02 07:10:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:10:16 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:10:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 07:10:16 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:10:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:10:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:10:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:10:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:10:16 --> Final output sent to browser
DEBUG - 2011-08-02 07:10:16 --> Total execution time: 0.3313
DEBUG - 2011-08-02 07:20:27 --> Config Class Initialized
DEBUG - 2011-08-02 07:20:27 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:20:27 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:20:27 --> URI Class Initialized
DEBUG - 2011-08-02 07:20:27 --> Router Class Initialized
ERROR - 2011-08-02 07:20:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-02 07:20:28 --> Config Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:20:28 --> URI Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Router Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Output Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Input Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:20:28 --> Language Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Loader Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Controller Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Model Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Model Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Model Class Initialized
DEBUG - 2011-08-02 07:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:20:28 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:20:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:20:28 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:20:28 --> Final output sent to browser
DEBUG - 2011-08-02 07:20:28 --> Total execution time: 0.4208
DEBUG - 2011-08-02 07:33:40 --> Config Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:33:40 --> URI Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Router Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Output Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Input Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:33:40 --> Language Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Loader Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Controller Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Model Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Model Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Model Class Initialized
DEBUG - 2011-08-02 07:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:33:40 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:33:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:33:40 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:33:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:33:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:33:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:33:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:33:40 --> Final output sent to browser
DEBUG - 2011-08-02 07:33:40 --> Total execution time: 0.0651
DEBUG - 2011-08-02 07:33:45 --> Config Class Initialized
DEBUG - 2011-08-02 07:33:45 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:33:45 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:33:45 --> URI Class Initialized
DEBUG - 2011-08-02 07:33:45 --> Router Class Initialized
ERROR - 2011-08-02 07:33:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-02 07:33:45 --> Config Class Initialized
DEBUG - 2011-08-02 07:33:45 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:33:45 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:33:45 --> URI Class Initialized
DEBUG - 2011-08-02 07:33:45 --> Router Class Initialized
ERROR - 2011-08-02 07:33:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-02 07:34:02 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:02 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:02 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:02 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:03 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:03 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:03 --> Total execution time: 1.0453
DEBUG - 2011-08-02 07:34:14 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:14 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:14 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:14 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:14 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:14 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:14 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:14 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:14 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:14 --> Total execution time: 0.0585
DEBUG - 2011-08-02 07:34:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:15 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:15 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:15 --> Total execution time: 1.2570
DEBUG - 2011-08-02 07:34:17 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:17 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:17 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:17 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:17 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:17 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:17 --> Total execution time: 0.1092
DEBUG - 2011-08-02 07:34:24 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:24 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:24 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:24 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:25 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:25 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:25 --> Total execution time: 0.7968
DEBUG - 2011-08-02 07:34:27 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:27 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:27 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:27 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:27 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:27 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:27 --> Total execution time: 0.0684
DEBUG - 2011-08-02 07:34:33 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:33 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:33 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:33 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:33 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:33 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:33 --> Total execution time: 0.0810
DEBUG - 2011-08-02 07:34:45 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:45 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:45 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:45 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:46 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:46 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:46 --> Total execution time: 0.3448
DEBUG - 2011-08-02 07:34:47 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:47 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:47 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:47 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:47 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:47 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:47 --> Total execution time: 0.0754
DEBUG - 2011-08-02 07:34:56 --> Config Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:34:56 --> URI Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Router Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Output Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Input Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:34:56 --> Language Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Loader Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Controller Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Model Class Initialized
DEBUG - 2011-08-02 07:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:34:56 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:34:57 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:34:57 --> Final output sent to browser
DEBUG - 2011-08-02 07:34:57 --> Total execution time: 0.5898
DEBUG - 2011-08-02 07:35:00 --> Config Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Hooks Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Utf8 Class Initialized
DEBUG - 2011-08-02 07:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 07:35:00 --> URI Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Router Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Output Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Input Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 07:35:00 --> Language Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Loader Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Controller Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Model Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Model Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Model Class Initialized
DEBUG - 2011-08-02 07:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 07:35:00 --> Database Driver Class Initialized
DEBUG - 2011-08-02 07:35:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 07:35:00 --> Helper loaded: url_helper
DEBUG - 2011-08-02 07:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 07:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 07:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 07:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 07:35:00 --> Final output sent to browser
DEBUG - 2011-08-02 07:35:00 --> Total execution time: 0.0502
DEBUG - 2011-08-02 08:51:01 --> Config Class Initialized
DEBUG - 2011-08-02 08:51:01 --> Hooks Class Initialized
DEBUG - 2011-08-02 08:51:01 --> Utf8 Class Initialized
DEBUG - 2011-08-02 08:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 08:51:01 --> URI Class Initialized
DEBUG - 2011-08-02 08:51:01 --> Router Class Initialized
DEBUG - 2011-08-02 08:51:01 --> Output Class Initialized
DEBUG - 2011-08-02 08:51:01 --> Input Class Initialized
DEBUG - 2011-08-02 08:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 08:51:01 --> Language Class Initialized
DEBUG - 2011-08-02 08:51:02 --> Loader Class Initialized
DEBUG - 2011-08-02 08:51:02 --> Controller Class Initialized
DEBUG - 2011-08-02 08:51:02 --> Model Class Initialized
DEBUG - 2011-08-02 08:51:02 --> Model Class Initialized
DEBUG - 2011-08-02 08:51:02 --> Model Class Initialized
DEBUG - 2011-08-02 08:51:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 08:51:02 --> Database Driver Class Initialized
DEBUG - 2011-08-02 08:51:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 08:51:03 --> Helper loaded: url_helper
DEBUG - 2011-08-02 08:51:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 08:51:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 08:51:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 08:51:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 08:51:03 --> Final output sent to browser
DEBUG - 2011-08-02 08:51:03 --> Total execution time: 2.0673
DEBUG - 2011-08-02 10:19:18 --> Config Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Hooks Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Utf8 Class Initialized
DEBUG - 2011-08-02 10:19:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 10:19:18 --> URI Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Router Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Output Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Input Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 10:19:18 --> Language Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Loader Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Controller Class Initialized
ERROR - 2011-08-02 10:19:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-02 10:19:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-02 10:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 10:19:18 --> Model Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Model Class Initialized
DEBUG - 2011-08-02 10:19:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 10:19:18 --> Database Driver Class Initialized
DEBUG - 2011-08-02 10:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 10:19:18 --> Helper loaded: url_helper
DEBUG - 2011-08-02 10:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 10:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 10:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 10:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 10:19:18 --> Final output sent to browser
DEBUG - 2011-08-02 10:19:18 --> Total execution time: 0.3251
DEBUG - 2011-08-02 11:04:05 --> Config Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Hooks Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Utf8 Class Initialized
DEBUG - 2011-08-02 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 11:04:05 --> URI Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Router Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Output Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Input Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 11:04:05 --> Language Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Loader Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Controller Class Initialized
ERROR - 2011-08-02 11:04:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-02 11:04:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-02 11:04:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 11:04:05 --> Model Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Model Class Initialized
DEBUG - 2011-08-02 11:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 11:04:05 --> Database Driver Class Initialized
DEBUG - 2011-08-02 11:04:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 11:04:05 --> Helper loaded: url_helper
DEBUG - 2011-08-02 11:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 11:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 11:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 11:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 11:04:05 --> Final output sent to browser
DEBUG - 2011-08-02 11:04:05 --> Total execution time: 0.0595
DEBUG - 2011-08-02 11:38:49 --> Config Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Hooks Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Utf8 Class Initialized
DEBUG - 2011-08-02 11:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 11:38:49 --> URI Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Router Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Output Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Input Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 11:38:49 --> Language Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Loader Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Controller Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Model Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Model Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Model Class Initialized
DEBUG - 2011-08-02 11:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 11:38:49 --> Database Driver Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Config Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-02 11:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 11:38:50 --> URI Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Router Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Output Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Input Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 11:38:50 --> Language Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Loader Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Controller Class Initialized
ERROR - 2011-08-02 11:38:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-02 11:38:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 11:38:50 --> Model Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Model Class Initialized
DEBUG - 2011-08-02 11:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 11:38:50 --> Database Driver Class Initialized
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 11:38:50 --> Helper loaded: url_helper
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 11:38:50 --> Final output sent to browser
DEBUG - 2011-08-02 11:38:50 --> Total execution time: 0.0694
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 11:38:50 --> Helper loaded: url_helper
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 11:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 11:38:50 --> Final output sent to browser
DEBUG - 2011-08-02 11:38:50 --> Total execution time: 1.1621
DEBUG - 2011-08-02 11:49:43 --> Config Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Hooks Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Utf8 Class Initialized
DEBUG - 2011-08-02 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 11:49:43 --> URI Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Router Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Output Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Input Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 11:49:43 --> Language Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Loader Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Controller Class Initialized
ERROR - 2011-08-02 11:49:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-02 11:49:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-02 11:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 11:49:43 --> Model Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Model Class Initialized
DEBUG - 2011-08-02 11:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 11:49:43 --> Database Driver Class Initialized
DEBUG - 2011-08-02 11:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 11:49:43 --> Helper loaded: url_helper
DEBUG - 2011-08-02 11:49:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 11:49:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 11:49:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 11:49:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 11:49:44 --> Final output sent to browser
DEBUG - 2011-08-02 11:49:44 --> Total execution time: 0.1144
DEBUG - 2011-08-02 11:49:47 --> Config Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Hooks Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Utf8 Class Initialized
DEBUG - 2011-08-02 11:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 11:49:47 --> URI Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Router Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Output Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Input Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 11:49:47 --> Language Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Loader Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Controller Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Model Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Model Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 11:49:47 --> Database Driver Class Initialized
DEBUG - 2011-08-02 11:49:47 --> Final output sent to browser
DEBUG - 2011-08-02 11:49:47 --> Total execution time: 0.5761
DEBUG - 2011-08-02 11:49:51 --> Config Class Initialized
DEBUG - 2011-08-02 11:49:51 --> Hooks Class Initialized
DEBUG - 2011-08-02 11:49:51 --> Utf8 Class Initialized
DEBUG - 2011-08-02 11:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 11:49:51 --> URI Class Initialized
DEBUG - 2011-08-02 11:49:51 --> Router Class Initialized
ERROR - 2011-08-02 11:49:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-02 12:05:30 --> Config Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Hooks Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Utf8 Class Initialized
DEBUG - 2011-08-02 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 12:05:30 --> URI Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Router Class Initialized
DEBUG - 2011-08-02 12:05:30 --> No URI present. Default controller set.
DEBUG - 2011-08-02 12:05:30 --> Output Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Input Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 12:05:30 --> Language Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Loader Class Initialized
DEBUG - 2011-08-02 12:05:30 --> Controller Class Initialized
DEBUG - 2011-08-02 12:05:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-02 12:05:30 --> Helper loaded: url_helper
DEBUG - 2011-08-02 12:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 12:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 12:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 12:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 12:05:30 --> Final output sent to browser
DEBUG - 2011-08-02 12:05:30 --> Total execution time: 0.0918
DEBUG - 2011-08-02 12:06:47 --> Config Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-02 12:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 12:06:47 --> URI Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Router Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Output Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Input Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 12:06:47 --> Language Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Loader Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Controller Class Initialized
ERROR - 2011-08-02 12:06:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-02 12:06:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-02 12:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 12:06:47 --> Model Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Model Class Initialized
DEBUG - 2011-08-02 12:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 12:06:47 --> Database Driver Class Initialized
DEBUG - 2011-08-02 12:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-02 12:06:47 --> Helper loaded: url_helper
DEBUG - 2011-08-02 12:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 12:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 12:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 12:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 12:06:47 --> Final output sent to browser
DEBUG - 2011-08-02 12:06:47 --> Total execution time: 0.0614
DEBUG - 2011-08-02 12:31:15 --> Config Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Hooks Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Utf8 Class Initialized
DEBUG - 2011-08-02 12:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 12:31:15 --> URI Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Router Class Initialized
DEBUG - 2011-08-02 12:31:15 --> No URI present. Default controller set.
DEBUG - 2011-08-02 12:31:15 --> Output Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Input Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 12:31:15 --> Language Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Loader Class Initialized
DEBUG - 2011-08-02 12:31:15 --> Controller Class Initialized
DEBUG - 2011-08-02 12:31:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-02 12:31:15 --> Helper loaded: url_helper
DEBUG - 2011-08-02 12:31:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 12:31:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 12:31:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 12:31:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 12:31:15 --> Final output sent to browser
DEBUG - 2011-08-02 12:31:15 --> Total execution time: 0.0202
DEBUG - 2011-08-02 13:42:30 --> Config Class Initialized
DEBUG - 2011-08-02 13:42:30 --> Hooks Class Initialized
DEBUG - 2011-08-02 13:42:30 --> Utf8 Class Initialized
DEBUG - 2011-08-02 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 13:42:30 --> URI Class Initialized
DEBUG - 2011-08-02 13:42:30 --> Router Class Initialized
ERROR - 2011-08-02 13:42:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-02 13:43:52 --> Config Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Hooks Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Utf8 Class Initialized
DEBUG - 2011-08-02 13:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 13:43:52 --> URI Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Router Class Initialized
DEBUG - 2011-08-02 13:43:52 --> No URI present. Default controller set.
DEBUG - 2011-08-02 13:43:52 --> Output Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Input Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 13:43:52 --> Language Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Loader Class Initialized
DEBUG - 2011-08-02 13:43:52 --> Controller Class Initialized
DEBUG - 2011-08-02 13:43:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-02 13:43:52 --> Helper loaded: url_helper
DEBUG - 2011-08-02 13:43:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 13:43:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 13:43:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 13:43:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 13:43:52 --> Final output sent to browser
DEBUG - 2011-08-02 13:43:52 --> Total execution time: 0.0175
DEBUG - 2011-08-02 13:47:33 --> Config Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Hooks Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Utf8 Class Initialized
DEBUG - 2011-08-02 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 13:47:33 --> URI Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Router Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Output Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Input Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 13:47:33 --> Language Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Loader Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Controller Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Model Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Model Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Model Class Initialized
DEBUG - 2011-08-02 13:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 13:47:33 --> Database Driver Class Initialized
DEBUG - 2011-08-02 13:47:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 13:47:34 --> Helper loaded: url_helper
DEBUG - 2011-08-02 13:47:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 13:47:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 13:47:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 13:47:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 13:47:34 --> Final output sent to browser
DEBUG - 2011-08-02 13:47:34 --> Total execution time: 0.5317
DEBUG - 2011-08-02 14:45:34 --> Config Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Hooks Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Utf8 Class Initialized
DEBUG - 2011-08-02 14:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 14:45:34 --> URI Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Router Class Initialized
ERROR - 2011-08-02 14:45:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-02 14:45:34 --> Config Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Hooks Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Utf8 Class Initialized
DEBUG - 2011-08-02 14:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 14:45:34 --> URI Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Router Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Output Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Input Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 14:45:34 --> Language Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Loader Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Controller Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Model Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Model Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Model Class Initialized
DEBUG - 2011-08-02 14:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 14:45:34 --> Database Driver Class Initialized
DEBUG - 2011-08-02 14:45:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 14:45:35 --> Helper loaded: url_helper
DEBUG - 2011-08-02 14:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 14:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 14:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 14:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 14:45:35 --> Final output sent to browser
DEBUG - 2011-08-02 14:45:35 --> Total execution time: 0.9368
DEBUG - 2011-08-02 19:10:02 --> Config Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-02 19:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 19:10:02 --> URI Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Router Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Output Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Input Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 19:10:02 --> Language Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Loader Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Controller Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Model Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Model Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Model Class Initialized
DEBUG - 2011-08-02 19:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 19:10:03 --> Database Driver Class Initialized
DEBUG - 2011-08-02 19:10:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 19:10:03 --> Helper loaded: url_helper
DEBUG - 2011-08-02 19:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 19:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 19:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 19:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 19:10:03 --> Final output sent to browser
DEBUG - 2011-08-02 19:10:03 --> Total execution time: 1.2069
DEBUG - 2011-08-02 21:20:17 --> Config Class Initialized
DEBUG - 2011-08-02 21:20:17 --> Hooks Class Initialized
DEBUG - 2011-08-02 21:20:17 --> Utf8 Class Initialized
DEBUG - 2011-08-02 21:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 21:20:17 --> URI Class Initialized
DEBUG - 2011-08-02 21:20:17 --> Router Class Initialized
ERROR - 2011-08-02 21:20:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-02 21:20:58 --> Config Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Hooks Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Utf8 Class Initialized
DEBUG - 2011-08-02 21:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 21:20:58 --> URI Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Router Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Output Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Input Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 21:20:58 --> Language Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Loader Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Controller Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Model Class Initialized
DEBUG - 2011-08-02 21:20:58 --> Model Class Initialized
DEBUG - 2011-08-02 21:20:59 --> Model Class Initialized
DEBUG - 2011-08-02 21:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 21:21:00 --> Database Driver Class Initialized
DEBUG - 2011-08-02 21:21:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 21:21:00 --> Helper loaded: url_helper
DEBUG - 2011-08-02 21:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 21:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 21:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 21:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 21:21:00 --> Final output sent to browser
DEBUG - 2011-08-02 21:21:00 --> Total execution time: 2.2345
DEBUG - 2011-08-02 22:03:50 --> Config Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Hooks Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Utf8 Class Initialized
DEBUG - 2011-08-02 22:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 22:03:50 --> URI Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Router Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Output Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Input Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 22:03:50 --> Language Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Loader Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Controller Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Model Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Model Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Model Class Initialized
DEBUG - 2011-08-02 22:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 22:03:50 --> Database Driver Class Initialized
DEBUG - 2011-08-02 22:03:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 22:03:50 --> Helper loaded: url_helper
DEBUG - 2011-08-02 22:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 22:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 22:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 22:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 22:03:50 --> Final output sent to browser
DEBUG - 2011-08-02 22:03:50 --> Total execution time: 0.4709
DEBUG - 2011-08-02 22:03:53 --> Config Class Initialized
DEBUG - 2011-08-02 22:03:53 --> Hooks Class Initialized
DEBUG - 2011-08-02 22:03:53 --> Utf8 Class Initialized
DEBUG - 2011-08-02 22:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 22:03:53 --> URI Class Initialized
DEBUG - 2011-08-02 22:03:53 --> Router Class Initialized
ERROR - 2011-08-02 22:03:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-02 22:04:06 --> Config Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Hooks Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Utf8 Class Initialized
DEBUG - 2011-08-02 22:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 22:04:06 --> URI Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Router Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Output Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Input Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 22:04:06 --> Language Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Loader Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Controller Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Model Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Model Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Model Class Initialized
DEBUG - 2011-08-02 22:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 22:04:06 --> Database Driver Class Initialized
DEBUG - 2011-08-02 22:04:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 22:04:07 --> Helper loaded: url_helper
DEBUG - 2011-08-02 22:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 22:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 22:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 22:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 22:04:07 --> Final output sent to browser
DEBUG - 2011-08-02 22:04:07 --> Total execution time: 0.8239
DEBUG - 2011-08-02 22:04:08 --> Config Class Initialized
DEBUG - 2011-08-02 22:04:08 --> Hooks Class Initialized
DEBUG - 2011-08-02 22:04:08 --> Utf8 Class Initialized
DEBUG - 2011-08-02 22:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 22:04:08 --> URI Class Initialized
DEBUG - 2011-08-02 22:04:08 --> Router Class Initialized
ERROR - 2011-08-02 22:04:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-02 22:04:09 --> Config Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Hooks Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Utf8 Class Initialized
DEBUG - 2011-08-02 22:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 22:04:09 --> URI Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Router Class Initialized
ERROR - 2011-08-02 22:04:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-02 22:04:09 --> Config Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Hooks Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Utf8 Class Initialized
DEBUG - 2011-08-02 22:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 22:04:09 --> URI Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Router Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Output Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Input Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 22:04:09 --> Language Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Loader Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Controller Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Model Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Model Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Model Class Initialized
DEBUG - 2011-08-02 22:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-02 22:04:09 --> Database Driver Class Initialized
DEBUG - 2011-08-02 22:04:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-02 22:04:09 --> Helper loaded: url_helper
DEBUG - 2011-08-02 22:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 22:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 22:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 22:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 22:04:09 --> Final output sent to browser
DEBUG - 2011-08-02 22:04:09 --> Total execution time: 0.0476
DEBUG - 2011-08-02 23:25:46 --> Config Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Hooks Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Utf8 Class Initialized
DEBUG - 2011-08-02 23:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-02 23:25:46 --> URI Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Router Class Initialized
DEBUG - 2011-08-02 23:25:46 --> No URI present. Default controller set.
DEBUG - 2011-08-02 23:25:46 --> Output Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Input Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-02 23:25:46 --> Language Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Loader Class Initialized
DEBUG - 2011-08-02 23:25:46 --> Controller Class Initialized
DEBUG - 2011-08-02 23:25:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-02 23:25:46 --> Helper loaded: url_helper
DEBUG - 2011-08-02 23:25:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-02 23:25:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-02 23:25:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-02 23:25:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-02 23:25:46 --> Final output sent to browser
DEBUG - 2011-08-02 23:25:46 --> Total execution time: 0.1652

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-18 00:27:47 --> Config Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:27:47 --> URI Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Router Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Output Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Input Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:27:47 --> Language Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Loader Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Controller Class Initialized
ERROR - 2011-09-18 00:27:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 00:27:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 00:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:27:47 --> Model Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Model Class Initialized
DEBUG - 2011-09-18 00:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:27:47 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:27:47 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:27:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:27:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:27:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:27:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:27:47 --> Final output sent to browser
DEBUG - 2011-09-18 00:27:47 --> Total execution time: 0.0641
DEBUG - 2011-09-18 00:27:50 --> Config Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:27:50 --> URI Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Router Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Output Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Input Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:27:50 --> Language Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Loader Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Controller Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Model Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Model Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:27:50 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:27:50 --> Final output sent to browser
DEBUG - 2011-09-18 00:27:50 --> Total execution time: 0.6028
DEBUG - 2011-09-18 00:27:53 --> Config Class Initialized
DEBUG - 2011-09-18 00:27:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:27:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:27:53 --> URI Class Initialized
DEBUG - 2011-09-18 00:27:53 --> Router Class Initialized
ERROR - 2011-09-18 00:27:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 00:34:27 --> Config Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:34:27 --> URI Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Router Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Output Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Input Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:34:27 --> Language Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Loader Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Controller Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:34:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 00:34:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:34:27 --> Final output sent to browser
DEBUG - 2011-09-18 00:34:27 --> Total execution time: 0.3742
DEBUG - 2011-09-18 00:34:30 --> Config Class Initialized
DEBUG - 2011-09-18 00:34:30 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:34:30 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:34:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:34:30 --> URI Class Initialized
DEBUG - 2011-09-18 00:34:30 --> Router Class Initialized
ERROR - 2011-09-18 00:34:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 00:34:58 --> Config Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:34:58 --> URI Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Router Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Output Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Input Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:34:58 --> Language Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Loader Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Controller Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:34:58 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:34:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 00:34:58 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:34:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:34:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:34:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:34:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:34:58 --> Final output sent to browser
DEBUG - 2011-09-18 00:34:58 --> Total execution time: 0.3045
DEBUG - 2011-09-18 00:34:59 --> Config Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:34:59 --> URI Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Router Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Output Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Input Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:34:59 --> Language Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Loader Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Controller Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Model Class Initialized
DEBUG - 2011-09-18 00:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:34:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 00:34:59 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:34:59 --> Final output sent to browser
DEBUG - 2011-09-18 00:34:59 --> Total execution time: 0.0438
DEBUG - 2011-09-18 00:58:33 --> Config Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:58:33 --> URI Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Router Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Output Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Input Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:58:33 --> Language Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Loader Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Controller Class Initialized
ERROR - 2011-09-18 00:58:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 00:58:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 00:58:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:58:33 --> Model Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Model Class Initialized
DEBUG - 2011-09-18 00:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:58:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:58:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:58:33 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:58:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:58:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:58:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:58:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:58:33 --> Final output sent to browser
DEBUG - 2011-09-18 00:58:33 --> Total execution time: 0.0375
DEBUG - 2011-09-18 00:58:37 --> Config Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:58:37 --> URI Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Router Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Output Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Input Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:58:37 --> Language Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Loader Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Controller Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Model Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Model Class Initialized
DEBUG - 2011-09-18 00:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:58:37 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:58:38 --> Final output sent to browser
DEBUG - 2011-09-18 00:58:38 --> Total execution time: 0.8081
DEBUG - 2011-09-18 00:58:40 --> Config Class Initialized
DEBUG - 2011-09-18 00:58:40 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:58:40 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:58:40 --> URI Class Initialized
DEBUG - 2011-09-18 00:58:40 --> Router Class Initialized
ERROR - 2011-09-18 00:58:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 00:59:14 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:14 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Router Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Output Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Input Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:59:14 --> Language Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Loader Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Controller Class Initialized
ERROR - 2011-09-18 00:59:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 00:59:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 00:59:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:59:14 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:59:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:59:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:59:14 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:59:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:59:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:59:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:59:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:59:14 --> Final output sent to browser
DEBUG - 2011-09-18 00:59:14 --> Total execution time: 0.0294
DEBUG - 2011-09-18 00:59:14 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:14 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Router Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Output Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Input Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:59:14 --> Language Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Loader Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Controller Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:59:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:59:15 --> Final output sent to browser
DEBUG - 2011-09-18 00:59:15 --> Total execution time: 0.6014
DEBUG - 2011-09-18 00:59:17 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:17 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:17 --> Router Class Initialized
ERROR - 2011-09-18 00:59:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 00:59:35 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:35 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Router Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Output Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Input Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:59:35 --> Language Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Loader Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Controller Class Initialized
ERROR - 2011-09-18 00:59:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 00:59:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 00:59:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:59:35 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:59:35 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:59:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:59:35 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:59:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:59:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:59:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:59:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:59:35 --> Final output sent to browser
DEBUG - 2011-09-18 00:59:35 --> Total execution time: 0.0296
DEBUG - 2011-09-18 00:59:36 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:36 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Router Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Output Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Input Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:59:36 --> Language Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Loader Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Controller Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:59:36 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:59:36 --> Final output sent to browser
DEBUG - 2011-09-18 00:59:36 --> Total execution time: 0.5621
DEBUG - 2011-09-18 00:59:39 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:39 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:39 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:39 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:39 --> Router Class Initialized
ERROR - 2011-09-18 00:59:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 00:59:55 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:55 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Router Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Output Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Input Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:59:55 --> Language Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Loader Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Controller Class Initialized
ERROR - 2011-09-18 00:59:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 00:59:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 00:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:59:55 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:59:55 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 00:59:55 --> Helper loaded: url_helper
DEBUG - 2011-09-18 00:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 00:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 00:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 00:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 00:59:55 --> Final output sent to browser
DEBUG - 2011-09-18 00:59:55 --> Total execution time: 0.0287
DEBUG - 2011-09-18 00:59:56 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:56 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Router Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Output Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Input Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 00:59:56 --> Language Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Loader Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Controller Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Model Class Initialized
DEBUG - 2011-09-18 00:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 00:59:56 --> Database Driver Class Initialized
DEBUG - 2011-09-18 00:59:57 --> Final output sent to browser
DEBUG - 2011-09-18 00:59:57 --> Total execution time: 0.6147
DEBUG - 2011-09-18 00:59:59 --> Config Class Initialized
DEBUG - 2011-09-18 00:59:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 00:59:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 00:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 00:59:59 --> URI Class Initialized
DEBUG - 2011-09-18 00:59:59 --> Router Class Initialized
ERROR - 2011-09-18 00:59:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:00:09 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:09 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:09 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Controller Class Initialized
ERROR - 2011-09-18 01:00:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:00:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:09 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:09 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:09 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:00:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:00:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:00:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:00:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:00:09 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:09 --> Total execution time: 0.0516
DEBUG - 2011-09-18 01:00:10 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:10 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:10 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Controller Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:10 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:11 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:11 --> Total execution time: 0.9138
DEBUG - 2011-09-18 01:00:13 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:13 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:13 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:13 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:13 --> Router Class Initialized
ERROR - 2011-09-18 01:00:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:00:17 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:17 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:17 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Controller Class Initialized
ERROR - 2011-09-18 01:00:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:00:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:00:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:17 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:17 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:00:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:00:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:00:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:00:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:00:17 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:17 --> Total execution time: 0.0345
DEBUG - 2011-09-18 01:00:18 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:18 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:18 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Controller Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:18 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:19 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:19 --> Total execution time: 0.9088
DEBUG - 2011-09-18 01:00:21 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:21 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:21 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:21 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:21 --> Router Class Initialized
ERROR - 2011-09-18 01:00:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:00:32 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:32 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:32 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Controller Class Initialized
ERROR - 2011-09-18 01:00:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:00:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:32 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:32 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:32 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:00:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:00:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:00:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:00:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:00:32 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:32 --> Total execution time: 0.0267
DEBUG - 2011-09-18 01:00:33 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:33 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:33 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Controller Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:34 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:34 --> Total execution time: 0.7426
DEBUG - 2011-09-18 01:00:36 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:36 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:36 --> Router Class Initialized
ERROR - 2011-09-18 01:00:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:00:40 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:40 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:40 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Controller Class Initialized
ERROR - 2011-09-18 01:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:40 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:40 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:40 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:00:40 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:40 --> Total execution time: 0.0273
DEBUG - 2011-09-18 01:00:42 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:42 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:42 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Controller Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:43 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:43 --> Total execution time: 0.9171
DEBUG - 2011-09-18 01:00:45 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:45 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:45 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:45 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:45 --> Router Class Initialized
ERROR - 2011-09-18 01:00:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:00:49 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:49 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:49 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Controller Class Initialized
ERROR - 2011-09-18 01:00:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:49 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:49 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:49 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:00:49 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:49 --> Total execution time: 0.0316
DEBUG - 2011-09-18 01:00:50 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:50 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:50 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Controller Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:50 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:51 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:51 --> Total execution time: 0.8988
DEBUG - 2011-09-18 01:00:53 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:53 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:53 --> Router Class Initialized
ERROR - 2011-09-18 01:00:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:00:55 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:55 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:55 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Controller Class Initialized
ERROR - 2011-09-18 01:00:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:00:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:55 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:55 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:00:55 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:00:55 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:55 --> Total execution time: 0.0294
DEBUG - 2011-09-18 01:00:57 --> Config Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:00:57 --> URI Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Router Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Output Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Input Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:00:57 --> Language Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Loader Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Controller Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Model Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:00:57 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:00:57 --> Final output sent to browser
DEBUG - 2011-09-18 01:00:57 --> Total execution time: 0.5634
DEBUG - 2011-09-18 01:01:00 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:00 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:00 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:00 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:00 --> Router Class Initialized
ERROR - 2011-09-18 01:01:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:01:03 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:03 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Router Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Output Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Input Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:01:03 --> Language Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Loader Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Controller Class Initialized
ERROR - 2011-09-18 01:01:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:01:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:01:03 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:01:03 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:01:03 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:01:03 --> Final output sent to browser
DEBUG - 2011-09-18 01:01:03 --> Total execution time: 0.0309
DEBUG - 2011-09-18 01:01:03 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:03 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Router Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Output Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Input Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:01:03 --> Language Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Loader Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Controller Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:01:03 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:01:04 --> Final output sent to browser
DEBUG - 2011-09-18 01:01:04 --> Total execution time: 0.5906
DEBUG - 2011-09-18 01:01:07 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:07 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:07 --> Router Class Initialized
ERROR - 2011-09-18 01:01:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:01:12 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:12 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Router Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Output Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Input Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:01:12 --> Language Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Loader Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Controller Class Initialized
ERROR - 2011-09-18 01:01:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:01:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:01:12 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:01:12 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:01:12 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:01:12 --> Final output sent to browser
DEBUG - 2011-09-18 01:01:12 --> Total execution time: 0.0288
DEBUG - 2011-09-18 01:01:13 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:13 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Router Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Output Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Input Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:01:13 --> Language Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Loader Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Controller Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:01:13 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:01:13 --> Final output sent to browser
DEBUG - 2011-09-18 01:01:13 --> Total execution time: 0.5623
DEBUG - 2011-09-18 01:01:16 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:16 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:16 --> Router Class Initialized
ERROR - 2011-09-18 01:01:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:01:45 --> Config Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:01:45 --> URI Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Router Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Output Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Input Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:01:45 --> Language Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Loader Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Controller Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Model Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:01:45 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:01:45 --> Final output sent to browser
DEBUG - 2011-09-18 01:01:45 --> Total execution time: 0.5331
DEBUG - 2011-09-18 01:20:45 --> Config Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:20:45 --> URI Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Router Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Output Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Input Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:20:45 --> Language Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Loader Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Controller Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Model Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Model Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Model Class Initialized
DEBUG - 2011-09-18 01:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:20:45 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:20:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 01:20:45 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:20:45 --> Final output sent to browser
DEBUG - 2011-09-18 01:20:45 --> Total execution time: 0.7585
DEBUG - 2011-09-18 01:20:49 --> Config Class Initialized
DEBUG - 2011-09-18 01:20:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:20:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:20:49 --> URI Class Initialized
DEBUG - 2011-09-18 01:20:49 --> Router Class Initialized
ERROR - 2011-09-18 01:20:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:20:51 --> Config Class Initialized
DEBUG - 2011-09-18 01:20:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:20:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:20:51 --> URI Class Initialized
DEBUG - 2011-09-18 01:20:51 --> Router Class Initialized
ERROR - 2011-09-18 01:20:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:20:52 --> Config Class Initialized
DEBUG - 2011-09-18 01:20:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:20:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:20:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:20:52 --> URI Class Initialized
DEBUG - 2011-09-18 01:20:52 --> Router Class Initialized
ERROR - 2011-09-18 01:20:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:21:04 --> Config Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:21:04 --> URI Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Router Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Output Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Input Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:21:04 --> Language Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Loader Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Controller Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Model Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Model Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Model Class Initialized
DEBUG - 2011-09-18 01:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:21:04 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 01:21:05 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:21:05 --> Final output sent to browser
DEBUG - 2011-09-18 01:21:05 --> Total execution time: 0.4365
DEBUG - 2011-09-18 01:21:07 --> Config Class Initialized
DEBUG - 2011-09-18 01:21:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:21:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:21:07 --> URI Class Initialized
DEBUG - 2011-09-18 01:21:07 --> Router Class Initialized
ERROR - 2011-09-18 01:21:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 01:21:10 --> Config Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:21:10 --> URI Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Router Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Output Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Input Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:21:10 --> Language Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Loader Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Controller Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Model Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Model Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Model Class Initialized
DEBUG - 2011-09-18 01:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:21:10 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:21:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 01:21:10 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:21:10 --> Final output sent to browser
DEBUG - 2011-09-18 01:21:10 --> Total execution time: 0.0419
DEBUG - 2011-09-18 01:24:04 --> Config Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 01:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 01:24:04 --> URI Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Router Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Output Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Input Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 01:24:04 --> Language Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Loader Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Controller Class Initialized
ERROR - 2011-09-18 01:24:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 01:24:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 01:24:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:24:04 --> Model Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Model Class Initialized
DEBUG - 2011-09-18 01:24:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 01:24:04 --> Database Driver Class Initialized
DEBUG - 2011-09-18 01:24:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 01:24:04 --> Helper loaded: url_helper
DEBUG - 2011-09-18 01:24:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 01:24:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 01:24:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 01:24:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 01:24:04 --> Final output sent to browser
DEBUG - 2011-09-18 01:24:04 --> Total execution time: 0.0799
DEBUG - 2011-09-18 02:40:16 --> Config Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 02:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 02:40:16 --> URI Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Router Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Output Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Input Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 02:40:16 --> Language Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Loader Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Controller Class Initialized
ERROR - 2011-09-18 02:40:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 02:40:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 02:40:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 02:40:16 --> Model Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Model Class Initialized
DEBUG - 2011-09-18 02:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 02:40:16 --> Database Driver Class Initialized
DEBUG - 2011-09-18 02:40:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 02:40:18 --> Helper loaded: url_helper
DEBUG - 2011-09-18 02:40:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 02:40:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 02:40:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 02:40:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 02:40:18 --> Final output sent to browser
DEBUG - 2011-09-18 02:40:18 --> Total execution time: 2.2671
DEBUG - 2011-09-18 02:40:54 --> Config Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 02:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 02:40:54 --> URI Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Router Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Output Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Input Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 02:40:54 --> Language Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Loader Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Controller Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Model Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Model Class Initialized
DEBUG - 2011-09-18 02:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 02:40:55 --> Database Driver Class Initialized
DEBUG - 2011-09-18 02:40:56 --> Final output sent to browser
DEBUG - 2011-09-18 02:40:56 --> Total execution time: 1.9813
DEBUG - 2011-09-18 02:41:11 --> Config Class Initialized
DEBUG - 2011-09-18 02:41:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 02:41:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 02:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 02:41:11 --> URI Class Initialized
DEBUG - 2011-09-18 02:41:11 --> Router Class Initialized
ERROR - 2011-09-18 02:41:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:01:10 --> Config Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:01:10 --> URI Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Router Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Output Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Input Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:01:10 --> Language Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Loader Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Controller Class Initialized
ERROR - 2011-09-18 03:01:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 03:01:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 03:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:01:10 --> Model Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Model Class Initialized
DEBUG - 2011-09-18 03:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:01:10 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:01:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:01:11 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:01:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:01:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:01:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:01:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:01:11 --> Final output sent to browser
DEBUG - 2011-09-18 03:01:11 --> Total execution time: 1.3770
DEBUG - 2011-09-18 03:01:13 --> Config Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:01:13 --> URI Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Router Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Output Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Input Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:01:13 --> Language Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Loader Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Controller Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Model Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Model Class Initialized
DEBUG - 2011-09-18 03:01:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:01:13 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:01:15 --> Final output sent to browser
DEBUG - 2011-09-18 03:01:15 --> Total execution time: 2.1039
DEBUG - 2011-09-18 03:01:26 --> Config Class Initialized
DEBUG - 2011-09-18 03:01:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:01:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:01:26 --> URI Class Initialized
DEBUG - 2011-09-18 03:01:26 --> Router Class Initialized
ERROR - 2011-09-18 03:01:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:01:27 --> Config Class Initialized
DEBUG - 2011-09-18 03:01:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:01:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:01:27 --> URI Class Initialized
DEBUG - 2011-09-18 03:01:27 --> Router Class Initialized
ERROR - 2011-09-18 03:01:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:11:46 --> Config Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:11:46 --> URI Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Router Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Output Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Input Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:11:46 --> Language Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Loader Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Controller Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Model Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Model Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Model Class Initialized
DEBUG - 2011-09-18 03:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:11:46 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:11:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 03:11:50 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:11:50 --> Final output sent to browser
DEBUG - 2011-09-18 03:11:50 --> Total execution time: 4.0622
DEBUG - 2011-09-18 03:11:51 --> Config Class Initialized
DEBUG - 2011-09-18 03:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:11:51 --> URI Class Initialized
DEBUG - 2011-09-18 03:11:51 --> Router Class Initialized
ERROR - 2011-09-18 03:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:12:03 --> Config Class Initialized
DEBUG - 2011-09-18 03:12:03 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:12:03 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:12:03 --> URI Class Initialized
DEBUG - 2011-09-18 03:12:03 --> Router Class Initialized
DEBUG - 2011-09-18 03:12:03 --> Output Class Initialized
DEBUG - 2011-09-18 03:12:03 --> Input Class Initialized
DEBUG - 2011-09-18 03:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:12:04 --> Language Class Initialized
DEBUG - 2011-09-18 03:12:04 --> Loader Class Initialized
DEBUG - 2011-09-18 03:12:04 --> Controller Class Initialized
DEBUG - 2011-09-18 03:12:04 --> Model Class Initialized
DEBUG - 2011-09-18 03:12:04 --> Model Class Initialized
DEBUG - 2011-09-18 03:12:04 --> Model Class Initialized
DEBUG - 2011-09-18 03:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:12:04 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:12:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 03:12:04 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:12:04 --> Final output sent to browser
DEBUG - 2011-09-18 03:12:04 --> Total execution time: 0.0477
DEBUG - 2011-09-18 03:12:16 --> Config Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:12:16 --> URI Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Router Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Output Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Input Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:12:16 --> Language Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Loader Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Controller Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Model Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Model Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Model Class Initialized
DEBUG - 2011-09-18 03:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:12:16 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 03:12:16 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:12:16 --> Final output sent to browser
DEBUG - 2011-09-18 03:12:16 --> Total execution time: 0.1814
DEBUG - 2011-09-18 03:23:08 --> Config Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:23:08 --> URI Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Router Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Output Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Input Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:23:08 --> Language Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Loader Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Controller Class Initialized
ERROR - 2011-09-18 03:23:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 03:23:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 03:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:23:08 --> Model Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Model Class Initialized
DEBUG - 2011-09-18 03:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:23:08 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:23:08 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:23:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:23:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:23:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:23:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:23:08 --> Final output sent to browser
DEBUG - 2011-09-18 03:23:08 --> Total execution time: 0.0452
DEBUG - 2011-09-18 03:23:09 --> Config Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:23:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:23:09 --> URI Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Router Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Output Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Input Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:23:09 --> Language Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Loader Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Controller Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Model Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Model Class Initialized
DEBUG - 2011-09-18 03:23:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:23:09 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:23:10 --> Final output sent to browser
DEBUG - 2011-09-18 03:23:10 --> Total execution time: 0.5887
DEBUG - 2011-09-18 03:23:11 --> Config Class Initialized
DEBUG - 2011-09-18 03:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:23:11 --> URI Class Initialized
DEBUG - 2011-09-18 03:23:11 --> Router Class Initialized
ERROR - 2011-09-18 03:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:23:11 --> Config Class Initialized
DEBUG - 2011-09-18 03:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:23:11 --> URI Class Initialized
DEBUG - 2011-09-18 03:23:11 --> Router Class Initialized
ERROR - 2011-09-18 03:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:39:01 --> Config Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:39:01 --> URI Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Router Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Output Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Input Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:39:01 --> Language Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Loader Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Controller Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Model Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Model Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Model Class Initialized
DEBUG - 2011-09-18 03:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:39:01 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:39:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 03:39:03 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:39:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:39:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:39:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:39:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:39:03 --> Final output sent to browser
DEBUG - 2011-09-18 03:39:03 --> Total execution time: 1.8328
DEBUG - 2011-09-18 03:39:06 --> Config Class Initialized
DEBUG - 2011-09-18 03:39:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:39:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:39:06 --> URI Class Initialized
DEBUG - 2011-09-18 03:39:06 --> Router Class Initialized
ERROR - 2011-09-18 03:39:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:46:40 --> Config Class Initialized
DEBUG - 2011-09-18 03:46:40 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:46:40 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:46:40 --> URI Class Initialized
DEBUG - 2011-09-18 03:46:40 --> Router Class Initialized
DEBUG - 2011-09-18 03:46:40 --> Output Class Initialized
DEBUG - 2011-09-18 03:46:40 --> Input Class Initialized
DEBUG - 2011-09-18 03:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:46:41 --> Language Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Loader Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Controller Class Initialized
ERROR - 2011-09-18 03:46:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 03:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 03:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:46:41 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:46:41 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:46:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:46:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:46:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:46:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:46:41 --> Final output sent to browser
DEBUG - 2011-09-18 03:46:41 --> Total execution time: 0.2294
DEBUG - 2011-09-18 03:46:41 --> Config Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:46:41 --> URI Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Router Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Output Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Input Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:46:41 --> Language Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Loader Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Controller Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-18 03:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:46:41 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:46:43 --> Final output sent to browser
DEBUG - 2011-09-18 03:46:43 --> Total execution time: 1.8603
DEBUG - 2011-09-18 03:46:44 --> Config Class Initialized
DEBUG - 2011-09-18 03:46:44 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:46:44 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:46:44 --> URI Class Initialized
DEBUG - 2011-09-18 03:46:44 --> Router Class Initialized
ERROR - 2011-09-18 03:46:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:46:59 --> Config Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:46:59 --> URI Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Router Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Output Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Input Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:46:59 --> Language Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Loader Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Controller Class Initialized
ERROR - 2011-09-18 03:46:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 03:46:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 03:46:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:46:59 --> Model Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Model Class Initialized
DEBUG - 2011-09-18 03:46:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:46:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:46:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 03:46:59 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:46:59 --> Final output sent to browser
DEBUG - 2011-09-18 03:46:59 --> Total execution time: 0.0357
DEBUG - 2011-09-18 03:47:00 --> Config Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:47:00 --> URI Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Router Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Output Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Input Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:47:00 --> Language Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Loader Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Controller Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Model Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Model Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 03:47:00 --> Database Driver Class Initialized
DEBUG - 2011-09-18 03:47:00 --> Final output sent to browser
DEBUG - 2011-09-18 03:47:00 --> Total execution time: 0.7355
DEBUG - 2011-09-18 03:47:01 --> Config Class Initialized
DEBUG - 2011-09-18 03:47:01 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:47:01 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:47:01 --> URI Class Initialized
DEBUG - 2011-09-18 03:47:01 --> Router Class Initialized
ERROR - 2011-09-18 03:47:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 03:58:28 --> Config Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Hooks Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Utf8 Class Initialized
DEBUG - 2011-09-18 03:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 03:58:28 --> URI Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Router Class Initialized
DEBUG - 2011-09-18 03:58:28 --> No URI present. Default controller set.
DEBUG - 2011-09-18 03:58:28 --> Output Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Input Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 03:58:28 --> Language Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Loader Class Initialized
DEBUG - 2011-09-18 03:58:28 --> Controller Class Initialized
DEBUG - 2011-09-18 03:58:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 03:58:28 --> Helper loaded: url_helper
DEBUG - 2011-09-18 03:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 03:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 03:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 03:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 03:58:28 --> Final output sent to browser
DEBUG - 2011-09-18 03:58:28 --> Total execution time: 0.0634
DEBUG - 2011-09-18 04:33:18 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:18 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Router Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Output Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Input Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:33:18 --> Language Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Loader Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Controller Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:33:18 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:33:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:33:20 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:33:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:33:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:33:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:33:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:33:20 --> Final output sent to browser
DEBUG - 2011-09-18 04:33:20 --> Total execution time: 1.9078
DEBUG - 2011-09-18 04:33:21 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:21 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:21 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:21 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:21 --> Router Class Initialized
ERROR - 2011-09-18 04:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:33:33 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:33 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Router Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Output Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Input Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:33:33 --> Language Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Loader Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Controller Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:33:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:33:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:33:36 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:33:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:33:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:33:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:33:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:33:36 --> Final output sent to browser
DEBUG - 2011-09-18 04:33:36 --> Total execution time: 2.1826
DEBUG - 2011-09-18 04:33:37 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:37 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:37 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:37 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:37 --> Router Class Initialized
ERROR - 2011-09-18 04:33:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:33:43 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:43 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Router Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Output Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Input Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:33:43 --> Language Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Loader Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Controller Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:33:43 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:33:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:33:44 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:33:44 --> Final output sent to browser
DEBUG - 2011-09-18 04:33:44 --> Total execution time: 1.2573
DEBUG - 2011-09-18 04:33:45 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:45 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:45 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:45 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:45 --> Router Class Initialized
ERROR - 2011-09-18 04:33:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:33:51 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:51 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Router Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Output Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Input Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:33:51 --> Language Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Loader Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Controller Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:33:51 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:33:53 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:33:53 --> Final output sent to browser
DEBUG - 2011-09-18 04:33:53 --> Total execution time: 1.4051
DEBUG - 2011-09-18 04:33:54 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:54 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:54 --> Router Class Initialized
ERROR - 2011-09-18 04:33:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:33:58 --> Config Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:33:58 --> URI Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Router Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Output Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Input Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:33:58 --> Language Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Loader Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Controller Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Model Class Initialized
DEBUG - 2011-09-18 04:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:33:58 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:33:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:33:59 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:33:59 --> Final output sent to browser
DEBUG - 2011-09-18 04:33:59 --> Total execution time: 0.6773
DEBUG - 2011-09-18 04:34:00 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:00 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:00 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:00 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:00 --> Router Class Initialized
ERROR - 2011-09-18 04:34:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:34:02 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:02 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:02 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:02 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:02 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:02 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:02 --> Total execution time: 0.0566
DEBUG - 2011-09-18 04:34:07 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:07 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:07 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:07 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:07 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:07 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:07 --> Total execution time: 0.0777
DEBUG - 2011-09-18 04:34:12 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:12 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:12 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:12 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:12 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:12 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:12 --> Total execution time: 0.6337
DEBUG - 2011-09-18 04:34:12 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:12 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:12 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:12 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:12 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:12 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:12 --> Total execution time: 0.0443
DEBUG - 2011-09-18 04:34:13 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:13 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:13 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:13 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:13 --> Router Class Initialized
ERROR - 2011-09-18 04:34:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:34:22 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:22 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:22 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:22 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:22 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:22 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:22 --> Total execution time: 0.1480
DEBUG - 2011-09-18 04:34:25 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:25 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:25 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:25 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:25 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:25 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:25 --> Total execution time: 0.8244
DEBUG - 2011-09-18 04:34:26 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:26 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:26 --> Router Class Initialized
ERROR - 2011-09-18 04:34:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:34:27 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:27 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:27 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:27 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:27 --> Total execution time: 0.0502
DEBUG - 2011-09-18 04:34:37 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:37 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:37 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:37 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:38 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:38 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:38 --> Total execution time: 0.9555
DEBUG - 2011-09-18 04:34:39 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:39 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Router Class Initialized
ERROR - 2011-09-18 04:34:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:34:39 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:39 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:39 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:39 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:39 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:39 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:39 --> Total execution time: 0.0477
DEBUG - 2011-09-18 04:34:46 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:46 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:46 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:46 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:47 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:47 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:47 --> Total execution time: 1.0048
DEBUG - 2011-09-18 04:34:50 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:50 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:50 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:50 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:50 --> Router Class Initialized
ERROR - 2011-09-18 04:34:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:34:52 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:52 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:52 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:52 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:52 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:52 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:52 --> Total execution time: 0.0542
DEBUG - 2011-09-18 04:34:57 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:57 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:57 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:57 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:57 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:57 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:57 --> Total execution time: 0.5974
DEBUG - 2011-09-18 04:34:58 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:58 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:58 --> Router Class Initialized
ERROR - 2011-09-18 04:34:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:34:59 --> Config Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:34:59 --> URI Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Router Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Output Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Input Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:34:59 --> Language Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Loader Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Controller Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Model Class Initialized
DEBUG - 2011-09-18 04:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:34:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:34:59 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:34:59 --> Final output sent to browser
DEBUG - 2011-09-18 04:34:59 --> Total execution time: 0.0445
DEBUG - 2011-09-18 04:35:02 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:02 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:02 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:02 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:03 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:03 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:03 --> Total execution time: 1.2931
DEBUG - 2011-09-18 04:35:04 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:04 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Router Class Initialized
ERROR - 2011-09-18 04:35:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:04 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:04 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:04 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:04 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:04 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:04 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:04 --> Total execution time: 0.0533
DEBUG - 2011-09-18 04:35:09 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:09 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:09 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:10 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:10 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:10 --> Total execution time: 0.8786
DEBUG - 2011-09-18 04:35:11 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:11 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:11 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:11 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:11 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:11 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:11 --> Total execution time: 0.0450
DEBUG - 2011-09-18 04:35:16 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:16 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:16 --> Router Class Initialized
ERROR - 2011-09-18 04:35:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:19 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:19 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:19 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:19 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:19 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:19 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:19 --> Total execution time: 0.3042
DEBUG - 2011-09-18 04:35:20 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:20 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:20 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:20 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:20 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:20 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:20 --> Total execution time: 0.0490
DEBUG - 2011-09-18 04:35:21 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:21 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:21 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:21 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:21 --> Router Class Initialized
ERROR - 2011-09-18 04:35:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:26 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:26 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:26 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:26 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:30 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:30 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:30 --> Total execution time: 3.8896
DEBUG - 2011-09-18 04:35:32 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:32 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:32 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:32 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:32 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:32 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:32 --> Total execution time: 0.1266
DEBUG - 2011-09-18 04:35:32 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:32 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Router Class Initialized
ERROR - 2011-09-18 04:35:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:32 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:32 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:32 --> Router Class Initialized
ERROR - 2011-09-18 04:35:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:40 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:40 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:40 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:40 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:41 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:41 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:41 --> Total execution time: 0.6745
DEBUG - 2011-09-18 04:35:42 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:42 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:42 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:42 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:42 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:42 --> Total execution time: 0.0469
DEBUG - 2011-09-18 04:35:42 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:42 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:42 --> Router Class Initialized
ERROR - 2011-09-18 04:35:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:46 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:46 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:46 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:46 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:46 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:46 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:46 --> Total execution time: 0.2661
DEBUG - 2011-09-18 04:35:47 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:47 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:47 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:47 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:47 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:47 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:47 --> Total execution time: 0.0508
DEBUG - 2011-09-18 04:35:47 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:47 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:47 --> Router Class Initialized
ERROR - 2011-09-18 04:35:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:35:56 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:56 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Router Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Output Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Input Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:35:56 --> Language Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Loader Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Controller Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Model Class Initialized
DEBUG - 2011-09-18 04:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:35:56 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:35:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:35:57 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:35:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:35:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:35:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:35:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:35:57 --> Final output sent to browser
DEBUG - 2011-09-18 04:35:57 --> Total execution time: 0.2760
DEBUG - 2011-09-18 04:35:57 --> Config Class Initialized
DEBUG - 2011-09-18 04:35:57 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:35:57 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:35:57 --> URI Class Initialized
DEBUG - 2011-09-18 04:35:57 --> Router Class Initialized
ERROR - 2011-09-18 04:35:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:05 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:05 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:05 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:05 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:05 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:05 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:05 --> Total execution time: 0.0820
DEBUG - 2011-09-18 04:36:06 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:06 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:06 --> Router Class Initialized
ERROR - 2011-09-18 04:36:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:11 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:11 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:11 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:11 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:11 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:11 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:11 --> Total execution time: 0.0575
DEBUG - 2011-09-18 04:36:11 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:11 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:11 --> Router Class Initialized
ERROR - 2011-09-18 04:36:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:14 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:14 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:14 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:14 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:14 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:14 --> Total execution time: 0.0438
DEBUG - 2011-09-18 04:36:15 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:15 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:15 --> Router Class Initialized
ERROR - 2011-09-18 04:36:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:17 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:17 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:17 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:17 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:17 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:17 --> Total execution time: 0.0421
DEBUG - 2011-09-18 04:36:18 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:18 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:18 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:18 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:18 --> Router Class Initialized
ERROR - 2011-09-18 04:36:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:20 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:20 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:20 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:20 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:21 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:21 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:21 --> Total execution time: 0.9540
DEBUG - 2011-09-18 04:36:22 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:22 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:22 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:22 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:22 --> Router Class Initialized
ERROR - 2011-09-18 04:36:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:23 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:23 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:23 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:23 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:23 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:23 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:23 --> Total execution time: 0.0520
DEBUG - 2011-09-18 04:36:24 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:24 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:24 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:24 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:24 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:24 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:24 --> Total execution time: 0.5264
DEBUG - 2011-09-18 04:36:25 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:25 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:25 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:25 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:25 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:25 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:25 --> Total execution time: 0.0510
DEBUG - 2011-09-18 04:36:25 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:25 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:25 --> Router Class Initialized
ERROR - 2011-09-18 04:36:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:27 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:27 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:27 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:27 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:27 --> Total execution time: 0.3216
DEBUG - 2011-09-18 04:36:28 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:28 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:28 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:28 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:28 --> Router Class Initialized
ERROR - 2011-09-18 04:36:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:30 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:30 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:30 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:30 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:30 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:30 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:30 --> Total execution time: 0.0878
DEBUG - 2011-09-18 04:36:33 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:33 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:33 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:33 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:33 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:33 --> Total execution time: 0.0483
DEBUG - 2011-09-18 04:36:34 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:34 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:34 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:34 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:34 --> Router Class Initialized
ERROR - 2011-09-18 04:36:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:36:36 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:36 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:36 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:36 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:36 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:36 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:36 --> Total execution time: 0.0463
DEBUG - 2011-09-18 04:36:40 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:40 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Router Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Output Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Input Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:36:40 --> Language Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Loader Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Controller Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Model Class Initialized
DEBUG - 2011-09-18 04:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:36:40 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:36:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:36:40 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:36:40 --> Final output sent to browser
DEBUG - 2011-09-18 04:36:40 --> Total execution time: 0.1162
DEBUG - 2011-09-18 04:36:41 --> Config Class Initialized
DEBUG - 2011-09-18 04:36:41 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:36:41 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:36:41 --> URI Class Initialized
DEBUG - 2011-09-18 04:36:41 --> Router Class Initialized
ERROR - 2011-09-18 04:36:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:37:17 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:17 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Router Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Output Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Input Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:37:17 --> Language Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Loader Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Controller Class Initialized
ERROR - 2011-09-18 04:37:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 04:37:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 04:37:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:37:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:37:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:37:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:37:17 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:37:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:37:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:37:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:37:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:37:17 --> Final output sent to browser
DEBUG - 2011-09-18 04:37:17 --> Total execution time: 0.1081
DEBUG - 2011-09-18 04:37:17 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:17 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Router Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Output Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Input Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:37:17 --> Language Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Loader Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Controller Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:37:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:37:18 --> Final output sent to browser
DEBUG - 2011-09-18 04:37:18 --> Total execution time: 0.6420
DEBUG - 2011-09-18 04:37:19 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:19 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:19 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:19 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:19 --> Router Class Initialized
ERROR - 2011-09-18 04:37:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:37:27 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:27 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Router Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Output Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Input Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:37:27 --> Language Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Loader Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Controller Class Initialized
ERROR - 2011-09-18 04:37:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 04:37:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 04:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:37:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:37:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:37:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:37:27 --> Final output sent to browser
DEBUG - 2011-09-18 04:37:27 --> Total execution time: 0.0271
DEBUG - 2011-09-18 04:37:28 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:28 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Router Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Output Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Input Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:37:28 --> Language Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Loader Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Controller Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:37:28 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:37:28 --> Final output sent to browser
DEBUG - 2011-09-18 04:37:28 --> Total execution time: 0.5666
DEBUG - 2011-09-18 04:37:29 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:29 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:29 --> Router Class Initialized
ERROR - 2011-09-18 04:37:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:37:33 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:33 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Router Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Output Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Input Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:37:33 --> Language Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Loader Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Controller Class Initialized
ERROR - 2011-09-18 04:37:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 04:37:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 04:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:37:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:37:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:37:33 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:37:33 --> Final output sent to browser
DEBUG - 2011-09-18 04:37:33 --> Total execution time: 0.0284
DEBUG - 2011-09-18 04:37:34 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:34 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Router Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Output Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Input Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:37:34 --> Language Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Loader Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Controller Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Model Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:37:34 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:37:34 --> Final output sent to browser
DEBUG - 2011-09-18 04:37:34 --> Total execution time: 0.5509
DEBUG - 2011-09-18 04:37:35 --> Config Class Initialized
DEBUG - 2011-09-18 04:37:35 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:37:35 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:37:35 --> URI Class Initialized
DEBUG - 2011-09-18 04:37:35 --> Router Class Initialized
ERROR - 2011-09-18 04:37:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:39:35 --> Config Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:39:35 --> URI Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Router Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Output Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Input Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:39:35 --> Language Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Loader Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Controller Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Model Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Model Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Model Class Initialized
DEBUG - 2011-09-18 04:39:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:39:35 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:39:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:39:35 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:39:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:39:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:39:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:39:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:39:35 --> Final output sent to browser
DEBUG - 2011-09-18 04:39:35 --> Total execution time: 0.0423
DEBUG - 2011-09-18 04:47:45 --> Config Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:47:45 --> URI Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Router Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Output Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Input Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:47:45 --> Language Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Loader Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Controller Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:47:45 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:47:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:47:45 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:47:45 --> Final output sent to browser
DEBUG - 2011-09-18 04:47:45 --> Total execution time: 0.0828
DEBUG - 2011-09-18 04:47:47 --> Config Class Initialized
DEBUG - 2011-09-18 04:47:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:47:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:47:47 --> URI Class Initialized
DEBUG - 2011-09-18 04:47:47 --> Router Class Initialized
ERROR - 2011-09-18 04:47:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:47:58 --> Config Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:47:58 --> URI Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Router Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Output Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Input Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:47:58 --> Language Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Loader Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Controller Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:47:58 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:47:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:47:58 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:47:58 --> Final output sent to browser
DEBUG - 2011-09-18 04:47:58 --> Total execution time: 0.3299
DEBUG - 2011-09-18 04:47:59 --> Config Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:47:59 --> URI Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Router Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Output Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Input Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:47:59 --> Language Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Loader Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Controller Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Model Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:47:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:47:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:47:59 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:47:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:47:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:47:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:47:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:47:59 --> Final output sent to browser
DEBUG - 2011-09-18 04:47:59 --> Total execution time: 0.0394
DEBUG - 2011-09-18 04:47:59 --> Config Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:47:59 --> URI Class Initialized
DEBUG - 2011-09-18 04:47:59 --> Router Class Initialized
ERROR - 2011-09-18 04:47:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:48:13 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:13 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Router Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Output Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Input Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:48:13 --> Language Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Loader Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Controller Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:48:13 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:48:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:48:13 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:48:13 --> Final output sent to browser
DEBUG - 2011-09-18 04:48:13 --> Total execution time: 0.0555
DEBUG - 2011-09-18 04:48:14 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:14 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:14 --> Router Class Initialized
ERROR - 2011-09-18 04:48:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:48:22 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:22 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Router Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Output Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Input Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:48:22 --> Language Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Loader Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Controller Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:48:22 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:48:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:48:22 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:48:22 --> Final output sent to browser
DEBUG - 2011-09-18 04:48:22 --> Total execution time: 0.2428
DEBUG - 2011-09-18 04:48:24 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:24 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Router Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Output Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Input Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:48:24 --> Language Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Loader Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Controller Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:48:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:48:24 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:48:24 --> Final output sent to browser
DEBUG - 2011-09-18 04:48:24 --> Total execution time: 0.1970
DEBUG - 2011-09-18 04:48:24 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:24 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:24 --> Router Class Initialized
ERROR - 2011-09-18 04:48:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:48:31 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:31 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Router Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Output Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Input Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:48:31 --> Language Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Loader Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Controller Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Model Class Initialized
DEBUG - 2011-09-18 04:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:48:31 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:48:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 04:48:31 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:48:31 --> Final output sent to browser
DEBUG - 2011-09-18 04:48:31 --> Total execution time: 0.0517
DEBUG - 2011-09-18 04:48:32 --> Config Class Initialized
DEBUG - 2011-09-18 04:48:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:48:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:48:32 --> URI Class Initialized
DEBUG - 2011-09-18 04:48:32 --> Router Class Initialized
ERROR - 2011-09-18 04:48:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:53:31 --> Config Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:53:31 --> URI Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Router Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Output Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Input Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:53:31 --> Language Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Loader Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Controller Class Initialized
ERROR - 2011-09-18 04:53:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 04:53:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 04:53:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:53:31 --> Model Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Model Class Initialized
DEBUG - 2011-09-18 04:53:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:53:31 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:53:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 04:53:31 --> Helper loaded: url_helper
DEBUG - 2011-09-18 04:53:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 04:53:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 04:53:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 04:53:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 04:53:31 --> Final output sent to browser
DEBUG - 2011-09-18 04:53:31 --> Total execution time: 0.0420
DEBUG - 2011-09-18 04:53:32 --> Config Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:53:32 --> URI Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Router Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Output Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Input Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 04:53:32 --> Language Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Loader Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Controller Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Model Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Model Class Initialized
DEBUG - 2011-09-18 04:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 04:53:32 --> Database Driver Class Initialized
DEBUG - 2011-09-18 04:53:33 --> Final output sent to browser
DEBUG - 2011-09-18 04:53:33 --> Total execution time: 0.5041
DEBUG - 2011-09-18 04:53:36 --> Config Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:53:36 --> URI Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Router Class Initialized
ERROR - 2011-09-18 04:53:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:53:36 --> Config Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:53:36 --> URI Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Router Class Initialized
ERROR - 2011-09-18 04:53:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 04:53:36 --> Config Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 04:53:36 --> URI Class Initialized
DEBUG - 2011-09-18 04:53:36 --> Router Class Initialized
ERROR - 2011-09-18 04:53:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 05:09:32 --> Config Class Initialized
DEBUG - 2011-09-18 05:09:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 05:09:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 05:09:32 --> URI Class Initialized
DEBUG - 2011-09-18 05:09:32 --> Router Class Initialized
DEBUG - 2011-09-18 05:09:32 --> Output Class Initialized
DEBUG - 2011-09-18 05:09:32 --> Input Class Initialized
DEBUG - 2011-09-18 05:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 05:09:32 --> Language Class Initialized
DEBUG - 2011-09-18 05:09:33 --> Loader Class Initialized
DEBUG - 2011-09-18 05:09:33 --> Controller Class Initialized
ERROR - 2011-09-18 05:09:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 05:09:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 05:09:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 05:09:33 --> Model Class Initialized
DEBUG - 2011-09-18 05:09:33 --> Model Class Initialized
DEBUG - 2011-09-18 05:09:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 05:09:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 05:09:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 05:09:33 --> Helper loaded: url_helper
DEBUG - 2011-09-18 05:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 05:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 05:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 05:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 05:09:33 --> Final output sent to browser
DEBUG - 2011-09-18 05:09:33 --> Total execution time: 0.1951
DEBUG - 2011-09-18 05:09:35 --> Config Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Hooks Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Utf8 Class Initialized
DEBUG - 2011-09-18 05:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 05:09:35 --> URI Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Router Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Output Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Input Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 05:09:35 --> Language Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Loader Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Controller Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Model Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Model Class Initialized
DEBUG - 2011-09-18 05:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 05:09:35 --> Database Driver Class Initialized
DEBUG - 2011-09-18 05:09:36 --> Final output sent to browser
DEBUG - 2011-09-18 05:09:36 --> Total execution time: 0.8945
DEBUG - 2011-09-18 05:09:39 --> Config Class Initialized
DEBUG - 2011-09-18 05:09:39 --> Hooks Class Initialized
DEBUG - 2011-09-18 05:09:39 --> Utf8 Class Initialized
DEBUG - 2011-09-18 05:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 05:09:39 --> URI Class Initialized
DEBUG - 2011-09-18 05:09:39 --> Router Class Initialized
ERROR - 2011-09-18 05:09:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 05:09:46 --> Config Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Hooks Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Utf8 Class Initialized
DEBUG - 2011-09-18 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 05:09:46 --> URI Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Router Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Output Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Input Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 05:09:46 --> Language Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Loader Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Controller Class Initialized
ERROR - 2011-09-18 05:09:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 05:09:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 05:09:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 05:09:46 --> Model Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Model Class Initialized
DEBUG - 2011-09-18 05:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 05:09:46 --> Database Driver Class Initialized
DEBUG - 2011-09-18 05:09:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 05:09:46 --> Helper loaded: url_helper
DEBUG - 2011-09-18 05:09:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 05:09:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 05:09:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 05:09:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 05:09:46 --> Final output sent to browser
DEBUG - 2011-09-18 05:09:46 --> Total execution time: 0.0282
DEBUG - 2011-09-18 05:09:47 --> Config Class Initialized
DEBUG - 2011-09-18 05:09:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 05:09:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 05:09:47 --> URI Class Initialized
DEBUG - 2011-09-18 05:09:47 --> Router Class Initialized
ERROR - 2011-09-18 05:09:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 06:54:08 --> Config Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:54:08 --> URI Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Router Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Output Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Input Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:54:08 --> Language Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Loader Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Controller Class Initialized
ERROR - 2011-09-18 06:54:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 06:54:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 06:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:54:08 --> Model Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Model Class Initialized
DEBUG - 2011-09-18 06:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:54:08 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:54:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:54:09 --> Helper loaded: url_helper
DEBUG - 2011-09-18 06:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 06:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 06:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 06:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 06:54:09 --> Final output sent to browser
DEBUG - 2011-09-18 06:54:09 --> Total execution time: 1.1308
DEBUG - 2011-09-18 06:54:12 --> Config Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:54:12 --> URI Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Router Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Output Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Input Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:54:12 --> Language Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Loader Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Controller Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Model Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Model Class Initialized
DEBUG - 2011-09-18 06:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:54:12 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:54:14 --> Final output sent to browser
DEBUG - 2011-09-18 06:54:14 --> Total execution time: 2.0132
DEBUG - 2011-09-18 06:54:18 --> Config Class Initialized
DEBUG - 2011-09-18 06:54:18 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:54:18 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:54:18 --> URI Class Initialized
DEBUG - 2011-09-18 06:54:18 --> Router Class Initialized
ERROR - 2011-09-18 06:54:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 06:55:37 --> Config Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:55:37 --> URI Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Router Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Output Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Input Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:55:37 --> Language Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Loader Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Controller Class Initialized
ERROR - 2011-09-18 06:55:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 06:55:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 06:55:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:55:37 --> Model Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Model Class Initialized
DEBUG - 2011-09-18 06:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:55:37 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:55:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:55:37 --> Helper loaded: url_helper
DEBUG - 2011-09-18 06:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 06:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 06:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 06:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 06:55:37 --> Final output sent to browser
DEBUG - 2011-09-18 06:55:37 --> Total execution time: 0.0332
DEBUG - 2011-09-18 06:55:41 --> Config Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:55:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:55:41 --> URI Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Router Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Output Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Input Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:55:41 --> Language Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Loader Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Controller Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Model Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Model Class Initialized
DEBUG - 2011-09-18 06:55:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:55:41 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:55:43 --> Final output sent to browser
DEBUG - 2011-09-18 06:55:43 --> Total execution time: 2.4508
DEBUG - 2011-09-18 06:55:49 --> Config Class Initialized
DEBUG - 2011-09-18 06:55:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:55:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:55:49 --> URI Class Initialized
DEBUG - 2011-09-18 06:55:49 --> Router Class Initialized
ERROR - 2011-09-18 06:55:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 06:56:43 --> Config Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:56:43 --> URI Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Router Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Output Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Input Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:56:43 --> Language Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Loader Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Controller Class Initialized
ERROR - 2011-09-18 06:56:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 06:56:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 06:56:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:56:43 --> Model Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Model Class Initialized
DEBUG - 2011-09-18 06:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:56:43 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:56:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:56:43 --> Helper loaded: url_helper
DEBUG - 2011-09-18 06:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 06:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 06:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 06:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 06:56:43 --> Final output sent to browser
DEBUG - 2011-09-18 06:56:43 --> Total execution time: 0.0303
DEBUG - 2011-09-18 06:56:47 --> Config Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:56:47 --> URI Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Router Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Output Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Input Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:56:47 --> Language Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Loader Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Controller Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Model Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Model Class Initialized
DEBUG - 2011-09-18 06:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:56:47 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:56:48 --> Final output sent to browser
DEBUG - 2011-09-18 06:56:48 --> Total execution time: 1.1725
DEBUG - 2011-09-18 06:57:15 --> Config Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:57:15 --> URI Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Router Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Output Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Input Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:57:15 --> Language Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Loader Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Controller Class Initialized
ERROR - 2011-09-18 06:57:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 06:57:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 06:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:57:15 --> Model Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Model Class Initialized
DEBUG - 2011-09-18 06:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:57:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 06:57:15 --> Helper loaded: url_helper
DEBUG - 2011-09-18 06:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 06:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 06:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 06:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 06:57:15 --> Final output sent to browser
DEBUG - 2011-09-18 06:57:15 --> Total execution time: 0.0278
DEBUG - 2011-09-18 06:57:17 --> Config Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 06:57:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 06:57:17 --> URI Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Router Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Output Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Input Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 06:57:17 --> Language Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Loader Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Controller Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Model Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Model Class Initialized
DEBUG - 2011-09-18 06:57:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 06:57:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 06:57:18 --> Final output sent to browser
DEBUG - 2011-09-18 06:57:18 --> Total execution time: 1.2453
DEBUG - 2011-09-18 08:56:51 --> Config Class Initialized
DEBUG - 2011-09-18 08:56:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 08:56:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 08:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 08:56:51 --> URI Class Initialized
DEBUG - 2011-09-18 08:56:51 --> Router Class Initialized
ERROR - 2011-09-18 08:56:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 08:56:52 --> Config Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 08:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 08:56:52 --> URI Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Router Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Output Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Input Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 08:56:52 --> Language Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Loader Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Controller Class Initialized
ERROR - 2011-09-18 08:56:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 08:56:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 08:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 08:56:52 --> Model Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Model Class Initialized
DEBUG - 2011-09-18 08:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 08:56:52 --> Database Driver Class Initialized
DEBUG - 2011-09-18 08:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 08:56:52 --> Helper loaded: url_helper
DEBUG - 2011-09-18 08:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 08:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 08:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 08:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 08:56:52 --> Final output sent to browser
DEBUG - 2011-09-18 08:56:52 --> Total execution time: 0.6767
DEBUG - 2011-09-18 09:03:36 --> Config Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:03:36 --> URI Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Router Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Output Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Input Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 09:03:36 --> Language Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Loader Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Controller Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-18 09:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 09:03:36 --> Database Driver Class Initialized
DEBUG - 2011-09-18 09:03:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 09:03:37 --> Helper loaded: url_helper
DEBUG - 2011-09-18 09:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 09:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 09:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 09:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 09:03:37 --> Final output sent to browser
DEBUG - 2011-09-18 09:03:37 --> Total execution time: 0.7806
DEBUG - 2011-09-18 09:58:24 --> Config Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:58:24 --> URI Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Router Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Output Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Input Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 09:58:24 --> Language Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Loader Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Controller Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Model Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Model Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Model Class Initialized
DEBUG - 2011-09-18 09:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 09:58:24 --> Database Driver Class Initialized
DEBUG - 2011-09-18 09:58:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 09:58:25 --> Helper loaded: url_helper
DEBUG - 2011-09-18 09:58:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 09:58:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 09:58:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 09:58:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 09:58:25 --> Final output sent to browser
DEBUG - 2011-09-18 09:58:25 --> Total execution time: 0.7466
DEBUG - 2011-09-18 09:58:27 --> Config Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:58:27 --> URI Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Router Class Initialized
ERROR - 2011-09-18 09:58:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 09:58:27 --> Config Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:58:27 --> URI Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Router Class Initialized
ERROR - 2011-09-18 09:58:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 09:58:27 --> Config Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:58:27 --> URI Class Initialized
DEBUG - 2011-09-18 09:58:27 --> Router Class Initialized
ERROR - 2011-09-18 09:58:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 09:58:45 --> Config Class Initialized
DEBUG - 2011-09-18 09:58:45 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:58:45 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:58:45 --> URI Class Initialized
DEBUG - 2011-09-18 09:58:45 --> Router Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Output Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Input Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 09:58:46 --> Language Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Loader Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Controller Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Model Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Model Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Model Class Initialized
DEBUG - 2011-09-18 09:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 09:58:46 --> Database Driver Class Initialized
DEBUG - 2011-09-18 09:58:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 09:58:46 --> Helper loaded: url_helper
DEBUG - 2011-09-18 09:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 09:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 09:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 09:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 09:58:46 --> Final output sent to browser
DEBUG - 2011-09-18 09:58:46 --> Total execution time: 0.3344
DEBUG - 2011-09-18 09:59:22 --> Config Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Hooks Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Utf8 Class Initialized
DEBUG - 2011-09-18 09:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 09:59:22 --> URI Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Router Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Output Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Input Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 09:59:22 --> Language Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Loader Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Controller Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Model Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Model Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Model Class Initialized
DEBUG - 2011-09-18 09:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 09:59:22 --> Database Driver Class Initialized
DEBUG - 2011-09-18 09:59:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 09:59:22 --> Helper loaded: url_helper
DEBUG - 2011-09-18 09:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 09:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 09:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 09:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 09:59:22 --> Final output sent to browser
DEBUG - 2011-09-18 09:59:22 --> Total execution time: 0.7577
DEBUG - 2011-09-18 10:00:03 --> Config Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:00:03 --> URI Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Router Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Output Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Input Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:00:03 --> Language Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Loader Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Controller Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:00:03 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:00:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:00:05 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:00:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:00:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:00:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:00:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:00:05 --> Final output sent to browser
DEBUG - 2011-09-18 10:00:05 --> Total execution time: 2.3087
DEBUG - 2011-09-18 10:00:26 --> Config Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:00:26 --> URI Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Router Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Output Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Input Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:00:26 --> Language Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Loader Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Controller Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:00:26 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:00:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:00:30 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:00:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:00:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:00:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:00:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:00:30 --> Final output sent to browser
DEBUG - 2011-09-18 10:00:30 --> Total execution time: 4.0548
DEBUG - 2011-09-18 10:00:54 --> Config Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:00:54 --> URI Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Router Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Output Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Input Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:00:54 --> Language Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Loader Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Controller Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Model Class Initialized
DEBUG - 2011-09-18 10:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:00:54 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:00:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:00:54 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:00:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:00:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:00:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:00:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:00:54 --> Final output sent to browser
DEBUG - 2011-09-18 10:00:54 --> Total execution time: 0.2274
DEBUG - 2011-09-18 10:01:26 --> Config Class Initialized
DEBUG - 2011-09-18 10:01:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:01:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:01:26 --> URI Class Initialized
DEBUG - 2011-09-18 10:01:26 --> Router Class Initialized
DEBUG - 2011-09-18 10:01:26 --> Output Class Initialized
DEBUG - 2011-09-18 10:01:26 --> Input Class Initialized
DEBUG - 2011-09-18 10:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:01:26 --> Language Class Initialized
DEBUG - 2011-09-18 10:01:27 --> Loader Class Initialized
DEBUG - 2011-09-18 10:01:27 --> Controller Class Initialized
DEBUG - 2011-09-18 10:01:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:01:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:01:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:01:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:01:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:01:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:01:27 --> Final output sent to browser
DEBUG - 2011-09-18 10:01:27 --> Total execution time: 0.5953
DEBUG - 2011-09-18 10:01:51 --> Config Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:01:51 --> URI Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Router Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Output Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Input Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:01:51 --> Language Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Loader Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Controller Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Model Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Model Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Model Class Initialized
DEBUG - 2011-09-18 10:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:01:51 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:01:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:01:51 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:01:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:01:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:01:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:01:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:01:51 --> Final output sent to browser
DEBUG - 2011-09-18 10:01:51 --> Total execution time: 0.2425
DEBUG - 2011-09-18 10:02:20 --> Config Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:02:20 --> URI Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Router Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Output Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Input Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:02:20 --> Language Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Loader Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Controller Class Initialized
DEBUG - 2011-09-18 10:02:20 --> Model Class Initialized
DEBUG - 2011-09-18 10:02:21 --> Model Class Initialized
DEBUG - 2011-09-18 10:02:21 --> Model Class Initialized
DEBUG - 2011-09-18 10:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:02:21 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:02:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:02:21 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:02:21 --> Final output sent to browser
DEBUG - 2011-09-18 10:02:21 --> Total execution time: 0.1981
DEBUG - 2011-09-18 10:02:41 --> Config Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:02:41 --> URI Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Router Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Output Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Input Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:02:41 --> Language Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Loader Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Controller Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Model Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Model Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Model Class Initialized
DEBUG - 2011-09-18 10:02:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:02:41 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:02:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:02:42 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:02:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:02:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:02:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:02:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:02:42 --> Final output sent to browser
DEBUG - 2011-09-18 10:02:42 --> Total execution time: 1.0306
DEBUG - 2011-09-18 10:03:01 --> Config Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:03:01 --> URI Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Router Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Output Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Input Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:03:01 --> Language Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Loader Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Controller Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Model Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Model Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Model Class Initialized
DEBUG - 2011-09-18 10:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:03:01 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:03:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:03:01 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:03:01 --> Final output sent to browser
DEBUG - 2011-09-18 10:03:01 --> Total execution time: 0.3077
DEBUG - 2011-09-18 10:03:20 --> Config Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:03:20 --> URI Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Router Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Output Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Input Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:03:20 --> Language Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Loader Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Controller Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Model Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Model Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Model Class Initialized
DEBUG - 2011-09-18 10:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:03:20 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:03:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:03:20 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:03:20 --> Final output sent to browser
DEBUG - 2011-09-18 10:03:20 --> Total execution time: 0.3600
DEBUG - 2011-09-18 10:23:27 --> Config Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:23:27 --> URI Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Router Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Output Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Input Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:23:27 --> Language Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Loader Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Controller Class Initialized
ERROR - 2011-09-18 10:23:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:23:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:23:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:23:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:23:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:23:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:23:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:23:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:23:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:23:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:23:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:23:27 --> Final output sent to browser
DEBUG - 2011-09-18 10:23:27 --> Total execution time: 0.0631
DEBUG - 2011-09-18 10:23:28 --> Config Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:23:28 --> URI Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Router Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Output Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Input Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:23:28 --> Language Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Loader Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Controller Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Model Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Model Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:23:28 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:23:28 --> Final output sent to browser
DEBUG - 2011-09-18 10:23:28 --> Total execution time: 0.6377
DEBUG - 2011-09-18 10:23:29 --> Config Class Initialized
DEBUG - 2011-09-18 10:23:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:23:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:23:29 --> URI Class Initialized
DEBUG - 2011-09-18 10:23:29 --> Router Class Initialized
ERROR - 2011-09-18 10:23:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 10:23:29 --> Config Class Initialized
DEBUG - 2011-09-18 10:23:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:23:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:23:29 --> URI Class Initialized
DEBUG - 2011-09-18 10:23:29 --> Router Class Initialized
ERROR - 2011-09-18 10:23:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 10:25:15 --> Config Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:25:15 --> URI Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Router Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Output Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Input Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:25:15 --> Language Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Loader Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Controller Class Initialized
ERROR - 2011-09-18 10:25:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:25:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:25:15 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:25:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:25:15 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:25:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:25:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:25:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:25:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:25:15 --> Final output sent to browser
DEBUG - 2011-09-18 10:25:15 --> Total execution time: 0.0300
DEBUG - 2011-09-18 10:25:16 --> Config Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:25:16 --> URI Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Router Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Output Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Input Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:25:16 --> Language Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Loader Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Controller Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:25:16 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:25:16 --> Final output sent to browser
DEBUG - 2011-09-18 10:25:16 --> Total execution time: 0.5890
DEBUG - 2011-09-18 10:25:27 --> Config Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:25:27 --> URI Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Router Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Output Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Input Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:25:27 --> Language Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Loader Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Controller Class Initialized
ERROR - 2011-09-18 10:25:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:25:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:25:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:25:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:25:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:25:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:25:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:25:27 --> Final output sent to browser
DEBUG - 2011-09-18 10:25:27 --> Total execution time: 0.0298
DEBUG - 2011-09-18 10:25:28 --> Config Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:25:28 --> URI Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Router Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Output Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Input Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:25:28 --> Language Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Loader Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Controller Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:25:28 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:25:29 --> Final output sent to browser
DEBUG - 2011-09-18 10:25:29 --> Total execution time: 1.2175
DEBUG - 2011-09-18 10:25:41 --> Config Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:25:41 --> URI Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Router Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Output Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Input Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:25:41 --> Language Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Loader Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Controller Class Initialized
ERROR - 2011-09-18 10:25:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:25:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:25:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:25:41 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:25:41 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:25:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:25:41 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:25:41 --> Final output sent to browser
DEBUG - 2011-09-18 10:25:41 --> Total execution time: 0.0317
DEBUG - 2011-09-18 10:25:42 --> Config Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:25:42 --> URI Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Router Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Output Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Input Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:25:42 --> Language Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Loader Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Controller Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Model Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:25:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:25:42 --> Final output sent to browser
DEBUG - 2011-09-18 10:25:42 --> Total execution time: 0.5030
DEBUG - 2011-09-18 10:26:14 --> Config Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:26:14 --> URI Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Router Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Output Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Input Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:26:14 --> Language Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Loader Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Controller Class Initialized
ERROR - 2011-09-18 10:26:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:26:14 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:26:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:26:14 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:26:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:26:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:26:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:26:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:26:14 --> Final output sent to browser
DEBUG - 2011-09-18 10:26:14 --> Total execution time: 0.0800
DEBUG - 2011-09-18 10:26:15 --> Config Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:26:15 --> URI Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Router Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Output Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Input Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:26:15 --> Language Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Loader Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Controller Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:26:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:26:15 --> Final output sent to browser
DEBUG - 2011-09-18 10:26:15 --> Total execution time: 0.6349
DEBUG - 2011-09-18 10:26:23 --> Config Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:26:23 --> URI Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Router Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Output Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Input Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:26:23 --> Language Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Loader Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Controller Class Initialized
ERROR - 2011-09-18 10:26:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:26:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:26:23 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:26:23 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:26:23 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:26:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:26:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:26:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:26:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:26:23 --> Final output sent to browser
DEBUG - 2011-09-18 10:26:23 --> Total execution time: 0.0333
DEBUG - 2011-09-18 10:26:24 --> Config Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:26:24 --> URI Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Router Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Output Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Input Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:26:24 --> Language Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Loader Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Controller Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Model Class Initialized
DEBUG - 2011-09-18 10:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:26:24 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:26:25 --> Final output sent to browser
DEBUG - 2011-09-18 10:26:25 --> Total execution time: 0.5453
DEBUG - 2011-09-18 10:55:58 --> Config Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:55:58 --> URI Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Router Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Output Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Input Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:55:58 --> Language Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Loader Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Controller Class Initialized
ERROR - 2011-09-18 10:55:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 10:55:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 10:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:55:58 --> Model Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Model Class Initialized
DEBUG - 2011-09-18 10:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:55:58 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 10:55:58 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:55:58 --> Final output sent to browser
DEBUG - 2011-09-18 10:55:58 --> Total execution time: 0.2474
DEBUG - 2011-09-18 10:55:59 --> Config Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:55:59 --> URI Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Router Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Output Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Input Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:55:59 --> Language Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Loader Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Controller Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Model Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Model Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:55:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:55:59 --> Final output sent to browser
DEBUG - 2011-09-18 10:55:59 --> Total execution time: 0.5483
DEBUG - 2011-09-18 10:56:01 --> Config Class Initialized
DEBUG - 2011-09-18 10:56:01 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:56:01 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:56:01 --> URI Class Initialized
DEBUG - 2011-09-18 10:56:01 --> Router Class Initialized
ERROR - 2011-09-18 10:56:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 10:56:01 --> Config Class Initialized
DEBUG - 2011-09-18 10:56:01 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:56:01 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:56:01 --> URI Class Initialized
DEBUG - 2011-09-18 10:56:01 --> Router Class Initialized
ERROR - 2011-09-18 10:56:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 10:56:32 --> Config Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Hooks Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Utf8 Class Initialized
DEBUG - 2011-09-18 10:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 10:56:32 --> URI Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Router Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Output Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Input Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 10:56:32 --> Language Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Loader Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Controller Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Model Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Model Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Model Class Initialized
DEBUG - 2011-09-18 10:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 10:56:32 --> Database Driver Class Initialized
DEBUG - 2011-09-18 10:56:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 10:56:32 --> Helper loaded: url_helper
DEBUG - 2011-09-18 10:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 10:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 10:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 10:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 10:56:32 --> Final output sent to browser
DEBUG - 2011-09-18 10:56:32 --> Total execution time: 0.4021
DEBUG - 2011-09-18 11:07:15 --> Config Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 11:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 11:07:15 --> URI Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Router Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Output Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Input Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 11:07:15 --> Language Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Loader Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Controller Class Initialized
ERROR - 2011-09-18 11:07:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 11:07:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 11:07:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 11:07:15 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 11:07:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 11:07:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 11:07:15 --> Helper loaded: url_helper
DEBUG - 2011-09-18 11:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 11:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 11:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 11:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 11:07:15 --> Final output sent to browser
DEBUG - 2011-09-18 11:07:15 --> Total execution time: 0.1297
DEBUG - 2011-09-18 11:07:19 --> Config Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Hooks Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Utf8 Class Initialized
DEBUG - 2011-09-18 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 11:07:19 --> URI Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Router Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Output Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Input Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 11:07:19 --> Language Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Loader Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Controller Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 11:07:19 --> Database Driver Class Initialized
DEBUG - 2011-09-18 11:07:20 --> Final output sent to browser
DEBUG - 2011-09-18 11:07:20 --> Total execution time: 0.6227
DEBUG - 2011-09-18 11:07:38 --> Config Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Hooks Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Utf8 Class Initialized
DEBUG - 2011-09-18 11:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 11:07:38 --> URI Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Router Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Output Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Input Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 11:07:38 --> Language Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Loader Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Controller Class Initialized
ERROR - 2011-09-18 11:07:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 11:07:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 11:07:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 11:07:38 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 11:07:38 --> Database Driver Class Initialized
DEBUG - 2011-09-18 11:07:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 11:07:38 --> Helper loaded: url_helper
DEBUG - 2011-09-18 11:07:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 11:07:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 11:07:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 11:07:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 11:07:38 --> Final output sent to browser
DEBUG - 2011-09-18 11:07:38 --> Total execution time: 0.0672
DEBUG - 2011-09-18 11:07:42 --> Config Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 11:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 11:07:42 --> URI Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Router Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Output Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Input Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 11:07:42 --> Language Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Loader Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Controller Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Model Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 11:07:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 11:07:42 --> Final output sent to browser
DEBUG - 2011-09-18 11:07:42 --> Total execution time: 0.6801
DEBUG - 2011-09-18 11:35:40 --> Config Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Hooks Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Utf8 Class Initialized
DEBUG - 2011-09-18 11:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 11:35:40 --> URI Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Router Class Initialized
DEBUG - 2011-09-18 11:35:40 --> No URI present. Default controller set.
DEBUG - 2011-09-18 11:35:40 --> Output Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Input Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 11:35:40 --> Language Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Loader Class Initialized
DEBUG - 2011-09-18 11:35:40 --> Controller Class Initialized
DEBUG - 2011-09-18 11:35:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 11:35:40 --> Helper loaded: url_helper
DEBUG - 2011-09-18 11:35:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 11:35:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 11:35:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 11:35:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 11:35:40 --> Final output sent to browser
DEBUG - 2011-09-18 11:35:40 --> Total execution time: 0.0757
DEBUG - 2011-09-18 12:11:18 --> Config Class Initialized
DEBUG - 2011-09-18 12:11:18 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:11:18 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:11:18 --> URI Class Initialized
DEBUG - 2011-09-18 12:11:18 --> Router Class Initialized
ERROR - 2011-09-18 12:11:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 12:12:11 --> Config Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:12:11 --> URI Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Router Class Initialized
DEBUG - 2011-09-18 12:12:11 --> No URI present. Default controller set.
DEBUG - 2011-09-18 12:12:11 --> Output Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Input Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:12:11 --> Language Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Loader Class Initialized
DEBUG - 2011-09-18 12:12:11 --> Controller Class Initialized
DEBUG - 2011-09-18 12:12:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 12:12:12 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:12:12 --> Final output sent to browser
DEBUG - 2011-09-18 12:12:12 --> Total execution time: 0.1661
DEBUG - 2011-09-18 12:18:19 --> Config Class Initialized
DEBUG - 2011-09-18 12:18:19 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:18:19 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:18:19 --> URI Class Initialized
DEBUG - 2011-09-18 12:18:19 --> Router Class Initialized
ERROR - 2011-09-18 12:18:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 12:29:31 --> Config Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:29:31 --> URI Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Router Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Output Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Input Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:29:31 --> Language Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Loader Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Controller Class Initialized
ERROR - 2011-09-18 12:29:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:29:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:29:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:29:31 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:29:31 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:29:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:29:31 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:29:31 --> Final output sent to browser
DEBUG - 2011-09-18 12:29:31 --> Total execution time: 0.4390
DEBUG - 2011-09-18 12:29:34 --> Config Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:29:34 --> URI Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Router Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Output Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Input Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:29:34 --> Language Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Loader Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Controller Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:29:34 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:29:35 --> Final output sent to browser
DEBUG - 2011-09-18 12:29:35 --> Total execution time: 0.8158
DEBUG - 2011-09-18 12:29:53 --> Config Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:29:53 --> URI Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Router Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Output Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Input Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:29:53 --> Language Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Loader Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Controller Class Initialized
ERROR - 2011-09-18 12:29:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:29:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:29:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:29:53 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:29:53 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:29:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:29:53 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:29:53 --> Final output sent to browser
DEBUG - 2011-09-18 12:29:53 --> Total execution time: 0.0307
DEBUG - 2011-09-18 12:29:58 --> Config Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:29:58 --> URI Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Router Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Output Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Input Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:29:58 --> Language Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Loader Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Controller Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:29:58 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Final output sent to browser
DEBUG - 2011-09-18 12:29:59 --> Total execution time: 0.6259
DEBUG - 2011-09-18 12:29:59 --> Config Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:29:59 --> URI Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Router Class Initialized
ERROR - 2011-09-18 12:29:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 12:29:59 --> Config Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:29:59 --> URI Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Router Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Output Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Input Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:29:59 --> Language Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Loader Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Controller Class Initialized
ERROR - 2011-09-18 12:29:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:29:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:29:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:29:59 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Model Class Initialized
DEBUG - 2011-09-18 12:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:29:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:29:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:29:59 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:29:59 --> Final output sent to browser
DEBUG - 2011-09-18 12:29:59 --> Total execution time: 0.0308
DEBUG - 2011-09-18 12:51:20 --> Config Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:51:20 --> URI Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Router Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Output Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Input Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:51:20 --> Language Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Loader Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Controller Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:51:20 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:51:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 12:51:20 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:51:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:51:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:51:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:51:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:51:20 --> Final output sent to browser
DEBUG - 2011-09-18 12:51:20 --> Total execution time: 0.4581
DEBUG - 2011-09-18 12:51:22 --> Config Class Initialized
DEBUG - 2011-09-18 12:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:51:22 --> URI Class Initialized
DEBUG - 2011-09-18 12:51:22 --> Router Class Initialized
ERROR - 2011-09-18 12:51:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 12:51:30 --> Config Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:51:30 --> URI Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Router Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Output Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Input Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:51:30 --> Language Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Loader Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Controller Class Initialized
ERROR - 2011-09-18 12:51:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:51:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:51:30 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:51:30 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:51:30 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:51:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:51:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:51:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:51:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:51:30 --> Final output sent to browser
DEBUG - 2011-09-18 12:51:30 --> Total execution time: 0.0266
DEBUG - 2011-09-18 12:51:30 --> Config Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:51:30 --> URI Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Router Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Output Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Input Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:51:30 --> Language Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Loader Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Controller Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:51:30 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:51:31 --> Final output sent to browser
DEBUG - 2011-09-18 12:51:31 --> Total execution time: 0.5369
DEBUG - 2011-09-18 12:51:58 --> Config Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:51:58 --> URI Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Router Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Output Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Input Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:51:58 --> Language Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Loader Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Controller Class Initialized
ERROR - 2011-09-18 12:51:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:51:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:51:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:51:58 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:51:58 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:51:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:51:58 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:51:58 --> Final output sent to browser
DEBUG - 2011-09-18 12:51:58 --> Total execution time: 0.0972
DEBUG - 2011-09-18 12:51:59 --> Config Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:51:59 --> URI Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Router Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Output Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Input Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:51:59 --> Language Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Loader Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Controller Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Model Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:51:59 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:51:59 --> Final output sent to browser
DEBUG - 2011-09-18 12:51:59 --> Total execution time: 0.8248
DEBUG - 2011-09-18 12:52:15 --> Config Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:52:15 --> URI Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Router Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Output Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Input Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:52:15 --> Language Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Loader Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Controller Class Initialized
ERROR - 2011-09-18 12:52:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:52:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:52:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:52:15 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:52:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:52:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:52:15 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:52:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:52:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:52:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:52:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:52:15 --> Final output sent to browser
DEBUG - 2011-09-18 12:52:15 --> Total execution time: 0.0305
DEBUG - 2011-09-18 12:52:16 --> Config Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:52:16 --> URI Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Router Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Output Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Input Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:52:16 --> Language Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Loader Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Controller Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:52:16 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:52:16 --> Final output sent to browser
DEBUG - 2011-09-18 12:52:16 --> Total execution time: 0.7503
DEBUG - 2011-09-18 12:52:26 --> Config Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:52:26 --> URI Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Router Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Output Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Input Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:52:26 --> Language Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Loader Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Controller Class Initialized
ERROR - 2011-09-18 12:52:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 12:52:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 12:52:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:52:26 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:52:26 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:52:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 12:52:26 --> Helper loaded: url_helper
DEBUG - 2011-09-18 12:52:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 12:52:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 12:52:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 12:52:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 12:52:26 --> Final output sent to browser
DEBUG - 2011-09-18 12:52:26 --> Total execution time: 0.0292
DEBUG - 2011-09-18 12:52:26 --> Config Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Hooks Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Utf8 Class Initialized
DEBUG - 2011-09-18 12:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 12:52:26 --> URI Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Router Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Output Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Input Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 12:52:26 --> Language Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Loader Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Controller Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Model Class Initialized
DEBUG - 2011-09-18 12:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 12:52:26 --> Database Driver Class Initialized
DEBUG - 2011-09-18 12:52:27 --> Final output sent to browser
DEBUG - 2011-09-18 12:52:27 --> Total execution time: 0.5553
DEBUG - 2011-09-18 13:24:08 --> Config Class Initialized
DEBUG - 2011-09-18 13:24:08 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:24:08 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:24:08 --> URI Class Initialized
DEBUG - 2011-09-18 13:24:08 --> Router Class Initialized
ERROR - 2011-09-18 13:24:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 13:45:04 --> Config Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:45:04 --> URI Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Router Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Output Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Input Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:45:04 --> Language Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Loader Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Controller Class Initialized
ERROR - 2011-09-18 13:45:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:45:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:45:04 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:45:04 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:45:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:45:05 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:45:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:45:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:45:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:45:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:45:05 --> Final output sent to browser
DEBUG - 2011-09-18 13:45:05 --> Total execution time: 0.5241
DEBUG - 2011-09-18 13:45:06 --> Config Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:45:06 --> URI Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Router Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Output Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Input Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:45:06 --> Language Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Loader Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Controller Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:45:06 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:45:07 --> Final output sent to browser
DEBUG - 2011-09-18 13:45:07 --> Total execution time: 1.0408
DEBUG - 2011-09-18 13:45:07 --> Config Class Initialized
DEBUG - 2011-09-18 13:45:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:45:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:45:08 --> URI Class Initialized
DEBUG - 2011-09-18 13:45:08 --> Router Class Initialized
ERROR - 2011-09-18 13:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 13:45:08 --> Config Class Initialized
DEBUG - 2011-09-18 13:45:08 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:45:08 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:45:08 --> URI Class Initialized
DEBUG - 2011-09-18 13:45:08 --> Router Class Initialized
ERROR - 2011-09-18 13:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 13:45:48 --> Config Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:45:48 --> URI Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Router Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Output Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Input Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:45:48 --> Language Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Loader Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Controller Class Initialized
ERROR - 2011-09-18 13:45:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:45:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:45:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:45:48 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:45:48 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:45:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:45:48 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:45:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:45:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:45:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:45:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:45:48 --> Final output sent to browser
DEBUG - 2011-09-18 13:45:48 --> Total execution time: 0.0560
DEBUG - 2011-09-18 13:45:49 --> Config Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:45:49 --> URI Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Router Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Output Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Input Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:45:49 --> Language Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Loader Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Controller Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Model Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:45:49 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:45:49 --> Final output sent to browser
DEBUG - 2011-09-18 13:45:49 --> Total execution time: 0.6730
DEBUG - 2011-09-18 13:46:16 --> Config Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:46:16 --> URI Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Router Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Output Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Input Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:46:16 --> Language Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Loader Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Controller Class Initialized
ERROR - 2011-09-18 13:46:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:46:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:46:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:46:16 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:46:16 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:46:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:46:16 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:46:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:46:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:46:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:46:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:46:16 --> Final output sent to browser
DEBUG - 2011-09-18 13:46:16 --> Total execution time: 0.1491
DEBUG - 2011-09-18 13:46:17 --> Config Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:46:17 --> URI Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Router Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Output Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Input Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:46:17 --> Language Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Loader Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Controller Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:46:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:46:17 --> Final output sent to browser
DEBUG - 2011-09-18 13:46:17 --> Total execution time: 0.8642
DEBUG - 2011-09-18 13:46:51 --> Config Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:46:51 --> URI Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Router Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Output Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Input Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:46:51 --> Language Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Loader Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Controller Class Initialized
ERROR - 2011-09-18 13:46:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:46:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:46:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:46:51 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:46:51 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:46:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:46:51 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:46:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:46:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:46:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:46:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:46:51 --> Final output sent to browser
DEBUG - 2011-09-18 13:46:51 --> Total execution time: 0.0300
DEBUG - 2011-09-18 13:46:52 --> Config Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:46:52 --> URI Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Router Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Output Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Input Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:46:52 --> Language Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Loader Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Controller Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Model Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:46:52 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:46:52 --> Final output sent to browser
DEBUG - 2011-09-18 13:46:52 --> Total execution time: 0.5969
DEBUG - 2011-09-18 13:47:53 --> Config Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:47:53 --> URI Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Router Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Output Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Input Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:47:53 --> Language Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Loader Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Controller Class Initialized
ERROR - 2011-09-18 13:47:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:47:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:47:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:47:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:47:53 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:47:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:47:53 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:47:53 --> Final output sent to browser
DEBUG - 2011-09-18 13:47:53 --> Total execution time: 0.0316
DEBUG - 2011-09-18 13:47:53 --> Config Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:47:53 --> URI Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Router Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Output Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Input Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:47:53 --> Language Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Loader Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Controller Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:47:53 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:47:54 --> Final output sent to browser
DEBUG - 2011-09-18 13:47:54 --> Total execution time: 0.6410
DEBUG - 2011-09-18 13:48:21 --> Config Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:48:21 --> URI Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Router Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Output Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Input Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:48:21 --> Language Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Loader Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Controller Class Initialized
ERROR - 2011-09-18 13:48:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:48:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:48:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:48:21 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:48:21 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:48:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:48:21 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:48:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:48:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:48:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:48:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:48:21 --> Final output sent to browser
DEBUG - 2011-09-18 13:48:21 --> Total execution time: 0.0306
DEBUG - 2011-09-18 13:48:22 --> Config Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:48:22 --> URI Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Router Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Output Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Input Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:48:22 --> Language Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Loader Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Controller Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:48:22 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:48:22 --> Final output sent to browser
DEBUG - 2011-09-18 13:48:22 --> Total execution time: 0.5354
DEBUG - 2011-09-18 13:48:53 --> Config Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:48:53 --> URI Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Router Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Output Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Input Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:48:53 --> Language Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Loader Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Controller Class Initialized
ERROR - 2011-09-18 13:48:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:48:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:48:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:48:53 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:48:53 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:48:53 --> Final output sent to browser
DEBUG - 2011-09-18 13:48:53 --> Total execution time: 0.0399
DEBUG - 2011-09-18 13:48:53 --> Config Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:48:53 --> URI Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Router Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Output Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Input Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:48:53 --> Language Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Loader Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Controller Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Model Class Initialized
DEBUG - 2011-09-18 13:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:48:53 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:48:54 --> Final output sent to browser
DEBUG - 2011-09-18 13:48:54 --> Total execution time: 0.5439
DEBUG - 2011-09-18 13:49:15 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:15 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Router Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Output Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Input Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:49:15 --> Language Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Loader Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Controller Class Initialized
ERROR - 2011-09-18 13:49:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:49:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:49:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:49:15 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:49:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:49:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:49:15 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:49:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:49:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:49:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:49:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:49:15 --> Final output sent to browser
DEBUG - 2011-09-18 13:49:15 --> Total execution time: 0.1596
DEBUG - 2011-09-18 13:49:16 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:16 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Router Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Output Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Input Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:49:16 --> Language Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Loader Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Controller Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:49:16 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:49:16 --> Final output sent to browser
DEBUG - 2011-09-18 13:49:16 --> Total execution time: 0.7049
DEBUG - 2011-09-18 13:49:17 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:17 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Router Class Initialized
ERROR - 2011-09-18 13:49:17 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:49:17 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:17 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:17 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Router Class Initialized
ERROR - 2011-09-18 13:49:17 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:17 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:17 --> Router Class Initialized
ERROR - 2011-09-18 13:49:17 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:49:41 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:41 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Router Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Output Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Input Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:49:41 --> Language Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Loader Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Controller Class Initialized
ERROR - 2011-09-18 13:49:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:49:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:49:41 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:49:41 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:49:41 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:49:41 --> Final output sent to browser
DEBUG - 2011-09-18 13:49:41 --> Total execution time: 0.0312
DEBUG - 2011-09-18 13:49:42 --> Config Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:49:42 --> URI Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Router Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Output Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Input Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:49:42 --> Language Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Loader Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Controller Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Model Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:49:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:49:42 --> Final output sent to browser
DEBUG - 2011-09-18 13:49:42 --> Total execution time: 0.5873
DEBUG - 2011-09-18 13:50:06 --> Config Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:50:06 --> URI Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Router Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Output Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Input Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:50:06 --> Language Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Loader Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Controller Class Initialized
ERROR - 2011-09-18 13:50:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:50:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:50:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:50:06 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:50:06 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:50:06 --> Final output sent to browser
DEBUG - 2011-09-18 13:50:06 --> Total execution time: 0.0867
DEBUG - 2011-09-18 13:50:06 --> Config Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:50:06 --> URI Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Router Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Output Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Input Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:50:06 --> Language Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Loader Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Controller Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:50:06 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:50:07 --> Final output sent to browser
DEBUG - 2011-09-18 13:50:07 --> Total execution time: 0.6243
DEBUG - 2011-09-18 13:50:29 --> Config Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:50:29 --> URI Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Router Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Output Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Input Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:50:29 --> Language Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Loader Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Controller Class Initialized
ERROR - 2011-09-18 13:50:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:50:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:50:29 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:50:29 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:50:29 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:50:29 --> Final output sent to browser
DEBUG - 2011-09-18 13:50:29 --> Total execution time: 0.0292
DEBUG - 2011-09-18 13:50:29 --> Config Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:50:29 --> URI Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Router Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Output Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Input Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:50:29 --> Language Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Loader Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Controller Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:50:29 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:50:30 --> Final output sent to browser
DEBUG - 2011-09-18 13:50:30 --> Total execution time: 0.5002
DEBUG - 2011-09-18 13:50:51 --> Config Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:50:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:50:51 --> URI Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Router Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Output Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Input Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:50:51 --> Language Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Loader Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Controller Class Initialized
ERROR - 2011-09-18 13:50:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:50:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:50:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:50:51 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:50:51 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:50:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:50:51 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:50:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:50:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:50:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:50:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:50:51 --> Final output sent to browser
DEBUG - 2011-09-18 13:50:51 --> Total execution time: 0.0279
DEBUG - 2011-09-18 13:50:52 --> Config Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:50:52 --> URI Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Router Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Output Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Input Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:50:52 --> Language Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Loader Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Controller Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Model Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:50:52 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:50:52 --> Final output sent to browser
DEBUG - 2011-09-18 13:50:52 --> Total execution time: 0.5348
DEBUG - 2011-09-18 13:51:06 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:06 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:06 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Controller Class Initialized
ERROR - 2011-09-18 13:51:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:51:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:06 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:51:06 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:06 --> Total execution time: 0.0341
DEBUG - 2011-09-18 13:51:06 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:06 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:06 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Controller Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:07 --> Total execution time: 0.5848
DEBUG - 2011-09-18 13:51:07 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:07 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Router Class Initialized
ERROR - 2011-09-18 13:51:07 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:07 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:07 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Router Class Initialized
ERROR - 2011-09-18 13:51:07 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:07 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:07 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:07 --> Router Class Initialized
ERROR - 2011-09-18 13:51:07 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:23 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:23 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:23 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Controller Class Initialized
ERROR - 2011-09-18 13:51:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:51:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:23 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:23 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:23 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:51:23 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:23 --> Total execution time: 0.0310
DEBUG - 2011-09-18 13:51:24 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:24 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:24 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Controller Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:24 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:24 --> Total execution time: 0.5485
DEBUG - 2011-09-18 13:51:24 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:24 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Router Class Initialized
ERROR - 2011-09-18 13:51:24 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:24 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:24 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Router Class Initialized
ERROR - 2011-09-18 13:51:24 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:24 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:24 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:24 --> Router Class Initialized
ERROR - 2011-09-18 13:51:24 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:42 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:42 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:42 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Controller Class Initialized
ERROR - 2011-09-18 13:51:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:51:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:51:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:42 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:42 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:51:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:51:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:51:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:51:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:51:42 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:42 --> Total execution time: 0.0289
DEBUG - 2011-09-18 13:51:42 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:42 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:42 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Controller Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:42 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:43 --> Total execution time: 0.6236
DEBUG - 2011-09-18 13:51:43 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:43 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Router Class Initialized
ERROR - 2011-09-18 13:51:43 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:43 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:43 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Router Class Initialized
ERROR - 2011-09-18 13:51:43 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:43 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:43 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:43 --> Router Class Initialized
ERROR - 2011-09-18 13:51:43 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:51:44 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:44 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:44 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Controller Class Initialized
ERROR - 2011-09-18 13:51:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:51:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:51:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:44 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:44 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:44 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:51:44 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:44 --> Total execution time: 0.0268
DEBUG - 2011-09-18 13:51:57 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:57 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:57 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Controller Class Initialized
ERROR - 2011-09-18 13:51:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:51:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:51:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:57 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:57 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:51:57 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:51:57 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:57 --> Total execution time: 0.0295
DEBUG - 2011-09-18 13:51:57 --> Config Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:51:57 --> URI Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Router Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Output Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Input Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:51:57 --> Language Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Loader Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Controller Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Model Class Initialized
DEBUG - 2011-09-18 13:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:51:57 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:51:58 --> Final output sent to browser
DEBUG - 2011-09-18 13:51:58 --> Total execution time: 0.6099
DEBUG - 2011-09-18 13:52:10 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:10 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Router Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Output Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Input Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:52:10 --> Language Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Loader Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Controller Class Initialized
ERROR - 2011-09-18 13:52:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:52:10 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:52:10 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:52:10 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:52:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:52:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:52:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:52:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:52:10 --> Final output sent to browser
DEBUG - 2011-09-18 13:52:10 --> Total execution time: 0.0471
DEBUG - 2011-09-18 13:52:11 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:11 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Router Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Output Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Input Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:52:11 --> Language Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Loader Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Controller Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:52:11 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:52:11 --> Final output sent to browser
DEBUG - 2011-09-18 13:52:11 --> Total execution time: 0.7024
DEBUG - 2011-09-18 13:52:27 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:27 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Router Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Output Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Input Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:52:27 --> Language Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Loader Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Controller Class Initialized
ERROR - 2011-09-18 13:52:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 13:52:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 13:52:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:52:27 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:52:27 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:52:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 13:52:27 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:52:27 --> Final output sent to browser
DEBUG - 2011-09-18 13:52:27 --> Total execution time: 0.0923
DEBUG - 2011-09-18 13:52:28 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:28 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Router Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Output Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Input Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:52:28 --> Language Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Loader Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Controller Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Model Class Initialized
DEBUG - 2011-09-18 13:52:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:52:28 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:29 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Router Class Initialized
ERROR - 2011-09-18 13:52:29 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:52:29 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:29 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Router Class Initialized
ERROR - 2011-09-18 13:52:29 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:52:29 --> Config Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:52:29 --> URI Class Initialized
DEBUG - 2011-09-18 13:52:29 --> Router Class Initialized
ERROR - 2011-09-18 13:52:29 --> 404 Page Not Found --> doubleclick
DEBUG - 2011-09-18 13:52:30 --> Final output sent to browser
DEBUG - 2011-09-18 13:52:30 --> Total execution time: 1.4325
DEBUG - 2011-09-18 13:55:30 --> Config Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:55:30 --> URI Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Router Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Output Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Input Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:55:30 --> Language Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Loader Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Controller Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Model Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Model Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Model Class Initialized
DEBUG - 2011-09-18 13:55:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:55:30 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:55:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 13:55:33 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:55:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:55:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:55:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:55:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:55:33 --> Final output sent to browser
DEBUG - 2011-09-18 13:55:33 --> Total execution time: 3.0512
DEBUG - 2011-09-18 13:55:36 --> Config Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:55:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:55:36 --> URI Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Router Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Output Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Input Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:55:36 --> Language Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Loader Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Controller Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Model Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Model Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Model Class Initialized
DEBUG - 2011-09-18 13:55:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:55:36 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:55:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 13:55:36 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:55:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:55:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:55:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:55:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:55:36 --> Final output sent to browser
DEBUG - 2011-09-18 13:55:36 --> Total execution time: 0.1393
DEBUG - 2011-09-18 13:55:37 --> Config Class Initialized
DEBUG - 2011-09-18 13:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:55:37 --> URI Class Initialized
DEBUG - 2011-09-18 13:55:37 --> Router Class Initialized
ERROR - 2011-09-18 13:55:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 13:56:07 --> Config Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:56:07 --> URI Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Router Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Output Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Input Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 13:56:07 --> Language Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Loader Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Controller Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Model Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Model Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Model Class Initialized
DEBUG - 2011-09-18 13:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 13:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-18 13:56:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 13:56:07 --> Helper loaded: url_helper
DEBUG - 2011-09-18 13:56:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 13:56:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 13:56:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 13:56:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 13:56:07 --> Final output sent to browser
DEBUG - 2011-09-18 13:56:07 --> Total execution time: 0.1216
DEBUG - 2011-09-18 13:56:08 --> Config Class Initialized
DEBUG - 2011-09-18 13:56:08 --> Hooks Class Initialized
DEBUG - 2011-09-18 13:56:08 --> Utf8 Class Initialized
DEBUG - 2011-09-18 13:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 13:56:08 --> URI Class Initialized
DEBUG - 2011-09-18 13:56:08 --> Router Class Initialized
ERROR - 2011-09-18 13:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 14:06:54 --> Config Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 14:06:54 --> URI Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Router Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Output Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Input Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 14:06:54 --> Language Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Loader Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Controller Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Model Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Model Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Model Class Initialized
DEBUG - 2011-09-18 14:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 14:06:54 --> Database Driver Class Initialized
DEBUG - 2011-09-18 14:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 14:06:54 --> Helper loaded: url_helper
DEBUG - 2011-09-18 14:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 14:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 14:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 14:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 14:06:54 --> Final output sent to browser
DEBUG - 2011-09-18 14:06:54 --> Total execution time: 0.0504
DEBUG - 2011-09-18 14:19:04 --> Config Class Initialized
DEBUG - 2011-09-18 14:19:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 14:19:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 14:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 14:19:04 --> URI Class Initialized
DEBUG - 2011-09-18 14:19:04 --> Router Class Initialized
ERROR - 2011-09-18 14:19:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 14:19:05 --> Config Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Hooks Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Utf8 Class Initialized
DEBUG - 2011-09-18 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 14:19:05 --> URI Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Router Class Initialized
DEBUG - 2011-09-18 14:19:05 --> No URI present. Default controller set.
DEBUG - 2011-09-18 14:19:05 --> Output Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Input Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 14:19:05 --> Language Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Loader Class Initialized
DEBUG - 2011-09-18 14:19:05 --> Controller Class Initialized
DEBUG - 2011-09-18 14:19:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 14:19:05 --> Helper loaded: url_helper
DEBUG - 2011-09-18 14:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 14:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 14:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 14:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 14:19:05 --> Final output sent to browser
DEBUG - 2011-09-18 14:19:05 --> Total execution time: 0.0900
DEBUG - 2011-09-18 15:34:31 --> Config Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:34:31 --> URI Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Router Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Output Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Input Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:34:31 --> Language Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Loader Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Controller Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:34:31 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:34:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:34:33 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:34:33 --> Final output sent to browser
DEBUG - 2011-09-18 15:34:33 --> Total execution time: 1.1845
DEBUG - 2011-09-18 15:34:33 --> Config Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:34:33 --> URI Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Router Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Config Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:34:33 --> URI Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Router Class Initialized
ERROR - 2011-09-18 15:34:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 15:34:33 --> Output Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Input Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:34:33 --> Language Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Loader Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Controller Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:34:33 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:34:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:34:34 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:34:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:34:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:34:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:34:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:34:34 --> Final output sent to browser
DEBUG - 2011-09-18 15:34:34 --> Total execution time: 0.2827
DEBUG - 2011-09-18 15:34:34 --> Config Class Initialized
DEBUG - 2011-09-18 15:34:34 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:34:34 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:34:34 --> URI Class Initialized
DEBUG - 2011-09-18 15:34:34 --> Router Class Initialized
ERROR - 2011-09-18 15:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 15:34:34 --> Config Class Initialized
DEBUG - 2011-09-18 15:34:34 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:34:34 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:34:34 --> URI Class Initialized
DEBUG - 2011-09-18 15:34:34 --> Router Class Initialized
ERROR - 2011-09-18 15:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 15:34:49 --> Config Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:34:49 --> URI Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Router Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Output Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Input Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:34:49 --> Language Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Loader Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Controller Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Model Class Initialized
DEBUG - 2011-09-18 15:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:34:49 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:34:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:34:49 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:34:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:34:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:34:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:34:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:34:49 --> Final output sent to browser
DEBUG - 2011-09-18 15:34:49 --> Total execution time: 0.3199
DEBUG - 2011-09-18 15:35:06 --> Config Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:35:06 --> URI Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Router Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Output Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Input Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:35:06 --> Language Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Loader Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Controller Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Model Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Model Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Model Class Initialized
DEBUG - 2011-09-18 15:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:35:06 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:35:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:35:06 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:35:06 --> Final output sent to browser
DEBUG - 2011-09-18 15:35:06 --> Total execution time: 0.0456
DEBUG - 2011-09-18 15:35:09 --> Config Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:35:09 --> URI Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Router Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Output Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Input Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:35:09 --> Language Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Loader Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Controller Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Model Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Model Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Model Class Initialized
DEBUG - 2011-09-18 15:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:35:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:35:09 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:35:09 --> Final output sent to browser
DEBUG - 2011-09-18 15:35:09 --> Total execution time: 0.1404
DEBUG - 2011-09-18 15:40:46 --> Config Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:40:46 --> URI Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Router Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Output Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Input Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:40:46 --> Language Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Loader Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Controller Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:40:46 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:40:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:40:46 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:40:46 --> Final output sent to browser
DEBUG - 2011-09-18 15:40:46 --> Total execution time: 0.7094
DEBUG - 2011-09-18 15:40:52 --> Config Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:40:52 --> URI Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Router Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Output Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Input Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:40:52 --> Language Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Loader Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Controller Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:40:52 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:40:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:40:52 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:40:52 --> Final output sent to browser
DEBUG - 2011-09-18 15:40:52 --> Total execution time: 0.0463
DEBUG - 2011-09-18 15:40:56 --> Config Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:40:56 --> URI Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Router Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Output Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Input Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:40:56 --> Language Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Loader Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Controller Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Model Class Initialized
DEBUG - 2011-09-18 15:40:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:40:56 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:40:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:40:56 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:40:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:40:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:40:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:40:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:40:56 --> Final output sent to browser
DEBUG - 2011-09-18 15:40:56 --> Total execution time: 0.5488
DEBUG - 2011-09-18 15:41:00 --> Config Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:41:00 --> URI Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Router Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Output Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Input Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:41:00 --> Language Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Loader Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Controller Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:41:00 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:41:00 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:41:00 --> Final output sent to browser
DEBUG - 2011-09-18 15:41:00 --> Total execution time: 0.0453
DEBUG - 2011-09-18 15:41:14 --> Config Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:41:14 --> URI Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Router Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Output Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Input Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:41:14 --> Language Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Loader Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Controller Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:41:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:41:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:41:14 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:41:14 --> Final output sent to browser
DEBUG - 2011-09-18 15:41:14 --> Total execution time: 0.4918
DEBUG - 2011-09-18 15:41:15 --> Config Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:41:15 --> URI Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Router Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Output Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Input Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:41:15 --> Language Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Loader Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Controller Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:41:15 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:41:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:41:15 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:41:15 --> Final output sent to browser
DEBUG - 2011-09-18 15:41:15 --> Total execution time: 0.0485
DEBUG - 2011-09-18 15:41:49 --> Config Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:41:49 --> URI Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Router Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Output Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Input Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:41:49 --> Language Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Loader Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Controller Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:41:49 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:41:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:41:50 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:41:50 --> Final output sent to browser
DEBUG - 2011-09-18 15:41:50 --> Total execution time: 0.5868
DEBUG - 2011-09-18 15:41:52 --> Config Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:41:52 --> URI Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Router Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Output Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Input Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:41:52 --> Language Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Loader Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Controller Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Model Class Initialized
DEBUG - 2011-09-18 15:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:41:52 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:41:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:41:52 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:41:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:41:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:41:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:41:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:41:52 --> Final output sent to browser
DEBUG - 2011-09-18 15:41:52 --> Total execution time: 0.0532
DEBUG - 2011-09-18 15:42:14 --> Config Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:42:14 --> URI Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Router Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Output Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Input Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:42:14 --> Language Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Loader Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Controller Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:42:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:42:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:42:14 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:42:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:42:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:42:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:42:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:42:14 --> Final output sent to browser
DEBUG - 2011-09-18 15:42:14 --> Total execution time: 0.2970
DEBUG - 2011-09-18 15:42:17 --> Config Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:42:17 --> URI Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Router Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Output Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Input Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:42:17 --> Language Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Loader Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Controller Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:42:17 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:42:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:42:17 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:42:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:42:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:42:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:42:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:42:17 --> Final output sent to browser
DEBUG - 2011-09-18 15:42:17 --> Total execution time: 0.0469
DEBUG - 2011-09-18 15:42:38 --> Config Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:42:38 --> URI Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Router Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Output Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Input Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:42:38 --> Language Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Loader Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Controller Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:42:38 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:42:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:42:38 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:42:38 --> Final output sent to browser
DEBUG - 2011-09-18 15:42:38 --> Total execution time: 0.3156
DEBUG - 2011-09-18 15:42:39 --> Config Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:42:39 --> URI Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Router Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Output Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Input Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:42:39 --> Language Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Loader Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Controller Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Model Class Initialized
DEBUG - 2011-09-18 15:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:42:39 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:42:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:42:39 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:42:39 --> Final output sent to browser
DEBUG - 2011-09-18 15:42:39 --> Total execution time: 0.0461
DEBUG - 2011-09-18 15:43:01 --> Config Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:43:01 --> URI Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Router Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Output Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Input Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:43:01 --> Language Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Loader Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Controller Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:43:01 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:43:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:43:02 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:43:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:43:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:43:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:43:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:43:02 --> Final output sent to browser
DEBUG - 2011-09-18 15:43:02 --> Total execution time: 0.4848
DEBUG - 2011-09-18 15:43:04 --> Config Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:43:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:43:04 --> URI Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Router Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Output Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Input Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:43:04 --> Language Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Loader Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Controller Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:43:04 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:43:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:43:04 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:43:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:43:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:43:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:43:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:43:04 --> Final output sent to browser
DEBUG - 2011-09-18 15:43:04 --> Total execution time: 0.0538
DEBUG - 2011-09-18 15:43:30 --> Config Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:43:30 --> URI Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Router Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Output Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Input Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:43:30 --> Language Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Loader Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Controller Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:43:30 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:43:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:43:30 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:43:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:43:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:43:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:43:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:43:30 --> Final output sent to browser
DEBUG - 2011-09-18 15:43:30 --> Total execution time: 0.2332
DEBUG - 2011-09-18 15:43:39 --> Config Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Hooks Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Utf8 Class Initialized
DEBUG - 2011-09-18 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 15:43:39 --> URI Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Router Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Output Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Input Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 15:43:39 --> Language Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Loader Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Controller Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Model Class Initialized
DEBUG - 2011-09-18 15:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 15:43:39 --> Database Driver Class Initialized
DEBUG - 2011-09-18 15:43:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 15:43:39 --> Helper loaded: url_helper
DEBUG - 2011-09-18 15:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 15:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 15:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 15:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 15:43:39 --> Final output sent to browser
DEBUG - 2011-09-18 15:43:39 --> Total execution time: 0.0648
DEBUG - 2011-09-18 16:09:54 --> Config Class Initialized
DEBUG - 2011-09-18 16:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 16:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 16:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 16:09:54 --> URI Class Initialized
DEBUG - 2011-09-18 16:09:54 --> Router Class Initialized
DEBUG - 2011-09-18 16:09:54 --> No URI present. Default controller set.
DEBUG - 2011-09-18 16:09:54 --> Output Class Initialized
DEBUG - 2011-09-18 16:09:54 --> Input Class Initialized
DEBUG - 2011-09-18 16:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 16:09:54 --> Language Class Initialized
DEBUG - 2011-09-18 16:09:55 --> Loader Class Initialized
DEBUG - 2011-09-18 16:09:55 --> Controller Class Initialized
DEBUG - 2011-09-18 16:09:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 16:09:55 --> Helper loaded: url_helper
DEBUG - 2011-09-18 16:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 16:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 16:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 16:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 16:09:55 --> Final output sent to browser
DEBUG - 2011-09-18 16:09:55 --> Total execution time: 0.1385
DEBUG - 2011-09-18 17:08:53 --> Config Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Hooks Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Utf8 Class Initialized
DEBUG - 2011-09-18 17:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 17:08:53 --> URI Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Router Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Output Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Input Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 17:08:53 --> Language Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Loader Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Controller Class Initialized
ERROR - 2011-09-18 17:08:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 17:08:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 17:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 17:08:53 --> Model Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Model Class Initialized
DEBUG - 2011-09-18 17:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 17:08:53 --> Database Driver Class Initialized
DEBUG - 2011-09-18 17:08:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 17:08:54 --> Helper loaded: url_helper
DEBUG - 2011-09-18 17:08:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 17:08:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 17:08:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 17:08:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 17:08:54 --> Final output sent to browser
DEBUG - 2011-09-18 17:08:54 --> Total execution time: 0.4115
DEBUG - 2011-09-18 17:09:00 --> Config Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Hooks Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Utf8 Class Initialized
DEBUG - 2011-09-18 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 17:09:00 --> URI Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Router Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Output Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Input Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 17:09:00 --> Language Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Loader Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Controller Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Model Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Model Class Initialized
DEBUG - 2011-09-18 17:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 17:09:00 --> Database Driver Class Initialized
DEBUG - 2011-09-18 17:09:02 --> Final output sent to browser
DEBUG - 2011-09-18 17:09:02 --> Total execution time: 1.8573
DEBUG - 2011-09-18 17:09:07 --> Config Class Initialized
DEBUG - 2011-09-18 17:09:07 --> Hooks Class Initialized
DEBUG - 2011-09-18 17:09:07 --> Utf8 Class Initialized
DEBUG - 2011-09-18 17:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 17:09:07 --> URI Class Initialized
DEBUG - 2011-09-18 17:09:07 --> Router Class Initialized
ERROR - 2011-09-18 17:09:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 18:01:47 --> Config Class Initialized
DEBUG - 2011-09-18 18:01:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:01:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:01:47 --> URI Class Initialized
DEBUG - 2011-09-18 18:01:47 --> Router Class Initialized
ERROR - 2011-09-18 18:01:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-18 18:01:48 --> Config Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:01:48 --> URI Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Router Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Output Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Input Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 18:01:48 --> Language Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Loader Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Controller Class Initialized
ERROR - 2011-09-18 18:01:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 18:01:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 18:01:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 18:01:48 --> Model Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Model Class Initialized
DEBUG - 2011-09-18 18:01:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 18:01:48 --> Database Driver Class Initialized
DEBUG - 2011-09-18 18:01:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 18:01:48 --> Helper loaded: url_helper
DEBUG - 2011-09-18 18:01:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 18:01:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 18:01:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 18:01:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 18:01:48 --> Final output sent to browser
DEBUG - 2011-09-18 18:01:48 --> Total execution time: 0.0648
DEBUG - 2011-09-18 18:02:49 --> Config Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:02:49 --> URI Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Router Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Output Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Input Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 18:02:49 --> Language Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Loader Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Controller Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Model Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Model Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Model Class Initialized
DEBUG - 2011-09-18 18:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 18:02:49 --> Database Driver Class Initialized
DEBUG - 2011-09-18 18:02:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 18:02:50 --> Helper loaded: url_helper
DEBUG - 2011-09-18 18:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 18:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 18:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 18:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 18:02:50 --> Final output sent to browser
DEBUG - 2011-09-18 18:02:50 --> Total execution time: 0.5381
DEBUG - 2011-09-18 18:29:54 --> Config Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:29:54 --> URI Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Router Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Output Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Input Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 18:29:54 --> Language Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Loader Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Controller Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Model Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Model Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Model Class Initialized
DEBUG - 2011-09-18 18:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 18:29:54 --> Database Driver Class Initialized
DEBUG - 2011-09-18 18:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 18:29:55 --> Helper loaded: url_helper
DEBUG - 2011-09-18 18:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 18:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 18:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 18:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 18:29:55 --> Final output sent to browser
DEBUG - 2011-09-18 18:29:55 --> Total execution time: 0.3758
DEBUG - 2011-09-18 18:40:23 --> Config Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:40:23 --> URI Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Router Class Initialized
DEBUG - 2011-09-18 18:40:23 --> No URI present. Default controller set.
DEBUG - 2011-09-18 18:40:23 --> Output Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Input Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 18:40:23 --> Language Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Loader Class Initialized
DEBUG - 2011-09-18 18:40:23 --> Controller Class Initialized
DEBUG - 2011-09-18 18:40:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 18:40:23 --> Helper loaded: url_helper
DEBUG - 2011-09-18 18:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 18:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 18:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 18:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 18:40:23 --> Final output sent to browser
DEBUG - 2011-09-18 18:40:23 --> Total execution time: 0.3771
DEBUG - 2011-09-18 18:52:12 --> Config Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:52:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:52:12 --> URI Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Router Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Output Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Input Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 18:52:12 --> Language Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Loader Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Controller Class Initialized
ERROR - 2011-09-18 18:52:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 18:52:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 18:52:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 18:52:12 --> Model Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Model Class Initialized
DEBUG - 2011-09-18 18:52:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 18:52:12 --> Database Driver Class Initialized
DEBUG - 2011-09-18 18:52:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 18:52:13 --> Helper loaded: url_helper
DEBUG - 2011-09-18 18:52:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 18:52:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 18:52:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 18:52:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 18:52:13 --> Final output sent to browser
DEBUG - 2011-09-18 18:52:13 --> Total execution time: 0.3725
DEBUG - 2011-09-18 18:52:14 --> Config Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:52:14 --> URI Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Router Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Output Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Input Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 18:52:14 --> Language Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Loader Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Controller Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Model Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Model Class Initialized
DEBUG - 2011-09-18 18:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 18:52:14 --> Database Driver Class Initialized
DEBUG - 2011-09-18 18:52:15 --> Final output sent to browser
DEBUG - 2011-09-18 18:52:15 --> Total execution time: 0.8124
DEBUG - 2011-09-18 18:52:16 --> Config Class Initialized
DEBUG - 2011-09-18 18:52:16 --> Hooks Class Initialized
DEBUG - 2011-09-18 18:52:16 --> Utf8 Class Initialized
DEBUG - 2011-09-18 18:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 18:52:16 --> URI Class Initialized
DEBUG - 2011-09-18 18:52:16 --> Router Class Initialized
ERROR - 2011-09-18 18:52:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 20:20:47 --> Config Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-18 20:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 20:20:47 --> URI Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Router Class Initialized
DEBUG - 2011-09-18 20:20:47 --> No URI present. Default controller set.
DEBUG - 2011-09-18 20:20:47 --> Output Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Input Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 20:20:47 --> Language Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Loader Class Initialized
DEBUG - 2011-09-18 20:20:47 --> Controller Class Initialized
DEBUG - 2011-09-18 20:20:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-18 20:20:47 --> Helper loaded: url_helper
DEBUG - 2011-09-18 20:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 20:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 20:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 20:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 20:20:47 --> Final output sent to browser
DEBUG - 2011-09-18 20:20:47 --> Total execution time: 0.0800
DEBUG - 2011-09-18 20:27:12 --> Config Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Hooks Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Utf8 Class Initialized
DEBUG - 2011-09-18 20:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 20:27:12 --> URI Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Router Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Output Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Input Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 20:27:12 --> Language Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Loader Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Controller Class Initialized
ERROR - 2011-09-18 20:27:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 20:27:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 20:27:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 20:27:12 --> Model Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Model Class Initialized
DEBUG - 2011-09-18 20:27:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 20:27:12 --> Database Driver Class Initialized
DEBUG - 2011-09-18 20:27:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 20:27:12 --> Helper loaded: url_helper
DEBUG - 2011-09-18 20:27:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 20:27:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 20:27:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 20:27:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 20:27:12 --> Final output sent to browser
DEBUG - 2011-09-18 20:27:12 --> Total execution time: 0.3520
DEBUG - 2011-09-18 20:28:51 --> Config Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 20:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 20:28:51 --> URI Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Router Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Output Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Input Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 20:28:51 --> Language Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Loader Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Controller Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Model Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Model Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Model Class Initialized
DEBUG - 2011-09-18 20:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 20:28:51 --> Database Driver Class Initialized
DEBUG - 2011-09-18 20:28:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 20:28:51 --> Helper loaded: url_helper
DEBUG - 2011-09-18 20:28:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 20:28:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 20:28:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 20:28:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 20:28:51 --> Final output sent to browser
DEBUG - 2011-09-18 20:28:51 --> Total execution time: 0.5403
DEBUG - 2011-09-18 22:26:51 --> Config Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Hooks Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Utf8 Class Initialized
DEBUG - 2011-09-18 22:26:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 22:26:51 --> URI Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Router Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Output Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Input Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 22:26:51 --> Language Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Loader Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Controller Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Model Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Model Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Model Class Initialized
DEBUG - 2011-09-18 22:26:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 22:26:51 --> Database Driver Class Initialized
DEBUG - 2011-09-18 22:26:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 22:26:53 --> Helper loaded: url_helper
DEBUG - 2011-09-18 22:26:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 22:26:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 22:26:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 22:26:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 22:26:53 --> Final output sent to browser
DEBUG - 2011-09-18 22:26:53 --> Total execution time: 1.1798
DEBUG - 2011-09-18 22:26:54 --> Config Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Hooks Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Utf8 Class Initialized
DEBUG - 2011-09-18 22:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 22:26:54 --> URI Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Router Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Output Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Input Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 22:26:54 --> Language Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Loader Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Controller Class Initialized
ERROR - 2011-09-18 22:26:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-18 22:26:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-18 22:26:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 22:26:54 --> Model Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Model Class Initialized
DEBUG - 2011-09-18 22:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 22:26:54 --> Database Driver Class Initialized
DEBUG - 2011-09-18 22:26:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-18 22:26:54 --> Helper loaded: url_helper
DEBUG - 2011-09-18 22:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 22:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 22:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 22:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 22:26:54 --> Final output sent to browser
DEBUG - 2011-09-18 22:26:54 --> Total execution time: 0.0622
DEBUG - 2011-09-18 23:41:00 --> Config Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Hooks Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Utf8 Class Initialized
DEBUG - 2011-09-18 23:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 23:41:00 --> URI Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Router Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Output Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Input Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-18 23:41:00 --> Language Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Loader Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Controller Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Model Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Model Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Model Class Initialized
DEBUG - 2011-09-18 23:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-18 23:41:00 --> Database Driver Class Initialized
DEBUG - 2011-09-18 23:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-18 23:41:00 --> Helper loaded: url_helper
DEBUG - 2011-09-18 23:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-18 23:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-18 23:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-18 23:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-18 23:41:00 --> Final output sent to browser
DEBUG - 2011-09-18 23:41:00 --> Total execution time: 0.2503
DEBUG - 2011-09-18 23:41:02 --> Config Class Initialized
DEBUG - 2011-09-18 23:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-18 23:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-18 23:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 23:41:02 --> URI Class Initialized
DEBUG - 2011-09-18 23:41:02 --> Router Class Initialized
ERROR - 2011-09-18 23:41:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 23:41:02 --> Config Class Initialized
DEBUG - 2011-09-18 23:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-18 23:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-18 23:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 23:41:02 --> URI Class Initialized
DEBUG - 2011-09-18 23:41:02 --> Router Class Initialized
ERROR - 2011-09-18 23:41:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-18 23:41:03 --> Config Class Initialized
DEBUG - 2011-09-18 23:41:03 --> Hooks Class Initialized
DEBUG - 2011-09-18 23:41:03 --> Utf8 Class Initialized
DEBUG - 2011-09-18 23:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-18 23:41:03 --> URI Class Initialized
DEBUG - 2011-09-18 23:41:03 --> Router Class Initialized
ERROR - 2011-09-18 23:41:03 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-06 00:29:24 --> Config Class Initialized
DEBUG - 2011-07-06 00:29:24 --> Hooks Class Initialized
DEBUG - 2011-07-06 00:29:24 --> Utf8 Class Initialized
DEBUG - 2011-07-06 00:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 00:29:24 --> URI Class Initialized
DEBUG - 2011-07-06 00:29:24 --> Router Class Initialized
ERROR - 2011-07-06 00:29:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-06 02:36:13 --> Config Class Initialized
DEBUG - 2011-07-06 02:36:13 --> Hooks Class Initialized
DEBUG - 2011-07-06 02:36:13 --> Utf8 Class Initialized
DEBUG - 2011-07-06 02:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 02:36:13 --> URI Class Initialized
DEBUG - 2011-07-06 02:36:13 --> Router Class Initialized
ERROR - 2011-07-06 02:36:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-06 02:36:14 --> Config Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Hooks Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Utf8 Class Initialized
DEBUG - 2011-07-06 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 02:36:14 --> URI Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Router Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Output Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Input Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 02:36:14 --> Language Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Loader Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Controller Class Initialized
ERROR - 2011-07-06 02:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 02:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 02:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 02:36:14 --> Model Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Model Class Initialized
DEBUG - 2011-07-06 02:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 02:36:14 --> Database Driver Class Initialized
DEBUG - 2011-07-06 02:36:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 02:36:15 --> Helper loaded: url_helper
DEBUG - 2011-07-06 02:36:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 02:36:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 02:36:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 02:36:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 02:36:15 --> Final output sent to browser
DEBUG - 2011-07-06 02:36:15 --> Total execution time: 1.2150
DEBUG - 2011-07-06 03:56:02 --> Config Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Hooks Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Utf8 Class Initialized
DEBUG - 2011-07-06 03:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 03:56:02 --> URI Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Router Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Output Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Input Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 03:56:02 --> Language Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Loader Class Initialized
DEBUG - 2011-07-06 03:56:02 --> Controller Class Initialized
ERROR - 2011-07-06 03:56:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 03:56:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 03:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 03:56:02 --> Model Class Initialized
DEBUG - 2011-07-06 03:56:03 --> Model Class Initialized
DEBUG - 2011-07-06 03:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 03:56:03 --> Database Driver Class Initialized
DEBUG - 2011-07-06 03:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 03:56:03 --> Helper loaded: url_helper
DEBUG - 2011-07-06 03:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 03:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 03:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 03:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 03:56:03 --> Final output sent to browser
DEBUG - 2011-07-06 03:56:03 --> Total execution time: 0.7005
DEBUG - 2011-07-06 03:56:08 --> Config Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Hooks Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Utf8 Class Initialized
DEBUG - 2011-07-06 03:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 03:56:08 --> URI Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Router Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Output Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Input Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 03:56:08 --> Language Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Loader Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Controller Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Model Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Model Class Initialized
DEBUG - 2011-07-06 03:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 03:56:08 --> Database Driver Class Initialized
DEBUG - 2011-07-06 03:56:09 --> Final output sent to browser
DEBUG - 2011-07-06 03:56:09 --> Total execution time: 1.0812
DEBUG - 2011-07-06 04:52:05 --> Config Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Hooks Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Utf8 Class Initialized
DEBUG - 2011-07-06 04:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 04:52:05 --> URI Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Router Class Initialized
DEBUG - 2011-07-06 04:52:05 --> No URI present. Default controller set.
DEBUG - 2011-07-06 04:52:05 --> Output Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Input Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 04:52:05 --> Language Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Loader Class Initialized
DEBUG - 2011-07-06 04:52:05 --> Controller Class Initialized
DEBUG - 2011-07-06 04:52:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-06 04:52:05 --> Helper loaded: url_helper
DEBUG - 2011-07-06 04:52:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 04:52:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 04:52:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 04:52:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 04:52:05 --> Final output sent to browser
DEBUG - 2011-07-06 04:52:05 --> Total execution time: 0.3022
DEBUG - 2011-07-06 11:50:06 --> Config Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Hooks Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Utf8 Class Initialized
DEBUG - 2011-07-06 11:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 11:50:06 --> URI Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Router Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Output Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Input Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 11:50:06 --> Language Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Loader Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Controller Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Model Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Model Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Model Class Initialized
DEBUG - 2011-07-06 11:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 11:50:06 --> Database Driver Class Initialized
DEBUG - 2011-07-06 11:50:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 11:50:08 --> Helper loaded: url_helper
DEBUG - 2011-07-06 11:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 11:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 11:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 11:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 11:50:08 --> Final output sent to browser
DEBUG - 2011-07-06 11:50:08 --> Total execution time: 2.4485
DEBUG - 2011-07-06 11:52:12 --> Config Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Hooks Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Utf8 Class Initialized
DEBUG - 2011-07-06 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 11:52:12 --> URI Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Router Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Output Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Input Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 11:52:12 --> Language Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Loader Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Controller Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Model Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Model Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Model Class Initialized
DEBUG - 2011-07-06 11:52:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 11:52:12 --> Database Driver Class Initialized
DEBUG - 2011-07-06 11:52:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 11:52:12 --> Helper loaded: url_helper
DEBUG - 2011-07-06 11:52:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 11:52:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 11:52:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 11:52:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 11:52:12 --> Final output sent to browser
DEBUG - 2011-07-06 11:52:12 --> Total execution time: 0.0964
DEBUG - 2011-07-06 11:52:14 --> Config Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Hooks Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Utf8 Class Initialized
DEBUG - 2011-07-06 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 11:52:14 --> URI Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Router Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Output Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Input Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 11:52:14 --> Language Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Loader Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Controller Class Initialized
ERROR - 2011-07-06 11:52:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 11:52:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 11:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 11:52:14 --> Model Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Model Class Initialized
DEBUG - 2011-07-06 11:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 11:52:14 --> Database Driver Class Initialized
DEBUG - 2011-07-06 11:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 11:52:14 --> Helper loaded: url_helper
DEBUG - 2011-07-06 11:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 11:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 11:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 11:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 11:52:14 --> Final output sent to browser
DEBUG - 2011-07-06 11:52:14 --> Total execution time: 0.1048
DEBUG - 2011-07-06 13:42:02 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:02 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:02 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:02 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:03 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:03 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:03 --> Total execution time: 0.9659
DEBUG - 2011-07-06 13:42:05 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:05 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:05 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:05 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:05 --> Router Class Initialized
ERROR - 2011-07-06 13:42:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:42:06 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:06 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Router Class Initialized
ERROR - 2011-07-06 13:42:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-06 13:42:06 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:06 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:06 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:06 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:06 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:06 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:06 --> Total execution time: 0.0577
DEBUG - 2011-07-06 13:42:27 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:27 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:27 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:27 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:28 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:28 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:28 --> Total execution time: 0.8991
DEBUG - 2011-07-06 13:42:29 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:29 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:29 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:29 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:29 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:29 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:29 --> Total execution time: 0.1101
DEBUG - 2011-07-06 13:42:29 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:29 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:29 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:29 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:29 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:29 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:29 --> Total execution time: 0.0549
DEBUG - 2011-07-06 13:42:29 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:29 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:29 --> Router Class Initialized
ERROR - 2011-07-06 13:42:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:42:40 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:40 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:40 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:40 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:41 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:41 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:41 --> Total execution time: 0.3793
DEBUG - 2011-07-06 13:42:42 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:42 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:42 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:42 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:42 --> Router Class Initialized
ERROR - 2011-07-06 13:42:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:42:43 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:43 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:43 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:43 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:43 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:43 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:43 --> Total execution time: 0.0500
DEBUG - 2011-07-06 13:42:58 --> Config Class Initialized
DEBUG - 2011-07-06 13:42:58 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:42:58 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:42:58 --> URI Class Initialized
DEBUG - 2011-07-06 13:42:58 --> Router Class Initialized
DEBUG - 2011-07-06 13:42:58 --> Output Class Initialized
DEBUG - 2011-07-06 13:42:58 --> Input Class Initialized
DEBUG - 2011-07-06 13:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:42:58 --> Language Class Initialized
DEBUG - 2011-07-06 13:42:59 --> Loader Class Initialized
DEBUG - 2011-07-06 13:42:59 --> Controller Class Initialized
DEBUG - 2011-07-06 13:42:59 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:59 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:59 --> Model Class Initialized
DEBUG - 2011-07-06 13:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:42:59 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:42:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:42:59 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:42:59 --> Final output sent to browser
DEBUG - 2011-07-06 13:42:59 --> Total execution time: 0.5470
DEBUG - 2011-07-06 13:43:00 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:00 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Router Class Initialized
ERROR - 2011-07-06 13:43:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:43:00 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:00 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Router Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Output Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Input Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:43:00 --> Language Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Loader Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Controller Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:43:01 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:43:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:43:01 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:43:01 --> Final output sent to browser
DEBUG - 2011-07-06 13:43:01 --> Total execution time: 0.0469
DEBUG - 2011-07-06 13:43:15 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:15 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Router Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Output Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Input Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:43:15 --> Language Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Loader Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Controller Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:43:15 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:43:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:43:15 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:43:15 --> Final output sent to browser
DEBUG - 2011-07-06 13:43:15 --> Total execution time: 0.3455
DEBUG - 2011-07-06 13:43:16 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:16 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:16 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:16 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:16 --> Router Class Initialized
ERROR - 2011-07-06 13:43:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:43:19 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:19 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Router Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Output Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Input Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:43:19 --> Language Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Loader Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Controller Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:43:19 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:43:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:43:19 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:43:19 --> Final output sent to browser
DEBUG - 2011-07-06 13:43:19 --> Total execution time: 0.0428
DEBUG - 2011-07-06 13:43:24 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:24 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Router Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Output Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Input Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:43:24 --> Language Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Loader Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Controller Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:43:24 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:43:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:43:25 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:43:25 --> Final output sent to browser
DEBUG - 2011-07-06 13:43:25 --> Total execution time: 0.3335
DEBUG - 2011-07-06 13:43:26 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:26 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:26 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:26 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:26 --> Router Class Initialized
ERROR - 2011-07-06 13:43:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:43:27 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:27 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Router Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Output Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Input Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:43:27 --> Language Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Loader Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Controller Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:43:27 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:43:27 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:43:27 --> Final output sent to browser
DEBUG - 2011-07-06 13:43:27 --> Total execution time: 0.0459
DEBUG - 2011-07-06 13:43:56 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:56 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Router Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Output Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Input Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:43:56 --> Language Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Loader Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Controller Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Model Class Initialized
DEBUG - 2011-07-06 13:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:43:56 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:43:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:43:56 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:43:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:43:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:43:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:43:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:43:56 --> Final output sent to browser
DEBUG - 2011-07-06 13:43:56 --> Total execution time: 0.0543
DEBUG - 2011-07-06 13:43:57 --> Config Class Initialized
DEBUG - 2011-07-06 13:43:57 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:43:57 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:43:57 --> URI Class Initialized
DEBUG - 2011-07-06 13:43:57 --> Router Class Initialized
ERROR - 2011-07-06 13:43:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:44:19 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:19 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Router Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Output Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Input Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:44:19 --> Language Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Loader Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Controller Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:44:19 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:44:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:44:20 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:44:20 --> Final output sent to browser
DEBUG - 2011-07-06 13:44:20 --> Total execution time: 0.3208
DEBUG - 2011-07-06 13:44:21 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:21 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Router Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Output Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Input Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:44:21 --> Language Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Loader Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Controller Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:44:21 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 13:44:21 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:44:21 --> Final output sent to browser
DEBUG - 2011-07-06 13:44:21 --> Total execution time: 0.0717
DEBUG - 2011-07-06 13:44:21 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:21 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:21 --> Router Class Initialized
ERROR - 2011-07-06 13:44:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:44:43 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:43 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Router Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Output Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Input Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:44:43 --> Language Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Loader Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Controller Class Initialized
ERROR - 2011-07-06 13:44:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 13:44:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 13:44:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:44:43 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:44:43 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:44:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:44:43 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:44:43 --> Final output sent to browser
DEBUG - 2011-07-06 13:44:43 --> Total execution time: 0.0891
DEBUG - 2011-07-06 13:44:44 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:44 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Router Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Output Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Input Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:44:44 --> Language Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Loader Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Controller Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:44:44 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:45 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Router Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Output Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Input Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:44:45 --> Language Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Loader Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Controller Class Initialized
ERROR - 2011-07-06 13:44:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 13:44:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 13:44:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:44:45 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Model Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:44:45 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:44:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:44:45 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:44:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:44:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:44:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:44:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:44:45 --> Final output sent to browser
DEBUG - 2011-07-06 13:44:45 --> Total execution time: 0.0282
DEBUG - 2011-07-06 13:44:45 --> Final output sent to browser
DEBUG - 2011-07-06 13:44:45 --> Total execution time: 0.7094
DEBUG - 2011-07-06 13:44:45 --> Config Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:44:45 --> URI Class Initialized
DEBUG - 2011-07-06 13:44:45 --> Router Class Initialized
ERROR - 2011-07-06 13:44:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:45:12 --> Config Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:45:12 --> URI Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Router Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Output Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Input Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:45:12 --> Language Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Loader Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Controller Class Initialized
ERROR - 2011-07-06 13:45:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 13:45:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 13:45:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:45:12 --> Model Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Model Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:45:12 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:45:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:45:12 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:45:12 --> Final output sent to browser
DEBUG - 2011-07-06 13:45:12 --> Total execution time: 0.0301
DEBUG - 2011-07-06 13:45:12 --> Config Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:45:12 --> URI Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Router Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Output Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Input Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:45:12 --> Language Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Loader Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Controller Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Model Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Model Class Initialized
DEBUG - 2011-07-06 13:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:45:12 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:45:13 --> Final output sent to browser
DEBUG - 2011-07-06 13:45:13 --> Total execution time: 0.8945
DEBUG - 2011-07-06 13:45:14 --> Config Class Initialized
DEBUG - 2011-07-06 13:45:14 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:45:14 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:45:14 --> URI Class Initialized
DEBUG - 2011-07-06 13:45:14 --> Router Class Initialized
ERROR - 2011-07-06 13:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 13:45:15 --> Config Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Hooks Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Utf8 Class Initialized
DEBUG - 2011-07-06 13:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 13:45:15 --> URI Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Router Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Output Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Input Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 13:45:15 --> Language Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Loader Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Controller Class Initialized
ERROR - 2011-07-06 13:45:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 13:45:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 13:45:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:45:15 --> Model Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Model Class Initialized
DEBUG - 2011-07-06 13:45:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 13:45:15 --> Database Driver Class Initialized
DEBUG - 2011-07-06 13:45:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 13:45:15 --> Helper loaded: url_helper
DEBUG - 2011-07-06 13:45:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 13:45:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 13:45:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 13:45:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 13:45:15 --> Final output sent to browser
DEBUG - 2011-07-06 13:45:15 --> Total execution time: 0.0327
DEBUG - 2011-07-06 14:24:39 --> Config Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:24:39 --> URI Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Router Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Output Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Input Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:24:39 --> Language Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Loader Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Controller Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Model Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Model Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Model Class Initialized
DEBUG - 2011-07-06 14:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:24:39 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:24:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 14:24:39 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:24:39 --> Final output sent to browser
DEBUG - 2011-07-06 14:24:39 --> Total execution time: 0.7021
DEBUG - 2011-07-06 14:24:42 --> Config Class Initialized
DEBUG - 2011-07-06 14:24:42 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:24:42 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:24:42 --> URI Class Initialized
DEBUG - 2011-07-06 14:24:42 --> Router Class Initialized
ERROR - 2011-07-06 14:24:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 14:24:43 --> Config Class Initialized
DEBUG - 2011-07-06 14:24:43 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:24:43 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:24:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:24:43 --> URI Class Initialized
DEBUG - 2011-07-06 14:24:43 --> Router Class Initialized
ERROR - 2011-07-06 14:24:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 14:25:06 --> Config Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:25:06 --> URI Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Router Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Output Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Input Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:25:06 --> Language Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Loader Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Controller Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:25:06 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:25:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 14:25:07 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:25:07 --> Final output sent to browser
DEBUG - 2011-07-06 14:25:07 --> Total execution time: 0.3638
DEBUG - 2011-07-06 14:25:08 --> Config Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:25:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:25:08 --> URI Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Router Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Output Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Input Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:25:08 --> Language Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Loader Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Controller Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:25:08 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:25:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 14:25:08 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:25:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:25:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:25:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:25:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:25:08 --> Final output sent to browser
DEBUG - 2011-07-06 14:25:08 --> Total execution time: 0.0602
DEBUG - 2011-07-06 14:25:25 --> Config Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:25:25 --> URI Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Router Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Output Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Input Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:25:25 --> Language Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Loader Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Controller Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:25:25 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:25:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 14:25:26 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:25:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:25:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:25:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:25:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:25:26 --> Final output sent to browser
DEBUG - 2011-07-06 14:25:26 --> Total execution time: 0.7396
DEBUG - 2011-07-06 14:25:27 --> Config Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:25:27 --> URI Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Router Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Output Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Input Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:25:27 --> Language Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Loader Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Controller Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:25:27 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:25:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 14:25:27 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:25:28 --> Final output sent to browser
DEBUG - 2011-07-06 14:25:28 --> Total execution time: 0.0761
DEBUG - 2011-07-06 14:25:30 --> Config Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:25:30 --> URI Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Router Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Output Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Input Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:25:30 --> Language Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Loader Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Controller Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Model Class Initialized
DEBUG - 2011-07-06 14:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:25:30 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:25:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 14:25:30 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:25:30 --> Final output sent to browser
DEBUG - 2011-07-06 14:25:30 --> Total execution time: 0.0514
DEBUG - 2011-07-06 14:26:11 --> Config Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:26:11 --> URI Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Router Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Output Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Input Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:26:11 --> Language Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Loader Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Controller Class Initialized
ERROR - 2011-07-06 14:26:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 14:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 14:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 14:26:11 --> Model Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Model Class Initialized
DEBUG - 2011-07-06 14:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:26:11 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 14:26:11 --> Helper loaded: url_helper
DEBUG - 2011-07-06 14:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 14:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 14:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 14:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 14:26:11 --> Final output sent to browser
DEBUG - 2011-07-06 14:26:11 --> Total execution time: 0.1169
DEBUG - 2011-07-06 14:26:12 --> Config Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Hooks Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Utf8 Class Initialized
DEBUG - 2011-07-06 14:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 14:26:12 --> URI Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Router Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Output Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Input Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 14:26:12 --> Language Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Loader Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Controller Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Model Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Model Class Initialized
DEBUG - 2011-07-06 14:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 14:26:12 --> Database Driver Class Initialized
DEBUG - 2011-07-06 14:26:13 --> Final output sent to browser
DEBUG - 2011-07-06 14:26:13 --> Total execution time: 0.7859
DEBUG - 2011-07-06 15:47:39 --> Config Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Hooks Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Utf8 Class Initialized
DEBUG - 2011-07-06 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 15:47:39 --> URI Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Router Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Output Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Input Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 15:47:39 --> Language Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Loader Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Controller Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Model Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Model Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Model Class Initialized
DEBUG - 2011-07-06 15:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 15:47:39 --> Database Driver Class Initialized
DEBUG - 2011-07-06 15:47:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 15:47:40 --> Helper loaded: url_helper
DEBUG - 2011-07-06 15:47:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 15:47:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 15:47:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 15:47:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 15:47:40 --> Final output sent to browser
DEBUG - 2011-07-06 15:47:40 --> Total execution time: 0.5568
DEBUG - 2011-07-06 15:48:10 --> Config Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Hooks Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Utf8 Class Initialized
DEBUG - 2011-07-06 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 15:48:10 --> URI Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Router Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Output Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Input Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 15:48:10 --> Language Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Loader Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Controller Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Model Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Model Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Model Class Initialized
DEBUG - 2011-07-06 15:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 15:48:10 --> Database Driver Class Initialized
DEBUG - 2011-07-06 15:48:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 15:48:10 --> Helper loaded: url_helper
DEBUG - 2011-07-06 15:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 15:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 15:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 15:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 15:48:10 --> Final output sent to browser
DEBUG - 2011-07-06 15:48:10 --> Total execution time: 0.1828
DEBUG - 2011-07-06 18:12:54 --> Config Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:12:54 --> URI Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Router Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Output Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Input Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 18:12:54 --> Language Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Loader Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Controller Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Model Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Model Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Model Class Initialized
DEBUG - 2011-07-06 18:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 18:12:54 --> Database Driver Class Initialized
DEBUG - 2011-07-06 18:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 18:12:54 --> Helper loaded: url_helper
DEBUG - 2011-07-06 18:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 18:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 18:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 18:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 18:12:54 --> Final output sent to browser
DEBUG - 2011-07-06 18:12:54 --> Total execution time: 0.7235
DEBUG - 2011-07-06 18:12:57 --> Config Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:12:57 --> URI Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Router Class Initialized
ERROR - 2011-07-06 18:12:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 18:12:57 --> Config Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:12:57 --> URI Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Router Class Initialized
ERROR - 2011-07-06 18:12:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 18:12:57 --> Config Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:12:57 --> URI Class Initialized
DEBUG - 2011-07-06 18:12:57 --> Router Class Initialized
ERROR - 2011-07-06 18:12:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 18:13:10 --> Config Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:13:10 --> URI Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Router Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Output Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Input Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 18:13:10 --> Language Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Loader Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Controller Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 18:13:10 --> Database Driver Class Initialized
DEBUG - 2011-07-06 18:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 18:13:10 --> Helper loaded: url_helper
DEBUG - 2011-07-06 18:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 18:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 18:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 18:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 18:13:10 --> Final output sent to browser
DEBUG - 2011-07-06 18:13:10 --> Total execution time: 0.0446
DEBUG - 2011-07-06 18:13:16 --> Config Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:13:16 --> URI Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Router Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Output Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Input Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 18:13:16 --> Language Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Loader Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Controller Class Initialized
ERROR - 2011-07-06 18:13:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 18:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 18:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 18:13:16 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 18:13:16 --> Database Driver Class Initialized
DEBUG - 2011-07-06 18:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 18:13:16 --> Helper loaded: url_helper
DEBUG - 2011-07-06 18:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 18:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 18:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 18:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 18:13:16 --> Final output sent to browser
DEBUG - 2011-07-06 18:13:16 --> Total execution time: 0.0887
DEBUG - 2011-07-06 18:13:16 --> Config Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Hooks Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Utf8 Class Initialized
DEBUG - 2011-07-06 18:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 18:13:16 --> URI Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Router Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Output Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Input Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 18:13:16 --> Language Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Loader Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Controller Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Model Class Initialized
DEBUG - 2011-07-06 18:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 18:13:16 --> Database Driver Class Initialized
DEBUG - 2011-07-06 18:13:17 --> Final output sent to browser
DEBUG - 2011-07-06 18:13:17 --> Total execution time: 0.5494
DEBUG - 2011-07-06 19:52:25 --> Config Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Hooks Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Utf8 Class Initialized
DEBUG - 2011-07-06 19:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 19:52:25 --> URI Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Router Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Output Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Input Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 19:52:25 --> Language Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Loader Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Controller Class Initialized
ERROR - 2011-07-06 19:52:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 19:52:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 19:52:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 19:52:25 --> Model Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Model Class Initialized
DEBUG - 2011-07-06 19:52:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 19:52:25 --> Database Driver Class Initialized
DEBUG - 2011-07-06 19:52:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 19:52:25 --> Helper loaded: url_helper
DEBUG - 2011-07-06 19:52:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 19:52:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 19:52:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 19:52:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 19:52:25 --> Final output sent to browser
DEBUG - 2011-07-06 19:52:25 --> Total execution time: 0.3351
DEBUG - 2011-07-06 19:54:17 --> Config Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Hooks Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Utf8 Class Initialized
DEBUG - 2011-07-06 19:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 19:54:17 --> URI Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Router Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Output Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Input Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 19:54:17 --> Language Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Loader Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Controller Class Initialized
DEBUG - 2011-07-06 19:54:17 --> Model Class Initialized
DEBUG - 2011-07-06 19:54:18 --> Model Class Initialized
DEBUG - 2011-07-06 19:54:18 --> Model Class Initialized
DEBUG - 2011-07-06 19:54:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 19:54:18 --> Database Driver Class Initialized
DEBUG - 2011-07-06 19:54:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 19:54:19 --> Helper loaded: url_helper
DEBUG - 2011-07-06 19:54:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 19:54:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 19:54:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 19:54:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 19:54:19 --> Final output sent to browser
DEBUG - 2011-07-06 19:54:19 --> Total execution time: 2.1615
DEBUG - 2011-07-06 19:54:23 --> Config Class Initialized
DEBUG - 2011-07-06 19:54:23 --> Hooks Class Initialized
DEBUG - 2011-07-06 19:54:23 --> Utf8 Class Initialized
DEBUG - 2011-07-06 19:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 19:54:23 --> URI Class Initialized
DEBUG - 2011-07-06 19:54:23 --> Router Class Initialized
ERROR - 2011-07-06 19:54:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 19:54:24 --> Config Class Initialized
DEBUG - 2011-07-06 19:54:24 --> Hooks Class Initialized
DEBUG - 2011-07-06 19:54:24 --> Utf8 Class Initialized
DEBUG - 2011-07-06 19:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 19:54:24 --> URI Class Initialized
DEBUG - 2011-07-06 19:54:24 --> Router Class Initialized
ERROR - 2011-07-06 19:54:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 19:54:24 --> Config Class Initialized
DEBUG - 2011-07-06 19:54:24 --> Hooks Class Initialized
DEBUG - 2011-07-06 19:54:24 --> Utf8 Class Initialized
DEBUG - 2011-07-06 19:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 19:54:24 --> URI Class Initialized
DEBUG - 2011-07-06 19:54:24 --> Router Class Initialized
ERROR - 2011-07-06 19:54:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-06 20:17:23 --> Config Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Hooks Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Utf8 Class Initialized
DEBUG - 2011-07-06 20:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 20:17:23 --> URI Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Router Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Output Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Input Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 20:17:23 --> Language Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Loader Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Controller Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Model Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Model Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Model Class Initialized
DEBUG - 2011-07-06 20:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 20:17:23 --> Database Driver Class Initialized
DEBUG - 2011-07-06 20:17:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 20:17:24 --> Helper loaded: url_helper
DEBUG - 2011-07-06 20:17:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 20:17:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 20:17:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 20:17:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 20:17:24 --> Final output sent to browser
DEBUG - 2011-07-06 20:17:24 --> Total execution time: 0.8318
DEBUG - 2011-07-06 20:17:25 --> Config Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Hooks Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Utf8 Class Initialized
DEBUG - 2011-07-06 20:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 20:17:25 --> URI Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Router Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Output Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Input Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 20:17:25 --> Language Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Loader Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Controller Class Initialized
ERROR - 2011-07-06 20:17:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 20:17:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 20:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 20:17:25 --> Model Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Model Class Initialized
DEBUG - 2011-07-06 20:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 20:17:25 --> Database Driver Class Initialized
DEBUG - 2011-07-06 20:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 20:17:25 --> Helper loaded: url_helper
DEBUG - 2011-07-06 20:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 20:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 20:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 20:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 20:17:25 --> Final output sent to browser
DEBUG - 2011-07-06 20:17:25 --> Total execution time: 0.1062
DEBUG - 2011-07-06 22:08:43 --> Config Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Hooks Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Utf8 Class Initialized
DEBUG - 2011-07-06 22:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 22:08:43 --> URI Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Router Class Initialized
DEBUG - 2011-07-06 22:08:43 --> No URI present. Default controller set.
DEBUG - 2011-07-06 22:08:43 --> Output Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Input Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 22:08:43 --> Language Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Loader Class Initialized
DEBUG - 2011-07-06 22:08:43 --> Controller Class Initialized
DEBUG - 2011-07-06 22:08:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-06 22:08:43 --> Helper loaded: url_helper
DEBUG - 2011-07-06 22:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 22:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 22:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 22:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 22:08:43 --> Final output sent to browser
DEBUG - 2011-07-06 22:08:43 --> Total execution time: 0.2258
DEBUG - 2011-07-06 22:27:01 --> Config Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Hooks Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Utf8 Class Initialized
DEBUG - 2011-07-06 22:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 22:27:01 --> URI Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Router Class Initialized
ERROR - 2011-07-06 22:27:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-06 22:27:01 --> Config Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Hooks Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Utf8 Class Initialized
DEBUG - 2011-07-06 22:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 22:27:01 --> URI Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Router Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Output Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Input Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 22:27:01 --> Language Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Loader Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Controller Class Initialized
ERROR - 2011-07-06 22:27:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-06 22:27:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-06 22:27:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 22:27:01 --> Model Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Model Class Initialized
DEBUG - 2011-07-06 22:27:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 22:27:01 --> Database Driver Class Initialized
DEBUG - 2011-07-06 22:27:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-06 22:27:01 --> Helper loaded: url_helper
DEBUG - 2011-07-06 22:27:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 22:27:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 22:27:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 22:27:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 22:27:01 --> Final output sent to browser
DEBUG - 2011-07-06 22:27:01 --> Total execution time: 0.2845
DEBUG - 2011-07-06 23:05:23 --> Config Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Hooks Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Utf8 Class Initialized
DEBUG - 2011-07-06 23:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-06 23:05:23 --> URI Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Router Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Output Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Input Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-06 23:05:23 --> Language Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Loader Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Controller Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Model Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Model Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Model Class Initialized
DEBUG - 2011-07-06 23:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-06 23:05:23 --> Database Driver Class Initialized
DEBUG - 2011-07-06 23:05:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-06 23:05:23 --> Helper loaded: url_helper
DEBUG - 2011-07-06 23:05:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-06 23:05:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-06 23:05:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-06 23:05:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-06 23:05:23 --> Final output sent to browser
DEBUG - 2011-07-06 23:05:23 --> Total execution time: 0.6412

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-03 00:11:10 --> Config Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:11:10 --> URI Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Router Class Initialized
DEBUG - 2011-04-03 00:11:10 --> No URI present. Default controller set.
DEBUG - 2011-04-03 00:11:10 --> Output Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Input Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:11:10 --> Language Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Loader Class Initialized
DEBUG - 2011-04-03 00:11:10 --> Controller Class Initialized
DEBUG - 2011-04-03 00:11:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 00:11:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:11:10 --> Final output sent to browser
DEBUG - 2011-04-03 00:11:10 --> Total execution time: 0.0610
DEBUG - 2011-04-03 00:11:19 --> Config Class Initialized
DEBUG - 2011-04-03 00:11:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:11:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:11:19 --> URI Class Initialized
DEBUG - 2011-04-03 00:11:19 --> Router Class Initialized
ERROR - 2011-04-03 00:11:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 00:11:39 --> Config Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:11:39 --> URI Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Router Class Initialized
DEBUG - 2011-04-03 00:11:39 --> No URI present. Default controller set.
DEBUG - 2011-04-03 00:11:39 --> Output Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Input Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:11:39 --> Language Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Loader Class Initialized
DEBUG - 2011-04-03 00:11:39 --> Controller Class Initialized
DEBUG - 2011-04-03 00:11:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 00:11:39 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:11:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:11:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:11:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:11:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:11:39 --> Final output sent to browser
DEBUG - 2011-04-03 00:11:39 --> Total execution time: 0.0153
DEBUG - 2011-04-03 00:11:50 --> Config Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:11:50 --> URI Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Router Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Output Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Input Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:11:50 --> Language Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Loader Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Controller Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Model Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Model Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Model Class Initialized
DEBUG - 2011-04-03 00:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:11:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:11:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:11:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:11:50 --> Final output sent to browser
DEBUG - 2011-04-03 00:11:50 --> Total execution time: 0.2541
DEBUG - 2011-04-03 00:12:03 --> Config Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:12:03 --> URI Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Router Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Output Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Input Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:12:03 --> Language Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Loader Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Controller Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Model Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Model Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Model Class Initialized
DEBUG - 2011-04-03 00:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:12:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:12:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:12:03 --> Final output sent to browser
DEBUG - 2011-04-03 00:12:03 --> Total execution time: 0.1901
DEBUG - 2011-04-03 00:13:30 --> Config Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:13:30 --> URI Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Router Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Output Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Input Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:13:30 --> Language Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Loader Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Controller Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:13:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:13:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:13:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:13:30 --> Final output sent to browser
DEBUG - 2011-04-03 00:13:30 --> Total execution time: 0.2561
DEBUG - 2011-04-03 00:13:34 --> Config Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:13:34 --> URI Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Router Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Output Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Input Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:13:34 --> Language Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Loader Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Controller Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:13:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:13:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:13:34 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:13:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:13:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:13:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:13:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:13:34 --> Final output sent to browser
DEBUG - 2011-04-03 00:13:34 --> Total execution time: 0.1667
DEBUG - 2011-04-03 00:13:53 --> Config Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:13:53 --> URI Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Router Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Output Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Input Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:13:53 --> Language Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Loader Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Controller Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Model Class Initialized
DEBUG - 2011-04-03 00:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:13:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:13:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:13:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:13:53 --> Final output sent to browser
DEBUG - 2011-04-03 00:13:53 --> Total execution time: 0.1872
DEBUG - 2011-04-03 00:14:08 --> Config Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:14:08 --> URI Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Router Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Output Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Input Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:14:08 --> Language Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Loader Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Controller Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:14:08 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:14:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:14:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:14:09 --> Final output sent to browser
DEBUG - 2011-04-03 00:14:09 --> Total execution time: 0.2115
DEBUG - 2011-04-03 00:14:37 --> Config Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:14:37 --> URI Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Router Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Output Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Input Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:14:37 --> Language Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Loader Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Controller Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:14:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:14:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:14:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:14:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:14:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:14:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:14:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:14:37 --> Final output sent to browser
DEBUG - 2011-04-03 00:14:37 --> Total execution time: 0.2103
DEBUG - 2011-04-03 00:14:44 --> Config Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:14:44 --> URI Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Router Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Output Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Input Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:14:44 --> Language Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Loader Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Controller Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:14:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:14:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:14:44 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:14:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:14:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:14:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:14:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:14:44 --> Final output sent to browser
DEBUG - 2011-04-03 00:14:44 --> Total execution time: 0.0442
DEBUG - 2011-04-03 00:14:45 --> Config Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:14:45 --> URI Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Router Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Output Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Input Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:14:45 --> Language Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Loader Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Controller Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:14:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:14:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:14:45 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:14:45 --> Final output sent to browser
DEBUG - 2011-04-03 00:14:45 --> Total execution time: 0.0603
DEBUG - 2011-04-03 00:14:46 --> Config Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:14:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:14:46 --> URI Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Router Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Output Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Input Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:14:46 --> Language Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Loader Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Controller Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Model Class Initialized
DEBUG - 2011-04-03 00:14:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:14:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:14:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:14:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:14:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:14:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:14:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:14:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:14:46 --> Final output sent to browser
DEBUG - 2011-04-03 00:14:46 --> Total execution time: 0.0421
DEBUG - 2011-04-03 00:15:02 --> Config Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:15:02 --> URI Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Router Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Output Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Input Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:15:02 --> Language Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Loader Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Controller Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Model Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Model Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Model Class Initialized
DEBUG - 2011-04-03 00:15:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:15:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:15:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:15:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:15:03 --> Final output sent to browser
DEBUG - 2011-04-03 00:15:03 --> Total execution time: 1.6547
DEBUG - 2011-04-03 00:15:09 --> Config Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:15:09 --> URI Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Router Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Output Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Input Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:15:09 --> Language Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Loader Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Controller Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Model Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Model Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Model Class Initialized
DEBUG - 2011-04-03 00:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:15:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:15:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:15:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:15:10 --> Final output sent to browser
DEBUG - 2011-04-03 00:15:10 --> Total execution time: 0.0648
DEBUG - 2011-04-03 00:16:04 --> Config Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:16:04 --> URI Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Router Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Output Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Input Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:16:04 --> Language Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Loader Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Controller Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Model Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Model Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:16:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:16:04 --> Final output sent to browser
DEBUG - 2011-04-03 00:16:04 --> Total execution time: 0.6458
DEBUG - 2011-04-03 00:16:52 --> Config Class Initialized
DEBUG - 2011-04-03 00:16:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:16:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:16:52 --> URI Class Initialized
DEBUG - 2011-04-03 00:16:52 --> Router Class Initialized
ERROR - 2011-04-03 00:16:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 00:16:54 --> Config Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:16:54 --> URI Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Router Class Initialized
DEBUG - 2011-04-03 00:16:54 --> No URI present. Default controller set.
DEBUG - 2011-04-03 00:16:54 --> Output Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Input Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:16:54 --> Language Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Loader Class Initialized
DEBUG - 2011-04-03 00:16:54 --> Controller Class Initialized
DEBUG - 2011-04-03 00:16:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 00:16:54 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:16:54 --> Final output sent to browser
DEBUG - 2011-04-03 00:16:54 --> Total execution time: 0.0121
DEBUG - 2011-04-03 00:20:17 --> Config Class Initialized
DEBUG - 2011-04-03 00:20:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:20:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:20:17 --> URI Class Initialized
DEBUG - 2011-04-03 00:20:17 --> Router Class Initialized
ERROR - 2011-04-03 00:20:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 00:20:18 --> Config Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:20:18 --> URI Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Router Class Initialized
DEBUG - 2011-04-03 00:20:18 --> No URI present. Default controller set.
DEBUG - 2011-04-03 00:20:18 --> Output Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Input Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:20:18 --> Language Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Loader Class Initialized
DEBUG - 2011-04-03 00:20:18 --> Controller Class Initialized
DEBUG - 2011-04-03 00:20:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 00:20:18 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:20:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:20:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:20:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:20:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:20:18 --> Final output sent to browser
DEBUG - 2011-04-03 00:20:18 --> Total execution time: 0.0123
DEBUG - 2011-04-03 00:21:59 --> Config Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:21:59 --> URI Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Router Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Output Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Input Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:21:59 --> Language Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Loader Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Controller Class Initialized
ERROR - 2011-04-03 00:21:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:21:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:21:59 --> Model Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Model Class Initialized
DEBUG - 2011-04-03 00:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:21:59 --> Final output sent to browser
DEBUG - 2011-04-03 00:21:59 --> Total execution time: 0.0310
DEBUG - 2011-04-03 00:22:02 --> Config Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:22:02 --> URI Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Router Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Output Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Input Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:22:02 --> Language Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Loader Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Controller Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Model Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Model Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:22:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:22:02 --> Final output sent to browser
DEBUG - 2011-04-03 00:22:02 --> Total execution time: 0.4737
DEBUG - 2011-04-03 00:22:05 --> Config Class Initialized
DEBUG - 2011-04-03 00:22:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:22:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:22:05 --> URI Class Initialized
DEBUG - 2011-04-03 00:22:05 --> Router Class Initialized
ERROR - 2011-04-03 00:22:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 00:23:00 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:00 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:00 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Controller Class Initialized
ERROR - 2011-04-03 00:23:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:23:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:00 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:23:00 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:00 --> Total execution time: 0.0296
DEBUG - 2011-04-03 00:23:06 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:06 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:06 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Controller Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:07 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:07 --> Total execution time: 0.6107
DEBUG - 2011-04-03 00:23:15 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:15 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:15 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Controller Class Initialized
ERROR - 2011-04-03 00:23:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:15 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:15 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:23:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:23:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:23:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:23:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:23:15 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:15 --> Total execution time: 0.0270
DEBUG - 2011-04-03 00:23:16 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:16 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:16 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Controller Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:16 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:16 --> Total execution time: 0.8324
DEBUG - 2011-04-03 00:23:24 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:24 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:24 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Controller Class Initialized
ERROR - 2011-04-03 00:23:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:24 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:23:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:23:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:23:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:23:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:23:24 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:24 --> Total execution time: 0.0303
DEBUG - 2011-04-03 00:23:25 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:25 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:25 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Controller Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:25 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:25 --> Total execution time: 0.5712
DEBUG - 2011-04-03 00:23:44 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:44 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:44 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Controller Class Initialized
ERROR - 2011-04-03 00:23:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:23:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:44 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:44 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:23:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:23:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:23:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:23:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:23:44 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:44 --> Total execution time: 0.0281
DEBUG - 2011-04-03 00:23:45 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:45 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:45 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Controller Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:46 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:46 --> Total execution time: 0.5836
DEBUG - 2011-04-03 00:23:59 --> Config Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:23:59 --> URI Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Router Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Output Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Input Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:23:59 --> Language Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Loader Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Controller Class Initialized
ERROR - 2011-04-03 00:23:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:23:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:23:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:59 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Model Class Initialized
DEBUG - 2011-04-03 00:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:23:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:23:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:23:59 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:23:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:23:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:23:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:23:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:23:59 --> Final output sent to browser
DEBUG - 2011-04-03 00:23:59 --> Total execution time: 0.0270
DEBUG - 2011-04-03 00:24:00 --> Config Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:24:00 --> URI Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Router Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Output Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Input Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:24:00 --> Language Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Loader Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Controller Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Model Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Model Class Initialized
DEBUG - 2011-04-03 00:24:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:24:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:24:01 --> Final output sent to browser
DEBUG - 2011-04-03 00:24:01 --> Total execution time: 0.5086
DEBUG - 2011-04-03 00:24:17 --> Config Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:24:17 --> URI Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Router Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Output Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Input Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:24:17 --> Language Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Loader Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Controller Class Initialized
ERROR - 2011-04-03 00:24:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:24:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:24:17 --> Model Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Model Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:24:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:24:17 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:24:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:24:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:24:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:24:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:24:17 --> Final output sent to browser
DEBUG - 2011-04-03 00:24:17 --> Total execution time: 0.0488
DEBUG - 2011-04-03 00:24:17 --> Config Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:24:17 --> URI Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Router Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Output Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Input Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:24:17 --> Language Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Loader Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Controller Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Model Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Model Class Initialized
DEBUG - 2011-04-03 00:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:24:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:24:18 --> Final output sent to browser
DEBUG - 2011-04-03 00:24:18 --> Total execution time: 0.5210
DEBUG - 2011-04-03 00:41:18 --> Config Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:41:18 --> URI Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Router Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Output Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Input Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:41:18 --> Language Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Loader Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Controller Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Model Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Model Class Initialized
DEBUG - 2011-04-03 00:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:41:18 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:41:19 --> Final output sent to browser
DEBUG - 2011-04-03 00:41:19 --> Total execution time: 0.5820
DEBUG - 2011-04-03 00:43:03 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:03 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Router Class Initialized
DEBUG - 2011-04-03 00:43:03 --> No URI present. Default controller set.
DEBUG - 2011-04-03 00:43:03 --> Output Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Input Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:43:03 --> Language Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Loader Class Initialized
DEBUG - 2011-04-03 00:43:03 --> Controller Class Initialized
DEBUG - 2011-04-03 00:43:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 00:43:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:43:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:43:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:43:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:43:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:43:03 --> Final output sent to browser
DEBUG - 2011-04-03 00:43:03 --> Total execution time: 0.0125
DEBUG - 2011-04-03 00:43:05 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:05 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:05 --> Router Class Initialized
ERROR - 2011-04-03 00:43:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 00:43:18 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:18 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Router Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Output Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Input Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:43:18 --> Language Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Loader Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Controller Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:43:18 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:43:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:43:18 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:43:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:43:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:43:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:43:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:43:18 --> Final output sent to browser
DEBUG - 2011-04-03 00:43:18 --> Total execution time: 0.4118
DEBUG - 2011-04-03 00:43:19 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:19 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:19 --> Router Class Initialized
ERROR - 2011-04-03 00:43:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 00:43:30 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:30 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Router Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Output Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Input Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:43:30 --> Language Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Loader Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Controller Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:43:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:43:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:43:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:43:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:43:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:43:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:43:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:43:30 --> Final output sent to browser
DEBUG - 2011-04-03 00:43:30 --> Total execution time: 0.1894
DEBUG - 2011-04-03 00:43:32 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:32 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:32 --> Router Class Initialized
ERROR - 2011-04-03 00:43:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 00:43:45 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:45 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Router Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Output Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Input Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:43:45 --> Language Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Loader Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Controller Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:43:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:43:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:43:45 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:43:45 --> Final output sent to browser
DEBUG - 2011-04-03 00:43:45 --> Total execution time: 0.1911
DEBUG - 2011-04-03 00:43:47 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:47 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Router Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Output Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Input Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:43:47 --> Language Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Loader Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Controller Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Model Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:43:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:43:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 00:43:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:43:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:43:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:43:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:43:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:43:47 --> Final output sent to browser
DEBUG - 2011-04-03 00:43:47 --> Total execution time: 0.0467
DEBUG - 2011-04-03 00:43:47 --> Config Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:43:47 --> URI Class Initialized
DEBUG - 2011-04-03 00:43:47 --> Router Class Initialized
ERROR - 2011-04-03 00:43:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 00:51:50 --> Config Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:51:50 --> URI Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Router Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Output Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Input Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 00:51:50 --> Language Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Loader Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Controller Class Initialized
ERROR - 2011-04-03 00:51:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 00:51:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 00:51:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:51:50 --> Model Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Model Class Initialized
DEBUG - 2011-04-03 00:51:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 00:51:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 00:51:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 00:51:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 00:51:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 00:51:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 00:51:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 00:51:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 00:51:50 --> Final output sent to browser
DEBUG - 2011-04-03 00:51:50 --> Total execution time: 0.1001
DEBUG - 2011-04-03 00:55:56 --> Config Class Initialized
DEBUG - 2011-04-03 00:55:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 00:55:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 00:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 00:55:56 --> URI Class Initialized
DEBUG - 2011-04-03 00:55:56 --> Router Class Initialized
ERROR - 2011-04-03 00:55:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 01:10:41 --> Config Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:10:41 --> URI Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Router Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Output Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Input Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:10:41 --> Language Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Loader Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Controller Class Initialized
ERROR - 2011-04-03 01:10:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 01:10:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 01:10:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:10:41 --> Model Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Model Class Initialized
DEBUG - 2011-04-03 01:10:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:10:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:10:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:10:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:10:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:10:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:10:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:10:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:10:41 --> Final output sent to browser
DEBUG - 2011-04-03 01:10:41 --> Total execution time: 0.0542
DEBUG - 2011-04-03 01:10:44 --> Config Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:10:44 --> URI Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Router Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Output Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Input Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:10:44 --> Language Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Loader Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Controller Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Model Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Model Class Initialized
DEBUG - 2011-04-03 01:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:10:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:10:45 --> Final output sent to browser
DEBUG - 2011-04-03 01:10:45 --> Total execution time: 0.7824
DEBUG - 2011-04-03 01:10:48 --> Config Class Initialized
DEBUG - 2011-04-03 01:10:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:10:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:10:48 --> URI Class Initialized
DEBUG - 2011-04-03 01:10:48 --> Router Class Initialized
ERROR - 2011-04-03 01:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:10:54 --> Config Class Initialized
DEBUG - 2011-04-03 01:10:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:10:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:10:54 --> URI Class Initialized
DEBUG - 2011-04-03 01:10:54 --> Router Class Initialized
ERROR - 2011-04-03 01:10:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:11:02 --> Config Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:11:02 --> URI Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Router Class Initialized
DEBUG - 2011-04-03 01:11:02 --> No URI present. Default controller set.
DEBUG - 2011-04-03 01:11:02 --> Output Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Input Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:11:02 --> Language Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Loader Class Initialized
DEBUG - 2011-04-03 01:11:02 --> Controller Class Initialized
DEBUG - 2011-04-03 01:11:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 01:11:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:11:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:11:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:11:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:11:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:11:03 --> Final output sent to browser
DEBUG - 2011-04-03 01:11:03 --> Total execution time: 0.8422
DEBUG - 2011-04-03 01:11:06 --> Config Class Initialized
DEBUG - 2011-04-03 01:11:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:11:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:11:06 --> URI Class Initialized
DEBUG - 2011-04-03 01:11:06 --> Router Class Initialized
ERROR - 2011-04-03 01:11:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:17:13 --> Config Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:17:13 --> URI Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Router Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Output Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Input Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:17:13 --> Language Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Loader Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Controller Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Model Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Model Class Initialized
DEBUG - 2011-04-03 01:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:17:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:17:14 --> Final output sent to browser
DEBUG - 2011-04-03 01:17:14 --> Total execution time: 0.5800
DEBUG - 2011-04-03 01:38:02 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:03 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:03 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Controller Class Initialized
ERROR - 2011-04-03 01:38:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 01:38:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 01:38:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:38:03 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:38:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:38:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:38:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:38:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:38:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:38:05 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:05 --> Total execution time: 5.9056
DEBUG - 2011-04-03 01:38:06 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:06 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:06 --> No URI present. Default controller set.
DEBUG - 2011-04-03 01:38:06 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:06 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Controller Class Initialized
DEBUG - 2011-04-03 01:38:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 01:38:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:38:06 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:06 --> Total execution time: 0.0578
DEBUG - 2011-04-03 01:38:06 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:06 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Router Class Initialized
ERROR - 2011-04-03 01:38:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:38:06 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:06 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:06 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Controller Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:07 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:07 --> Total execution time: 0.6188
DEBUG - 2011-04-03 01:38:08 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:08 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:08 --> Router Class Initialized
ERROR - 2011-04-03 01:38:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:38:09 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:09 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:09 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Controller Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 01:38:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:38:09 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:09 --> Total execution time: 0.8202
DEBUG - 2011-04-03 01:38:11 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:11 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:11 --> Router Class Initialized
ERROR - 2011-04-03 01:38:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:38:11 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:11 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:11 --> Router Class Initialized
ERROR - 2011-04-03 01:38:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:38:22 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:22 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:22 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Controller Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:22 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:42 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:42 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Controller Class Initialized
ERROR - 2011-04-03 01:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 01:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 01:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:38:42 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:38:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:38:42 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:42 --> Total execution time: 0.2717
DEBUG - 2011-04-03 01:38:44 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:44 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:44 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Controller Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 01:38:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:38:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:38:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:38:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:38:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:38:46 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:46 --> Total execution time: 24.5400
DEBUG - 2011-04-03 01:38:50 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:50 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:50 --> Router Class Initialized
ERROR - 2011-04-03 01:38:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 01:38:52 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:52 --> Total execution time: 7.5598
DEBUG - 2011-04-03 01:38:56 --> Config Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:38:56 --> URI Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Router Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Output Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Input Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:38:56 --> Language Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Loader Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Controller Class Initialized
ERROR - 2011-04-03 01:38:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 01:38:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 01:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:38:56 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Model Class Initialized
DEBUG - 2011-04-03 01:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:38:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 01:38:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:38:56 --> Final output sent to browser
DEBUG - 2011-04-03 01:38:56 --> Total execution time: 0.0278
DEBUG - 2011-04-03 01:39:06 --> Config Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:39:06 --> URI Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Router Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Output Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Input Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:39:06 --> Language Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Loader Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Controller Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Model Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Model Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Model Class Initialized
DEBUG - 2011-04-03 01:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:39:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:39:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 01:39:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:39:06 --> Final output sent to browser
DEBUG - 2011-04-03 01:39:06 --> Total execution time: 0.0585
DEBUG - 2011-04-03 01:47:21 --> Config Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:47:21 --> URI Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Router Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Output Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Input Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:47:21 --> Language Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Loader Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Controller Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Model Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Model Class Initialized
DEBUG - 2011-04-03 01:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:47:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:47:22 --> Final output sent to browser
DEBUG - 2011-04-03 01:47:22 --> Total execution time: 0.7087
DEBUG - 2011-04-03 01:50:45 --> Config Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:50:45 --> URI Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Router Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Output Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Input Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:50:45 --> Language Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Loader Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Controller Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Model Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Model Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 01:50:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 01:50:45 --> Final output sent to browser
DEBUG - 2011-04-03 01:50:45 --> Total execution time: 0.6390
DEBUG - 2011-04-03 01:57:18 --> Config Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 01:57:18 --> URI Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Router Class Initialized
DEBUG - 2011-04-03 01:57:18 --> No URI present. Default controller set.
DEBUG - 2011-04-03 01:57:18 --> Output Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Input Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 01:57:18 --> Language Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Loader Class Initialized
DEBUG - 2011-04-03 01:57:18 --> Controller Class Initialized
DEBUG - 2011-04-03 01:57:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 01:57:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 01:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 01:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 01:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 01:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 01:57:19 --> Final output sent to browser
DEBUG - 2011-04-03 01:57:19 --> Total execution time: 2.5339
DEBUG - 2011-04-03 02:07:46 --> Config Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:07:46 --> URI Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Router Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Output Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Input Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:07:46 --> Language Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Loader Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Controller Class Initialized
ERROR - 2011-04-03 02:07:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:07:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:07:46 --> Model Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Model Class Initialized
DEBUG - 2011-04-03 02:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:07:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:07:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:07:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:07:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:07:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:07:48 --> Final output sent to browser
DEBUG - 2011-04-03 02:07:48 --> Total execution time: 1.2640
DEBUG - 2011-04-03 02:07:50 --> Config Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:07:50 --> URI Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Router Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Output Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Input Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:07:50 --> Language Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Loader Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Controller Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:07:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:07:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:07:51 --> Final output sent to browser
DEBUG - 2011-04-03 02:07:51 --> Total execution time: 1.1959
DEBUG - 2011-04-03 02:07:55 --> Config Class Initialized
DEBUG - 2011-04-03 02:07:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:07:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:07:55 --> URI Class Initialized
DEBUG - 2011-04-03 02:07:55 --> Router Class Initialized
ERROR - 2011-04-03 02:07:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:08:22 --> Config Class Initialized
DEBUG - 2011-04-03 02:08:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:08:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:08:22 --> URI Class Initialized
DEBUG - 2011-04-03 02:08:22 --> Router Class Initialized
DEBUG - 2011-04-03 02:08:22 --> No URI present. Default controller set.
DEBUG - 2011-04-03 02:08:22 --> Output Class Initialized
DEBUG - 2011-04-03 02:08:22 --> Input Class Initialized
DEBUG - 2011-04-03 02:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:08:22 --> Language Class Initialized
DEBUG - 2011-04-03 02:08:23 --> Loader Class Initialized
DEBUG - 2011-04-03 02:08:23 --> Controller Class Initialized
DEBUG - 2011-04-03 02:08:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 02:08:23 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:08:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:08:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:08:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:08:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:08:23 --> Final output sent to browser
DEBUG - 2011-04-03 02:08:23 --> Total execution time: 0.0710
DEBUG - 2011-04-03 02:08:25 --> Config Class Initialized
DEBUG - 2011-04-03 02:08:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:08:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:08:25 --> URI Class Initialized
DEBUG - 2011-04-03 02:08:25 --> Router Class Initialized
ERROR - 2011-04-03 02:08:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:08:27 --> Config Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:08:27 --> URI Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Router Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Output Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Input Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:08:27 --> Language Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Loader Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Controller Class Initialized
ERROR - 2011-04-03 02:08:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:08:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:08:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:08:27 --> Model Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Model Class Initialized
DEBUG - 2011-04-03 02:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:08:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:08:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:08:27 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:08:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:08:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:08:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:08:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:08:27 --> Final output sent to browser
DEBUG - 2011-04-03 02:08:27 --> Total execution time: 0.0375
DEBUG - 2011-04-03 02:08:29 --> Config Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:08:29 --> URI Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Router Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Output Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Input Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:08:29 --> Language Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Loader Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Controller Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Model Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Model Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:08:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:08:29 --> Final output sent to browser
DEBUG - 2011-04-03 02:08:29 --> Total execution time: 0.4717
DEBUG - 2011-04-03 02:08:32 --> Config Class Initialized
DEBUG - 2011-04-03 02:08:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:08:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:08:32 --> URI Class Initialized
DEBUG - 2011-04-03 02:08:32 --> Router Class Initialized
ERROR - 2011-04-03 02:08:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:09:32 --> Config Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:09:32 --> URI Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Router Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Output Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Input Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:09:32 --> Language Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Loader Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Controller Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Model Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Model Class Initialized
DEBUG - 2011-04-03 02:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:09:32 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:09:33 --> Final output sent to browser
DEBUG - 2011-04-03 02:09:33 --> Total execution time: 0.5373
DEBUG - 2011-04-03 02:17:11 --> Config Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:17:11 --> URI Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Router Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Output Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Input Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:17:11 --> Language Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Loader Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Controller Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Model Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Model Class Initialized
DEBUG - 2011-04-03 02:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:17:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:17:12 --> Final output sent to browser
DEBUG - 2011-04-03 02:17:12 --> Total execution time: 0.8927
DEBUG - 2011-04-03 02:24:16 --> Config Class Initialized
DEBUG - 2011-04-03 02:24:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:24:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:24:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:24:16 --> URI Class Initialized
DEBUG - 2011-04-03 02:24:17 --> Router Class Initialized
DEBUG - 2011-04-03 02:24:17 --> No URI present. Default controller set.
DEBUG - 2011-04-03 02:24:17 --> Output Class Initialized
DEBUG - 2011-04-03 02:24:17 --> Input Class Initialized
DEBUG - 2011-04-03 02:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:24:17 --> Language Class Initialized
DEBUG - 2011-04-03 02:24:17 --> Loader Class Initialized
DEBUG - 2011-04-03 02:24:17 --> Controller Class Initialized
DEBUG - 2011-04-03 02:24:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 02:24:18 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:24:18 --> Final output sent to browser
DEBUG - 2011-04-03 02:24:18 --> Total execution time: 3.4601
DEBUG - 2011-04-03 02:24:21 --> Config Class Initialized
DEBUG - 2011-04-03 02:24:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:24:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:24:21 --> URI Class Initialized
DEBUG - 2011-04-03 02:24:21 --> Router Class Initialized
ERROR - 2011-04-03 02:24:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:24:22 --> Config Class Initialized
DEBUG - 2011-04-03 02:24:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:24:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:24:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:24:22 --> URI Class Initialized
DEBUG - 2011-04-03 02:24:22 --> Router Class Initialized
ERROR - 2011-04-03 02:24:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:24:41 --> Config Class Initialized
DEBUG - 2011-04-03 02:24:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:24:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:24:41 --> URI Class Initialized
DEBUG - 2011-04-03 02:24:41 --> Router Class Initialized
DEBUG - 2011-04-03 02:24:41 --> Output Class Initialized
DEBUG - 2011-04-03 02:24:41 --> Input Class Initialized
DEBUG - 2011-04-03 02:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:24:42 --> Language Class Initialized
DEBUG - 2011-04-03 02:24:42 --> Loader Class Initialized
DEBUG - 2011-04-03 02:24:42 --> Controller Class Initialized
DEBUG - 2011-04-03 02:24:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:24:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:24:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:24:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:24:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:24:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 02:24:54 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:24:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:24:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:24:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:24:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:24:54 --> Final output sent to browser
DEBUG - 2011-04-03 02:24:54 --> Total execution time: 12.9969
DEBUG - 2011-04-03 02:24:58 --> Config Class Initialized
DEBUG - 2011-04-03 02:24:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:24:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:24:58 --> URI Class Initialized
DEBUG - 2011-04-03 02:24:58 --> Router Class Initialized
ERROR - 2011-04-03 02:24:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:26:03 --> Config Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:26:03 --> URI Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Router Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Output Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Input Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:26:03 --> Language Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Loader Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Controller Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Model Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Model Class Initialized
DEBUG - 2011-04-03 02:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:26:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:26:04 --> Final output sent to browser
DEBUG - 2011-04-03 02:26:04 --> Total execution time: 0.5216
DEBUG - 2011-04-03 02:31:43 --> Config Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:31:43 --> URI Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Router Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Output Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Input Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:31:43 --> Language Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Loader Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Controller Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:31:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:31:43 --> Final output sent to browser
DEBUG - 2011-04-03 02:31:43 --> Total execution time: 1.9401
DEBUG - 2011-04-03 02:44:59 --> Config Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:44:59 --> URI Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Router Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Output Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Input Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:44:59 --> Language Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Loader Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Controller Class Initialized
ERROR - 2011-04-03 02:44:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:44:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:44:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:44:59 --> Model Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Model Class Initialized
DEBUG - 2011-04-03 02:44:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:44:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:45:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:45:00 --> Final output sent to browser
DEBUG - 2011-04-03 02:45:00 --> Total execution time: 0.5260
DEBUG - 2011-04-03 02:45:01 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:01 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Router Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Output Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Input Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:45:01 --> Language Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Loader Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Controller Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:45:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:45:02 --> Final output sent to browser
DEBUG - 2011-04-03 02:45:02 --> Total execution time: 1.2129
DEBUG - 2011-04-03 02:45:07 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:07 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:07 --> Router Class Initialized
ERROR - 2011-04-03 02:45:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:45:10 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:10 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:10 --> Router Class Initialized
ERROR - 2011-04-03 02:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:45:19 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:19 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Router Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Output Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Input Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:45:19 --> Language Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Loader Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Controller Class Initialized
ERROR - 2011-04-03 02:45:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:45:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:45:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:45:19 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:45:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:45:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:45:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:45:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:45:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:45:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:45:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:45:19 --> Final output sent to browser
DEBUG - 2011-04-03 02:45:19 --> Total execution time: 0.0281
DEBUG - 2011-04-03 02:45:20 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:20 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Router Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Output Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Input Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:45:20 --> Language Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Loader Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Controller Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:45:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:45:23 --> Final output sent to browser
DEBUG - 2011-04-03 02:45:23 --> Total execution time: 3.6969
DEBUG - 2011-04-03 02:45:50 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:50 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Router Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Output Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Input Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:45:50 --> Language Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Loader Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Controller Class Initialized
ERROR - 2011-04-03 02:45:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:45:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:45:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:45:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:45:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:45:50 --> Final output sent to browser
DEBUG - 2011-04-03 02:45:50 --> Total execution time: 0.0294
DEBUG - 2011-04-03 02:45:52 --> Config Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:45:52 --> URI Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Router Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Output Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Input Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:45:52 --> Language Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Loader Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Controller Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Model Class Initialized
DEBUG - 2011-04-03 02:45:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:45:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:45:53 --> Final output sent to browser
DEBUG - 2011-04-03 02:45:53 --> Total execution time: 1.3589
DEBUG - 2011-04-03 02:46:15 --> Config Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:46:15 --> URI Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Router Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Output Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Input Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:46:15 --> Language Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Loader Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Controller Class Initialized
ERROR - 2011-04-03 02:46:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:46:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:46:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:46:15 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:46:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:46:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:46:15 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:46:15 --> Final output sent to browser
DEBUG - 2011-04-03 02:46:15 --> Total execution time: 0.0389
DEBUG - 2011-04-03 02:46:17 --> Config Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:46:17 --> URI Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Router Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Output Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Input Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:46:17 --> Language Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Loader Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Controller Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:46:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:46:17 --> Final output sent to browser
DEBUG - 2011-04-03 02:46:17 --> Total execution time: 0.4731
DEBUG - 2011-04-03 02:46:41 --> Config Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:46:41 --> URI Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Router Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Output Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Input Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:46:41 --> Language Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Loader Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Controller Class Initialized
ERROR - 2011-04-03 02:46:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:46:41 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:46:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:46:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:46:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:46:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:46:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:46:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:46:41 --> Final output sent to browser
DEBUG - 2011-04-03 02:46:41 --> Total execution time: 0.0309
DEBUG - 2011-04-03 02:46:42 --> Config Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:46:42 --> URI Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Router Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Output Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Input Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:46:42 --> Language Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Loader Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Controller Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:46:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:46:44 --> Final output sent to browser
DEBUG - 2011-04-03 02:46:44 --> Total execution time: 1.7447
DEBUG - 2011-04-03 02:46:56 --> Config Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:46:56 --> URI Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Router Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Output Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Input Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:46:56 --> Language Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Loader Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Controller Class Initialized
ERROR - 2011-04-03 02:46:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:46:56 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:46:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:46:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:46:56 --> Final output sent to browser
DEBUG - 2011-04-03 02:46:56 --> Total execution time: 0.0314
DEBUG - 2011-04-03 02:46:58 --> Config Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:46:58 --> URI Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Router Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Output Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Input Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:46:58 --> Language Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Loader Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Controller Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:46:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:46:58 --> Final output sent to browser
DEBUG - 2011-04-03 02:46:58 --> Total execution time: 0.7939
DEBUG - 2011-04-03 02:47:14 --> Config Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:47:14 --> URI Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Router Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Output Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Input Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:47:14 --> Language Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Loader Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Controller Class Initialized
ERROR - 2011-04-03 02:47:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:47:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:47:14 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:47:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:47:14 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:47:14 --> Final output sent to browser
DEBUG - 2011-04-03 02:47:14 --> Total execution time: 0.1561
DEBUG - 2011-04-03 02:47:15 --> Config Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:47:15 --> URI Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Router Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Output Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Input Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:47:15 --> Language Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Loader Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Controller Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:47:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:47:20 --> Final output sent to browser
DEBUG - 2011-04-03 02:47:20 --> Total execution time: 4.4183
DEBUG - 2011-04-03 02:47:42 --> Config Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:47:42 --> URI Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Router Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Output Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Input Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:47:42 --> Language Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Loader Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Controller Class Initialized
ERROR - 2011-04-03 02:47:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:47:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:47:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:47:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:47:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:47:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:47:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:47:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:47:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:47:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:47:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:47:42 --> Final output sent to browser
DEBUG - 2011-04-03 02:47:42 --> Total execution time: 0.0349
DEBUG - 2011-04-03 02:47:43 --> Config Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:47:43 --> URI Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Router Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Output Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Input Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:47:43 --> Language Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Loader Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Controller Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:47:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:47:44 --> Final output sent to browser
DEBUG - 2011-04-03 02:47:44 --> Total execution time: 0.6979
DEBUG - 2011-04-03 02:47:56 --> Config Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:47:56 --> URI Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Router Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Output Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Input Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:47:56 --> Language Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Loader Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Controller Class Initialized
ERROR - 2011-04-03 02:47:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:47:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:47:56 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:47:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:47:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:47:56 --> Final output sent to browser
DEBUG - 2011-04-03 02:47:56 --> Total execution time: 0.0413
DEBUG - 2011-04-03 02:47:58 --> Config Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:47:58 --> URI Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Router Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Output Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Input Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:47:58 --> Language Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Loader Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Controller Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:47:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:47:58 --> Final output sent to browser
DEBUG - 2011-04-03 02:47:58 --> Total execution time: 0.5463
DEBUG - 2011-04-03 02:49:36 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:36 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:36 --> Router Class Initialized
DEBUG - 2011-04-03 02:49:36 --> No URI present. Default controller set.
DEBUG - 2011-04-03 02:49:36 --> Output Class Initialized
DEBUG - 2011-04-03 02:49:36 --> Input Class Initialized
DEBUG - 2011-04-03 02:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:49:36 --> Language Class Initialized
DEBUG - 2011-04-03 02:49:37 --> Loader Class Initialized
DEBUG - 2011-04-03 02:49:37 --> Controller Class Initialized
DEBUG - 2011-04-03 02:49:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 02:49:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:49:37 --> Final output sent to browser
DEBUG - 2011-04-03 02:49:37 --> Total execution time: 1.6407
DEBUG - 2011-04-03 02:49:39 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:39 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:39 --> Router Class Initialized
ERROR - 2011-04-03 02:49:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:49:48 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:48 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Router Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Output Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Input Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:49:48 --> Language Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Loader Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Controller Class Initialized
ERROR - 2011-04-03 02:49:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:49:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:49:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:49:48 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:49:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:49:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:49:48 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:49:48 --> Final output sent to browser
DEBUG - 2011-04-03 02:49:48 --> Total execution time: 0.0499
DEBUG - 2011-04-03 02:49:50 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:50 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Router Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Output Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Input Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:49:50 --> Language Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Loader Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Controller Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:49:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:49:50 --> Final output sent to browser
DEBUG - 2011-04-03 02:49:50 --> Total execution time: 0.5072
DEBUG - 2011-04-03 02:49:52 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:52 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:52 --> Router Class Initialized
ERROR - 2011-04-03 02:49:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:49:57 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:57 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Router Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Output Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Input Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:49:57 --> Language Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Loader Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Controller Class Initialized
ERROR - 2011-04-03 02:49:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:49:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:49:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:49:57 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:49:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:49:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:49:57 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:49:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:49:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:49:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:49:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:49:57 --> Final output sent to browser
DEBUG - 2011-04-03 02:49:57 --> Total execution time: 0.0325
DEBUG - 2011-04-03 02:49:58 --> Config Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:49:58 --> URI Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Router Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Output Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Input Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:49:58 --> Language Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Loader Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Controller Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:49:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:49:59 --> Final output sent to browser
DEBUG - 2011-04-03 02:49:59 --> Total execution time: 0.9872
DEBUG - 2011-04-03 02:50:01 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:01 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:01 --> Router Class Initialized
ERROR - 2011-04-03 02:50:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:50:06 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:06 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:06 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Controller Class Initialized
ERROR - 2011-04-03 02:50:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:50:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:50:06 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:50:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:50:06 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:06 --> Total execution time: 0.0358
DEBUG - 2011-04-03 02:50:07 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:07 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:07 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Controller Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:07 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:07 --> Total execution time: 0.5214
DEBUG - 2011-04-03 02:50:09 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:09 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:09 --> Router Class Initialized
ERROR - 2011-04-03 02:50:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:50:13 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:13 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:13 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Controller Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:14 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:14 --> Total execution time: 0.4567
DEBUG - 2011-04-03 02:50:21 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:21 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:21 --> Router Class Initialized
ERROR - 2011-04-03 02:50:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:50:25 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:25 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:25 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Controller Class Initialized
ERROR - 2011-04-03 02:50:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:50:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:50:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:50:25 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:50:25 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:50:25 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:25 --> Total execution time: 0.0318
DEBUG - 2011-04-03 02:50:27 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:27 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:27 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Controller Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:28 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:28 --> Total execution time: 0.7024
DEBUG - 2011-04-03 02:50:29 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:29 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:29 --> Router Class Initialized
ERROR - 2011-04-03 02:50:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:50:48 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:48 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:48 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Controller Class Initialized
ERROR - 2011-04-03 02:50:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:50:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:50:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:50:48 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:50:48 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:50:48 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:48 --> Total execution time: 0.0294
DEBUG - 2011-04-03 02:50:50 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:50 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Router Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Output Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Input Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:50:50 --> Language Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Loader Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Controller Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:50:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:50:50 --> Final output sent to browser
DEBUG - 2011-04-03 02:50:50 --> Total execution time: 0.4620
DEBUG - 2011-04-03 02:50:52 --> Config Class Initialized
DEBUG - 2011-04-03 02:50:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:50:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:50:52 --> URI Class Initialized
DEBUG - 2011-04-03 02:50:52 --> Router Class Initialized
ERROR - 2011-04-03 02:50:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:51:14 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:14 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:14 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:15 --> Total execution time: 0.9545
DEBUG - 2011-04-03 02:51:15 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:15 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:15 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Controller Class Initialized
ERROR - 2011-04-03 02:51:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:51:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:51:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:15 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:15 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:51:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:51:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:51:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:51:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:51:15 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:15 --> Total execution time: 0.0283
DEBUG - 2011-04-03 02:51:17 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:18 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:18 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:18 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:18 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:18 --> Total execution time: 0.5701
DEBUG - 2011-04-03 02:51:20 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:20 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:20 --> Router Class Initialized
ERROR - 2011-04-03 02:51:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:51:28 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:28 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:28 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:28 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:29 --> Total execution time: 0.4657
DEBUG - 2011-04-03 02:51:29 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:29 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:29 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Controller Class Initialized
ERROR - 2011-04-03 02:51:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:51:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:51:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:29 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:29 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:51:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:51:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:51:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:51:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:51:29 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:29 --> Total execution time: 0.0283
DEBUG - 2011-04-03 02:51:33 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:33 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:33 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:35 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:35 --> Total execution time: 2.0589
DEBUG - 2011-04-03 02:51:37 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:37 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:37 --> Router Class Initialized
ERROR - 2011-04-03 02:51:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:51:44 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:44 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:44 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:44 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:44 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:44 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:45 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:45 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:45 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:45 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:45 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:45 --> Total execution time: 0.5056
DEBUG - 2011-04-03 02:51:52 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:52 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:52 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Controller Class Initialized
ERROR - 2011-04-03 02:51:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:51:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:51:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:52 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:52 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:51:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:51:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:51:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:51:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:51:52 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:52 --> Total execution time: 0.0563
DEBUG - 2011-04-03 02:51:54 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:54 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:54 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:55 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:55 --> Total execution time: 1.9023
DEBUG - 2011-04-03 02:51:57 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:57 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:57 --> Router Class Initialized
ERROR - 2011-04-03 02:51:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:51:58 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:58 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:58 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Controller Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:59 --> Total execution time: 1.0072
DEBUG - 2011-04-03 02:51:59 --> Config Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:51:59 --> URI Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Router Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Output Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Input Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:51:59 --> Language Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Loader Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Controller Class Initialized
ERROR - 2011-04-03 02:51:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:51:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:51:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:59 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Model Class Initialized
DEBUG - 2011-04-03 02:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:51:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:51:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:51:59 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:51:59 --> Final output sent to browser
DEBUG - 2011-04-03 02:51:59 --> Total execution time: 0.0320
DEBUG - 2011-04-03 02:52:01 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:01 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:01 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:01 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:01 --> Total execution time: 0.7362
DEBUG - 2011-04-03 02:52:03 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:03 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:03 --> Router Class Initialized
ERROR - 2011-04-03 02:52:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:52:09 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:09 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:09 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:09 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:09 --> Total execution time: 0.4611
DEBUG - 2011-04-03 02:52:25 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:25 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:25 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Controller Class Initialized
ERROR - 2011-04-03 02:52:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:52:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:52:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:25 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:25 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:52:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:52:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:52:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:52:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:52:25 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:25 --> Total execution time: 0.1336
DEBUG - 2011-04-03 02:52:27 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:27 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:27 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:27 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:27 --> Total execution time: 0.5400
DEBUG - 2011-04-03 02:52:29 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:29 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:29 --> Router Class Initialized
ERROR - 2011-04-03 02:52:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:52:33 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:33 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:33 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Controller Class Initialized
ERROR - 2011-04-03 02:52:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:52:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:52:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:33 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:52:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:52:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:52:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:52:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:52:33 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:33 --> Total execution time: 0.0400
DEBUG - 2011-04-03 02:52:34 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:34 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:34 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:34 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:34 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:34 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:35 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:35 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:35 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:35 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:36 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:36 --> Total execution time: 1.0736
DEBUG - 2011-04-03 02:52:37 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:37 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:37 --> Router Class Initialized
ERROR - 2011-04-03 02:52:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:52:42 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:42 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:42 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Controller Class Initialized
ERROR - 2011-04-03 02:52:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:52:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:52:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:52:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:52:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:52:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:52:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:52:42 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:42 --> Total execution time: 0.0561
DEBUG - 2011-04-03 02:52:43 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:43 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:43 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:46 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:46 --> Total execution time: 3.2541
DEBUG - 2011-04-03 02:52:49 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:49 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:49 --> Router Class Initialized
ERROR - 2011-04-03 02:52:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:52:50 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:50 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:50 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:50 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:50 --> Total execution time: 0.5494
DEBUG - 2011-04-03 02:52:53 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:53 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:53 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Controller Class Initialized
ERROR - 2011-04-03 02:52:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:52:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:52:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:53 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:52:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:52:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:52:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:52:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:52:53 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:53 --> Total execution time: 0.0275
DEBUG - 2011-04-03 02:52:54 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:54 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:54 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:55 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:55 --> Total execution time: 0.4950
DEBUG - 2011-04-03 02:52:57 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:57 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Router Class Initialized
ERROR - 2011-04-03 02:52:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:52:57 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:57 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:57 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Controller Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:58 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:58 --> Total execution time: 0.4626
DEBUG - 2011-04-03 02:52:59 --> Config Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:52:59 --> URI Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Router Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Output Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Input Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:52:59 --> Language Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Loader Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Controller Class Initialized
ERROR - 2011-04-03 02:52:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:52:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:59 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Model Class Initialized
DEBUG - 2011-04-03 02:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:52:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:52:59 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:52:59 --> Final output sent to browser
DEBUG - 2011-04-03 02:52:59 --> Total execution time: 0.0272
DEBUG - 2011-04-03 02:53:00 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:00 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:00 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:00 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:00 --> Total execution time: 0.4694
DEBUG - 2011-04-03 02:53:02 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:02 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:02 --> Router Class Initialized
ERROR - 2011-04-03 02:53:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:53:04 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:04 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:04 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:04 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:05 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:05 --> Total execution time: 0.0352
DEBUG - 2011-04-03 02:53:05 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:05 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:05 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:05 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:06 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:06 --> Total execution time: 0.4981
DEBUG - 2011-04-03 02:53:07 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:07 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:07 --> Router Class Initialized
ERROR - 2011-04-03 02:53:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:53:09 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:09 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:09 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:09 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:09 --> Total execution time: 0.4823
DEBUG - 2011-04-03 02:53:12 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:12 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:12 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:12 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:12 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:12 --> Total execution time: 0.0295
DEBUG - 2011-04-03 02:53:13 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:13 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:13 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:14 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:14 --> Total execution time: 0.5163
DEBUG - 2011-04-03 02:53:16 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:16 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:16 --> Router Class Initialized
ERROR - 2011-04-03 02:53:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:53:20 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:20 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:20 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:20 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:20 --> Total execution time: 0.4585
DEBUG - 2011-04-03 02:53:21 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:21 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:21 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:21 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:21 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:21 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:21 --> Total execution time: 0.0413
DEBUG - 2011-04-03 02:53:23 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:23 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:23 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:24 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:24 --> Total execution time: 0.4988
DEBUG - 2011-04-03 02:53:25 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:25 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:25 --> Router Class Initialized
ERROR - 2011-04-03 02:53:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:53:28 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:28 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:28 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:28 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:28 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:28 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:28 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:28 --> Total execution time: 0.0347
DEBUG - 2011-04-03 02:53:29 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:29 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:29 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:30 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:30 --> Total execution time: 0.6058
DEBUG - 2011-04-03 02:53:32 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:32 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:32 --> Router Class Initialized
ERROR - 2011-04-03 02:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:53:42 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:42 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:42 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:42 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:42 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:42 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:43 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:43 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:43 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:43 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:43 --> Total execution time: 0.4727
DEBUG - 2011-04-03 02:53:46 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:46 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:46 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:46 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:46 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:46 --> Total execution time: 0.0275
DEBUG - 2011-04-03 02:53:47 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:47 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:47 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:48 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:48 --> Total execution time: 0.7118
DEBUG - 2011-04-03 02:53:49 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:49 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:49 --> Router Class Initialized
ERROR - 2011-04-03 02:53:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:53:51 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:51 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:51 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:51 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:51 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:51 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:51 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:51 --> Total execution time: 0.0302
DEBUG - 2011-04-03 02:53:56 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:56 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:56 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Controller Class Initialized
ERROR - 2011-04-03 02:53:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 02:53:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 02:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:56 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 02:53:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 02:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 02:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 02:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 02:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 02:53:56 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:56 --> Total execution time: 0.0282
DEBUG - 2011-04-03 02:53:57 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:57 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Router Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Output Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Input Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:53:57 --> Language Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Loader Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Controller Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Model Class Initialized
DEBUG - 2011-04-03 02:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:53:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:53:58 --> Final output sent to browser
DEBUG - 2011-04-03 02:53:58 --> Total execution time: 0.4650
DEBUG - 2011-04-03 02:53:59 --> Config Class Initialized
DEBUG - 2011-04-03 02:53:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:53:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:53:59 --> URI Class Initialized
DEBUG - 2011-04-03 02:53:59 --> Router Class Initialized
ERROR - 2011-04-03 02:53:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 02:54:26 --> Config Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 02:54:26 --> URI Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Router Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Output Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Input Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 02:54:26 --> Language Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Loader Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Controller Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Model Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Model Class Initialized
DEBUG - 2011-04-03 02:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 02:54:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 02:54:27 --> Final output sent to browser
DEBUG - 2011-04-03 02:54:27 --> Total execution time: 0.9434
DEBUG - 2011-04-03 03:13:57 --> Config Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:13:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:13:57 --> URI Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Router Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Output Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Input Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:13:57 --> Language Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Loader Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Controller Class Initialized
ERROR - 2011-04-03 03:13:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:13:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:13:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:13:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:13:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:13:58 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:13:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:13:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:13:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:13:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:13:58 --> Final output sent to browser
DEBUG - 2011-04-03 03:13:58 --> Total execution time: 4.0014
DEBUG - 2011-04-03 03:13:59 --> Config Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:13:59 --> URI Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Router Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Output Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Input Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:13:59 --> Language Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Loader Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Controller Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Model Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Model Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:13:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:13:59 --> Final output sent to browser
DEBUG - 2011-04-03 03:13:59 --> Total execution time: 0.6337
DEBUG - 2011-04-03 03:14:01 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:02 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:02 --> Router Class Initialized
ERROR - 2011-04-03 03:14:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:14:06 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:06 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Router Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Output Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Input Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:14:06 --> Language Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Loader Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Controller Class Initialized
ERROR - 2011-04-03 03:14:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:14:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:14:06 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:14:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:14:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:14:06 --> Final output sent to browser
DEBUG - 2011-04-03 03:14:06 --> Total execution time: 0.0290
DEBUG - 2011-04-03 03:14:07 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:07 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Router Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Output Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Input Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:14:07 --> Language Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Loader Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Controller Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:14:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:14:08 --> Final output sent to browser
DEBUG - 2011-04-03 03:14:08 --> Total execution time: 1.3731
DEBUG - 2011-04-03 03:14:25 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:25 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Router Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Output Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Input Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:14:25 --> Language Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Loader Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Controller Class Initialized
ERROR - 2011-04-03 03:14:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:14:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:14:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:14:25 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:14:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:14:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:14:25 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:14:25 --> Final output sent to browser
DEBUG - 2011-04-03 03:14:25 --> Total execution time: 0.0307
DEBUG - 2011-04-03 03:14:26 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:26 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Router Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Output Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Input Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:14:26 --> Language Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Loader Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Controller Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:14:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:14:28 --> Final output sent to browser
DEBUG - 2011-04-03 03:14:28 --> Total execution time: 1.8302
DEBUG - 2011-04-03 03:14:39 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:39 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Router Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Output Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Input Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:14:39 --> Language Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Loader Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Controller Class Initialized
ERROR - 2011-04-03 03:14:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:14:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:14:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:14:39 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:14:39 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:14:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:14:39 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:14:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:14:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:14:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:14:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:14:39 --> Final output sent to browser
DEBUG - 2011-04-03 03:14:39 --> Total execution time: 0.0304
DEBUG - 2011-04-03 03:14:40 --> Config Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:14:40 --> URI Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Router Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Output Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Input Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:14:40 --> Language Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Loader Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Controller Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Model Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:14:40 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:14:40 --> Final output sent to browser
DEBUG - 2011-04-03 03:14:40 --> Total execution time: 0.4572
DEBUG - 2011-04-03 03:15:10 --> Config Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:15:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:15:10 --> URI Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Router Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Output Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Input Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:15:10 --> Language Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Loader Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Controller Class Initialized
ERROR - 2011-04-03 03:15:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:15:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:15:10 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:15:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:15:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:15:10 --> Final output sent to browser
DEBUG - 2011-04-03 03:15:10 --> Total execution time: 0.0278
DEBUG - 2011-04-03 03:15:11 --> Config Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:15:11 --> URI Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Router Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Output Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Input Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:15:11 --> Language Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Loader Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Controller Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:15:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:15:14 --> Final output sent to browser
DEBUG - 2011-04-03 03:15:14 --> Total execution time: 2.9599
DEBUG - 2011-04-03 03:15:35 --> Config Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:15:35 --> URI Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Router Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Output Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Input Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:15:35 --> Language Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Loader Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Controller Class Initialized
ERROR - 2011-04-03 03:15:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:15:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:15:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:15:35 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:15:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:15:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:15:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:15:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:15:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:15:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:15:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:15:35 --> Final output sent to browser
DEBUG - 2011-04-03 03:15:35 --> Total execution time: 0.0854
DEBUG - 2011-04-03 03:15:38 --> Config Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:15:38 --> URI Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Router Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Output Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Input Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:15:38 --> Language Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Loader Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Controller Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Model Class Initialized
DEBUG - 2011-04-03 03:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:15:38 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:15:45 --> Final output sent to browser
DEBUG - 2011-04-03 03:15:45 --> Total execution time: 7.1963
DEBUG - 2011-04-03 03:16:06 --> Config Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:16:06 --> URI Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Router Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Output Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Input Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:16:06 --> Language Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Loader Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Controller Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Model Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Model Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:16:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:16:06 --> Final output sent to browser
DEBUG - 2011-04-03 03:16:06 --> Total execution time: 0.7023
DEBUG - 2011-04-03 03:18:31 --> Config Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:18:31 --> URI Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Router Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Output Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Input Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:18:31 --> Language Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Loader Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Controller Class Initialized
ERROR - 2011-04-03 03:18:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:18:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:18:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:18:31 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:18:31 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:18:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:18:31 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:18:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:18:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:18:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:18:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:18:31 --> Final output sent to browser
DEBUG - 2011-04-03 03:18:31 --> Total execution time: 0.0278
DEBUG - 2011-04-03 03:18:34 --> Config Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:18:34 --> URI Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Router Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Output Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Input Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:18:34 --> Language Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Loader Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Controller Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:18:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:18:35 --> Final output sent to browser
DEBUG - 2011-04-03 03:18:35 --> Total execution time: 0.7086
DEBUG - 2011-04-03 03:18:36 --> Config Class Initialized
DEBUG - 2011-04-03 03:18:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:18:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:18:36 --> URI Class Initialized
DEBUG - 2011-04-03 03:18:36 --> Router Class Initialized
ERROR - 2011-04-03 03:18:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:18:56 --> Config Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:18:56 --> URI Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Router Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Output Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Input Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:18:56 --> Language Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Loader Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Controller Class Initialized
ERROR - 2011-04-03 03:18:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:18:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:18:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:18:56 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:18:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:18:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:18:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:18:56 --> Final output sent to browser
DEBUG - 2011-04-03 03:18:56 --> Total execution time: 0.0346
DEBUG - 2011-04-03 03:18:57 --> Config Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:18:57 --> URI Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Router Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Output Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Input Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:18:57 --> Language Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Loader Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Controller Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:18:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:18:57 --> Final output sent to browser
DEBUG - 2011-04-03 03:18:57 --> Total execution time: 0.5162
DEBUG - 2011-04-03 03:19:10 --> Config Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:19:10 --> URI Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Router Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Output Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Input Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:19:10 --> Language Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Loader Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Controller Class Initialized
ERROR - 2011-04-03 03:19:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:19:10 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:19:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:19:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:19:10 --> Final output sent to browser
DEBUG - 2011-04-03 03:19:10 --> Total execution time: 0.0281
DEBUG - 2011-04-03 03:19:10 --> Config Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:19:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:19:11 --> URI Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Router Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Output Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Input Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:19:11 --> Language Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Loader Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Controller Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:19:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:19:12 --> Final output sent to browser
DEBUG - 2011-04-03 03:19:12 --> Total execution time: 1.7877
DEBUG - 2011-04-03 03:19:16 --> Config Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:19:16 --> URI Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Router Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Output Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Input Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:19:16 --> Language Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Loader Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Controller Class Initialized
ERROR - 2011-04-03 03:19:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:19:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:19:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:19:16 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:19:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:19:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:19:16 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:19:16 --> Final output sent to browser
DEBUG - 2011-04-03 03:19:16 --> Total execution time: 0.0491
DEBUG - 2011-04-03 03:19:17 --> Config Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:19:17 --> URI Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Router Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Output Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Input Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:19:17 --> Language Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Loader Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Controller Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:19:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:19:18 --> Final output sent to browser
DEBUG - 2011-04-03 03:19:18 --> Total execution time: 0.5747
DEBUG - 2011-04-03 03:19:29 --> Config Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:19:29 --> URI Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Router Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Output Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Input Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:19:29 --> Language Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Loader Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Controller Class Initialized
ERROR - 2011-04-03 03:19:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:19:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:19:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:19:29 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:19:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:19:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:19:29 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:19:29 --> Final output sent to browser
DEBUG - 2011-04-03 03:19:29 --> Total execution time: 0.0300
DEBUG - 2011-04-03 03:19:30 --> Config Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:19:30 --> URI Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Router Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Output Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Input Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:19:30 --> Language Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Loader Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Controller Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Model Class Initialized
DEBUG - 2011-04-03 03:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:19:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:19:31 --> Final output sent to browser
DEBUG - 2011-04-03 03:19:31 --> Total execution time: 1.6338
DEBUG - 2011-04-03 03:29:02 --> Config Class Initialized
DEBUG - 2011-04-03 03:29:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:29:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:29:02 --> URI Class Initialized
DEBUG - 2011-04-03 03:29:02 --> Router Class Initialized
ERROR - 2011-04-03 03:29:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 03:29:03 --> Config Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:29:03 --> URI Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Router Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Output Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Input Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:29:03 --> Language Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Loader Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Controller Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Model Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Model Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:29:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:29:03 --> Final output sent to browser
DEBUG - 2011-04-03 03:29:03 --> Total execution time: 0.5889
DEBUG - 2011-04-03 03:29:07 --> Config Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:29:07 --> URI Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Router Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Output Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Input Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:29:07 --> Language Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Loader Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Controller Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Model Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Model Class Initialized
DEBUG - 2011-04-03 03:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:29:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:29:08 --> Final output sent to browser
DEBUG - 2011-04-03 03:29:08 --> Total execution time: 0.5051
DEBUG - 2011-04-03 03:33:10 --> Config Class Initialized
DEBUG - 2011-04-03 03:33:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:33:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:33:10 --> URI Class Initialized
DEBUG - 2011-04-03 03:33:10 --> Router Class Initialized
DEBUG - 2011-04-03 03:33:10 --> Output Class Initialized
DEBUG - 2011-04-03 03:33:11 --> Input Class Initialized
DEBUG - 2011-04-03 03:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:33:11 --> Language Class Initialized
DEBUG - 2011-04-03 03:33:11 --> Loader Class Initialized
DEBUG - 2011-04-03 03:33:11 --> Controller Class Initialized
ERROR - 2011-04-03 03:33:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:33:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:33:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:33:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:33:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:33:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:33:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:33:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:33:12 --> Final output sent to browser
DEBUG - 2011-04-03 03:33:12 --> Total execution time: 1.4992
DEBUG - 2011-04-03 03:37:45 --> Config Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:37:45 --> URI Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Router Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Output Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Input Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:37:45 --> Language Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Loader Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Controller Class Initialized
ERROR - 2011-04-03 03:37:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:37:45 --> Model Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Model Class Initialized
DEBUG - 2011-04-03 03:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:37:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:37:45 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:37:45 --> Final output sent to browser
DEBUG - 2011-04-03 03:37:45 --> Total execution time: 0.2540
DEBUG - 2011-04-03 03:38:28 --> Config Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:38:28 --> URI Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Router Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Output Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Input Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:38:28 --> Language Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Loader Class Initialized
DEBUG - 2011-04-03 03:38:28 --> Controller Class Initialized
ERROR - 2011-04-03 03:38:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:38:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:38:29 --> Model Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Model Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:38:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:38:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:38:29 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:38:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:38:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:38:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:38:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:38:29 --> Final output sent to browser
DEBUG - 2011-04-03 03:38:29 --> Total execution time: 0.3020
DEBUG - 2011-04-03 03:38:29 --> Config Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:38:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:38:29 --> URI Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Router Class Initialized
DEBUG - 2011-04-03 03:38:29 --> No URI present. Default controller set.
DEBUG - 2011-04-03 03:38:29 --> Output Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Input Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:38:29 --> Language Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Loader Class Initialized
DEBUG - 2011-04-03 03:38:29 --> Controller Class Initialized
DEBUG - 2011-04-03 03:38:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 03:38:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:38:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:38:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:38:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:38:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:38:30 --> Final output sent to browser
DEBUG - 2011-04-03 03:38:30 --> Total execution time: 0.3210
DEBUG - 2011-04-03 03:38:44 --> Config Class Initialized
DEBUG - 2011-04-03 03:38:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:38:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:38:44 --> URI Class Initialized
DEBUG - 2011-04-03 03:38:44 --> Router Class Initialized
ERROR - 2011-04-03 03:38:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:38:57 --> Config Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:38:57 --> URI Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Router Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Output Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Input Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:38:57 --> Language Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Loader Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Controller Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Model Class Initialized
DEBUG - 2011-04-03 03:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:38:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Config Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:39:00 --> URI Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Router Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Output Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Input Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:39:00 --> Language Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Loader Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Controller Class Initialized
ERROR - 2011-04-03 03:39:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 03:39:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:39:00 --> Model Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Model Class Initialized
DEBUG - 2011-04-03 03:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:39:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 03:39:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:39:00 --> Final output sent to browser
DEBUG - 2011-04-03 03:39:00 --> Total execution time: 0.0953
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 03:39:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:39:00 --> Final output sent to browser
DEBUG - 2011-04-03 03:39:00 --> Total execution time: 2.5784
DEBUG - 2011-04-03 03:39:07 --> Config Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:39:07 --> URI Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Router Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Output Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Input Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:39:07 --> Language Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Loader Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Controller Class Initialized
DEBUG - 2011-04-03 03:39:07 --> Model Class Initialized
DEBUG - 2011-04-03 03:39:08 --> Model Class Initialized
DEBUG - 2011-04-03 03:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:39:08 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:39:08 --> Final output sent to browser
DEBUG - 2011-04-03 03:39:08 --> Total execution time: 1.4971
DEBUG - 2011-04-03 03:39:19 --> Config Class Initialized
DEBUG - 2011-04-03 03:39:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:39:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:39:19 --> URI Class Initialized
DEBUG - 2011-04-03 03:39:19 --> Router Class Initialized
ERROR - 2011-04-03 03:39:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:44:20 --> Config Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:44:20 --> URI Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Router Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Output Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Input Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:44:20 --> Language Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Loader Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Controller Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Model Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Model Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Model Class Initialized
DEBUG - 2011-04-03 03:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:44:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:44:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 03:44:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:44:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:44:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:44:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:44:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:44:24 --> Final output sent to browser
DEBUG - 2011-04-03 03:44:24 --> Total execution time: 4.1032
DEBUG - 2011-04-03 03:44:36 --> Config Class Initialized
DEBUG - 2011-04-03 03:44:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:44:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:44:36 --> URI Class Initialized
DEBUG - 2011-04-03 03:44:36 --> Router Class Initialized
ERROR - 2011-04-03 03:44:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:45:32 --> Config Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:45:32 --> URI Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Router Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Output Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Input Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:45:32 --> Language Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Loader Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Controller Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Model Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Model Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Model Class Initialized
DEBUG - 2011-04-03 03:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:45:32 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:45:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 03:45:32 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:45:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:45:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:45:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:45:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:45:32 --> Final output sent to browser
DEBUG - 2011-04-03 03:45:32 --> Total execution time: 0.0947
DEBUG - 2011-04-03 03:45:45 --> Config Class Initialized
DEBUG - 2011-04-03 03:45:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:45:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:45:45 --> URI Class Initialized
DEBUG - 2011-04-03 03:45:45 --> Router Class Initialized
ERROR - 2011-04-03 03:45:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:45:50 --> Config Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:45:50 --> URI Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Router Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Output Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Input Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:45:50 --> Language Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Loader Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Controller Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Model Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Model Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Model Class Initialized
DEBUG - 2011-04-03 03:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:45:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:45:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 03:45:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:45:50 --> Final output sent to browser
DEBUG - 2011-04-03 03:45:50 --> Total execution time: 0.0477
DEBUG - 2011-04-03 03:45:58 --> Config Class Initialized
DEBUG - 2011-04-03 03:45:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:45:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:45:58 --> URI Class Initialized
DEBUG - 2011-04-03 03:45:58 --> Router Class Initialized
ERROR - 2011-04-03 03:45:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:46:11 --> Config Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:46:11 --> URI Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Router Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Output Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Input Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:46:11 --> Language Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Loader Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Controller Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Model Class Initialized
DEBUG - 2011-04-03 03:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 03:46:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 03:46:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 03:46:11 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:46:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:46:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:46:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:46:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:46:11 --> Final output sent to browser
DEBUG - 2011-04-03 03:46:11 --> Total execution time: 0.0426
DEBUG - 2011-04-03 03:46:13 --> Config Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:46:13 --> URI Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Router Class Initialized
DEBUG - 2011-04-03 03:46:13 --> No URI present. Default controller set.
DEBUG - 2011-04-03 03:46:13 --> Output Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Input Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 03:46:13 --> Language Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Loader Class Initialized
DEBUG - 2011-04-03 03:46:13 --> Controller Class Initialized
DEBUG - 2011-04-03 03:46:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 03:46:13 --> Helper loaded: url_helper
DEBUG - 2011-04-03 03:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 03:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 03:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 03:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 03:46:13 --> Final output sent to browser
DEBUG - 2011-04-03 03:46:13 --> Total execution time: 0.1838
DEBUG - 2011-04-03 03:46:19 --> Config Class Initialized
DEBUG - 2011-04-03 03:46:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:46:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:46:19 --> URI Class Initialized
DEBUG - 2011-04-03 03:46:19 --> Router Class Initialized
ERROR - 2011-04-03 03:46:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:46:20 --> Config Class Initialized
DEBUG - 2011-04-03 03:46:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:46:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:46:20 --> URI Class Initialized
DEBUG - 2011-04-03 03:46:20 --> Router Class Initialized
ERROR - 2011-04-03 03:46:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:46:21 --> Config Class Initialized
DEBUG - 2011-04-03 03:46:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:46:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:46:21 --> URI Class Initialized
DEBUG - 2011-04-03 03:46:21 --> Router Class Initialized
ERROR - 2011-04-03 03:46:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 03:46:28 --> Config Class Initialized
DEBUG - 2011-04-03 03:46:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 03:46:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 03:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 03:46:28 --> URI Class Initialized
DEBUG - 2011-04-03 03:46:28 --> Router Class Initialized
ERROR - 2011-04-03 03:46:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:01:30 --> Config Class Initialized
DEBUG - 2011-04-03 04:01:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:01:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:01:32 --> URI Class Initialized
DEBUG - 2011-04-03 04:01:32 --> Router Class Initialized
DEBUG - 2011-04-03 04:01:33 --> Output Class Initialized
DEBUG - 2011-04-03 04:01:33 --> Input Class Initialized
DEBUG - 2011-04-03 04:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:01:34 --> Language Class Initialized
DEBUG - 2011-04-03 04:01:35 --> Loader Class Initialized
DEBUG - 2011-04-03 04:01:35 --> Controller Class Initialized
DEBUG - 2011-04-03 04:01:35 --> Model Class Initialized
DEBUG - 2011-04-03 04:01:35 --> Model Class Initialized
DEBUG - 2011-04-03 04:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:01:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:01:36 --> Final output sent to browser
DEBUG - 2011-04-03 04:01:36 --> Total execution time: 7.6822
DEBUG - 2011-04-03 04:02:18 --> Config Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:02:18 --> URI Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Router Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Output Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Input Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:02:18 --> Language Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Loader Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Controller Class Initialized
ERROR - 2011-04-03 04:02:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:02:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:02:18 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:02:18 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:02:18 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:02:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:02:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:02:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:02:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:02:18 --> Final output sent to browser
DEBUG - 2011-04-03 04:02:18 --> Total execution time: 0.2034
DEBUG - 2011-04-03 04:02:18 --> Config Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:02:18 --> URI Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Router Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Output Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Input Class Initialized
DEBUG - 2011-04-03 04:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:02:18 --> Language Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Loader Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Controller Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:02:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:02:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:02:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:02:19 --> Final output sent to browser
DEBUG - 2011-04-03 04:02:19 --> Total execution time: 0.0852
DEBUG - 2011-04-03 04:02:19 --> Config Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:02:19 --> URI Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Router Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Output Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Input Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:02:19 --> Language Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Loader Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Controller Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Model Class Initialized
DEBUG - 2011-04-03 04:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:02:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:02:20 --> Final output sent to browser
DEBUG - 2011-04-03 04:02:20 --> Total execution time: 0.5873
DEBUG - 2011-04-03 04:14:50 --> Config Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:14:50 --> URI Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Router Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Output Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Input Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:14:50 --> Language Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Loader Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Controller Class Initialized
ERROR - 2011-04-03 04:14:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:14:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:14:50 --> Model Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Model Class Initialized
DEBUG - 2011-04-03 04:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:14:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:14:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:14:50 --> Final output sent to browser
DEBUG - 2011-04-03 04:14:50 --> Total execution time: 0.1271
DEBUG - 2011-04-03 04:14:51 --> Config Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:14:51 --> URI Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Router Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Output Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Input Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:14:51 --> Language Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Loader Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Controller Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Model Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Model Class Initialized
DEBUG - 2011-04-03 04:14:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:14:51 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:14:52 --> Final output sent to browser
DEBUG - 2011-04-03 04:14:52 --> Total execution time: 0.6691
DEBUG - 2011-04-03 04:14:52 --> Config Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:14:53 --> URI Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Router Class Initialized
ERROR - 2011-04-03 04:14:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 04:14:53 --> Config Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:14:53 --> URI Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Router Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Output Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Input Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:14:53 --> Language Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Loader Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Controller Class Initialized
ERROR - 2011-04-03 04:14:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:14:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:14:53 --> Model Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Model Class Initialized
DEBUG - 2011-04-03 04:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:14:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:14:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:14:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:14:53 --> Final output sent to browser
DEBUG - 2011-04-03 04:14:53 --> Total execution time: 0.0289
DEBUG - 2011-04-03 04:15:11 --> Config Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:15:11 --> URI Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Router Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Output Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Input Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:15:11 --> Language Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Loader Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Controller Class Initialized
ERROR - 2011-04-03 04:15:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:15:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:15:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:15:11 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:15:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:15:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:15:11 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:15:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:15:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:15:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:15:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:15:11 --> Final output sent to browser
DEBUG - 2011-04-03 04:15:11 --> Total execution time: 0.0281
DEBUG - 2011-04-03 04:15:13 --> Config Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:15:13 --> URI Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Router Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Output Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Input Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:15:13 --> Language Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Loader Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Controller Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:15:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:15:15 --> Final output sent to browser
DEBUG - 2011-04-03 04:15:15 --> Total execution time: 1.9945
DEBUG - 2011-04-03 04:15:36 --> Config Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:15:36 --> URI Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Router Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Output Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Input Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:15:36 --> Language Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Loader Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Controller Class Initialized
ERROR - 2011-04-03 04:15:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:15:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:15:36 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:15:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:15:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:15:36 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:15:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:15:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:15:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:15:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:15:36 --> Final output sent to browser
DEBUG - 2011-04-03 04:15:36 --> Total execution time: 0.0614
DEBUG - 2011-04-03 04:15:37 --> Config Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:15:37 --> URI Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Router Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Output Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Input Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:15:37 --> Language Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Loader Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Controller Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Model Class Initialized
DEBUG - 2011-04-03 04:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:15:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:15:38 --> Final output sent to browser
DEBUG - 2011-04-03 04:15:38 --> Total execution time: 0.6617
DEBUG - 2011-04-03 04:16:13 --> Config Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:16:13 --> URI Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Router Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Output Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Input Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:16:13 --> Language Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Loader Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Controller Class Initialized
ERROR - 2011-04-03 04:16:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:16:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:16:13 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:16:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:16:13 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:16:13 --> Final output sent to browser
DEBUG - 2011-04-03 04:16:13 --> Total execution time: 0.0340
DEBUG - 2011-04-03 04:16:14 --> Config Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:16:14 --> URI Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Router Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Output Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Input Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:16:14 --> Language Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Loader Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Controller Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:16:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:16:15 --> Final output sent to browser
DEBUG - 2011-04-03 04:16:15 --> Total execution time: 0.5143
DEBUG - 2011-04-03 04:16:29 --> Config Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:16:29 --> URI Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Router Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Output Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Input Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:16:29 --> Language Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Loader Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Controller Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:16:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:16:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:16:32 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:16:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:16:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:16:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:16:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:16:32 --> Final output sent to browser
DEBUG - 2011-04-03 04:16:32 --> Total execution time: 3.3395
DEBUG - 2011-04-03 04:16:34 --> Config Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:16:34 --> URI Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Router Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Output Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Input Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:16:34 --> Language Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Loader Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Controller Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:16:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:16:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:16:34 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:16:34 --> Final output sent to browser
DEBUG - 2011-04-03 04:16:34 --> Total execution time: 0.0488
DEBUG - 2011-04-03 04:16:41 --> Config Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:16:41 --> URI Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Router Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Output Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Input Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:16:41 --> Language Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Loader Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Controller Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Model Class Initialized
DEBUG - 2011-04-03 04:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:16:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:16:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:16:41 --> Final output sent to browser
DEBUG - 2011-04-03 04:16:41 --> Total execution time: 0.3455
DEBUG - 2011-04-03 04:17:02 --> Config Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:17:02 --> URI Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Router Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Output Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Input Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:17:02 --> Language Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Loader Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Controller Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:17:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:17:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:17:02 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:17:02 --> Final output sent to browser
DEBUG - 2011-04-03 04:17:02 --> Total execution time: 0.0950
DEBUG - 2011-04-03 04:17:11 --> Config Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:17:11 --> URI Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Router Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Output Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Input Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:17:11 --> Language Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Loader Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Controller Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:17:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:17:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:17:23 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:17:23 --> Final output sent to browser
DEBUG - 2011-04-03 04:17:23 --> Total execution time: 12.7492
DEBUG - 2011-04-03 04:17:30 --> Config Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:17:30 --> URI Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Router Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Output Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Input Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:17:30 --> Language Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Loader Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Controller Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Model Class Initialized
DEBUG - 2011-04-03 04:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:17:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:17:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:17:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:17:30 --> Final output sent to browser
DEBUG - 2011-04-03 04:17:30 --> Total execution time: 0.2353
DEBUG - 2011-04-03 04:18:20 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:20 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Router Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Output Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Input Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:18:20 --> Language Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Loader Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Controller Class Initialized
ERROR - 2011-04-03 04:18:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:18:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:18:20 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:18:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:18:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:18:20 --> Final output sent to browser
DEBUG - 2011-04-03 04:18:20 --> Total execution time: 0.0270
DEBUG - 2011-04-03 04:18:24 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:24 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Router Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Output Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Input Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:18:24 --> Language Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Loader Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Controller Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:18:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:18:25 --> Final output sent to browser
DEBUG - 2011-04-03 04:18:25 --> Total execution time: 0.5151
DEBUG - 2011-04-03 04:18:26 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:26 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Router Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Output Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Input Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:18:26 --> Language Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Loader Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Controller Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:18:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:18:28 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:28 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:28 --> Router Class Initialized
ERROR - 2011-04-03 04:18:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:18:39 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:39 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Router Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Output Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Input Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:18:39 --> Language Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Loader Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Controller Class Initialized
ERROR - 2011-04-03 04:18:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 04:18:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 04:18:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:18:39 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:18:39 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:18:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 04:18:39 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:18:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:18:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:18:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:18:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:18:39 --> Final output sent to browser
DEBUG - 2011-04-03 04:18:39 --> Total execution time: 0.1589
DEBUG - 2011-04-03 04:18:41 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:41 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Router Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Output Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Input Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:18:41 --> Language Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Loader Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Controller Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:18:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:18:42 --> Final output sent to browser
DEBUG - 2011-04-03 04:18:42 --> Total execution time: 1.1895
DEBUG - 2011-04-03 04:18:45 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:45 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:45 --> Router Class Initialized
ERROR - 2011-04-03 04:18:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:18:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:18:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:18:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:18:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:18:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:18:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:18:50 --> Final output sent to browser
DEBUG - 2011-04-03 04:18:50 --> Total execution time: 23.9348
DEBUG - 2011-04-03 04:18:56 --> Config Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:18:56 --> URI Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Router Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Output Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Input Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:18:56 --> Language Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Loader Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Controller Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Model Class Initialized
DEBUG - 2011-04-03 04:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:18:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:18:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:18:57 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:18:57 --> Final output sent to browser
DEBUG - 2011-04-03 04:18:57 --> Total execution time: 0.0840
DEBUG - 2011-04-03 04:19:50 --> Config Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:19:50 --> URI Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Router Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Output Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Input Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:19:50 --> Language Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Loader Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Controller Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Model Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Model Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Model Class Initialized
DEBUG - 2011-04-03 04:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:19:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:19:51 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:19:51 --> Final output sent to browser
DEBUG - 2011-04-03 04:19:51 --> Total execution time: 1.5444
DEBUG - 2011-04-03 04:19:53 --> Config Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:19:53 --> URI Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Router Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Output Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Input Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:19:53 --> Language Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Loader Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Controller Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Model Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Model Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Model Class Initialized
DEBUG - 2011-04-03 04:19:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:19:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:19:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:19:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:19:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:19:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:19:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:19:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:19:53 --> Final output sent to browser
DEBUG - 2011-04-03 04:19:53 --> Total execution time: 0.0530
DEBUG - 2011-04-03 04:22:37 --> Config Class Initialized
DEBUG - 2011-04-03 04:22:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:22:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:22:37 --> URI Class Initialized
DEBUG - 2011-04-03 04:22:37 --> Router Class Initialized
ERROR - 2011-04-03 04:22:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 04:22:38 --> Config Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:22:38 --> URI Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Router Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Output Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Input Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:22:38 --> Language Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Loader Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Controller Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Model Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Model Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Model Class Initialized
DEBUG - 2011-04-03 04:22:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:22:38 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:22:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:22:38 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:22:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:22:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:22:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:22:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:22:38 --> Final output sent to browser
DEBUG - 2011-04-03 04:22:38 --> Total execution time: 0.0931
DEBUG - 2011-04-03 04:24:34 --> Config Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:24:34 --> URI Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Router Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Output Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Input Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:24:34 --> Language Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Loader Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Controller Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:24:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:24:35 --> Final output sent to browser
DEBUG - 2011-04-03 04:24:35 --> Total execution time: 0.6434
DEBUG - 2011-04-03 04:27:15 --> Config Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:27:15 --> URI Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Router Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Output Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Input Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:27:15 --> Language Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Loader Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Controller Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Model Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Model Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:27:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:27:15 --> Final output sent to browser
DEBUG - 2011-04-03 04:27:15 --> Total execution time: 0.7578
DEBUG - 2011-04-03 04:40:47 --> Config Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:40:47 --> URI Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Router Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Output Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Input Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:40:47 --> Language Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Loader Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Controller Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Model Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Model Class Initialized
DEBUG - 2011-04-03 04:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:40:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:40:48 --> Final output sent to browser
DEBUG - 2011-04-03 04:40:48 --> Total execution time: 1.2827
DEBUG - 2011-04-03 04:47:05 --> Config Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:47:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:47:05 --> URI Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Router Class Initialized
DEBUG - 2011-04-03 04:47:05 --> No URI present. Default controller set.
DEBUG - 2011-04-03 04:47:05 --> Output Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Input Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:47:05 --> Language Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Loader Class Initialized
DEBUG - 2011-04-03 04:47:05 --> Controller Class Initialized
DEBUG - 2011-04-03 04:47:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 04:47:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:47:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:47:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:47:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:47:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:47:05 --> Final output sent to browser
DEBUG - 2011-04-03 04:47:05 --> Total execution time: 0.2085
DEBUG - 2011-04-03 04:47:08 --> Config Class Initialized
DEBUG - 2011-04-03 04:47:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:47:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:47:08 --> URI Class Initialized
DEBUG - 2011-04-03 04:47:08 --> Router Class Initialized
ERROR - 2011-04-03 04:47:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:47:09 --> Config Class Initialized
DEBUG - 2011-04-03 04:47:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:47:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:47:09 --> URI Class Initialized
DEBUG - 2011-04-03 04:47:09 --> Router Class Initialized
ERROR - 2011-04-03 04:47:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:47:11 --> Config Class Initialized
DEBUG - 2011-04-03 04:47:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:47:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:47:11 --> URI Class Initialized
DEBUG - 2011-04-03 04:47:11 --> Router Class Initialized
ERROR - 2011-04-03 04:47:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:56:02 --> Config Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:56:02 --> URI Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Router Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Output Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Input Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:56:02 --> Language Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Loader Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Controller Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:56:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:56:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:56:04 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:56:04 --> Final output sent to browser
DEBUG - 2011-04-03 04:56:04 --> Total execution time: 1.6854
DEBUG - 2011-04-03 04:56:08 --> Config Class Initialized
DEBUG - 2011-04-03 04:56:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:56:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:56:08 --> URI Class Initialized
DEBUG - 2011-04-03 04:56:08 --> Router Class Initialized
ERROR - 2011-04-03 04:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:56:14 --> Config Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:56:14 --> URI Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Router Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Output Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Input Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:56:14 --> Language Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Loader Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Controller Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:56:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:56:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:56:17 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:56:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:56:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:56:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:56:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:56:17 --> Final output sent to browser
DEBUG - 2011-04-03 04:56:17 --> Total execution time: 3.4348
DEBUG - 2011-04-03 04:56:19 --> Config Class Initialized
DEBUG - 2011-04-03 04:56:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:56:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:56:19 --> URI Class Initialized
DEBUG - 2011-04-03 04:56:19 --> Router Class Initialized
ERROR - 2011-04-03 04:56:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 04:56:34 --> Config Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:56:34 --> URI Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Router Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Output Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Input Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:56:34 --> Language Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Loader Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Controller Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Model Class Initialized
DEBUG - 2011-04-03 04:56:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:56:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:56:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 04:56:40 --> Helper loaded: url_helper
DEBUG - 2011-04-03 04:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 04:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 04:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 04:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 04:56:40 --> Final output sent to browser
DEBUG - 2011-04-03 04:56:40 --> Total execution time: 6.5921
DEBUG - 2011-04-03 04:57:27 --> Config Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 04:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 04:57:27 --> URI Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Router Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Output Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Input Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 04:57:27 --> Language Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Loader Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Controller Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Model Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Model Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 04:57:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 04:57:27 --> Final output sent to browser
DEBUG - 2011-04-03 04:57:27 --> Total execution time: 0.5227
DEBUG - 2011-04-03 05:12:05 --> Config Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:12:05 --> URI Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Router Class Initialized
DEBUG - 2011-04-03 05:12:05 --> No URI present. Default controller set.
DEBUG - 2011-04-03 05:12:05 --> Output Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Input Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:12:05 --> Language Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Loader Class Initialized
DEBUG - 2011-04-03 05:12:05 --> Controller Class Initialized
DEBUG - 2011-04-03 05:12:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 05:12:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 05:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 05:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 05:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 05:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 05:12:05 --> Final output sent to browser
DEBUG - 2011-04-03 05:12:05 --> Total execution time: 0.2214
DEBUG - 2011-04-03 05:12:17 --> Config Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:12:17 --> URI Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Router Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Output Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Input Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:12:17 --> Language Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Loader Class Initialized
DEBUG - 2011-04-03 05:12:17 --> Controller Class Initialized
DEBUG - 2011-04-03 05:12:19 --> Model Class Initialized
DEBUG - 2011-04-03 05:12:19 --> Model Class Initialized
DEBUG - 2011-04-03 05:12:19 --> Model Class Initialized
DEBUG - 2011-04-03 05:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:12:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:12:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 05:12:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 05:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 05:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 05:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 05:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 05:12:19 --> Final output sent to browser
DEBUG - 2011-04-03 05:12:19 --> Total execution time: 2.3847
DEBUG - 2011-04-03 05:12:23 --> Config Class Initialized
DEBUG - 2011-04-03 05:12:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:12:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:12:23 --> URI Class Initialized
DEBUG - 2011-04-03 05:12:23 --> Router Class Initialized
ERROR - 2011-04-03 05:12:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 05:18:17 --> Config Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:18:17 --> URI Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Router Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Output Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Input Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:18:17 --> Language Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Loader Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Controller Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Model Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Model Class Initialized
DEBUG - 2011-04-03 05:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:18:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:18:18 --> Final output sent to browser
DEBUG - 2011-04-03 05:18:18 --> Total execution time: 1.1304
DEBUG - 2011-04-03 05:28:57 --> Config Class Initialized
DEBUG - 2011-04-03 05:28:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:28:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:28:58 --> URI Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Router Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Output Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Input Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:28:58 --> Language Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Loader Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Controller Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Model Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Model Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:28:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:28:58 --> Final output sent to browser
DEBUG - 2011-04-03 05:28:58 --> Total execution time: 0.6849
DEBUG - 2011-04-03 05:33:38 --> Config Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:33:38 --> URI Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Router Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Output Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Input Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:33:38 --> Language Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Loader Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Controller Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Model Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Model Class Initialized
DEBUG - 2011-04-03 05:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:33:38 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:33:39 --> Final output sent to browser
DEBUG - 2011-04-03 05:33:39 --> Total execution time: 0.6554
DEBUG - 2011-04-03 05:34:43 --> Config Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:34:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:34:43 --> URI Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Router Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Output Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Input Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:34:43 --> Language Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Loader Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Controller Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Model Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Model Class Initialized
DEBUG - 2011-04-03 05:34:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:34:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:34:44 --> Final output sent to browser
DEBUG - 2011-04-03 05:34:44 --> Total execution time: 1.0716
DEBUG - 2011-04-03 05:37:47 --> Config Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:37:47 --> URI Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Router Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Output Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Input Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:37:47 --> Language Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Loader Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Controller Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Model Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Model Class Initialized
DEBUG - 2011-04-03 05:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:37:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:37:48 --> Final output sent to browser
DEBUG - 2011-04-03 05:37:48 --> Total execution time: 0.5063
DEBUG - 2011-04-03 05:38:00 --> Config Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:38:00 --> URI Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Router Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Output Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Input Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:38:00 --> Language Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Loader Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Controller Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Model Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Model Class Initialized
DEBUG - 2011-04-03 05:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:38:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:38:01 --> Final output sent to browser
DEBUG - 2011-04-03 05:38:01 --> Total execution time: 0.4743
DEBUG - 2011-04-03 05:47:32 --> Config Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:47:32 --> URI Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Router Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Output Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Input Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:47:32 --> Language Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Loader Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Controller Class Initialized
ERROR - 2011-04-03 05:47:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 05:47:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 05:47:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 05:47:32 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:47:32 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:47:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 05:47:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 05:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 05:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 05:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 05:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 05:47:33 --> Final output sent to browser
DEBUG - 2011-04-03 05:47:33 --> Total execution time: 0.4904
DEBUG - 2011-04-03 05:47:34 --> Config Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:47:34 --> URI Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Router Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Output Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Input Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:47:34 --> Language Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Loader Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Controller Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:47:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:47:34 --> Final output sent to browser
DEBUG - 2011-04-03 05:47:34 --> Total execution time: 0.4992
DEBUG - 2011-04-03 05:47:35 --> Config Class Initialized
DEBUG - 2011-04-03 05:47:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:47:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:47:35 --> URI Class Initialized
DEBUG - 2011-04-03 05:47:35 --> Router Class Initialized
ERROR - 2011-04-03 05:47:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 05:47:37 --> Config Class Initialized
DEBUG - 2011-04-03 05:47:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:47:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:47:37 --> URI Class Initialized
DEBUG - 2011-04-03 05:47:37 --> Router Class Initialized
ERROR - 2011-04-03 05:47:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 05:47:54 --> Config Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:47:54 --> URI Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Router Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Output Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Input Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:47:54 --> Language Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Loader Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Controller Class Initialized
ERROR - 2011-04-03 05:47:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 05:47:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 05:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 05:47:54 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:47:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 05:47:54 --> Helper loaded: url_helper
DEBUG - 2011-04-03 05:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 05:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 05:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 05:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 05:47:54 --> Final output sent to browser
DEBUG - 2011-04-03 05:47:54 --> Total execution time: 0.0320
DEBUG - 2011-04-03 05:47:55 --> Config Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:47:55 --> URI Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Router Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Output Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Input Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:47:55 --> Language Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Loader Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Controller Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Model Class Initialized
DEBUG - 2011-04-03 05:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:47:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:48:00 --> Final output sent to browser
DEBUG - 2011-04-03 05:48:00 --> Total execution time: 5.5986
DEBUG - 2011-04-03 05:48:29 --> Config Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:48:29 --> URI Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Router Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Output Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Input Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:48:29 --> Language Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Loader Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Controller Class Initialized
ERROR - 2011-04-03 05:48:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 05:48:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 05:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 05:48:29 --> Model Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Model Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:48:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 05:48:29 --> Helper loaded: url_helper
DEBUG - 2011-04-03 05:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 05:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 05:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 05:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 05:48:29 --> Final output sent to browser
DEBUG - 2011-04-03 05:48:29 --> Total execution time: 0.0279
DEBUG - 2011-04-03 05:48:29 --> Config Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:48:29 --> URI Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Router Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Output Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Input Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:48:29 --> Language Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Loader Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Controller Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Model Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Model Class Initialized
DEBUG - 2011-04-03 05:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:48:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:48:31 --> Final output sent to browser
DEBUG - 2011-04-03 05:48:31 --> Total execution time: 1.1964
DEBUG - 2011-04-03 05:50:47 --> Config Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:50:47 --> URI Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Router Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Output Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Input Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:50:47 --> Language Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Loader Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Controller Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Model Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Model Class Initialized
DEBUG - 2011-04-03 05:50:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:50:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:50:48 --> Final output sent to browser
DEBUG - 2011-04-03 05:50:48 --> Total execution time: 0.4775
DEBUG - 2011-04-03 05:57:20 --> Config Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 05:57:20 --> URI Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Router Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Output Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Input Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 05:57:20 --> Language Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Loader Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Controller Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Model Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Model Class Initialized
DEBUG - 2011-04-03 05:57:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 05:57:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 05:57:22 --> Final output sent to browser
DEBUG - 2011-04-03 05:57:22 --> Total execution time: 1.4120
DEBUG - 2011-04-03 06:12:06 --> Config Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:12:06 --> URI Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Router Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Output Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Input Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:12:06 --> Language Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Loader Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Controller Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Model Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Model Class Initialized
DEBUG - 2011-04-03 06:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:12:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:12:07 --> Final output sent to browser
DEBUG - 2011-04-03 06:12:07 --> Total execution time: 0.6684
DEBUG - 2011-04-03 06:18:44 --> Config Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:18:44 --> URI Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Router Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Output Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Input Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:18:44 --> Language Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Loader Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Controller Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Model Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Model Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:18:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:18:44 --> Final output sent to browser
DEBUG - 2011-04-03 06:18:44 --> Total execution time: 0.6160
DEBUG - 2011-04-03 06:18:57 --> Config Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:18:57 --> URI Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Router Class Initialized
DEBUG - 2011-04-03 06:18:57 --> No URI present. Default controller set.
DEBUG - 2011-04-03 06:18:57 --> Output Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Input Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:18:57 --> Language Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Loader Class Initialized
DEBUG - 2011-04-03 06:18:57 --> Controller Class Initialized
DEBUG - 2011-04-03 06:18:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 06:18:57 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:18:57 --> Final output sent to browser
DEBUG - 2011-04-03 06:18:57 --> Total execution time: 0.1484
DEBUG - 2011-04-03 06:19:01 --> Config Class Initialized
DEBUG - 2011-04-03 06:19:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:19:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:19:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:19:01 --> URI Class Initialized
DEBUG - 2011-04-03 06:19:01 --> Router Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Config Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:19:02 --> URI Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Router Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Output Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Input Class Initialized
DEBUG - 2011-04-03 06:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:19:02 --> Language Class Initialized
DEBUG - 2011-04-03 06:19:03 --> Loader Class Initialized
DEBUG - 2011-04-03 06:19:03 --> Controller Class Initialized
DEBUG - 2011-04-03 06:19:03 --> Model Class Initialized
ERROR - 2011-04-03 06:19:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 06:19:03 --> Model Class Initialized
DEBUG - 2011-04-03 06:19:04 --> Model Class Initialized
DEBUG - 2011-04-03 06:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:19:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:19:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:19:04 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:19:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:19:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:19:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:19:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:19:04 --> Final output sent to browser
DEBUG - 2011-04-03 06:19:04 --> Total execution time: 1.9468
DEBUG - 2011-04-03 06:19:21 --> Config Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:19:21 --> URI Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Router Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Output Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Input Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:19:21 --> Language Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Loader Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Controller Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Model Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Model Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Model Class Initialized
DEBUG - 2011-04-03 06:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:19:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:19:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:19:22 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:19:22 --> Final output sent to browser
DEBUG - 2011-04-03 06:19:22 --> Total execution time: 0.3143
DEBUG - 2011-04-03 06:20:07 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:07 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:07 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:07 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:07 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:07 --> Total execution time: 0.2010
DEBUG - 2011-04-03 06:20:08 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:08 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:08 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:08 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:08 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:08 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:08 --> Total execution time: 0.0433
DEBUG - 2011-04-03 06:20:19 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:19 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:19 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:19 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:19 --> Total execution time: 0.2181
DEBUG - 2011-04-03 06:20:24 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:24 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:24 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:24 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:24 --> Total execution time: 0.0423
DEBUG - 2011-04-03 06:20:36 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:36 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:36 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:36 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:36 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:36 --> Total execution time: 0.3002
DEBUG - 2011-04-03 06:20:37 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:37 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:37 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:37 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:37 --> Total execution time: 0.0478
DEBUG - 2011-04-03 06:20:47 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:47 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:47 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:48 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:48 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:48 --> Total execution time: 0.2550
DEBUG - 2011-04-03 06:20:54 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:54 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:54 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:54 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:54 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:54 --> Total execution time: 0.3039
DEBUG - 2011-04-03 06:20:55 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:55 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:55 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:55 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:55 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:55 --> Total execution time: 0.0513
DEBUG - 2011-04-03 06:20:55 --> Config Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:20:55 --> URI Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Router Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Output Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Input Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:20:55 --> Language Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Loader Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Controller Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 06:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:20:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:20:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:20:56 --> Final output sent to browser
DEBUG - 2011-04-03 06:20:56 --> Total execution time: 0.0453
DEBUG - 2011-04-03 06:21:02 --> Config Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:21:02 --> URI Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Router Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Output Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Input Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:21:02 --> Language Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Loader Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Controller Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Model Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Model Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Model Class Initialized
DEBUG - 2011-04-03 06:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:21:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:21:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:21:02 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:21:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:21:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:21:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:21:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:21:02 --> Final output sent to browser
DEBUG - 2011-04-03 06:21:02 --> Total execution time: 0.1911
DEBUG - 2011-04-03 06:21:43 --> Config Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:21:43 --> URI Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Router Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Output Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Input Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:21:43 --> Language Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Loader Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Controller Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Model Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Model Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Model Class Initialized
DEBUG - 2011-04-03 06:21:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:21:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:21:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:21:43 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:21:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:21:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:21:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:21:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:21:43 --> Final output sent to browser
DEBUG - 2011-04-03 06:21:43 --> Total execution time: 0.2540
DEBUG - 2011-04-03 06:27:33 --> Config Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:27:33 --> URI Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Router Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Output Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Input Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:27:33 --> Language Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Loader Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Controller Class Initialized
DEBUG - 2011-04-03 06:27:33 --> Model Class Initialized
DEBUG - 2011-04-03 06:27:34 --> Model Class Initialized
DEBUG - 2011-04-03 06:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:27:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:27:35 --> Final output sent to browser
DEBUG - 2011-04-03 06:27:35 --> Total execution time: 2.9651
DEBUG - 2011-04-03 06:31:00 --> Config Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:31:00 --> URI Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Router Class Initialized
DEBUG - 2011-04-03 06:31:00 --> No URI present. Default controller set.
DEBUG - 2011-04-03 06:31:00 --> Output Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Input Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:31:00 --> Language Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Loader Class Initialized
DEBUG - 2011-04-03 06:31:00 --> Controller Class Initialized
DEBUG - 2011-04-03 06:31:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 06:31:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:31:00 --> Final output sent to browser
DEBUG - 2011-04-03 06:31:00 --> Total execution time: 0.1245
DEBUG - 2011-04-03 06:31:01 --> Config Class Initialized
DEBUG - 2011-04-03 06:31:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:31:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:31:01 --> URI Class Initialized
DEBUG - 2011-04-03 06:31:01 --> Router Class Initialized
ERROR - 2011-04-03 06:31:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 06:31:01 --> Config Class Initialized
DEBUG - 2011-04-03 06:31:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:31:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:31:01 --> URI Class Initialized
DEBUG - 2011-04-03 06:31:01 --> Router Class Initialized
ERROR - 2011-04-03 06:31:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 06:31:02 --> Config Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:31:02 --> URI Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Router Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Output Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Input Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:31:02 --> Language Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Loader Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Controller Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Model Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Model Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Model Class Initialized
DEBUG - 2011-04-03 06:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:31:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:31:02 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:31:02 --> Final output sent to browser
DEBUG - 2011-04-03 06:31:02 --> Total execution time: 0.1693
DEBUG - 2011-04-03 06:31:04 --> Config Class Initialized
DEBUG - 2011-04-03 06:31:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:31:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:31:04 --> URI Class Initialized
DEBUG - 2011-04-03 06:31:04 --> Router Class Initialized
ERROR - 2011-04-03 06:31:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 06:36:25 --> Config Class Initialized
DEBUG - 2011-04-03 06:36:25 --> Config Class Initialized
DEBUG - 2011-04-03 06:36:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:36:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:36:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:36:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:36:25 --> URI Class Initialized
DEBUG - 2011-04-03 06:36:25 --> URI Class Initialized
DEBUG - 2011-04-03 06:36:25 --> Router Class Initialized
DEBUG - 2011-04-03 06:36:25 --> Router Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Output Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Output Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Input Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Input Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:36:26 --> Language Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Language Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Loader Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Loader Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Controller Class Initialized
DEBUG - 2011-04-03 06:36:26 --> Controller Class Initialized
DEBUG - 2011-04-03 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-03 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-03 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-03 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-03 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-03 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-03 06:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:36:28 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:36:28 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:36:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 06:36:30 --> Final output sent to browser
DEBUG - 2011-04-03 06:36:30 --> Total execution time: 4.9682
DEBUG - 2011-04-03 06:36:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:36:30 --> Final output sent to browser
DEBUG - 2011-04-03 06:36:30 --> Total execution time: 4.9710
DEBUG - 2011-04-03 06:36:34 --> Config Class Initialized
DEBUG - 2011-04-03 06:36:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:36:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:36:34 --> URI Class Initialized
DEBUG - 2011-04-03 06:36:34 --> Router Class Initialized
ERROR - 2011-04-03 06:36:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 06:41:12 --> Config Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:41:12 --> URI Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Router Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Output Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Input Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:41:12 --> Language Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Loader Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Controller Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Model Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Model Class Initialized
DEBUG - 2011-04-03 06:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:41:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:41:13 --> Final output sent to browser
DEBUG - 2011-04-03 06:41:13 --> Total execution time: 0.5873
DEBUG - 2011-04-03 06:43:37 --> Config Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:43:37 --> URI Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Router Class Initialized
DEBUG - 2011-04-03 06:43:37 --> No URI present. Default controller set.
DEBUG - 2011-04-03 06:43:37 --> Output Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Input Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:43:37 --> Language Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Loader Class Initialized
DEBUG - 2011-04-03 06:43:37 --> Controller Class Initialized
DEBUG - 2011-04-03 06:43:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 06:43:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 06:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 06:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 06:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 06:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 06:43:37 --> Final output sent to browser
DEBUG - 2011-04-03 06:43:37 --> Total execution time: 0.0641
DEBUG - 2011-04-03 06:43:41 --> Config Class Initialized
DEBUG - 2011-04-03 06:43:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:43:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:43:41 --> URI Class Initialized
DEBUG - 2011-04-03 06:43:41 --> Router Class Initialized
ERROR - 2011-04-03 06:43:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 06:55:03 --> Config Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 06:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 06:55:03 --> URI Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Router Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Output Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Input Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 06:55:03 --> Language Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Loader Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Controller Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Model Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Model Class Initialized
DEBUG - 2011-04-03 06:55:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 06:55:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 06:55:04 --> Final output sent to browser
DEBUG - 2011-04-03 06:55:04 --> Total execution time: 1.2365
DEBUG - 2011-04-03 07:00:23 --> Config Class Initialized
DEBUG - 2011-04-03 07:00:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:00:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:00:23 --> URI Class Initialized
DEBUG - 2011-04-03 07:00:23 --> Router Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Output Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Input Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:00:24 --> Language Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Loader Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Controller Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Model Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Model Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:00:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:00:24 --> Final output sent to browser
DEBUG - 2011-04-03 07:00:24 --> Total execution time: 1.4625
DEBUG - 2011-04-03 07:07:35 --> Config Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:07:35 --> URI Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Router Class Initialized
DEBUG - 2011-04-03 07:07:35 --> No URI present. Default controller set.
DEBUG - 2011-04-03 07:07:35 --> Output Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Input Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:07:35 --> Language Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Loader Class Initialized
DEBUG - 2011-04-03 07:07:35 --> Controller Class Initialized
DEBUG - 2011-04-03 07:07:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 07:07:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:07:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:07:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:07:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:07:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:07:35 --> Final output sent to browser
DEBUG - 2011-04-03 07:07:35 --> Total execution time: 0.2498
DEBUG - 2011-04-03 07:07:41 --> Config Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:07:41 --> URI Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Router Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Output Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Input Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:07:41 --> Language Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Loader Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Controller Class Initialized
ERROR - 2011-04-03 07:07:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 07:07:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 07:07:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:07:41 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:07:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:07:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:07:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:07:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:07:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:07:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:07:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:07:41 --> Final output sent to browser
DEBUG - 2011-04-03 07:07:41 --> Total execution time: 0.1905
DEBUG - 2011-04-03 07:07:42 --> Config Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:07:42 --> URI Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Router Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Output Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Input Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:07:42 --> Language Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Loader Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Controller Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:07:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:07:43 --> Final output sent to browser
DEBUG - 2011-04-03 07:07:43 --> Total execution time: 1.1028
DEBUG - 2011-04-03 07:07:53 --> Config Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:07:53 --> URI Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Router Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Output Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Input Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:07:53 --> Language Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Loader Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Controller Class Initialized
ERROR - 2011-04-03 07:07:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 07:07:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 07:07:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:07:53 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:07:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:07:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:07:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:07:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:07:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:07:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:07:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:07:53 --> Final output sent to browser
DEBUG - 2011-04-03 07:07:53 --> Total execution time: 0.0282
DEBUG - 2011-04-03 07:07:54 --> Config Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:07:54 --> URI Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Router Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Output Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Input Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:07:54 --> Language Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Loader Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Controller Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Model Class Initialized
DEBUG - 2011-04-03 07:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:07:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:07:55 --> Final output sent to browser
DEBUG - 2011-04-03 07:07:55 --> Total execution time: 0.5165
DEBUG - 2011-04-03 07:09:36 --> Config Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:09:36 --> URI Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Router Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Output Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Input Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:09:36 --> Language Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Loader Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Controller Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Model Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Model Class Initialized
DEBUG - 2011-04-03 07:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:09:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:09:37 --> Final output sent to browser
DEBUG - 2011-04-03 07:09:37 --> Total execution time: 0.8560
DEBUG - 2011-04-03 07:17:48 --> Config Class Initialized
DEBUG - 2011-04-03 07:17:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:17:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:17:49 --> URI Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Router Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Output Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Input Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:17:50 --> Language Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Loader Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Controller Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Model Class Initialized
DEBUG - 2011-04-03 07:17:50 --> Model Class Initialized
DEBUG - 2011-04-03 07:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:17:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:17:52 --> Final output sent to browser
DEBUG - 2011-04-03 07:17:52 --> Total execution time: 5.0045
DEBUG - 2011-04-03 07:20:09 --> Config Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:20:09 --> URI Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Router Class Initialized
DEBUG - 2011-04-03 07:20:09 --> No URI present. Default controller set.
DEBUG - 2011-04-03 07:20:09 --> Output Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Input Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:20:09 --> Language Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Loader Class Initialized
DEBUG - 2011-04-03 07:20:09 --> Controller Class Initialized
DEBUG - 2011-04-03 07:20:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 07:20:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:20:09 --> Final output sent to browser
DEBUG - 2011-04-03 07:20:09 --> Total execution time: 0.0901
DEBUG - 2011-04-03 07:20:21 --> Config Class Initialized
DEBUG - 2011-04-03 07:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:20:21 --> URI Class Initialized
DEBUG - 2011-04-03 07:20:21 --> Router Class Initialized
ERROR - 2011-04-03 07:20:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 07:20:22 --> Config Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:20:22 --> URI Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Router Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Output Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Input Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:20:22 --> Language Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Loader Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Controller Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:20:22 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:20:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:20:22 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:20:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:20:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:20:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:20:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:20:22 --> Final output sent to browser
DEBUG - 2011-04-03 07:20:22 --> Total execution time: 0.3101
DEBUG - 2011-04-03 07:20:34 --> Config Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:20:34 --> URI Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Router Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Output Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Input Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:20:34 --> Language Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Loader Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Controller Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:20:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:20:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:20:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:20:35 --> Final output sent to browser
DEBUG - 2011-04-03 07:20:35 --> Total execution time: 0.5613
DEBUG - 2011-04-03 07:20:51 --> Config Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:20:51 --> URI Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Router Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Output Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Input Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:20:51 --> Language Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Loader Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Controller Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Model Class Initialized
DEBUG - 2011-04-03 07:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:20:51 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:20:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:20:52 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:20:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:20:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:20:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:20:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:20:52 --> Final output sent to browser
DEBUG - 2011-04-03 07:20:52 --> Total execution time: 0.2847
DEBUG - 2011-04-03 07:21:01 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:01 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:01 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:01 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:01 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:01 --> Total execution time: 0.3040
DEBUG - 2011-04-03 07:21:12 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:12 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:12 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:12 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:12 --> Total execution time: 0.2384
DEBUG - 2011-04-03 07:21:20 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:20 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:20 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:20 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:20 --> Total execution time: 0.0448
DEBUG - 2011-04-03 07:21:21 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:21 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:21 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:21 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:21 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:21 --> Total execution time: 0.0492
DEBUG - 2011-04-03 07:21:24 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:24 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:24 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:24 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:24 --> Total execution time: 0.2262
DEBUG - 2011-04-03 07:21:34 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:34 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:34 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:35 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:35 --> Total execution time: 0.9548
DEBUG - 2011-04-03 07:21:40 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:40 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:40 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:40 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:40 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:40 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:40 --> Total execution time: 0.2491
DEBUG - 2011-04-03 07:21:46 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:46 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:46 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:46 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:46 --> Total execution time: 0.1980
DEBUG - 2011-04-03 07:21:49 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:49 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:49 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:49 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:49 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:49 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:49 --> Total execution time: 0.0889
DEBUG - 2011-04-03 07:21:52 --> Config Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:21:52 --> URI Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Router Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Output Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Input Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:21:52 --> Language Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Loader Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Controller Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Model Class Initialized
DEBUG - 2011-04-03 07:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:21:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:21:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:21:53 --> Final output sent to browser
DEBUG - 2011-04-03 07:21:53 --> Total execution time: 0.3359
DEBUG - 2011-04-03 07:25:16 --> Config Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:25:16 --> URI Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Router Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Output Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Input Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:25:16 --> Language Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Loader Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Controller Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Model Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Model Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Model Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:25:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:25:16 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:25:16 --> Final output sent to browser
DEBUG - 2011-04-03 07:25:16 --> Total execution time: 0.0804
DEBUG - 2011-04-03 07:25:16 --> Config Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:25:16 --> URI Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Router Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Output Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Input Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:25:16 --> Language Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Loader Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Controller Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Model Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Model Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Model Class Initialized
DEBUG - 2011-04-03 07:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:25:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 07:25:16 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:25:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:25:16 --> Final output sent to browser
DEBUG - 2011-04-03 07:25:16 --> Total execution time: 0.0436
DEBUG - 2011-04-03 07:46:43 --> Config Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:46:43 --> URI Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Router Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Output Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Input Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:46:43 --> Language Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Loader Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Controller Class Initialized
ERROR - 2011-04-03 07:46:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 07:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 07:46:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:46:43 --> Model Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Model Class Initialized
DEBUG - 2011-04-03 07:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:46:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:46:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:46:43 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:46:43 --> Final output sent to browser
DEBUG - 2011-04-03 07:46:43 --> Total execution time: 0.2996
DEBUG - 2011-04-03 07:46:44 --> Config Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:46:44 --> URI Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Router Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Output Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Input Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:46:44 --> Language Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Loader Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Controller Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Model Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Model Class Initialized
DEBUG - 2011-04-03 07:46:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:46:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:46:45 --> Final output sent to browser
DEBUG - 2011-04-03 07:46:45 --> Total execution time: 0.6103
DEBUG - 2011-04-03 07:46:47 --> Config Class Initialized
DEBUG - 2011-04-03 07:46:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:46:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:46:47 --> URI Class Initialized
DEBUG - 2011-04-03 07:46:47 --> Router Class Initialized
ERROR - 2011-04-03 07:46:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 07:47:06 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:06 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Router Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Output Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Input Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:47:06 --> Language Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Loader Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Controller Class Initialized
ERROR - 2011-04-03 07:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 07:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 07:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:47:06 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:47:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:47:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:47:06 --> Final output sent to browser
DEBUG - 2011-04-03 07:47:06 --> Total execution time: 0.0921
DEBUG - 2011-04-03 07:47:07 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:07 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Router Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Output Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Input Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:47:07 --> Language Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Loader Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Controller Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:47:08 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:47:08 --> Final output sent to browser
DEBUG - 2011-04-03 07:47:08 --> Total execution time: 0.8291
DEBUG - 2011-04-03 07:47:10 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:10 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:10 --> Router Class Initialized
ERROR - 2011-04-03 07:47:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 07:47:20 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:20 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Router Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Output Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Input Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:47:20 --> Language Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Loader Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Controller Class Initialized
ERROR - 2011-04-03 07:47:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 07:47:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 07:47:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:47:20 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:47:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:47:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:47:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:47:20 --> Final output sent to browser
DEBUG - 2011-04-03 07:47:20 --> Total execution time: 0.0276
DEBUG - 2011-04-03 07:47:21 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:21 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Router Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Output Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Input Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:47:21 --> Language Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Loader Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Controller Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:47:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:47:22 --> Final output sent to browser
DEBUG - 2011-04-03 07:47:22 --> Total execution time: 0.5598
DEBUG - 2011-04-03 07:47:24 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:24 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:24 --> Router Class Initialized
ERROR - 2011-04-03 07:47:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 07:47:30 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:30 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Router Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Output Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Input Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:47:30 --> Language Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Loader Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Controller Class Initialized
ERROR - 2011-04-03 07:47:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 07:47:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 07:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:47:30 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:47:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 07:47:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 07:47:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 07:47:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 07:47:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 07:47:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 07:47:30 --> Final output sent to browser
DEBUG - 2011-04-03 07:47:30 --> Total execution time: 0.0277
DEBUG - 2011-04-03 07:47:31 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:31 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Router Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Output Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Input Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 07:47:31 --> Language Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Loader Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Controller Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Model Class Initialized
DEBUG - 2011-04-03 07:47:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 07:47:31 --> Database Driver Class Initialized
DEBUG - 2011-04-03 07:47:32 --> Final output sent to browser
DEBUG - 2011-04-03 07:47:32 --> Total execution time: 0.6812
DEBUG - 2011-04-03 07:47:34 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:34 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:34 --> Router Class Initialized
ERROR - 2011-04-03 07:47:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 07:47:41 --> Config Class Initialized
DEBUG - 2011-04-03 07:47:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 07:47:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 07:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 07:47:41 --> URI Class Initialized
DEBUG - 2011-04-03 07:47:41 --> Router Class Initialized
ERROR - 2011-04-03 07:47:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 08:03:06 --> Config Class Initialized
DEBUG - 2011-04-03 08:03:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:03:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:03:06 --> URI Class Initialized
DEBUG - 2011-04-03 08:03:06 --> Router Class Initialized
ERROR - 2011-04-03 08:03:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 08:33:53 --> Config Class Initialized
DEBUG - 2011-04-03 08:33:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:33:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:33:53 --> URI Class Initialized
DEBUG - 2011-04-03 08:33:53 --> Router Class Initialized
DEBUG - 2011-04-03 08:33:53 --> Output Class Initialized
DEBUG - 2011-04-03 08:33:53 --> Input Class Initialized
DEBUG - 2011-04-03 08:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:33:53 --> Language Class Initialized
DEBUG - 2011-04-03 08:33:54 --> Loader Class Initialized
DEBUG - 2011-04-03 08:33:54 --> Controller Class Initialized
DEBUG - 2011-04-03 08:33:54 --> Model Class Initialized
DEBUG - 2011-04-03 08:33:54 --> Model Class Initialized
DEBUG - 2011-04-03 08:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:33:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:33:55 --> Final output sent to browser
DEBUG - 2011-04-03 08:33:55 --> Total execution time: 1.3388
DEBUG - 2011-04-03 08:40:06 --> Config Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:40:06 --> URI Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Router Class Initialized
DEBUG - 2011-04-03 08:40:06 --> No URI present. Default controller set.
DEBUG - 2011-04-03 08:40:06 --> Output Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Input Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:40:06 --> Language Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Loader Class Initialized
DEBUG - 2011-04-03 08:40:06 --> Controller Class Initialized
DEBUG - 2011-04-03 08:40:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 08:40:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 08:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 08:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 08:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 08:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 08:40:06 --> Final output sent to browser
DEBUG - 2011-04-03 08:40:06 --> Total execution time: 0.2323
DEBUG - 2011-04-03 08:40:40 --> Config Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:40:40 --> URI Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Router Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Output Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Input Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:40:40 --> Language Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Loader Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Controller Class Initialized
ERROR - 2011-04-03 08:40:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 08:40:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 08:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 08:40:40 --> Model Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Model Class Initialized
DEBUG - 2011-04-03 08:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:40:40 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 08:40:40 --> Helper loaded: url_helper
DEBUG - 2011-04-03 08:40:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 08:40:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 08:40:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 08:40:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 08:40:40 --> Final output sent to browser
DEBUG - 2011-04-03 08:40:40 --> Total execution time: 0.1565
DEBUG - 2011-04-03 08:40:42 --> Config Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:40:42 --> URI Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Router Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Output Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Input Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:40:42 --> Language Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Loader Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Controller Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Model Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Model Class Initialized
DEBUG - 2011-04-03 08:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:40:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:40:43 --> Final output sent to browser
DEBUG - 2011-04-03 08:40:43 --> Total execution time: 1.1306
DEBUG - 2011-04-03 08:40:45 --> Config Class Initialized
DEBUG - 2011-04-03 08:40:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:40:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:40:45 --> URI Class Initialized
DEBUG - 2011-04-03 08:40:45 --> Router Class Initialized
ERROR - 2011-04-03 08:40:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 08:40:48 --> Config Class Initialized
DEBUG - 2011-04-03 08:40:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:40:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:40:48 --> URI Class Initialized
DEBUG - 2011-04-03 08:40:48 --> Router Class Initialized
ERROR - 2011-04-03 08:40:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 08:45:45 --> Config Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:45:45 --> URI Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Router Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Output Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Input Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:45:45 --> Language Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Loader Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Controller Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Model Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Model Class Initialized
DEBUG - 2011-04-03 08:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:45:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:45:46 --> Final output sent to browser
DEBUG - 2011-04-03 08:45:46 --> Total execution time: 1.7429
DEBUG - 2011-04-03 08:55:50 --> Config Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:55:50 --> URI Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Router Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Output Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Input Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:55:50 --> Language Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Loader Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Controller Class Initialized
ERROR - 2011-04-03 08:55:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 08:55:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 08:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 08:55:50 --> Model Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Model Class Initialized
DEBUG - 2011-04-03 08:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:55:51 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:55:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 08:55:51 --> Helper loaded: url_helper
DEBUG - 2011-04-03 08:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 08:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 08:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 08:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 08:55:51 --> Final output sent to browser
DEBUG - 2011-04-03 08:55:51 --> Total execution time: 1.4349
DEBUG - 2011-04-03 08:55:55 --> Config Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:55:55 --> URI Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Router Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Output Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Input Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:55:55 --> Language Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Loader Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Controller Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Model Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Model Class Initialized
DEBUG - 2011-04-03 08:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:55:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:55:56 --> Final output sent to browser
DEBUG - 2011-04-03 08:55:56 --> Total execution time: 0.7595
DEBUG - 2011-04-03 08:56:12 --> Config Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:56:12 --> URI Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Router Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Output Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Input Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:56:12 --> Language Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Loader Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Controller Class Initialized
ERROR - 2011-04-03 08:56:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 08:56:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 08:56:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 08:56:12 --> Model Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Model Class Initialized
DEBUG - 2011-04-03 08:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:56:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:56:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 08:56:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 08:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 08:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 08:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 08:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 08:56:12 --> Final output sent to browser
DEBUG - 2011-04-03 08:56:12 --> Total execution time: 0.0281
DEBUG - 2011-04-03 08:56:13 --> Config Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:56:13 --> URI Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Router Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Output Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Input Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:56:13 --> Language Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Loader Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Controller Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Model Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Model Class Initialized
DEBUG - 2011-04-03 08:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:56:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:56:14 --> Final output sent to browser
DEBUG - 2011-04-03 08:56:14 --> Total execution time: 0.6169
DEBUG - 2011-04-03 08:58:17 --> Config Class Initialized
DEBUG - 2011-04-03 08:58:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:58:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:58:17 --> URI Class Initialized
DEBUG - 2011-04-03 08:58:17 --> Router Class Initialized
ERROR - 2011-04-03 08:58:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 08:58:20 --> Config Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 08:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 08:58:20 --> URI Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Router Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Output Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Input Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 08:58:20 --> Language Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Loader Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Controller Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Model Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Model Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Model Class Initialized
DEBUG - 2011-04-03 08:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 08:58:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 08:58:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 08:58:21 --> Helper loaded: url_helper
DEBUG - 2011-04-03 08:58:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 08:58:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 08:58:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 08:58:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 08:58:21 --> Final output sent to browser
DEBUG - 2011-04-03 08:58:21 --> Total execution time: 0.4049
DEBUG - 2011-04-03 09:00:26 --> Config Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:00:26 --> URI Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Router Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Output Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Input Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:00:26 --> Language Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Loader Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Controller Class Initialized
ERROR - 2011-04-03 09:00:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:00:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:00:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:00:26 --> Model Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Model Class Initialized
DEBUG - 2011-04-03 09:00:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:00:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:00:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:00:26 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:00:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:00:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:00:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:00:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:00:26 --> Final output sent to browser
DEBUG - 2011-04-03 09:00:26 --> Total execution time: 0.0369
DEBUG - 2011-04-03 09:00:29 --> Config Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:00:29 --> URI Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Router Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Output Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Input Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:00:29 --> Language Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Loader Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Controller Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Model Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Model Class Initialized
DEBUG - 2011-04-03 09:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:00:29 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:00:31 --> Final output sent to browser
DEBUG - 2011-04-03 09:00:31 --> Total execution time: 1.3796
DEBUG - 2011-04-03 09:00:56 --> Config Class Initialized
DEBUG - 2011-04-03 09:00:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:00:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:00:56 --> URI Class Initialized
DEBUG - 2011-04-03 09:00:56 --> Router Class Initialized
ERROR - 2011-04-03 09:00:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 09:01:56 --> Config Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:01:56 --> URI Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Router Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Output Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Input Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:01:56 --> Language Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Loader Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Controller Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Model Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Model Class Initialized
DEBUG - 2011-04-03 09:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:01:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:01:59 --> Final output sent to browser
DEBUG - 2011-04-03 09:01:59 --> Total execution time: 2.1941
DEBUG - 2011-04-03 09:02:10 --> Config Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:02:10 --> URI Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Router Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Output Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Input Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:02:10 --> Language Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Loader Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Controller Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Model Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Model Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:02:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:02:10 --> Final output sent to browser
DEBUG - 2011-04-03 09:02:10 --> Total execution time: 0.4749
DEBUG - 2011-04-03 09:28:30 --> Config Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:28:30 --> URI Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Router Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Output Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Input Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:28:30 --> Language Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Loader Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Controller Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Model Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Model Class Initialized
DEBUG - 2011-04-03 09:28:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:28:31 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:28:32 --> Final output sent to browser
DEBUG - 2011-04-03 09:28:32 --> Total execution time: 2.2008
DEBUG - 2011-04-03 09:36:28 --> Config Class Initialized
DEBUG - 2011-04-03 09:36:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:36:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:36:28 --> URI Class Initialized
DEBUG - 2011-04-03 09:36:28 --> Router Class Initialized
DEBUG - 2011-04-03 09:36:28 --> Output Class Initialized
DEBUG - 2011-04-03 09:36:29 --> Input Class Initialized
DEBUG - 2011-04-03 09:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:36:29 --> Language Class Initialized
DEBUG - 2011-04-03 09:36:29 --> Loader Class Initialized
DEBUG - 2011-04-03 09:36:29 --> Controller Class Initialized
DEBUG - 2011-04-03 09:36:29 --> Model Class Initialized
DEBUG - 2011-04-03 09:36:30 --> Model Class Initialized
DEBUG - 2011-04-03 09:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:36:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:36:31 --> Final output sent to browser
DEBUG - 2011-04-03 09:36:31 --> Total execution time: 4.4887
DEBUG - 2011-04-03 09:40:54 --> Config Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:40:54 --> URI Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Router Class Initialized
ERROR - 2011-04-03 09:40:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 09:40:54 --> Config Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:40:54 --> URI Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Router Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Output Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Input Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:40:54 --> Language Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Loader Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Controller Class Initialized
ERROR - 2011-04-03 09:40:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:40:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:40:54 --> Model Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Model Class Initialized
DEBUG - 2011-04-03 09:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:40:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:40:55 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:40:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:40:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:40:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:40:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:40:55 --> Final output sent to browser
DEBUG - 2011-04-03 09:40:55 --> Total execution time: 0.2110
DEBUG - 2011-04-03 09:44:51 --> Config Class Initialized
DEBUG - 2011-04-03 09:44:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:44:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:44:51 --> URI Class Initialized
DEBUG - 2011-04-03 09:44:51 --> Router Class Initialized
DEBUG - 2011-04-03 09:44:51 --> Output Class Initialized
DEBUG - 2011-04-03 09:44:51 --> Input Class Initialized
DEBUG - 2011-04-03 09:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:44:51 --> Language Class Initialized
DEBUG - 2011-04-03 09:44:52 --> Loader Class Initialized
DEBUG - 2011-04-03 09:44:52 --> Controller Class Initialized
DEBUG - 2011-04-03 09:44:52 --> Model Class Initialized
DEBUG - 2011-04-03 09:44:52 --> Model Class Initialized
DEBUG - 2011-04-03 09:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:44:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:44:52 --> Final output sent to browser
DEBUG - 2011-04-03 09:44:52 --> Total execution time: 0.5326
DEBUG - 2011-04-03 09:51:29 --> Config Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:51:30 --> URI Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Router Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Output Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Input Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:51:30 --> Language Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Loader Class Initialized
DEBUG - 2011-04-03 09:51:30 --> Controller Class Initialized
DEBUG - 2011-04-03 09:51:31 --> Model Class Initialized
DEBUG - 2011-04-03 09:51:31 --> Model Class Initialized
DEBUG - 2011-04-03 09:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:51:32 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:51:32 --> Final output sent to browser
DEBUG - 2011-04-03 09:51:32 --> Total execution time: 3.2490
DEBUG - 2011-04-03 09:52:27 --> Config Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:52:27 --> URI Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Router Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Output Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Input Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:52:27 --> Language Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Loader Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Controller Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Model Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Model Class Initialized
DEBUG - 2011-04-03 09:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:52:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:52:28 --> Final output sent to browser
DEBUG - 2011-04-03 09:52:28 --> Total execution time: 1.1609
DEBUG - 2011-04-03 09:53:26 --> Config Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:53:26 --> URI Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Router Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Output Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Input Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:53:26 --> Language Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Loader Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Controller Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Model Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Model Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Model Class Initialized
DEBUG - 2011-04-03 09:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:53:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:53:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 09:53:26 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:53:26 --> Final output sent to browser
DEBUG - 2011-04-03 09:53:26 --> Total execution time: 0.3942
DEBUG - 2011-04-03 09:58:09 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:09 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Router Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Output Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Input Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:58:09 --> Language Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Loader Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Controller Class Initialized
ERROR - 2011-04-03 09:58:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:58:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:58:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:58:09 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:58:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:58:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:58:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:58:09 --> Final output sent to browser
DEBUG - 2011-04-03 09:58:09 --> Total execution time: 0.1462
DEBUG - 2011-04-03 09:58:10 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:10 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Router Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Output Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Input Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:58:10 --> Language Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Loader Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Controller Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:58:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:58:11 --> Final output sent to browser
DEBUG - 2011-04-03 09:58:11 --> Total execution time: 0.4584
DEBUG - 2011-04-03 09:58:13 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:13 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:13 --> Router Class Initialized
ERROR - 2011-04-03 09:58:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 09:58:27 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:27 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Router Class Initialized
DEBUG - 2011-04-03 09:58:27 --> No URI present. Default controller set.
DEBUG - 2011-04-03 09:58:27 --> Output Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Input Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:58:27 --> Language Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Loader Class Initialized
DEBUG - 2011-04-03 09:58:27 --> Controller Class Initialized
DEBUG - 2011-04-03 09:58:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 09:58:27 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:58:27 --> Final output sent to browser
DEBUG - 2011-04-03 09:58:27 --> Total execution time: 0.0611
DEBUG - 2011-04-03 09:58:29 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:29 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:29 --> Router Class Initialized
ERROR - 2011-04-03 09:58:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 09:58:56 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:56 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Router Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Output Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Input Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:58:56 --> Language Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Loader Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Controller Class Initialized
ERROR - 2011-04-03 09:58:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:58:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:58:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:58:56 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:58:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:58:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:58:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:58:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:58:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:58:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:58:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:58:56 --> Final output sent to browser
DEBUG - 2011-04-03 09:58:56 --> Total execution time: 0.0294
DEBUG - 2011-04-03 09:58:57 --> Config Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:58:57 --> URI Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Router Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Output Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Input Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:58:57 --> Language Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Loader Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Controller Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Model Class Initialized
DEBUG - 2011-04-03 09:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:58:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:58:58 --> Final output sent to browser
DEBUG - 2011-04-03 09:58:58 --> Total execution time: 0.4980
DEBUG - 2011-04-03 09:59:14 --> Config Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:59:14 --> URI Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Router Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Output Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Input Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:59:14 --> Language Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Loader Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Controller Class Initialized
ERROR - 2011-04-03 09:59:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:59:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:59:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:59:14 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:59:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:59:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:59:14 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:59:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:59:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:59:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:59:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:59:14 --> Final output sent to browser
DEBUG - 2011-04-03 09:59:14 --> Total execution time: 0.0460
DEBUG - 2011-04-03 09:59:15 --> Config Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:59:15 --> URI Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Router Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Output Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Input Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:59:15 --> Language Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Loader Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Controller Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:59:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:59:16 --> Final output sent to browser
DEBUG - 2011-04-03 09:59:16 --> Total execution time: 0.9460
DEBUG - 2011-04-03 09:59:30 --> Config Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:59:30 --> URI Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Router Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Output Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Input Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:59:30 --> Language Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Loader Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Controller Class Initialized
ERROR - 2011-04-03 09:59:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:59:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:59:30 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:59:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:59:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:59:30 --> Final output sent to browser
DEBUG - 2011-04-03 09:59:30 --> Total execution time: 0.1186
DEBUG - 2011-04-03 09:59:32 --> Config Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:59:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:59:32 --> URI Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Router Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Output Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Input Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:59:32 --> Language Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Loader Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Controller Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:59:32 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:59:32 --> Final output sent to browser
DEBUG - 2011-04-03 09:59:32 --> Total execution time: 0.7001
DEBUG - 2011-04-03 09:59:42 --> Config Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:59:42 --> URI Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Router Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Output Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Input Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:59:42 --> Language Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Loader Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Controller Class Initialized
ERROR - 2011-04-03 09:59:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 09:59:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 09:59:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:59:42 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:59:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:59:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 09:59:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 09:59:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 09:59:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 09:59:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 09:59:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 09:59:42 --> Final output sent to browser
DEBUG - 2011-04-03 09:59:42 --> Total execution time: 0.0282
DEBUG - 2011-04-03 09:59:43 --> Config Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 09:59:43 --> URI Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Router Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Output Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Input Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 09:59:43 --> Language Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Loader Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Controller Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Model Class Initialized
DEBUG - 2011-04-03 09:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 09:59:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 09:59:44 --> Final output sent to browser
DEBUG - 2011-04-03 09:59:44 --> Total execution time: 0.5329
DEBUG - 2011-04-03 10:00:02 --> Config Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:00:02 --> URI Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Router Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Output Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Input Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:00:02 --> Language Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Loader Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Controller Class Initialized
ERROR - 2011-04-03 10:00:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:00:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:00:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:00:02 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:00:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:00:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:00:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:00:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:00:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:00:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:00:03 --> Final output sent to browser
DEBUG - 2011-04-03 10:00:03 --> Total execution time: 0.2914
DEBUG - 2011-04-03 10:00:04 --> Config Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:00:04 --> URI Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Router Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Output Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Input Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:00:04 --> Language Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Loader Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Controller Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:00:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:00:05 --> Final output sent to browser
DEBUG - 2011-04-03 10:00:05 --> Total execution time: 0.6511
DEBUG - 2011-04-03 10:00:22 --> Config Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:00:22 --> URI Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Router Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Output Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Input Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:00:22 --> Language Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Loader Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Controller Class Initialized
ERROR - 2011-04-03 10:00:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:00:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:00:22 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:00:22 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:00:22 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:00:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:00:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:00:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:00:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:00:22 --> Final output sent to browser
DEBUG - 2011-04-03 10:00:22 --> Total execution time: 0.0303
DEBUG - 2011-04-03 10:00:24 --> Config Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:00:24 --> URI Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Router Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Output Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Input Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:00:24 --> Language Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Loader Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Controller Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:00:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:00:24 --> Final output sent to browser
DEBUG - 2011-04-03 10:00:24 --> Total execution time: 0.5647
DEBUG - 2011-04-03 10:00:48 --> Config Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:00:48 --> URI Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Router Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Output Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Input Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:00:48 --> Language Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Loader Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Controller Class Initialized
ERROR - 2011-04-03 10:00:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:00:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:00:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:00:48 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:00:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:00:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:00:48 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:00:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:00:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:00:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:00:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:00:48 --> Final output sent to browser
DEBUG - 2011-04-03 10:00:48 --> Total execution time: 0.0943
DEBUG - 2011-04-03 10:00:49 --> Config Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:00:49 --> URI Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Router Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Output Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Input Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:00:49 --> Language Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Loader Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Controller Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Model Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:00:49 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:00:49 --> Final output sent to browser
DEBUG - 2011-04-03 10:00:49 --> Total execution time: 0.5491
DEBUG - 2011-04-03 10:01:12 --> Config Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:01:12 --> URI Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Router Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Output Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Input Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:01:12 --> Language Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Loader Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Controller Class Initialized
ERROR - 2011-04-03 10:01:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:01:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:01:12 --> Model Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Model Class Initialized
DEBUG - 2011-04-03 10:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:01:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:01:13 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:01:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:01:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:01:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:01:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:01:13 --> Final output sent to browser
DEBUG - 2011-04-03 10:01:13 --> Total execution time: 1.1695
DEBUG - 2011-04-03 10:01:14 --> Config Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:01:14 --> URI Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Router Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Output Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Input Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:01:14 --> Language Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Loader Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Controller Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Model Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Model Class Initialized
DEBUG - 2011-04-03 10:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:01:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:01:15 --> Final output sent to browser
DEBUG - 2011-04-03 10:01:15 --> Total execution time: 0.5002
DEBUG - 2011-04-03 10:03:12 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:12 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Router Class Initialized
DEBUG - 2011-04-03 10:03:12 --> No URI present. Default controller set.
DEBUG - 2011-04-03 10:03:12 --> Output Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Input Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:03:12 --> Language Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Loader Class Initialized
DEBUG - 2011-04-03 10:03:12 --> Controller Class Initialized
DEBUG - 2011-04-03 10:03:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 10:03:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:03:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:03:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:03:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:03:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:03:12 --> Final output sent to browser
DEBUG - 2011-04-03 10:03:12 --> Total execution time: 0.0480
DEBUG - 2011-04-03 10:03:14 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:14 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Router Class Initialized
ERROR - 2011-04-03 10:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:03:14 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:14 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Router Class Initialized
ERROR - 2011-04-03 10:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:03:14 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:14 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:14 --> Router Class Initialized
ERROR - 2011-04-03 10:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:03:19 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:19 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Router Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Output Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Input Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:03:19 --> Language Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Loader Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Controller Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:03:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:03:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:03:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:03:19 --> Final output sent to browser
DEBUG - 2011-04-03 10:03:19 --> Total execution time: 0.1052
DEBUG - 2011-04-03 10:03:37 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:37 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Router Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Output Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Input Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:03:37 --> Language Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Loader Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Controller Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:03:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:03:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:03:38 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:03:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:03:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:03:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:03:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:03:38 --> Final output sent to browser
DEBUG - 2011-04-03 10:03:38 --> Total execution time: 0.2021
DEBUG - 2011-04-03 10:03:50 --> Config Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:03:50 --> URI Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Router Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Output Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Input Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:03:50 --> Language Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Loader Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Controller Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Model Class Initialized
DEBUG - 2011-04-03 10:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:03:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:03:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:03:50 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:03:50 --> Final output sent to browser
DEBUG - 2011-04-03 10:03:50 --> Total execution time: 0.0500
DEBUG - 2011-04-03 10:04:01 --> Config Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:04:01 --> URI Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Router Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Output Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Input Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:04:01 --> Language Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Loader Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Controller Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:04:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:04:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:04:01 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:04:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:04:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:04:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:04:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:04:01 --> Final output sent to browser
DEBUG - 2011-04-03 10:04:01 --> Total execution time: 0.0426
DEBUG - 2011-04-03 10:04:09 --> Config Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:04:09 --> URI Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Router Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Output Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Input Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:04:09 --> Language Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Loader Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Controller Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:04:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:04:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:04:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:04:09 --> Final output sent to browser
DEBUG - 2011-04-03 10:04:09 --> Total execution time: 0.2039
DEBUG - 2011-04-03 10:04:10 --> Config Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:04:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:04:10 --> URI Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Router Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Output Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Input Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:04:10 --> Language Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Loader Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Controller Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:04:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:04:10 --> Final output sent to browser
DEBUG - 2011-04-03 10:04:10 --> Total execution time: 0.4749
DEBUG - 2011-04-03 10:04:20 --> Config Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:04:20 --> URI Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Router Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Output Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Input Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:04:20 --> Language Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Loader Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Controller Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:04:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:04:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:04:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:04:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:04:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:04:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:04:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:04:20 --> Final output sent to browser
DEBUG - 2011-04-03 10:04:20 --> Total execution time: 0.2779
DEBUG - 2011-04-03 10:04:37 --> Config Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:04:37 --> URI Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Router Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Output Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Input Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:04:37 --> Language Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Loader Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Controller Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Model Class Initialized
DEBUG - 2011-04-03 10:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:04:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:04:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:04:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:04:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:04:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:04:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:04:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:04:37 --> Final output sent to browser
DEBUG - 2011-04-03 10:04:37 --> Total execution time: 0.2147
DEBUG - 2011-04-03 10:14:09 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:09 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Router Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Output Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Input Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:14:09 --> Language Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Loader Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Controller Class Initialized
ERROR - 2011-04-03 10:14:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:14:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:14:09 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:14:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:14:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:14:09 --> Final output sent to browser
DEBUG - 2011-04-03 10:14:09 --> Total execution time: 0.3337
DEBUG - 2011-04-03 10:14:11 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:11 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Router Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Output Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Input Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:14:11 --> Language Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Loader Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Controller Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:14:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:14:12 --> Final output sent to browser
DEBUG - 2011-04-03 10:14:12 --> Total execution time: 0.4792
DEBUG - 2011-04-03 10:14:16 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:16 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:16 --> Router Class Initialized
ERROR - 2011-04-03 10:14:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:14:17 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:17 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:17 --> Router Class Initialized
ERROR - 2011-04-03 10:14:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:14:20 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:20 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:20 --> Router Class Initialized
ERROR - 2011-04-03 10:14:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:14:34 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:34 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Router Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Output Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Input Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:14:34 --> Language Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Loader Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Controller Class Initialized
ERROR - 2011-04-03 10:14:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:14:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:14:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:14:34 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:14:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:14:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:14:34 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:14:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:14:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:14:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:14:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:14:34 --> Final output sent to browser
DEBUG - 2011-04-03 10:14:34 --> Total execution time: 0.0841
DEBUG - 2011-04-03 10:14:36 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:36 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Router Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Output Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Input Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:14:36 --> Language Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Loader Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Controller Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:14:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:14:36 --> Final output sent to browser
DEBUG - 2011-04-03 10:14:36 --> Total execution time: 0.6207
DEBUG - 2011-04-03 10:14:47 --> Config Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:14:47 --> URI Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Router Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Output Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Input Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:14:47 --> Language Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Loader Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Controller Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Model Class Initialized
DEBUG - 2011-04-03 10:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:14:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:14:48 --> Final output sent to browser
DEBUG - 2011-04-03 10:14:48 --> Total execution time: 0.4970
DEBUG - 2011-04-03 10:15:19 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:19 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:19 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Controller Class Initialized
ERROR - 2011-04-03 10:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:19 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:15:19 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:19 --> Total execution time: 0.0310
DEBUG - 2011-04-03 10:15:21 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:21 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:21 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Controller Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:21 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:21 --> Total execution time: 0.4614
DEBUG - 2011-04-03 10:15:23 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:23 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:23 --> Router Class Initialized
ERROR - 2011-04-03 10:15:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:15:33 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:33 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:33 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Controller Class Initialized
ERROR - 2011-04-03 10:15:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:15:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:15:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:33 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:15:33 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:33 --> Total execution time: 0.0285
DEBUG - 2011-04-03 10:15:34 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:34 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:34 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:34 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:35 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Controller Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:35 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:35 --> Total execution time: 0.6305
DEBUG - 2011-04-03 10:15:37 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:37 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:37 --> Router Class Initialized
ERROR - 2011-04-03 10:15:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:15:42 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:42 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:42 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Controller Class Initialized
ERROR - 2011-04-03 10:15:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:15:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:42 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:15:42 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:42 --> Total execution time: 0.0354
DEBUG - 2011-04-03 10:15:43 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:43 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:43 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Controller Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:43 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:43 --> Total execution time: 0.5346
DEBUG - 2011-04-03 10:15:45 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:45 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:45 --> Router Class Initialized
ERROR - 2011-04-03 10:15:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:15:57 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:57 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:57 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Controller Class Initialized
ERROR - 2011-04-03 10:15:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:15:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:57 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:15:57 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:15:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:15:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:15:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:15:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:15:57 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:57 --> Total execution time: 0.0309
DEBUG - 2011-04-03 10:15:58 --> Config Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:15:58 --> URI Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Router Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Output Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Input Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:15:58 --> Language Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Loader Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Controller Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Model Class Initialized
DEBUG - 2011-04-03 10:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:15:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:15:59 --> Final output sent to browser
DEBUG - 2011-04-03 10:15:59 --> Total execution time: 0.6282
DEBUG - 2011-04-03 10:16:01 --> Config Class Initialized
DEBUG - 2011-04-03 10:16:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:16:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:16:01 --> URI Class Initialized
DEBUG - 2011-04-03 10:16:01 --> Router Class Initialized
ERROR - 2011-04-03 10:16:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:16:13 --> Config Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:16:13 --> URI Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Router Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Output Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Input Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:16:13 --> Language Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Loader Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Controller Class Initialized
ERROR - 2011-04-03 10:16:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:16:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:16:13 --> Model Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Model Class Initialized
DEBUG - 2011-04-03 10:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:16:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:16:14 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:16:14 --> Final output sent to browser
DEBUG - 2011-04-03 10:16:14 --> Total execution time: 0.0901
DEBUG - 2011-04-03 10:16:15 --> Config Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:16:15 --> URI Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Router Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Output Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Input Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:16:15 --> Language Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Loader Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Controller Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Model Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Model Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:16:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:16:15 --> Final output sent to browser
DEBUG - 2011-04-03 10:16:15 --> Total execution time: 0.5218
DEBUG - 2011-04-03 10:16:17 --> Config Class Initialized
DEBUG - 2011-04-03 10:16:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:16:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:16:17 --> URI Class Initialized
DEBUG - 2011-04-03 10:16:17 --> Router Class Initialized
ERROR - 2011-04-03 10:16:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:30:32 --> Config Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:30:32 --> URI Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Router Class Initialized
ERROR - 2011-04-03 10:30:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 10:30:32 --> Config Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:30:32 --> URI Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Router Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Output Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Input Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:30:32 --> Language Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Loader Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Controller Class Initialized
ERROR - 2011-04-03 10:30:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 10:30:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 10:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:30:32 --> Model Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Model Class Initialized
DEBUG - 2011-04-03 10:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:30:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 10:30:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:30:33 --> Final output sent to browser
DEBUG - 2011-04-03 10:30:33 --> Total execution time: 0.7819
DEBUG - 2011-04-03 10:31:04 --> Config Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:31:04 --> URI Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Router Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Output Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Input Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:31:04 --> Language Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Loader Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Controller Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Model Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Model Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Model Class Initialized
DEBUG - 2011-04-03 10:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:31:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:31:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:31:04 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:31:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:31:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:31:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:31:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:31:04 --> Final output sent to browser
DEBUG - 2011-04-03 10:31:04 --> Total execution time: 0.4818
DEBUG - 2011-04-03 10:32:36 --> Config Class Initialized
DEBUG - 2011-04-03 10:32:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:32:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:32:36 --> URI Class Initialized
DEBUG - 2011-04-03 10:32:36 --> Router Class Initialized
DEBUG - 2011-04-03 10:32:36 --> No URI present. Default controller set.
DEBUG - 2011-04-03 10:32:36 --> Output Class Initialized
DEBUG - 2011-04-03 10:32:36 --> Input Class Initialized
DEBUG - 2011-04-03 10:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:32:36 --> Language Class Initialized
DEBUG - 2011-04-03 10:32:37 --> Loader Class Initialized
DEBUG - 2011-04-03 10:32:37 --> Controller Class Initialized
DEBUG - 2011-04-03 10:32:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 10:32:40 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:32:40 --> Final output sent to browser
DEBUG - 2011-04-03 10:32:40 --> Total execution time: 4.6336
DEBUG - 2011-04-03 10:34:56 --> Config Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:34:56 --> URI Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Router Class Initialized
DEBUG - 2011-04-03 10:34:56 --> No URI present. Default controller set.
DEBUG - 2011-04-03 10:34:56 --> Output Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Input Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:34:56 --> Language Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Loader Class Initialized
DEBUG - 2011-04-03 10:34:56 --> Controller Class Initialized
DEBUG - 2011-04-03 10:34:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 10:34:56 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:34:56 --> Final output sent to browser
DEBUG - 2011-04-03 10:34:56 --> Total execution time: 0.0238
DEBUG - 2011-04-03 10:34:59 --> Config Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:34:59 --> URI Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Router Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Output Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Input Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:34:59 --> Language Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Loader Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Controller Class Initialized
DEBUG - 2011-04-03 10:34:59 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:00 --> Config Class Initialized
DEBUG - 2011-04-03 10:35:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:35:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:35:00 --> URI Class Initialized
DEBUG - 2011-04-03 10:35:00 --> Router Class Initialized
ERROR - 2011-04-03 10:35:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 10:35:00 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:00 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:35:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:35:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:35:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:35:00 --> Final output sent to browser
DEBUG - 2011-04-03 10:35:00 --> Total execution time: 0.9142
DEBUG - 2011-04-03 10:35:16 --> Config Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:35:16 --> URI Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Router Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Output Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Input Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:35:16 --> Language Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Loader Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Controller Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:35:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:35:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:35:16 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:35:16 --> Final output sent to browser
DEBUG - 2011-04-03 10:35:16 --> Total execution time: 0.2804
DEBUG - 2011-04-03 10:35:27 --> Config Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:35:27 --> URI Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Router Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Output Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Input Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:35:27 --> Language Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Loader Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Controller Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Model Class Initialized
DEBUG - 2011-04-03 10:35:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 10:35:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 10:35:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 10:35:27 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:35:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:35:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:35:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:35:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:35:27 --> Final output sent to browser
DEBUG - 2011-04-03 10:35:27 --> Total execution time: 0.0418
DEBUG - 2011-04-03 10:35:28 --> Config Class Initialized
DEBUG - 2011-04-03 10:35:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:35:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:35:32 --> URI Class Initialized
DEBUG - 2011-04-03 10:35:32 --> Router Class Initialized
DEBUG - 2011-04-03 10:35:32 --> No URI present. Default controller set.
DEBUG - 2011-04-03 10:35:32 --> Output Class Initialized
DEBUG - 2011-04-03 10:35:32 --> Input Class Initialized
DEBUG - 2011-04-03 10:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:35:32 --> Language Class Initialized
DEBUG - 2011-04-03 10:35:32 --> Loader Class Initialized
DEBUG - 2011-04-03 10:35:32 --> Controller Class Initialized
DEBUG - 2011-04-03 10:35:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 10:35:32 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:35:32 --> Final output sent to browser
DEBUG - 2011-04-03 10:35:32 --> Total execution time: 3.7266
DEBUG - 2011-04-03 10:47:16 --> Config Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 10:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 10:47:16 --> URI Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Router Class Initialized
DEBUG - 2011-04-03 10:47:16 --> No URI present. Default controller set.
DEBUG - 2011-04-03 10:47:16 --> Output Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Input Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 10:47:16 --> Language Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Loader Class Initialized
DEBUG - 2011-04-03 10:47:16 --> Controller Class Initialized
DEBUG - 2011-04-03 10:47:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 10:47:16 --> Helper loaded: url_helper
DEBUG - 2011-04-03 10:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 10:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 10:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 10:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 10:47:16 --> Final output sent to browser
DEBUG - 2011-04-03 10:47:16 --> Total execution time: 0.2303
DEBUG - 2011-04-03 11:32:24 --> Config Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:32:24 --> URI Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Router Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Output Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Input Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 11:32:24 --> Language Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Loader Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Controller Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Model Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Model Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Model Class Initialized
DEBUG - 2011-04-03 11:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 11:32:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 11:32:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 11:32:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 11:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 11:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 11:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 11:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 11:32:24 --> Final output sent to browser
DEBUG - 2011-04-03 11:32:24 --> Total execution time: 0.4628
DEBUG - 2011-04-03 11:32:27 --> Config Class Initialized
DEBUG - 2011-04-03 11:32:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:32:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:32:27 --> URI Class Initialized
DEBUG - 2011-04-03 11:32:27 --> Router Class Initialized
ERROR - 2011-04-03 11:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 11:32:27 --> Config Class Initialized
DEBUG - 2011-04-03 11:32:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:32:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:32:27 --> URI Class Initialized
DEBUG - 2011-04-03 11:32:27 --> Router Class Initialized
ERROR - 2011-04-03 11:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 11:40:38 --> Config Class Initialized
DEBUG - 2011-04-03 11:40:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:40:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:40:38 --> URI Class Initialized
DEBUG - 2011-04-03 11:40:38 --> Router Class Initialized
DEBUG - 2011-04-03 11:40:38 --> No URI present. Default controller set.
DEBUG - 2011-04-03 11:40:39 --> Output Class Initialized
DEBUG - 2011-04-03 11:40:39 --> Input Class Initialized
DEBUG - 2011-04-03 11:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 11:40:39 --> Language Class Initialized
DEBUG - 2011-04-03 11:40:39 --> Loader Class Initialized
DEBUG - 2011-04-03 11:40:39 --> Controller Class Initialized
DEBUG - 2011-04-03 11:40:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 11:40:39 --> Helper loaded: url_helper
DEBUG - 2011-04-03 11:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 11:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 11:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 11:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 11:40:39 --> Final output sent to browser
DEBUG - 2011-04-03 11:40:39 --> Total execution time: 0.4808
DEBUG - 2011-04-03 11:40:41 --> Config Class Initialized
DEBUG - 2011-04-03 11:40:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:40:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:40:41 --> URI Class Initialized
DEBUG - 2011-04-03 11:40:41 --> Router Class Initialized
ERROR - 2011-04-03 11:40:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 11:55:36 --> Config Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:55:37 --> URI Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Router Class Initialized
DEBUG - 2011-04-03 11:55:37 --> No URI present. Default controller set.
DEBUG - 2011-04-03 11:55:37 --> Output Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Input Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 11:55:37 --> Language Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Loader Class Initialized
DEBUG - 2011-04-03 11:55:37 --> Controller Class Initialized
DEBUG - 2011-04-03 11:55:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 11:55:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 11:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 11:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 11:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 11:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 11:55:37 --> Final output sent to browser
DEBUG - 2011-04-03 11:55:37 --> Total execution time: 1.0308
DEBUG - 2011-04-03 11:57:54 --> Config Class Initialized
DEBUG - 2011-04-03 11:57:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 11:57:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 11:57:54 --> URI Class Initialized
DEBUG - 2011-04-03 11:57:54 --> Router Class Initialized
DEBUG - 2011-04-03 11:57:54 --> Output Class Initialized
DEBUG - 2011-04-03 11:57:54 --> Input Class Initialized
DEBUG - 2011-04-03 11:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 11:57:54 --> Language Class Initialized
DEBUG - 2011-04-03 11:57:56 --> Loader Class Initialized
DEBUG - 2011-04-03 11:57:56 --> Controller Class Initialized
DEBUG - 2011-04-03 11:57:56 --> Model Class Initialized
DEBUG - 2011-04-03 11:57:59 --> Model Class Initialized
DEBUG - 2011-04-03 11:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 11:58:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 11:58:02 --> Final output sent to browser
DEBUG - 2011-04-03 11:58:02 --> Total execution time: 8.1954
DEBUG - 2011-04-03 12:11:09 --> Config Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 12:11:09 --> URI Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Router Class Initialized
DEBUG - 2011-04-03 12:11:09 --> No URI present. Default controller set.
DEBUG - 2011-04-03 12:11:09 --> Output Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Input Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 12:11:09 --> Language Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Loader Class Initialized
DEBUG - 2011-04-03 12:11:09 --> Controller Class Initialized
DEBUG - 2011-04-03 12:11:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 12:11:09 --> Helper loaded: url_helper
DEBUG - 2011-04-03 12:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 12:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 12:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 12:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 12:11:09 --> Final output sent to browser
DEBUG - 2011-04-03 12:11:09 --> Total execution time: 0.0910
DEBUG - 2011-04-03 12:12:14 --> Config Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 12:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 12:12:14 --> URI Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Router Class Initialized
DEBUG - 2011-04-03 12:12:14 --> No URI present. Default controller set.
DEBUG - 2011-04-03 12:12:14 --> Output Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Input Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 12:12:14 --> Language Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Loader Class Initialized
DEBUG - 2011-04-03 12:12:14 --> Controller Class Initialized
DEBUG - 2011-04-03 12:12:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 12:12:14 --> Helper loaded: url_helper
DEBUG - 2011-04-03 12:12:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 12:12:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 12:12:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 12:12:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 12:12:14 --> Final output sent to browser
DEBUG - 2011-04-03 12:12:14 --> Total execution time: 0.0132
DEBUG - 2011-04-03 12:12:21 --> Config Class Initialized
DEBUG - 2011-04-03 12:12:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 12:12:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 12:12:21 --> URI Class Initialized
DEBUG - 2011-04-03 12:12:21 --> Router Class Initialized
ERROR - 2011-04-03 12:12:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 12:14:52 --> Config Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 12:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 12:14:52 --> URI Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Router Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Output Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Input Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 12:14:52 --> Language Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Loader Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Controller Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Model Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Model Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Model Class Initialized
DEBUG - 2011-04-03 12:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 12:14:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 12:14:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 12:14:52 --> Helper loaded: url_helper
DEBUG - 2011-04-03 12:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 12:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 12:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 12:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 12:14:52 --> Final output sent to browser
DEBUG - 2011-04-03 12:14:52 --> Total execution time: 0.3467
DEBUG - 2011-04-03 12:59:53 --> Config Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 12:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 12:59:53 --> URI Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Router Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Output Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Input Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 12:59:53 --> Language Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Loader Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Controller Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Model Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Model Class Initialized
DEBUG - 2011-04-03 12:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 12:59:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 12:59:54 --> Final output sent to browser
DEBUG - 2011-04-03 12:59:54 --> Total execution time: 0.8690
DEBUG - 2011-04-03 13:00:23 --> Config Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:00:23 --> URI Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Router Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Output Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Input Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:00:23 --> Language Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Loader Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Controller Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Model Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Model Class Initialized
DEBUG - 2011-04-03 13:00:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:00:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:00:24 --> Final output sent to browser
DEBUG - 2011-04-03 13:00:24 --> Total execution time: 1.1154
DEBUG - 2011-04-03 13:00:51 --> Config Class Initialized
DEBUG - 2011-04-03 13:00:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:00:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:00:51 --> URI Class Initialized
DEBUG - 2011-04-03 13:00:51 --> Router Class Initialized
ERROR - 2011-04-03 13:00:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 13:05:20 --> Config Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:05:20 --> URI Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Router Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Output Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Input Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:05:20 --> Language Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Loader Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Controller Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Model Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Model Class Initialized
DEBUG - 2011-04-03 13:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:05:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:05:21 --> Final output sent to browser
DEBUG - 2011-04-03 13:05:21 --> Total execution time: 0.5725
DEBUG - 2011-04-03 13:09:04 --> Config Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:09:04 --> URI Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Router Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Output Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Input Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:09:04 --> Language Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Loader Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Controller Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Model Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Model Class Initialized
DEBUG - 2011-04-03 13:09:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:09:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:09:05 --> Final output sent to browser
DEBUG - 2011-04-03 13:09:05 --> Total execution time: 0.9593
DEBUG - 2011-04-03 13:17:03 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:03 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:03 --> No URI present. Default controller set.
DEBUG - 2011-04-03 13:17:03 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:03 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:03 --> Controller Class Initialized
DEBUG - 2011-04-03 13:17:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 13:17:04 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:17:04 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:04 --> Total execution time: 0.2073
DEBUG - 2011-04-03 13:17:09 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:09 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:09 --> Router Class Initialized
ERROR - 2011-04-03 13:17:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 13:17:11 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:11 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:11 --> Router Class Initialized
ERROR - 2011-04-03 13:17:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 13:17:15 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:15 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:15 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Controller Class Initialized
ERROR - 2011-04-03 13:17:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:17:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:17:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:15 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:15 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:15 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:17:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:17:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:17:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:17:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:17:15 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:15 --> Total execution time: 0.1091
DEBUG - 2011-04-03 13:17:16 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:16 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:16 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Controller Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:17 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:17 --> Total execution time: 0.8434
DEBUG - 2011-04-03 13:17:20 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:20 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:20 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Controller Class Initialized
ERROR - 2011-04-03 13:17:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:17:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:20 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:17:20 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:20 --> Total execution time: 0.0499
DEBUG - 2011-04-03 13:17:21 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:21 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:21 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Controller Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:21 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:21 --> Total execution time: 0.5502
DEBUG - 2011-04-03 13:17:22 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:22 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:22 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Controller Class Initialized
ERROR - 2011-04-03 13:17:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:22 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:22 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:22 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:17:22 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:22 --> Total execution time: 0.0282
DEBUG - 2011-04-03 13:17:53 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:53 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:53 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Controller Class Initialized
ERROR - 2011-04-03 13:17:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:17:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:17:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:53 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:17:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:17:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:17:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:17:53 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:53 --> Total execution time: 0.0281
DEBUG - 2011-04-03 13:17:55 --> Config Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:17:55 --> URI Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Router Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Output Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Input Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:17:55 --> Language Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Loader Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Controller Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Model Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:17:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:17:55 --> Final output sent to browser
DEBUG - 2011-04-03 13:17:55 --> Total execution time: 0.5076
DEBUG - 2011-04-03 13:18:07 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:07 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:07 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Controller Class Initialized
ERROR - 2011-04-03 13:18:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:18:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:18:07 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:18:07 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:18:07 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:07 --> Total execution time: 0.0295
DEBUG - 2011-04-03 13:18:08 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:08 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:08 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Controller Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:08 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:10 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:10 --> Total execution time: 1.1921
DEBUG - 2011-04-03 13:18:15 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:15 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:15 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:15 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:15 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:15 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:16 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:16 --> Controller Class Initialized
DEBUG - 2011-04-03 13:18:16 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:16 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:16 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:16 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:16 --> Total execution time: 0.6707
DEBUG - 2011-04-03 13:18:38 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:38 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:38 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Controller Class Initialized
ERROR - 2011-04-03 13:18:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:18:38 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:38 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:18:38 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:18:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:18:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:18:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:18:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:18:38 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:38 --> Total execution time: 0.1302
DEBUG - 2011-04-03 13:18:39 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:39 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:39 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Controller Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:39 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:40 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:40 --> Total execution time: 0.5181
DEBUG - 2011-04-03 13:18:49 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:49 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:49 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Controller Class Initialized
ERROR - 2011-04-03 13:18:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:18:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:18:49 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:49 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:18:49 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:18:49 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:49 --> Total execution time: 0.0423
DEBUG - 2011-04-03 13:18:50 --> Config Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:18:50 --> URI Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Router Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Output Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Input Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:18:50 --> Language Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Loader Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Controller Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Model Class Initialized
DEBUG - 2011-04-03 13:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:18:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:18:51 --> Final output sent to browser
DEBUG - 2011-04-03 13:18:51 --> Total execution time: 1.3401
DEBUG - 2011-04-03 13:19:07 --> Config Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:19:07 --> URI Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Router Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Output Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Input Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:19:07 --> Language Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Loader Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Controller Class Initialized
ERROR - 2011-04-03 13:19:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:19:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:19:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:19:07 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:19:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:19:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:19:07 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:19:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:19:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:19:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:19:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:19:07 --> Final output sent to browser
DEBUG - 2011-04-03 13:19:07 --> Total execution time: 0.0304
DEBUG - 2011-04-03 13:19:09 --> Config Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:19:09 --> URI Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Router Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Output Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Input Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:19:09 --> Language Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Loader Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Controller Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:19:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:19:10 --> Final output sent to browser
DEBUG - 2011-04-03 13:19:10 --> Total execution time: 1.3753
DEBUG - 2011-04-03 13:19:30 --> Config Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:19:30 --> URI Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Router Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Output Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Input Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:19:30 --> Language Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Loader Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Controller Class Initialized
ERROR - 2011-04-03 13:19:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 13:19:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 13:19:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:19:30 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:19:30 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:19:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 13:19:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:19:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:19:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:19:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:19:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:19:30 --> Final output sent to browser
DEBUG - 2011-04-03 13:19:30 --> Total execution time: 0.0292
DEBUG - 2011-04-03 13:19:31 --> Config Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:19:31 --> URI Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Router Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Output Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Input Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:19:31 --> Language Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Loader Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Controller Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Model Class Initialized
DEBUG - 2011-04-03 13:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:19:31 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:19:33 --> Final output sent to browser
DEBUG - 2011-04-03 13:19:33 --> Total execution time: 1.4963
DEBUG - 2011-04-03 13:30:35 --> Config Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:30:35 --> URI Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Router Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Output Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Input Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:30:35 --> Language Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Loader Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Controller Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Model Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Model Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:30:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:30:35 --> Final output sent to browser
DEBUG - 2011-04-03 13:30:35 --> Total execution time: 0.5875
DEBUG - 2011-04-03 13:32:45 --> Config Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:32:45 --> URI Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Router Class Initialized
DEBUG - 2011-04-03 13:32:45 --> No URI present. Default controller set.
DEBUG - 2011-04-03 13:32:45 --> Output Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Input Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:32:45 --> Language Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Loader Class Initialized
DEBUG - 2011-04-03 13:32:45 --> Controller Class Initialized
DEBUG - 2011-04-03 13:32:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 13:32:45 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:32:45 --> Final output sent to browser
DEBUG - 2011-04-03 13:32:45 --> Total execution time: 0.0449
DEBUG - 2011-04-03 13:32:49 --> Config Class Initialized
DEBUG - 2011-04-03 13:32:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:32:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:32:49 --> URI Class Initialized
DEBUG - 2011-04-03 13:32:49 --> Router Class Initialized
ERROR - 2011-04-03 13:32:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 13:32:49 --> Config Class Initialized
DEBUG - 2011-04-03 13:32:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:32:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:32:49 --> URI Class Initialized
DEBUG - 2011-04-03 13:32:49 --> Router Class Initialized
ERROR - 2011-04-03 13:32:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 13:32:50 --> Config Class Initialized
DEBUG - 2011-04-03 13:32:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:32:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:32:50 --> URI Class Initialized
DEBUG - 2011-04-03 13:32:50 --> Router Class Initialized
ERROR - 2011-04-03 13:32:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 13:32:58 --> Config Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:32:58 --> URI Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Router Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Output Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Input Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:32:58 --> Language Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Loader Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Controller Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Model Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Model Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Model Class Initialized
DEBUG - 2011-04-03 13:32:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:32:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:32:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 13:32:58 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:32:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:32:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:32:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:32:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:32:58 --> Final output sent to browser
DEBUG - 2011-04-03 13:32:58 --> Total execution time: 0.2766
DEBUG - 2011-04-03 13:33:38 --> Config Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:33:38 --> URI Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Router Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Output Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Input Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:33:38 --> Language Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Loader Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Controller Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Model Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Model Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Model Class Initialized
DEBUG - 2011-04-03 13:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:33:38 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:33:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 13:33:38 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:33:38 --> Final output sent to browser
DEBUG - 2011-04-03 13:33:38 --> Total execution time: 0.2175
DEBUG - 2011-04-03 13:33:53 --> Config Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:33:53 --> URI Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Router Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Output Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Input Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:33:53 --> Language Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Loader Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Controller Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Model Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Model Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Model Class Initialized
DEBUG - 2011-04-03 13:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:33:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:33:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 13:33:54 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:33:54 --> Final output sent to browser
DEBUG - 2011-04-03 13:33:54 --> Total execution time: 0.2225
DEBUG - 2011-04-03 13:34:10 --> Config Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:34:10 --> URI Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Router Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Output Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Input Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:34:10 --> Language Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Loader Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Controller Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Model Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Model Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Model Class Initialized
DEBUG - 2011-04-03 13:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 13:34:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 13:34:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 13:34:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:34:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:34:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:34:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:34:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:34:10 --> Final output sent to browser
DEBUG - 2011-04-03 13:34:10 --> Total execution time: 0.1993
DEBUG - 2011-04-03 13:57:29 --> Config Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:57:29 --> URI Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Router Class Initialized
DEBUG - 2011-04-03 13:57:29 --> No URI present. Default controller set.
DEBUG - 2011-04-03 13:57:29 --> Output Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Input Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 13:57:29 --> Language Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Loader Class Initialized
DEBUG - 2011-04-03 13:57:29 --> Controller Class Initialized
DEBUG - 2011-04-03 13:57:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 13:57:30 --> Helper loaded: url_helper
DEBUG - 2011-04-03 13:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 13:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 13:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 13:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 13:57:30 --> Final output sent to browser
DEBUG - 2011-04-03 13:57:30 --> Total execution time: 1.9084
DEBUG - 2011-04-03 13:57:35 --> Config Class Initialized
DEBUG - 2011-04-03 13:57:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:57:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:57:35 --> URI Class Initialized
DEBUG - 2011-04-03 13:57:35 --> Router Class Initialized
ERROR - 2011-04-03 13:57:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 13:57:35 --> Config Class Initialized
DEBUG - 2011-04-03 13:57:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 13:57:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 13:57:35 --> URI Class Initialized
DEBUG - 2011-04-03 13:57:35 --> Router Class Initialized
ERROR - 2011-04-03 13:57:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 14:03:47 --> Config Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:03:47 --> URI Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Router Class Initialized
DEBUG - 2011-04-03 14:03:47 --> No URI present. Default controller set.
DEBUG - 2011-04-03 14:03:47 --> Output Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Input Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:03:47 --> Language Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Loader Class Initialized
DEBUG - 2011-04-03 14:03:47 --> Controller Class Initialized
DEBUG - 2011-04-03 14:03:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 14:03:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:03:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:03:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:03:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:03:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:03:47 --> Final output sent to browser
DEBUG - 2011-04-03 14:03:47 --> Total execution time: 0.0157
DEBUG - 2011-04-03 14:05:01 --> Config Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:05:01 --> URI Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Router Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Output Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Input Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:05:01 --> Language Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Loader Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Controller Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Model Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Model Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Model Class Initialized
DEBUG - 2011-04-03 14:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:05:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:05:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 14:05:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:05:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:05:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:05:03 --> Final output sent to browser
DEBUG - 2011-04-03 14:05:03 --> Total execution time: 1.3520
DEBUG - 2011-04-03 14:05:31 --> Config Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:05:31 --> URI Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Router Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Output Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Input Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:05:31 --> Language Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Loader Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Controller Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Model Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Model Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Model Class Initialized
DEBUG - 2011-04-03 14:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:05:31 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:05:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 14:05:31 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:05:31 --> Final output sent to browser
DEBUG - 2011-04-03 14:05:31 --> Total execution time: 0.0442
DEBUG - 2011-04-03 14:06:00 --> Config Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:06:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:06:00 --> URI Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Router Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Output Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Input Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:06:00 --> Language Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Loader Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Controller Class Initialized
ERROR - 2011-04-03 14:06:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 14:06:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 14:06:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 14:06:00 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:06:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:06:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 14:06:00 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:06:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:06:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:06:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:06:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:06:00 --> Final output sent to browser
DEBUG - 2011-04-03 14:06:00 --> Total execution time: 0.0750
DEBUG - 2011-04-03 14:06:01 --> Config Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:06:01 --> URI Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Router Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Output Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Input Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:06:01 --> Language Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Loader Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Controller Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:06:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:06:01 --> Final output sent to browser
DEBUG - 2011-04-03 14:06:01 --> Total execution time: 0.6445
DEBUG - 2011-04-03 14:06:03 --> Config Class Initialized
DEBUG - 2011-04-03 14:06:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:06:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:06:03 --> URI Class Initialized
DEBUG - 2011-04-03 14:06:03 --> Router Class Initialized
ERROR - 2011-04-03 14:06:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 14:06:35 --> Config Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:06:35 --> URI Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Router Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Output Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Input Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:06:35 --> Language Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Loader Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Controller Class Initialized
ERROR - 2011-04-03 14:06:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 14:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 14:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 14:06:35 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:06:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 14:06:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:06:35 --> Final output sent to browser
DEBUG - 2011-04-03 14:06:35 --> Total execution time: 0.0533
DEBUG - 2011-04-03 14:06:36 --> Config Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:06:36 --> URI Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Router Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Output Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Input Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:06:36 --> Language Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Loader Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Controller Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Model Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:06:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:06:36 --> Final output sent to browser
DEBUG - 2011-04-03 14:06:36 --> Total execution time: 0.7021
DEBUG - 2011-04-03 14:06:38 --> Config Class Initialized
DEBUG - 2011-04-03 14:06:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:06:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:06:38 --> URI Class Initialized
DEBUG - 2011-04-03 14:06:38 --> Router Class Initialized
ERROR - 2011-04-03 14:06:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 14:09:24 --> Config Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:09:24 --> URI Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Router Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Output Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Input Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:09:24 --> Language Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Loader Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Controller Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Model Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Model Class Initialized
DEBUG - 2011-04-03 14:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:09:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:09:26 --> Final output sent to browser
DEBUG - 2011-04-03 14:09:26 --> Total execution time: 1.8647
DEBUG - 2011-04-03 14:10:34 --> Config Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:10:34 --> URI Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Router Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Output Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Input Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:10:34 --> Language Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Loader Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Controller Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Model Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Model Class Initialized
DEBUG - 2011-04-03 14:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:10:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:10:35 --> Final output sent to browser
DEBUG - 2011-04-03 14:10:35 --> Total execution time: 0.5059
DEBUG - 2011-04-03 14:17:59 --> Config Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:17:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:17:59 --> URI Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Router Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Output Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Input Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:17:59 --> Language Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Loader Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Controller Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Model Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Model Class Initialized
DEBUG - 2011-04-03 14:17:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:17:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:18:00 --> Final output sent to browser
DEBUG - 2011-04-03 14:18:00 --> Total execution time: 0.6388
DEBUG - 2011-04-03 14:21:59 --> Config Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:21:59 --> URI Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Router Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Output Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Input Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:21:59 --> Language Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Loader Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Controller Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Model Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Model Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Model Class Initialized
DEBUG - 2011-04-03 14:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 14:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:21:59 --> Final output sent to browser
DEBUG - 2011-04-03 14:21:59 --> Total execution time: 0.0651
DEBUG - 2011-04-03 14:22:06 --> Config Class Initialized
DEBUG - 2011-04-03 14:22:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:22:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:22:06 --> URI Class Initialized
DEBUG - 2011-04-03 14:22:06 --> Router Class Initialized
ERROR - 2011-04-03 14:22:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 14:22:08 --> Config Class Initialized
DEBUG - 2011-04-03 14:22:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:22:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:22:08 --> URI Class Initialized
DEBUG - 2011-04-03 14:22:08 --> Router Class Initialized
ERROR - 2011-04-03 14:22:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 14:24:02 --> Config Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:24:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:24:02 --> URI Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Router Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Output Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Input Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:24:02 --> Language Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Loader Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Controller Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Model Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Model Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Model Class Initialized
DEBUG - 2011-04-03 14:24:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:24:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:24:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 14:24:02 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:24:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:24:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:24:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:24:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:24:02 --> Final output sent to browser
DEBUG - 2011-04-03 14:24:02 --> Total execution time: 0.0561
DEBUG - 2011-04-03 14:45:53 --> Config Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:45:53 --> URI Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Router Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Output Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Input Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:45:53 --> Language Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Loader Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Controller Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Model Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Model Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Model Class Initialized
DEBUG - 2011-04-03 14:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:45:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:45:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 14:45:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 14:45:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 14:45:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 14:45:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 14:45:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 14:45:53 --> Final output sent to browser
DEBUG - 2011-04-03 14:45:53 --> Total execution time: 0.4351
DEBUG - 2011-04-03 14:45:56 --> Config Class Initialized
DEBUG - 2011-04-03 14:45:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:45:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:45:56 --> URI Class Initialized
DEBUG - 2011-04-03 14:45:56 --> Router Class Initialized
ERROR - 2011-04-03 14:45:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 14:52:31 --> Config Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 14:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 14:52:31 --> URI Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Router Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Output Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Input Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 14:52:31 --> Language Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Loader Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Controller Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Model Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Model Class Initialized
DEBUG - 2011-04-03 14:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 14:52:31 --> Database Driver Class Initialized
DEBUG - 2011-04-03 14:52:32 --> Final output sent to browser
DEBUG - 2011-04-03 14:52:32 --> Total execution time: 0.6855
DEBUG - 2011-04-03 15:36:35 --> Config Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:36:35 --> URI Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Router Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Output Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Input Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:36:35 --> Language Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Loader Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Controller Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:36:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:36:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 15:36:36 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:36:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:36:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:36:37 --> Final output sent to browser
DEBUG - 2011-04-03 15:36:37 --> Total execution time: 1.4832
DEBUG - 2011-04-03 15:36:39 --> Config Class Initialized
DEBUG - 2011-04-03 15:36:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:36:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:36:39 --> URI Class Initialized
DEBUG - 2011-04-03 15:36:39 --> Router Class Initialized
ERROR - 2011-04-03 15:36:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:36:40 --> Config Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:36:40 --> URI Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Router Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Output Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Input Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:36:40 --> Language Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Loader Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Controller Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:36:40 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:36:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 15:36:40 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:36:40 --> Final output sent to browser
DEBUG - 2011-04-03 15:36:40 --> Total execution time: 0.0459
DEBUG - 2011-04-03 15:36:45 --> Config Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:36:45 --> URI Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Router Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Output Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Input Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:36:45 --> Language Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Loader Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Controller Class Initialized
ERROR - 2011-04-03 15:36:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 15:36:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 15:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:36:45 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:36:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:36:45 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:36:45 --> Final output sent to browser
DEBUG - 2011-04-03 15:36:45 --> Total execution time: 0.4544
DEBUG - 2011-04-03 15:36:46 --> Config Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:36:46 --> URI Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Router Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Output Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Input Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:36:46 --> Language Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Loader Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Controller Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Model Class Initialized
DEBUG - 2011-04-03 15:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:36:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:36:47 --> Final output sent to browser
DEBUG - 2011-04-03 15:36:47 --> Total execution time: 0.6147
DEBUG - 2011-04-03 15:36:48 --> Config Class Initialized
DEBUG - 2011-04-03 15:36:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:36:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:36:48 --> URI Class Initialized
DEBUG - 2011-04-03 15:36:48 --> Router Class Initialized
ERROR - 2011-04-03 15:36:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:37:10 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:10 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:10 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Controller Class Initialized
ERROR - 2011-04-03 15:37:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 15:37:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 15:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:10 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:37:10 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:10 --> Total execution time: 0.0287
DEBUG - 2011-04-03 15:37:11 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:11 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:11 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Controller Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:11 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:12 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:12 --> Total execution time: 0.7127
DEBUG - 2011-04-03 15:37:13 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:13 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:13 --> Router Class Initialized
ERROR - 2011-04-03 15:37:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:37:24 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:24 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:24 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Controller Class Initialized
ERROR - 2011-04-03 15:37:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 15:37:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 15:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:24 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:37:24 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:24 --> Total execution time: 0.0290
DEBUG - 2011-04-03 15:37:25 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:25 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:25 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Controller Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:25 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:25 --> Total execution time: 0.5487
DEBUG - 2011-04-03 15:37:26 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:26 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:26 --> Router Class Initialized
ERROR - 2011-04-03 15:37:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:37:39 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:39 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:39 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Controller Class Initialized
ERROR - 2011-04-03 15:37:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 15:37:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 15:37:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:39 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:39 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:39 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:37:39 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:39 --> Total execution time: 0.0277
DEBUG - 2011-04-03 15:37:40 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:40 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:40 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Controller Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:40 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:40 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:40 --> Total execution time: 0.5680
DEBUG - 2011-04-03 15:37:42 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:42 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:42 --> Router Class Initialized
ERROR - 2011-04-03 15:37:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:37:45 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:45 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:45 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Controller Class Initialized
ERROR - 2011-04-03 15:37:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 15:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 15:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:45 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:45 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:37:45 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:45 --> Total execution time: 0.0415
DEBUG - 2011-04-03 15:37:46 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:46 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:46 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Controller Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:46 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:46 --> Total execution time: 0.5370
DEBUG - 2011-04-03 15:37:47 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:47 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:47 --> Router Class Initialized
ERROR - 2011-04-03 15:37:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:37:53 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:53 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:53 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Controller Class Initialized
ERROR - 2011-04-03 15:37:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 15:37:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 15:37:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:53 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 15:37:54 --> Helper loaded: url_helper
DEBUG - 2011-04-03 15:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 15:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 15:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 15:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 15:37:54 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:54 --> Total execution time: 0.0487
DEBUG - 2011-04-03 15:37:54 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:54 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Router Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Output Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Input Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:37:54 --> Language Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Loader Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Controller Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Model Class Initialized
DEBUG - 2011-04-03 15:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:37:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:37:55 --> Final output sent to browser
DEBUG - 2011-04-03 15:37:55 --> Total execution time: 0.5481
DEBUG - 2011-04-03 15:37:56 --> Config Class Initialized
DEBUG - 2011-04-03 15:37:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:37:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:37:56 --> URI Class Initialized
DEBUG - 2011-04-03 15:37:56 --> Router Class Initialized
ERROR - 2011-04-03 15:37:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 15:56:20 --> Config Class Initialized
DEBUG - 2011-04-03 15:56:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 15:56:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 15:56:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 15:56:21 --> URI Class Initialized
DEBUG - 2011-04-03 15:56:21 --> Router Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Output Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Input Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 15:56:22 --> Language Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Loader Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Controller Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Model Class Initialized
DEBUG - 2011-04-03 15:56:22 --> Model Class Initialized
DEBUG - 2011-04-03 15:56:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 15:56:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 15:56:24 --> Final output sent to browser
DEBUG - 2011-04-03 15:56:24 --> Total execution time: 4.2165
DEBUG - 2011-04-03 16:00:04 --> Config Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:00:04 --> URI Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Router Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Output Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Input Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:00:04 --> Language Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Loader Class Initialized
DEBUG - 2011-04-03 16:00:04 --> Controller Class Initialized
ERROR - 2011-04-03 16:00:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 16:00:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 16:00:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:00:05 --> Model Class Initialized
DEBUG - 2011-04-03 16:00:05 --> Model Class Initialized
DEBUG - 2011-04-03 16:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:00:05 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:00:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:00:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 16:00:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 16:00:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 16:00:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 16:00:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 16:00:05 --> Final output sent to browser
DEBUG - 2011-04-03 16:00:05 --> Total execution time: 0.7659
DEBUG - 2011-04-03 16:03:47 --> Config Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:03:47 --> URI Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Router Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Output Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Input Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:03:47 --> Language Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Loader Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Controller Class Initialized
ERROR - 2011-04-03 16:03:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 16:03:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 16:03:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:03:47 --> Model Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Model Class Initialized
DEBUG - 2011-04-03 16:03:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:03:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:03:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:03:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 16:03:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 16:03:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 16:03:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 16:03:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 16:03:47 --> Final output sent to browser
DEBUG - 2011-04-03 16:03:47 --> Total execution time: 0.0432
DEBUG - 2011-04-03 16:03:53 --> Config Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:03:53 --> URI Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Router Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Output Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Input Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:03:53 --> Language Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Loader Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Controller Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Model Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Model Class Initialized
DEBUG - 2011-04-03 16:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:03:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:03:54 --> Final output sent to browser
DEBUG - 2011-04-03 16:03:54 --> Total execution time: 0.6482
DEBUG - 2011-04-03 16:04:05 --> Config Class Initialized
DEBUG - 2011-04-03 16:04:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:04:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:04:05 --> URI Class Initialized
DEBUG - 2011-04-03 16:04:05 --> Router Class Initialized
ERROR - 2011-04-03 16:04:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 16:05:33 --> Config Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:05:33 --> URI Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Router Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Output Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Input Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:05:33 --> Language Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Loader Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Controller Class Initialized
ERROR - 2011-04-03 16:05:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 16:05:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 16:05:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:05:33 --> Model Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Model Class Initialized
DEBUG - 2011-04-03 16:05:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:05:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:05:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:05:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 16:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 16:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 16:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 16:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 16:05:33 --> Final output sent to browser
DEBUG - 2011-04-03 16:05:33 --> Total execution time: 0.0306
DEBUG - 2011-04-03 16:05:37 --> Config Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:05:37 --> URI Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Router Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Output Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Input Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:05:37 --> Language Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Loader Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Controller Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Model Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Model Class Initialized
DEBUG - 2011-04-03 16:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:05:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:05:41 --> Final output sent to browser
DEBUG - 2011-04-03 16:05:41 --> Total execution time: 4.0437
DEBUG - 2011-04-03 16:12:10 --> Config Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:12:10 --> URI Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Router Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Output Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Input Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:12:10 --> Language Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Loader Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Controller Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Model Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Model Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Model Class Initialized
DEBUG - 2011-04-03 16:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:12:10 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:12:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 16:12:10 --> Helper loaded: url_helper
DEBUG - 2011-04-03 16:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 16:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 16:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 16:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 16:12:10 --> Final output sent to browser
DEBUG - 2011-04-03 16:12:10 --> Total execution time: 0.3888
DEBUG - 2011-04-03 16:20:45 --> Config Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:20:45 --> URI Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Router Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Output Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Input Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:20:45 --> Language Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Loader Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Controller Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:20:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 16:20:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 16:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 16:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 16:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 16:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 16:20:46 --> Final output sent to browser
DEBUG - 2011-04-03 16:20:46 --> Total execution time: 0.2363
DEBUG - 2011-04-03 16:20:47 --> Config Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:20:47 --> URI Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Router Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Output Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Input Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:20:47 --> Language Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Loader Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Controller Class Initialized
ERROR - 2011-04-03 16:20:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 16:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 16:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:20:47 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:20:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 16:20:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 16:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 16:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 16:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 16:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 16:20:47 --> Final output sent to browser
DEBUG - 2011-04-03 16:20:47 --> Total execution time: 0.2928
DEBUG - 2011-04-03 16:20:54 --> Config Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:20:54 --> URI Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Router Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Output Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Input Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:20:54 --> Language Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Loader Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Controller Class Initialized
DEBUG - 2011-04-03 16:20:54 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:55 --> Model Class Initialized
DEBUG - 2011-04-03 16:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:20:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:20:56 --> Final output sent to browser
DEBUG - 2011-04-03 16:20:56 --> Total execution time: 1.8149
DEBUG - 2011-04-03 16:21:08 --> Config Class Initialized
DEBUG - 2011-04-03 16:21:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:21:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:21:08 --> URI Class Initialized
DEBUG - 2011-04-03 16:21:08 --> Router Class Initialized
ERROR - 2011-04-03 16:21:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 16:52:50 --> Config Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 16:52:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 16:52:50 --> URI Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Router Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Output Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Input Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 16:52:50 --> Language Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Loader Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Controller Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Model Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Model Class Initialized
DEBUG - 2011-04-03 16:52:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 16:52:50 --> Database Driver Class Initialized
DEBUG - 2011-04-03 16:52:51 --> Final output sent to browser
DEBUG - 2011-04-03 16:52:51 --> Total execution time: 0.7548
DEBUG - 2011-04-03 17:01:16 --> Config Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:01:16 --> URI Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Router Class Initialized
DEBUG - 2011-04-03 17:01:16 --> No URI present. Default controller set.
DEBUG - 2011-04-03 17:01:16 --> Output Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Input Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:01:16 --> Language Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Loader Class Initialized
DEBUG - 2011-04-03 17:01:16 --> Controller Class Initialized
DEBUG - 2011-04-03 17:01:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 17:01:17 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:01:17 --> Final output sent to browser
DEBUG - 2011-04-03 17:01:17 --> Total execution time: 0.9818
DEBUG - 2011-04-03 17:01:20 --> Config Class Initialized
DEBUG - 2011-04-03 17:01:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:01:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:01:20 --> URI Class Initialized
DEBUG - 2011-04-03 17:01:20 --> Router Class Initialized
ERROR - 2011-04-03 17:01:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 17:15:47 --> Config Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:15:47 --> URI Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Router Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Output Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Input Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:15:47 --> Language Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Loader Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Controller Class Initialized
ERROR - 2011-04-03 17:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:15:47 --> Model Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Model Class Initialized
DEBUG - 2011-04-03 17:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:15:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:15:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:15:47 --> Final output sent to browser
DEBUG - 2011-04-03 17:15:47 --> Total execution time: 0.1909
DEBUG - 2011-04-03 17:15:48 --> Config Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:15:48 --> URI Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Router Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Output Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Input Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:15:48 --> Language Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Loader Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Controller Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Model Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Model Class Initialized
DEBUG - 2011-04-03 17:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:15:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:15:49 --> Final output sent to browser
DEBUG - 2011-04-03 17:15:49 --> Total execution time: 0.9729
DEBUG - 2011-04-03 17:15:50 --> Config Class Initialized
DEBUG - 2011-04-03 17:15:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:15:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:15:50 --> URI Class Initialized
DEBUG - 2011-04-03 17:15:50 --> Router Class Initialized
ERROR - 2011-04-03 17:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 17:15:50 --> Config Class Initialized
DEBUG - 2011-04-03 17:15:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:15:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:15:50 --> URI Class Initialized
DEBUG - 2011-04-03 17:15:50 --> Router Class Initialized
ERROR - 2011-04-03 17:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 17:15:51 --> Config Class Initialized
DEBUG - 2011-04-03 17:15:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:15:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:15:51 --> URI Class Initialized
DEBUG - 2011-04-03 17:15:51 --> Router Class Initialized
ERROR - 2011-04-03 17:15:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 17:16:20 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:20 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:20 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Controller Class Initialized
ERROR - 2011-04-03 17:16:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:16:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:16:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:20 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:16:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:16:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:16:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:16:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:16:20 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:20 --> Total execution time: 0.0266
DEBUG - 2011-04-03 17:16:21 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:21 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:21 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Controller Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:22 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:22 --> Total execution time: 0.8630
DEBUG - 2011-04-03 17:16:33 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:33 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:33 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Controller Class Initialized
ERROR - 2011-04-03 17:16:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:16:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:16:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:33 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:16:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:16:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:16:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:16:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:16:33 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:33 --> Total execution time: 0.0296
DEBUG - 2011-04-03 17:16:34 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:34 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:34 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Controller Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:34 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:34 --> Total execution time: 0.7866
DEBUG - 2011-04-03 17:16:42 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:42 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:42 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Controller Class Initialized
ERROR - 2011-04-03 17:16:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:16:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:16:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:42 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:16:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:16:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:16:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:16:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:16:42 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:42 --> Total execution time: 0.0394
DEBUG - 2011-04-03 17:16:42 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:42 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:42 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Controller Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:43 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:43 --> Total execution time: 0.6975
DEBUG - 2011-04-03 17:16:53 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:53 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:53 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Controller Class Initialized
ERROR - 2011-04-03 17:16:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:16:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:16:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:53 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:16:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:16:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:16:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:16:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:16:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:16:53 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:53 --> Total execution time: 0.0331
DEBUG - 2011-04-03 17:16:53 --> Config Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:16:53 --> URI Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Router Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Output Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Input Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:16:53 --> Language Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Loader Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Controller Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Model Class Initialized
DEBUG - 2011-04-03 17:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:16:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:16:54 --> Final output sent to browser
DEBUG - 2011-04-03 17:16:54 --> Total execution time: 0.6406
DEBUG - 2011-04-03 17:48:22 --> Config Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:48:22 --> URI Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Router Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Output Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Input Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:48:22 --> Language Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Loader Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Controller Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:48:22 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 17:48:23 --> Config Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:48:23 --> URI Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Router Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Output Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Input Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:48:23 --> Language Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:48:23 --> Loader Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Controller Class Initialized
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:48:23 --> Final output sent to browser
DEBUG - 2011-04-03 17:48:23 --> Total execution time: 1.2279
ERROR - 2011-04-03 17:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:48:23 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:48:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:48:23 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:48:23 --> Final output sent to browser
DEBUG - 2011-04-03 17:48:23 --> Total execution time: 0.1368
DEBUG - 2011-04-03 17:48:24 --> Config Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:48:24 --> URI Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Router Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Output Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Input Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:48:24 --> Language Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Loader Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Controller Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Model Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:48:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Config Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:48:24 --> URI Class Initialized
DEBUG - 2011-04-03 17:48:24 --> Router Class Initialized
ERROR - 2011-04-03 17:48:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 17:48:25 --> Final output sent to browser
DEBUG - 2011-04-03 17:48:25 --> Total execution time: 0.5361
DEBUG - 2011-04-03 17:50:06 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:06 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:06 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:06 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:06 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:06 --> Total execution time: 0.0347
DEBUG - 2011-04-03 17:50:07 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:07 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:07 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Router Class Initialized
ERROR - 2011-04-03 17:50:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 17:50:07 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:07 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Controller Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:07 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:07 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:07 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:07 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:07 --> Total execution time: 0.0287
DEBUG - 2011-04-03 17:50:07 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:07 --> Total execution time: 0.5998
DEBUG - 2011-04-03 17:50:19 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:19 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:19 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:19 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:19 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:19 --> Total execution time: 0.0275
DEBUG - 2011-04-03 17:50:19 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:19 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:19 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Controller Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:20 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:20 --> Total execution time: 0.5048
DEBUG - 2011-04-03 17:50:21 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:21 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:21 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:21 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:21 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:21 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:21 --> Total execution time: 0.0292
DEBUG - 2011-04-03 17:50:33 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:33 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:33 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:33 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:33 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:33 --> Total execution time: 0.0298
DEBUG - 2011-04-03 17:50:33 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:33 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:33 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:33 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:34 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:34 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:34 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:34 --> Total execution time: 0.0378
DEBUG - 2011-04-03 17:50:34 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:34 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:34 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Controller Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:34 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:34 --> Total execution time: 0.5644
DEBUG - 2011-04-03 17:50:41 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:41 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:41 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:41 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:41 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:41 --> Total execution time: 0.0286
DEBUG - 2011-04-03 17:50:42 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:42 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:42 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Controller Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:42 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:42 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:42 --> Total execution time: 0.5152
DEBUG - 2011-04-03 17:50:59 --> Config Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:50:59 --> URI Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Router Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Output Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Input Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:50:59 --> Language Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Loader Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Controller Class Initialized
ERROR - 2011-04-03 17:50:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 17:50:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 17:50:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:59 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Model Class Initialized
DEBUG - 2011-04-03 17:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:50:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:50:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 17:50:59 --> Helper loaded: url_helper
DEBUG - 2011-04-03 17:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 17:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 17:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 17:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 17:50:59 --> Final output sent to browser
DEBUG - 2011-04-03 17:50:59 --> Total execution time: 0.0284
DEBUG - 2011-04-03 17:51:00 --> Config Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 17:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 17:51:00 --> URI Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Router Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Output Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Input Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 17:51:00 --> Language Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Loader Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Controller Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Model Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Model Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 17:51:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 17:51:00 --> Final output sent to browser
DEBUG - 2011-04-03 17:51:00 --> Total execution time: 0.5284
DEBUG - 2011-04-03 18:31:36 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:36 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:36 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Controller Class Initialized
ERROR - 2011-04-03 18:31:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:31:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:36 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:37 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:31:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:31:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:31:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:31:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:31:37 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:37 --> Total execution time: 0.5014
DEBUG - 2011-04-03 18:31:37 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:37 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:37 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Controller Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:37 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:38 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:38 --> Total execution time: 0.6858
DEBUG - 2011-04-03 18:31:39 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:39 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:39 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:39 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:39 --> Router Class Initialized
ERROR - 2011-04-03 18:31:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:31:46 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:46 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:46 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Controller Class Initialized
ERROR - 2011-04-03 18:31:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:31:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:31:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:46 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:31:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:31:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:31:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:31:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:31:46 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:46 --> Total execution time: 0.0328
DEBUG - 2011-04-03 18:31:46 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:46 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:46 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Controller Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:46 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:47 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:47 --> Total execution time: 0.6209
DEBUG - 2011-04-03 18:31:47 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:47 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:47 --> Router Class Initialized
ERROR - 2011-04-03 18:31:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:31:52 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:52 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:52 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Controller Class Initialized
ERROR - 2011-04-03 18:31:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:31:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:31:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:52 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:52 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:31:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:31:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:31:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:31:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:31:52 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:52 --> Total execution time: 0.0275
DEBUG - 2011-04-03 18:31:52 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:52 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:52 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Controller Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:53 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:53 --> Total execution time: 0.5824
DEBUG - 2011-04-03 18:31:53 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:53 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:53 --> Router Class Initialized
ERROR - 2011-04-03 18:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:31:58 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:58 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:58 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Controller Class Initialized
ERROR - 2011-04-03 18:31:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:31:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:58 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:31:58 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:31:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:31:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:31:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:31:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:31:58 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:58 --> Total execution time: 0.0283
DEBUG - 2011-04-03 18:31:58 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:58 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Router Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Output Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Input Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:31:58 --> Language Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Loader Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Controller Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Model Class Initialized
DEBUG - 2011-04-03 18:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:31:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:31:59 --> Final output sent to browser
DEBUG - 2011-04-03 18:31:59 --> Total execution time: 0.6511
DEBUG - 2011-04-03 18:31:59 --> Config Class Initialized
DEBUG - 2011-04-03 18:31:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:31:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:31:59 --> URI Class Initialized
DEBUG - 2011-04-03 18:31:59 --> Router Class Initialized
ERROR - 2011-04-03 18:31:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:32:05 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:05 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:05 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Controller Class Initialized
ERROR - 2011-04-03 18:32:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:32:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:32:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:05 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:05 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:32:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:32:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:32:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:32:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:32:05 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:05 --> Total execution time: 0.0278
DEBUG - 2011-04-03 18:32:06 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:06 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:06 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Controller Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:06 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:06 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:06 --> Total execution time: 0.5298
DEBUG - 2011-04-03 18:32:07 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:07 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:07 --> Router Class Initialized
ERROR - 2011-04-03 18:32:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:32:25 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:25 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:25 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Controller Class Initialized
ERROR - 2011-04-03 18:32:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:32:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:25 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:25 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:32:25 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:25 --> Total execution time: 0.0275
DEBUG - 2011-04-03 18:32:26 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:26 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:26 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Controller Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:26 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:26 --> Total execution time: 0.4931
DEBUG - 2011-04-03 18:32:27 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:27 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:27 --> Router Class Initialized
ERROR - 2011-04-03 18:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:32:43 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:43 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:43 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Controller Class Initialized
ERROR - 2011-04-03 18:32:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:32:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:32:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:43 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:43 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:32:43 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:43 --> Total execution time: 0.0359
DEBUG - 2011-04-03 18:32:43 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:43 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:43 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Controller Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:44 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:44 --> Total execution time: 0.5300
DEBUG - 2011-04-03 18:32:44 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:44 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:44 --> Router Class Initialized
ERROR - 2011-04-03 18:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:32:53 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:53 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:53 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Controller Class Initialized
ERROR - 2011-04-03 18:32:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:32:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:53 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:32:53 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:32:53 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:53 --> Total execution time: 0.0285
DEBUG - 2011-04-03 18:32:54 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:54 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Router Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Output Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Input Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:32:54 --> Language Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Loader Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Controller Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Model Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:32:54 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:32:54 --> Final output sent to browser
DEBUG - 2011-04-03 18:32:54 --> Total execution time: 0.5821
DEBUG - 2011-04-03 18:32:55 --> Config Class Initialized
DEBUG - 2011-04-03 18:32:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:32:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:32:55 --> URI Class Initialized
DEBUG - 2011-04-03 18:32:55 --> Router Class Initialized
ERROR - 2011-04-03 18:32:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:33:05 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:05 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:05 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Controller Class Initialized
ERROR - 2011-04-03 18:33:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:33:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:33:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:05 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:05 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:05 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:33:05 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:05 --> Total execution time: 0.0302
DEBUG - 2011-04-03 18:33:05 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:05 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:05 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Controller Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:05 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:06 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:06 --> Total execution time: 0.8021
DEBUG - 2011-04-03 18:33:07 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:07 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:07 --> Router Class Initialized
ERROR - 2011-04-03 18:33:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:33:23 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:23 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:23 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Controller Class Initialized
ERROR - 2011-04-03 18:33:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:33:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:33:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:23 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:23 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:33:23 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:23 --> Total execution time: 0.0302
DEBUG - 2011-04-03 18:33:23 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:23 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:23 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Controller Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:24 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:24 --> Total execution time: 0.5111
DEBUG - 2011-04-03 18:33:24 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:24 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:24 --> Router Class Initialized
ERROR - 2011-04-03 18:33:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:33:33 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:33 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:33 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Controller Class Initialized
ERROR - 2011-04-03 18:33:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:33:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:33:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:33 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:33:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:33:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:33:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:33:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:33:33 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:33 --> Total execution time: 0.0291
DEBUG - 2011-04-03 18:33:33 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:33 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:33 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Controller Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:34 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:34 --> Total execution time: 0.5117
DEBUG - 2011-04-03 18:33:34 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:34 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:34 --> Router Class Initialized
ERROR - 2011-04-03 18:33:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:33:43 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:43 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:43 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Controller Class Initialized
ERROR - 2011-04-03 18:33:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:33:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:43 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:43 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:33:43 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:43 --> Total execution time: 0.0283
DEBUG - 2011-04-03 18:33:44 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:44 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:44 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Controller Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:44 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:44 --> Total execution time: 0.8640
DEBUG - 2011-04-03 18:33:45 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:45 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:45 --> Router Class Initialized
ERROR - 2011-04-03 18:33:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:33:57 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:57 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:57 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Controller Class Initialized
ERROR - 2011-04-03 18:33:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:33:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:33:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:57 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:33:57 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:33:57 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:57 --> Total execution time: 0.0280
DEBUG - 2011-04-03 18:33:57 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:57 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Router Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Output Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Input Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:33:57 --> Language Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Loader Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Controller Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Model Class Initialized
DEBUG - 2011-04-03 18:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:33:57 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:33:58 --> Final output sent to browser
DEBUG - 2011-04-03 18:33:58 --> Total execution time: 0.4918
DEBUG - 2011-04-03 18:33:58 --> Config Class Initialized
DEBUG - 2011-04-03 18:33:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:33:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:33:58 --> URI Class Initialized
DEBUG - 2011-04-03 18:33:58 --> Router Class Initialized
ERROR - 2011-04-03 18:33:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:34:08 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:08 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:08 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Controller Class Initialized
ERROR - 2011-04-03 18:34:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:34:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:08 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:08 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:08 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:34:08 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:08 --> Total execution time: 0.0335
DEBUG - 2011-04-03 18:34:09 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:09 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:09 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Controller Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:09 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:09 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:09 --> Total execution time: 0.5887
DEBUG - 2011-04-03 18:34:10 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:10 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:10 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:10 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:10 --> Router Class Initialized
ERROR - 2011-04-03 18:34:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:34:17 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:17 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:17 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Controller Class Initialized
ERROR - 2011-04-03 18:34:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:34:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:34:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:17 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:17 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:34:17 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:17 --> Total execution time: 0.0353
DEBUG - 2011-04-03 18:34:17 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:17 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:17 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Controller Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:17 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:18 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:18 --> Total execution time: 0.5569
DEBUG - 2011-04-03 18:34:18 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:18 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:18 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:18 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:18 --> Router Class Initialized
ERROR - 2011-04-03 18:34:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:34:25 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:25 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:25 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Controller Class Initialized
ERROR - 2011-04-03 18:34:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:34:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:34:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:25 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:25 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:25 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:34:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:34:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:34:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:34:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:34:25 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:25 --> Total execution time: 0.0283
DEBUG - 2011-04-03 18:34:26 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:26 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:26 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Controller Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:26 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:26 --> Total execution time: 0.5422
DEBUG - 2011-04-03 18:34:27 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:27 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:27 --> Router Class Initialized
ERROR - 2011-04-03 18:34:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:34:35 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:35 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:35 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Controller Class Initialized
ERROR - 2011-04-03 18:34:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:34:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:35 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:34:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:34:35 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:35 --> Total execution time: 0.0280
DEBUG - 2011-04-03 18:34:36 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:36 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Router Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Output Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Input Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:34:36 --> Language Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Loader Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Controller Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Model Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:34:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:34:36 --> Final output sent to browser
DEBUG - 2011-04-03 18:34:36 --> Total execution time: 0.5245
DEBUG - 2011-04-03 18:34:37 --> Config Class Initialized
DEBUG - 2011-04-03 18:34:37 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:34:37 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:34:37 --> URI Class Initialized
DEBUG - 2011-04-03 18:34:37 --> Router Class Initialized
ERROR - 2011-04-03 18:34:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:35:26 --> Config Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:35:26 --> URI Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Router Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Output Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Input Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:35:26 --> Language Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Loader Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Controller Class Initialized
ERROR - 2011-04-03 18:35:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:35:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:35:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:35:26 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:35:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:35:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:35:26 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:35:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:35:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:35:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:35:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:35:26 --> Final output sent to browser
DEBUG - 2011-04-03 18:35:26 --> Total execution time: 0.0276
DEBUG - 2011-04-03 18:35:27 --> Config Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:35:27 --> URI Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Router Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Output Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Input Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:35:27 --> Language Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Loader Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Controller Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:35:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:35:27 --> Final output sent to browser
DEBUG - 2011-04-03 18:35:27 --> Total execution time: 0.6146
DEBUG - 2011-04-03 18:35:28 --> Config Class Initialized
DEBUG - 2011-04-03 18:35:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:35:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:35:28 --> URI Class Initialized
DEBUG - 2011-04-03 18:35:28 --> Router Class Initialized
ERROR - 2011-04-03 18:35:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 18:35:42 --> Config Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:35:42 --> URI Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Router Class Initialized
DEBUG - 2011-04-03 18:35:42 --> No URI present. Default controller set.
DEBUG - 2011-04-03 18:35:42 --> Output Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Input Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:35:42 --> Language Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Loader Class Initialized
DEBUG - 2011-04-03 18:35:42 --> Controller Class Initialized
DEBUG - 2011-04-03 18:35:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 18:35:42 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:35:42 --> Final output sent to browser
DEBUG - 2011-04-03 18:35:42 --> Total execution time: 0.0686
DEBUG - 2011-04-03 18:35:58 --> Config Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:35:58 --> URI Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Router Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Output Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Input Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:35:58 --> Language Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Loader Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Controller Class Initialized
ERROR - 2011-04-03 18:35:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 18:35:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 18:35:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:35:58 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:35:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:35:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 18:35:58 --> Helper loaded: url_helper
DEBUG - 2011-04-03 18:35:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 18:35:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 18:35:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 18:35:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 18:35:58 --> Final output sent to browser
DEBUG - 2011-04-03 18:35:58 --> Total execution time: 0.0293
DEBUG - 2011-04-03 18:35:59 --> Config Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:35:59 --> URI Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Router Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Output Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Input Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 18:35:59 --> Language Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Loader Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Controller Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Model Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 18:35:59 --> Database Driver Class Initialized
DEBUG - 2011-04-03 18:35:59 --> Final output sent to browser
DEBUG - 2011-04-03 18:35:59 --> Total execution time: 0.7530
DEBUG - 2011-04-03 18:36:00 --> Config Class Initialized
DEBUG - 2011-04-03 18:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 18:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 18:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 18:36:00 --> URI Class Initialized
DEBUG - 2011-04-03 18:36:00 --> Router Class Initialized
ERROR - 2011-04-03 18:36:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:01:38 --> Config Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:01:38 --> URI Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Router Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Output Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Input Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:01:38 --> Language Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Loader Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Controller Class Initialized
ERROR - 2011-04-03 19:01:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:01:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:01:38 --> Model Class Initialized
DEBUG - 2011-04-03 19:01:38 --> Model Class Initialized
DEBUG - 2011-04-03 19:01:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:01:39 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:01:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:01:40 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:01:40 --> Final output sent to browser
DEBUG - 2011-04-03 19:01:40 --> Total execution time: 1.7312
DEBUG - 2011-04-03 19:01:40 --> Config Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:01:40 --> URI Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Router Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Output Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Input Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:01:40 --> Language Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Loader Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Controller Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Model Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Model Class Initialized
DEBUG - 2011-04-03 19:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:01:40 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:01:41 --> Final output sent to browser
DEBUG - 2011-04-03 19:01:41 --> Total execution time: 0.5234
DEBUG - 2011-04-03 19:01:42 --> Config Class Initialized
DEBUG - 2011-04-03 19:01:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:01:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:01:42 --> URI Class Initialized
DEBUG - 2011-04-03 19:01:42 --> Router Class Initialized
ERROR - 2011-04-03 19:01:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:22:11 --> Config Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:22:11 --> URI Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Router Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Output Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Input Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:22:11 --> Language Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Loader Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Controller Class Initialized
ERROR - 2011-04-03 19:22:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:22:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:22:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:22:11 --> Model Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Model Class Initialized
DEBUG - 2011-04-03 19:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:22:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:22:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:22:12 --> Final output sent to browser
DEBUG - 2011-04-03 19:22:12 --> Total execution time: 0.2915
DEBUG - 2011-04-03 19:22:13 --> Config Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:22:13 --> URI Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Router Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Output Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Input Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:22:13 --> Language Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Loader Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Controller Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Model Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Model Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:22:13 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:22:13 --> Final output sent to browser
DEBUG - 2011-04-03 19:22:13 --> Total execution time: 0.5936
DEBUG - 2011-04-03 19:22:15 --> Config Class Initialized
DEBUG - 2011-04-03 19:22:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:22:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:22:15 --> URI Class Initialized
DEBUG - 2011-04-03 19:22:15 --> Router Class Initialized
ERROR - 2011-04-03 19:22:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:22:58 --> Config Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:22:58 --> URI Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Router Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Output Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Input Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:22:58 --> Language Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Loader Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Controller Class Initialized
ERROR - 2011-04-03 19:22:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:22:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:22:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:22:58 --> Model Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Model Class Initialized
DEBUG - 2011-04-03 19:22:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:22:58 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:22:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:22:58 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:22:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:22:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:22:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:22:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:22:58 --> Final output sent to browser
DEBUG - 2011-04-03 19:22:58 --> Total execution time: 0.0317
DEBUG - 2011-04-03 19:23:00 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:00 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:00 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Controller Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:00 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:01 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:01 --> Total execution time: 0.5030
DEBUG - 2011-04-03 19:23:12 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:12 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:12 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Controller Class Initialized
ERROR - 2011-04-03 19:23:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:23:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:12 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:23:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:23:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:23:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:23:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:23:12 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:12 --> Total execution time: 0.0948
DEBUG - 2011-04-03 19:23:12 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:12 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:12 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Controller Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:13 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:13 --> Total execution time: 0.6147
DEBUG - 2011-04-03 19:23:15 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:15 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:15 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:15 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:15 --> Router Class Initialized
ERROR - 2011-04-03 19:23:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:23:21 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:21 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:21 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Controller Class Initialized
ERROR - 2011-04-03 19:23:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:23:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:23:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:21 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:21 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:21 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:23:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:23:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:23:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:23:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:23:21 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:21 --> Total execution time: 0.0398
DEBUG - 2011-04-03 19:23:22 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:22 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:22 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Controller Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:22 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:22 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:22 --> Total execution time: 0.5295
DEBUG - 2011-04-03 19:23:23 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:23 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:23 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Controller Class Initialized
ERROR - 2011-04-03 19:23:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:23:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:23:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:23 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:23 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:23 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:23:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:23:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:23:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:23:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:23:23 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:23 --> Total execution time: 0.0288
DEBUG - 2011-04-03 19:23:28 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:28 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:28 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:28 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:28 --> Router Class Initialized
ERROR - 2011-04-03 19:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:23:35 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:35 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:35 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Controller Class Initialized
ERROR - 2011-04-03 19:23:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:23:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:35 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:23:35 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:35 --> Total execution time: 0.0285
DEBUG - 2011-04-03 19:23:36 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:36 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:36 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Controller Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:37 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:37 --> Total execution time: 0.5648
DEBUG - 2011-04-03 19:23:43 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:43 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:43 --> Router Class Initialized
ERROR - 2011-04-03 19:23:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:23:48 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:48 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:48 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Controller Class Initialized
ERROR - 2011-04-03 19:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:23:48 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:23:48 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:48 --> Total execution time: 0.0285
DEBUG - 2011-04-03 19:23:49 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:49 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Router Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Output Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Input Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:23:49 --> Language Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Loader Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Controller Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Model Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:23:49 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:23:49 --> Final output sent to browser
DEBUG - 2011-04-03 19:23:49 --> Total execution time: 0.5251
DEBUG - 2011-04-03 19:23:52 --> Config Class Initialized
DEBUG - 2011-04-03 19:23:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:23:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:23:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:23:52 --> URI Class Initialized
DEBUG - 2011-04-03 19:23:52 --> Router Class Initialized
ERROR - 2011-04-03 19:23:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:24:01 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:01 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Router Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Output Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Input Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:24:01 --> Language Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Loader Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Controller Class Initialized
ERROR - 2011-04-03 19:24:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:24:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:24:01 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:24:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:24:01 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:24:01 --> Final output sent to browser
DEBUG - 2011-04-03 19:24:01 --> Total execution time: 0.0307
DEBUG - 2011-04-03 19:24:03 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:03 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:03 --> Router Class Initialized
ERROR - 2011-04-03 19:24:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:24:19 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:19 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Router Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Output Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Input Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:24:19 --> Language Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Loader Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Controller Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:24:19 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:24:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:24:19 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:24:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:24:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:24:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:24:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:24:20 --> Final output sent to browser
DEBUG - 2011-04-03 19:24:20 --> Total execution time: 0.3072
DEBUG - 2011-04-03 19:24:24 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:24 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:24 --> Router Class Initialized
ERROR - 2011-04-03 19:24:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:24:27 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:27 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Router Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Output Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Input Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:24:27 --> Language Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Loader Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Controller Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:24:27 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:24:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:24:27 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:24:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:24:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:24:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:24:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:24:27 --> Final output sent to browser
DEBUG - 2011-04-03 19:24:27 --> Total execution time: 0.2061
DEBUG - 2011-04-03 19:24:29 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:29 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:29 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:29 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:29 --> Router Class Initialized
ERROR - 2011-04-03 19:24:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:24:33 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:33 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Router Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Output Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Input Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:24:33 --> Language Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Loader Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Controller Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:24:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:24:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:24:35 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:24:35 --> Final output sent to browser
DEBUG - 2011-04-03 19:24:35 --> Total execution time: 1.7337
DEBUG - 2011-04-03 19:24:36 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:36 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:36 --> Router Class Initialized
ERROR - 2011-04-03 19:24:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:24:41 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:41 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Router Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Output Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Input Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:24:41 --> Language Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Loader Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Controller Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:24:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:24:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:24:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:24:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:24:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:24:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:24:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:24:41 --> Final output sent to browser
DEBUG - 2011-04-03 19:24:41 --> Total execution time: 0.2200
DEBUG - 2011-04-03 19:24:44 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:44 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:44 --> Router Class Initialized
ERROR - 2011-04-03 19:24:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:24:48 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:48 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Router Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Output Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Input Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:24:48 --> Language Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Loader Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Controller Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:24:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:24:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:24:49 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:24:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:24:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:24:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:24:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:24:49 --> Final output sent to browser
DEBUG - 2011-04-03 19:24:49 --> Total execution time: 0.2336
DEBUG - 2011-04-03 19:24:50 --> Config Class Initialized
DEBUG - 2011-04-03 19:24:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:24:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:24:50 --> URI Class Initialized
DEBUG - 2011-04-03 19:24:50 --> Router Class Initialized
ERROR - 2011-04-03 19:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:25:20 --> Config Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:25:20 --> URI Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Router Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Output Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Input Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:25:20 --> Language Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Loader Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Controller Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:25:20 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:25:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:25:20 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:25:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:25:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:25:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:25:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:25:20 --> Final output sent to browser
DEBUG - 2011-04-03 19:25:20 --> Total execution time: 0.2117
DEBUG - 2011-04-03 19:25:36 --> Config Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:25:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:25:36 --> URI Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Router Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Output Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Input Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:25:36 --> Language Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Loader Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Controller Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:25:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:25:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:25:36 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:25:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:25:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:25:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:25:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:25:36 --> Final output sent to browser
DEBUG - 2011-04-03 19:25:36 --> Total execution time: 0.1891
DEBUG - 2011-04-03 19:25:38 --> Config Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:25:38 --> URI Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Router Class Initialized
ERROR - 2011-04-03 19:25:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:25:38 --> Config Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:25:38 --> URI Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Router Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Output Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Input Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:25:38 --> Language Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Loader Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Controller Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:25:38 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:25:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:25:38 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:25:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:25:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:25:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:25:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:25:38 --> Final output sent to browser
DEBUG - 2011-04-03 19:25:38 --> Total execution time: 0.0425
DEBUG - 2011-04-03 19:25:41 --> Config Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:25:41 --> URI Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Router Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Output Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Input Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:25:41 --> Language Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Loader Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Controller Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Model Class Initialized
DEBUG - 2011-04-03 19:25:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:25:41 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:25:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 19:25:41 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:25:41 --> Final output sent to browser
DEBUG - 2011-04-03 19:25:41 --> Total execution time: 0.1979
DEBUG - 2011-04-03 19:25:43 --> Config Class Initialized
DEBUG - 2011-04-03 19:25:43 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:25:43 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:25:43 --> URI Class Initialized
DEBUG - 2011-04-03 19:25:43 --> Router Class Initialized
ERROR - 2011-04-03 19:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:26:03 --> Config Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:26:03 --> URI Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Router Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Output Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Input Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:26:03 --> Language Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Loader Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Controller Class Initialized
ERROR - 2011-04-03 19:26:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:26:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:26:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:26:03 --> Model Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Model Class Initialized
DEBUG - 2011-04-03 19:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:26:03 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:26:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:26:03 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:26:03 --> Final output sent to browser
DEBUG - 2011-04-03 19:26:03 --> Total execution time: 0.0308
DEBUG - 2011-04-03 19:26:04 --> Config Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:26:04 --> URI Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Router Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Output Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Input Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:26:04 --> Language Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Loader Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Controller Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Model Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Model Class Initialized
DEBUG - 2011-04-03 19:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:26:04 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:26:05 --> Final output sent to browser
DEBUG - 2011-04-03 19:26:05 --> Total execution time: 0.4459
DEBUG - 2011-04-03 19:26:07 --> Config Class Initialized
DEBUG - 2011-04-03 19:26:07 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:26:07 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:26:07 --> URI Class Initialized
DEBUG - 2011-04-03 19:26:07 --> Router Class Initialized
ERROR - 2011-04-03 19:26:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:26:08 --> Config Class Initialized
DEBUG - 2011-04-03 19:26:08 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:26:08 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:26:08 --> URI Class Initialized
DEBUG - 2011-04-03 19:26:08 --> Router Class Initialized
ERROR - 2011-04-03 19:26:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:27:48 --> Config Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:27:48 --> URI Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Router Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Output Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Input Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:27:48 --> Language Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Loader Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Controller Class Initialized
ERROR - 2011-04-03 19:27:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:27:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:27:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:27:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:27:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:27:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:27:48 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:27:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:27:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:27:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:27:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:27:48 --> Final output sent to browser
DEBUG - 2011-04-03 19:27:48 --> Total execution time: 0.0363
DEBUG - 2011-04-03 19:27:48 --> Config Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:27:48 --> URI Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Router Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Output Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Input Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:27:48 --> Language Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Loader Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Controller Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:27:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:27:49 --> Final output sent to browser
DEBUG - 2011-04-03 19:27:49 --> Total execution time: 0.7513
DEBUG - 2011-04-03 19:28:34 --> Config Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:28:34 --> URI Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Router Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Output Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Input Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:28:34 --> Language Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Loader Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Controller Class Initialized
ERROR - 2011-04-03 19:28:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:28:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:28:34 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:28:34 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:28:34 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:28:34 --> Final output sent to browser
DEBUG - 2011-04-03 19:28:34 --> Total execution time: 0.0889
DEBUG - 2011-04-03 19:28:35 --> Config Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:28:35 --> URI Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Router Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Output Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Input Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:28:35 --> Language Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Loader Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Controller Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:28:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:28:36 --> Final output sent to browser
DEBUG - 2011-04-03 19:28:36 --> Total execution time: 0.5847
DEBUG - 2011-04-03 19:28:47 --> Config Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:28:47 --> URI Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Router Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Output Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Input Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:28:47 --> Language Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Loader Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Controller Class Initialized
ERROR - 2011-04-03 19:28:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:28:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:28:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:28:47 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:28:47 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:28:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:28:47 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:28:47 --> Final output sent to browser
DEBUG - 2011-04-03 19:28:47 --> Total execution time: 0.0940
DEBUG - 2011-04-03 19:28:48 --> Config Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:28:48 --> URI Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Router Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Output Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Input Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:28:48 --> Language Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Loader Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Controller Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Model Class Initialized
DEBUG - 2011-04-03 19:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:28:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:28:49 --> Final output sent to browser
DEBUG - 2011-04-03 19:28:49 --> Total execution time: 0.5053
DEBUG - 2011-04-03 19:41:50 --> Config Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:41:50 --> URI Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Router Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Output Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Input Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:41:50 --> Language Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Loader Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Controller Class Initialized
ERROR - 2011-04-03 19:41:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:41:50 --> Model Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Model Class Initialized
DEBUG - 2011-04-03 19:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:41:51 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:41:51 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:41:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:41:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:41:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:41:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:41:51 --> Final output sent to browser
DEBUG - 2011-04-03 19:41:51 --> Total execution time: 0.1568
DEBUG - 2011-04-03 19:41:51 --> Config Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:41:51 --> URI Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Router Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Output Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Input Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:41:51 --> Language Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Loader Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Controller Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Model Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Model Class Initialized
DEBUG - 2011-04-03 19:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:41:51 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:41:52 --> Final output sent to browser
DEBUG - 2011-04-03 19:41:52 --> Total execution time: 0.9576
DEBUG - 2011-04-03 19:41:54 --> Config Class Initialized
DEBUG - 2011-04-03 19:41:54 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:41:54 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:41:54 --> URI Class Initialized
DEBUG - 2011-04-03 19:41:54 --> Router Class Initialized
ERROR - 2011-04-03 19:41:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:41:55 --> Config Class Initialized
DEBUG - 2011-04-03 19:41:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:41:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:41:55 --> URI Class Initialized
DEBUG - 2011-04-03 19:41:55 --> Router Class Initialized
ERROR - 2011-04-03 19:41:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 19:42:26 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:26 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:26 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Controller Class Initialized
ERROR - 2011-04-03 19:42:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:42:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:26 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:26 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:42:26 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:26 --> Total execution time: 0.0298
DEBUG - 2011-04-03 19:42:26 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:26 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:26 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Controller Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:26 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:27 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:27 --> Total execution time: 0.6649
DEBUG - 2011-04-03 19:42:35 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:35 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:35 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Controller Class Initialized
ERROR - 2011-04-03 19:42:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:42:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:42:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:35 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:35 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:36 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:42:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:42:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:42:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:42:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:42:36 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:36 --> Total execution time: 0.0412
DEBUG - 2011-04-03 19:42:36 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:36 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:36 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Controller Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:36 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:37 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:37 --> Total execution time: 0.6774
DEBUG - 2011-04-03 19:42:44 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:44 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:44 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Controller Class Initialized
ERROR - 2011-04-03 19:42:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:42:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:44 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:44 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:42:44 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:44 --> Total execution time: 0.0312
DEBUG - 2011-04-03 19:42:45 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:45 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:45 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Controller Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:45 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:45 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:45 --> Total execution time: 0.5507
DEBUG - 2011-04-03 19:42:55 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:55 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:55 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Controller Class Initialized
ERROR - 2011-04-03 19:42:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:42:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:42:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:55 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:55 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:42:55 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:42:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:42:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:42:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:42:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:42:55 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:55 --> Total execution time: 0.0271
DEBUG - 2011-04-03 19:42:56 --> Config Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:42:56 --> URI Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Router Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Output Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Input Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:42:56 --> Language Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Loader Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Controller Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Model Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:42:56 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:42:56 --> Final output sent to browser
DEBUG - 2011-04-03 19:42:56 --> Total execution time: 0.4787
DEBUG - 2011-04-03 19:43:01 --> Config Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:43:01 --> URI Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Router Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Output Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Input Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:43:01 --> Language Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Loader Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Controller Class Initialized
ERROR - 2011-04-03 19:43:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:43:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:43:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:43:01 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:43:01 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:43:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:43:01 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:43:02 --> Final output sent to browser
DEBUG - 2011-04-03 19:43:02 --> Total execution time: 0.1000
DEBUG - 2011-04-03 19:43:02 --> Config Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:43:02 --> URI Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Router Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Output Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Input Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:43:02 --> Language Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Loader Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Controller Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:43:02 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:43:03 --> Final output sent to browser
DEBUG - 2011-04-03 19:43:03 --> Total execution time: 0.6720
DEBUG - 2011-04-03 19:43:12 --> Config Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:43:12 --> URI Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Router Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Output Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Input Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:43:12 --> Language Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Loader Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Controller Class Initialized
ERROR - 2011-04-03 19:43:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 19:43:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 19:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:43:12 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:43:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 19:43:12 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:43:12 --> Final output sent to browser
DEBUG - 2011-04-03 19:43:12 --> Total execution time: 0.0504
DEBUG - 2011-04-03 19:43:14 --> Config Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:43:14 --> URI Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Router Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Output Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Input Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:43:14 --> Language Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Loader Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Controller Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Model Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 19:43:14 --> Database Driver Class Initialized
DEBUG - 2011-04-03 19:43:14 --> Final output sent to browser
DEBUG - 2011-04-03 19:43:14 --> Total execution time: 0.5316
DEBUG - 2011-04-03 19:57:31 --> Config Class Initialized
DEBUG - 2011-04-03 19:57:31 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:57:31 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:57:31 --> URI Class Initialized
DEBUG - 2011-04-03 19:57:31 --> Router Class Initialized
ERROR - 2011-04-03 19:57:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 19:57:32 --> Config Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Hooks Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Utf8 Class Initialized
DEBUG - 2011-04-03 19:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 19:57:32 --> URI Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Router Class Initialized
DEBUG - 2011-04-03 19:57:32 --> No URI present. Default controller set.
DEBUG - 2011-04-03 19:57:32 --> Output Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Input Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 19:57:32 --> Language Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Loader Class Initialized
DEBUG - 2011-04-03 19:57:32 --> Controller Class Initialized
DEBUG - 2011-04-03 19:57:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 19:57:32 --> Helper loaded: url_helper
DEBUG - 2011-04-03 19:57:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 19:57:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 19:57:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 19:57:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 19:57:32 --> Final output sent to browser
DEBUG - 2011-04-03 19:57:32 --> Total execution time: 0.2476
DEBUG - 2011-04-03 20:15:11 --> Config Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Hooks Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Utf8 Class Initialized
DEBUG - 2011-04-03 20:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 20:15:11 --> URI Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Router Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Output Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Input Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 20:15:11 --> Language Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Loader Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Controller Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Model Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Model Class Initialized
DEBUG - 2011-04-03 20:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 20:15:12 --> Database Driver Class Initialized
DEBUG - 2011-04-03 20:15:12 --> Final output sent to browser
DEBUG - 2011-04-03 20:15:12 --> Total execution time: 1.2438
DEBUG - 2011-04-03 21:36:04 --> Config Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:36:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:36:04 --> URI Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Router Class Initialized
DEBUG - 2011-04-03 21:36:04 --> No URI present. Default controller set.
DEBUG - 2011-04-03 21:36:04 --> Output Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Input Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 21:36:04 --> Language Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Loader Class Initialized
DEBUG - 2011-04-03 21:36:04 --> Controller Class Initialized
DEBUG - 2011-04-03 21:36:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 21:36:06 --> Helper loaded: url_helper
DEBUG - 2011-04-03 21:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 21:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 21:36:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 21:36:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 21:36:08 --> Final output sent to browser
DEBUG - 2011-04-03 21:36:08 --> Total execution time: 3.5020
DEBUG - 2011-04-03 21:36:21 --> Config Class Initialized
DEBUG - 2011-04-03 21:36:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:36:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:36:21 --> URI Class Initialized
DEBUG - 2011-04-03 21:36:21 --> Router Class Initialized
ERROR - 2011-04-03 21:36:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 21:36:24 --> Config Class Initialized
DEBUG - 2011-04-03 21:36:24 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:36:24 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:36:24 --> URI Class Initialized
DEBUG - 2011-04-03 21:36:24 --> Router Class Initialized
ERROR - 2011-04-03 21:36:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 21:36:38 --> Config Class Initialized
DEBUG - 2011-04-03 21:36:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:36:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:36:38 --> URI Class Initialized
DEBUG - 2011-04-03 21:36:38 --> Router Class Initialized
DEBUG - 2011-04-03 21:36:38 --> Output Class Initialized
DEBUG - 2011-04-03 21:36:38 --> Input Class Initialized
DEBUG - 2011-04-03 21:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 21:36:38 --> Language Class Initialized
DEBUG - 2011-04-03 21:36:39 --> Loader Class Initialized
DEBUG - 2011-04-03 21:36:39 --> Controller Class Initialized
DEBUG - 2011-04-03 21:36:39 --> Model Class Initialized
DEBUG - 2011-04-03 21:36:41 --> Model Class Initialized
DEBUG - 2011-04-03 21:36:42 --> Model Class Initialized
DEBUG - 2011-04-03 21:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 21:36:48 --> Database Driver Class Initialized
DEBUG - 2011-04-03 21:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 21:36:49 --> Helper loaded: url_helper
DEBUG - 2011-04-03 21:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 21:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 21:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 21:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 21:36:49 --> Final output sent to browser
DEBUG - 2011-04-03 21:36:49 --> Total execution time: 11.5806
DEBUG - 2011-04-03 21:49:33 --> Config Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:49:33 --> URI Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Router Class Initialized
ERROR - 2011-04-03 21:49:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-03 21:49:33 --> Config Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:49:33 --> URI Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Router Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Output Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Input Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 21:49:33 --> Language Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Loader Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Controller Class Initialized
ERROR - 2011-04-03 21:49:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 21:49:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 21:49:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 21:49:33 --> Model Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Model Class Initialized
DEBUG - 2011-04-03 21:49:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 21:49:33 --> Database Driver Class Initialized
DEBUG - 2011-04-03 21:49:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 21:49:33 --> Helper loaded: url_helper
DEBUG - 2011-04-03 21:49:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 21:49:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 21:49:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 21:49:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 21:49:33 --> Final output sent to browser
DEBUG - 2011-04-03 21:49:33 --> Total execution time: 0.1649
DEBUG - 2011-04-03 21:52:46 --> Config Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:52:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:52:46 --> URI Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Router Class Initialized
DEBUG - 2011-04-03 21:52:46 --> No URI present. Default controller set.
DEBUG - 2011-04-03 21:52:46 --> Output Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Input Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 21:52:46 --> Language Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Loader Class Initialized
DEBUG - 2011-04-03 21:52:46 --> Controller Class Initialized
DEBUG - 2011-04-03 21:52:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 21:52:46 --> Helper loaded: url_helper
DEBUG - 2011-04-03 21:52:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 21:52:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 21:52:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 21:52:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 21:52:46 --> Final output sent to browser
DEBUG - 2011-04-03 21:52:46 --> Total execution time: 0.0384
DEBUG - 2011-04-03 21:52:47 --> Config Class Initialized
DEBUG - 2011-04-03 21:52:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 21:52:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 21:52:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 21:52:47 --> URI Class Initialized
DEBUG - 2011-04-03 21:52:47 --> Router Class Initialized
ERROR - 2011-04-03 21:52:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 22:18:44 --> Config Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:18:44 --> URI Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Router Class Initialized
DEBUG - 2011-04-03 22:18:44 --> No URI present. Default controller set.
DEBUG - 2011-04-03 22:18:44 --> Output Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Input Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:18:44 --> Language Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Loader Class Initialized
DEBUG - 2011-04-03 22:18:44 --> Controller Class Initialized
DEBUG - 2011-04-03 22:18:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 22:18:44 --> Helper loaded: url_helper
DEBUG - 2011-04-03 22:18:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 22:18:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 22:18:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 22:18:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 22:18:44 --> Final output sent to browser
DEBUG - 2011-04-03 22:18:44 --> Total execution time: 0.2476
DEBUG - 2011-04-03 22:18:47 --> Config Class Initialized
DEBUG - 2011-04-03 22:18:47 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:18:47 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:18:47 --> URI Class Initialized
DEBUG - 2011-04-03 22:18:47 --> Router Class Initialized
ERROR - 2011-04-03 22:18:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 22:18:48 --> Config Class Initialized
DEBUG - 2011-04-03 22:18:48 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:18:48 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:18:48 --> URI Class Initialized
DEBUG - 2011-04-03 22:18:48 --> Router Class Initialized
ERROR - 2011-04-03 22:18:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 22:18:49 --> Config Class Initialized
DEBUG - 2011-04-03 22:18:49 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:18:49 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:18:49 --> URI Class Initialized
DEBUG - 2011-04-03 22:18:49 --> Router Class Initialized
ERROR - 2011-04-03 22:18:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-03 22:20:21 --> Config Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:20:21 --> URI Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Router Class Initialized
DEBUG - 2011-04-03 22:20:21 --> No URI present. Default controller set.
DEBUG - 2011-04-03 22:20:21 --> Output Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Input Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:20:21 --> Language Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Loader Class Initialized
DEBUG - 2011-04-03 22:20:21 --> Controller Class Initialized
DEBUG - 2011-04-03 22:20:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 22:20:21 --> Helper loaded: url_helper
DEBUG - 2011-04-03 22:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 22:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 22:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 22:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 22:20:21 --> Final output sent to browser
DEBUG - 2011-04-03 22:20:21 --> Total execution time: 0.0854
DEBUG - 2011-04-03 22:20:23 --> Config Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:20:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:20:23 --> URI Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Router Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Output Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Input Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:20:23 --> Language Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Loader Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Controller Class Initialized
DEBUG - 2011-04-03 22:20:23 --> Model Class Initialized
DEBUG - 2011-04-03 22:20:24 --> Model Class Initialized
DEBUG - 2011-04-03 22:20:24 --> Model Class Initialized
DEBUG - 2011-04-03 22:20:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 22:20:24 --> Database Driver Class Initialized
DEBUG - 2011-04-03 22:20:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 22:20:24 --> Helper loaded: url_helper
DEBUG - 2011-04-03 22:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 22:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 22:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 22:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 22:20:24 --> Final output sent to browser
DEBUG - 2011-04-03 22:20:24 --> Total execution time: 1.4857
DEBUG - 2011-04-03 22:20:52 --> Config Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:20:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:20:52 --> URI Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Router Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Output Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Input Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:20:52 --> Language Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Loader Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Controller Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Model Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Model Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Model Class Initialized
DEBUG - 2011-04-03 22:20:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 22:20:52 --> Database Driver Class Initialized
DEBUG - 2011-04-03 22:20:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-03 22:20:52 --> Helper loaded: url_helper
DEBUG - 2011-04-03 22:20:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 22:20:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 22:20:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 22:20:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 22:20:52 --> Final output sent to browser
DEBUG - 2011-04-03 22:20:52 --> Total execution time: 0.2256
DEBUG - 2011-04-03 22:22:38 --> Config Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:22:38 --> URI Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Router Class Initialized
DEBUG - 2011-04-03 22:22:38 --> No URI present. Default controller set.
DEBUG - 2011-04-03 22:22:38 --> Output Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Input Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:22:38 --> Language Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Loader Class Initialized
DEBUG - 2011-04-03 22:22:38 --> Controller Class Initialized
DEBUG - 2011-04-03 22:22:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-03 22:22:38 --> Helper loaded: url_helper
DEBUG - 2011-04-03 22:22:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 22:22:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 22:22:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 22:22:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 22:22:38 --> Final output sent to browser
DEBUG - 2011-04-03 22:22:38 --> Total execution time: 0.0131
DEBUG - 2011-04-03 22:22:42 --> Config Class Initialized
DEBUG - 2011-04-03 22:22:42 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:22:42 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:22:42 --> URI Class Initialized
DEBUG - 2011-04-03 22:22:42 --> Router Class Initialized
DEBUG - 2011-04-03 22:22:42 --> Output Class Initialized
DEBUG - 2011-04-03 22:22:42 --> Input Class Initialized
DEBUG - 2011-04-03 22:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:22:42 --> Language Class Initialized
DEBUG - 2011-04-03 22:22:43 --> Loader Class Initialized
DEBUG - 2011-04-03 22:22:43 --> Controller Class Initialized
ERROR - 2011-04-03 22:22:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-03 22:22:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-03 22:22:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 22:22:43 --> Model Class Initialized
DEBUG - 2011-04-03 22:22:43 --> Model Class Initialized
DEBUG - 2011-04-03 22:22:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 22:22:43 --> Database Driver Class Initialized
DEBUG - 2011-04-03 22:22:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-03 22:22:43 --> Helper loaded: url_helper
DEBUG - 2011-04-03 22:22:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-03 22:22:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-03 22:22:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-03 22:22:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-03 22:22:43 --> Final output sent to browser
DEBUG - 2011-04-03 22:22:43 --> Total execution time: 1.0137
DEBUG - 2011-04-03 22:22:44 --> Config Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Hooks Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Utf8 Class Initialized
DEBUG - 2011-04-03 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-03 22:22:44 --> URI Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Router Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Output Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Input Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-03 22:22:44 --> Language Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Loader Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Controller Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Model Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Model Class Initialized
DEBUG - 2011-04-03 22:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-03 22:22:44 --> Database Driver Class Initialized
DEBUG - 2011-04-03 22:22:46 --> Final output sent to browser
DEBUG - 2011-04-03 22:22:46 --> Total execution time: 1.5714

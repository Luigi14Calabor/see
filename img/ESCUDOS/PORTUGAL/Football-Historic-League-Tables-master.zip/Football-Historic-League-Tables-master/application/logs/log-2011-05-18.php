<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-18 00:38:53 --> Config Class Initialized
DEBUG - 2011-05-18 00:38:53 --> Hooks Class Initialized
DEBUG - 2011-05-18 00:38:53 --> Utf8 Class Initialized
DEBUG - 2011-05-18 00:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 00:38:53 --> URI Class Initialized
DEBUG - 2011-05-18 00:38:53 --> Router Class Initialized
ERROR - 2011-05-18 00:38:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-18 04:48:32 --> Config Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:48:32 --> URI Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Router Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Output Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Input Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 04:48:32 --> Language Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Loader Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Controller Class Initialized
ERROR - 2011-05-18 04:48:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 04:48:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 04:48:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 04:48:32 --> Model Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Model Class Initialized
DEBUG - 2011-05-18 04:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 04:48:32 --> Database Driver Class Initialized
DEBUG - 2011-05-18 04:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 04:48:33 --> Helper loaded: url_helper
DEBUG - 2011-05-18 04:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 04:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 04:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 04:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 04:48:33 --> Final output sent to browser
DEBUG - 2011-05-18 04:48:33 --> Total execution time: 0.8562
DEBUG - 2011-05-18 04:48:34 --> Config Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:48:34 --> URI Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Router Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Output Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Input Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 04:48:34 --> Language Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Loader Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Controller Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Model Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Model Class Initialized
DEBUG - 2011-05-18 04:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 04:48:34 --> Database Driver Class Initialized
DEBUG - 2011-05-18 04:48:36 --> Final output sent to browser
DEBUG - 2011-05-18 04:48:36 --> Total execution time: 1.7192
DEBUG - 2011-05-18 04:48:37 --> Config Class Initialized
DEBUG - 2011-05-18 04:48:37 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:48:37 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:48:37 --> URI Class Initialized
DEBUG - 2011-05-18 04:48:37 --> Router Class Initialized
ERROR - 2011-05-18 04:48:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 04:48:39 --> Config Class Initialized
DEBUG - 2011-05-18 04:48:39 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:48:39 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:48:39 --> URI Class Initialized
DEBUG - 2011-05-18 04:48:39 --> Router Class Initialized
ERROR - 2011-05-18 04:48:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 04:49:00 --> Config Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:49:00 --> URI Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Router Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Output Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Input Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 04:49:00 --> Language Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Loader Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Controller Class Initialized
ERROR - 2011-05-18 04:49:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 04:49:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 04:49:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 04:49:00 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 04:49:00 --> Database Driver Class Initialized
DEBUG - 2011-05-18 04:49:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 04:49:00 --> Helper loaded: url_helper
DEBUG - 2011-05-18 04:49:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 04:49:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 04:49:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 04:49:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 04:49:00 --> Final output sent to browser
DEBUG - 2011-05-18 04:49:00 --> Total execution time: 0.0464
DEBUG - 2011-05-18 04:49:01 --> Config Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:49:01 --> URI Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Router Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Output Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Input Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 04:49:01 --> Language Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Loader Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Controller Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 04:49:01 --> Database Driver Class Initialized
DEBUG - 2011-05-18 04:49:02 --> Final output sent to browser
DEBUG - 2011-05-18 04:49:02 --> Total execution time: 1.5170
DEBUG - 2011-05-18 04:49:09 --> Config Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:49:09 --> URI Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Router Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Output Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Input Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 04:49:09 --> Language Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Loader Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Controller Class Initialized
ERROR - 2011-05-18 04:49:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 04:49:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 04:49:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 04:49:09 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 04:49:09 --> Database Driver Class Initialized
DEBUG - 2011-05-18 04:49:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 04:49:09 --> Helper loaded: url_helper
DEBUG - 2011-05-18 04:49:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 04:49:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 04:49:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 04:49:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 04:49:09 --> Final output sent to browser
DEBUG - 2011-05-18 04:49:09 --> Total execution time: 0.0376
DEBUG - 2011-05-18 04:49:10 --> Config Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Hooks Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Utf8 Class Initialized
DEBUG - 2011-05-18 04:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 04:49:10 --> URI Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Router Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Output Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Input Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 04:49:10 --> Language Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Loader Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Controller Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Model Class Initialized
DEBUG - 2011-05-18 04:49:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 04:49:10 --> Database Driver Class Initialized
DEBUG - 2011-05-18 04:49:11 --> Final output sent to browser
DEBUG - 2011-05-18 04:49:11 --> Total execution time: 0.8221
DEBUG - 2011-05-18 07:06:05 --> Config Class Initialized
DEBUG - 2011-05-18 07:06:05 --> Hooks Class Initialized
DEBUG - 2011-05-18 07:06:05 --> Utf8 Class Initialized
DEBUG - 2011-05-18 07:06:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 07:06:05 --> URI Class Initialized
DEBUG - 2011-05-18 07:06:05 --> Router Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Output Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Input Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 07:06:06 --> Language Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Loader Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Controller Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Model Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Model Class Initialized
DEBUG - 2011-05-18 07:06:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 07:06:07 --> Database Driver Class Initialized
DEBUG - 2011-05-18 07:06:10 --> Final output sent to browser
DEBUG - 2011-05-18 07:06:10 --> Total execution time: 5.1274
DEBUG - 2011-05-18 07:49:09 --> Config Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Hooks Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Utf8 Class Initialized
DEBUG - 2011-05-18 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 07:49:09 --> URI Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Router Class Initialized
ERROR - 2011-05-18 07:49:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-18 07:49:09 --> Config Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Hooks Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Utf8 Class Initialized
DEBUG - 2011-05-18 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 07:49:09 --> URI Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Router Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Output Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Input Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 07:49:09 --> Language Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Loader Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Controller Class Initialized
ERROR - 2011-05-18 07:49:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 07:49:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 07:49:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 07:49:09 --> Model Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Model Class Initialized
DEBUG - 2011-05-18 07:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 07:49:09 --> Database Driver Class Initialized
DEBUG - 2011-05-18 07:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 07:49:10 --> Helper loaded: url_helper
DEBUG - 2011-05-18 07:49:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 07:49:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 07:49:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 07:49:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 07:49:10 --> Final output sent to browser
DEBUG - 2011-05-18 07:49:10 --> Total execution time: 0.7207
DEBUG - 2011-05-18 09:27:29 --> Config Class Initialized
DEBUG - 2011-05-18 09:27:29 --> Hooks Class Initialized
DEBUG - 2011-05-18 09:27:29 --> Utf8 Class Initialized
DEBUG - 2011-05-18 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 09:27:29 --> URI Class Initialized
DEBUG - 2011-05-18 09:27:29 --> Router Class Initialized
ERROR - 2011-05-18 09:27:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-18 09:27:30 --> Config Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Hooks Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Utf8 Class Initialized
DEBUG - 2011-05-18 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 09:27:30 --> URI Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Router Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Output Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Input Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 09:27:30 --> Language Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Loader Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Controller Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Model Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Model Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Model Class Initialized
DEBUG - 2011-05-18 09:27:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 09:27:30 --> Database Driver Class Initialized
DEBUG - 2011-05-18 09:27:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 09:27:31 --> Helper loaded: url_helper
DEBUG - 2011-05-18 09:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 09:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 09:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 09:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 09:27:31 --> Final output sent to browser
DEBUG - 2011-05-18 09:27:31 --> Total execution time: 0.7717
DEBUG - 2011-05-18 11:19:28 --> Config Class Initialized
DEBUG - 2011-05-18 11:19:28 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:19:28 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:19:28 --> URI Class Initialized
DEBUG - 2011-05-18 11:19:28 --> Router Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Output Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Input Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:19:29 --> Language Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Loader Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Controller Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Model Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Model Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Model Class Initialized
DEBUG - 2011-05-18 11:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:19:29 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:19:29 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:19:29 --> Final output sent to browser
DEBUG - 2011-05-18 11:19:29 --> Total execution time: 0.8832
DEBUG - 2011-05-18 11:19:31 --> Config Class Initialized
DEBUG - 2011-05-18 11:19:31 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:19:31 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:19:31 --> URI Class Initialized
DEBUG - 2011-05-18 11:19:31 --> Router Class Initialized
ERROR - 2011-05-18 11:19:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 11:23:31 --> Config Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:23:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:23:31 --> URI Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Router Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Output Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Input Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:23:31 --> Language Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Loader Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Controller Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:23:31 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:23:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:23:32 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:23:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:23:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:23:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:23:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:23:32 --> Final output sent to browser
DEBUG - 2011-05-18 11:23:32 --> Total execution time: 0.3031
DEBUG - 2011-05-18 11:23:35 --> Config Class Initialized
DEBUG - 2011-05-18 11:23:35 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:23:35 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:23:35 --> URI Class Initialized
DEBUG - 2011-05-18 11:23:35 --> Router Class Initialized
ERROR - 2011-05-18 11:23:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 11:23:36 --> Config Class Initialized
DEBUG - 2011-05-18 11:23:36 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:23:36 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:23:36 --> URI Class Initialized
DEBUG - 2011-05-18 11:23:36 --> Router Class Initialized
ERROR - 2011-05-18 11:23:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 11:23:36 --> Config Class Initialized
DEBUG - 2011-05-18 11:23:36 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:23:36 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:23:36 --> URI Class Initialized
DEBUG - 2011-05-18 11:23:36 --> Router Class Initialized
ERROR - 2011-05-18 11:23:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 11:23:40 --> Config Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:23:40 --> URI Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Router Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Output Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Input Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:23:40 --> Language Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Loader Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Controller Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:23:40 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:23:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:23:40 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:23:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:23:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:23:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:23:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:23:40 --> Final output sent to browser
DEBUG - 2011-05-18 11:23:40 --> Total execution time: 0.2367
DEBUG - 2011-05-18 11:23:46 --> Config Class Initialized
DEBUG - 2011-05-18 11:23:46 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:23:46 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:23:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:23:46 --> URI Class Initialized
DEBUG - 2011-05-18 11:23:46 --> Router Class Initialized
DEBUG - 2011-05-18 11:23:46 --> Output Class Initialized
DEBUG - 2011-05-18 11:23:46 --> Input Class Initialized
DEBUG - 2011-05-18 11:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:23:46 --> Language Class Initialized
DEBUG - 2011-05-18 11:23:47 --> Loader Class Initialized
DEBUG - 2011-05-18 11:23:47 --> Controller Class Initialized
DEBUG - 2011-05-18 11:23:47 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:47 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:47 --> Model Class Initialized
DEBUG - 2011-05-18 11:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:23:47 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:23:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:23:51 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:23:51 --> Final output sent to browser
DEBUG - 2011-05-18 11:23:51 --> Total execution time: 4.9797
DEBUG - 2011-05-18 11:25:02 --> Config Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:25:02 --> URI Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Router Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Output Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Input Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:25:02 --> Language Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Loader Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Controller Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Model Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Model Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Model Class Initialized
DEBUG - 2011-05-18 11:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:25:02 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:25:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:25:03 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:25:03 --> Final output sent to browser
DEBUG - 2011-05-18 11:25:03 --> Total execution time: 0.4676
DEBUG - 2011-05-18 11:26:34 --> Config Class Initialized
DEBUG - 2011-05-18 11:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:26:34 --> URI Class Initialized
DEBUG - 2011-05-18 11:26:34 --> Router Class Initialized
ERROR - 2011-05-18 11:26:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-18 11:26:35 --> Config Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:26:35 --> URI Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Router Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Output Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Input Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:26:35 --> Language Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Loader Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Controller Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:26:35 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:26:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:26:35 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:26:35 --> Final output sent to browser
DEBUG - 2011-05-18 11:26:35 --> Total execution time: 0.0772
DEBUG - 2011-05-18 11:26:38 --> Config Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:26:38 --> URI Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Router Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Output Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Input Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:26:38 --> Language Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Loader Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Controller Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:26:38 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:26:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:26:38 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:26:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:26:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:26:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:26:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:26:38 --> Final output sent to browser
DEBUG - 2011-05-18 11:26:38 --> Total execution time: 0.0709
DEBUG - 2011-05-18 11:26:46 --> Config Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:26:46 --> URI Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Router Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Output Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Input Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:26:46 --> Language Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Loader Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Controller Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Model Class Initialized
DEBUG - 2011-05-18 11:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:26:46 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:26:46 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:26:46 --> Final output sent to browser
DEBUG - 2011-05-18 11:26:46 --> Total execution time: 0.0795
DEBUG - 2011-05-18 11:27:31 --> Config Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:27:31 --> URI Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Router Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Output Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Input Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:27:31 --> Language Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Loader Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Controller Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Model Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Model Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Model Class Initialized
DEBUG - 2011-05-18 11:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:27:31 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:27:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 11:27:31 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:27:31 --> Final output sent to browser
DEBUG - 2011-05-18 11:27:31 --> Total execution time: 0.0693
DEBUG - 2011-05-18 11:30:27 --> Config Class Initialized
DEBUG - 2011-05-18 11:30:27 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:30:27 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:30:27 --> URI Class Initialized
DEBUG - 2011-05-18 11:30:27 --> Router Class Initialized
ERROR - 2011-05-18 11:30:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-18 11:35:57 --> Config Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:35:57 --> URI Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Router Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Output Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Input Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:35:57 --> Language Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Loader Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Controller Class Initialized
ERROR - 2011-05-18 11:35:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 11:35:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 11:35:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 11:35:57 --> Model Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Model Class Initialized
DEBUG - 2011-05-18 11:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:35:57 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:35:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 11:35:58 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:35:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:35:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:35:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:35:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:35:58 --> Final output sent to browser
DEBUG - 2011-05-18 11:35:58 --> Total execution time: 0.3420
DEBUG - 2011-05-18 11:35:58 --> Config Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:35:58 --> URI Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Router Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Output Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Input Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:35:58 --> Language Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Loader Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Controller Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Model Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Model Class Initialized
DEBUG - 2011-05-18 11:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:35:59 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Config Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Hooks Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Utf8 Class Initialized
DEBUG - 2011-05-18 11:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 11:36:01 --> URI Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Router Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Output Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Input Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 11:36:01 --> Language Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Loader Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Controller Class Initialized
ERROR - 2011-05-18 11:36:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 11:36:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 11:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 11:36:01 --> Model Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Model Class Initialized
DEBUG - 2011-05-18 11:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 11:36:01 --> Database Driver Class Initialized
DEBUG - 2011-05-18 11:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 11:36:01 --> Helper loaded: url_helper
DEBUG - 2011-05-18 11:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 11:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 11:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 11:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 11:36:01 --> Final output sent to browser
DEBUG - 2011-05-18 11:36:01 --> Total execution time: 0.0286
DEBUG - 2011-05-18 11:36:05 --> Final output sent to browser
DEBUG - 2011-05-18 11:36:05 --> Total execution time: 6.1292
DEBUG - 2011-05-18 12:13:07 --> Config Class Initialized
DEBUG - 2011-05-18 12:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:13:08 --> URI Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Router Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Output Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Input Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 12:13:08 --> Language Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Loader Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Controller Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Model Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Model Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Model Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 12:13:08 --> Database Driver Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Config Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:13:08 --> URI Class Initialized
DEBUG - 2011-05-18 12:13:08 --> Router Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Output Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Input Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 12:13:09 --> Language Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Loader Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Controller Class Initialized
ERROR - 2011-05-18 12:13:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 12:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 12:13:09 --> Model Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Model Class Initialized
DEBUG - 2011-05-18 12:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 12:13:09 --> Database Driver Class Initialized
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 12:13:09 --> Helper loaded: url_helper
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 12:13:09 --> Helper loaded: url_helper
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 12:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 12:13:09 --> Final output sent to browser
DEBUG - 2011-05-18 12:13:09 --> Total execution time: 2.1259
DEBUG - 2011-05-18 12:13:09 --> Final output sent to browser
DEBUG - 2011-05-18 12:13:09 --> Total execution time: 0.4710
DEBUG - 2011-05-18 12:15:32 --> Config Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:15:32 --> URI Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Router Class Initialized
DEBUG - 2011-05-18 12:15:32 --> No URI present. Default controller set.
DEBUG - 2011-05-18 12:15:32 --> Output Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Input Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 12:15:32 --> Language Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Loader Class Initialized
DEBUG - 2011-05-18 12:15:32 --> Controller Class Initialized
DEBUG - 2011-05-18 12:15:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 12:15:32 --> Helper loaded: url_helper
DEBUG - 2011-05-18 12:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 12:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 12:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 12:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 12:15:32 --> Final output sent to browser
DEBUG - 2011-05-18 12:15:32 --> Total execution time: 0.1318
DEBUG - 2011-05-18 12:19:08 --> Config Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:19:08 --> URI Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Router Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Output Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Input Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 12:19:08 --> Language Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Loader Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Controller Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 12:19:08 --> Database Driver Class Initialized
DEBUG - 2011-05-18 12:19:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 12:19:08 --> Helper loaded: url_helper
DEBUG - 2011-05-18 12:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 12:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 12:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 12:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 12:19:08 --> Final output sent to browser
DEBUG - 2011-05-18 12:19:08 --> Total execution time: 0.2280
DEBUG - 2011-05-18 12:19:11 --> Config Class Initialized
DEBUG - 2011-05-18 12:19:11 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:19:11 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:19:11 --> URI Class Initialized
DEBUG - 2011-05-18 12:19:11 --> Router Class Initialized
ERROR - 2011-05-18 12:19:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 12:19:14 --> Config Class Initialized
DEBUG - 2011-05-18 12:19:14 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:19:14 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:19:14 --> URI Class Initialized
DEBUG - 2011-05-18 12:19:14 --> Router Class Initialized
ERROR - 2011-05-18 12:19:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 12:19:27 --> Config Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:19:27 --> URI Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Router Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Output Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Input Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 12:19:27 --> Language Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Loader Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Controller Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 12:19:27 --> Database Driver Class Initialized
DEBUG - 2011-05-18 12:19:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 12:19:28 --> Helper loaded: url_helper
DEBUG - 2011-05-18 12:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 12:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 12:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 12:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 12:19:28 --> Final output sent to browser
DEBUG - 2011-05-18 12:19:28 --> Total execution time: 0.3940
DEBUG - 2011-05-18 12:19:45 --> Config Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Hooks Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Utf8 Class Initialized
DEBUG - 2011-05-18 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 12:19:45 --> URI Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Router Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Output Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Input Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 12:19:45 --> Language Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Loader Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Controller Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Model Class Initialized
DEBUG - 2011-05-18 12:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 12:19:45 --> Database Driver Class Initialized
DEBUG - 2011-05-18 12:19:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 12:19:45 --> Helper loaded: url_helper
DEBUG - 2011-05-18 12:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 12:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 12:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 12:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 12:19:45 --> Final output sent to browser
DEBUG - 2011-05-18 12:19:45 --> Total execution time: 0.2950
DEBUG - 2011-05-18 13:40:01 --> Config Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:40:01 --> URI Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Router Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Output Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Input Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:40:01 --> Language Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Loader Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Controller Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:40:01 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:40:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 13:40:02 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:40:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:40:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:40:03 --> Final output sent to browser
DEBUG - 2011-05-18 13:40:03 --> Total execution time: 1.5322
DEBUG - 2011-05-18 13:40:13 --> Config Class Initialized
DEBUG - 2011-05-18 13:40:13 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:40:13 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:40:13 --> URI Class Initialized
DEBUG - 2011-05-18 13:40:13 --> Router Class Initialized
ERROR - 2011-05-18 13:40:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:40:38 --> Config Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:40:38 --> URI Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Router Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Output Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Input Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:40:38 --> Language Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Loader Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Controller Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:40:38 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:40:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 13:40:38 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:40:38 --> Final output sent to browser
DEBUG - 2011-05-18 13:40:38 --> Total execution time: 0.3112
DEBUG - 2011-05-18 13:40:44 --> Config Class Initialized
DEBUG - 2011-05-18 13:40:44 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:40:44 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:40:44 --> URI Class Initialized
DEBUG - 2011-05-18 13:40:44 --> Router Class Initialized
ERROR - 2011-05-18 13:40:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:40:50 --> Config Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:40:50 --> URI Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Router Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Output Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Input Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:40:50 --> Language Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Loader Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Controller Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Model Class Initialized
DEBUG - 2011-05-18 13:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:40:50 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:40:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 13:40:50 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:40:50 --> Final output sent to browser
DEBUG - 2011-05-18 13:40:50 --> Total execution time: 0.1407
DEBUG - 2011-05-18 13:44:39 --> Config Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:44:39 --> URI Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Router Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Output Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Input Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:44:39 --> Language Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Loader Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Controller Class Initialized
ERROR - 2011-05-18 13:44:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 13:44:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 13:44:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:44:39 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:44:39 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:44:40 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:44:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:44:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:44:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:44:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:44:40 --> Final output sent to browser
DEBUG - 2011-05-18 13:44:40 --> Total execution time: 0.1304
DEBUG - 2011-05-18 13:44:43 --> Config Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:44:43 --> URI Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Router Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Output Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Input Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:44:43 --> Language Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Loader Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Controller Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:44:43 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:44:44 --> Final output sent to browser
DEBUG - 2011-05-18 13:44:44 --> Total execution time: 0.8483
DEBUG - 2011-05-18 13:44:52 --> Config Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:44:52 --> URI Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Router Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Output Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Input Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:44:52 --> Language Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Loader Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Controller Class Initialized
ERROR - 2011-05-18 13:44:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 13:44:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 13:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:44:52 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:44:52 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:44:52 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:44:52 --> Final output sent to browser
DEBUG - 2011-05-18 13:44:52 --> Total execution time: 0.1093
DEBUG - 2011-05-18 13:44:52 --> Config Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:44:52 --> URI Class Initialized
DEBUG - 2011-05-18 13:44:52 --> Router Class Initialized
ERROR - 2011-05-18 13:44:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:44:54 --> Config Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:44:54 --> URI Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Router Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Output Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Input Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:44:54 --> Language Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Loader Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Controller Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:44:54 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Final output sent to browser
DEBUG - 2011-05-18 13:44:55 --> Total execution time: 0.7297
DEBUG - 2011-05-18 13:44:55 --> Config Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:44:55 --> URI Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Router Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Output Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Input Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:44:55 --> Language Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Loader Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Controller Class Initialized
ERROR - 2011-05-18 13:44:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 13:44:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 13:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:44:55 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Model Class Initialized
DEBUG - 2011-05-18 13:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:44:55 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:44:55 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:44:55 --> Final output sent to browser
DEBUG - 2011-05-18 13:44:55 --> Total execution time: 0.0557
DEBUG - 2011-05-18 13:45:06 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:06 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:06 --> No URI present. Default controller set.
DEBUG - 2011-05-18 13:45:06 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:06 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:06 --> Controller Class Initialized
DEBUG - 2011-05-18 13:45:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 13:45:07 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:45:07 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:07 --> Total execution time: 0.4215
DEBUG - 2011-05-18 13:45:08 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:08 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:08 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:08 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:08 --> Router Class Initialized
ERROR - 2011-05-18 13:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:45:10 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:10 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:10 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:10 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:10 --> Router Class Initialized
ERROR - 2011-05-18 13:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:45:12 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:12 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:12 --> No URI present. Default controller set.
DEBUG - 2011-05-18 13:45:12 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:12 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:12 --> Controller Class Initialized
DEBUG - 2011-05-18 13:45:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 13:45:12 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:45:12 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:12 --> Total execution time: 0.1340
DEBUG - 2011-05-18 13:45:17 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:17 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:17 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Controller Class Initialized
ERROR - 2011-05-18 13:45:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 13:45:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 13:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:45:17 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:45:17 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:45:17 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:45:17 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:17 --> Total execution time: 0.1296
DEBUG - 2011-05-18 13:45:19 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:19 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:19 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Controller Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:45:19 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:45:19 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:19 --> Total execution time: 0.5850
DEBUG - 2011-05-18 13:45:22 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:22 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:22 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:22 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:22 --> Router Class Initialized
ERROR - 2011-05-18 13:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:45:26 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:26 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:26 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Controller Class Initialized
ERROR - 2011-05-18 13:45:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 13:45:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 13:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:45:26 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:45:26 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:45:26 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:45:26 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:26 --> Total execution time: 0.0390
DEBUG - 2011-05-18 13:45:28 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:28 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:28 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:28 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:28 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:28 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:29 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Controller Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:45:29 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:45:29 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:29 --> Total execution time: 0.9586
DEBUG - 2011-05-18 13:45:31 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:31 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:31 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Controller Class Initialized
ERROR - 2011-05-18 13:45:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 13:45:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 13:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:45:31 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:45:31 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 13:45:31 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:45:31 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:31 --> Total execution time: 0.3047
DEBUG - 2011-05-18 13:45:34 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:34 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:34 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:34 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:34 --> Router Class Initialized
ERROR - 2011-05-18 13:45:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:45:43 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:43 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:43 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:43 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:43 --> Router Class Initialized
ERROR - 2011-05-18 13:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 13:45:45 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:45 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Router Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Output Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Input Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 13:45:45 --> Language Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Loader Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Controller Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Model Class Initialized
DEBUG - 2011-05-18 13:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 13:45:45 --> Database Driver Class Initialized
DEBUG - 2011-05-18 13:45:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 13:45:45 --> Helper loaded: url_helper
DEBUG - 2011-05-18 13:45:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 13:45:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 13:45:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 13:45:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 13:45:45 --> Final output sent to browser
DEBUG - 2011-05-18 13:45:45 --> Total execution time: 0.0565
DEBUG - 2011-05-18 13:45:47 --> Config Class Initialized
DEBUG - 2011-05-18 13:45:47 --> Hooks Class Initialized
DEBUG - 2011-05-18 13:45:47 --> Utf8 Class Initialized
DEBUG - 2011-05-18 13:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 13:45:47 --> URI Class Initialized
DEBUG - 2011-05-18 13:45:47 --> Router Class Initialized
ERROR - 2011-05-18 13:45:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 14:08:53 --> Config Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Hooks Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Utf8 Class Initialized
DEBUG - 2011-05-18 14:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 14:08:53 --> URI Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Router Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Output Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Input Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 14:08:53 --> Language Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Loader Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Controller Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Model Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Model Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Model Class Initialized
DEBUG - 2011-05-18 14:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 14:08:53 --> Database Driver Class Initialized
DEBUG - 2011-05-18 14:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 14:08:53 --> Helper loaded: url_helper
DEBUG - 2011-05-18 14:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 14:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 14:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 14:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 14:08:53 --> Final output sent to browser
DEBUG - 2011-05-18 14:08:53 --> Total execution time: 0.4320
DEBUG - 2011-05-18 14:09:24 --> Config Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Hooks Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Utf8 Class Initialized
DEBUG - 2011-05-18 14:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 14:09:24 --> URI Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Router Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Output Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Input Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 14:09:24 --> Language Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Loader Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Controller Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Model Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Model Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Model Class Initialized
DEBUG - 2011-05-18 14:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 14:09:24 --> Database Driver Class Initialized
DEBUG - 2011-05-18 14:09:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 14:09:24 --> Helper loaded: url_helper
DEBUG - 2011-05-18 14:09:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 14:09:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 14:09:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 14:09:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 14:09:24 --> Final output sent to browser
DEBUG - 2011-05-18 14:09:24 --> Total execution time: 0.0476
DEBUG - 2011-05-18 14:09:25 --> Config Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Hooks Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Utf8 Class Initialized
DEBUG - 2011-05-18 14:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 14:09:25 --> URI Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Router Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Output Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Input Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 14:09:25 --> Language Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Loader Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Controller Class Initialized
ERROR - 2011-05-18 14:09:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 14:09:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 14:09:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 14:09:25 --> Model Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Model Class Initialized
DEBUG - 2011-05-18 14:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 14:09:25 --> Database Driver Class Initialized
DEBUG - 2011-05-18 14:09:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 14:09:25 --> Helper loaded: url_helper
DEBUG - 2011-05-18 14:09:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 14:09:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 14:09:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 14:09:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 14:09:25 --> Final output sent to browser
DEBUG - 2011-05-18 14:09:25 --> Total execution time: 0.1137
DEBUG - 2011-05-18 14:46:54 --> Config Class Initialized
DEBUG - 2011-05-18 14:46:54 --> Hooks Class Initialized
DEBUG - 2011-05-18 14:46:54 --> Utf8 Class Initialized
DEBUG - 2011-05-18 14:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 14:46:54 --> URI Class Initialized
DEBUG - 2011-05-18 14:46:55 --> Router Class Initialized
DEBUG - 2011-05-18 14:46:55 --> Output Class Initialized
DEBUG - 2011-05-18 14:46:55 --> Input Class Initialized
DEBUG - 2011-05-18 14:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 14:46:55 --> Language Class Initialized
DEBUG - 2011-05-18 14:46:55 --> Loader Class Initialized
DEBUG - 2011-05-18 14:46:55 --> Controller Class Initialized
DEBUG - 2011-05-18 14:46:56 --> Model Class Initialized
DEBUG - 2011-05-18 14:46:56 --> Model Class Initialized
DEBUG - 2011-05-18 14:46:57 --> Model Class Initialized
DEBUG - 2011-05-18 14:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 14:46:59 --> Database Driver Class Initialized
DEBUG - 2011-05-18 14:47:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 14:47:01 --> Helper loaded: url_helper
DEBUG - 2011-05-18 14:47:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 14:47:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 14:47:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 14:47:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 14:47:01 --> Final output sent to browser
DEBUG - 2011-05-18 14:47:01 --> Total execution time: 7.5935
DEBUG - 2011-05-18 14:47:02 --> Config Class Initialized
DEBUG - 2011-05-18 14:47:02 --> Hooks Class Initialized
DEBUG - 2011-05-18 14:47:02 --> Utf8 Class Initialized
DEBUG - 2011-05-18 14:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 14:47:02 --> URI Class Initialized
DEBUG - 2011-05-18 14:47:02 --> Router Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Output Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Input Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 14:47:03 --> Language Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Loader Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Controller Class Initialized
ERROR - 2011-05-18 14:47:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 14:47:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 14:47:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 14:47:03 --> Model Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Model Class Initialized
DEBUG - 2011-05-18 14:47:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 14:47:03 --> Database Driver Class Initialized
DEBUG - 2011-05-18 14:47:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 14:47:03 --> Helper loaded: url_helper
DEBUG - 2011-05-18 14:47:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 14:47:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 14:47:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 14:47:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 14:47:03 --> Final output sent to browser
DEBUG - 2011-05-18 14:47:03 --> Total execution time: 0.9014
DEBUG - 2011-05-18 16:03:20 --> Config Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:03:20 --> URI Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Router Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Output Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Input Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 16:03:20 --> Language Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Loader Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Controller Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Model Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Model Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Model Class Initialized
DEBUG - 2011-05-18 16:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 16:03:20 --> Database Driver Class Initialized
DEBUG - 2011-05-18 16:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 16:03:21 --> Helper loaded: url_helper
DEBUG - 2011-05-18 16:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 16:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 16:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 16:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 16:03:21 --> Final output sent to browser
DEBUG - 2011-05-18 16:03:21 --> Total execution time: 0.9125
DEBUG - 2011-05-18 16:03:23 --> Config Class Initialized
DEBUG - 2011-05-18 16:03:23 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:03:23 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:03:23 --> URI Class Initialized
DEBUG - 2011-05-18 16:03:23 --> Router Class Initialized
ERROR - 2011-05-18 16:03:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 16:03:25 --> Config Class Initialized
DEBUG - 2011-05-18 16:03:25 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:03:25 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:03:25 --> URI Class Initialized
DEBUG - 2011-05-18 16:03:25 --> Router Class Initialized
ERROR - 2011-05-18 16:03:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 16:24:04 --> Config Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:24:04 --> URI Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Router Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Output Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Input Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 16:24:04 --> Language Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Loader Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Controller Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 16:24:04 --> Database Driver Class Initialized
DEBUG - 2011-05-18 16:24:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 16:24:05 --> Helper loaded: url_helper
DEBUG - 2011-05-18 16:24:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 16:24:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 16:24:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 16:24:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 16:24:05 --> Final output sent to browser
DEBUG - 2011-05-18 16:24:05 --> Total execution time: 0.3825
DEBUG - 2011-05-18 16:24:06 --> Config Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:24:06 --> URI Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Router Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Output Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Input Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 16:24:06 --> Language Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Loader Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Controller Class Initialized
ERROR - 2011-05-18 16:24:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 16:24:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 16:24:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 16:24:06 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 16:24:06 --> Database Driver Class Initialized
DEBUG - 2011-05-18 16:24:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 16:24:06 --> Helper loaded: url_helper
DEBUG - 2011-05-18 16:24:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 16:24:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 16:24:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 16:24:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 16:24:06 --> Final output sent to browser
DEBUG - 2011-05-18 16:24:06 --> Total execution time: 0.0928
DEBUG - 2011-05-18 16:24:53 --> Config Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:24:53 --> URI Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Router Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Output Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Input Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 16:24:53 --> Language Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Loader Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Controller Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 16:24:53 --> Database Driver Class Initialized
DEBUG - 2011-05-18 16:24:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 16:24:53 --> Helper loaded: url_helper
DEBUG - 2011-05-18 16:24:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 16:24:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 16:24:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 16:24:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 16:24:53 --> Final output sent to browser
DEBUG - 2011-05-18 16:24:53 --> Total execution time: 0.0650
DEBUG - 2011-05-18 16:24:55 --> Config Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:24:55 --> URI Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Router Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Output Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Input Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 16:24:55 --> Language Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Loader Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Controller Class Initialized
ERROR - 2011-05-18 16:24:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 16:24:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 16:24:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 16:24:55 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Model Class Initialized
DEBUG - 2011-05-18 16:24:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 16:24:55 --> Database Driver Class Initialized
DEBUG - 2011-05-18 16:24:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 16:24:55 --> Helper loaded: url_helper
DEBUG - 2011-05-18 16:24:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 16:24:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 16:24:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 16:24:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 16:24:55 --> Final output sent to browser
DEBUG - 2011-05-18 16:24:55 --> Total execution time: 0.0654
DEBUG - 2011-05-18 16:29:36 --> Config Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Hooks Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Utf8 Class Initialized
DEBUG - 2011-05-18 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 16:29:36 --> URI Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Router Class Initialized
DEBUG - 2011-05-18 16:29:36 --> No URI present. Default controller set.
DEBUG - 2011-05-18 16:29:36 --> Output Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Input Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 16:29:36 --> Language Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Loader Class Initialized
DEBUG - 2011-05-18 16:29:36 --> Controller Class Initialized
DEBUG - 2011-05-18 16:29:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 16:29:36 --> Helper loaded: url_helper
DEBUG - 2011-05-18 16:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 16:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 16:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 16:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 16:29:36 --> Final output sent to browser
DEBUG - 2011-05-18 16:29:36 --> Total execution time: 0.0670
DEBUG - 2011-05-18 17:54:41 --> Config Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Hooks Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Utf8 Class Initialized
DEBUG - 2011-05-18 17:54:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 17:54:41 --> URI Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Router Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Output Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Input Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 17:54:41 --> Language Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Loader Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Controller Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Model Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Model Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Model Class Initialized
DEBUG - 2011-05-18 17:54:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 17:54:41 --> Database Driver Class Initialized
DEBUG - 2011-05-18 17:54:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-18 17:54:42 --> Helper loaded: url_helper
DEBUG - 2011-05-18 17:54:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 17:54:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 17:54:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 17:54:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 17:54:42 --> Final output sent to browser
DEBUG - 2011-05-18 17:54:42 --> Total execution time: 1.1027
DEBUG - 2011-05-18 17:54:43 --> Config Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Hooks Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Utf8 Class Initialized
DEBUG - 2011-05-18 17:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 17:54:43 --> URI Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Router Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Output Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Input Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 17:54:43 --> Language Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Loader Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Controller Class Initialized
ERROR - 2011-05-18 17:54:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 17:54:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 17:54:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 17:54:43 --> Model Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Model Class Initialized
DEBUG - 2011-05-18 17:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 17:54:43 --> Database Driver Class Initialized
DEBUG - 2011-05-18 17:54:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 17:54:43 --> Helper loaded: url_helper
DEBUG - 2011-05-18 17:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 17:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 17:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 17:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 17:54:43 --> Final output sent to browser
DEBUG - 2011-05-18 17:54:43 --> Total execution time: 0.1047
DEBUG - 2011-05-18 18:33:16 --> Config Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Hooks Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Utf8 Class Initialized
DEBUG - 2011-05-18 18:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 18:33:16 --> URI Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Router Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Output Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Input Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 18:33:16 --> Language Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Loader Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Controller Class Initialized
ERROR - 2011-05-18 18:33:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-18 18:33:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-18 18:33:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 18:33:16 --> Model Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Model Class Initialized
DEBUG - 2011-05-18 18:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-18 18:33:16 --> Database Driver Class Initialized
DEBUG - 2011-05-18 18:33:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-18 18:33:16 --> Helper loaded: url_helper
DEBUG - 2011-05-18 18:33:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 18:33:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 18:33:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 18:33:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 18:33:16 --> Final output sent to browser
DEBUG - 2011-05-18 18:33:16 --> Total execution time: 0.3403
DEBUG - 2011-05-18 22:17:18 --> Config Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Hooks Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Utf8 Class Initialized
DEBUG - 2011-05-18 22:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 22:17:18 --> URI Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Router Class Initialized
DEBUG - 2011-05-18 22:17:18 --> No URI present. Default controller set.
DEBUG - 2011-05-18 22:17:18 --> Output Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Input Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 22:17:18 --> Language Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Loader Class Initialized
DEBUG - 2011-05-18 22:17:18 --> Controller Class Initialized
DEBUG - 2011-05-18 22:17:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 22:17:18 --> Helper loaded: url_helper
DEBUG - 2011-05-18 22:17:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 22:17:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 22:17:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 22:17:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 22:17:18 --> Final output sent to browser
DEBUG - 2011-05-18 22:17:18 --> Total execution time: 0.2574
DEBUG - 2011-05-18 23:37:38 --> Config Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Hooks Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Utf8 Class Initialized
DEBUG - 2011-05-18 23:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 23:37:38 --> URI Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Router Class Initialized
DEBUG - 2011-05-18 23:37:38 --> No URI present. Default controller set.
DEBUG - 2011-05-18 23:37:38 --> Output Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Input Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 23:37:38 --> Language Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Loader Class Initialized
DEBUG - 2011-05-18 23:37:38 --> Controller Class Initialized
DEBUG - 2011-05-18 23:37:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 23:37:38 --> Helper loaded: url_helper
DEBUG - 2011-05-18 23:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 23:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 23:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 23:37:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 23:37:38 --> Final output sent to browser
DEBUG - 2011-05-18 23:37:38 --> Total execution time: 0.2987
DEBUG - 2011-05-18 23:37:40 --> Config Class Initialized
DEBUG - 2011-05-18 23:37:40 --> Hooks Class Initialized
DEBUG - 2011-05-18 23:37:40 --> Utf8 Class Initialized
DEBUG - 2011-05-18 23:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 23:37:40 --> URI Class Initialized
DEBUG - 2011-05-18 23:37:40 --> Router Class Initialized
ERROR - 2011-05-18 23:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 23:37:41 --> Config Class Initialized
DEBUG - 2011-05-18 23:37:41 --> Hooks Class Initialized
DEBUG - 2011-05-18 23:37:41 --> Utf8 Class Initialized
DEBUG - 2011-05-18 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 23:37:41 --> URI Class Initialized
DEBUG - 2011-05-18 23:37:41 --> Router Class Initialized
ERROR - 2011-05-18 23:37:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-18 23:37:42 --> Config Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Hooks Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Utf8 Class Initialized
DEBUG - 2011-05-18 23:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 23:37:42 --> URI Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Router Class Initialized
ERROR - 2011-05-18 23:37:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-18 23:37:42 --> Config Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Hooks Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Utf8 Class Initialized
DEBUG - 2011-05-18 23:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-18 23:37:42 --> URI Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Router Class Initialized
DEBUG - 2011-05-18 23:37:42 --> No URI present. Default controller set.
DEBUG - 2011-05-18 23:37:42 --> Output Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Input Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-18 23:37:42 --> Language Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Loader Class Initialized
DEBUG - 2011-05-18 23:37:42 --> Controller Class Initialized
DEBUG - 2011-05-18 23:37:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-18 23:37:42 --> Helper loaded: url_helper
DEBUG - 2011-05-18 23:37:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-18 23:37:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-18 23:37:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-18 23:37:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-18 23:37:42 --> Final output sent to browser
DEBUG - 2011-05-18 23:37:42 --> Total execution time: 0.0133

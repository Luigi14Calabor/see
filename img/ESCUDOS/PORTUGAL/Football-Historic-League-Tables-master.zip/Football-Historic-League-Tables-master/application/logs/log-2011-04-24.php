<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-24 00:12:42 --> Config Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:12:42 --> URI Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Router Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Output Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Input Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:12:42 --> Language Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Loader Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Controller Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Model Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Model Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Model Class Initialized
DEBUG - 2011-04-24 00:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:12:42 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:12:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 00:12:42 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:12:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:12:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:12:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:12:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:12:42 --> Final output sent to browser
DEBUG - 2011-04-24 00:12:42 --> Total execution time: 0.4085
DEBUG - 2011-04-24 00:12:44 --> Config Class Initialized
DEBUG - 2011-04-24 00:12:44 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:12:44 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:12:44 --> URI Class Initialized
DEBUG - 2011-04-24 00:12:44 --> Router Class Initialized
ERROR - 2011-04-24 00:12:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 00:12:44 --> Config Class Initialized
DEBUG - 2011-04-24 00:12:44 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:12:44 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:12:44 --> URI Class Initialized
DEBUG - 2011-04-24 00:12:44 --> Router Class Initialized
ERROR - 2011-04-24 00:12:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 00:12:45 --> Config Class Initialized
DEBUG - 2011-04-24 00:12:45 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:12:45 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:12:45 --> URI Class Initialized
DEBUG - 2011-04-24 00:12:45 --> Router Class Initialized
ERROR - 2011-04-24 00:12:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 00:12:52 --> Config Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:12:52 --> URI Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Router Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Output Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Input Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:12:52 --> Language Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Loader Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Controller Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Model Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Model Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Model Class Initialized
DEBUG - 2011-04-24 00:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:12:52 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:12:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 00:12:52 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:12:52 --> Final output sent to browser
DEBUG - 2011-04-24 00:12:52 --> Total execution time: 0.2823
DEBUG - 2011-04-24 00:13:00 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:00 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:00 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Controller Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:00 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 00:13:00 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:13:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:13:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:13:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:13:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:13:00 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:00 --> Total execution time: 0.0466
DEBUG - 2011-04-24 00:13:08 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:08 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:08 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Controller Class Initialized
ERROR - 2011-04-24 00:13:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 00:13:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 00:13:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:13:08 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:08 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:13:08 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:13:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:13:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:13:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:13:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:13:08 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:08 --> Total execution time: 0.0519
DEBUG - 2011-04-24 00:13:09 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:09 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:09 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Controller Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:09 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:09 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:09 --> Total execution time: 0.5775
DEBUG - 2011-04-24 00:13:16 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:16 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:16 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Controller Class Initialized
ERROR - 2011-04-24 00:13:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 00:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 00:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:13:16 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:13:16 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:13:16 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:16 --> Total execution time: 0.0308
DEBUG - 2011-04-24 00:13:17 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:17 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:17 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Controller Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:17 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:17 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:17 --> Total execution time: 0.5158
DEBUG - 2011-04-24 00:13:54 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:54 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:54 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Controller Class Initialized
ERROR - 2011-04-24 00:13:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 00:13:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 00:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:13:54 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:54 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:13:54 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:13:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:13:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:13:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:13:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:13:54 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:54 --> Total execution time: 0.0292
DEBUG - 2011-04-24 00:13:54 --> Config Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:13:54 --> URI Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Router Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Output Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Input Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:13:54 --> Language Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Loader Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Controller Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Model Class Initialized
DEBUG - 2011-04-24 00:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:13:54 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:13:55 --> Final output sent to browser
DEBUG - 2011-04-24 00:13:55 --> Total execution time: 0.4928
DEBUG - 2011-04-24 00:22:37 --> Config Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:22:37 --> URI Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Router Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Output Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Input Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:22:37 --> Language Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Loader Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Controller Class Initialized
ERROR - 2011-04-24 00:22:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 00:22:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 00:22:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:22:37 --> Model Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Model Class Initialized
DEBUG - 2011-04-24 00:22:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:22:37 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:22:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:22:37 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:22:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:22:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:22:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:22:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:22:37 --> Final output sent to browser
DEBUG - 2011-04-24 00:22:37 --> Total execution time: 0.0506
DEBUG - 2011-04-24 00:22:38 --> Config Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:22:38 --> URI Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Router Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Output Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Input Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:22:38 --> Language Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Loader Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Controller Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Model Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Model Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:22:38 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:22:38 --> Final output sent to browser
DEBUG - 2011-04-24 00:22:38 --> Total execution time: 0.7060
DEBUG - 2011-04-24 00:22:40 --> Config Class Initialized
DEBUG - 2011-04-24 00:22:40 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:22:40 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:22:40 --> URI Class Initialized
DEBUG - 2011-04-24 00:22:40 --> Router Class Initialized
ERROR - 2011-04-24 00:22:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 00:22:41 --> Config Class Initialized
DEBUG - 2011-04-24 00:22:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:22:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:22:41 --> URI Class Initialized
DEBUG - 2011-04-24 00:22:41 --> Router Class Initialized
ERROR - 2011-04-24 00:22:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 00:22:41 --> Config Class Initialized
DEBUG - 2011-04-24 00:22:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:22:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:22:41 --> URI Class Initialized
DEBUG - 2011-04-24 00:22:41 --> Router Class Initialized
ERROR - 2011-04-24 00:22:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 00:22:51 --> Config Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 00:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 00:22:51 --> URI Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Router Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Output Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Input Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 00:22:51 --> Language Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Loader Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Controller Class Initialized
ERROR - 2011-04-24 00:22:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 00:22:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 00:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:22:51 --> Model Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Model Class Initialized
DEBUG - 2011-04-24 00:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 00:22:51 --> Database Driver Class Initialized
DEBUG - 2011-04-24 00:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 00:22:51 --> Helper loaded: url_helper
DEBUG - 2011-04-24 00:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 00:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 00:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 00:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 00:22:51 --> Final output sent to browser
DEBUG - 2011-04-24 00:22:51 --> Total execution time: 0.0422
DEBUG - 2011-04-24 02:14:23 --> Config Class Initialized
DEBUG - 2011-04-24 02:14:23 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:14:23 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:14:23 --> URI Class Initialized
DEBUG - 2011-04-24 02:14:23 --> Router Class Initialized
DEBUG - 2011-04-24 02:14:23 --> Output Class Initialized
DEBUG - 2011-04-24 02:14:23 --> Input Class Initialized
DEBUG - 2011-04-24 02:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 02:14:24 --> Language Class Initialized
DEBUG - 2011-04-24 02:14:24 --> Loader Class Initialized
DEBUG - 2011-04-24 02:14:24 --> Controller Class Initialized
DEBUG - 2011-04-24 02:14:24 --> Model Class Initialized
DEBUG - 2011-04-24 02:14:24 --> Model Class Initialized
DEBUG - 2011-04-24 02:14:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 02:14:24 --> Database Driver Class Initialized
DEBUG - 2011-04-24 02:14:25 --> Final output sent to browser
DEBUG - 2011-04-24 02:14:25 --> Total execution time: 1.8206
DEBUG - 2011-04-24 02:24:21 --> Config Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:24:21 --> URI Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Router Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Output Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Input Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 02:24:21 --> Language Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Loader Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Controller Class Initialized
DEBUG - 2011-04-24 02:24:21 --> Model Class Initialized
DEBUG - 2011-04-24 02:24:22 --> Model Class Initialized
DEBUG - 2011-04-24 02:24:22 --> Model Class Initialized
DEBUG - 2011-04-24 02:24:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 02:24:22 --> Database Driver Class Initialized
DEBUG - 2011-04-24 02:24:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 02:24:23 --> Helper loaded: url_helper
DEBUG - 2011-04-24 02:24:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 02:24:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 02:24:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 02:24:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 02:24:23 --> Final output sent to browser
DEBUG - 2011-04-24 02:24:23 --> Total execution time: 1.4680
DEBUG - 2011-04-24 02:24:29 --> Config Class Initialized
DEBUG - 2011-04-24 02:24:29 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:24:29 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:24:29 --> URI Class Initialized
DEBUG - 2011-04-24 02:24:29 --> Router Class Initialized
ERROR - 2011-04-24 02:24:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 02:24:30 --> Config Class Initialized
DEBUG - 2011-04-24 02:24:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:24:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:24:30 --> URI Class Initialized
DEBUG - 2011-04-24 02:24:30 --> Router Class Initialized
ERROR - 2011-04-24 02:24:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 02:24:58 --> Config Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:24:58 --> URI Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Router Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Output Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Input Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 02:24:58 --> Language Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Loader Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Controller Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Model Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Model Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Model Class Initialized
DEBUG - 2011-04-24 02:24:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 02:24:58 --> Database Driver Class Initialized
DEBUG - 2011-04-24 02:25:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 02:25:12 --> Helper loaded: url_helper
DEBUG - 2011-04-24 02:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 02:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 02:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 02:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 02:25:12 --> Final output sent to browser
DEBUG - 2011-04-24 02:25:12 --> Total execution time: 13.9933
DEBUG - 2011-04-24 02:25:30 --> Config Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:25:30 --> URI Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Router Class Initialized
ERROR - 2011-04-24 02:25:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 02:25:30 --> Config Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:25:30 --> URI Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Router Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Output Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Input Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 02:25:30 --> Language Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Loader Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Controller Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Model Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Model Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Model Class Initialized
DEBUG - 2011-04-24 02:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 02:25:30 --> Database Driver Class Initialized
DEBUG - 2011-04-24 02:25:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 02:25:30 --> Helper loaded: url_helper
DEBUG - 2011-04-24 02:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 02:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 02:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 02:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 02:25:30 --> Final output sent to browser
DEBUG - 2011-04-24 02:25:30 --> Total execution time: 0.0440
DEBUG - 2011-04-24 02:50:22 --> Config Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Hooks Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Utf8 Class Initialized
DEBUG - 2011-04-24 02:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 02:50:22 --> URI Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Router Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Output Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Input Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 02:50:22 --> Language Class Initialized
DEBUG - 2011-04-24 02:50:22 --> Loader Class Initialized
DEBUG - 2011-04-24 02:50:23 --> Controller Class Initialized
DEBUG - 2011-04-24 02:50:23 --> Model Class Initialized
DEBUG - 2011-04-24 02:50:24 --> Model Class Initialized
DEBUG - 2011-04-24 02:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 02:50:24 --> Database Driver Class Initialized
DEBUG - 2011-04-24 02:50:27 --> Final output sent to browser
DEBUG - 2011-04-24 02:50:27 --> Total execution time: 6.3049
DEBUG - 2011-04-24 03:22:20 --> Config Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 03:22:20 --> URI Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Router Class Initialized
DEBUG - 2011-04-24 03:22:20 --> No URI present. Default controller set.
DEBUG - 2011-04-24 03:22:20 --> Output Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Input Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 03:22:20 --> Language Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Loader Class Initialized
DEBUG - 2011-04-24 03:22:20 --> Controller Class Initialized
DEBUG - 2011-04-24 03:22:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 03:22:20 --> Helper loaded: url_helper
DEBUG - 2011-04-24 03:22:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 03:22:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 03:22:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 03:22:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 03:22:20 --> Final output sent to browser
DEBUG - 2011-04-24 03:22:20 --> Total execution time: 0.2156
DEBUG - 2011-04-24 04:08:55 --> Config Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 04:08:55 --> URI Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Router Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Output Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Input Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 04:08:55 --> Language Class Initialized
DEBUG - 2011-04-24 04:08:55 --> Loader Class Initialized
DEBUG - 2011-04-24 04:08:56 --> Controller Class Initialized
DEBUG - 2011-04-24 04:08:56 --> Model Class Initialized
DEBUG - 2011-04-24 04:08:56 --> Model Class Initialized
DEBUG - 2011-04-24 04:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 04:08:56 --> Database Driver Class Initialized
DEBUG - 2011-04-24 04:08:57 --> Final output sent to browser
DEBUG - 2011-04-24 04:08:57 --> Total execution time: 1.6008
DEBUG - 2011-04-24 04:52:46 --> Config Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 04:52:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 04:52:46 --> URI Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Router Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Output Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Input Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 04:52:46 --> Language Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Loader Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Controller Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Model Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Model Class Initialized
DEBUG - 2011-04-24 04:52:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 04:52:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 04:52:48 --> Final output sent to browser
DEBUG - 2011-04-24 04:52:48 --> Total execution time: 1.3190
DEBUG - 2011-04-24 06:05:16 --> Config Class Initialized
DEBUG - 2011-04-24 06:05:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:05:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:05:16 --> URI Class Initialized
DEBUG - 2011-04-24 06:05:17 --> Router Class Initialized
DEBUG - 2011-04-24 06:05:17 --> Output Class Initialized
DEBUG - 2011-04-24 06:05:17 --> Input Class Initialized
DEBUG - 2011-04-24 06:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:05:17 --> Language Class Initialized
DEBUG - 2011-04-24 06:05:18 --> Loader Class Initialized
DEBUG - 2011-04-24 06:05:18 --> Controller Class Initialized
DEBUG - 2011-04-24 06:05:19 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:19 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:20 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:05:23 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Config Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:05:24 --> URI Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Router Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Output Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Input Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:05:24 --> Language Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Loader Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Controller Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:05:24 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:05:27 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:05:27 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:05:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:05:27 --> Final output sent to browser
DEBUG - 2011-04-24 06:05:27 --> Total execution time: 2.6209
DEBUG - 2011-04-24 06:05:27 --> Final output sent to browser
DEBUG - 2011-04-24 06:05:27 --> Total execution time: 10.8917
DEBUG - 2011-04-24 06:05:29 --> Config Class Initialized
DEBUG - 2011-04-24 06:05:29 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:05:29 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:05:29 --> URI Class Initialized
DEBUG - 2011-04-24 06:05:29 --> Router Class Initialized
ERROR - 2011-04-24 06:05:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 06:05:30 --> Config Class Initialized
DEBUG - 2011-04-24 06:05:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:05:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:05:30 --> URI Class Initialized
DEBUG - 2011-04-24 06:05:30 --> Router Class Initialized
ERROR - 2011-04-24 06:05:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 06:05:31 --> Config Class Initialized
DEBUG - 2011-04-24 06:05:31 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:05:31 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:05:31 --> URI Class Initialized
DEBUG - 2011-04-24 06:05:31 --> Router Class Initialized
ERROR - 2011-04-24 06:05:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 06:05:54 --> Config Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:05:54 --> URI Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Router Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Output Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Input Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:05:54 --> Language Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Loader Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Controller Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Model Class Initialized
DEBUG - 2011-04-24 06:05:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:05:54 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:05:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:05:55 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:05:55 --> Final output sent to browser
DEBUG - 2011-04-24 06:05:55 --> Total execution time: 1.0823
DEBUG - 2011-04-24 06:06:03 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:03 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:03 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:03 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:03 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:03 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:03 --> Total execution time: 0.0531
DEBUG - 2011-04-24 06:06:06 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:06 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:06 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:06 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:06 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:06 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:06 --> Total execution time: 0.2323
DEBUG - 2011-04-24 06:06:07 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:07 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:07 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:07 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:07 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:07 --> Total execution time: 0.0491
DEBUG - 2011-04-24 06:06:08 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:08 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:08 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:08 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:08 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:08 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:08 --> Total execution time: 0.0610
DEBUG - 2011-04-24 06:06:37 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:37 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:37 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:37 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:37 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:37 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:37 --> Total execution time: 0.2397
DEBUG - 2011-04-24 06:06:38 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:38 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:38 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:38 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:38 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:38 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:38 --> Total execution time: 0.0516
DEBUG - 2011-04-24 06:06:46 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:46 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:46 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:46 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:46 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:46 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:46 --> Total execution time: 0.2413
DEBUG - 2011-04-24 06:06:47 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:47 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:47 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:06:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:06:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:06:47 --> Final output sent to browser
DEBUG - 2011-04-24 06:06:47 --> Total execution time: 0.0581
DEBUG - 2011-04-24 06:06:59 --> Config Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:06:59 --> URI Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Router Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Output Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Input Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:06:59 --> Language Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Loader Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Controller Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Model Class Initialized
DEBUG - 2011-04-24 06:06:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:06:59 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:07:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:07:00 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:07:00 --> Final output sent to browser
DEBUG - 2011-04-24 06:07:00 --> Total execution time: 0.3607
DEBUG - 2011-04-24 06:07:01 --> Config Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:07:01 --> URI Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Router Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Output Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Input Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:07:01 --> Language Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Loader Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Controller Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:07:01 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:07:01 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:07:01 --> Final output sent to browser
DEBUG - 2011-04-24 06:07:01 --> Total execution time: 0.0557
DEBUG - 2011-04-24 06:07:13 --> Config Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:07:13 --> URI Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Router Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Output Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Input Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:07:13 --> Language Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Loader Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Controller Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:07:13 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:07:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:07:13 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:07:13 --> Final output sent to browser
DEBUG - 2011-04-24 06:07:13 --> Total execution time: 0.3145
DEBUG - 2011-04-24 06:07:14 --> Config Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:07:14 --> URI Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Router Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Output Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Input Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:07:14 --> Language Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Loader Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Controller Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:07:14 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:07:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:07:14 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:07:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:07:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:07:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:07:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:07:14 --> Final output sent to browser
DEBUG - 2011-04-24 06:07:14 --> Total execution time: 0.0454
DEBUG - 2011-04-24 06:07:15 --> Config Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:07:15 --> URI Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Router Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Output Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Input Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:07:15 --> Language Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Loader Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Controller Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Model Class Initialized
DEBUG - 2011-04-24 06:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:07:15 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:07:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:07:15 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:07:15 --> Final output sent to browser
DEBUG - 2011-04-24 06:07:15 --> Total execution time: 0.0573
DEBUG - 2011-04-24 06:09:48 --> Config Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:09:48 --> URI Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Router Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Output Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Input Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:09:48 --> Language Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Loader Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Controller Class Initialized
ERROR - 2011-04-24 06:09:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 06:09:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 06:09:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 06:09:48 --> Model Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Model Class Initialized
DEBUG - 2011-04-24 06:09:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:09:48 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:09:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 06:09:48 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:09:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:09:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:09:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:09:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:09:48 --> Final output sent to browser
DEBUG - 2011-04-24 06:09:48 --> Total execution time: 0.2252
DEBUG - 2011-04-24 06:09:49 --> Config Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:09:49 --> URI Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Router Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Output Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Input Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:09:49 --> Language Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Loader Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Controller Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Model Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Model Class Initialized
DEBUG - 2011-04-24 06:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:09:49 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:09:50 --> Final output sent to browser
DEBUG - 2011-04-24 06:09:50 --> Total execution time: 0.7687
DEBUG - 2011-04-24 06:09:51 --> Config Class Initialized
DEBUG - 2011-04-24 06:09:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:09:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:09:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:09:51 --> URI Class Initialized
DEBUG - 2011-04-24 06:09:51 --> Router Class Initialized
ERROR - 2011-04-24 06:09:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 06:10:59 --> Config Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:10:59 --> URI Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Router Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Output Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Input Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 06:10:59 --> Language Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Loader Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Controller Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Model Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Model Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Model Class Initialized
DEBUG - 2011-04-24 06:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 06:10:59 --> Database Driver Class Initialized
DEBUG - 2011-04-24 06:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 06:10:59 --> Helper loaded: url_helper
DEBUG - 2011-04-24 06:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 06:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 06:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 06:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 06:10:59 --> Final output sent to browser
DEBUG - 2011-04-24 06:10:59 --> Total execution time: 0.0516
DEBUG - 2011-04-24 06:11:00 --> Config Class Initialized
DEBUG - 2011-04-24 06:11:00 --> Hooks Class Initialized
DEBUG - 2011-04-24 06:11:00 --> Utf8 Class Initialized
DEBUG - 2011-04-24 06:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 06:11:00 --> URI Class Initialized
DEBUG - 2011-04-24 06:11:00 --> Router Class Initialized
ERROR - 2011-04-24 06:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 07:21:12 --> Config Class Initialized
DEBUG - 2011-04-24 07:21:12 --> Hooks Class Initialized
DEBUG - 2011-04-24 07:21:12 --> Utf8 Class Initialized
DEBUG - 2011-04-24 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 07:21:12 --> URI Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Router Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Output Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Input Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 07:21:13 --> Language Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Loader Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Controller Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 07:21:13 --> Database Driver Class Initialized
DEBUG - 2011-04-24 07:21:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 07:21:13 --> Helper loaded: url_helper
DEBUG - 2011-04-24 07:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 07:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 07:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 07:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 07:21:13 --> Final output sent to browser
DEBUG - 2011-04-24 07:21:13 --> Total execution time: 0.5025
DEBUG - 2011-04-24 07:21:15 --> Config Class Initialized
DEBUG - 2011-04-24 07:21:15 --> Hooks Class Initialized
DEBUG - 2011-04-24 07:21:15 --> Utf8 Class Initialized
DEBUG - 2011-04-24 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 07:21:15 --> URI Class Initialized
DEBUG - 2011-04-24 07:21:15 --> Router Class Initialized
ERROR - 2011-04-24 07:21:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 07:21:17 --> Config Class Initialized
DEBUG - 2011-04-24 07:21:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 07:21:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 07:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 07:21:17 --> URI Class Initialized
DEBUG - 2011-04-24 07:21:17 --> Router Class Initialized
ERROR - 2011-04-24 07:21:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 07:21:28 --> Config Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Hooks Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Utf8 Class Initialized
DEBUG - 2011-04-24 07:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 07:21:28 --> URI Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Router Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Output Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Input Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 07:21:28 --> Language Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Loader Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Controller Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 07:21:29 --> Database Driver Class Initialized
DEBUG - 2011-04-24 07:21:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 07:21:29 --> Helper loaded: url_helper
DEBUG - 2011-04-24 07:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 07:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 07:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 07:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 07:21:29 --> Final output sent to browser
DEBUG - 2011-04-24 07:21:29 --> Total execution time: 0.0447
DEBUG - 2011-04-24 07:21:31 --> Config Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Hooks Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Utf8 Class Initialized
DEBUG - 2011-04-24 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 07:21:31 --> URI Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Router Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Output Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Input Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 07:21:31 --> Language Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Loader Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Controller Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Model Class Initialized
DEBUG - 2011-04-24 07:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 07:21:31 --> Database Driver Class Initialized
DEBUG - 2011-04-24 07:21:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 07:21:31 --> Helper loaded: url_helper
DEBUG - 2011-04-24 07:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 07:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 07:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 07:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 07:21:31 --> Final output sent to browser
DEBUG - 2011-04-24 07:21:31 --> Total execution time: 0.0467
DEBUG - 2011-04-24 08:42:39 --> Config Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:42:39 --> URI Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Router Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Output Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Input Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 08:42:39 --> Language Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Loader Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Controller Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Model Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Model Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Model Class Initialized
DEBUG - 2011-04-24 08:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 08:42:39 --> Database Driver Class Initialized
DEBUG - 2011-04-24 08:42:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 08:42:40 --> Helper loaded: url_helper
DEBUG - 2011-04-24 08:42:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 08:42:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 08:42:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 08:42:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 08:42:40 --> Final output sent to browser
DEBUG - 2011-04-24 08:42:40 --> Total execution time: 0.7232
DEBUG - 2011-04-24 08:42:46 --> Config Class Initialized
DEBUG - 2011-04-24 08:42:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:42:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:42:46 --> URI Class Initialized
DEBUG - 2011-04-24 08:42:46 --> Router Class Initialized
ERROR - 2011-04-24 08:42:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 08:42:47 --> Config Class Initialized
DEBUG - 2011-04-24 08:42:47 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:42:47 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:42:47 --> URI Class Initialized
DEBUG - 2011-04-24 08:42:47 --> Router Class Initialized
ERROR - 2011-04-24 08:42:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 08:43:13 --> Config Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:43:13 --> URI Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Router Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Output Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Input Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 08:43:13 --> Language Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Loader Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Controller Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Model Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Model Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Model Class Initialized
DEBUG - 2011-04-24 08:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 08:43:13 --> Database Driver Class Initialized
DEBUG - 2011-04-24 08:43:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 08:43:13 --> Helper loaded: url_helper
DEBUG - 2011-04-24 08:43:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 08:43:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 08:43:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 08:43:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 08:43:13 --> Final output sent to browser
DEBUG - 2011-04-24 08:43:13 --> Total execution time: 0.0517
DEBUG - 2011-04-24 08:43:16 --> Config Class Initialized
DEBUG - 2011-04-24 08:43:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:43:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:43:16 --> URI Class Initialized
DEBUG - 2011-04-24 08:43:16 --> Router Class Initialized
ERROR - 2011-04-24 08:43:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 08:43:47 --> Config Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:43:47 --> URI Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Router Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Output Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Input Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 08:43:47 --> Language Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Loader Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Controller Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Model Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Model Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Model Class Initialized
DEBUG - 2011-04-24 08:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 08:43:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 08:43:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 08:43:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 08:43:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 08:43:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 08:43:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 08:43:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 08:43:47 --> Final output sent to browser
DEBUG - 2011-04-24 08:43:47 --> Total execution time: 0.0450
DEBUG - 2011-04-24 08:43:50 --> Config Class Initialized
DEBUG - 2011-04-24 08:43:50 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:43:50 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:43:50 --> URI Class Initialized
DEBUG - 2011-04-24 08:43:50 --> Router Class Initialized
ERROR - 2011-04-24 08:43:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 08:43:55 --> Config Class Initialized
DEBUG - 2011-04-24 08:43:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:43:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:43:55 --> URI Class Initialized
DEBUG - 2011-04-24 08:43:55 --> Router Class Initialized
ERROR - 2011-04-24 08:43:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 08:49:26 --> Config Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:49:26 --> URI Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Router Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Output Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Input Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 08:49:26 --> Language Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Loader Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Controller Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Model Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Model Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Model Class Initialized
DEBUG - 2011-04-24 08:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 08:49:26 --> Database Driver Class Initialized
DEBUG - 2011-04-24 08:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 08:49:26 --> Helper loaded: url_helper
DEBUG - 2011-04-24 08:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 08:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 08:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 08:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 08:49:26 --> Final output sent to browser
DEBUG - 2011-04-24 08:49:26 --> Total execution time: 0.0535
DEBUG - 2011-04-24 08:49:32 --> Config Class Initialized
DEBUG - 2011-04-24 08:49:32 --> Hooks Class Initialized
DEBUG - 2011-04-24 08:49:32 --> Utf8 Class Initialized
DEBUG - 2011-04-24 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 08:49:32 --> URI Class Initialized
DEBUG - 2011-04-24 08:49:32 --> Router Class Initialized
ERROR - 2011-04-24 08:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:12:19 --> Config Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:12:20 --> URI Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Router Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Output Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Input Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:12:20 --> Language Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Loader Class Initialized
DEBUG - 2011-04-24 10:12:20 --> Controller Class Initialized
ERROR - 2011-04-24 10:12:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:12:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:12:21 --> Model Class Initialized
DEBUG - 2011-04-24 10:12:21 --> Model Class Initialized
DEBUG - 2011-04-24 10:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:12:21 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:12:22 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:12:22 --> Final output sent to browser
DEBUG - 2011-04-24 10:12:22 --> Total execution time: 2.4459
DEBUG - 2011-04-24 10:12:23 --> Config Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:12:23 --> URI Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Router Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Output Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Input Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:12:23 --> Language Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Loader Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Controller Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:12:23 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:12:24 --> Final output sent to browser
DEBUG - 2011-04-24 10:12:24 --> Total execution time: 1.2677
DEBUG - 2011-04-24 10:12:25 --> Config Class Initialized
DEBUG - 2011-04-24 10:12:25 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:12:25 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:12:25 --> URI Class Initialized
DEBUG - 2011-04-24 10:12:25 --> Router Class Initialized
ERROR - 2011-04-24 10:12:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:12:26 --> Config Class Initialized
DEBUG - 2011-04-24 10:12:26 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:12:26 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:12:26 --> URI Class Initialized
DEBUG - 2011-04-24 10:12:26 --> Router Class Initialized
ERROR - 2011-04-24 10:12:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:12:26 --> Config Class Initialized
DEBUG - 2011-04-24 10:12:26 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:12:26 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:12:26 --> URI Class Initialized
DEBUG - 2011-04-24 10:12:26 --> Router Class Initialized
ERROR - 2011-04-24 10:12:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:13:21 --> Config Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:13:21 --> URI Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Router Class Initialized
DEBUG - 2011-04-24 10:13:21 --> No URI present. Default controller set.
DEBUG - 2011-04-24 10:13:21 --> Output Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Input Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:13:21 --> Language Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Loader Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Controller Class Initialized
DEBUG - 2011-04-24 10:13:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 10:13:21 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:13:21 --> Final output sent to browser
DEBUG - 2011-04-24 10:13:21 --> Total execution time: 0.0610
DEBUG - 2011-04-24 10:13:21 --> Config Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:13:21 --> URI Class Initialized
DEBUG - 2011-04-24 10:13:21 --> Router Class Initialized
ERROR - 2011-04-24 10:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:30:07 --> Config Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:30:07 --> URI Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Router Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Output Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Input Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:30:07 --> Language Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Loader Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Controller Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Model Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Model Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Model Class Initialized
DEBUG - 2011-04-24 10:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:30:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:30:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 10:30:08 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:30:08 --> Final output sent to browser
DEBUG - 2011-04-24 10:30:08 --> Total execution time: 1.7655
DEBUG - 2011-04-24 10:35:10 --> Config Class Initialized
DEBUG - 2011-04-24 10:35:10 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:35:10 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:35:10 --> URI Class Initialized
DEBUG - 2011-04-24 10:35:10 --> Router Class Initialized
DEBUG - 2011-04-24 10:35:10 --> Output Class Initialized
DEBUG - 2011-04-24 10:35:11 --> Input Class Initialized
DEBUG - 2011-04-24 10:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:35:11 --> Language Class Initialized
DEBUG - 2011-04-24 10:35:11 --> Loader Class Initialized
DEBUG - 2011-04-24 10:35:11 --> Controller Class Initialized
ERROR - 2011-04-24 10:35:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:35:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:35:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:35:12 --> Model Class Initialized
DEBUG - 2011-04-24 10:35:12 --> Model Class Initialized
DEBUG - 2011-04-24 10:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:35:14 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:35:15 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:35:15 --> Final output sent to browser
DEBUG - 2011-04-24 10:35:15 --> Total execution time: 5.8756
DEBUG - 2011-04-24 10:35:17 --> Config Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:35:17 --> URI Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Router Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Output Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Input Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:35:17 --> Language Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Loader Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Controller Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Model Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Model Class Initialized
DEBUG - 2011-04-24 10:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:35:17 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:35:18 --> Final output sent to browser
DEBUG - 2011-04-24 10:35:18 --> Total execution time: 0.8071
DEBUG - 2011-04-24 10:35:19 --> Config Class Initialized
DEBUG - 2011-04-24 10:35:19 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:35:19 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:35:19 --> URI Class Initialized
DEBUG - 2011-04-24 10:35:19 --> Router Class Initialized
ERROR - 2011-04-24 10:35:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:35:21 --> Config Class Initialized
DEBUG - 2011-04-24 10:35:21 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:35:21 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:35:21 --> URI Class Initialized
DEBUG - 2011-04-24 10:35:21 --> Router Class Initialized
ERROR - 2011-04-24 10:35:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:35:40 --> Config Class Initialized
DEBUG - 2011-04-24 10:35:40 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:35:40 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:35:40 --> URI Class Initialized
DEBUG - 2011-04-24 10:35:40 --> Router Class Initialized
ERROR - 2011-04-24 10:35:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 10:35:48 --> Config Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:35:48 --> URI Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Router Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Output Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Input Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:35:48 --> Language Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Loader Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Controller Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Model Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Model Class Initialized
DEBUG - 2011-04-24 10:35:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:35:48 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:35:49 --> Final output sent to browser
DEBUG - 2011-04-24 10:35:49 --> Total execution time: 0.3658
DEBUG - 2011-04-24 10:36:45 --> Config Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:36:45 --> URI Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Router Class Initialized
DEBUG - 2011-04-24 10:36:45 --> No URI present. Default controller set.
DEBUG - 2011-04-24 10:36:45 --> Output Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Input Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:36:45 --> Language Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Loader Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Controller Class Initialized
DEBUG - 2011-04-24 10:36:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 10:36:45 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:36:45 --> Final output sent to browser
DEBUG - 2011-04-24 10:36:45 --> Total execution time: 0.1269
DEBUG - 2011-04-24 10:36:45 --> Config Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:36:45 --> URI Class Initialized
DEBUG - 2011-04-24 10:36:45 --> Router Class Initialized
ERROR - 2011-04-24 10:36:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:49:28 --> Config Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:49:28 --> URI Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Router Class Initialized
DEBUG - 2011-04-24 10:49:28 --> No URI present. Default controller set.
DEBUG - 2011-04-24 10:49:28 --> Output Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Input Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:49:28 --> Language Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Loader Class Initialized
DEBUG - 2011-04-24 10:49:28 --> Controller Class Initialized
DEBUG - 2011-04-24 10:49:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 10:49:28 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:49:28 --> Final output sent to browser
DEBUG - 2011-04-24 10:49:28 --> Total execution time: 0.2321
DEBUG - 2011-04-24 10:49:38 --> Config Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:49:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:49:38 --> URI Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Router Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Output Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Input Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:49:38 --> Language Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Loader Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Controller Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:49:38 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:49:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 10:49:38 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:49:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:49:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:49:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:49:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:49:38 --> Final output sent to browser
DEBUG - 2011-04-24 10:49:38 --> Total execution time: 0.2230
DEBUG - 2011-04-24 10:49:46 --> Config Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:49:46 --> URI Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Router Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Output Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Input Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:49:46 --> Language Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Loader Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Controller Class Initialized
ERROR - 2011-04-24 10:49:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:49:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:49:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:49:46 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:49:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:49:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:49:47 --> Final output sent to browser
DEBUG - 2011-04-24 10:49:47 --> Total execution time: 0.1150
DEBUG - 2011-04-24 10:49:47 --> Config Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:49:47 --> URI Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Router Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Output Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Input Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:49:47 --> Language Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Loader Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Controller Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Model Class Initialized
DEBUG - 2011-04-24 10:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:49:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:49:48 --> Final output sent to browser
DEBUG - 2011-04-24 10:49:48 --> Total execution time: 0.6025
DEBUG - 2011-04-24 10:51:15 --> Config Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:51:15 --> URI Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Router Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Output Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Input Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:51:15 --> Language Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Loader Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Controller Class Initialized
ERROR - 2011-04-24 10:51:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:51:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:51:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:51:15 --> Model Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Model Class Initialized
DEBUG - 2011-04-24 10:51:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:51:15 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:51:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:51:15 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:51:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:51:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:51:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:51:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:51:15 --> Final output sent to browser
DEBUG - 2011-04-24 10:51:15 --> Total execution time: 0.0306
DEBUG - 2011-04-24 10:51:16 --> Config Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:51:16 --> URI Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Router Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Output Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Input Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:51:16 --> Language Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Loader Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Controller Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Model Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Model Class Initialized
DEBUG - 2011-04-24 10:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:51:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:51:18 --> Final output sent to browser
DEBUG - 2011-04-24 10:51:18 --> Total execution time: 1.3824
DEBUG - 2011-04-24 10:52:22 --> Config Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:52:22 --> URI Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Router Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Output Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Input Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:52:22 --> Language Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Loader Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Controller Class Initialized
ERROR - 2011-04-24 10:52:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:52:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:52:22 --> Model Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Model Class Initialized
DEBUG - 2011-04-24 10:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:52:22 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:52:22 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:52:22 --> Final output sent to browser
DEBUG - 2011-04-24 10:52:22 --> Total execution time: 0.1733
DEBUG - 2011-04-24 10:52:23 --> Config Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:52:23 --> URI Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Router Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Output Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Input Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:52:23 --> Language Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Loader Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Controller Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:52:23 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:52:24 --> Final output sent to browser
DEBUG - 2011-04-24 10:52:24 --> Total execution time: 1.5307
DEBUG - 2011-04-24 10:52:26 --> Config Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:52:26 --> URI Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Router Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Output Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Input Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:52:26 --> Language Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Loader Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Controller Class Initialized
ERROR - 2011-04-24 10:52:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:52:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:52:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:52:26 --> Model Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Model Class Initialized
DEBUG - 2011-04-24 10:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:52:26 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:52:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:52:26 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:52:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:52:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:52:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:52:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:52:26 --> Final output sent to browser
DEBUG - 2011-04-24 10:52:26 --> Total execution time: 0.2316
DEBUG - 2011-04-24 10:53:23 --> Config Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:53:23 --> URI Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Router Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Output Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Input Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:53:23 --> Language Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Loader Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Controller Class Initialized
ERROR - 2011-04-24 10:53:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:53:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:53:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:53:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:53:23 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:53:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:53:23 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:53:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:53:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:53:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:53:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:53:23 --> Final output sent to browser
DEBUG - 2011-04-24 10:53:23 --> Total execution time: 0.0912
DEBUG - 2011-04-24 10:53:24 --> Config Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:53:24 --> URI Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Router Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Output Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Input Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:53:24 --> Language Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Loader Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Controller Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:53:24 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:53:25 --> Final output sent to browser
DEBUG - 2011-04-24 10:53:25 --> Total execution time: 1.0624
DEBUG - 2011-04-24 10:53:28 --> Config Class Initialized
DEBUG - 2011-04-24 10:53:28 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:53:28 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:53:28 --> URI Class Initialized
DEBUG - 2011-04-24 10:53:28 --> Router Class Initialized
ERROR - 2011-04-24 10:53:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:53:55 --> Config Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:53:55 --> URI Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Router Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Output Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Input Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:53:55 --> Language Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Loader Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Controller Class Initialized
ERROR - 2011-04-24 10:53:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:53:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:53:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:53:55 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:53:55 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:53:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:53:55 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:53:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:53:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:53:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:53:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:53:55 --> Final output sent to browser
DEBUG - 2011-04-24 10:53:55 --> Total execution time: 0.0295
DEBUG - 2011-04-24 10:53:56 --> Config Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:53:56 --> URI Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Router Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Output Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Input Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:53:56 --> Language Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Loader Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Controller Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Model Class Initialized
DEBUG - 2011-04-24 10:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:53:56 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:53:57 --> Final output sent to browser
DEBUG - 2011-04-24 10:53:57 --> Total execution time: 1.1458
DEBUG - 2011-04-24 10:53:59 --> Config Class Initialized
DEBUG - 2011-04-24 10:53:59 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:53:59 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:53:59 --> URI Class Initialized
DEBUG - 2011-04-24 10:53:59 --> Router Class Initialized
ERROR - 2011-04-24 10:53:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:54:26 --> Config Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:54:26 --> URI Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Router Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Output Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Input Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:54:26 --> Language Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Loader Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Controller Class Initialized
ERROR - 2011-04-24 10:54:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:54:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:54:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:54:26 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:54:26 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:54:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:54:26 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:54:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:54:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:54:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:54:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:54:26 --> Final output sent to browser
DEBUG - 2011-04-24 10:54:26 --> Total execution time: 0.0296
DEBUG - 2011-04-24 10:54:27 --> Config Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:54:27 --> URI Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Router Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Output Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Input Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:54:27 --> Language Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Loader Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Controller Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:54:27 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:54:28 --> Final output sent to browser
DEBUG - 2011-04-24 10:54:28 --> Total execution time: 0.7815
DEBUG - 2011-04-24 10:54:51 --> Config Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:54:51 --> URI Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Router Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Output Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Input Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:54:51 --> Language Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Loader Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Controller Class Initialized
ERROR - 2011-04-24 10:54:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:54:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:54:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:54:51 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:54:51 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:54:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:54:51 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:54:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:54:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:54:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:54:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:54:51 --> Final output sent to browser
DEBUG - 2011-04-24 10:54:51 --> Total execution time: 0.0306
DEBUG - 2011-04-24 10:54:52 --> Config Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:54:52 --> URI Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Router Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Output Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Input Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:54:52 --> Language Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Loader Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Controller Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Model Class Initialized
DEBUG - 2011-04-24 10:54:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:54:52 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:54:53 --> Final output sent to browser
DEBUG - 2011-04-24 10:54:53 --> Total execution time: 0.9604
DEBUG - 2011-04-24 10:55:16 --> Config Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:55:16 --> URI Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Router Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Output Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Input Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:55:16 --> Language Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Loader Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Controller Class Initialized
ERROR - 2011-04-24 10:55:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:55:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:55:16 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:55:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:55:16 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:55:16 --> Final output sent to browser
DEBUG - 2011-04-24 10:55:16 --> Total execution time: 0.0305
DEBUG - 2011-04-24 10:55:17 --> Config Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:55:17 --> URI Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Router Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Output Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Input Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:55:17 --> Language Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Loader Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Controller Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:55:17 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:55:20 --> Final output sent to browser
DEBUG - 2011-04-24 10:55:20 --> Total execution time: 2.1637
DEBUG - 2011-04-24 10:55:35 --> Config Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:55:35 --> URI Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Router Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Output Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Input Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:55:35 --> Language Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Loader Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Controller Class Initialized
ERROR - 2011-04-24 10:55:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:55:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:55:35 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:55:35 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:55:35 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:55:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:55:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:55:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:55:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:55:35 --> Final output sent to browser
DEBUG - 2011-04-24 10:55:35 --> Total execution time: 0.0797
DEBUG - 2011-04-24 10:55:36 --> Config Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:55:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:55:36 --> URI Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Router Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Output Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Input Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:55:36 --> Language Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Loader Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Controller Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Model Class Initialized
DEBUG - 2011-04-24 10:55:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:55:36 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:55:37 --> Final output sent to browser
DEBUG - 2011-04-24 10:55:37 --> Total execution time: 0.6160
DEBUG - 2011-04-24 10:56:06 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:06 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:06 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Controller Class Initialized
ERROR - 2011-04-24 10:56:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:56:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:06 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:06 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:06 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:56:06 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:06 --> Total execution time: 0.0369
DEBUG - 2011-04-24 10:56:07 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:07 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:07 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Controller Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:08 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:08 --> Total execution time: 1.0807
DEBUG - 2011-04-24 10:56:16 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:16 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:16 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Controller Class Initialized
ERROR - 2011-04-24 10:56:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:56:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:56:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:16 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:17 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:17 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:56:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:56:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:56:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:56:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:56:17 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:17 --> Total execution time: 0.1444
DEBUG - 2011-04-24 10:56:17 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:17 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:17 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Controller Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:18 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:18 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:18 --> Total execution time: 0.5224
DEBUG - 2011-04-24 10:56:31 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:31 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:31 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Controller Class Initialized
ERROR - 2011-04-24 10:56:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:56:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:31 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:31 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:31 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:56:31 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:31 --> Total execution time: 0.0296
DEBUG - 2011-04-24 10:56:32 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:32 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:32 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Controller Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:32 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:33 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:33 --> Total execution time: 0.5849
DEBUG - 2011-04-24 10:56:55 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:55 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:55 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:55 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:56 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Controller Class Initialized
ERROR - 2011-04-24 10:56:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:56:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:56 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:56 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:56 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:56:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:56:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:56:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:56:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:56:56 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:56 --> Total execution time: 0.0864
DEBUG - 2011-04-24 10:56:56 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:56 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:56 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Controller Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:56 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Config Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:56:57 --> URI Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Router Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Output Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Input Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:56:57 --> Language Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Loader Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Controller Class Initialized
ERROR - 2011-04-24 10:56:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:56:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:56:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:57 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Model Class Initialized
DEBUG - 2011-04-24 10:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:56:57 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:56:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:56:57 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:56:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:56:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:56:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:56:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:56:57 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:57 --> Total execution time: 0.0592
DEBUG - 2011-04-24 10:56:57 --> Final output sent to browser
DEBUG - 2011-04-24 10:56:57 --> Total execution time: 0.9524
DEBUG - 2011-04-24 10:57:35 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:35 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Router Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Output Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Input Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:57:35 --> Language Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Loader Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Controller Class Initialized
ERROR - 2011-04-24 10:57:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:57:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:57:35 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:57:35 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:57:35 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:57:35 --> Final output sent to browser
DEBUG - 2011-04-24 10:57:35 --> Total execution time: 0.0309
DEBUG - 2011-04-24 10:57:36 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:36 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Router Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Output Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Input Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:57:36 --> Language Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Loader Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Controller Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:57:36 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:36 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Router Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Output Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Input Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:57:36 --> Language Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Loader Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Controller Class Initialized
ERROR - 2011-04-24 10:57:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:57:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:57:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:57:36 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:57:36 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:57:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:57:36 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:57:36 --> Final output sent to browser
DEBUG - 2011-04-24 10:57:36 --> Total execution time: 0.0309
DEBUG - 2011-04-24 10:57:36 --> Final output sent to browser
DEBUG - 2011-04-24 10:57:36 --> Total execution time: 0.8905
DEBUG - 2011-04-24 10:57:44 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:44 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Router Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Output Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Input Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:57:44 --> Language Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Loader Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Controller Class Initialized
ERROR - 2011-04-24 10:57:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:57:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:57:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:57:44 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:57:44 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:57:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:57:44 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:57:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:57:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:57:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:57:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:57:44 --> Final output sent to browser
DEBUG - 2011-04-24 10:57:44 --> Total execution time: 0.0287
DEBUG - 2011-04-24 10:57:45 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:45 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Router Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Output Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Input Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:57:45 --> Language Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Loader Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Controller Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:57:45 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:57:45 --> Final output sent to browser
DEBUG - 2011-04-24 10:57:45 --> Total execution time: 0.5074
DEBUG - 2011-04-24 10:57:46 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:46 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:46 --> Router Class Initialized
ERROR - 2011-04-24 10:57:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:57:52 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:52 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Router Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Output Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Input Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:57:52 --> Language Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Loader Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Controller Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Model Class Initialized
DEBUG - 2011-04-24 10:57:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:57:52 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:57:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 10:57:52 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:57:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:57:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:57:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:57:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:57:52 --> Final output sent to browser
DEBUG - 2011-04-24 10:57:52 --> Total execution time: 0.0930
DEBUG - 2011-04-24 10:57:53 --> Config Class Initialized
DEBUG - 2011-04-24 10:57:53 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:57:53 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:57:53 --> URI Class Initialized
DEBUG - 2011-04-24 10:57:53 --> Router Class Initialized
ERROR - 2011-04-24 10:57:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 10:58:20 --> Config Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:58:20 --> URI Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Router Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Output Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Input Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:58:20 --> Language Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Loader Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Controller Class Initialized
ERROR - 2011-04-24 10:58:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:58:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:58:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:58:20 --> Model Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Model Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:58:20 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:58:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:58:20 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:58:20 --> Final output sent to browser
DEBUG - 2011-04-24 10:58:20 --> Total execution time: 0.0279
DEBUG - 2011-04-24 10:58:20 --> Config Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:58:20 --> URI Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Router Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Output Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Input Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:58:20 --> Language Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Loader Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Controller Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Model Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Model Class Initialized
DEBUG - 2011-04-24 10:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:58:20 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:58:21 --> Final output sent to browser
DEBUG - 2011-04-24 10:58:21 --> Total execution time: 0.6910
DEBUG - 2011-04-24 10:58:23 --> Config Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:58:23 --> URI Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Router Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Output Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Input Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:58:23 --> Language Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Loader Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Controller Class Initialized
ERROR - 2011-04-24 10:58:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:58:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:58:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Model Class Initialized
DEBUG - 2011-04-24 10:58:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:58:23 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:58:23 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:58:23 --> Final output sent to browser
DEBUG - 2011-04-24 10:58:23 --> Total execution time: 0.0374
DEBUG - 2011-04-24 10:59:43 --> Config Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:59:43 --> URI Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Router Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Output Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Input Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:59:43 --> Language Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Loader Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Controller Class Initialized
ERROR - 2011-04-24 10:59:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 10:59:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 10:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:59:43 --> Model Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Model Class Initialized
DEBUG - 2011-04-24 10:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:59:43 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 10:59:43 --> Helper loaded: url_helper
DEBUG - 2011-04-24 10:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 10:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 10:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 10:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 10:59:43 --> Final output sent to browser
DEBUG - 2011-04-24 10:59:43 --> Total execution time: 0.0537
DEBUG - 2011-04-24 10:59:44 --> Config Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Hooks Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Utf8 Class Initialized
DEBUG - 2011-04-24 10:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 10:59:44 --> URI Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Router Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Output Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Input Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 10:59:44 --> Language Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Loader Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Controller Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Model Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Model Class Initialized
DEBUG - 2011-04-24 10:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 10:59:44 --> Database Driver Class Initialized
DEBUG - 2011-04-24 10:59:45 --> Final output sent to browser
DEBUG - 2011-04-24 10:59:45 --> Total execution time: 1.1162
DEBUG - 2011-04-24 11:00:39 --> Config Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:00:39 --> URI Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Router Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Output Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Input Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:00:39 --> Language Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Loader Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Controller Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Model Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Model Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Model Class Initialized
DEBUG - 2011-04-24 11:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:00:39 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:00:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 11:00:39 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:00:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:00:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:00:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:00:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:00:39 --> Final output sent to browser
DEBUG - 2011-04-24 11:00:39 --> Total execution time: 0.1383
DEBUG - 2011-04-24 11:00:40 --> Config Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:00:40 --> URI Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Router Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Output Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Input Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:00:40 --> Language Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Loader Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Controller Class Initialized
ERROR - 2011-04-24 11:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:00:40 --> Model Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Model Class Initialized
DEBUG - 2011-04-24 11:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:00:40 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:00:40 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:00:40 --> Final output sent to browser
DEBUG - 2011-04-24 11:00:40 --> Total execution time: 0.0505
DEBUG - 2011-04-24 11:01:07 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:07 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:07 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Controller Class Initialized
ERROR - 2011-04-24 11:01:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:01:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:01:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:07 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:07 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:01:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:01:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:01:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:01:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:01:07 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:07 --> Total execution time: 0.0345
DEBUG - 2011-04-24 11:01:08 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:08 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:08 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Controller Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:08 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:09 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:09 --> Total execution time: 0.8577
DEBUG - 2011-04-24 11:01:22 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:22 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:22 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Controller Class Initialized
ERROR - 2011-04-24 11:01:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:01:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:01:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:22 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:22 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:22 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:01:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:01:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:01:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:01:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:01:22 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:22 --> Total execution time: 0.0267
DEBUG - 2011-04-24 11:01:23 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:23 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:23 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Controller Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:23 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:24 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:24 --> Total execution time: 0.6394
DEBUG - 2011-04-24 11:01:50 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:50 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:50 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Controller Class Initialized
ERROR - 2011-04-24 11:01:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:01:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:01:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:50 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:50 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:50 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:01:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:01:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:01:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:01:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:01:50 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:50 --> Total execution time: 0.1052
DEBUG - 2011-04-24 11:01:51 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:51 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:51 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Controller Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:51 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:51 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:51 --> Total execution time: 0.6646
DEBUG - 2011-04-24 11:01:52 --> Config Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:01:52 --> URI Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Router Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Output Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Input Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:01:52 --> Language Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Loader Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Controller Class Initialized
ERROR - 2011-04-24 11:01:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:52 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Model Class Initialized
DEBUG - 2011-04-24 11:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:01:52 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:01:52 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:01:52 --> Final output sent to browser
DEBUG - 2011-04-24 11:01:52 --> Total execution time: 0.0279
DEBUG - 2011-04-24 11:02:04 --> Config Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:02:04 --> URI Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Router Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Output Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Input Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:02:04 --> Language Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Loader Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Controller Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:02:04 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:02:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 11:02:04 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:02:04 --> Final output sent to browser
DEBUG - 2011-04-24 11:02:04 --> Total execution time: 0.0580
DEBUG - 2011-04-24 11:02:10 --> Config Class Initialized
DEBUG - 2011-04-24 11:02:10 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:02:10 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:02:10 --> URI Class Initialized
DEBUG - 2011-04-24 11:02:10 --> Router Class Initialized
ERROR - 2011-04-24 11:02:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 11:11:03 --> Config Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:11:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:11:03 --> URI Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Router Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Output Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Input Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:11:03 --> Language Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Loader Class Initialized
DEBUG - 2011-04-24 11:11:03 --> Controller Class Initialized
ERROR - 2011-04-24 11:11:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:11:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:11:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:11:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:11:04 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:11:04 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:11:04 --> Final output sent to browser
DEBUG - 2011-04-24 11:11:04 --> Total execution time: 0.1412
DEBUG - 2011-04-24 11:11:06 --> Config Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:11:06 --> URI Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Router Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Output Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Input Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:11:06 --> Language Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Loader Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Controller Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Model Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Model Class Initialized
DEBUG - 2011-04-24 11:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:11:06 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:11:07 --> Final output sent to browser
DEBUG - 2011-04-24 11:11:07 --> Total execution time: 1.0514
DEBUG - 2011-04-24 11:12:05 --> Config Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:12:05 --> URI Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Router Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Output Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Input Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:12:05 --> Language Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Loader Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Controller Class Initialized
ERROR - 2011-04-24 11:12:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:12:05 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:12:05 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:12:05 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:12:05 --> Final output sent to browser
DEBUG - 2011-04-24 11:12:05 --> Total execution time: 0.0326
DEBUG - 2011-04-24 11:12:05 --> Config Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:12:05 --> URI Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Router Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Output Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Input Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:12:05 --> Language Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Loader Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Controller Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:12:05 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:12:06 --> Final output sent to browser
DEBUG - 2011-04-24 11:12:06 --> Total execution time: 0.6963
DEBUG - 2011-04-24 11:12:07 --> Config Class Initialized
DEBUG - 2011-04-24 11:12:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:12:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:12:07 --> URI Class Initialized
DEBUG - 2011-04-24 11:12:07 --> Router Class Initialized
ERROR - 2011-04-24 11:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 11:12:08 --> Config Class Initialized
DEBUG - 2011-04-24 11:12:08 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:12:08 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:12:08 --> URI Class Initialized
DEBUG - 2011-04-24 11:12:08 --> Router Class Initialized
ERROR - 2011-04-24 11:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 11:12:16 --> Config Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:12:16 --> URI Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Router Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Output Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Input Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:12:16 --> Language Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Loader Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Controller Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Model Class Initialized
DEBUG - 2011-04-24 11:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:12:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:12:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 11:12:17 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:12:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:12:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:12:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:12:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:12:17 --> Final output sent to browser
DEBUG - 2011-04-24 11:12:17 --> Total execution time: 0.6822
DEBUG - 2011-04-24 11:15:16 --> Config Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:15:16 --> URI Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Router Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Output Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Input Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:15:16 --> Language Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Loader Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Controller Class Initialized
ERROR - 2011-04-24 11:15:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:15:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:15:16 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:15:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:15:16 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:15:16 --> Final output sent to browser
DEBUG - 2011-04-24 11:15:16 --> Total execution time: 0.0861
DEBUG - 2011-04-24 11:15:17 --> Config Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:15:17 --> URI Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Router Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Output Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Input Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:15:17 --> Language Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Loader Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Controller Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:15:17 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:15:18 --> Final output sent to browser
DEBUG - 2011-04-24 11:15:18 --> Total execution time: 1.0887
DEBUG - 2011-04-24 11:15:19 --> Config Class Initialized
DEBUG - 2011-04-24 11:15:19 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:15:19 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:15:19 --> URI Class Initialized
DEBUG - 2011-04-24 11:15:19 --> Router Class Initialized
ERROR - 2011-04-24 11:15:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 11:15:27 --> Config Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:15:27 --> URI Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Router Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Output Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Input Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:15:27 --> Language Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Loader Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Controller Class Initialized
ERROR - 2011-04-24 11:15:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:15:27 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:15:28 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:15:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:15:28 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:15:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:15:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:15:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:15:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:15:28 --> Final output sent to browser
DEBUG - 2011-04-24 11:15:28 --> Total execution time: 0.1203
DEBUG - 2011-04-24 11:15:29 --> Config Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:15:29 --> URI Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Router Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Output Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Input Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:15:29 --> Language Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Loader Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Controller Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Model Class Initialized
DEBUG - 2011-04-24 11:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:15:29 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:15:30 --> Final output sent to browser
DEBUG - 2011-04-24 11:15:30 --> Total execution time: 1.1687
DEBUG - 2011-04-24 11:17:29 --> Config Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:17:29 --> URI Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Router Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Output Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Input Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:17:29 --> Language Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Loader Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Controller Class Initialized
ERROR - 2011-04-24 11:17:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:17:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:17:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:17:29 --> Model Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Model Class Initialized
DEBUG - 2011-04-24 11:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:17:29 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:17:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:17:29 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:17:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:17:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:17:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:17:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:17:29 --> Final output sent to browser
DEBUG - 2011-04-24 11:17:29 --> Total execution time: 0.0523
DEBUG - 2011-04-24 11:17:30 --> Config Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:17:30 --> URI Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Router Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Output Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Input Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:17:30 --> Language Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Loader Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Controller Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Model Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Model Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:17:30 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:17:30 --> Final output sent to browser
DEBUG - 2011-04-24 11:17:30 --> Total execution time: 0.5416
DEBUG - 2011-04-24 11:18:00 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:00 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:00 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Controller Class Initialized
ERROR - 2011-04-24 11:18:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:18:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:18:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:00 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:00 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:00 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:18:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:18:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:18:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:18:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:18:00 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:00 --> Total execution time: 0.0386
DEBUG - 2011-04-24 11:18:01 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:01 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:01 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Controller Class Initialized
ERROR - 2011-04-24 11:18:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:18:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:18:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:01 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:01 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:01 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:18:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:18:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:18:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:18:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:18:01 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:01 --> Total execution time: 0.0291
DEBUG - 2011-04-24 11:18:02 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:02 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:02 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Controller Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:02 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:02 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:02 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Controller Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:02 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:03 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:03 --> Total execution time: 1.2331
DEBUG - 2011-04-24 11:18:04 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:04 --> Total execution time: 1.7396
DEBUG - 2011-04-24 11:18:04 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:04 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:04 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Controller Class Initialized
ERROR - 2011-04-24 11:18:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:18:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:04 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:04 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:18:04 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:04 --> Total execution time: 0.1419
DEBUG - 2011-04-24 11:18:05 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:05 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:05 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:05 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:05 --> Router Class Initialized
ERROR - 2011-04-24 11:18:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 11:18:07 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:07 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:07 --> Router Class Initialized
ERROR - 2011-04-24 11:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 11:18:19 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:19 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:19 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Controller Class Initialized
ERROR - 2011-04-24 11:18:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:18:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:19 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:19 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:19 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:18:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:18:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:18:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:18:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:18:19 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:19 --> Total execution time: 0.0776
DEBUG - 2011-04-24 11:18:20 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:20 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:20 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Controller Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:20 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:21 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:21 --> Total execution time: 0.5619
DEBUG - 2011-04-24 11:18:38 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:38 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:38 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Controller Class Initialized
ERROR - 2011-04-24 11:18:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:38 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:38 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:18:38 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:18:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:18:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:18:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:18:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:18:38 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:38 --> Total execution time: 0.1030
DEBUG - 2011-04-24 11:18:39 --> Config Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:18:39 --> URI Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Router Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Output Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Input Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:18:39 --> Language Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Loader Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Controller Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Model Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:18:39 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:18:39 --> Final output sent to browser
DEBUG - 2011-04-24 11:18:39 --> Total execution time: 0.5995
DEBUG - 2011-04-24 11:26:41 --> Config Class Initialized
DEBUG - 2011-04-24 11:26:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:26:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:26:41 --> URI Class Initialized
DEBUG - 2011-04-24 11:26:41 --> Router Class Initialized
ERROR - 2011-04-24 11:26:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 11:26:46 --> Config Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:26:46 --> URI Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Router Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Output Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Input Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:26:46 --> Language Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Loader Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Controller Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:26:46 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 11:26:46 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:26:46 --> Final output sent to browser
DEBUG - 2011-04-24 11:26:46 --> Total execution time: 0.1960
DEBUG - 2011-04-24 11:26:58 --> Config Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:26:58 --> URI Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Router Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Output Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Input Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:26:58 --> Language Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Loader Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Controller Class Initialized
ERROR - 2011-04-24 11:26:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:26:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:26:58 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:26:58 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:26:58 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:26:58 --> Final output sent to browser
DEBUG - 2011-04-24 11:26:58 --> Total execution time: 0.1208
DEBUG - 2011-04-24 11:26:59 --> Config Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:26:59 --> URI Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Router Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Output Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Input Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:26:59 --> Language Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Loader Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Controller Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Model Class Initialized
DEBUG - 2011-04-24 11:26:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:26:59 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:27:00 --> Final output sent to browser
DEBUG - 2011-04-24 11:27:00 --> Total execution time: 0.8060
DEBUG - 2011-04-24 11:27:32 --> Config Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Hooks Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Utf8 Class Initialized
DEBUG - 2011-04-24 11:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 11:27:32 --> URI Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Router Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Output Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Input Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 11:27:32 --> Language Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Loader Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Controller Class Initialized
ERROR - 2011-04-24 11:27:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 11:27:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 11:27:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:27:32 --> Model Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Model Class Initialized
DEBUG - 2011-04-24 11:27:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 11:27:32 --> Database Driver Class Initialized
DEBUG - 2011-04-24 11:27:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 11:27:32 --> Helper loaded: url_helper
DEBUG - 2011-04-24 11:27:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 11:27:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 11:27:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 11:27:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 11:27:32 --> Final output sent to browser
DEBUG - 2011-04-24 11:27:32 --> Total execution time: 0.0698
DEBUG - 2011-04-24 12:16:50 --> Config Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:16:50 --> URI Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Router Class Initialized
DEBUG - 2011-04-24 12:16:50 --> No URI present. Default controller set.
DEBUG - 2011-04-24 12:16:50 --> Output Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Input Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 12:16:50 --> Language Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Loader Class Initialized
DEBUG - 2011-04-24 12:16:50 --> Controller Class Initialized
DEBUG - 2011-04-24 12:16:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 12:16:50 --> Helper loaded: url_helper
DEBUG - 2011-04-24 12:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 12:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 12:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 12:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 12:16:50 --> Final output sent to browser
DEBUG - 2011-04-24 12:16:50 --> Total execution time: 0.2325
DEBUG - 2011-04-24 12:18:48 --> Config Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:18:48 --> URI Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Router Class Initialized
DEBUG - 2011-04-24 12:18:48 --> No URI present. Default controller set.
DEBUG - 2011-04-24 12:18:48 --> Output Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Input Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 12:18:48 --> Language Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Loader Class Initialized
DEBUG - 2011-04-24 12:18:48 --> Controller Class Initialized
DEBUG - 2011-04-24 12:18:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 12:18:48 --> Helper loaded: url_helper
DEBUG - 2011-04-24 12:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 12:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 12:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 12:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 12:18:48 --> Final output sent to browser
DEBUG - 2011-04-24 12:18:48 --> Total execution time: 0.0155
DEBUG - 2011-04-24 12:18:50 --> Config Class Initialized
DEBUG - 2011-04-24 12:18:50 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:18:50 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:18:50 --> URI Class Initialized
DEBUG - 2011-04-24 12:18:50 --> Router Class Initialized
ERROR - 2011-04-24 12:18:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 12:29:00 --> Config Class Initialized
DEBUG - 2011-04-24 12:29:00 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:29:00 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:29:00 --> URI Class Initialized
DEBUG - 2011-04-24 12:29:00 --> Router Class Initialized
ERROR - 2011-04-24 12:29:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 12:29:04 --> Config Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:29:04 --> URI Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Router Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Output Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Input Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 12:29:04 --> Language Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Loader Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Controller Class Initialized
ERROR - 2011-04-24 12:29:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 12:29:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 12:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 12:29:04 --> Model Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Model Class Initialized
DEBUG - 2011-04-24 12:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 12:29:04 --> Database Driver Class Initialized
DEBUG - 2011-04-24 12:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 12:29:04 --> Helper loaded: url_helper
DEBUG - 2011-04-24 12:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 12:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 12:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 12:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 12:29:04 --> Final output sent to browser
DEBUG - 2011-04-24 12:29:04 --> Total execution time: 0.2023
DEBUG - 2011-04-24 12:31:15 --> Config Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:31:15 --> URI Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Router Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Output Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Input Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 12:31:15 --> Language Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Loader Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Controller Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Model Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Model Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Model Class Initialized
DEBUG - 2011-04-24 12:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 12:31:15 --> Database Driver Class Initialized
DEBUG - 2011-04-24 12:31:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 12:31:16 --> Helper loaded: url_helper
DEBUG - 2011-04-24 12:31:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 12:31:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 12:31:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 12:31:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 12:31:16 --> Final output sent to browser
DEBUG - 2011-04-24 12:31:16 --> Total execution time: 0.3704
DEBUG - 2011-04-24 12:45:53 --> Config Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:45:53 --> URI Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Router Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Output Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Input Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 12:45:53 --> Language Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Loader Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Controller Class Initialized
ERROR - 2011-04-24 12:45:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 12:45:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 12:45:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 12:45:53 --> Model Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Model Class Initialized
DEBUG - 2011-04-24 12:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 12:45:53 --> Database Driver Class Initialized
DEBUG - 2011-04-24 12:45:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 12:45:53 --> Helper loaded: url_helper
DEBUG - 2011-04-24 12:45:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 12:45:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 12:45:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 12:45:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 12:45:53 --> Final output sent to browser
DEBUG - 2011-04-24 12:45:53 --> Total execution time: 0.0539
DEBUG - 2011-04-24 12:45:55 --> Config Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:45:55 --> URI Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Router Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Output Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Input Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 12:45:55 --> Language Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Loader Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Controller Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Model Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Model Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 12:45:55 --> Database Driver Class Initialized
DEBUG - 2011-04-24 12:45:55 --> Final output sent to browser
DEBUG - 2011-04-24 12:45:55 --> Total execution time: 0.6607
DEBUG - 2011-04-24 12:45:56 --> Config Class Initialized
DEBUG - 2011-04-24 12:45:56 --> Hooks Class Initialized
DEBUG - 2011-04-24 12:45:56 --> Utf8 Class Initialized
DEBUG - 2011-04-24 12:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 12:45:56 --> URI Class Initialized
DEBUG - 2011-04-24 12:45:56 --> Router Class Initialized
ERROR - 2011-04-24 12:45:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:29:35 --> Config Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:29:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:29:35 --> URI Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Router Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Output Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Input Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:29:35 --> Language Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Loader Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Controller Class Initialized
ERROR - 2011-04-24 13:29:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 13:29:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 13:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:29:35 --> Model Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Model Class Initialized
DEBUG - 2011-04-24 13:29:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:29:35 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:29:35 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:29:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:29:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:29:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:29:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:29:35 --> Final output sent to browser
DEBUG - 2011-04-24 13:29:35 --> Total execution time: 0.2319
DEBUG - 2011-04-24 13:29:36 --> Config Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:29:36 --> URI Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Router Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Output Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Input Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:29:36 --> Language Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Loader Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Controller Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Model Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Model Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:29:36 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:29:36 --> Final output sent to browser
DEBUG - 2011-04-24 13:29:36 --> Total execution time: 0.6388
DEBUG - 2011-04-24 13:29:37 --> Config Class Initialized
DEBUG - 2011-04-24 13:29:37 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:29:37 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:29:37 --> URI Class Initialized
DEBUG - 2011-04-24 13:29:37 --> Router Class Initialized
ERROR - 2011-04-24 13:29:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:29:39 --> Config Class Initialized
DEBUG - 2011-04-24 13:29:39 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:29:39 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:29:39 --> URI Class Initialized
DEBUG - 2011-04-24 13:29:39 --> Router Class Initialized
ERROR - 2011-04-24 13:29:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:38:58 --> Config Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:38:58 --> URI Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Router Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Output Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Input Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:38:58 --> Language Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Loader Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Controller Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Model Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Model Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Model Class Initialized
DEBUG - 2011-04-24 13:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:38:58 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 13:38:59 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:38:59 --> Final output sent to browser
DEBUG - 2011-04-24 13:38:59 --> Total execution time: 0.4178
DEBUG - 2011-04-24 13:39:01 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:01 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Router Class Initialized
ERROR - 2011-04-24 13:39:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:39:01 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:01 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:01 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Controller Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:01 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 13:39:01 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:39:01 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:01 --> Total execution time: 0.0716
DEBUG - 2011-04-24 13:39:19 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:19 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:19 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Controller Class Initialized
ERROR - 2011-04-24 13:39:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 13:39:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 13:39:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:39:19 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:19 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:39:19 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:39:19 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:19 --> Total execution time: 0.0304
DEBUG - 2011-04-24 13:39:20 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:20 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:20 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Controller Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:20 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:21 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:21 --> Total execution time: 0.6464
DEBUG - 2011-04-24 13:39:22 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:22 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:22 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:22 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:22 --> Router Class Initialized
ERROR - 2011-04-24 13:39:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:39:29 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:29 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:29 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Controller Class Initialized
ERROR - 2011-04-24 13:39:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 13:39:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 13:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:39:29 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:29 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:39:29 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:39:29 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:29 --> Total execution time: 0.0279
DEBUG - 2011-04-24 13:39:30 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:30 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:30 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Controller Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:30 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:31 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:31 --> Total execution time: 0.5976
DEBUG - 2011-04-24 13:39:34 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:34 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:34 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:34 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:34 --> Router Class Initialized
ERROR - 2011-04-24 13:39:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:39:47 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:47 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:47 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Controller Class Initialized
ERROR - 2011-04-24 13:39:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 13:39:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 13:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:39:47 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:39:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:39:47 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:47 --> Total execution time: 0.0283
DEBUG - 2011-04-24 13:39:48 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:48 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Router Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Output Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Input Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:39:48 --> Language Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Loader Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Controller Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Model Class Initialized
DEBUG - 2011-04-24 13:39:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:39:48 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:39:49 --> Final output sent to browser
DEBUG - 2011-04-24 13:39:49 --> Total execution time: 0.6562
DEBUG - 2011-04-24 13:39:51 --> Config Class Initialized
DEBUG - 2011-04-24 13:39:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:39:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:39:51 --> URI Class Initialized
DEBUG - 2011-04-24 13:39:51 --> Router Class Initialized
ERROR - 2011-04-24 13:39:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:44:42 --> Config Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:44:42 --> URI Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Router Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Output Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Input Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:44:42 --> Language Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Loader Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Controller Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Model Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Model Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Model Class Initialized
DEBUG - 2011-04-24 13:44:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:44:42 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:44:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 13:44:42 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:44:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:44:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:44:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:44:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:44:42 --> Final output sent to browser
DEBUG - 2011-04-24 13:44:42 --> Total execution time: 0.0497
DEBUG - 2011-04-24 13:44:43 --> Config Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:44:43 --> URI Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Router Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Output Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Input Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:44:43 --> Language Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Loader Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Controller Class Initialized
ERROR - 2011-04-24 13:44:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 13:44:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 13:44:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:44:43 --> Model Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Model Class Initialized
DEBUG - 2011-04-24 13:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:44:43 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:44:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:44:43 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:44:43 --> Final output sent to browser
DEBUG - 2011-04-24 13:44:43 --> Total execution time: 0.0290
DEBUG - 2011-04-24 13:49:54 --> Config Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:49:54 --> URI Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Router Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Output Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Input Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:49:54 --> Language Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Loader Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Controller Class Initialized
ERROR - 2011-04-24 13:49:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 13:49:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 13:49:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:49:54 --> Model Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Model Class Initialized
DEBUG - 2011-04-24 13:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:49:54 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:49:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 13:49:54 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:49:54 --> Final output sent to browser
DEBUG - 2011-04-24 13:49:54 --> Total execution time: 0.0306
DEBUG - 2011-04-24 13:49:55 --> Config Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:49:55 --> URI Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Router Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Output Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Input Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:49:55 --> Language Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Loader Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Controller Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Model Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Model Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:49:55 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:49:55 --> Final output sent to browser
DEBUG - 2011-04-24 13:49:55 --> Total execution time: 0.4996
DEBUG - 2011-04-24 13:49:57 --> Config Class Initialized
DEBUG - 2011-04-24 13:49:57 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:49:57 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:49:57 --> URI Class Initialized
DEBUG - 2011-04-24 13:49:57 --> Router Class Initialized
ERROR - 2011-04-24 13:49:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 13:50:14 --> Config Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:50:14 --> URI Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Router Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Output Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Input Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 13:50:14 --> Language Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Loader Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Controller Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Model Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Model Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Model Class Initialized
DEBUG - 2011-04-24 13:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 13:50:14 --> Database Driver Class Initialized
DEBUG - 2011-04-24 13:50:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 13:50:14 --> Helper loaded: url_helper
DEBUG - 2011-04-24 13:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 13:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 13:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 13:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 13:50:14 --> Final output sent to browser
DEBUG - 2011-04-24 13:50:14 --> Total execution time: 0.2078
DEBUG - 2011-04-24 13:50:16 --> Config Class Initialized
DEBUG - 2011-04-24 13:50:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 13:50:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 13:50:16 --> URI Class Initialized
DEBUG - 2011-04-24 13:50:16 --> Router Class Initialized
ERROR - 2011-04-24 13:50:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 14:25:34 --> Config Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Hooks Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Utf8 Class Initialized
DEBUG - 2011-04-24 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 14:25:34 --> URI Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Router Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Output Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Input Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 14:25:34 --> Language Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Loader Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Controller Class Initialized
ERROR - 2011-04-24 14:25:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 14:25:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 14:25:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 14:25:34 --> Model Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Model Class Initialized
DEBUG - 2011-04-24 14:25:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 14:25:34 --> Database Driver Class Initialized
DEBUG - 2011-04-24 14:25:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 14:25:34 --> Helper loaded: url_helper
DEBUG - 2011-04-24 14:25:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 14:25:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 14:25:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 14:25:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 14:25:34 --> Final output sent to browser
DEBUG - 2011-04-24 14:25:34 --> Total execution time: 0.4069
DEBUG - 2011-04-24 14:25:35 --> Config Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Hooks Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Utf8 Class Initialized
DEBUG - 2011-04-24 14:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 14:25:35 --> URI Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Router Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Output Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Input Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 14:25:35 --> Language Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Loader Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Controller Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Model Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Model Class Initialized
DEBUG - 2011-04-24 14:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 14:25:35 --> Database Driver Class Initialized
DEBUG - 2011-04-24 14:25:36 --> Final output sent to browser
DEBUG - 2011-04-24 14:25:36 --> Total execution time: 0.7879
DEBUG - 2011-04-24 14:25:37 --> Config Class Initialized
DEBUG - 2011-04-24 14:25:37 --> Hooks Class Initialized
DEBUG - 2011-04-24 14:25:37 --> Utf8 Class Initialized
DEBUG - 2011-04-24 14:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 14:25:37 --> URI Class Initialized
DEBUG - 2011-04-24 14:25:37 --> Router Class Initialized
ERROR - 2011-04-24 14:25:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 14:50:42 --> Config Class Initialized
DEBUG - 2011-04-24 14:50:42 --> Hooks Class Initialized
DEBUG - 2011-04-24 14:50:42 --> Utf8 Class Initialized
DEBUG - 2011-04-24 14:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 14:50:42 --> URI Class Initialized
DEBUG - 2011-04-24 14:50:42 --> Router Class Initialized
ERROR - 2011-04-24 14:50:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 14:50:48 --> Config Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Hooks Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Utf8 Class Initialized
DEBUG - 2011-04-24 14:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 14:50:48 --> URI Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Router Class Initialized
DEBUG - 2011-04-24 14:50:48 --> No URI present. Default controller set.
DEBUG - 2011-04-24 14:50:48 --> Output Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Input Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 14:50:48 --> Language Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Loader Class Initialized
DEBUG - 2011-04-24 14:50:48 --> Controller Class Initialized
DEBUG - 2011-04-24 14:50:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-24 14:50:48 --> Helper loaded: url_helper
DEBUG - 2011-04-24 14:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 14:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 14:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 14:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 14:50:48 --> Final output sent to browser
DEBUG - 2011-04-24 14:50:48 --> Total execution time: 0.1068
DEBUG - 2011-04-24 15:42:10 --> Config Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Hooks Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Utf8 Class Initialized
DEBUG - 2011-04-24 15:42:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 15:42:10 --> URI Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Router Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Output Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Input Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 15:42:10 --> Language Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Loader Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Controller Class Initialized
ERROR - 2011-04-24 15:42:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 15:42:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 15:42:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 15:42:10 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 15:42:11 --> Database Driver Class Initialized
DEBUG - 2011-04-24 15:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 15:42:11 --> Helper loaded: url_helper
DEBUG - 2011-04-24 15:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 15:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 15:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 15:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 15:42:11 --> Final output sent to browser
DEBUG - 2011-04-24 15:42:11 --> Total execution time: 0.5543
DEBUG - 2011-04-24 15:42:11 --> Config Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Hooks Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Utf8 Class Initialized
DEBUG - 2011-04-24 15:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 15:42:11 --> URI Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Router Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Output Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Input Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 15:42:11 --> Language Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Loader Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Controller Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 15:42:11 --> Database Driver Class Initialized
DEBUG - 2011-04-24 15:42:12 --> Final output sent to browser
DEBUG - 2011-04-24 15:42:12 --> Total execution time: 0.7541
DEBUG - 2011-04-24 15:42:13 --> Config Class Initialized
DEBUG - 2011-04-24 15:42:13 --> Hooks Class Initialized
DEBUG - 2011-04-24 15:42:13 --> Utf8 Class Initialized
DEBUG - 2011-04-24 15:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 15:42:13 --> URI Class Initialized
DEBUG - 2011-04-24 15:42:13 --> Router Class Initialized
ERROR - 2011-04-24 15:42:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 15:42:14 --> Config Class Initialized
DEBUG - 2011-04-24 15:42:14 --> Hooks Class Initialized
DEBUG - 2011-04-24 15:42:14 --> Utf8 Class Initialized
DEBUG - 2011-04-24 15:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 15:42:14 --> URI Class Initialized
DEBUG - 2011-04-24 15:42:14 --> Router Class Initialized
ERROR - 2011-04-24 15:42:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 15:42:27 --> Config Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Hooks Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Utf8 Class Initialized
DEBUG - 2011-04-24 15:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 15:42:27 --> URI Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Router Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Output Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Input Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 15:42:27 --> Language Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Loader Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Controller Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Model Class Initialized
DEBUG - 2011-04-24 15:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 15:42:27 --> Database Driver Class Initialized
DEBUG - 2011-04-24 15:42:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 15:42:28 --> Helper loaded: url_helper
DEBUG - 2011-04-24 15:42:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 15:42:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 15:42:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 15:42:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 15:42:28 --> Final output sent to browser
DEBUG - 2011-04-24 15:42:28 --> Total execution time: 0.2591
DEBUG - 2011-04-24 16:25:40 --> Config Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Hooks Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Utf8 Class Initialized
DEBUG - 2011-04-24 16:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 16:25:40 --> URI Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Router Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Output Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Input Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 16:25:40 --> Language Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Loader Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Controller Class Initialized
ERROR - 2011-04-24 16:25:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 16:25:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 16:25:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 16:25:40 --> Model Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Model Class Initialized
DEBUG - 2011-04-24 16:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 16:25:40 --> Database Driver Class Initialized
DEBUG - 2011-04-24 16:25:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 16:25:40 --> Helper loaded: url_helper
DEBUG - 2011-04-24 16:25:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 16:25:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 16:25:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 16:25:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 16:25:40 --> Final output sent to browser
DEBUG - 2011-04-24 16:25:40 --> Total execution time: 0.3320
DEBUG - 2011-04-24 16:25:41 --> Config Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 16:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 16:25:41 --> URI Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Router Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Output Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Input Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 16:25:41 --> Language Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Loader Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Controller Class Initialized
DEBUG - 2011-04-24 16:25:41 --> Model Class Initialized
DEBUG - 2011-04-24 16:25:42 --> Model Class Initialized
DEBUG - 2011-04-24 16:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 16:25:42 --> Database Driver Class Initialized
DEBUG - 2011-04-24 16:25:42 --> Final output sent to browser
DEBUG - 2011-04-24 16:25:42 --> Total execution time: 0.9089
DEBUG - 2011-04-24 16:43:38 --> Config Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Hooks Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Utf8 Class Initialized
DEBUG - 2011-04-24 16:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 16:43:38 --> URI Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Router Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Output Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Input Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 16:43:38 --> Language Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Loader Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Controller Class Initialized
ERROR - 2011-04-24 16:43:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 16:43:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 16:43:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 16:43:38 --> Model Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Model Class Initialized
DEBUG - 2011-04-24 16:43:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 16:43:38 --> Database Driver Class Initialized
DEBUG - 2011-04-24 16:43:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 16:43:39 --> Helper loaded: url_helper
DEBUG - 2011-04-24 16:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 16:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 16:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 16:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 16:43:39 --> Final output sent to browser
DEBUG - 2011-04-24 16:43:39 --> Total execution time: 0.9847
DEBUG - 2011-04-24 16:43:39 --> Config Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Hooks Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Utf8 Class Initialized
DEBUG - 2011-04-24 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 16:43:39 --> URI Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Router Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Output Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Input Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 16:43:39 --> Language Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Loader Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Controller Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Model Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Model Class Initialized
DEBUG - 2011-04-24 16:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 16:43:39 --> Database Driver Class Initialized
DEBUG - 2011-04-24 16:43:40 --> Final output sent to browser
DEBUG - 2011-04-24 16:43:40 --> Total execution time: 0.5628
DEBUG - 2011-04-24 16:43:41 --> Config Class Initialized
DEBUG - 2011-04-24 16:43:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 16:43:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 16:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 16:43:41 --> URI Class Initialized
DEBUG - 2011-04-24 16:43:41 --> Router Class Initialized
ERROR - 2011-04-24 16:43:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 16:43:42 --> Config Class Initialized
DEBUG - 2011-04-24 16:43:42 --> Hooks Class Initialized
DEBUG - 2011-04-24 16:43:42 --> Utf8 Class Initialized
DEBUG - 2011-04-24 16:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 16:43:42 --> URI Class Initialized
DEBUG - 2011-04-24 16:43:42 --> Router Class Initialized
ERROR - 2011-04-24 16:43:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 17:06:12 --> Config Class Initialized
DEBUG - 2011-04-24 17:06:12 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:06:12 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:06:12 --> URI Class Initialized
DEBUG - 2011-04-24 17:06:12 --> Router Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Output Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Input Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:06:13 --> Language Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Loader Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Controller Class Initialized
ERROR - 2011-04-24 17:06:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 17:06:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 17:06:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:06:13 --> Model Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Model Class Initialized
DEBUG - 2011-04-24 17:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:06:13 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:06:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:06:13 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:06:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:06:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:06:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:06:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:06:13 --> Final output sent to browser
DEBUG - 2011-04-24 17:06:13 --> Total execution time: 0.2923
DEBUG - 2011-04-24 17:06:14 --> Config Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:06:14 --> URI Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Router Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Output Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Input Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:06:14 --> Language Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Loader Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Controller Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Model Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Model Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:06:14 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:06:14 --> Final output sent to browser
DEBUG - 2011-04-24 17:06:14 --> Total execution time: 0.6428
DEBUG - 2011-04-24 17:31:03 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:03 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:03 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Controller Class Initialized
ERROR - 2011-04-24 17:31:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 17:31:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 17:31:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:03 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:03 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:03 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:31:03 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:03 --> Total execution time: 0.2410
DEBUG - 2011-04-24 17:31:05 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:05 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:05 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Controller Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:05 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:05 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:05 --> Total execution time: 0.6635
DEBUG - 2011-04-24 17:31:09 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:09 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:09 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:09 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:09 --> Router Class Initialized
ERROR - 2011-04-24 17:31:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 17:31:12 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:12 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:12 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:12 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:12 --> Router Class Initialized
ERROR - 2011-04-24 17:31:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 17:31:30 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:30 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:30 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:31 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:31 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Controller Class Initialized
ERROR - 2011-04-24 17:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 17:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 17:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:31 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:31 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:31 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:31:31 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:31 --> Total execution time: 0.0347
DEBUG - 2011-04-24 17:31:31 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:31 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:31 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Controller Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:31 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:32 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Router Class Initialized
ERROR - 2011-04-24 17:31:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 17:31:32 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:32 --> Total execution time: 0.5866
DEBUG - 2011-04-24 17:31:32 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:32 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:32 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Controller Class Initialized
ERROR - 2011-04-24 17:31:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 17:31:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 17:31:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:32 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:32 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:32 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:31:32 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:32 --> Total execution time: 0.0276
DEBUG - 2011-04-24 17:31:41 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:41 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:41 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Controller Class Initialized
ERROR - 2011-04-24 17:31:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 17:31:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 17:31:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:41 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:41 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:31:41 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:31:41 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:41 --> Total execution time: 0.0459
DEBUG - 2011-04-24 17:31:41 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:41 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:41 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Controller Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:41 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:42 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:42 --> Total execution time: 0.5807
DEBUG - 2011-04-24 17:31:55 --> Config Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:31:55 --> URI Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Router Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Output Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Input Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:31:55 --> Language Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Loader Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Controller Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Model Class Initialized
DEBUG - 2011-04-24 17:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:31:55 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:31:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:31:56 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:31:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:31:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:31:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:31:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:31:56 --> Final output sent to browser
DEBUG - 2011-04-24 17:31:56 --> Total execution time: 0.2535
DEBUG - 2011-04-24 17:32:09 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:09 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:09 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:09 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:09 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:09 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:09 --> Total execution time: 0.2475
DEBUG - 2011-04-24 17:32:14 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:14 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:14 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:14 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:14 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:14 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:14 --> Total execution time: 0.0454
DEBUG - 2011-04-24 17:32:20 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:20 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:20 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:20 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:20 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:20 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:20 --> Total execution time: 0.3091
DEBUG - 2011-04-24 17:32:22 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:22 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:22 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:22 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:22 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:22 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:22 --> Total execution time: 0.0457
DEBUG - 2011-04-24 17:32:43 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:43 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:43 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:43 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:43 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:43 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:43 --> Total execution time: 0.2155
DEBUG - 2011-04-24 17:32:44 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:44 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:44 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:44 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:44 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:44 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:44 --> Total execution time: 0.0491
DEBUG - 2011-04-24 17:32:47 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:47 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:47 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:47 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:47 --> Total execution time: 0.0555
DEBUG - 2011-04-24 17:32:50 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:50 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:50 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:50 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:50 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:50 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:50 --> Total execution time: 0.1936
DEBUG - 2011-04-24 17:32:56 --> Config Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:32:56 --> URI Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Router Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Output Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Input Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:32:56 --> Language Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Loader Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Controller Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Model Class Initialized
DEBUG - 2011-04-24 17:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:32:56 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:32:56 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:32:56 --> Final output sent to browser
DEBUG - 2011-04-24 17:32:56 --> Total execution time: 0.0483
DEBUG - 2011-04-24 17:33:10 --> Config Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:33:10 --> URI Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Router Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Output Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Input Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:33:10 --> Language Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Loader Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Controller Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:33:10 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:33:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:33:10 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:33:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:33:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:33:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:33:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:33:10 --> Final output sent to browser
DEBUG - 2011-04-24 17:33:10 --> Total execution time: 0.2566
DEBUG - 2011-04-24 17:33:12 --> Config Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:33:12 --> URI Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Router Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Output Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Input Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:33:12 --> Language Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Loader Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Controller Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:33:12 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:33:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:33:12 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:33:12 --> Final output sent to browser
DEBUG - 2011-04-24 17:33:12 --> Total execution time: 0.0530
DEBUG - 2011-04-24 17:33:13 --> Config Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:33:13 --> URI Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Router Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Output Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Input Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:33:13 --> Language Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Loader Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Controller Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:33:13 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:33:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:33:13 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:33:13 --> Final output sent to browser
DEBUG - 2011-04-24 17:33:13 --> Total execution time: 0.1454
DEBUG - 2011-04-24 17:33:52 --> Config Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:33:52 --> URI Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Router Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Output Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Input Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:33:52 --> Language Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Loader Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Controller Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:33:52 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:33:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:33:52 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:33:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:33:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:33:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:33:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:33:52 --> Final output sent to browser
DEBUG - 2011-04-24 17:33:52 --> Total execution time: 0.2668
DEBUG - 2011-04-24 17:33:54 --> Config Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:33:54 --> URI Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Router Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Output Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Input Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:33:54 --> Language Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Loader Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Controller Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Model Class Initialized
DEBUG - 2011-04-24 17:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:33:54 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:33:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:33:54 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:33:54 --> Final output sent to browser
DEBUG - 2011-04-24 17:33:54 --> Total execution time: 0.0447
DEBUG - 2011-04-24 17:34:07 --> Config Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:34:07 --> URI Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Router Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Output Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Input Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:34:07 --> Language Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Loader Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Controller Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:34:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:34:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:34:07 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:34:07 --> Final output sent to browser
DEBUG - 2011-04-24 17:34:07 --> Total execution time: 0.1981
DEBUG - 2011-04-24 17:34:11 --> Config Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:34:11 --> URI Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Router Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Output Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Input Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:34:11 --> Language Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Loader Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Controller Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:34:11 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:34:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:34:11 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:34:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:34:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:34:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:34:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:34:11 --> Final output sent to browser
DEBUG - 2011-04-24 17:34:11 --> Total execution time: 0.0464
DEBUG - 2011-04-24 17:34:22 --> Config Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:34:22 --> URI Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Router Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Output Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Input Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:34:22 --> Language Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Loader Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Controller Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:34:22 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:34:22 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:34:22 --> Final output sent to browser
DEBUG - 2011-04-24 17:34:22 --> Total execution time: 0.3140
DEBUG - 2011-04-24 17:34:24 --> Config Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:34:24 --> URI Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Router Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Output Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Input Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:34:24 --> Language Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Loader Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Controller Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:34:24 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:34:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:34:24 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:34:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:34:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:34:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:34:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:34:24 --> Final output sent to browser
DEBUG - 2011-04-24 17:34:24 --> Total execution time: 0.0511
DEBUG - 2011-04-24 17:34:50 --> Config Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:34:50 --> URI Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Router Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Output Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Input Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:34:50 --> Language Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Loader Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Controller Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:34:50 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:34:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:34:50 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:34:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:34:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:34:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:34:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:34:50 --> Final output sent to browser
DEBUG - 2011-04-24 17:34:50 --> Total execution time: 0.3770
DEBUG - 2011-04-24 17:34:55 --> Config Class Initialized
DEBUG - 2011-04-24 17:34:55 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:34:55 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:34:56 --> URI Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Router Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Output Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Input Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:34:56 --> Language Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Loader Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Controller Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Model Class Initialized
DEBUG - 2011-04-24 17:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:34:56 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:34:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:34:56 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:34:56 --> Final output sent to browser
DEBUG - 2011-04-24 17:34:56 --> Total execution time: 0.0677
DEBUG - 2011-04-24 17:39:34 --> Config Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:39:34 --> URI Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Router Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Output Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Input Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:39:34 --> Language Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Loader Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Controller Class Initialized
ERROR - 2011-04-24 17:39:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 17:39:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 17:39:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:39:34 --> Model Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Model Class Initialized
DEBUG - 2011-04-24 17:39:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:39:34 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:39:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 17:39:34 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:39:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:39:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:39:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:39:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:39:34 --> Final output sent to browser
DEBUG - 2011-04-24 17:39:34 --> Total execution time: 0.0273
DEBUG - 2011-04-24 17:41:53 --> Config Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:41:53 --> URI Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Router Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Output Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Input Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:41:53 --> Language Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Loader Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Controller Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2011-04-24 17:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:41:53 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:41:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:41:53 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:41:53 --> Final output sent to browser
DEBUG - 2011-04-24 17:41:53 --> Total execution time: 0.0552
DEBUG - 2011-04-24 17:49:04 --> Config Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:49:04 --> URI Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Router Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Output Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Input Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:49:04 --> Language Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Loader Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Controller Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Model Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Model Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Model Class Initialized
DEBUG - 2011-04-24 17:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:49:04 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:49:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:49:06 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:49:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:49:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:49:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:49:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:49:06 --> Final output sent to browser
DEBUG - 2011-04-24 17:49:06 --> Total execution time: 1.7663
DEBUG - 2011-04-24 17:49:07 --> Config Class Initialized
DEBUG - 2011-04-24 17:49:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:49:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:49:07 --> URI Class Initialized
DEBUG - 2011-04-24 17:49:07 --> Router Class Initialized
ERROR - 2011-04-24 17:49:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 17:49:16 --> Config Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:49:16 --> Config Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:49:16 --> URI Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:49:16 --> Router Class Initialized
DEBUG - 2011-04-24 17:49:16 --> URI Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Router Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Output Class Initialized
ERROR - 2011-04-24 17:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 17:49:16 --> Input Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 17:49:16 --> Language Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Loader Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Controller Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Model Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Model Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Model Class Initialized
DEBUG - 2011-04-24 17:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 17:49:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 17:49:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 17:49:16 --> Helper loaded: url_helper
DEBUG - 2011-04-24 17:49:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 17:49:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 17:49:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 17:49:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 17:49:16 --> Final output sent to browser
DEBUG - 2011-04-24 17:49:16 --> Total execution time: 0.0444
DEBUG - 2011-04-24 17:49:17 --> Config Class Initialized
DEBUG - 2011-04-24 17:49:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 17:49:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 17:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 17:49:17 --> URI Class Initialized
DEBUG - 2011-04-24 17:49:17 --> Router Class Initialized
ERROR - 2011-04-24 17:49:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 18:11:46 --> Config Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 18:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 18:11:46 --> URI Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Router Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Output Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Input Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 18:11:46 --> Language Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Loader Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Controller Class Initialized
DEBUG - 2011-04-24 18:11:46 --> Model Class Initialized
DEBUG - 2011-04-24 18:11:47 --> Model Class Initialized
DEBUG - 2011-04-24 18:11:47 --> Model Class Initialized
DEBUG - 2011-04-24 18:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 18:11:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 18:11:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 18:11:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 18:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 18:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 18:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 18:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 18:11:47 --> Final output sent to browser
DEBUG - 2011-04-24 18:11:47 --> Total execution time: 0.5017
DEBUG - 2011-04-24 19:47:13 --> Config Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Hooks Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Utf8 Class Initialized
DEBUG - 2011-04-24 19:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 19:47:13 --> URI Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Router Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Output Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Input Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 19:47:13 --> Language Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Loader Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Controller Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Model Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Model Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Model Class Initialized
DEBUG - 2011-04-24 19:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 19:47:13 --> Database Driver Class Initialized
DEBUG - 2011-04-24 19:47:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 19:47:14 --> Helper loaded: url_helper
DEBUG - 2011-04-24 19:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 19:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 19:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 19:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 19:47:14 --> Final output sent to browser
DEBUG - 2011-04-24 19:47:14 --> Total execution time: 0.6665
DEBUG - 2011-04-24 19:47:15 --> Config Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Hooks Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Utf8 Class Initialized
DEBUG - 2011-04-24 19:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 19:47:15 --> URI Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Router Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Output Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Input Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 19:47:15 --> Language Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Loader Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Controller Class Initialized
ERROR - 2011-04-24 19:47:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 19:47:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 19:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 19:47:15 --> Model Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Model Class Initialized
DEBUG - 2011-04-24 19:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 19:47:15 --> Database Driver Class Initialized
DEBUG - 2011-04-24 19:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 19:47:15 --> Helper loaded: url_helper
DEBUG - 2011-04-24 19:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 19:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 19:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 19:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 19:47:15 --> Final output sent to browser
DEBUG - 2011-04-24 19:47:15 --> Total execution time: 0.1130
DEBUG - 2011-04-24 20:22:51 --> Config Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:22:51 --> URI Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Router Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Output Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Input Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 20:22:51 --> Language Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Loader Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Controller Class Initialized
ERROR - 2011-04-24 20:22:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 20:22:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 20:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 20:22:51 --> Model Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Model Class Initialized
DEBUG - 2011-04-24 20:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 20:22:51 --> Database Driver Class Initialized
DEBUG - 2011-04-24 20:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 20:22:52 --> Helper loaded: url_helper
DEBUG - 2011-04-24 20:22:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 20:22:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 20:22:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 20:22:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 20:22:52 --> Final output sent to browser
DEBUG - 2011-04-24 20:22:52 --> Total execution time: 0.6137
DEBUG - 2011-04-24 20:22:52 --> Config Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:22:52 --> URI Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Router Class Initialized
ERROR - 2011-04-24 20:22:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 20:22:52 --> Config Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:22:52 --> URI Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Router Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Output Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Input Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 20:22:52 --> Language Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Loader Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Controller Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Model Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Model Class Initialized
DEBUG - 2011-04-24 20:22:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 20:22:52 --> Database Driver Class Initialized
DEBUG - 2011-04-24 20:22:53 --> Final output sent to browser
DEBUG - 2011-04-24 20:22:53 --> Total execution time: 0.6584
DEBUG - 2011-04-24 20:31:12 --> Config Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:31:12 --> URI Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Router Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Output Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Input Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 20:31:12 --> Language Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Loader Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Controller Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Model Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Model Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Model Class Initialized
DEBUG - 2011-04-24 20:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 20:31:12 --> Database Driver Class Initialized
DEBUG - 2011-04-24 20:31:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 20:31:13 --> Helper loaded: url_helper
DEBUG - 2011-04-24 20:31:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 20:31:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 20:31:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 20:31:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 20:31:13 --> Final output sent to browser
DEBUG - 2011-04-24 20:31:13 --> Total execution time: 0.3127
DEBUG - 2011-04-24 20:31:46 --> Config Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:31:46 --> URI Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Router Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Output Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Input Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 20:31:46 --> Language Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Loader Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Controller Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Model Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Model Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Model Class Initialized
DEBUG - 2011-04-24 20:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 20:31:46 --> Database Driver Class Initialized
DEBUG - 2011-04-24 20:31:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 20:31:46 --> Helper loaded: url_helper
DEBUG - 2011-04-24 20:31:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 20:31:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 20:31:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 20:31:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 20:31:46 --> Final output sent to browser
DEBUG - 2011-04-24 20:31:46 --> Total execution time: 0.0871
DEBUG - 2011-04-24 20:31:51 --> Config Class Initialized
DEBUG - 2011-04-24 20:31:51 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:31:51 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:31:51 --> URI Class Initialized
DEBUG - 2011-04-24 20:31:51 --> Router Class Initialized
ERROR - 2011-04-24 20:31:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 20:31:53 --> Config Class Initialized
DEBUG - 2011-04-24 20:31:53 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:31:53 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:31:53 --> URI Class Initialized
DEBUG - 2011-04-24 20:31:53 --> Router Class Initialized
ERROR - 2011-04-24 20:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 20:32:04 --> Config Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:32:04 --> URI Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Router Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Output Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Input Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 20:32:04 --> Language Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Loader Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Controller Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Model Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Model Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Model Class Initialized
DEBUG - 2011-04-24 20:32:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 20:32:04 --> Database Driver Class Initialized
DEBUG - 2011-04-24 20:32:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 20:32:04 --> Helper loaded: url_helper
DEBUG - 2011-04-24 20:32:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 20:32:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 20:32:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 20:32:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 20:32:04 --> Final output sent to browser
DEBUG - 2011-04-24 20:32:04 --> Total execution time: 0.0683
DEBUG - 2011-04-24 20:32:06 --> Config Class Initialized
DEBUG - 2011-04-24 20:32:06 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:32:06 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:32:06 --> URI Class Initialized
DEBUG - 2011-04-24 20:32:06 --> Router Class Initialized
ERROR - 2011-04-24 20:32:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 20:32:18 --> Config Class Initialized
DEBUG - 2011-04-24 20:32:18 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:32:18 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:32:18 --> URI Class Initialized
DEBUG - 2011-04-24 20:32:18 --> Router Class Initialized
ERROR - 2011-04-24 20:32:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 20:32:21 --> Config Class Initialized
DEBUG - 2011-04-24 20:32:21 --> Hooks Class Initialized
DEBUG - 2011-04-24 20:32:21 --> Utf8 Class Initialized
DEBUG - 2011-04-24 20:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 20:32:21 --> URI Class Initialized
DEBUG - 2011-04-24 20:32:21 --> Router Class Initialized
ERROR - 2011-04-24 20:32:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 21:13:01 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:01 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Router Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Output Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Input Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 21:13:01 --> Language Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Loader Class Initialized
DEBUG - 2011-04-24 21:13:01 --> Controller Class Initialized
ERROR - 2011-04-24 21:13:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 21:13:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 21:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:13:02 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 21:13:02 --> Database Driver Class Initialized
DEBUG - 2011-04-24 21:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:13:02 --> Helper loaded: url_helper
DEBUG - 2011-04-24 21:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 21:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 21:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 21:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 21:13:02 --> Final output sent to browser
DEBUG - 2011-04-24 21:13:02 --> Total execution time: 0.3531
DEBUG - 2011-04-24 21:13:02 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:02 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Router Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Output Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Input Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 21:13:02 --> Language Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Loader Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Controller Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 21:13:02 --> Database Driver Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:03 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Router Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Output Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Input Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 21:13:03 --> Language Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Loader Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Controller Class Initialized
ERROR - 2011-04-24 21:13:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 21:13:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 21:13:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:13:03 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 21:13:03 --> Database Driver Class Initialized
DEBUG - 2011-04-24 21:13:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:13:03 --> Helper loaded: url_helper
DEBUG - 2011-04-24 21:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 21:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 21:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 21:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 21:13:03 --> Final output sent to browser
DEBUG - 2011-04-24 21:13:03 --> Total execution time: 0.0502
DEBUG - 2011-04-24 21:13:03 --> Final output sent to browser
DEBUG - 2011-04-24 21:13:03 --> Total execution time: 0.7746
DEBUG - 2011-04-24 21:13:04 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:04 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:04 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:04 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:04 --> Router Class Initialized
ERROR - 2011-04-24 21:13:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 21:13:15 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:15 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Router Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Output Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Input Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 21:13:15 --> Language Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Loader Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Controller Class Initialized
ERROR - 2011-04-24 21:13:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 21:13:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 21:13:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:13:15 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 21:13:15 --> Database Driver Class Initialized
DEBUG - 2011-04-24 21:13:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:13:15 --> Helper loaded: url_helper
DEBUG - 2011-04-24 21:13:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 21:13:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 21:13:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 21:13:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 21:13:15 --> Final output sent to browser
DEBUG - 2011-04-24 21:13:15 --> Total execution time: 0.0270
DEBUG - 2011-04-24 21:13:16 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:16 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Router Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Output Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Input Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 21:13:16 --> Language Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Loader Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Controller Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Model Class Initialized
DEBUG - 2011-04-24 21:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 21:13:16 --> Database Driver Class Initialized
DEBUG - 2011-04-24 21:13:17 --> Final output sent to browser
DEBUG - 2011-04-24 21:13:17 --> Total execution time: 0.5818
DEBUG - 2011-04-24 21:13:17 --> Config Class Initialized
DEBUG - 2011-04-24 21:13:17 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:13:17 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:13:17 --> URI Class Initialized
DEBUG - 2011-04-24 21:13:17 --> Router Class Initialized
ERROR - 2011-04-24 21:13:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-24 21:51:46 --> Config Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:51:46 --> URI Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Router Class Initialized
ERROR - 2011-04-24 21:51:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-24 21:51:46 --> Config Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Hooks Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Utf8 Class Initialized
DEBUG - 2011-04-24 21:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 21:51:46 --> URI Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Router Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Output Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Input Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 21:51:46 --> Language Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Loader Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Controller Class Initialized
ERROR - 2011-04-24 21:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 21:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 21:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:51:46 --> Model Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Model Class Initialized
DEBUG - 2011-04-24 21:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 21:51:47 --> Database Driver Class Initialized
DEBUG - 2011-04-24 21:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 21:51:47 --> Helper loaded: url_helper
DEBUG - 2011-04-24 21:51:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 21:51:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 21:51:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 21:51:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 21:51:47 --> Final output sent to browser
DEBUG - 2011-04-24 21:51:47 --> Total execution time: 0.3387
DEBUG - 2011-04-24 22:25:02 --> Config Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Hooks Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Utf8 Class Initialized
DEBUG - 2011-04-24 22:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 22:25:02 --> URI Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Router Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Output Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Input Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 22:25:02 --> Language Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Loader Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Controller Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Model Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Model Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Model Class Initialized
DEBUG - 2011-04-24 22:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 22:25:03 --> Database Driver Class Initialized
DEBUG - 2011-04-24 22:25:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-24 22:25:03 --> Helper loaded: url_helper
DEBUG - 2011-04-24 22:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 22:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 22:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 22:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 22:25:03 --> Final output sent to browser
DEBUG - 2011-04-24 22:25:03 --> Total execution time: 0.7911
DEBUG - 2011-04-24 22:25:07 --> Config Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 22:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 22:25:07 --> URI Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Router Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Output Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Input Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 22:25:07 --> Language Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Loader Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Controller Class Initialized
ERROR - 2011-04-24 22:25:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 22:25:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 22:25:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 22:25:07 --> Model Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Model Class Initialized
DEBUG - 2011-04-24 22:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 22:25:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 22:25:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 22:25:07 --> Helper loaded: url_helper
DEBUG - 2011-04-24 22:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 22:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 22:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 22:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 22:25:07 --> Final output sent to browser
DEBUG - 2011-04-24 22:25:07 --> Total execution time: 0.2444
DEBUG - 2011-04-24 22:56:01 --> Config Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Hooks Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Utf8 Class Initialized
DEBUG - 2011-04-24 22:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 22:56:01 --> URI Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Router Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Output Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Input Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 22:56:01 --> Language Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Loader Class Initialized
DEBUG - 2011-04-24 22:56:01 --> Controller Class Initialized
ERROR - 2011-04-24 22:56:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-24 22:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-24 22:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 22:56:01 --> Model Class Initialized
DEBUG - 2011-04-24 22:56:02 --> Model Class Initialized
DEBUG - 2011-04-24 22:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 22:56:02 --> Database Driver Class Initialized
DEBUG - 2011-04-24 22:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-24 22:56:03 --> Helper loaded: url_helper
DEBUG - 2011-04-24 22:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-24 22:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-24 22:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-24 22:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-24 22:56:03 --> Final output sent to browser
DEBUG - 2011-04-24 22:56:03 --> Total execution time: 2.9558
DEBUG - 2011-04-24 22:56:07 --> Config Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Hooks Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Utf8 Class Initialized
DEBUG - 2011-04-24 22:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 22:56:07 --> URI Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Router Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Output Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Input Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-24 22:56:07 --> Language Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Loader Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Controller Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Model Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Model Class Initialized
DEBUG - 2011-04-24 22:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-24 22:56:07 --> Database Driver Class Initialized
DEBUG - 2011-04-24 22:56:08 --> Final output sent to browser
DEBUG - 2011-04-24 22:56:08 --> Total execution time: 0.9989
DEBUG - 2011-04-24 22:56:12 --> Config Class Initialized
DEBUG - 2011-04-24 22:56:12 --> Hooks Class Initialized
DEBUG - 2011-04-24 22:56:12 --> Utf8 Class Initialized
DEBUG - 2011-04-24 22:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-24 22:56:12 --> URI Class Initialized
DEBUG - 2011-04-24 22:56:12 --> Router Class Initialized
ERROR - 2011-04-24 22:56:12 --> 404 Page Not Found --> favicon.ico

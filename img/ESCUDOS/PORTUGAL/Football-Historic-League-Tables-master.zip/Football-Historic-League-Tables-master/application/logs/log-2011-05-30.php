<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-30 01:12:35 --> Config Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Hooks Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Utf8 Class Initialized
DEBUG - 2011-05-30 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 01:12:35 --> URI Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Router Class Initialized
ERROR - 2011-05-30 01:12:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-30 01:12:35 --> Config Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Hooks Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Utf8 Class Initialized
DEBUG - 2011-05-30 01:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 01:12:35 --> URI Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Router Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Output Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Input Class Initialized
DEBUG - 2011-05-30 01:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 01:12:35 --> Language Class Initialized
DEBUG - 2011-05-30 01:12:36 --> Loader Class Initialized
DEBUG - 2011-05-30 01:12:36 --> Controller Class Initialized
DEBUG - 2011-05-30 01:12:36 --> Model Class Initialized
DEBUG - 2011-05-30 01:12:36 --> Model Class Initialized
DEBUG - 2011-05-30 01:12:36 --> Model Class Initialized
DEBUG - 2011-05-30 01:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 01:12:36 --> Database Driver Class Initialized
DEBUG - 2011-05-30 01:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 01:12:36 --> Helper loaded: url_helper
DEBUG - 2011-05-30 01:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 01:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 01:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 01:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 01:12:36 --> Final output sent to browser
DEBUG - 2011-05-30 01:12:36 --> Total execution time: 0.4978
DEBUG - 2011-05-30 01:13:06 --> Config Class Initialized
DEBUG - 2011-05-30 01:13:06 --> Hooks Class Initialized
DEBUG - 2011-05-30 01:13:06 --> Utf8 Class Initialized
DEBUG - 2011-05-30 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 01:13:06 --> URI Class Initialized
DEBUG - 2011-05-30 01:13:06 --> Router Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Output Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Input Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 01:13:07 --> Language Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Loader Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Controller Class Initialized
ERROR - 2011-05-30 01:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 01:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 01:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 01:13:07 --> Model Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Model Class Initialized
DEBUG - 2011-05-30 01:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 01:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-30 01:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 01:13:07 --> Helper loaded: url_helper
DEBUG - 2011-05-30 01:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 01:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 01:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 01:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 01:13:07 --> Final output sent to browser
DEBUG - 2011-05-30 01:13:07 --> Total execution time: 0.8657
DEBUG - 2011-05-30 01:18:08 --> Config Class Initialized
DEBUG - 2011-05-30 01:18:08 --> Hooks Class Initialized
DEBUG - 2011-05-30 01:18:08 --> Utf8 Class Initialized
DEBUG - 2011-05-30 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 01:18:08 --> URI Class Initialized
DEBUG - 2011-05-30 01:18:08 --> Router Class Initialized
ERROR - 2011-05-30 01:18:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-30 01:18:09 --> Config Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Hooks Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Utf8 Class Initialized
DEBUG - 2011-05-30 01:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 01:18:09 --> URI Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Router Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Output Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Input Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 01:18:09 --> Language Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Loader Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Controller Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Model Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Model Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Model Class Initialized
DEBUG - 2011-05-30 01:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 01:18:09 --> Database Driver Class Initialized
DEBUG - 2011-05-30 01:18:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 01:18:09 --> Helper loaded: url_helper
DEBUG - 2011-05-30 01:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 01:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 01:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 01:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 01:18:09 --> Final output sent to browser
DEBUG - 2011-05-30 01:18:09 --> Total execution time: 0.1566
DEBUG - 2011-05-30 01:18:39 --> Config Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Hooks Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Utf8 Class Initialized
DEBUG - 2011-05-30 01:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 01:18:39 --> URI Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Router Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Output Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Input Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 01:18:39 --> Language Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Loader Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Controller Class Initialized
ERROR - 2011-05-30 01:18:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 01:18:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 01:18:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 01:18:39 --> Model Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Model Class Initialized
DEBUG - 2011-05-30 01:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 01:18:39 --> Database Driver Class Initialized
DEBUG - 2011-05-30 01:18:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 01:18:39 --> Helper loaded: url_helper
DEBUG - 2011-05-30 01:18:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 01:18:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 01:18:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 01:18:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 01:18:39 --> Final output sent to browser
DEBUG - 2011-05-30 01:18:39 --> Total execution time: 0.0332
DEBUG - 2011-05-30 03:08:38 --> Config Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Hooks Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Utf8 Class Initialized
DEBUG - 2011-05-30 03:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 03:08:38 --> URI Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Router Class Initialized
DEBUG - 2011-05-30 03:08:38 --> No URI present. Default controller set.
DEBUG - 2011-05-30 03:08:38 --> Output Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Input Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 03:08:38 --> Language Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Loader Class Initialized
DEBUG - 2011-05-30 03:08:38 --> Controller Class Initialized
DEBUG - 2011-05-30 03:08:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-30 03:08:38 --> Helper loaded: url_helper
DEBUG - 2011-05-30 03:08:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 03:08:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 03:08:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 03:08:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 03:08:38 --> Final output sent to browser
DEBUG - 2011-05-30 03:08:38 --> Total execution time: 0.2219
DEBUG - 2011-05-30 03:12:43 --> Config Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Hooks Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Utf8 Class Initialized
DEBUG - 2011-05-30 03:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 03:12:43 --> URI Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Router Class Initialized
DEBUG - 2011-05-30 03:12:43 --> No URI present. Default controller set.
DEBUG - 2011-05-30 03:12:43 --> Output Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Input Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 03:12:43 --> Language Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Loader Class Initialized
DEBUG - 2011-05-30 03:12:43 --> Controller Class Initialized
DEBUG - 2011-05-30 03:12:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-30 03:12:43 --> Helper loaded: url_helper
DEBUG - 2011-05-30 03:12:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 03:12:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 03:12:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 03:12:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 03:12:43 --> Final output sent to browser
DEBUG - 2011-05-30 03:12:43 --> Total execution time: 0.2142
DEBUG - 2011-05-30 03:15:31 --> Config Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Hooks Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Config Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Hooks Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Utf8 Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Utf8 Class Initialized
DEBUG - 2011-05-30 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 03:15:31 --> URI Class Initialized
DEBUG - 2011-05-30 03:15:31 --> URI Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Router Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Router Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Output Class Initialized
DEBUG - 2011-05-30 03:15:31 --> Output Class Initialized
DEBUG - 2011-05-30 03:15:32 --> Input Class Initialized
DEBUG - 2011-05-30 03:15:32 --> Input Class Initialized
DEBUG - 2011-05-30 03:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 03:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 03:15:32 --> Language Class Initialized
DEBUG - 2011-05-30 03:15:32 --> Language Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Loader Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Loader Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Controller Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Controller Class Initialized
ERROR - 2011-05-30 03:15:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 03:15:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 03:15:33 --> File loaded: application/views/snakes/main.php
ERROR - 2011-05-30 03:15:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 03:15:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 03:15:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 03:15:33 --> Model Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Model Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Model Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Model Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 03:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 03:15:33 --> Database Driver Class Initialized
DEBUG - 2011-05-30 03:15:33 --> Database Driver Class Initialized
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 03:15:38 --> Helper loaded: url_helper
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 03:15:38 --> Helper loaded: url_helper
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 03:15:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 03:15:38 --> Final output sent to browser
DEBUG - 2011-05-30 03:15:38 --> Final output sent to browser
DEBUG - 2011-05-30 03:15:38 --> Total execution time: 8.2005
DEBUG - 2011-05-30 03:15:38 --> Total execution time: 8.1920
DEBUG - 2011-05-30 03:15:39 --> Config Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Hooks Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Utf8 Class Initialized
DEBUG - 2011-05-30 03:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 03:15:39 --> URI Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Router Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Output Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Input Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 03:15:39 --> Language Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Loader Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Controller Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Model Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Model Class Initialized
DEBUG - 2011-05-30 03:15:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 03:15:39 --> Database Driver Class Initialized
DEBUG - 2011-05-30 03:15:49 --> Final output sent to browser
DEBUG - 2011-05-30 03:15:49 --> Total execution time: 10.4300
DEBUG - 2011-05-30 03:16:19 --> Config Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Hooks Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Utf8 Class Initialized
DEBUG - 2011-05-30 03:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 03:16:19 --> URI Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Router Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Output Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Input Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 03:16:19 --> Language Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Loader Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Controller Class Initialized
ERROR - 2011-05-30 03:16:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 03:16:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 03:16:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 03:16:19 --> Model Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Model Class Initialized
DEBUG - 2011-05-30 03:16:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 03:16:20 --> Database Driver Class Initialized
DEBUG - 2011-05-30 03:16:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 03:16:20 --> Helper loaded: url_helper
DEBUG - 2011-05-30 03:16:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 03:16:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 03:16:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 03:16:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 03:16:20 --> Final output sent to browser
DEBUG - 2011-05-30 03:16:20 --> Total execution time: 0.0443
DEBUG - 2011-05-30 06:36:09 --> Config Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Hooks Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Utf8 Class Initialized
DEBUG - 2011-05-30 06:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 06:36:09 --> URI Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Router Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Output Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Input Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 06:36:09 --> Language Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Loader Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Controller Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Model Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Model Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Model Class Initialized
DEBUG - 2011-05-30 06:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 06:36:09 --> Database Driver Class Initialized
DEBUG - 2011-05-30 06:36:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 06:36:11 --> Helper loaded: url_helper
DEBUG - 2011-05-30 06:36:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 06:36:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 06:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 06:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 06:36:12 --> Final output sent to browser
DEBUG - 2011-05-30 06:36:12 --> Total execution time: 2.4216
DEBUG - 2011-05-30 06:36:13 --> Config Class Initialized
DEBUG - 2011-05-30 06:36:13 --> Hooks Class Initialized
DEBUG - 2011-05-30 06:36:13 --> Utf8 Class Initialized
DEBUG - 2011-05-30 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 06:36:13 --> URI Class Initialized
DEBUG - 2011-05-30 06:36:13 --> Router Class Initialized
ERROR - 2011-05-30 06:36:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-30 06:56:33 --> Config Class Initialized
DEBUG - 2011-05-30 06:56:33 --> Hooks Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Utf8 Class Initialized
DEBUG - 2011-05-30 06:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 06:56:34 --> URI Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Router Class Initialized
ERROR - 2011-05-30 06:56:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-30 06:56:34 --> Config Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Hooks Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Utf8 Class Initialized
DEBUG - 2011-05-30 06:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 06:56:34 --> URI Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Router Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Output Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Input Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 06:56:34 --> Language Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Loader Class Initialized
DEBUG - 2011-05-30 06:56:34 --> Controller Class Initialized
ERROR - 2011-05-30 06:56:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 06:56:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 06:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 06:56:35 --> Model Class Initialized
DEBUG - 2011-05-30 06:56:35 --> Model Class Initialized
DEBUG - 2011-05-30 06:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 06:56:35 --> Database Driver Class Initialized
DEBUG - 2011-05-30 06:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 06:56:35 --> Helper loaded: url_helper
DEBUG - 2011-05-30 06:56:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 06:56:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 06:56:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 06:56:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 06:56:35 --> Final output sent to browser
DEBUG - 2011-05-30 06:56:35 --> Total execution time: 0.7264
DEBUG - 2011-05-30 06:56:36 --> Config Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Hooks Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Utf8 Class Initialized
DEBUG - 2011-05-30 06:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 06:56:36 --> URI Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Router Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Output Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Input Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 06:56:36 --> Language Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Loader Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Controller Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Model Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Model Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Model Class Initialized
DEBUG - 2011-05-30 06:56:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 06:56:36 --> Database Driver Class Initialized
DEBUG - 2011-05-30 06:56:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 06:56:36 --> Helper loaded: url_helper
DEBUG - 2011-05-30 06:56:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 06:56:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 06:56:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 06:56:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 06:56:36 --> Final output sent to browser
DEBUG - 2011-05-30 06:56:36 --> Total execution time: 0.3988
DEBUG - 2011-05-30 07:08:42 --> Config Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Hooks Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Utf8 Class Initialized
DEBUG - 2011-05-30 07:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 07:08:42 --> URI Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Router Class Initialized
ERROR - 2011-05-30 07:08:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-30 07:08:42 --> Config Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Hooks Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Utf8 Class Initialized
DEBUG - 2011-05-30 07:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 07:08:42 --> URI Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Router Class Initialized
DEBUG - 2011-05-30 07:08:42 --> Output Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Input Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 07:08:43 --> Language Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Loader Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Controller Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Model Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Model Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Model Class Initialized
DEBUG - 2011-05-30 07:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 07:08:43 --> Database Driver Class Initialized
DEBUG - 2011-05-30 07:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 07:08:43 --> Helper loaded: url_helper
DEBUG - 2011-05-30 07:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 07:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 07:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 07:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 07:08:43 --> Final output sent to browser
DEBUG - 2011-05-30 07:08:43 --> Total execution time: 0.4454
DEBUG - 2011-05-30 08:28:05 --> Config Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Hooks Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Utf8 Class Initialized
DEBUG - 2011-05-30 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 08:28:05 --> URI Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Router Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Output Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Input Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 08:28:05 --> Language Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Loader Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Controller Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Model Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Model Class Initialized
DEBUG - 2011-05-30 08:28:05 --> Model Class Initialized
DEBUG - 2011-05-30 08:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 08:28:06 --> Database Driver Class Initialized
DEBUG - 2011-05-30 08:28:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 08:28:06 --> Helper loaded: url_helper
DEBUG - 2011-05-30 08:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 08:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 08:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 08:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 08:28:06 --> Final output sent to browser
DEBUG - 2011-05-30 08:28:06 --> Total execution time: 1.0153
DEBUG - 2011-05-30 08:28:08 --> Config Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Hooks Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Utf8 Class Initialized
DEBUG - 2011-05-30 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 08:28:08 --> URI Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Router Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Output Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Input Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 08:28:08 --> Language Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Loader Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Controller Class Initialized
ERROR - 2011-05-30 08:28:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 08:28:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 08:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 08:28:08 --> Model Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Model Class Initialized
DEBUG - 2011-05-30 08:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 08:28:08 --> Database Driver Class Initialized
DEBUG - 2011-05-30 08:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 08:28:08 --> Helper loaded: url_helper
DEBUG - 2011-05-30 08:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 08:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 08:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 08:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 08:28:08 --> Final output sent to browser
DEBUG - 2011-05-30 08:28:08 --> Total execution time: 0.0987
DEBUG - 2011-05-30 08:31:20 --> Config Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Hooks Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Utf8 Class Initialized
DEBUG - 2011-05-30 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 08:31:20 --> URI Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Router Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Output Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Input Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 08:31:20 --> Language Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Loader Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Controller Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Model Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Model Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Model Class Initialized
DEBUG - 2011-05-30 08:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 08:31:20 --> Database Driver Class Initialized
DEBUG - 2011-05-30 08:31:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 08:31:20 --> Helper loaded: url_helper
DEBUG - 2011-05-30 08:31:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 08:31:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 08:31:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 08:31:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 08:31:20 --> Final output sent to browser
DEBUG - 2011-05-30 08:31:20 --> Total execution time: 0.0464
DEBUG - 2011-05-30 08:31:24 --> Config Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Hooks Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Utf8 Class Initialized
DEBUG - 2011-05-30 08:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 08:31:24 --> URI Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Router Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Output Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Input Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 08:31:24 --> Language Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Loader Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Controller Class Initialized
ERROR - 2011-05-30 08:31:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 08:31:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 08:31:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 08:31:24 --> Model Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Model Class Initialized
DEBUG - 2011-05-30 08:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 08:31:24 --> Database Driver Class Initialized
DEBUG - 2011-05-30 08:31:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 08:31:24 --> Helper loaded: url_helper
DEBUG - 2011-05-30 08:31:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 08:31:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 08:31:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 08:31:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 08:31:24 --> Final output sent to browser
DEBUG - 2011-05-30 08:31:24 --> Total execution time: 0.0283
DEBUG - 2011-05-30 08:59:51 --> Config Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Hooks Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Utf8 Class Initialized
DEBUG - 2011-05-30 08:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 08:59:51 --> URI Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Router Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Output Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Input Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 08:59:51 --> Language Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Loader Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Controller Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Model Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Model Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Model Class Initialized
DEBUG - 2011-05-30 08:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 08:59:51 --> Database Driver Class Initialized
DEBUG - 2011-05-30 08:59:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 08:59:51 --> Helper loaded: url_helper
DEBUG - 2011-05-30 08:59:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 08:59:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 08:59:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 08:59:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 08:59:51 --> Final output sent to browser
DEBUG - 2011-05-30 08:59:51 --> Total execution time: 0.6957
DEBUG - 2011-05-30 11:39:04 --> Config Class Initialized
DEBUG - 2011-05-30 11:39:04 --> Hooks Class Initialized
DEBUG - 2011-05-30 11:39:04 --> Utf8 Class Initialized
DEBUG - 2011-05-30 11:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 11:39:04 --> URI Class Initialized
DEBUG - 2011-05-30 11:39:04 --> Router Class Initialized
DEBUG - 2011-05-30 11:39:05 --> No URI present. Default controller set.
DEBUG - 2011-05-30 11:39:05 --> Output Class Initialized
DEBUG - 2011-05-30 11:39:05 --> Input Class Initialized
DEBUG - 2011-05-30 11:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 11:39:05 --> Language Class Initialized
DEBUG - 2011-05-30 11:39:05 --> Loader Class Initialized
DEBUG - 2011-05-30 11:39:05 --> Controller Class Initialized
DEBUG - 2011-05-30 11:39:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-30 11:39:05 --> Helper loaded: url_helper
DEBUG - 2011-05-30 11:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 11:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 11:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 11:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 11:39:05 --> Final output sent to browser
DEBUG - 2011-05-30 11:39:05 --> Total execution time: 0.2741
DEBUG - 2011-05-30 11:54:34 --> Config Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Hooks Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Utf8 Class Initialized
DEBUG - 2011-05-30 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 11:54:34 --> URI Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Router Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Output Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Input Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 11:54:34 --> Language Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Loader Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Controller Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Model Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Model Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Model Class Initialized
DEBUG - 2011-05-30 11:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 11:54:34 --> Database Driver Class Initialized
DEBUG - 2011-05-30 11:54:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 11:54:35 --> Helper loaded: url_helper
DEBUG - 2011-05-30 11:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 11:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 11:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 11:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 11:54:35 --> Final output sent to browser
DEBUG - 2011-05-30 11:54:35 --> Total execution time: 0.9577
DEBUG - 2011-05-30 13:53:17 --> Config Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Hooks Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Utf8 Class Initialized
DEBUG - 2011-05-30 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 13:53:17 --> URI Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Router Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Output Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Input Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 13:53:17 --> Language Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Loader Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Controller Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Model Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Model Class Initialized
DEBUG - 2011-05-30 13:53:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 13:53:17 --> Database Driver Class Initialized
DEBUG - 2011-05-30 13:53:18 --> Final output sent to browser
DEBUG - 2011-05-30 13:53:18 --> Total execution time: 1.1003
DEBUG - 2011-05-30 15:00:33 --> Config Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Hooks Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Utf8 Class Initialized
DEBUG - 2011-05-30 15:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 15:00:33 --> URI Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Router Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Output Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Input Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 15:00:33 --> Language Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Loader Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Controller Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Model Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Model Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Model Class Initialized
DEBUG - 2011-05-30 15:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 15:00:33 --> Database Driver Class Initialized
DEBUG - 2011-05-30 15:00:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 15:00:34 --> Helper loaded: url_helper
DEBUG - 2011-05-30 15:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 15:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 15:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 15:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 15:00:34 --> Final output sent to browser
DEBUG - 2011-05-30 15:00:34 --> Total execution time: 1.0488
DEBUG - 2011-05-30 15:00:36 --> Config Class Initialized
DEBUG - 2011-05-30 15:00:36 --> Hooks Class Initialized
DEBUG - 2011-05-30 15:00:36 --> Utf8 Class Initialized
DEBUG - 2011-05-30 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 15:00:36 --> URI Class Initialized
DEBUG - 2011-05-30 15:00:36 --> Router Class Initialized
ERROR - 2011-05-30 15:00:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-30 17:59:57 --> Config Class Initialized
DEBUG - 2011-05-30 17:59:57 --> Hooks Class Initialized
DEBUG - 2011-05-30 17:59:57 --> Utf8 Class Initialized
DEBUG - 2011-05-30 17:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 17:59:57 --> URI Class Initialized
DEBUG - 2011-05-30 17:59:57 --> Router Class Initialized
ERROR - 2011-05-30 17:59:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-30 18:02:09 --> Config Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Hooks Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Utf8 Class Initialized
DEBUG - 2011-05-30 18:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 18:02:09 --> URI Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Router Class Initialized
DEBUG - 2011-05-30 18:02:09 --> No URI present. Default controller set.
DEBUG - 2011-05-30 18:02:09 --> Output Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Input Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 18:02:09 --> Language Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Loader Class Initialized
DEBUG - 2011-05-30 18:02:09 --> Controller Class Initialized
DEBUG - 2011-05-30 18:02:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-30 18:02:09 --> Helper loaded: url_helper
DEBUG - 2011-05-30 18:02:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 18:02:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 18:02:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 18:02:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 18:02:09 --> Final output sent to browser
DEBUG - 2011-05-30 18:02:09 --> Total execution time: 0.2573
DEBUG - 2011-05-30 19:17:59 --> Config Class Initialized
DEBUG - 2011-05-30 19:17:59 --> Hooks Class Initialized
DEBUG - 2011-05-30 19:17:59 --> Utf8 Class Initialized
DEBUG - 2011-05-30 19:17:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 19:17:59 --> URI Class Initialized
DEBUG - 2011-05-30 19:17:59 --> Router Class Initialized
ERROR - 2011-05-30 19:17:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-30 19:19:05 --> Config Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Hooks Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Utf8 Class Initialized
DEBUG - 2011-05-30 19:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 19:19:05 --> URI Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Router Class Initialized
DEBUG - 2011-05-30 19:19:05 --> No URI present. Default controller set.
DEBUG - 2011-05-30 19:19:05 --> Output Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Input Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 19:19:05 --> Language Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Loader Class Initialized
DEBUG - 2011-05-30 19:19:05 --> Controller Class Initialized
DEBUG - 2011-05-30 19:19:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-30 19:19:05 --> Helper loaded: url_helper
DEBUG - 2011-05-30 19:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 19:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 19:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 19:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 19:19:05 --> Final output sent to browser
DEBUG - 2011-05-30 19:19:05 --> Total execution time: 0.2359
DEBUG - 2011-05-30 19:55:26 --> Config Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Hooks Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Utf8 Class Initialized
DEBUG - 2011-05-30 19:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 19:55:26 --> URI Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Router Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Output Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Input Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 19:55:26 --> Language Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Loader Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Controller Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Model Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Model Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Model Class Initialized
DEBUG - 2011-05-30 19:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 19:55:26 --> Database Driver Class Initialized
DEBUG - 2011-05-30 19:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 19:55:26 --> Helper loaded: url_helper
DEBUG - 2011-05-30 19:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 19:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 19:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 19:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 19:55:26 --> Final output sent to browser
DEBUG - 2011-05-30 19:55:26 --> Total execution time: 0.5248
DEBUG - 2011-05-30 20:24:41 --> Config Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:24:41 --> URI Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Router Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Output Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Input Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:24:41 --> Language Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Loader Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Controller Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Model Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Model Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Model Class Initialized
DEBUG - 2011-05-30 20:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:24:41 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:24:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 20:24:41 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:24:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:24:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:24:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:24:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:24:41 --> Final output sent to browser
DEBUG - 2011-05-30 20:24:41 --> Total execution time: 0.5496
DEBUG - 2011-05-30 20:24:42 --> Config Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:24:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:24:42 --> URI Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Router Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Output Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Input Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:24:42 --> Language Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Loader Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Controller Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Model Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Model Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Model Class Initialized
DEBUG - 2011-05-30 20:24:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:24:42 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:24:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 20:24:42 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:24:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:24:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:24:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:24:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:24:42 --> Final output sent to browser
DEBUG - 2011-05-30 20:24:42 --> Total execution time: 0.0473
DEBUG - 2011-05-30 20:27:23 --> Config Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:27:23 --> URI Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Router Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Output Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Input Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:27:23 --> Language Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Loader Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Controller Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Model Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Model Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Model Class Initialized
DEBUG - 2011-05-30 20:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:27:23 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:27:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 20:27:23 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:27:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:27:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:27:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:27:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:27:23 --> Final output sent to browser
DEBUG - 2011-05-30 20:27:23 --> Total execution time: 0.0440
DEBUG - 2011-05-30 20:33:12 --> Config Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:33:12 --> URI Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Router Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Output Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Input Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:33:12 --> Language Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Loader Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Controller Class Initialized
ERROR - 2011-05-30 20:33:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 20:33:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 20:33:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 20:33:12 --> Model Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Model Class Initialized
DEBUG - 2011-05-30 20:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:33:12 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:33:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 20:33:12 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:33:12 --> Final output sent to browser
DEBUG - 2011-05-30 20:33:12 --> Total execution time: 0.1073
DEBUG - 2011-05-30 20:33:14 --> Config Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:33:14 --> URI Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Router Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Output Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Input Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:33:14 --> Language Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Loader Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Controller Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Model Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Model Class Initialized
DEBUG - 2011-05-30 20:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:33:14 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:33:15 --> Final output sent to browser
DEBUG - 2011-05-30 20:33:15 --> Total execution time: 0.6016
DEBUG - 2011-05-30 20:33:17 --> Config Class Initialized
DEBUG - 2011-05-30 20:33:17 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:33:17 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:33:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:33:17 --> URI Class Initialized
DEBUG - 2011-05-30 20:33:17 --> Router Class Initialized
ERROR - 2011-05-30 20:33:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-30 20:33:18 --> Config Class Initialized
DEBUG - 2011-05-30 20:33:18 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:33:18 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:33:18 --> URI Class Initialized
DEBUG - 2011-05-30 20:33:18 --> Router Class Initialized
ERROR - 2011-05-30 20:33:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-30 20:44:08 --> Config Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:44:08 --> URI Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Router Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Output Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Input Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:44:08 --> Language Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Loader Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Controller Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Model Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Model Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Model Class Initialized
DEBUG - 2011-05-30 20:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:44:08 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:44:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 20:44:08 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:44:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:44:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:44:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:44:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:44:08 --> Final output sent to browser
DEBUG - 2011-05-30 20:44:08 --> Total execution time: 0.1037
DEBUG - 2011-05-30 20:47:42 --> Config Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:47:42 --> URI Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Router Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Output Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Input Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:47:42 --> Language Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Loader Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Controller Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:47:42 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:47:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-30 20:47:42 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:47:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:47:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:47:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:47:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:47:42 --> Final output sent to browser
DEBUG - 2011-05-30 20:47:42 --> Total execution time: 0.0776
DEBUG - 2011-05-30 20:47:43 --> Config Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:47:43 --> URI Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Router Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Output Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Input Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:47:43 --> Language Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Loader Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Controller Class Initialized
ERROR - 2011-05-30 20:47:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-30 20:47:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-30 20:47:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 20:47:43 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:47:43 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:47:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-30 20:47:43 --> Helper loaded: url_helper
DEBUG - 2011-05-30 20:47:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 20:47:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 20:47:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 20:47:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 20:47:43 --> Final output sent to browser
DEBUG - 2011-05-30 20:47:43 --> Total execution time: 0.0275
DEBUG - 2011-05-30 20:47:44 --> Config Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Hooks Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Utf8 Class Initialized
DEBUG - 2011-05-30 20:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 20:47:44 --> URI Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Router Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Output Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Input Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 20:47:44 --> Language Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Loader Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Controller Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Model Class Initialized
DEBUG - 2011-05-30 20:47:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-30 20:47:44 --> Database Driver Class Initialized
DEBUG - 2011-05-30 20:47:45 --> Final output sent to browser
DEBUG - 2011-05-30 20:47:45 --> Total execution time: 0.6244
DEBUG - 2011-05-30 21:14:41 --> Config Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Hooks Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Utf8 Class Initialized
DEBUG - 2011-05-30 21:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-30 21:14:41 --> URI Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Router Class Initialized
DEBUG - 2011-05-30 21:14:41 --> No URI present. Default controller set.
DEBUG - 2011-05-30 21:14:41 --> Output Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Input Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-30 21:14:41 --> Language Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Loader Class Initialized
DEBUG - 2011-05-30 21:14:41 --> Controller Class Initialized
DEBUG - 2011-05-30 21:14:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-30 21:14:41 --> Helper loaded: url_helper
DEBUG - 2011-05-30 21:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-30 21:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-30 21:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-30 21:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-30 21:14:41 --> Final output sent to browser
DEBUG - 2011-05-30 21:14:41 --> Total execution time: 0.4234

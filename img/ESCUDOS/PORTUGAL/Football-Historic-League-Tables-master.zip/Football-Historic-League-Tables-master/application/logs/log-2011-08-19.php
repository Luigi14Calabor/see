<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-19 00:59:31 --> Config Class Initialized
DEBUG - 2011-08-19 00:59:31 --> Hooks Class Initialized
DEBUG - 2011-08-19 00:59:31 --> Utf8 Class Initialized
DEBUG - 2011-08-19 00:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 00:59:31 --> URI Class Initialized
DEBUG - 2011-08-19 00:59:31 --> Router Class Initialized
ERROR - 2011-08-19 00:59:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 02:11:48 --> Config Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Hooks Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Utf8 Class Initialized
DEBUG - 2011-08-19 02:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 02:11:48 --> URI Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Router Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Output Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Input Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 02:11:48 --> Language Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Loader Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Controller Class Initialized
ERROR - 2011-08-19 02:11:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 02:11:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 02:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 02:11:48 --> Model Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Model Class Initialized
DEBUG - 2011-08-19 02:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 02:11:48 --> Database Driver Class Initialized
DEBUG - 2011-08-19 02:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 02:11:49 --> Helper loaded: url_helper
DEBUG - 2011-08-19 02:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 02:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 02:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 02:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 02:11:49 --> Final output sent to browser
DEBUG - 2011-08-19 02:11:49 --> Total execution time: 1.0507
DEBUG - 2011-08-19 02:11:50 --> Config Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-19 02:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 02:11:50 --> URI Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Router Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Output Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Input Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 02:11:50 --> Language Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Loader Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Controller Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Model Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Model Class Initialized
DEBUG - 2011-08-19 02:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 02:11:50 --> Database Driver Class Initialized
DEBUG - 2011-08-19 02:11:51 --> Final output sent to browser
DEBUG - 2011-08-19 02:11:51 --> Total execution time: 1.2668
DEBUG - 2011-08-19 02:11:53 --> Config Class Initialized
DEBUG - 2011-08-19 02:11:53 --> Hooks Class Initialized
DEBUG - 2011-08-19 02:11:53 --> Utf8 Class Initialized
DEBUG - 2011-08-19 02:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 02:11:53 --> URI Class Initialized
DEBUG - 2011-08-19 02:11:53 --> Router Class Initialized
ERROR - 2011-08-19 02:11:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 02:42:36 --> Config Class Initialized
DEBUG - 2011-08-19 02:42:36 --> Hooks Class Initialized
DEBUG - 2011-08-19 02:42:36 --> Utf8 Class Initialized
DEBUG - 2011-08-19 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 02:42:36 --> URI Class Initialized
DEBUG - 2011-08-19 02:42:36 --> Router Class Initialized
DEBUG - 2011-08-19 02:42:36 --> No URI present. Default controller set.
DEBUG - 2011-08-19 02:42:36 --> Output Class Initialized
DEBUG - 2011-08-19 02:42:36 --> Input Class Initialized
DEBUG - 2011-08-19 02:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 02:42:36 --> Language Class Initialized
DEBUG - 2011-08-19 02:42:36 --> Loader Class Initialized
DEBUG - 2011-08-19 02:42:37 --> Controller Class Initialized
DEBUG - 2011-08-19 02:42:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-19 02:42:37 --> Helper loaded: url_helper
DEBUG - 2011-08-19 02:42:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 02:42:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 02:42:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 02:42:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 02:42:37 --> Final output sent to browser
DEBUG - 2011-08-19 02:42:37 --> Total execution time: 0.3515
DEBUG - 2011-08-19 03:05:09 --> Config Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Hooks Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Utf8 Class Initialized
DEBUG - 2011-08-19 03:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 03:05:09 --> URI Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Router Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Output Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Input Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 03:05:09 --> Language Class Initialized
DEBUG - 2011-08-19 03:05:09 --> Loader Class Initialized
DEBUG - 2011-08-19 03:05:10 --> Controller Class Initialized
DEBUG - 2011-08-19 03:05:10 --> Model Class Initialized
DEBUG - 2011-08-19 03:05:10 --> Model Class Initialized
DEBUG - 2011-08-19 03:05:10 --> Model Class Initialized
DEBUG - 2011-08-19 03:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 03:05:10 --> Database Driver Class Initialized
DEBUG - 2011-08-19 03:05:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 03:05:12 --> Helper loaded: url_helper
DEBUG - 2011-08-19 03:05:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 03:05:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 03:05:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 03:05:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 03:05:12 --> Final output sent to browser
DEBUG - 2011-08-19 03:05:12 --> Total execution time: 2.3219
DEBUG - 2011-08-19 03:05:18 --> Config Class Initialized
DEBUG - 2011-08-19 03:05:18 --> Hooks Class Initialized
DEBUG - 2011-08-19 03:05:18 --> Utf8 Class Initialized
DEBUG - 2011-08-19 03:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 03:05:18 --> URI Class Initialized
DEBUG - 2011-08-19 03:05:18 --> Router Class Initialized
ERROR - 2011-08-19 03:05:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 03:47:55 --> Config Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Hooks Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Utf8 Class Initialized
DEBUG - 2011-08-19 03:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 03:47:55 --> URI Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Router Class Initialized
DEBUG - 2011-08-19 03:47:55 --> No URI present. Default controller set.
DEBUG - 2011-08-19 03:47:55 --> Output Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Input Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 03:47:55 --> Language Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Loader Class Initialized
DEBUG - 2011-08-19 03:47:55 --> Controller Class Initialized
DEBUG - 2011-08-19 03:47:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-19 03:47:55 --> Helper loaded: url_helper
DEBUG - 2011-08-19 03:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 03:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 03:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 03:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 03:47:55 --> Final output sent to browser
DEBUG - 2011-08-19 03:47:55 --> Total execution time: 0.1419
DEBUG - 2011-08-19 03:53:42 --> Config Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Hooks Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Utf8 Class Initialized
DEBUG - 2011-08-19 03:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 03:53:42 --> URI Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Router Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Output Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Input Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 03:53:42 --> Language Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Loader Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Controller Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Config Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Hooks Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Utf8 Class Initialized
DEBUG - 2011-08-19 03:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 03:53:42 --> URI Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Router Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Output Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Input Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 03:53:42 --> Language Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Loader Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Controller Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Model Class Initialized
ERROR - 2011-08-19 03:53:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 03:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 03:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 03:53:42 --> Model Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Model Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Model Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Model Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 03:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 03:53:42 --> Database Driver Class Initialized
DEBUG - 2011-08-19 03:53:42 --> Database Driver Class Initialized
DEBUG - 2011-08-19 03:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 03:53:43 --> Helper loaded: url_helper
DEBUG - 2011-08-19 03:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 03:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 03:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 03:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 03:53:43 --> Final output sent to browser
DEBUG - 2011-08-19 03:53:43 --> Total execution time: 0.7039
DEBUG - 2011-08-19 03:53:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 03:53:45 --> Helper loaded: url_helper
DEBUG - 2011-08-19 03:53:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 03:53:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 03:53:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 03:53:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 03:53:45 --> Final output sent to browser
DEBUG - 2011-08-19 03:53:45 --> Total execution time: 2.2698
DEBUG - 2011-08-19 05:51:33 --> Config Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Hooks Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Utf8 Class Initialized
DEBUG - 2011-08-19 05:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 05:51:33 --> URI Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Router Class Initialized
ERROR - 2011-08-19 05:51:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 05:51:33 --> Config Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Hooks Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Utf8 Class Initialized
DEBUG - 2011-08-19 05:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 05:51:33 --> URI Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Router Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Output Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Input Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 05:51:33 --> Language Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Loader Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Controller Class Initialized
ERROR - 2011-08-19 05:51:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 05:51:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 05:51:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 05:51:33 --> Model Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Model Class Initialized
DEBUG - 2011-08-19 05:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 05:51:33 --> Database Driver Class Initialized
DEBUG - 2011-08-19 05:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 05:51:34 --> Helper loaded: url_helper
DEBUG - 2011-08-19 05:51:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 05:51:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 05:51:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 05:51:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 05:51:34 --> Final output sent to browser
DEBUG - 2011-08-19 05:51:34 --> Total execution time: 0.6032
DEBUG - 2011-08-19 06:21:57 --> Config Class Initialized
DEBUG - 2011-08-19 06:21:57 --> Hooks Class Initialized
DEBUG - 2011-08-19 06:21:57 --> Utf8 Class Initialized
DEBUG - 2011-08-19 06:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 06:21:57 --> URI Class Initialized
DEBUG - 2011-08-19 06:21:57 --> Router Class Initialized
ERROR - 2011-08-19 06:21:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 07:32:37 --> Config Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:32:37 --> URI Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Router Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Output Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Input Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:32:37 --> Language Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Loader Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Controller Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Model Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Model Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Model Class Initialized
DEBUG - 2011-08-19 07:32:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:32:37 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:32:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 07:32:39 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:32:39 --> Final output sent to browser
DEBUG - 2011-08-19 07:32:39 --> Total execution time: 1.6313
DEBUG - 2011-08-19 07:32:40 --> Config Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:32:40 --> URI Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Router Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Output Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Input Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:32:40 --> Language Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Loader Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Controller Class Initialized
ERROR - 2011-08-19 07:32:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:32:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:32:40 --> Model Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Model Class Initialized
DEBUG - 2011-08-19 07:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:32:40 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:32:40 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:32:40 --> Final output sent to browser
DEBUG - 2011-08-19 07:32:40 --> Total execution time: 0.0860
DEBUG - 2011-08-19 07:35:20 --> Config Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:35:20 --> URI Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Router Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Output Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Input Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:35:20 --> Language Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Loader Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Controller Class Initialized
ERROR - 2011-08-19 07:35:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:35:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:35:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:35:20 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:35:20 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:35:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:35:20 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:35:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:35:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:35:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:35:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:35:20 --> Final output sent to browser
DEBUG - 2011-08-19 07:35:20 --> Total execution time: 0.0639
DEBUG - 2011-08-19 07:35:25 --> Config Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:35:25 --> URI Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Router Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Output Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Input Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:35:25 --> Language Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Loader Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Controller Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:35:25 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:35:25 --> Final output sent to browser
DEBUG - 2011-08-19 07:35:25 --> Total execution time: 0.8803
DEBUG - 2011-08-19 07:35:28 --> Config Class Initialized
DEBUG - 2011-08-19 07:35:28 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:35:28 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:35:28 --> URI Class Initialized
DEBUG - 2011-08-19 07:35:28 --> Router Class Initialized
ERROR - 2011-08-19 07:35:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 07:35:29 --> Config Class Initialized
DEBUG - 2011-08-19 07:35:29 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:35:29 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:35:29 --> URI Class Initialized
DEBUG - 2011-08-19 07:35:29 --> Router Class Initialized
ERROR - 2011-08-19 07:35:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 07:35:30 --> Config Class Initialized
DEBUG - 2011-08-19 07:35:30 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:35:30 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:35:30 --> URI Class Initialized
DEBUG - 2011-08-19 07:35:30 --> Router Class Initialized
ERROR - 2011-08-19 07:35:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 07:35:49 --> Config Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:35:49 --> URI Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Router Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Output Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Input Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:35:49 --> Language Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Loader Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Controller Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Model Class Initialized
DEBUG - 2011-08-19 07:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:35:49 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:35:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 07:35:49 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:35:49 --> Final output sent to browser
DEBUG - 2011-08-19 07:35:49 --> Total execution time: 0.0714
DEBUG - 2011-08-19 07:43:57 --> Config Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:43:57 --> URI Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Router Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Output Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Input Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:43:57 --> Language Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Loader Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Controller Class Initialized
ERROR - 2011-08-19 07:43:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:43:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:43:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:43:57 --> Model Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Model Class Initialized
DEBUG - 2011-08-19 07:43:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:43:57 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:43:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:43:57 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:43:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:43:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:43:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:43:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:43:57 --> Final output sent to browser
DEBUG - 2011-08-19 07:43:57 --> Total execution time: 0.0378
DEBUG - 2011-08-19 07:43:58 --> Config Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:43:58 --> URI Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Router Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Output Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Input Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:43:58 --> Language Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Loader Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Controller Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Model Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Model Class Initialized
DEBUG - 2011-08-19 07:43:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:43:58 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:43:59 --> Final output sent to browser
DEBUG - 2011-08-19 07:43:59 --> Total execution time: 0.5073
DEBUG - 2011-08-19 07:44:00 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:00 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:00 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:00 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:00 --> Router Class Initialized
ERROR - 2011-08-19 07:44:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 07:44:00 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:00 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:00 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:00 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:00 --> Router Class Initialized
ERROR - 2011-08-19 07:44:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 07:44:36 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:36 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Router Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Output Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Input Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:44:36 --> Language Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Loader Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Controller Class Initialized
ERROR - 2011-08-19 07:44:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:44:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:44:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:44:36 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:44:36 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:44:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:44:36 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:44:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:44:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:44:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:44:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:44:36 --> Final output sent to browser
DEBUG - 2011-08-19 07:44:36 --> Total execution time: 0.0990
DEBUG - 2011-08-19 07:44:37 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:37 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Router Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Output Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Input Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:44:37 --> Language Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Loader Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Controller Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:44:37 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:44:37 --> Final output sent to browser
DEBUG - 2011-08-19 07:44:37 --> Total execution time: 0.4917
DEBUG - 2011-08-19 07:44:42 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:42 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Router Class Initialized
ERROR - 2011-08-19 07:44:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 07:44:42 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:42 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Router Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Output Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Input Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:44:42 --> Language Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Loader Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Controller Class Initialized
ERROR - 2011-08-19 07:44:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:44:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:44:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:44:42 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:44:42 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:44:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:44:42 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:44:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:44:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:44:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:44:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:44:42 --> Final output sent to browser
DEBUG - 2011-08-19 07:44:42 --> Total execution time: 0.1105
DEBUG - 2011-08-19 07:44:54 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:54 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Router Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Output Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Input Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:44:54 --> Language Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Loader Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Controller Class Initialized
ERROR - 2011-08-19 07:44:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:44:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:44:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:44:54 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:44:54 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:44:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:44:54 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:44:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:44:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:44:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:44:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:44:54 --> Final output sent to browser
DEBUG - 2011-08-19 07:44:54 --> Total execution time: 0.0896
DEBUG - 2011-08-19 07:44:55 --> Config Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:44:55 --> URI Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Router Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Output Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Input Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:44:55 --> Language Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Loader Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Controller Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Model Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:44:55 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:44:55 --> Final output sent to browser
DEBUG - 2011-08-19 07:44:55 --> Total execution time: 0.7274
DEBUG - 2011-08-19 07:45:11 --> Config Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:45:11 --> URI Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Router Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Output Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Input Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:45:11 --> Language Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Loader Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Controller Class Initialized
ERROR - 2011-08-19 07:45:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:45:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:45:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:45:11 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:45:11 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:45:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:45:11 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:45:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:45:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:45:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:45:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:45:11 --> Final output sent to browser
DEBUG - 2011-08-19 07:45:11 --> Total execution time: 0.1249
DEBUG - 2011-08-19 07:45:13 --> Config Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:45:13 --> URI Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Router Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Output Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Input Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:45:13 --> Language Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Loader Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Controller Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:45:13 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:45:13 --> Final output sent to browser
DEBUG - 2011-08-19 07:45:13 --> Total execution time: 0.7408
DEBUG - 2011-08-19 07:45:31 --> Config Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:45:31 --> URI Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Router Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Output Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Input Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:45:31 --> Language Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Loader Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Controller Class Initialized
ERROR - 2011-08-19 07:45:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:45:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:45:31 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:45:31 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:45:31 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:45:31 --> Final output sent to browser
DEBUG - 2011-08-19 07:45:31 --> Total execution time: 0.0489
DEBUG - 2011-08-19 07:45:32 --> Config Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:45:32 --> URI Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Router Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Output Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Input Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:45:32 --> Language Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Loader Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Controller Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Model Class Initialized
DEBUG - 2011-08-19 07:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:45:32 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:45:33 --> Final output sent to browser
DEBUG - 2011-08-19 07:45:33 --> Total execution time: 0.9088
DEBUG - 2011-08-19 07:59:51 --> Config Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:59:51 --> URI Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Router Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Output Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Input Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:59:51 --> Language Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Loader Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Controller Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:59:51 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:59:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 07:59:51 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:59:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:59:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:59:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:59:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:59:51 --> Final output sent to browser
DEBUG - 2011-08-19 07:59:51 --> Total execution time: 0.4610
DEBUG - 2011-08-19 07:59:52 --> Config Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:59:52 --> URI Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Router Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Output Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Input Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:59:52 --> Language Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Loader Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Controller Class Initialized
ERROR - 2011-08-19 07:59:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 07:59:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 07:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:59:52 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:59:52 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 07:59:52 --> Helper loaded: url_helper
DEBUG - 2011-08-19 07:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 07:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 07:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 07:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 07:59:52 --> Final output sent to browser
DEBUG - 2011-08-19 07:59:52 --> Total execution time: 0.0280
DEBUG - 2011-08-19 07:59:53 --> Config Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:59:53 --> URI Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Router Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Output Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Input Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 07:59:53 --> Language Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Loader Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Controller Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Model Class Initialized
DEBUG - 2011-08-19 07:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 07:59:53 --> Database Driver Class Initialized
DEBUG - 2011-08-19 07:59:54 --> Final output sent to browser
DEBUG - 2011-08-19 07:59:54 --> Total execution time: 0.6196
DEBUG - 2011-08-19 07:59:58 --> Config Class Initialized
DEBUG - 2011-08-19 07:59:58 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:59:58 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:59:58 --> URI Class Initialized
DEBUG - 2011-08-19 07:59:58 --> Router Class Initialized
ERROR - 2011-08-19 07:59:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 07:59:58 --> Config Class Initialized
DEBUG - 2011-08-19 07:59:58 --> Hooks Class Initialized
DEBUG - 2011-08-19 07:59:58 --> Utf8 Class Initialized
DEBUG - 2011-08-19 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 07:59:58 --> URI Class Initialized
DEBUG - 2011-08-19 07:59:58 --> Router Class Initialized
ERROR - 2011-08-19 07:59:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:00:03 --> Config Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:00:03 --> URI Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Router Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Output Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Input Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:00:03 --> Language Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Loader Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Controller Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:00:03 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:00:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 08:00:03 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:00:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:00:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:00:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:00:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:00:03 --> Final output sent to browser
DEBUG - 2011-08-19 08:00:03 --> Total execution time: 0.4628
DEBUG - 2011-08-19 08:00:06 --> Config Class Initialized
DEBUG - 2011-08-19 08:00:06 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:00:06 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:00:06 --> URI Class Initialized
DEBUG - 2011-08-19 08:00:06 --> Router Class Initialized
ERROR - 2011-08-19 08:00:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:00:24 --> Config Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:00:24 --> URI Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Router Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Output Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Input Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:00:24 --> Language Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Loader Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Controller Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:00:24 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:00:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 08:00:25 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:00:25 --> Final output sent to browser
DEBUG - 2011-08-19 08:00:25 --> Total execution time: 1.2874
DEBUG - 2011-08-19 08:00:27 --> Config Class Initialized
DEBUG - 2011-08-19 08:00:27 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:00:27 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:00:27 --> URI Class Initialized
DEBUG - 2011-08-19 08:00:27 --> Router Class Initialized
ERROR - 2011-08-19 08:00:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:00:27 --> Config Class Initialized
DEBUG - 2011-08-19 08:00:27 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:00:27 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:00:27 --> URI Class Initialized
DEBUG - 2011-08-19 08:00:27 --> Router Class Initialized
ERROR - 2011-08-19 08:00:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:00:28 --> Config Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:00:28 --> URI Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Router Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Output Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Input Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:00:28 --> Language Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Loader Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Controller Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Model Class Initialized
DEBUG - 2011-08-19 08:00:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:00:28 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:00:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 08:00:28 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:00:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:00:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:00:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:00:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:00:28 --> Final output sent to browser
DEBUG - 2011-08-19 08:00:28 --> Total execution time: 0.0878
DEBUG - 2011-08-19 08:01:09 --> Config Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:01:09 --> URI Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Router Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Output Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Input Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:01:09 --> Language Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Loader Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Controller Class Initialized
ERROR - 2011-08-19 08:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:01:09 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:01:09 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:01:09 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:01:09 --> Final output sent to browser
DEBUG - 2011-08-19 08:01:09 --> Total execution time: 0.0346
DEBUG - 2011-08-19 08:01:10 --> Config Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:01:10 --> URI Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Router Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Output Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Input Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:01:10 --> Language Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Loader Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Controller Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:01:10 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:01:11 --> Final output sent to browser
DEBUG - 2011-08-19 08:01:11 --> Total execution time: 0.5858
DEBUG - 2011-08-19 08:01:12 --> Config Class Initialized
DEBUG - 2011-08-19 08:01:12 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:01:12 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:01:12 --> URI Class Initialized
DEBUG - 2011-08-19 08:01:12 --> Router Class Initialized
ERROR - 2011-08-19 08:01:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:01:42 --> Config Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:01:42 --> URI Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Router Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Output Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Input Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:01:42 --> Language Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Loader Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Controller Class Initialized
ERROR - 2011-08-19 08:01:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:01:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:01:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:01:42 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:01:42 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:01:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:01:42 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:01:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:01:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:01:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:01:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:01:42 --> Final output sent to browser
DEBUG - 2011-08-19 08:01:42 --> Total execution time: 0.0301
DEBUG - 2011-08-19 08:01:43 --> Config Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:01:43 --> URI Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Router Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Output Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Input Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:01:43 --> Language Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Loader Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Controller Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Model Class Initialized
DEBUG - 2011-08-19 08:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:01:43 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:01:44 --> Final output sent to browser
DEBUG - 2011-08-19 08:01:44 --> Total execution time: 0.6515
DEBUG - 2011-08-19 08:01:46 --> Config Class Initialized
DEBUG - 2011-08-19 08:01:46 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:01:46 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:01:46 --> URI Class Initialized
DEBUG - 2011-08-19 08:01:46 --> Router Class Initialized
ERROR - 2011-08-19 08:01:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:02:06 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:06 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:06 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Controller Class Initialized
ERROR - 2011-08-19 08:02:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:06 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:06 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:06 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:02:06 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:06 --> Total execution time: 0.0491
DEBUG - 2011-08-19 08:02:07 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:07 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:07 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Controller Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:07 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:08 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:08 --> Total execution time: 0.6907
DEBUG - 2011-08-19 08:02:10 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:10 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Router Class Initialized
ERROR - 2011-08-19 08:02:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:02:10 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:10 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:10 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Controller Class Initialized
ERROR - 2011-08-19 08:02:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:02:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:02:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:10 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:10 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:10 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:02:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:02:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:02:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:02:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:02:10 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:10 --> Total execution time: 0.0615
DEBUG - 2011-08-19 08:02:19 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:19 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:19 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Controller Class Initialized
ERROR - 2011-08-19 08:02:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:19 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:19 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:19 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:02:19 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:19 --> Total execution time: 0.0493
DEBUG - 2011-08-19 08:02:20 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:20 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:20 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Controller Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:20 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:21 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:21 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Controller Class Initialized
ERROR - 2011-08-19 08:02:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:02:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:21 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:21 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:21 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:02:21 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:21 --> Total execution time: 0.0338
DEBUG - 2011-08-19 08:02:21 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:21 --> Total execution time: 0.6533
DEBUG - 2011-08-19 08:02:24 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:24 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:24 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:24 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:24 --> Router Class Initialized
ERROR - 2011-08-19 08:02:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:02:29 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:29 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:29 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Controller Class Initialized
ERROR - 2011-08-19 08:02:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:02:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:02:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:29 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:29 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:29 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:02:29 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:29 --> Total execution time: 0.0276
DEBUG - 2011-08-19 08:02:30 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:30 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:30 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Controller Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:30 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:30 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:30 --> Total execution time: 0.5346
DEBUG - 2011-08-19 08:02:33 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:33 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:33 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:33 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:33 --> Router Class Initialized
ERROR - 2011-08-19 08:02:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 08:02:35 --> Config Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Hooks Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Utf8 Class Initialized
DEBUG - 2011-08-19 08:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 08:02:35 --> URI Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Router Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Output Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Input Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 08:02:35 --> Language Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Loader Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Controller Class Initialized
ERROR - 2011-08-19 08:02:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 08:02:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 08:02:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:35 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Model Class Initialized
DEBUG - 2011-08-19 08:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 08:02:35 --> Database Driver Class Initialized
DEBUG - 2011-08-19 08:02:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 08:02:35 --> Helper loaded: url_helper
DEBUG - 2011-08-19 08:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 08:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 08:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 08:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 08:02:35 --> Final output sent to browser
DEBUG - 2011-08-19 08:02:35 --> Total execution time: 0.0425
DEBUG - 2011-08-19 09:29:58 --> Config Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Hooks Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Utf8 Class Initialized
DEBUG - 2011-08-19 09:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 09:29:58 --> URI Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Router Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Output Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Input Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 09:29:58 --> Language Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Loader Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Controller Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Model Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Model Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Model Class Initialized
DEBUG - 2011-08-19 09:29:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 09:29:58 --> Database Driver Class Initialized
DEBUG - 2011-08-19 09:29:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 09:29:58 --> Helper loaded: url_helper
DEBUG - 2011-08-19 09:29:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 09:29:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 09:29:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 09:29:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 09:29:58 --> Final output sent to browser
DEBUG - 2011-08-19 09:29:58 --> Total execution time: 0.5485
DEBUG - 2011-08-19 09:30:02 --> Config Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Hooks Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Utf8 Class Initialized
DEBUG - 2011-08-19 09:30:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 09:30:02 --> URI Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Router Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Output Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Input Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 09:30:02 --> Language Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Loader Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Controller Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Model Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Model Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Model Class Initialized
DEBUG - 2011-08-19 09:30:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 09:30:02 --> Database Driver Class Initialized
DEBUG - 2011-08-19 09:30:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 09:30:02 --> Helper loaded: url_helper
DEBUG - 2011-08-19 09:30:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 09:30:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 09:30:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 09:30:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 09:30:02 --> Final output sent to browser
DEBUG - 2011-08-19 09:30:02 --> Total execution time: 0.4811
DEBUG - 2011-08-19 09:46:22 --> Config Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-19 09:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 09:46:22 --> URI Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Router Class Initialized
DEBUG - 2011-08-19 09:46:22 --> No URI present. Default controller set.
DEBUG - 2011-08-19 09:46:22 --> Output Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Input Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 09:46:22 --> Language Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Loader Class Initialized
DEBUG - 2011-08-19 09:46:22 --> Controller Class Initialized
DEBUG - 2011-08-19 09:46:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-19 09:46:22 --> Helper loaded: url_helper
DEBUG - 2011-08-19 09:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 09:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 09:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 09:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 09:46:22 --> Final output sent to browser
DEBUG - 2011-08-19 09:46:22 --> Total execution time: 0.0754
DEBUG - 2011-08-19 11:38:00 --> Config Class Initialized
DEBUG - 2011-08-19 11:38:00 --> Hooks Class Initialized
DEBUG - 2011-08-19 11:38:00 --> Utf8 Class Initialized
DEBUG - 2011-08-19 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 11:38:00 --> URI Class Initialized
DEBUG - 2011-08-19 11:38:00 --> Router Class Initialized
ERROR - 2011-08-19 11:38:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 14:21:09 --> Config Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Hooks Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Utf8 Class Initialized
DEBUG - 2011-08-19 14:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 14:21:09 --> URI Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Router Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Output Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Input Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 14:21:09 --> Language Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Loader Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Controller Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Model Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Model Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Model Class Initialized
DEBUG - 2011-08-19 14:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 14:21:09 --> Database Driver Class Initialized
DEBUG - 2011-08-19 14:21:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 14:21:09 --> Helper loaded: url_helper
DEBUG - 2011-08-19 14:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 14:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 14:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 14:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 14:21:09 --> Final output sent to browser
DEBUG - 2011-08-19 14:21:09 --> Total execution time: 0.4751
DEBUG - 2011-08-19 14:21:11 --> Config Class Initialized
DEBUG - 2011-08-19 14:21:11 --> Hooks Class Initialized
DEBUG - 2011-08-19 14:21:11 --> Utf8 Class Initialized
DEBUG - 2011-08-19 14:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 14:21:11 --> URI Class Initialized
DEBUG - 2011-08-19 14:21:11 --> Router Class Initialized
ERROR - 2011-08-19 14:21:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:36:53 --> Config Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:36:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:36:53 --> URI Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Router Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Output Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Input Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:36:53 --> Language Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Loader Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Controller Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Model Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Model Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Model Class Initialized
DEBUG - 2011-08-19 15:36:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:36:53 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:36:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:36:54 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:36:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:36:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:36:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:36:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:36:54 --> Final output sent to browser
DEBUG - 2011-08-19 15:36:54 --> Total execution time: 0.4776
DEBUG - 2011-08-19 15:36:56 --> Config Class Initialized
DEBUG - 2011-08-19 15:36:56 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:36:56 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:36:56 --> URI Class Initialized
DEBUG - 2011-08-19 15:36:56 --> Router Class Initialized
ERROR - 2011-08-19 15:36:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:37:11 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:11 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Router Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Output Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Input Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:37:11 --> Language Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Loader Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Controller Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:37:11 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:37:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:37:12 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:37:12 --> Final output sent to browser
DEBUG - 2011-08-19 15:37:12 --> Total execution time: 0.8684
DEBUG - 2011-08-19 15:37:13 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:13 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:13 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:13 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:13 --> Router Class Initialized
ERROR - 2011-08-19 15:37:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:37:23 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:23 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Router Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Output Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Input Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:37:23 --> Language Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Loader Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Controller Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:37:23 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:37:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:37:24 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:37:24 --> Final output sent to browser
DEBUG - 2011-08-19 15:37:24 --> Total execution time: 0.8869
DEBUG - 2011-08-19 15:37:25 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:25 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:25 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:25 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:25 --> Router Class Initialized
ERROR - 2011-08-19 15:37:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:37:27 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:27 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Router Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Output Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Input Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:37:27 --> Language Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Loader Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Controller Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:37:27 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:37:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:37:27 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:37:27 --> Final output sent to browser
DEBUG - 2011-08-19 15:37:27 --> Total execution time: 0.0702
DEBUG - 2011-08-19 15:37:31 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:31 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Router Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Output Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Input Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:37:31 --> Language Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Loader Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Controller Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:37:31 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:37:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:37:31 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:37:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:37:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:37:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:37:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:37:31 --> Final output sent to browser
DEBUG - 2011-08-19 15:37:31 --> Total execution time: 0.0454
DEBUG - 2011-08-19 15:37:47 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:47 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Router Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Output Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Input Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:37:47 --> Language Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Loader Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Controller Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:37:47 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:37:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:37:48 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:37:48 --> Final output sent to browser
DEBUG - 2011-08-19 15:37:48 --> Total execution time: 0.8214
DEBUG - 2011-08-19 15:37:49 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:49 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:49 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:49 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:49 --> Router Class Initialized
ERROR - 2011-08-19 15:37:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:37:50 --> Config Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:37:50 --> URI Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Router Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Output Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Input Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:37:50 --> Language Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Loader Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Controller Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Model Class Initialized
DEBUG - 2011-08-19 15:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:37:50 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:37:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:37:50 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:37:50 --> Final output sent to browser
DEBUG - 2011-08-19 15:37:50 --> Total execution time: 0.0865
DEBUG - 2011-08-19 15:38:09 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:09 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Router Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Output Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Input Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:38:09 --> Language Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Loader Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Controller Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:38:09 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:38:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:38:10 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:38:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:38:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:38:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:38:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:38:10 --> Final output sent to browser
DEBUG - 2011-08-19 15:38:10 --> Total execution time: 0.7708
DEBUG - 2011-08-19 15:38:11 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:11 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:11 --> Router Class Initialized
ERROR - 2011-08-19 15:38:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:38:12 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:12 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Router Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Output Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Input Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:38:12 --> Language Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Loader Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Controller Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:38:12 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:38:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:38:12 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:38:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:38:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:38:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:38:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:38:12 --> Final output sent to browser
DEBUG - 2011-08-19 15:38:12 --> Total execution time: 0.0475
DEBUG - 2011-08-19 15:38:22 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:22 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Router Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Output Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Input Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:38:22 --> Language Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Loader Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Controller Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:38:22 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:38:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:38:22 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:38:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:38:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:38:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:38:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:38:22 --> Final output sent to browser
DEBUG - 2011-08-19 15:38:22 --> Total execution time: 0.2367
DEBUG - 2011-08-19 15:38:24 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:24 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:24 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:24 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:24 --> Router Class Initialized
ERROR - 2011-08-19 15:38:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:38:35 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:35 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Router Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Output Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Input Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:38:35 --> Language Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Loader Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Controller Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:38:35 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:38:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:38:35 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:38:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:38:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:38:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:38:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:38:35 --> Final output sent to browser
DEBUG - 2011-08-19 15:38:35 --> Total execution time: 0.5079
DEBUG - 2011-08-19 15:38:37 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:37 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:37 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:37 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:37 --> Router Class Initialized
ERROR - 2011-08-19 15:38:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:38:47 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:47 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Router Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Output Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Input Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:38:47 --> Language Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Loader Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Controller Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:38:47 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:38:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:38:47 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:38:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:38:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:38:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:38:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:38:47 --> Final output sent to browser
DEBUG - 2011-08-19 15:38:47 --> Total execution time: 0.2765
DEBUG - 2011-08-19 15:38:48 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:48 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:48 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:48 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:48 --> Router Class Initialized
ERROR - 2011-08-19 15:38:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:38:59 --> Config Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:38:59 --> URI Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Router Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Output Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Input Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:38:59 --> Language Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Loader Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Controller Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Model Class Initialized
DEBUG - 2011-08-19 15:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:38:59 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:00 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:00 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:00 --> Total execution time: 0.5759
DEBUG - 2011-08-19 15:39:01 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:01 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:01 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:01 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:01 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:01 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:01 --> Total execution time: 0.1288
DEBUG - 2011-08-19 15:39:01 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:01 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Router Class Initialized
ERROR - 2011-08-19 15:39:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:39:01 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:01 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:01 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:01 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:01 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:01 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:01 --> Total execution time: 0.1173
DEBUG - 2011-08-19 15:39:09 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:09 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:09 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:09 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:09 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:09 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:09 --> Total execution time: 0.0600
DEBUG - 2011-08-19 15:39:10 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:10 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:10 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:10 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:10 --> Router Class Initialized
ERROR - 2011-08-19 15:39:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:39:11 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:11 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:11 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:11 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:11 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:11 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:11 --> Total execution time: 0.0660
DEBUG - 2011-08-19 15:39:21 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:21 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:21 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:21 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:22 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:22 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:22 --> Total execution time: 0.4337
DEBUG - 2011-08-19 15:39:22 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:22 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:22 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:22 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:22 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:22 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:23 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:23 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:23 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:23 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:23 --> Total execution time: 0.1472
DEBUG - 2011-08-19 15:39:23 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:23 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:23 --> Router Class Initialized
ERROR - 2011-08-19 15:39:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:39:32 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:32 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Router Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Output Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Input Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:39:32 --> Language Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Loader Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Controller Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Model Class Initialized
DEBUG - 2011-08-19 15:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:39:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:39:32 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:39:32 --> Final output sent to browser
DEBUG - 2011-08-19 15:39:32 --> Total execution time: 0.0714
DEBUG - 2011-08-19 15:39:33 --> Config Class Initialized
DEBUG - 2011-08-19 15:39:33 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:39:33 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:39:33 --> URI Class Initialized
DEBUG - 2011-08-19 15:39:33 --> Router Class Initialized
ERROR - 2011-08-19 15:39:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:40:03 --> Config Class Initialized
DEBUG - 2011-08-19 15:40:03 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:40:03 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:40:03 --> URI Class Initialized
DEBUG - 2011-08-19 15:40:03 --> Router Class Initialized
ERROR - 2011-08-19 15:40:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 15:40:41 --> Config Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:40:41 --> URI Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Router Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Output Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Input Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:40:41 --> Language Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Loader Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Controller Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Model Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Model Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Model Class Initialized
DEBUG - 2011-08-19 15:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:40:41 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:40:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:40:41 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:40:41 --> Final output sent to browser
DEBUG - 2011-08-19 15:40:41 --> Total execution time: 0.0488
DEBUG - 2011-08-19 15:41:03 --> Config Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Hooks Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Utf8 Class Initialized
DEBUG - 2011-08-19 15:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 15:41:03 --> URI Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Router Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Output Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Input Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 15:41:03 --> Language Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Loader Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Controller Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Model Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Model Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Model Class Initialized
DEBUG - 2011-08-19 15:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 15:41:03 --> Database Driver Class Initialized
DEBUG - 2011-08-19 15:41:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 15:41:03 --> Helper loaded: url_helper
DEBUG - 2011-08-19 15:41:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 15:41:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 15:41:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 15:41:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 15:41:03 --> Final output sent to browser
DEBUG - 2011-08-19 15:41:03 --> Total execution time: 0.0477
DEBUG - 2011-08-19 16:18:37 --> Config Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Hooks Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Utf8 Class Initialized
DEBUG - 2011-08-19 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 16:18:37 --> URI Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Router Class Initialized
DEBUG - 2011-08-19 16:18:37 --> No URI present. Default controller set.
DEBUG - 2011-08-19 16:18:37 --> Output Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Input Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 16:18:37 --> Language Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Loader Class Initialized
DEBUG - 2011-08-19 16:18:37 --> Controller Class Initialized
DEBUG - 2011-08-19 16:18:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-19 16:18:37 --> Helper loaded: url_helper
DEBUG - 2011-08-19 16:18:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 16:18:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 16:18:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 16:18:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 16:18:37 --> Final output sent to browser
DEBUG - 2011-08-19 16:18:37 --> Total execution time: 0.1142
DEBUG - 2011-08-19 17:16:07 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:07 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Router Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Output Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Input Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:16:07 --> Language Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Loader Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Controller Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:16:07 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:16:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 17:16:08 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:16:08 --> Final output sent to browser
DEBUG - 2011-08-19 17:16:08 --> Total execution time: 0.3570
DEBUG - 2011-08-19 17:16:14 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:14 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:14 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:14 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:14 --> Router Class Initialized
ERROR - 2011-08-19 17:16:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 17:16:15 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:15 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:15 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:15 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:15 --> Router Class Initialized
ERROR - 2011-08-19 17:16:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 17:16:15 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:15 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:15 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:15 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:15 --> Router Class Initialized
ERROR - 2011-08-19 17:16:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 17:16:25 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:25 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Router Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Output Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Input Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:16:25 --> Language Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Loader Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Controller Class Initialized
ERROR - 2011-08-19 17:16:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:16:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:16:25 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:16:25 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:16:25 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:16:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:16:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:16:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:16:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:16:25 --> Final output sent to browser
DEBUG - 2011-08-19 17:16:25 --> Total execution time: 0.0792
DEBUG - 2011-08-19 17:16:26 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:26 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Router Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Output Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Input Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:16:26 --> Language Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Loader Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Controller Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:16:26 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:16:27 --> Final output sent to browser
DEBUG - 2011-08-19 17:16:27 --> Total execution time: 0.5561
DEBUG - 2011-08-19 17:16:53 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:53 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Router Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Output Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Input Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:16:53 --> Language Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Loader Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Controller Class Initialized
ERROR - 2011-08-19 17:16:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:16:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:16:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:16:53 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:16:53 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:16:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:16:53 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:16:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:16:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:16:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:16:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:16:53 --> Final output sent to browser
DEBUG - 2011-08-19 17:16:53 --> Total execution time: 0.0304
DEBUG - 2011-08-19 17:16:54 --> Config Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:16:54 --> URI Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Router Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Output Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Input Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:16:54 --> Language Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Loader Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Controller Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Model Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:16:54 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:16:54 --> Final output sent to browser
DEBUG - 2011-08-19 17:16:54 --> Total execution time: 0.7104
DEBUG - 2011-08-19 17:17:05 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:05 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:05 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Controller Class Initialized
ERROR - 2011-08-19 17:17:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:17:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:05 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:05 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:05 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:17:05 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:05 --> Total execution time: 0.0279
DEBUG - 2011-08-19 17:17:06 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:06 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:06 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Controller Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:06 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:07 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:07 --> Total execution time: 0.5619
DEBUG - 2011-08-19 17:17:15 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:15 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:15 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Controller Class Initialized
ERROR - 2011-08-19 17:17:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:17:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:17:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:15 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:15 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:15 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:17:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:17:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:17:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:17:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:17:15 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:15 --> Total execution time: 0.0668
DEBUG - 2011-08-19 17:17:15 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:15 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:15 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Controller Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:15 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:16 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:16 --> Total execution time: 0.6245
DEBUG - 2011-08-19 17:17:29 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:29 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:29 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Controller Class Initialized
ERROR - 2011-08-19 17:17:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:17:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:17:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:29 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:29 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:29 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:17:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:17:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:17:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:17:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:17:29 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:29 --> Total execution time: 0.0263
DEBUG - 2011-08-19 17:17:30 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:30 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:30 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Controller Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:30 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:31 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:31 --> Total execution time: 1.3699
DEBUG - 2011-08-19 17:17:38 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:38 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:38 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Controller Class Initialized
ERROR - 2011-08-19 17:17:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:17:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:17:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:38 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:38 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:38 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:17:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:17:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:17:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:17:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:17:38 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:38 --> Total execution time: 0.0339
DEBUG - 2011-08-19 17:17:38 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:38 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:38 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Controller Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:38 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:39 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:39 --> Total execution time: 0.5473
DEBUG - 2011-08-19 17:17:40 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:40 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:40 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Controller Class Initialized
ERROR - 2011-08-19 17:17:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:17:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:40 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:40 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:40 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:17:40 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:40 --> Total execution time: 0.0287
DEBUG - 2011-08-19 17:17:40 --> Config Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:17:40 --> URI Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Router Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Output Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Input Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:17:40 --> Language Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Loader Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Controller Class Initialized
ERROR - 2011-08-19 17:17:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:17:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:40 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Model Class Initialized
DEBUG - 2011-08-19 17:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:17:40 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:17:40 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:17:40 --> Final output sent to browser
DEBUG - 2011-08-19 17:17:40 --> Total execution time: 0.0273
DEBUG - 2011-08-19 17:18:05 --> Config Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:18:05 --> URI Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Router Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Output Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Input Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:18:05 --> Language Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Loader Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Controller Class Initialized
ERROR - 2011-08-19 17:18:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 17:18:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 17:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:18:05 --> Model Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Model Class Initialized
DEBUG - 2011-08-19 17:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:18:05 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 17:18:05 --> Helper loaded: url_helper
DEBUG - 2011-08-19 17:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 17:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 17:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 17:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 17:18:05 --> Final output sent to browser
DEBUG - 2011-08-19 17:18:05 --> Total execution time: 0.0304
DEBUG - 2011-08-19 17:18:06 --> Config Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Hooks Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Utf8 Class Initialized
DEBUG - 2011-08-19 17:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 17:18:06 --> URI Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Router Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Output Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Input Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 17:18:06 --> Language Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Loader Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Controller Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Model Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Model Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 17:18:06 --> Database Driver Class Initialized
DEBUG - 2011-08-19 17:18:06 --> Final output sent to browser
DEBUG - 2011-08-19 17:18:06 --> Total execution time: 0.6147
DEBUG - 2011-08-19 18:17:13 --> Config Class Initialized
DEBUG - 2011-08-19 18:17:13 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:17:13 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:17:13 --> URI Class Initialized
DEBUG - 2011-08-19 18:17:13 --> Router Class Initialized
ERROR - 2011-08-19 18:17:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 18:17:17 --> Config Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:17:17 --> URI Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Router Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Output Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Input Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:17:17 --> Language Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Loader Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Controller Class Initialized
ERROR - 2011-08-19 18:17:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 18:17:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 18:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 18:17:17 --> Model Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Model Class Initialized
DEBUG - 2011-08-19 18:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:17:17 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 18:17:17 --> Helper loaded: url_helper
DEBUG - 2011-08-19 18:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 18:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 18:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 18:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 18:17:17 --> Final output sent to browser
DEBUG - 2011-08-19 18:17:17 --> Total execution time: 0.1326
DEBUG - 2011-08-19 18:17:21 --> Config Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:17:21 --> URI Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Router Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Output Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Input Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:17:21 --> Language Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Loader Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Controller Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Model Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Model Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Model Class Initialized
DEBUG - 2011-08-19 18:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:17:21 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:17:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 18:17:21 --> Helper loaded: url_helper
DEBUG - 2011-08-19 18:17:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 18:17:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 18:17:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 18:17:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 18:17:21 --> Final output sent to browser
DEBUG - 2011-08-19 18:17:21 --> Total execution time: 0.2106
DEBUG - 2011-08-19 18:18:47 --> Config Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:18:47 --> URI Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Router Class Initialized
ERROR - 2011-08-19 18:18:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 18:18:47 --> Config Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:18:47 --> URI Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Router Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Output Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Input Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:18:47 --> Language Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Loader Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Controller Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Model Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Model Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Model Class Initialized
DEBUG - 2011-08-19 18:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:18:47 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:18:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 18:18:47 --> Helper loaded: url_helper
DEBUG - 2011-08-19 18:18:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 18:18:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 18:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 18:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 18:18:47 --> Final output sent to browser
DEBUG - 2011-08-19 18:18:47 --> Total execution time: 0.0511
DEBUG - 2011-08-19 18:31:59 --> Config Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:31:59 --> URI Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Router Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Output Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Input Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:31:59 --> Language Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Loader Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Controller Class Initialized
ERROR - 2011-08-19 18:31:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 18:31:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 18:31:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 18:31:59 --> Model Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Model Class Initialized
DEBUG - 2011-08-19 18:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:31:59 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:31:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 18:31:59 --> Helper loaded: url_helper
DEBUG - 2011-08-19 18:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 18:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 18:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 18:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 18:31:59 --> Final output sent to browser
DEBUG - 2011-08-19 18:31:59 --> Total execution time: 0.0920
DEBUG - 2011-08-19 18:32:01 --> Config Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:32:01 --> URI Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Router Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Output Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Input Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:32:01 --> Language Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Loader Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Controller Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Model Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Model Class Initialized
DEBUG - 2011-08-19 18:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:32:01 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:32:02 --> Final output sent to browser
DEBUG - 2011-08-19 18:32:02 --> Total execution time: 0.8365
DEBUG - 2011-08-19 18:32:03 --> Config Class Initialized
DEBUG - 2011-08-19 18:32:03 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:32:03 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:32:03 --> URI Class Initialized
DEBUG - 2011-08-19 18:32:03 --> Router Class Initialized
ERROR - 2011-08-19 18:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 18:32:03 --> Config Class Initialized
DEBUG - 2011-08-19 18:32:03 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:32:03 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:32:03 --> URI Class Initialized
DEBUG - 2011-08-19 18:32:03 --> Router Class Initialized
ERROR - 2011-08-19 18:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-19 18:56:43 --> Config Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:56:43 --> URI Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Router Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Output Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Input Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:56:43 --> Language Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Loader Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Controller Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Model Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Model Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Model Class Initialized
DEBUG - 2011-08-19 18:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:56:43 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 18:56:43 --> Helper loaded: url_helper
DEBUG - 2011-08-19 18:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 18:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 18:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 18:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 18:56:43 --> Final output sent to browser
DEBUG - 2011-08-19 18:56:43 --> Total execution time: 0.2039
DEBUG - 2011-08-19 18:56:44 --> Config Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Hooks Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Utf8 Class Initialized
DEBUG - 2011-08-19 18:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 18:56:44 --> URI Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Router Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Output Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Input Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 18:56:44 --> Language Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Loader Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Controller Class Initialized
ERROR - 2011-08-19 18:56:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 18:56:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 18:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 18:56:44 --> Model Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Model Class Initialized
DEBUG - 2011-08-19 18:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 18:56:44 --> Database Driver Class Initialized
DEBUG - 2011-08-19 18:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 18:56:44 --> Helper loaded: url_helper
DEBUG - 2011-08-19 18:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 18:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 18:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 18:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 18:56:44 --> Final output sent to browser
DEBUG - 2011-08-19 18:56:44 --> Total execution time: 0.0262
DEBUG - 2011-08-19 19:13:08 --> Config Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Hooks Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Utf8 Class Initialized
DEBUG - 2011-08-19 19:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 19:13:08 --> URI Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Router Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Output Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Input Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 19:13:08 --> Language Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Loader Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Controller Class Initialized
ERROR - 2011-08-19 19:13:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-19 19:13:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-19 19:13:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 19:13:08 --> Model Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Model Class Initialized
DEBUG - 2011-08-19 19:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 19:13:08 --> Database Driver Class Initialized
DEBUG - 2011-08-19 19:13:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-19 19:13:08 --> Helper loaded: url_helper
DEBUG - 2011-08-19 19:13:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 19:13:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 19:13:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 19:13:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 19:13:08 --> Final output sent to browser
DEBUG - 2011-08-19 19:13:08 --> Total execution time: 0.0361
DEBUG - 2011-08-19 19:13:14 --> Config Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Hooks Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Utf8 Class Initialized
DEBUG - 2011-08-19 19:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 19:13:14 --> URI Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Router Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Output Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Input Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 19:13:14 --> Language Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Loader Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Controller Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Model Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Model Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Model Class Initialized
DEBUG - 2011-08-19 19:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 19:13:14 --> Database Driver Class Initialized
DEBUG - 2011-08-19 19:13:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 19:13:14 --> Helper loaded: url_helper
DEBUG - 2011-08-19 19:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 19:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 19:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 19:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 19:13:14 --> Final output sent to browser
DEBUG - 2011-08-19 19:13:14 --> Total execution time: 0.0575
DEBUG - 2011-08-19 19:37:20 --> Config Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-19 19:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 19:37:20 --> URI Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Router Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Output Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Input Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 19:37:20 --> Language Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Loader Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Controller Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Model Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Model Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Model Class Initialized
DEBUG - 2011-08-19 19:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-19 19:37:20 --> Database Driver Class Initialized
DEBUG - 2011-08-19 19:37:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-19 19:37:20 --> Helper loaded: url_helper
DEBUG - 2011-08-19 19:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 19:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 19:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 19:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 19:37:20 --> Final output sent to browser
DEBUG - 2011-08-19 19:37:20 --> Total execution time: 0.3980
DEBUG - 2011-08-19 23:14:14 --> Config Class Initialized
DEBUG - 2011-08-19 23:14:14 --> Hooks Class Initialized
DEBUG - 2011-08-19 23:14:14 --> Utf8 Class Initialized
DEBUG - 2011-08-19 23:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 23:14:14 --> URI Class Initialized
DEBUG - 2011-08-19 23:14:14 --> Router Class Initialized
ERROR - 2011-08-19 23:14:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-19 23:44:32 --> Config Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Hooks Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Utf8 Class Initialized
DEBUG - 2011-08-19 23:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-19 23:44:32 --> URI Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Router Class Initialized
DEBUG - 2011-08-19 23:44:32 --> No URI present. Default controller set.
DEBUG - 2011-08-19 23:44:32 --> Output Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Input Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-19 23:44:32 --> Language Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Loader Class Initialized
DEBUG - 2011-08-19 23:44:32 --> Controller Class Initialized
DEBUG - 2011-08-19 23:44:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-19 23:44:32 --> Helper loaded: url_helper
DEBUG - 2011-08-19 23:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-19 23:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-19 23:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-19 23:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-19 23:44:32 --> Final output sent to browser
DEBUG - 2011-08-19 23:44:32 --> Total execution time: 0.2394

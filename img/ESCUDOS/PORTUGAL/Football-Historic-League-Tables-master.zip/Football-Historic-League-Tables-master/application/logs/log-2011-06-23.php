<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-23 01:09:56 --> Config Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Hooks Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Utf8 Class Initialized
DEBUG - 2011-06-23 01:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 01:09:56 --> URI Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Router Class Initialized
ERROR - 2011-06-23 01:09:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 01:09:56 --> Config Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Hooks Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Utf8 Class Initialized
DEBUG - 2011-06-23 01:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 01:09:56 --> URI Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Router Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Output Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Input Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 01:09:56 --> Language Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Loader Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Controller Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Model Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Model Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Model Class Initialized
DEBUG - 2011-06-23 01:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 01:09:56 --> Database Driver Class Initialized
DEBUG - 2011-06-23 01:09:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 01:09:57 --> Helper loaded: url_helper
DEBUG - 2011-06-23 01:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 01:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 01:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 01:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 01:09:57 --> Final output sent to browser
DEBUG - 2011-06-23 01:09:57 --> Total execution time: 0.5687
DEBUG - 2011-06-23 01:10:27 --> Config Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Hooks Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Utf8 Class Initialized
DEBUG - 2011-06-23 01:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 01:10:27 --> URI Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Router Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Output Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Input Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 01:10:27 --> Language Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Loader Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Controller Class Initialized
ERROR - 2011-06-23 01:10:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-23 01:10:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-23 01:10:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 01:10:27 --> Model Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Model Class Initialized
DEBUG - 2011-06-23 01:10:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 01:10:27 --> Database Driver Class Initialized
DEBUG - 2011-06-23 01:10:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 01:10:27 --> Helper loaded: url_helper
DEBUG - 2011-06-23 01:10:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 01:10:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 01:10:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 01:10:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 01:10:27 --> Final output sent to browser
DEBUG - 2011-06-23 01:10:27 --> Total execution time: 0.0873
DEBUG - 2011-06-23 01:48:12 --> Config Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Hooks Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Utf8 Class Initialized
DEBUG - 2011-06-23 01:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 01:48:12 --> URI Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Router Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Output Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Input Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 01:48:12 --> Language Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Loader Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Controller Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Model Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Model Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Model Class Initialized
DEBUG - 2011-06-23 01:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 01:48:13 --> Database Driver Class Initialized
DEBUG - 2011-06-23 01:48:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 01:48:15 --> Helper loaded: url_helper
DEBUG - 2011-06-23 01:48:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 01:48:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 01:48:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 01:48:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 01:48:15 --> Final output sent to browser
DEBUG - 2011-06-23 01:48:15 --> Total execution time: 2.9995
DEBUG - 2011-06-23 01:48:28 --> Config Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Hooks Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Utf8 Class Initialized
DEBUG - 2011-06-23 01:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 01:48:28 --> URI Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Router Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Output Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Input Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 01:48:28 --> Language Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Loader Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Controller Class Initialized
ERROR - 2011-06-23 01:48:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-23 01:48:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-23 01:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 01:48:28 --> Model Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Model Class Initialized
DEBUG - 2011-06-23 01:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 01:48:28 --> Database Driver Class Initialized
DEBUG - 2011-06-23 01:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 01:48:28 --> Helper loaded: url_helper
DEBUG - 2011-06-23 01:48:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 01:48:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 01:48:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 01:48:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 01:48:28 --> Final output sent to browser
DEBUG - 2011-06-23 01:48:28 --> Total execution time: 0.1687
DEBUG - 2011-06-23 03:31:25 --> Config Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Hooks Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Utf8 Class Initialized
DEBUG - 2011-06-23 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 03:31:25 --> URI Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Router Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Output Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Input Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 03:31:25 --> Language Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Loader Class Initialized
DEBUG - 2011-06-23 03:31:25 --> Controller Class Initialized
DEBUG - 2011-06-23 03:31:26 --> Model Class Initialized
DEBUG - 2011-06-23 03:31:26 --> Model Class Initialized
DEBUG - 2011-06-23 03:31:26 --> Model Class Initialized
DEBUG - 2011-06-23 03:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 03:31:26 --> Database Driver Class Initialized
DEBUG - 2011-06-23 03:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 03:31:27 --> Helper loaded: url_helper
DEBUG - 2011-06-23 03:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 03:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 03:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 03:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 03:31:27 --> Final output sent to browser
DEBUG - 2011-06-23 03:31:27 --> Total execution time: 1.7207
DEBUG - 2011-06-23 05:18:26 --> Config Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Hooks Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Utf8 Class Initialized
DEBUG - 2011-06-23 05:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 05:18:26 --> URI Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Router Class Initialized
DEBUG - 2011-06-23 05:18:26 --> No URI present. Default controller set.
DEBUG - 2011-06-23 05:18:26 --> Output Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Input Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 05:18:26 --> Language Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Loader Class Initialized
DEBUG - 2011-06-23 05:18:26 --> Controller Class Initialized
DEBUG - 2011-06-23 05:18:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-23 05:18:26 --> Helper loaded: url_helper
DEBUG - 2011-06-23 05:18:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 05:18:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 05:18:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 05:18:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 05:18:26 --> Final output sent to browser
DEBUG - 2011-06-23 05:18:26 --> Total execution time: 0.3101
DEBUG - 2011-06-23 07:32:08 --> Config Class Initialized
DEBUG - 2011-06-23 07:32:08 --> Hooks Class Initialized
DEBUG - 2011-06-23 07:32:08 --> Utf8 Class Initialized
DEBUG - 2011-06-23 07:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 07:32:08 --> URI Class Initialized
DEBUG - 2011-06-23 07:32:08 --> Router Class Initialized
ERROR - 2011-06-23 07:32:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 07:34:02 --> Config Class Initialized
DEBUG - 2011-06-23 07:34:02 --> Hooks Class Initialized
DEBUG - 2011-06-23 07:34:02 --> Utf8 Class Initialized
DEBUG - 2011-06-23 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 07:34:02 --> URI Class Initialized
DEBUG - 2011-06-23 07:34:02 --> Router Class Initialized
DEBUG - 2011-06-23 07:34:02 --> Output Class Initialized
DEBUG - 2011-06-23 07:34:02 --> Input Class Initialized
DEBUG - 2011-06-23 07:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 07:34:03 --> Language Class Initialized
DEBUG - 2011-06-23 07:34:03 --> Loader Class Initialized
DEBUG - 2011-06-23 07:34:03 --> Controller Class Initialized
DEBUG - 2011-06-23 07:34:03 --> Model Class Initialized
DEBUG - 2011-06-23 07:34:03 --> Model Class Initialized
DEBUG - 2011-06-23 07:34:03 --> Model Class Initialized
DEBUG - 2011-06-23 07:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 07:34:03 --> Database Driver Class Initialized
DEBUG - 2011-06-23 07:34:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 07:34:04 --> Helper loaded: url_helper
DEBUG - 2011-06-23 07:34:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 07:34:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 07:34:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 07:34:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 07:34:04 --> Final output sent to browser
DEBUG - 2011-06-23 07:34:04 --> Total execution time: 1.6656
DEBUG - 2011-06-23 07:34:05 --> Config Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Hooks Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Utf8 Class Initialized
DEBUG - 2011-06-23 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 07:34:05 --> URI Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Router Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Output Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Input Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 07:34:05 --> Language Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Loader Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Controller Class Initialized
ERROR - 2011-06-23 07:34:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-23 07:34:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-23 07:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 07:34:05 --> Model Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Model Class Initialized
DEBUG - 2011-06-23 07:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 07:34:05 --> Database Driver Class Initialized
DEBUG - 2011-06-23 07:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 07:34:05 --> Helper loaded: url_helper
DEBUG - 2011-06-23 07:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 07:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 07:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 07:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 07:34:05 --> Final output sent to browser
DEBUG - 2011-06-23 07:34:05 --> Total execution time: 0.1146
DEBUG - 2011-06-23 09:11:25 --> Config Class Initialized
DEBUG - 2011-06-23 09:11:25 --> Hooks Class Initialized
DEBUG - 2011-06-23 09:11:25 --> Utf8 Class Initialized
DEBUG - 2011-06-23 09:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 09:11:25 --> URI Class Initialized
DEBUG - 2011-06-23 09:11:25 --> Router Class Initialized
ERROR - 2011-06-23 09:11:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 09:12:12 --> Config Class Initialized
DEBUG - 2011-06-23 09:12:12 --> Hooks Class Initialized
DEBUG - 2011-06-23 09:12:12 --> Utf8 Class Initialized
DEBUG - 2011-06-23 09:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 09:12:12 --> URI Class Initialized
DEBUG - 2011-06-23 09:12:12 --> Router Class Initialized
DEBUG - 2011-06-23 09:12:12 --> No URI present. Default controller set.
DEBUG - 2011-06-23 09:12:12 --> Output Class Initialized
DEBUG - 2011-06-23 09:12:12 --> Input Class Initialized
DEBUG - 2011-06-23 09:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 09:12:12 --> Language Class Initialized
DEBUG - 2011-06-23 09:12:12 --> Loader Class Initialized
DEBUG - 2011-06-23 09:12:13 --> Controller Class Initialized
DEBUG - 2011-06-23 09:12:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-23 09:12:13 --> Helper loaded: url_helper
DEBUG - 2011-06-23 09:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 09:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 09:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 09:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 09:12:13 --> Final output sent to browser
DEBUG - 2011-06-23 09:12:13 --> Total execution time: 0.5607
DEBUG - 2011-06-23 10:48:35 --> Config Class Initialized
DEBUG - 2011-06-23 10:48:35 --> Hooks Class Initialized
DEBUG - 2011-06-23 10:48:35 --> Utf8 Class Initialized
DEBUG - 2011-06-23 10:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 10:48:35 --> URI Class Initialized
DEBUG - 2011-06-23 10:48:35 --> Router Class Initialized
ERROR - 2011-06-23 10:48:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 10:48:36 --> Config Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Hooks Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Utf8 Class Initialized
DEBUG - 2011-06-23 10:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 10:48:36 --> URI Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Router Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Output Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Input Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 10:48:36 --> Language Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Loader Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Controller Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Model Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Model Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Model Class Initialized
DEBUG - 2011-06-23 10:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 10:48:36 --> Database Driver Class Initialized
DEBUG - 2011-06-23 10:48:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 10:48:36 --> Helper loaded: url_helper
DEBUG - 2011-06-23 10:48:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 10:48:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 10:48:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 10:48:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 10:48:36 --> Final output sent to browser
DEBUG - 2011-06-23 10:48:36 --> Total execution time: 0.7299
DEBUG - 2011-06-23 12:53:01 --> Config Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Hooks Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Utf8 Class Initialized
DEBUG - 2011-06-23 12:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 12:53:01 --> URI Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Router Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Output Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Input Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 12:53:01 --> Language Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Loader Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Controller Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Model Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Model Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Model Class Initialized
DEBUG - 2011-06-23 12:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 12:53:01 --> Database Driver Class Initialized
DEBUG - 2011-06-23 12:53:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 12:53:02 --> Helper loaded: url_helper
DEBUG - 2011-06-23 12:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 12:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 12:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 12:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 12:53:02 --> Final output sent to browser
DEBUG - 2011-06-23 12:53:02 --> Total execution time: 1.1371
DEBUG - 2011-06-23 12:53:03 --> Config Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Hooks Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Utf8 Class Initialized
DEBUG - 2011-06-23 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 12:53:03 --> URI Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Router Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Output Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Input Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 12:53:03 --> Language Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Loader Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Controller Class Initialized
ERROR - 2011-06-23 12:53:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-23 12:53:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-23 12:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 12:53:03 --> Model Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Model Class Initialized
DEBUG - 2011-06-23 12:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 12:53:03 --> Database Driver Class Initialized
DEBUG - 2011-06-23 12:53:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 12:53:03 --> Helper loaded: url_helper
DEBUG - 2011-06-23 12:53:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 12:53:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 12:53:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 12:53:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 12:53:03 --> Final output sent to browser
DEBUG - 2011-06-23 12:53:03 --> Total execution time: 0.1568
DEBUG - 2011-06-23 15:21:37 --> Config Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Hooks Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Utf8 Class Initialized
DEBUG - 2011-06-23 15:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 15:21:37 --> URI Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Router Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Output Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Input Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 15:21:37 --> Language Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Loader Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Controller Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 15:21:37 --> Database Driver Class Initialized
DEBUG - 2011-06-23 15:21:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 15:21:38 --> Helper loaded: url_helper
DEBUG - 2011-06-23 15:21:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 15:21:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 15:21:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 15:21:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 15:21:38 --> Final output sent to browser
DEBUG - 2011-06-23 15:21:38 --> Total execution time: 0.6459
DEBUG - 2011-06-23 15:21:39 --> Config Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Hooks Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Utf8 Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Config Class Initialized
DEBUG - 2011-06-23 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 15:21:39 --> Hooks Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Utf8 Class Initialized
DEBUG - 2011-06-23 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 15:21:39 --> URI Class Initialized
DEBUG - 2011-06-23 15:21:39 --> URI Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Router Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Router Class Initialized
ERROR - 2011-06-23 15:21:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-23 15:21:39 --> Output Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Input Class Initialized
DEBUG - 2011-06-23 15:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 15:21:39 --> Language Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Loader Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Controller Class Initialized
ERROR - 2011-06-23 15:21:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-23 15:21:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-23 15:21:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 15:21:40 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 15:21:40 --> Database Driver Class Initialized
DEBUG - 2011-06-23 15:21:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 15:21:40 --> Helper loaded: url_helper
DEBUG - 2011-06-23 15:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 15:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 15:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 15:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 15:21:40 --> Final output sent to browser
DEBUG - 2011-06-23 15:21:40 --> Total execution time: 0.1006
DEBUG - 2011-06-23 15:21:40 --> Config Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Hooks Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Utf8 Class Initialized
DEBUG - 2011-06-23 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 15:21:40 --> URI Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Router Class Initialized
ERROR - 2011-06-23 15:21:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-23 15:21:40 --> Config Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Hooks Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Utf8 Class Initialized
DEBUG - 2011-06-23 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 15:21:40 --> URI Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Router Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Output Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Input Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 15:21:40 --> Language Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Loader Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Controller Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Model Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 15:21:40 --> Config Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Hooks Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Utf8 Class Initialized
DEBUG - 2011-06-23 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 15:21:40 --> URI Class Initialized
DEBUG - 2011-06-23 15:21:40 --> Router Class Initialized
ERROR - 2011-06-23 15:21:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-23 15:21:40 --> Database Driver Class Initialized
DEBUG - 2011-06-23 15:21:41 --> Final output sent to browser
DEBUG - 2011-06-23 15:21:41 --> Total execution time: 0.6101
DEBUG - 2011-06-23 17:41:29 --> Config Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Hooks Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Config Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Hooks Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Utf8 Class Initialized
DEBUG - 2011-06-23 17:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 17:41:29 --> Utf8 Class Initialized
DEBUG - 2011-06-23 17:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 17:41:29 --> URI Class Initialized
DEBUG - 2011-06-23 17:41:29 --> URI Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Router Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Router Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Output Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Output Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Input Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 17:41:29 --> Input Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 17:41:29 --> Language Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Language Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Loader Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Loader Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Controller Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Controller Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Model Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Model Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Model Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Model Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Model Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Model Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 17:41:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 17:41:29 --> Database Driver Class Initialized
DEBUG - 2011-06-23 17:41:29 --> Database Driver Class Initialized
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 17:41:29 --> Helper loaded: url_helper
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 17:41:29 --> Helper loaded: url_helper
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 17:41:29 --> Final output sent to browser
DEBUG - 2011-06-23 17:41:29 --> Total execution time: 0.6628
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 17:41:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 17:41:29 --> Final output sent to browser
DEBUG - 2011-06-23 17:41:29 --> Total execution time: 0.6691
DEBUG - 2011-06-23 18:07:10 --> Config Class Initialized
DEBUG - 2011-06-23 18:07:10 --> Hooks Class Initialized
DEBUG - 2011-06-23 18:07:10 --> Utf8 Class Initialized
DEBUG - 2011-06-23 18:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 18:07:10 --> URI Class Initialized
DEBUG - 2011-06-23 18:07:10 --> Router Class Initialized
ERROR - 2011-06-23 18:07:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 19:14:03 --> Config Class Initialized
DEBUG - 2011-06-23 19:14:03 --> Hooks Class Initialized
DEBUG - 2011-06-23 19:14:03 --> Utf8 Class Initialized
DEBUG - 2011-06-23 19:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 19:14:03 --> URI Class Initialized
DEBUG - 2011-06-23 19:14:03 --> Router Class Initialized
ERROR - 2011-06-23 19:14:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 20:26:27 --> Config Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Hooks Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Utf8 Class Initialized
DEBUG - 2011-06-23 20:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 20:26:27 --> URI Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Router Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Output Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Input Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 20:26:27 --> Language Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Loader Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Controller Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Model Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Model Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Model Class Initialized
DEBUG - 2011-06-23 20:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 20:26:27 --> Database Driver Class Initialized
DEBUG - 2011-06-23 20:26:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 20:26:28 --> Helper loaded: url_helper
DEBUG - 2011-06-23 20:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 20:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 20:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 20:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 20:26:28 --> Final output sent to browser
DEBUG - 2011-06-23 20:26:28 --> Total execution time: 0.6646
DEBUG - 2011-06-23 21:00:14 --> Config Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Hooks Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Utf8 Class Initialized
DEBUG - 2011-06-23 21:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 21:00:14 --> URI Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Router Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Output Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Input Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 21:00:14 --> Language Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Loader Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Controller Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Model Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Model Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Model Class Initialized
DEBUG - 2011-06-23 21:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 21:00:14 --> Database Driver Class Initialized
DEBUG - 2011-06-23 21:00:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-23 21:00:14 --> Helper loaded: url_helper
DEBUG - 2011-06-23 21:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 21:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 21:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 21:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 21:00:14 --> Final output sent to browser
DEBUG - 2011-06-23 21:00:14 --> Total execution time: 0.4864
DEBUG - 2011-06-23 23:22:58 --> Config Class Initialized
DEBUG - 2011-06-23 23:22:58 --> Hooks Class Initialized
DEBUG - 2011-06-23 23:22:58 --> Utf8 Class Initialized
DEBUG - 2011-06-23 23:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 23:22:58 --> URI Class Initialized
DEBUG - 2011-06-23 23:22:58 --> Router Class Initialized
ERROR - 2011-06-23 23:22:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-23 23:22:59 --> Config Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Hooks Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Utf8 Class Initialized
DEBUG - 2011-06-23 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-23 23:22:59 --> URI Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Router Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Output Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Input Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-23 23:22:59 --> Language Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Loader Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Controller Class Initialized
ERROR - 2011-06-23 23:22:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-23 23:22:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-23 23:22:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 23:22:59 --> Model Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Model Class Initialized
DEBUG - 2011-06-23 23:22:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-23 23:22:59 --> Database Driver Class Initialized
DEBUG - 2011-06-23 23:22:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-23 23:22:59 --> Helper loaded: url_helper
DEBUG - 2011-06-23 23:22:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-23 23:22:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-23 23:22:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-23 23:22:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-23 23:22:59 --> Final output sent to browser
DEBUG - 2011-06-23 23:22:59 --> Total execution time: 0.2438

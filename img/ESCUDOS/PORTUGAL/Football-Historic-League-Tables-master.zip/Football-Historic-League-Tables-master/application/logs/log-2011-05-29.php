<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-29 00:33:15 --> Config Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Hooks Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Utf8 Class Initialized
DEBUG - 2011-05-29 00:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 00:33:15 --> URI Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Router Class Initialized
ERROR - 2011-05-29 00:33:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 00:33:15 --> Config Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Hooks Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Utf8 Class Initialized
DEBUG - 2011-05-29 00:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 00:33:15 --> URI Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Router Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Output Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Input Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 00:33:15 --> Language Class Initialized
DEBUG - 2011-05-29 00:33:15 --> Loader Class Initialized
DEBUG - 2011-05-29 00:33:16 --> Controller Class Initialized
DEBUG - 2011-05-29 00:33:16 --> Model Class Initialized
DEBUG - 2011-05-29 00:33:16 --> Model Class Initialized
DEBUG - 2011-05-29 00:33:16 --> Model Class Initialized
DEBUG - 2011-05-29 00:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 00:33:16 --> Database Driver Class Initialized
DEBUG - 2011-05-29 00:33:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 00:33:16 --> Helper loaded: url_helper
DEBUG - 2011-05-29 00:33:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 00:33:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 00:33:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 00:33:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 00:33:16 --> Final output sent to browser
DEBUG - 2011-05-29 00:33:16 --> Total execution time: 0.9223
DEBUG - 2011-05-29 01:17:24 --> Config Class Initialized
DEBUG - 2011-05-29 01:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:17:24 --> URI Class Initialized
DEBUG - 2011-05-29 01:17:24 --> Router Class Initialized
ERROR - 2011-05-29 01:17:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 01:17:25 --> Config Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:17:25 --> URI Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Router Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Output Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Input Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 01:17:25 --> Language Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Loader Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Controller Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Model Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Model Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Model Class Initialized
DEBUG - 2011-05-29 01:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 01:17:25 --> Database Driver Class Initialized
DEBUG - 2011-05-29 01:17:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 01:17:25 --> Helper loaded: url_helper
DEBUG - 2011-05-29 01:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 01:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 01:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 01:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 01:17:25 --> Final output sent to browser
DEBUG - 2011-05-29 01:17:25 --> Total execution time: 0.3903
DEBUG - 2011-05-29 01:17:55 --> Config Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:17:55 --> URI Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Router Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Output Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Input Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 01:17:55 --> Language Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Loader Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Controller Class Initialized
ERROR - 2011-05-29 01:17:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 01:17:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 01:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 01:17:55 --> Model Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Model Class Initialized
DEBUG - 2011-05-29 01:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 01:17:55 --> Database Driver Class Initialized
DEBUG - 2011-05-29 01:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 01:17:55 --> Helper loaded: url_helper
DEBUG - 2011-05-29 01:17:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 01:17:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 01:17:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 01:17:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 01:17:55 --> Final output sent to browser
DEBUG - 2011-05-29 01:17:55 --> Total execution time: 0.0919
DEBUG - 2011-05-29 01:29:11 --> Config Class Initialized
DEBUG - 2011-05-29 01:29:11 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:29:11 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:29:11 --> URI Class Initialized
DEBUG - 2011-05-29 01:29:11 --> Router Class Initialized
DEBUG - 2011-05-29 01:29:12 --> No URI present. Default controller set.
DEBUG - 2011-05-29 01:29:12 --> Output Class Initialized
DEBUG - 2011-05-29 01:29:12 --> Input Class Initialized
DEBUG - 2011-05-29 01:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 01:29:12 --> Language Class Initialized
DEBUG - 2011-05-29 01:29:12 --> Loader Class Initialized
DEBUG - 2011-05-29 01:29:12 --> Controller Class Initialized
DEBUG - 2011-05-29 01:29:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 01:29:12 --> Helper loaded: url_helper
DEBUG - 2011-05-29 01:29:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 01:29:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 01:29:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 01:29:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 01:29:12 --> Final output sent to browser
DEBUG - 2011-05-29 01:29:12 --> Total execution time: 0.0878
DEBUG - 2011-05-29 01:34:57 --> Config Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:34:57 --> URI Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Router Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Output Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Input Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 01:34:57 --> Language Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Loader Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Controller Class Initialized
DEBUG - 2011-05-29 01:34:57 --> Model Class Initialized
DEBUG - 2011-05-29 01:34:59 --> Model Class Initialized
DEBUG - 2011-05-29 01:34:59 --> Model Class Initialized
DEBUG - 2011-05-29 01:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 01:34:59 --> Database Driver Class Initialized
DEBUG - 2011-05-29 01:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 01:35:00 --> Helper loaded: url_helper
DEBUG - 2011-05-29 01:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 01:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 01:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 01:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 01:35:00 --> Final output sent to browser
DEBUG - 2011-05-29 01:35:00 --> Total execution time: 4.3530
DEBUG - 2011-05-29 01:37:00 --> Config Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:37:00 --> URI Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Router Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Output Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Input Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 01:37:00 --> Language Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Loader Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Controller Class Initialized
ERROR - 2011-05-29 01:37:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 01:37:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 01:37:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 01:37:00 --> Model Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Model Class Initialized
DEBUG - 2011-05-29 01:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 01:37:00 --> Database Driver Class Initialized
DEBUG - 2011-05-29 01:37:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 01:37:00 --> Helper loaded: url_helper
DEBUG - 2011-05-29 01:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 01:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 01:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 01:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 01:37:00 --> Final output sent to browser
DEBUG - 2011-05-29 01:37:00 --> Total execution time: 0.1946
DEBUG - 2011-05-29 01:54:29 --> Config Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Hooks Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Utf8 Class Initialized
DEBUG - 2011-05-29 01:54:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 01:54:29 --> URI Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Router Class Initialized
DEBUG - 2011-05-29 01:54:29 --> No URI present. Default controller set.
DEBUG - 2011-05-29 01:54:29 --> Output Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Input Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 01:54:29 --> Language Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Loader Class Initialized
DEBUG - 2011-05-29 01:54:29 --> Controller Class Initialized
DEBUG - 2011-05-29 01:54:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 01:54:29 --> Helper loaded: url_helper
DEBUG - 2011-05-29 01:54:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 01:54:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 01:54:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 01:54:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 01:54:29 --> Final output sent to browser
DEBUG - 2011-05-29 01:54:29 --> Total execution time: 0.2584
DEBUG - 2011-05-29 02:07:39 --> Config Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Hooks Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Utf8 Class Initialized
DEBUG - 2011-05-29 02:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 02:07:39 --> URI Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Router Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Output Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Input Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 02:07:39 --> Language Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Loader Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Controller Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 02:07:39 --> Database Driver Class Initialized
DEBUG - 2011-05-29 02:07:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 02:07:41 --> Helper loaded: url_helper
DEBUG - 2011-05-29 02:07:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 02:07:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 02:07:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 02:07:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 02:07:41 --> Final output sent to browser
DEBUG - 2011-05-29 02:07:41 --> Total execution time: 2.9188
DEBUG - 2011-05-29 02:07:44 --> Config Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Hooks Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Utf8 Class Initialized
DEBUG - 2011-05-29 02:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 02:07:44 --> URI Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Router Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Output Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Input Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 02:07:44 --> Language Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Loader Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Controller Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 02:07:44 --> Database Driver Class Initialized
DEBUG - 2011-05-29 02:07:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 02:07:44 --> Helper loaded: url_helper
DEBUG - 2011-05-29 02:07:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 02:07:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 02:07:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 02:07:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 02:07:44 --> Final output sent to browser
DEBUG - 2011-05-29 02:07:44 --> Total execution time: 0.0561
DEBUG - 2011-05-29 02:07:54 --> Config Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 02:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 02:07:54 --> URI Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Router Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Output Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Input Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 02:07:54 --> Language Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Loader Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Controller Class Initialized
ERROR - 2011-05-29 02:07:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 02:07:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 02:07:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 02:07:54 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 02:07:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 02:07:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 02:07:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 02:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 02:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 02:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 02:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 02:07:54 --> Final output sent to browser
DEBUG - 2011-05-29 02:07:54 --> Total execution time: 0.1666
DEBUG - 2011-05-29 02:07:55 --> Config Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 02:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 02:07:55 --> URI Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Router Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Output Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Input Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 02:07:55 --> Language Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Loader Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Controller Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 02:07:55 --> Database Driver Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Config Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 02:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 02:07:55 --> URI Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Router Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Output Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Input Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 02:07:55 --> Language Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Loader Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Controller Class Initialized
ERROR - 2011-05-29 02:07:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 02:07:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 02:07:55 --> Database Driver Class Initialized
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 02:07:55 --> Helper loaded: url_helper
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 02:07:55 --> Final output sent to browser
DEBUG - 2011-05-29 02:07:55 --> Total execution time: 0.0332
DEBUG - 2011-05-29 02:07:55 --> Config Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 02:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 02:07:55 --> URI Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Router Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Output Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Input Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 02:07:55 --> Language Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Loader Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Controller Class Initialized
ERROR - 2011-05-29 02:07:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 02:07:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 02:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-05-29 02:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 02:07:56 --> Database Driver Class Initialized
DEBUG - 2011-05-29 02:07:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 02:07:56 --> Helper loaded: url_helper
DEBUG - 2011-05-29 02:07:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 02:07:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 02:07:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 02:07:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 02:07:56 --> Final output sent to browser
DEBUG - 2011-05-29 02:07:56 --> Total execution time: 0.0373
DEBUG - 2011-05-29 02:07:57 --> Final output sent to browser
DEBUG - 2011-05-29 02:07:57 --> Total execution time: 1.7011
DEBUG - 2011-05-29 03:13:06 --> Config Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Hooks Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Utf8 Class Initialized
DEBUG - 2011-05-29 03:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 03:13:06 --> URI Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Router Class Initialized
DEBUG - 2011-05-29 03:13:06 --> No URI present. Default controller set.
DEBUG - 2011-05-29 03:13:06 --> Output Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Input Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 03:13:06 --> Language Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Loader Class Initialized
DEBUG - 2011-05-29 03:13:06 --> Controller Class Initialized
DEBUG - 2011-05-29 03:13:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 03:13:06 --> Helper loaded: url_helper
DEBUG - 2011-05-29 03:13:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 03:13:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 03:13:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 03:13:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 03:13:06 --> Final output sent to browser
DEBUG - 2011-05-29 03:13:06 --> Total execution time: 0.4804
DEBUG - 2011-05-29 03:47:48 --> Config Class Initialized
DEBUG - 2011-05-29 03:47:48 --> Hooks Class Initialized
DEBUG - 2011-05-29 03:47:48 --> Utf8 Class Initialized
DEBUG - 2011-05-29 03:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 03:47:48 --> URI Class Initialized
DEBUG - 2011-05-29 03:47:48 --> Router Class Initialized
ERROR - 2011-05-29 03:47:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 03:47:49 --> Config Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Hooks Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Utf8 Class Initialized
DEBUG - 2011-05-29 03:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 03:47:49 --> URI Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Router Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Output Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Input Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 03:47:49 --> Language Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Loader Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Controller Class Initialized
ERROR - 2011-05-29 03:47:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 03:47:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 03:47:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 03:47:49 --> Model Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Model Class Initialized
DEBUG - 2011-05-29 03:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 03:47:49 --> Database Driver Class Initialized
DEBUG - 2011-05-29 03:47:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 03:47:49 --> Helper loaded: url_helper
DEBUG - 2011-05-29 03:47:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 03:47:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 03:47:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 03:47:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 03:47:49 --> Final output sent to browser
DEBUG - 2011-05-29 03:47:49 --> Total execution time: 0.7257
DEBUG - 2011-05-29 03:47:51 --> Config Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Hooks Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Utf8 Class Initialized
DEBUG - 2011-05-29 03:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 03:47:51 --> URI Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Router Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Output Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Input Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 03:47:51 --> Language Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Loader Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Controller Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Model Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Model Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Model Class Initialized
DEBUG - 2011-05-29 03:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 03:47:51 --> Database Driver Class Initialized
DEBUG - 2011-05-29 03:47:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 03:47:53 --> Helper loaded: url_helper
DEBUG - 2011-05-29 03:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 03:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 03:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 03:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 03:47:53 --> Final output sent to browser
DEBUG - 2011-05-29 03:47:53 --> Total execution time: 1.3663
DEBUG - 2011-05-29 03:57:35 --> Config Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Hooks Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Utf8 Class Initialized
DEBUG - 2011-05-29 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 03:57:35 --> URI Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Router Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Output Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Input Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 03:57:35 --> Language Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Loader Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Controller Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Model Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Model Class Initialized
DEBUG - 2011-05-29 03:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 03:57:35 --> Database Driver Class Initialized
DEBUG - 2011-05-29 03:57:36 --> Final output sent to browser
DEBUG - 2011-05-29 03:57:36 --> Total execution time: 1.3536
DEBUG - 2011-05-29 05:21:21 --> Config Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Hooks Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Utf8 Class Initialized
DEBUG - 2011-05-29 05:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 05:21:21 --> URI Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Router Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Output Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Input Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 05:21:21 --> Language Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Loader Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Controller Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Model Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Model Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Model Class Initialized
DEBUG - 2011-05-29 05:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 05:21:21 --> Database Driver Class Initialized
DEBUG - 2011-05-29 05:21:21 --> DB Transaction Failure
ERROR - 2011-05-29 05:21:21 --> Query error: Lost connection to MySQL server during query
DEBUG - 2011-05-29 05:21:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-05-29 06:30:27 --> Config Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:30:27 --> URI Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Router Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Output Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Input Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:30:27 --> Language Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Loader Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Controller Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Model Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Model Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Model Class Initialized
DEBUG - 2011-05-29 06:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:30:27 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:30:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:30:29 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:30:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:30:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:30:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:30:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:30:29 --> Final output sent to browser
DEBUG - 2011-05-29 06:30:29 --> Total execution time: 1.3743
DEBUG - 2011-05-29 06:30:32 --> Config Class Initialized
DEBUG - 2011-05-29 06:30:32 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:30:32 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:30:32 --> URI Class Initialized
DEBUG - 2011-05-29 06:30:32 --> Router Class Initialized
ERROR - 2011-05-29 06:30:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:30:32 --> Config Class Initialized
DEBUG - 2011-05-29 06:30:32 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:30:32 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:30:32 --> URI Class Initialized
DEBUG - 2011-05-29 06:30:32 --> Router Class Initialized
ERROR - 2011-05-29 06:30:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:31:13 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:13 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:13 --> No URI present. Default controller set.
DEBUG - 2011-05-29 06:31:13 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:13 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:13 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 06:31:13 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:13 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:13 --> Total execution time: 0.0724
DEBUG - 2011-05-29 06:31:19 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:19 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:19 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:19 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:19 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:19 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:19 --> Total execution time: 0.0525
DEBUG - 2011-05-29 06:31:28 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:28 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:28 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:28 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:29 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:29 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:29 --> Total execution time: 0.7633
DEBUG - 2011-05-29 06:31:30 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:30 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:30 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:30 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:30 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:30 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:30 --> Total execution time: 0.0507
DEBUG - 2011-05-29 06:31:39 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:39 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:39 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:39 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:40 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:40 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:40 --> Total execution time: 0.4005
DEBUG - 2011-05-29 06:31:41 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:41 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:41 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:41 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:41 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:41 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:41 --> Total execution time: 0.0490
DEBUG - 2011-05-29 06:31:43 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:43 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:43 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:43 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:43 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:43 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:43 --> Total execution time: 0.0449
DEBUG - 2011-05-29 06:31:51 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:51 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:51 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:51 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:51 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:51 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:51 --> Total execution time: 0.3489
DEBUG - 2011-05-29 06:31:52 --> Config Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:31:52 --> URI Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Router Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Output Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Input Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:31:52 --> Language Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Loader Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Controller Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Model Class Initialized
DEBUG - 2011-05-29 06:31:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:31:52 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:31:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:31:52 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:31:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:31:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:31:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:31:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:31:52 --> Final output sent to browser
DEBUG - 2011-05-29 06:31:52 --> Total execution time: 0.0514
DEBUG - 2011-05-29 06:32:00 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:00 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:00 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:00 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:00 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:00 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:00 --> Total execution time: 0.3937
DEBUG - 2011-05-29 06:32:02 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:02 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:02 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:02 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:02 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:02 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:02 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:02 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:02 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:02 --> Total execution time: 0.2928
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:02 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:02 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:02 --> Total execution time: 0.0952
DEBUG - 2011-05-29 06:32:12 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:12 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:12 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:12 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:12 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:12 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:12 --> Total execution time: 0.4473
DEBUG - 2011-05-29 06:32:13 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:13 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:13 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:13 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:13 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:13 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:13 --> Total execution time: 0.0567
DEBUG - 2011-05-29 06:32:15 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:15 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:15 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:15 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:15 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:15 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:15 --> Total execution time: 0.0561
DEBUG - 2011-05-29 06:32:22 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:22 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:22 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:22 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:22 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:22 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:22 --> Total execution time: 0.2121
DEBUG - 2011-05-29 06:32:23 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:23 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:23 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:23 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:23 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:23 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:23 --> Total execution time: 0.0498
DEBUG - 2011-05-29 06:32:24 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:24 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:24 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:24 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:24 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:24 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:24 --> Total execution time: 0.0517
DEBUG - 2011-05-29 06:32:32 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:32 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:32 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:32 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:32 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:32 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:32 --> Total execution time: 0.2768
DEBUG - 2011-05-29 06:32:33 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:33 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:33 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:33 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:33 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:33 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:33 --> Total execution time: 0.1010
DEBUG - 2011-05-29 06:32:33 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:33 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:33 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:33 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:33 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:33 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:33 --> Total execution time: 0.0606
DEBUG - 2011-05-29 06:32:33 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:33 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:33 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:33 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:33 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:33 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:33 --> Total execution time: 0.0926
DEBUG - 2011-05-29 06:32:41 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:41 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:41 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:41 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:41 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:41 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:41 --> Total execution time: 0.2408
DEBUG - 2011-05-29 06:32:42 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:42 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:42 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:42 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:42 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:42 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:42 --> Total execution time: 0.0491
DEBUG - 2011-05-29 06:32:43 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:43 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:43 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:43 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:43 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:43 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:43 --> Total execution time: 0.0632
DEBUG - 2011-05-29 06:32:48 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:48 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:48 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:48 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:48 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:48 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:48 --> Total execution time: 0.4948
DEBUG - 2011-05-29 06:32:54 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:54 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:54 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:54 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:54 --> Total execution time: 0.0496
DEBUG - 2011-05-29 06:32:54 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:54 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:54 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:55 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:55 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:55 --> Total execution time: 0.5492
DEBUG - 2011-05-29 06:32:57 --> Config Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:32:57 --> URI Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Router Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Output Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Input Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:32:57 --> Language Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Loader Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Controller Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:32:57 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:32:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:32:57 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:32:57 --> Final output sent to browser
DEBUG - 2011-05-29 06:32:57 --> Total execution time: 0.0483
DEBUG - 2011-05-29 06:33:06 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:06 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:06 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:06 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:07 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:07 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:07 --> Total execution time: 0.2785
DEBUG - 2011-05-29 06:33:14 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:14 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:14 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:14 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:15 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:15 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:15 --> Total execution time: 0.2714
DEBUG - 2011-05-29 06:33:15 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:15 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:15 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:15 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:15 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:15 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:15 --> Total execution time: 0.0716
DEBUG - 2011-05-29 06:33:20 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:20 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:20 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:20 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:20 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:20 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:20 --> Total execution time: 0.0591
DEBUG - 2011-05-29 06:33:32 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:32 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:32 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:32 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:32 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:32 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:32 --> Total execution time: 0.3960
DEBUG - 2011-05-29 06:33:34 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:34 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:34 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:34 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:34 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:34 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:34 --> Total execution time: 0.0483
DEBUG - 2011-05-29 06:33:40 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:40 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:40 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:40 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:41 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:41 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:41 --> Total execution time: 0.3173
DEBUG - 2011-05-29 06:33:45 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:45 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:45 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:45 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:45 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:45 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:45 --> Total execution time: 0.0978
DEBUG - 2011-05-29 06:33:47 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:47 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:47 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:47 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:48 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:48 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:48 --> Total execution time: 0.3560
DEBUG - 2011-05-29 06:33:54 --> Config Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:33:54 --> URI Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Router Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Output Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Input Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:33:54 --> Language Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Loader Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Controller Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:33:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:33:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:33:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:33:54 --> Final output sent to browser
DEBUG - 2011-05-29 06:33:54 --> Total execution time: 0.0494
DEBUG - 2011-05-29 06:47:54 --> Config Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:47:54 --> URI Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Router Class Initialized
DEBUG - 2011-05-29 06:47:54 --> No URI present. Default controller set.
DEBUG - 2011-05-29 06:47:54 --> Output Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Input Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:47:54 --> Language Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Loader Class Initialized
DEBUG - 2011-05-29 06:47:54 --> Controller Class Initialized
DEBUG - 2011-05-29 06:47:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 06:47:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:47:54 --> Final output sent to browser
DEBUG - 2011-05-29 06:47:54 --> Total execution time: 0.1437
DEBUG - 2011-05-29 06:48:01 --> Config Class Initialized
DEBUG - 2011-05-29 06:48:01 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:48:01 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:48:01 --> URI Class Initialized
DEBUG - 2011-05-29 06:48:01 --> Router Class Initialized
ERROR - 2011-05-29 06:48:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:48:01 --> Config Class Initialized
DEBUG - 2011-05-29 06:48:01 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:48:01 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:48:01 --> URI Class Initialized
DEBUG - 2011-05-29 06:48:01 --> Router Class Initialized
ERROR - 2011-05-29 06:48:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:53:54 --> Config Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:53:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:53:54 --> URI Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Router Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Output Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Input Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:53:54 --> Language Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Loader Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Controller Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Model Class Initialized
DEBUG - 2011-05-29 06:53:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:53:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:53:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:53:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:53:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:53:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:53:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:53:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:53:54 --> Final output sent to browser
DEBUG - 2011-05-29 06:53:54 --> Total execution time: 0.1809
DEBUG - 2011-05-29 06:53:59 --> Config Class Initialized
DEBUG - 2011-05-29 06:53:59 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:53:59 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:53:59 --> URI Class Initialized
DEBUG - 2011-05-29 06:53:59 --> Router Class Initialized
ERROR - 2011-05-29 06:53:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:54:37 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:37 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Router Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Output Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Input Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:54:37 --> Language Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Loader Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Controller Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:54:37 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:54:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:54:37 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:54:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:54:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:54:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:54:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:54:37 --> Final output sent to browser
DEBUG - 2011-05-29 06:54:37 --> Total execution time: 0.5024
DEBUG - 2011-05-29 06:54:38 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:38 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Router Class Initialized
ERROR - 2011-05-29 06:54:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 06:54:38 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:38 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Router Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Output Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Input Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:54:38 --> Language Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Loader Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Controller Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:54:38 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:54:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:54:38 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:54:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:54:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:54:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:54:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:54:38 --> Final output sent to browser
DEBUG - 2011-05-29 06:54:38 --> Total execution time: 0.0447
DEBUG - 2011-05-29 06:54:39 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:39 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:39 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:39 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:39 --> Router Class Initialized
ERROR - 2011-05-29 06:54:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:54:42 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:42 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Router Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Output Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Input Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:54:42 --> Language Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Loader Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Controller Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:54:42 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:54:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:54:42 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:54:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:54:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:54:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:54:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:54:42 --> Final output sent to browser
DEBUG - 2011-05-29 06:54:42 --> Total execution time: 0.4470
DEBUG - 2011-05-29 06:54:44 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:44 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Router Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Output Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Input Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:54:44 --> Language Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Loader Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Controller Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:54:44 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:54:44 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:54:44 --> Final output sent to browser
DEBUG - 2011-05-29 06:54:44 --> Total execution time: 0.0522
DEBUG - 2011-05-29 06:54:44 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:44 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:44 --> Router Class Initialized
ERROR - 2011-05-29 06:54:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:54:52 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:52 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Router Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Output Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Input Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:54:52 --> Language Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Loader Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Controller Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:54:52 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:54:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:54:52 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:54:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:54:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:54:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:54:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:54:52 --> Final output sent to browser
DEBUG - 2011-05-29 06:54:52 --> Total execution time: 0.0502
DEBUG - 2011-05-29 06:54:54 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:54 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:54 --> Router Class Initialized
ERROR - 2011-05-29 06:54:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:54:58 --> Config Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:54:58 --> URI Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Router Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Output Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Input Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:54:58 --> Language Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Loader Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Controller Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Model Class Initialized
DEBUG - 2011-05-29 06:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:54:58 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:54:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:54:59 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:54:59 --> Final output sent to browser
DEBUG - 2011-05-29 06:54:59 --> Total execution time: 0.6493
DEBUG - 2011-05-29 06:55:00 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:00 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:00 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:00 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:00 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:00 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:00 --> Total execution time: 0.1382
DEBUG - 2011-05-29 06:55:00 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:00 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:00 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:00 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:00 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:00 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:00 --> Total execution time: 0.0567
DEBUG - 2011-05-29 06:55:01 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:01 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:01 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:01 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:01 --> Router Class Initialized
ERROR - 2011-05-29 06:55:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 06:55:11 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:11 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:11 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:11 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:11 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:11 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:11 --> Total execution time: 0.2172
DEBUG - 2011-05-29 06:55:12 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:12 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:12 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:12 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:12 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:12 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:12 --> Total execution time: 0.0432
DEBUG - 2011-05-29 06:55:22 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:22 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:22 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:22 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:22 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:22 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:22 --> Total execution time: 0.4195
DEBUG - 2011-05-29 06:55:25 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:25 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:25 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:25 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:25 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:25 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:25 --> Total execution time: 0.0459
DEBUG - 2011-05-29 06:55:56 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:56 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:56 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:56 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:56 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:56 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:56 --> Total execution time: 0.2129
DEBUG - 2011-05-29 06:55:57 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:57 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:57 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:57 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:57 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:57 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:57 --> Total execution time: 0.0467
DEBUG - 2011-05-29 06:55:57 --> Config Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Hooks Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Utf8 Class Initialized
DEBUG - 2011-05-29 06:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 06:55:57 --> URI Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Router Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Output Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Input Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 06:55:57 --> Language Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Loader Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Controller Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Model Class Initialized
DEBUG - 2011-05-29 06:55:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 06:55:57 --> Database Driver Class Initialized
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 06:55:57 --> Helper loaded: url_helper
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 06:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 06:55:57 --> Final output sent to browser
DEBUG - 2011-05-29 06:55:57 --> Total execution time: 0.0517
DEBUG - 2011-05-29 07:11:52 --> Config Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:11:52 --> URI Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Router Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Output Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Input Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:11:52 --> Language Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Loader Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Controller Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Model Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Model Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Model Class Initialized
DEBUG - 2011-05-29 07:11:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:11:52 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:11:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:11:52 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:11:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:11:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:11:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:11:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:11:52 --> Final output sent to browser
DEBUG - 2011-05-29 07:11:52 --> Total execution time: 0.3591
DEBUG - 2011-05-29 07:11:57 --> Config Class Initialized
DEBUG - 2011-05-29 07:11:57 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:11:57 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:11:57 --> URI Class Initialized
DEBUG - 2011-05-29 07:11:57 --> Router Class Initialized
ERROR - 2011-05-29 07:11:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:11:58 --> Config Class Initialized
DEBUG - 2011-05-29 07:11:58 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:11:58 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:11:58 --> URI Class Initialized
DEBUG - 2011-05-29 07:11:58 --> Router Class Initialized
ERROR - 2011-05-29 07:11:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:12:05 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:05 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:05 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:05 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:06 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:06 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:06 --> Total execution time: 0.2533
DEBUG - 2011-05-29 07:12:07 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:07 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:07 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:07 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:07 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:07 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:07 --> Total execution time: 0.0442
DEBUG - 2011-05-29 07:12:08 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:08 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:08 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:08 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:08 --> Router Class Initialized
ERROR - 2011-05-29 07:12:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:12:25 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:25 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:25 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:25 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:26 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:26 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:26 --> Total execution time: 0.5498
DEBUG - 2011-05-29 07:12:26 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:26 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:26 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:26 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:26 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:26 --> Total execution time: 0.0454
DEBUG - 2011-05-29 07:12:27 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:27 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:27 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:27 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:27 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:27 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:27 --> Total execution time: 0.0503
DEBUG - 2011-05-29 07:12:28 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:28 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:28 --> Router Class Initialized
ERROR - 2011-05-29 07:12:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:12:34 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:34 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:34 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:34 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:35 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:35 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:35 --> Total execution time: 0.3253
DEBUG - 2011-05-29 07:12:40 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:40 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:40 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:40 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:40 --> Router Class Initialized
ERROR - 2011-05-29 07:12:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:12:41 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:41 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:41 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:41 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:41 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:41 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:41 --> Total execution time: 0.0623
DEBUG - 2011-05-29 07:12:46 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:46 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:46 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:46 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:46 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:46 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:46 --> Total execution time: 0.2989
DEBUG - 2011-05-29 07:12:48 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:48 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:48 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:48 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:48 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:48 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:48 --> Total execution time: 0.1072
DEBUG - 2011-05-29 07:12:48 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:48 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:48 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:48 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:48 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:48 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:48 --> Total execution time: 0.2778
DEBUG - 2011-05-29 07:12:49 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:49 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:49 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:49 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:49 --> Router Class Initialized
ERROR - 2011-05-29 07:12:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:12:54 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:54 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Router Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Output Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Input Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:12:54 --> Language Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Loader Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Controller Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Model Class Initialized
DEBUG - 2011-05-29 07:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:12:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:12:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:12:54 --> Final output sent to browser
DEBUG - 2011-05-29 07:12:54 --> Total execution time: 0.2426
DEBUG - 2011-05-29 07:12:58 --> Config Class Initialized
DEBUG - 2011-05-29 07:12:58 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:12:58 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:12:58 --> URI Class Initialized
DEBUG - 2011-05-29 07:12:58 --> Router Class Initialized
ERROR - 2011-05-29 07:12:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 07:13:03 --> Config Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:13:03 --> URI Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Router Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Output Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Input Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:13:03 --> Language Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Loader Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Controller Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:13:03 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:13:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:13:03 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:13:03 --> Final output sent to browser
DEBUG - 2011-05-29 07:13:03 --> Total execution time: 0.2766
DEBUG - 2011-05-29 07:13:04 --> Config Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:13:04 --> URI Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Router Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Output Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Input Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:13:04 --> Language Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Loader Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Controller Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:13:04 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:13:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:13:04 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:13:04 --> Final output sent to browser
DEBUG - 2011-05-29 07:13:04 --> Total execution time: 0.0746
DEBUG - 2011-05-29 07:13:05 --> Config Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:13:05 --> URI Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Router Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Output Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Input Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 07:13:05 --> Language Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Loader Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Controller Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Model Class Initialized
DEBUG - 2011-05-29 07:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 07:13:05 --> Database Driver Class Initialized
DEBUG - 2011-05-29 07:13:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 07:13:05 --> Helper loaded: url_helper
DEBUG - 2011-05-29 07:13:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 07:13:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 07:13:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 07:13:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 07:13:05 --> Final output sent to browser
DEBUG - 2011-05-29 07:13:05 --> Total execution time: 0.0789
DEBUG - 2011-05-29 07:13:07 --> Config Class Initialized
DEBUG - 2011-05-29 07:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-29 07:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-29 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 07:13:07 --> URI Class Initialized
DEBUG - 2011-05-29 07:13:07 --> Router Class Initialized
ERROR - 2011-05-29 07:13:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 08:17:21 --> Config Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Hooks Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Utf8 Class Initialized
DEBUG - 2011-05-29 08:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 08:17:21 --> URI Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Router Class Initialized
ERROR - 2011-05-29 08:17:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 08:17:21 --> Config Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Hooks Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Utf8 Class Initialized
DEBUG - 2011-05-29 08:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 08:17:21 --> URI Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Router Class Initialized
DEBUG - 2011-05-29 08:17:21 --> No URI present. Default controller set.
DEBUG - 2011-05-29 08:17:21 --> Output Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Input Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 08:17:21 --> Language Class Initialized
DEBUG - 2011-05-29 08:17:21 --> Loader Class Initialized
DEBUG - 2011-05-29 08:17:22 --> Controller Class Initialized
DEBUG - 2011-05-29 08:17:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 08:17:22 --> Helper loaded: url_helper
DEBUG - 2011-05-29 08:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 08:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 08:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 08:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 08:17:22 --> Final output sent to browser
DEBUG - 2011-05-29 08:17:22 --> Total execution time: 0.2908
DEBUG - 2011-05-29 08:50:54 --> Config Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 08:50:54 --> URI Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Router Class Initialized
DEBUG - 2011-05-29 08:50:54 --> No URI present. Default controller set.
DEBUG - 2011-05-29 08:50:54 --> Output Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Input Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 08:50:54 --> Language Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Loader Class Initialized
DEBUG - 2011-05-29 08:50:54 --> Controller Class Initialized
DEBUG - 2011-05-29 08:50:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 08:50:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 08:50:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 08:50:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 08:50:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 08:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 08:50:54 --> Final output sent to browser
DEBUG - 2011-05-29 08:50:54 --> Total execution time: 0.3162
DEBUG - 2011-05-29 09:09:52 --> Config Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:09:52 --> URI Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Router Class Initialized
DEBUG - 2011-05-29 09:09:52 --> No URI present. Default controller set.
DEBUG - 2011-05-29 09:09:52 --> Output Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Input Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:09:52 --> Language Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Loader Class Initialized
DEBUG - 2011-05-29 09:09:52 --> Controller Class Initialized
DEBUG - 2011-05-29 09:09:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 09:09:52 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:09:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:09:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:09:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:09:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:09:52 --> Final output sent to browser
DEBUG - 2011-05-29 09:09:52 --> Total execution time: 0.1738
DEBUG - 2011-05-29 09:55:25 --> Config Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:55:25 --> URI Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Router Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Output Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Input Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:55:25 --> Language Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Loader Class Initialized
DEBUG - 2011-05-29 09:55:25 --> Controller Class Initialized
ERROR - 2011-05-29 09:55:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:55:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:55:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:55:26 --> Model Class Initialized
DEBUG - 2011-05-29 09:55:26 --> Model Class Initialized
DEBUG - 2011-05-29 09:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:55:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:55:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:55:26 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:55:26 --> Final output sent to browser
DEBUG - 2011-05-29 09:55:26 --> Total execution time: 1.4162
DEBUG - 2011-05-29 09:55:29 --> Config Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:55:29 --> URI Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Router Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Output Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Input Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:55:29 --> Language Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Loader Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Controller Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Model Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Model Class Initialized
DEBUG - 2011-05-29 09:55:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:55:29 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:55:30 --> Final output sent to browser
DEBUG - 2011-05-29 09:55:30 --> Total execution time: 0.9850
DEBUG - 2011-05-29 09:55:31 --> Config Class Initialized
DEBUG - 2011-05-29 09:55:31 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:55:31 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:55:31 --> URI Class Initialized
DEBUG - 2011-05-29 09:55:31 --> Router Class Initialized
ERROR - 2011-05-29 09:55:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:55:32 --> Config Class Initialized
DEBUG - 2011-05-29 09:55:32 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:55:32 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:55:32 --> URI Class Initialized
DEBUG - 2011-05-29 09:55:32 --> Router Class Initialized
ERROR - 2011-05-29 09:55:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:56:02 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:02 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:02 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Controller Class Initialized
ERROR - 2011-05-29 09:56:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:56:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:02 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:02 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:02 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:56:02 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:02 --> Total execution time: 0.0399
DEBUG - 2011-05-29 09:56:03 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:03 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:03 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Controller Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:03 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:04 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:04 --> Total execution time: 0.6499
DEBUG - 2011-05-29 09:56:05 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:05 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:05 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:05 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:05 --> Router Class Initialized
ERROR - 2011-05-29 09:56:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:56:06 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:06 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:06 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Controller Class Initialized
ERROR - 2011-05-29 09:56:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:56:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:06 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:06 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:06 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:56:06 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:06 --> Total execution time: 0.0325
DEBUG - 2011-05-29 09:56:14 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:14 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:14 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Controller Class Initialized
ERROR - 2011-05-29 09:56:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:56:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:14 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:14 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:14 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:56:14 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:14 --> Total execution time: 0.0304
DEBUG - 2011-05-29 09:56:14 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:14 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:14 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Controller Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:14 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:15 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:15 --> Total execution time: 0.6258
DEBUG - 2011-05-29 09:56:17 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:17 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:17 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:17 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:17 --> Router Class Initialized
ERROR - 2011-05-29 09:56:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:56:25 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:25 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:25 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Controller Class Initialized
ERROR - 2011-05-29 09:56:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:56:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:25 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:25 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:25 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:56:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:56:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:56:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:56:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:56:25 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:25 --> Total execution time: 0.0360
DEBUG - 2011-05-29 09:56:26 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:26 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:26 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Controller Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:26 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:26 --> Total execution time: 0.6505
DEBUG - 2011-05-29 09:56:28 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:28 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:28 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:28 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:28 --> Router Class Initialized
ERROR - 2011-05-29 09:56:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:56:38 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:38 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:38 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Controller Class Initialized
ERROR - 2011-05-29 09:56:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:56:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:38 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:38 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:38 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:56:38 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:38 --> Total execution time: 0.0421
DEBUG - 2011-05-29 09:56:38 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:38 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:38 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Controller Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:38 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:39 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:39 --> Total execution time: 0.6280
DEBUG - 2011-05-29 09:56:40 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:40 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:40 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:40 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:40 --> Router Class Initialized
ERROR - 2011-05-29 09:56:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:56:54 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:54 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:54 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Controller Class Initialized
ERROR - 2011-05-29 09:56:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:56:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:56:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:54 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:56:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:56:54 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:54 --> Total execution time: 0.0308
DEBUG - 2011-05-29 09:56:55 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:55 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Router Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Output Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Input Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:56:55 --> Language Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Loader Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Controller Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Model Class Initialized
DEBUG - 2011-05-29 09:56:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:56:55 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:56:56 --> Final output sent to browser
DEBUG - 2011-05-29 09:56:56 --> Total execution time: 0.6744
DEBUG - 2011-05-29 09:56:57 --> Config Class Initialized
DEBUG - 2011-05-29 09:56:57 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:56:57 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:56:57 --> URI Class Initialized
DEBUG - 2011-05-29 09:56:57 --> Router Class Initialized
ERROR - 2011-05-29 09:56:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:57:05 --> Config Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:57:05 --> URI Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Router Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Output Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Input Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:57:05 --> Language Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Loader Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Controller Class Initialized
ERROR - 2011-05-29 09:57:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:57:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:57:05 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:57:05 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:57:05 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:57:05 --> Final output sent to browser
DEBUG - 2011-05-29 09:57:05 --> Total execution time: 0.0347
DEBUG - 2011-05-29 09:57:05 --> Config Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:57:05 --> URI Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Router Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Output Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Input Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:57:05 --> Language Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Loader Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Controller Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:57:06 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:57:06 --> Final output sent to browser
DEBUG - 2011-05-29 09:57:06 --> Total execution time: 1.0332
DEBUG - 2011-05-29 09:57:08 --> Config Class Initialized
DEBUG - 2011-05-29 09:57:08 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:57:08 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:57:08 --> URI Class Initialized
DEBUG - 2011-05-29 09:57:08 --> Router Class Initialized
ERROR - 2011-05-29 09:57:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 09:57:47 --> Config Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:57:47 --> URI Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Router Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Output Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Input Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:57:47 --> Language Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Loader Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Controller Class Initialized
ERROR - 2011-05-29 09:57:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:57:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:57:47 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:57:47 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:57:47 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:57:47 --> Final output sent to browser
DEBUG - 2011-05-29 09:57:47 --> Total execution time: 0.0433
DEBUG - 2011-05-29 09:57:47 --> Config Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Hooks Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Utf8 Class Initialized
DEBUG - 2011-05-29 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 09:57:47 --> URI Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Router Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Output Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Input Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 09:57:47 --> Language Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Loader Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Controller Class Initialized
ERROR - 2011-05-29 09:57:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 09:57:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:57:47 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Model Class Initialized
DEBUG - 2011-05-29 09:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 09:57:47 --> Database Driver Class Initialized
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 09:57:47 --> Helper loaded: url_helper
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 09:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 09:57:47 --> Final output sent to browser
DEBUG - 2011-05-29 09:57:47 --> Total execution time: 0.0296
DEBUG - 2011-05-29 10:39:19 --> Config Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Hooks Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Utf8 Class Initialized
DEBUG - 2011-05-29 10:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 10:39:19 --> URI Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Router Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Output Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Input Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 10:39:19 --> Language Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Loader Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Controller Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Model Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Model Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Model Class Initialized
DEBUG - 2011-05-29 10:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 10:39:19 --> Database Driver Class Initialized
DEBUG - 2011-05-29 10:39:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 10:39:20 --> Helper loaded: url_helper
DEBUG - 2011-05-29 10:39:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 10:39:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 10:39:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 10:39:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 10:39:20 --> Final output sent to browser
DEBUG - 2011-05-29 10:39:20 --> Total execution time: 1.4861
DEBUG - 2011-05-29 10:39:26 --> Config Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Hooks Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Utf8 Class Initialized
DEBUG - 2011-05-29 10:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 10:39:26 --> URI Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Router Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Output Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Input Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 10:39:26 --> Language Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Loader Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Controller Class Initialized
ERROR - 2011-05-29 10:39:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 10:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 10:39:26 --> Model Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Model Class Initialized
DEBUG - 2011-05-29 10:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 10:39:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 10:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 10:39:26 --> Helper loaded: url_helper
DEBUG - 2011-05-29 10:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 10:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 10:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 10:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 10:39:26 --> Final output sent to browser
DEBUG - 2011-05-29 10:39:26 --> Total execution time: 0.1137
DEBUG - 2011-05-29 15:01:45 --> Config Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Hooks Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Utf8 Class Initialized
DEBUG - 2011-05-29 15:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 15:01:45 --> URI Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Router Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Output Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Input Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 15:01:45 --> Language Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Loader Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Controller Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Model Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Model Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Model Class Initialized
DEBUG - 2011-05-29 15:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 15:01:45 --> Database Driver Class Initialized
DEBUG - 2011-05-29 15:01:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 15:01:45 --> Helper loaded: url_helper
DEBUG - 2011-05-29 15:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 15:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 15:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 15:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 15:01:45 --> Final output sent to browser
DEBUG - 2011-05-29 15:01:45 --> Total execution time: 0.5668
DEBUG - 2011-05-29 15:01:49 --> Config Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Hooks Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Utf8 Class Initialized
DEBUG - 2011-05-29 15:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 15:01:49 --> URI Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Router Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Output Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Input Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 15:01:49 --> Language Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Loader Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Controller Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Model Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Model Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Model Class Initialized
DEBUG - 2011-05-29 15:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 15:01:49 --> Database Driver Class Initialized
DEBUG - 2011-05-29 15:01:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 15:01:49 --> Helper loaded: url_helper
DEBUG - 2011-05-29 15:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 15:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 15:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 15:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 15:01:49 --> Final output sent to browser
DEBUG - 2011-05-29 15:01:49 --> Total execution time: 0.0451
DEBUG - 2011-05-29 15:01:53 --> Config Class Initialized
DEBUG - 2011-05-29 15:01:53 --> Hooks Class Initialized
DEBUG - 2011-05-29 15:01:53 --> Utf8 Class Initialized
DEBUG - 2011-05-29 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 15:01:53 --> URI Class Initialized
DEBUG - 2011-05-29 15:01:53 --> Router Class Initialized
ERROR - 2011-05-29 15:01:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 15:01:56 --> Config Class Initialized
DEBUG - 2011-05-29 15:01:56 --> Hooks Class Initialized
DEBUG - 2011-05-29 15:01:56 --> Utf8 Class Initialized
DEBUG - 2011-05-29 15:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 15:01:56 --> URI Class Initialized
DEBUG - 2011-05-29 15:01:56 --> Router Class Initialized
ERROR - 2011-05-29 15:01:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 15:01:59 --> Config Class Initialized
DEBUG - 2011-05-29 15:01:59 --> Hooks Class Initialized
DEBUG - 2011-05-29 15:01:59 --> Utf8 Class Initialized
DEBUG - 2011-05-29 15:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 15:01:59 --> URI Class Initialized
DEBUG - 2011-05-29 15:01:59 --> Router Class Initialized
ERROR - 2011-05-29 15:01:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 15:45:16 --> Config Class Initialized
DEBUG - 2011-05-29 15:45:16 --> Hooks Class Initialized
DEBUG - 2011-05-29 15:45:16 --> Utf8 Class Initialized
DEBUG - 2011-05-29 15:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 15:45:16 --> URI Class Initialized
DEBUG - 2011-05-29 15:45:16 --> Router Class Initialized
ERROR - 2011-05-29 15:45:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 16:20:56 --> Config Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:20:56 --> URI Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Router Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Output Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Input Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 16:20:56 --> Language Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Loader Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Controller Class Initialized
ERROR - 2011-05-29 16:20:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 16:20:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 16:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 16:20:56 --> Model Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Model Class Initialized
DEBUG - 2011-05-29 16:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 16:20:56 --> Database Driver Class Initialized
DEBUG - 2011-05-29 16:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 16:20:56 --> Helper loaded: url_helper
DEBUG - 2011-05-29 16:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 16:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 16:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 16:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 16:20:56 --> Final output sent to browser
DEBUG - 2011-05-29 16:20:56 --> Total execution time: 0.3652
DEBUG - 2011-05-29 17:20:13 --> Config Class Initialized
DEBUG - 2011-05-29 17:20:13 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:20:13 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:20:13 --> URI Class Initialized
DEBUG - 2011-05-29 17:20:13 --> Router Class Initialized
ERROR - 2011-05-29 17:20:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 17:20:15 --> Config Class Initialized
DEBUG - 2011-05-29 17:20:15 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:20:15 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:20:15 --> URI Class Initialized
DEBUG - 2011-05-29 17:20:15 --> Router Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Output Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Input Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:20:16 --> Language Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Loader Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Controller Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Model Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Model Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Model Class Initialized
DEBUG - 2011-05-29 17:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:20:17 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:20:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:20:18 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:20:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:20:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:20:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:20:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:20:18 --> Final output sent to browser
DEBUG - 2011-05-29 17:20:18 --> Total execution time: 2.6405
DEBUG - 2011-05-29 17:21:09 --> Config Class Initialized
DEBUG - 2011-05-29 17:21:09 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:21:09 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:21:09 --> URI Class Initialized
DEBUG - 2011-05-29 17:21:09 --> Router Class Initialized
ERROR - 2011-05-29 17:21:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 17:21:10 --> Config Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:21:10 --> URI Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Router Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Output Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Input Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:21:10 --> Language Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Loader Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Controller Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Model Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Model Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Model Class Initialized
DEBUG - 2011-05-29 17:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:21:10 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:21:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:21:10 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:21:10 --> Final output sent to browser
DEBUG - 2011-05-29 17:21:10 --> Total execution time: 0.0436
DEBUG - 2011-05-29 17:30:32 --> Config Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:30:32 --> URI Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Router Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Output Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Input Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:30:32 --> Language Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Loader Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Controller Class Initialized
ERROR - 2011-05-29 17:30:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 17:30:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 17:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 17:30:32 --> Model Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Model Class Initialized
DEBUG - 2011-05-29 17:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:30:32 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 17:30:32 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:30:32 --> Final output sent to browser
DEBUG - 2011-05-29 17:30:32 --> Total execution time: 0.1193
DEBUG - 2011-05-29 17:38:08 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:08 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Router Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Output Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Input Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:38:08 --> Language Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Loader Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Controller Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:38:08 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:38:08 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:38:08 --> Final output sent to browser
DEBUG - 2011-05-29 17:38:08 --> Total execution time: 0.1032
DEBUG - 2011-05-29 17:38:10 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:10 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:10 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:10 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:10 --> Router Class Initialized
ERROR - 2011-05-29 17:38:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 17:38:16 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:16 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Router Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Output Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Input Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:38:16 --> Language Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Loader Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Controller Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:38:16 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:38:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:38:16 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:38:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:38:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:38:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:38:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:38:16 --> Final output sent to browser
DEBUG - 2011-05-29 17:38:16 --> Total execution time: 0.3676
DEBUG - 2011-05-29 17:38:26 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:26 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Router Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Output Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Input Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:38:26 --> Language Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Loader Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Controller Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:38:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:38:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:38:26 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:38:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:38:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:38:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:38:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:38:26 --> Final output sent to browser
DEBUG - 2011-05-29 17:38:26 --> Total execution time: 0.5271
DEBUG - 2011-05-29 17:38:38 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:38 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Router Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Output Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Input Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:38:38 --> Language Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Loader Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Controller Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:38:38 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:38:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:38:38 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:38:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:38:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:38:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:38:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:38:38 --> Final output sent to browser
DEBUG - 2011-05-29 17:38:38 --> Total execution time: 0.0836
DEBUG - 2011-05-29 17:38:39 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:39 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Router Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Output Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Input Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:38:39 --> Language Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Loader Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Controller Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:38:39 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:38:41 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:38:41 --> Final output sent to browser
DEBUG - 2011-05-29 17:38:41 --> Total execution time: 1.4226
DEBUG - 2011-05-29 17:38:50 --> Config Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:38:50 --> URI Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Router Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Output Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Input Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:38:50 --> Language Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Loader Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Controller Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Model Class Initialized
DEBUG - 2011-05-29 17:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:38:50 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:38:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:38:51 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:38:51 --> Final output sent to browser
DEBUG - 2011-05-29 17:38:51 --> Total execution time: 0.5774
DEBUG - 2011-05-29 17:39:04 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:04 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:04 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:04 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:04 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:04 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:04 --> Total execution time: 0.7086
DEBUG - 2011-05-29 17:39:10 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:10 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:10 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:10 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:10 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:10 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:10 --> Total execution time: 0.3023
DEBUG - 2011-05-29 17:39:15 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:15 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:15 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:15 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:16 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:16 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:16 --> Total execution time: 0.2407
DEBUG - 2011-05-29 17:39:20 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:20 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:20 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:20 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:21 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:21 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:21 --> Total execution time: 0.5482
DEBUG - 2011-05-29 17:39:26 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:26 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:26 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:27 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:27 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:27 --> Total execution time: 0.0530
DEBUG - 2011-05-29 17:39:31 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:31 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:31 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:31 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:32 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:32 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:32 --> Total execution time: 0.5861
DEBUG - 2011-05-29 17:39:55 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:55 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:55 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:55 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:55 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:55 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:55 --> Total execution time: 0.0638
DEBUG - 2011-05-29 17:39:58 --> Config Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Hooks Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Utf8 Class Initialized
DEBUG - 2011-05-29 17:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 17:39:58 --> URI Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Router Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Output Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Input Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 17:39:58 --> Language Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Loader Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Controller Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Model Class Initialized
DEBUG - 2011-05-29 17:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 17:39:59 --> Database Driver Class Initialized
DEBUG - 2011-05-29 17:39:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 17:39:59 --> Helper loaded: url_helper
DEBUG - 2011-05-29 17:39:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 17:39:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 17:39:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 17:39:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 17:39:59 --> Final output sent to browser
DEBUG - 2011-05-29 17:39:59 --> Total execution time: 0.0490
DEBUG - 2011-05-29 18:00:54 --> Config Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:00:54 --> URI Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Router Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Output Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Input Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:00:54 --> Language Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Loader Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Controller Class Initialized
ERROR - 2011-05-29 18:00:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:00:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:00:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:00:54 --> Model Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Model Class Initialized
DEBUG - 2011-05-29 18:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:00:54 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:00:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:00:54 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:00:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:00:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:00:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:00:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:00:54 --> Final output sent to browser
DEBUG - 2011-05-29 18:00:54 --> Total execution time: 0.2766
DEBUG - 2011-05-29 18:00:55 --> Config Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:00:55 --> URI Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Router Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Output Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Input Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:00:55 --> Language Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Loader Class Initialized
DEBUG - 2011-05-29 18:00:55 --> Controller Class Initialized
DEBUG - 2011-05-29 18:00:56 --> Model Class Initialized
DEBUG - 2011-05-29 18:00:56 --> Model Class Initialized
DEBUG - 2011-05-29 18:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:00:56 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:00:56 --> Final output sent to browser
DEBUG - 2011-05-29 18:00:56 --> Total execution time: 1.1512
DEBUG - 2011-05-29 18:00:58 --> Config Class Initialized
DEBUG - 2011-05-29 18:00:58 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:00:58 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:00:58 --> URI Class Initialized
DEBUG - 2011-05-29 18:00:58 --> Router Class Initialized
ERROR - 2011-05-29 18:00:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 18:01:10 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:10 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:10 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Controller Class Initialized
ERROR - 2011-05-29 18:01:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:01:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:10 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:10 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:10 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:01:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:01:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:01:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:01:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:01:10 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:10 --> Total execution time: 0.0300
DEBUG - 2011-05-29 18:01:10 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:10 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:10 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Controller Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:10 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:11 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:11 --> Total execution time: 0.6288
DEBUG - 2011-05-29 18:01:12 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:12 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:12 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:12 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:12 --> Router Class Initialized
ERROR - 2011-05-29 18:01:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 18:01:20 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:20 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:20 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Controller Class Initialized
ERROR - 2011-05-29 18:01:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:01:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:01:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:20 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:20 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:20 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:01:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:01:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:01:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:01:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:01:20 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:20 --> Total execution time: 0.0331
DEBUG - 2011-05-29 18:01:21 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:21 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:21 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Controller Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:21 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:21 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:21 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Controller Class Initialized
ERROR - 2011-05-29 18:01:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:01:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:01:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:21 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:21 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:21 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:01:21 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:21 --> Total execution time: 0.0290
DEBUG - 2011-05-29 18:01:21 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:21 --> Total execution time: 0.6685
DEBUG - 2011-05-29 18:01:22 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:22 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:22 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:22 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:22 --> Router Class Initialized
ERROR - 2011-05-29 18:01:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 18:01:43 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:43 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:43 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Controller Class Initialized
ERROR - 2011-05-29 18:01:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:01:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:43 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:43 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:01:43 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:01:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:01:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:01:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:01:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:01:43 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:43 --> Total execution time: 0.0832
DEBUG - 2011-05-29 18:01:44 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:44 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Router Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Output Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Input Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:01:44 --> Language Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Loader Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Controller Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Model Class Initialized
DEBUG - 2011-05-29 18:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:01:44 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:01:45 --> Final output sent to browser
DEBUG - 2011-05-29 18:01:45 --> Total execution time: 0.6532
DEBUG - 2011-05-29 18:01:46 --> Config Class Initialized
DEBUG - 2011-05-29 18:01:46 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:01:46 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:01:46 --> URI Class Initialized
DEBUG - 2011-05-29 18:01:46 --> Router Class Initialized
ERROR - 2011-05-29 18:01:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 18:02:09 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:09 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Router Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Output Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Input Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:02:09 --> Language Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Loader Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Controller Class Initialized
ERROR - 2011-05-29 18:02:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:02:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:02:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:02:09 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:02:09 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:02:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:02:09 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:02:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:02:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:02:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:02:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:02:09 --> Final output sent to browser
DEBUG - 2011-05-29 18:02:09 --> Total execution time: 0.0302
DEBUG - 2011-05-29 18:02:10 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:10 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Router Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Output Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Input Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:02:10 --> Language Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Loader Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Controller Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:02:10 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:02:11 --> Final output sent to browser
DEBUG - 2011-05-29 18:02:11 --> Total execution time: 0.5274
DEBUG - 2011-05-29 18:02:12 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:12 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:12 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:12 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:12 --> Router Class Initialized
ERROR - 2011-05-29 18:02:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 18:02:20 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:20 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Router Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Output Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Input Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:02:20 --> Language Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Loader Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Controller Class Initialized
ERROR - 2011-05-29 18:02:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:02:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:02:20 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:02:20 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:02:20 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:02:20 --> Final output sent to browser
DEBUG - 2011-05-29 18:02:20 --> Total execution time: 0.0300
DEBUG - 2011-05-29 18:02:21 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:21 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Router Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Output Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Input Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:02:21 --> Language Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Loader Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Controller Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:02:21 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:02:21 --> Final output sent to browser
DEBUG - 2011-05-29 18:02:21 --> Total execution time: 0.5267
DEBUG - 2011-05-29 18:02:22 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:22 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:22 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:22 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:22 --> Router Class Initialized
ERROR - 2011-05-29 18:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 18:02:25 --> Config Class Initialized
DEBUG - 2011-05-29 18:02:25 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:02:25 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:02:25 --> URI Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Router Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Output Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Input Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:02:26 --> Language Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Loader Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Controller Class Initialized
ERROR - 2011-05-29 18:02:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 18:02:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 18:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:02:26 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Model Class Initialized
DEBUG - 2011-05-29 18:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:02:26 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 18:02:26 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:02:26 --> Final output sent to browser
DEBUG - 2011-05-29 18:02:26 --> Total execution time: 0.0289
DEBUG - 2011-05-29 18:06:38 --> Config Class Initialized
DEBUG - 2011-05-29 18:06:38 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:06:38 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:06:38 --> URI Class Initialized
DEBUG - 2011-05-29 18:06:38 --> Router Class Initialized
DEBUG - 2011-05-29 18:06:38 --> No URI present. Default controller set.
DEBUG - 2011-05-29 18:06:38 --> Output Class Initialized
DEBUG - 2011-05-29 18:06:38 --> Input Class Initialized
DEBUG - 2011-05-29 18:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:06:38 --> Language Class Initialized
DEBUG - 2011-05-29 18:06:39 --> Loader Class Initialized
DEBUG - 2011-05-29 18:06:39 --> Controller Class Initialized
DEBUG - 2011-05-29 18:06:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 18:06:39 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:06:39 --> Final output sent to browser
DEBUG - 2011-05-29 18:06:39 --> Total execution time: 0.0666
DEBUG - 2011-05-29 18:35:43 --> Config Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:35:43 --> URI Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Router Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Output Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Input Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 18:35:43 --> Language Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Loader Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Controller Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Model Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Model Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Model Class Initialized
DEBUG - 2011-05-29 18:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 18:35:43 --> Database Driver Class Initialized
DEBUG - 2011-05-29 18:35:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 18:35:43 --> Helper loaded: url_helper
DEBUG - 2011-05-29 18:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 18:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 18:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 18:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 18:35:43 --> Final output sent to browser
DEBUG - 2011-05-29 18:35:43 --> Total execution time: 0.5961
DEBUG - 2011-05-29 18:35:48 --> Config Class Initialized
DEBUG - 2011-05-29 18:35:48 --> Hooks Class Initialized
DEBUG - 2011-05-29 18:35:48 --> Utf8 Class Initialized
DEBUG - 2011-05-29 18:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 18:35:48 --> URI Class Initialized
DEBUG - 2011-05-29 18:35:48 --> Router Class Initialized
ERROR - 2011-05-29 18:35:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 19:12:44 --> Config Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Hooks Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Utf8 Class Initialized
DEBUG - 2011-05-29 19:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 19:12:44 --> URI Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Router Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Output Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Input Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 19:12:44 --> Language Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Loader Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Controller Class Initialized
ERROR - 2011-05-29 19:12:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 19:12:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 19:12:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 19:12:44 --> Model Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Model Class Initialized
DEBUG - 2011-05-29 19:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 19:12:44 --> Database Driver Class Initialized
DEBUG - 2011-05-29 19:12:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 19:12:44 --> Helper loaded: url_helper
DEBUG - 2011-05-29 19:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 19:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 19:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 19:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 19:12:44 --> Final output sent to browser
DEBUG - 2011-05-29 19:12:44 --> Total execution time: 0.3160
DEBUG - 2011-05-29 19:52:03 --> Config Class Initialized
DEBUG - 2011-05-29 19:52:03 --> Hooks Class Initialized
DEBUG - 2011-05-29 19:52:03 --> Utf8 Class Initialized
DEBUG - 2011-05-29 19:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 19:52:03 --> URI Class Initialized
DEBUG - 2011-05-29 19:52:03 --> Router Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Output Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Input Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 19:52:04 --> Language Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Loader Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Controller Class Initialized
ERROR - 2011-05-29 19:52:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 19:52:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 19:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 19:52:04 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 19:52:04 --> Database Driver Class Initialized
DEBUG - 2011-05-29 19:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 19:52:04 --> Helper loaded: url_helper
DEBUG - 2011-05-29 19:52:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 19:52:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 19:52:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 19:52:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 19:52:04 --> Final output sent to browser
DEBUG - 2011-05-29 19:52:04 --> Total execution time: 0.3571
DEBUG - 2011-05-29 19:52:07 --> Config Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Hooks Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Utf8 Class Initialized
DEBUG - 2011-05-29 19:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 19:52:07 --> URI Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Router Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Output Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Input Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 19:52:07 --> Language Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Loader Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Controller Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 19:52:07 --> Database Driver Class Initialized
DEBUG - 2011-05-29 19:52:08 --> Final output sent to browser
DEBUG - 2011-05-29 19:52:08 --> Total execution time: 1.0904
DEBUG - 2011-05-29 19:52:09 --> Config Class Initialized
DEBUG - 2011-05-29 19:52:09 --> Hooks Class Initialized
DEBUG - 2011-05-29 19:52:09 --> Utf8 Class Initialized
DEBUG - 2011-05-29 19:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 19:52:09 --> URI Class Initialized
DEBUG - 2011-05-29 19:52:09 --> Router Class Initialized
ERROR - 2011-05-29 19:52:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-29 19:52:33 --> Config Class Initialized
DEBUG - 2011-05-29 19:52:33 --> Hooks Class Initialized
DEBUG - 2011-05-29 19:52:33 --> Utf8 Class Initialized
DEBUG - 2011-05-29 19:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 19:52:33 --> URI Class Initialized
DEBUG - 2011-05-29 19:52:33 --> Router Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Output Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Input Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 19:52:34 --> Language Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Loader Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Controller Class Initialized
ERROR - 2011-05-29 19:52:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 19:52:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 19:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 19:52:34 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 19:52:34 --> Database Driver Class Initialized
DEBUG - 2011-05-29 19:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 19:52:34 --> Helper loaded: url_helper
DEBUG - 2011-05-29 19:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 19:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 19:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 19:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 19:52:34 --> Final output sent to browser
DEBUG - 2011-05-29 19:52:34 --> Total execution time: 0.0293
DEBUG - 2011-05-29 19:52:37 --> Config Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Hooks Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Utf8 Class Initialized
DEBUG - 2011-05-29 19:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 19:52:37 --> URI Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Router Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Output Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Input Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 19:52:37 --> Language Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Loader Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Controller Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Model Class Initialized
DEBUG - 2011-05-29 19:52:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 19:52:37 --> Database Driver Class Initialized
DEBUG - 2011-05-29 19:52:38 --> Final output sent to browser
DEBUG - 2011-05-29 19:52:38 --> Total execution time: 0.4180
DEBUG - 2011-05-29 20:12:48 --> Config Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Hooks Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Utf8 Class Initialized
DEBUG - 2011-05-29 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 20:12:48 --> URI Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Router Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Output Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Input Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 20:12:48 --> Language Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Loader Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Controller Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Model Class Initialized
DEBUG - 2011-05-29 20:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 20:12:48 --> Database Driver Class Initialized
DEBUG - 2011-05-29 20:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 20:12:48 --> Helper loaded: url_helper
DEBUG - 2011-05-29 20:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 20:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 20:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 20:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 20:12:48 --> Final output sent to browser
DEBUG - 2011-05-29 20:12:48 --> Total execution time: 0.5742
DEBUG - 2011-05-29 20:13:20 --> Config Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Hooks Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Utf8 Class Initialized
DEBUG - 2011-05-29 20:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 20:13:20 --> URI Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Router Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Output Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Input Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 20:13:20 --> Language Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Loader Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Controller Class Initialized
ERROR - 2011-05-29 20:13:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 20:13:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 20:13:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 20:13:20 --> Model Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Model Class Initialized
DEBUG - 2011-05-29 20:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 20:13:20 --> Database Driver Class Initialized
DEBUG - 2011-05-29 20:13:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 20:13:20 --> Helper loaded: url_helper
DEBUG - 2011-05-29 20:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 20:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 20:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 20:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 20:13:20 --> Final output sent to browser
DEBUG - 2011-05-29 20:13:20 --> Total execution time: 0.0834
DEBUG - 2011-05-29 22:02:43 --> Config Class Initialized
DEBUG - 2011-05-29 22:02:43 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:02:43 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:02:43 --> URI Class Initialized
DEBUG - 2011-05-29 22:02:43 --> Router Class Initialized
ERROR - 2011-05-29 22:02:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 22:03:30 --> Config Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:03:30 --> URI Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Router Class Initialized
DEBUG - 2011-05-29 22:03:30 --> No URI present. Default controller set.
DEBUG - 2011-05-29 22:03:30 --> Output Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Input Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:03:30 --> Language Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Loader Class Initialized
DEBUG - 2011-05-29 22:03:30 --> Controller Class Initialized
DEBUG - 2011-05-29 22:03:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 22:03:30 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:03:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:03:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:03:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:03:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:03:30 --> Final output sent to browser
DEBUG - 2011-05-29 22:03:30 --> Total execution time: 0.2454
DEBUG - 2011-05-29 22:16:59 --> Config Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:16:59 --> URI Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Router Class Initialized
ERROR - 2011-05-29 22:16:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 22:16:59 --> Config Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:16:59 --> URI Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Router Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Output Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Input Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:16:59 --> Language Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Loader Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Controller Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Model Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Model Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Model Class Initialized
DEBUG - 2011-05-29 22:16:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 22:16:59 --> Database Driver Class Initialized
DEBUG - 2011-05-29 22:17:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 22:17:00 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:17:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:17:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:17:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:17:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:17:00 --> Final output sent to browser
DEBUG - 2011-05-29 22:17:00 --> Total execution time: 0.4327
DEBUG - 2011-05-29 22:19:28 --> Config Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:19:28 --> URI Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Router Class Initialized
DEBUG - 2011-05-29 22:19:28 --> No URI present. Default controller set.
DEBUG - 2011-05-29 22:19:28 --> Output Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Input Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:19:28 --> Language Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Loader Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Controller Class Initialized
DEBUG - 2011-05-29 22:19:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-29 22:19:28 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:19:28 --> Final output sent to browser
DEBUG - 2011-05-29 22:19:28 --> Total execution time: 0.0827
DEBUG - 2011-05-29 22:19:28 --> Config Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:19:28 --> URI Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Router Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Output Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Input Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:19:28 --> Language Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Loader Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Controller Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Model Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Model Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Model Class Initialized
DEBUG - 2011-05-29 22:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 22:19:28 --> Database Driver Class Initialized
DEBUG - 2011-05-29 22:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 22:19:29 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:19:29 --> Final output sent to browser
DEBUG - 2011-05-29 22:19:29 --> Total execution time: 0.0825
DEBUG - 2011-05-29 22:19:29 --> Config Class Initialized
DEBUG - 2011-05-29 22:19:29 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:19:29 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:19:29 --> URI Class Initialized
DEBUG - 2011-05-29 22:19:29 --> Router Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Output Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Input Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:19:30 --> Language Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Loader Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Controller Class Initialized
ERROR - 2011-05-29 22:19:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 22:19:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 22:19:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 22:19:30 --> Model Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Model Class Initialized
DEBUG - 2011-05-29 22:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 22:19:30 --> Database Driver Class Initialized
DEBUG - 2011-05-29 22:19:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 22:19:30 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:19:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:19:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:19:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:19:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:19:30 --> Final output sent to browser
DEBUG - 2011-05-29 22:19:30 --> Total execution time: 0.2922
DEBUG - 2011-05-29 22:32:03 --> Config Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:32:03 --> URI Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Router Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Output Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Input Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:32:03 --> Language Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Loader Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Controller Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Model Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Model Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Model Class Initialized
DEBUG - 2011-05-29 22:32:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 22:32:03 --> Database Driver Class Initialized
DEBUG - 2011-05-29 22:32:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 22:32:03 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:32:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:32:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:32:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:32:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:32:03 --> Final output sent to browser
DEBUG - 2011-05-29 22:32:03 --> Total execution time: 0.4323
DEBUG - 2011-05-29 22:32:04 --> Config Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Hooks Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Utf8 Class Initialized
DEBUG - 2011-05-29 22:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 22:32:04 --> URI Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Router Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Output Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Input Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 22:32:04 --> Language Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Loader Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Controller Class Initialized
ERROR - 2011-05-29 22:32:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-29 22:32:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-29 22:32:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 22:32:04 --> Model Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Model Class Initialized
DEBUG - 2011-05-29 22:32:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 22:32:04 --> Database Driver Class Initialized
DEBUG - 2011-05-29 22:32:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-29 22:32:04 --> Helper loaded: url_helper
DEBUG - 2011-05-29 22:32:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 22:32:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 22:32:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 22:32:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 22:32:04 --> Final output sent to browser
DEBUG - 2011-05-29 22:32:04 --> Total execution time: 0.0576
DEBUG - 2011-05-29 23:23:12 --> Config Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Hooks Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Utf8 Class Initialized
DEBUG - 2011-05-29 23:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 23:23:12 --> URI Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Router Class Initialized
ERROR - 2011-05-29 23:23:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-29 23:23:12 --> Config Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Hooks Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Utf8 Class Initialized
DEBUG - 2011-05-29 23:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 23:23:12 --> URI Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Router Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Output Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Input Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-29 23:23:12 --> Language Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Loader Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Controller Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Model Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Model Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Model Class Initialized
DEBUG - 2011-05-29 23:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-29 23:23:12 --> Database Driver Class Initialized
DEBUG - 2011-05-29 23:23:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-29 23:23:13 --> Helper loaded: url_helper
DEBUG - 2011-05-29 23:23:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-29 23:23:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-29 23:23:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-29 23:23:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-29 23:23:13 --> Final output sent to browser
DEBUG - 2011-05-29 23:23:13 --> Total execution time: 0.6021

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-02 02:49:35 --> Config Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Hooks Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Utf8 Class Initialized
DEBUG - 2011-10-02 02:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 02:49:35 --> URI Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Router Class Initialized
DEBUG - 2011-10-02 02:49:35 --> No URI present. Default controller set.
DEBUG - 2011-10-02 02:49:35 --> Output Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Input Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 02:49:35 --> Language Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Loader Class Initialized
DEBUG - 2011-10-02 02:49:35 --> Controller Class Initialized
DEBUG - 2011-10-02 02:49:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-02 02:49:35 --> Helper loaded: url_helper
DEBUG - 2011-10-02 02:49:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 02:49:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 02:49:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 02:49:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 02:49:35 --> Final output sent to browser
DEBUG - 2011-10-02 02:49:35 --> Total execution time: 0.2306
DEBUG - 2011-10-02 02:53:48 --> Config Class Initialized
DEBUG - 2011-10-02 02:53:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 02:53:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 02:53:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 02:53:48 --> URI Class Initialized
DEBUG - 2011-10-02 02:53:48 --> Router Class Initialized
ERROR - 2011-10-02 02:53:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-02 02:53:50 --> Config Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Hooks Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Utf8 Class Initialized
DEBUG - 2011-10-02 02:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 02:53:50 --> URI Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Router Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Output Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Input Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 02:53:50 --> Language Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Loader Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Controller Class Initialized
ERROR - 2011-10-02 02:53:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 02:53:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 02:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 02:53:50 --> Model Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Model Class Initialized
DEBUG - 2011-10-02 02:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 02:53:50 --> Database Driver Class Initialized
DEBUG - 2011-10-02 02:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 02:53:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 02:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 02:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 02:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 02:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 02:53:51 --> Final output sent to browser
DEBUG - 2011-10-02 02:53:51 --> Total execution time: 0.6821
DEBUG - 2011-10-02 03:18:52 --> Config Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 03:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 03:18:52 --> URI Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Router Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Output Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Input Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 03:18:52 --> Language Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Loader Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Controller Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Model Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Model Class Initialized
DEBUG - 2011-10-02 03:18:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 03:18:52 --> Database Driver Class Initialized
DEBUG - 2011-10-02 03:18:53 --> Final output sent to browser
DEBUG - 2011-10-02 03:18:53 --> Total execution time: 0.9269
DEBUG - 2011-10-02 05:54:24 --> Config Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:54:24 --> URI Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Router Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Output Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Input Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:54:24 --> Language Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Loader Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Controller Class Initialized
ERROR - 2011-10-02 05:54:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:54:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:54:24 --> Model Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Model Class Initialized
DEBUG - 2011-10-02 05:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:54:24 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:54:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:54:25 --> Final output sent to browser
DEBUG - 2011-10-02 05:54:25 --> Total execution time: 0.6579
DEBUG - 2011-10-02 05:54:26 --> Config Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:54:26 --> URI Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Router Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Output Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Input Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:54:26 --> Language Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Loader Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Controller Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Model Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Model Class Initialized
DEBUG - 2011-10-02 05:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:54:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:54:27 --> Final output sent to browser
DEBUG - 2011-10-02 05:54:27 --> Total execution time: 0.6714
DEBUG - 2011-10-02 05:54:28 --> Config Class Initialized
DEBUG - 2011-10-02 05:54:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:54:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:54:28 --> URI Class Initialized
DEBUG - 2011-10-02 05:54:28 --> Router Class Initialized
ERROR - 2011-10-02 05:54:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:55:22 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:22 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Router Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Output Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Input Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:55:22 --> Language Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Loader Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Controller Class Initialized
ERROR - 2011-10-02 05:55:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:55:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:55:22 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:55:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:55:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:55:22 --> Final output sent to browser
DEBUG - 2011-10-02 05:55:22 --> Total execution time: 0.0369
DEBUG - 2011-10-02 05:55:22 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:22 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Router Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Output Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Input Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:55:22 --> Language Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Loader Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Controller Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:55:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:55:23 --> Final output sent to browser
DEBUG - 2011-10-02 05:55:23 --> Total execution time: 0.6378
DEBUG - 2011-10-02 05:55:24 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:24 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:24 --> Router Class Initialized
ERROR - 2011-10-02 05:55:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:55:39 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:39 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Router Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Output Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Input Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:55:39 --> Language Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Loader Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Controller Class Initialized
ERROR - 2011-10-02 05:55:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:55:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:55:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:55:39 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:55:39 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:55:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:55:39 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:55:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:55:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:55:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:55:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:55:39 --> Final output sent to browser
DEBUG - 2011-10-02 05:55:39 --> Total execution time: 0.0379
DEBUG - 2011-10-02 05:55:40 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:40 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Router Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Output Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Input Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:55:40 --> Language Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Loader Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Controller Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:55:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:55:41 --> Final output sent to browser
DEBUG - 2011-10-02 05:55:41 --> Total execution time: 0.6494
DEBUG - 2011-10-02 05:55:42 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:42 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:42 --> Router Class Initialized
ERROR - 2011-10-02 05:55:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:55:58 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:58 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Router Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Output Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Input Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:55:58 --> Language Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Loader Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Controller Class Initialized
ERROR - 2011-10-02 05:55:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:55:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:55:58 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:55:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:55:58 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:55:58 --> Final output sent to browser
DEBUG - 2011-10-02 05:55:58 --> Total execution time: 0.0546
DEBUG - 2011-10-02 05:55:59 --> Config Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:55:59 --> URI Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Router Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Output Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Input Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:55:59 --> Language Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Loader Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Controller Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Model Class Initialized
DEBUG - 2011-10-02 05:55:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:55:59 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:00 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:00 --> Total execution time: 0.5482
DEBUG - 2011-10-02 05:56:00 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:00 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:00 --> Router Class Initialized
ERROR - 2011-10-02 05:56:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-02 05:56:01 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:01 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:01 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Controller Class Initialized
ERROR - 2011-10-02 05:56:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:01 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:01 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:56:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:56:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:56:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:56:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:56:01 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:01 --> Total execution time: 0.0351
DEBUG - 2011-10-02 05:56:01 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:01 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:01 --> Router Class Initialized
ERROR - 2011-10-02 05:56:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:56:23 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:23 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:23 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Controller Class Initialized
ERROR - 2011-10-02 05:56:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:56:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:56:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:23 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:23 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:23 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:56:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:56:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:56:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:56:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:56:23 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:23 --> Total execution time: 0.0316
DEBUG - 2011-10-02 05:56:24 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:24 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:24 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Controller Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:24 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:25 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:25 --> Total execution time: 0.7514
DEBUG - 2011-10-02 05:56:26 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:26 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:26 --> Router Class Initialized
ERROR - 2011-10-02 05:56:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:56:44 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:44 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:44 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Controller Class Initialized
ERROR - 2011-10-02 05:56:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:56:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:44 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:44 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:44 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:56:44 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:44 --> Total execution time: 0.0366
DEBUG - 2011-10-02 05:56:45 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:45 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:45 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Controller Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:45 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:45 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:45 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Controller Class Initialized
ERROR - 2011-10-02 05:56:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:56:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:45 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:45 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:45 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:56:45 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:45 --> Total execution time: 0.0322
DEBUG - 2011-10-02 05:56:46 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:46 --> Total execution time: 1.4354
DEBUG - 2011-10-02 05:56:47 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:47 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:47 --> Router Class Initialized
ERROR - 2011-10-02 05:56:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:56:57 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:57 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:57 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Controller Class Initialized
ERROR - 2011-10-02 05:56:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:56:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:56:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:57 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:57 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:56:57 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:56:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:56:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:56:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:56:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:56:57 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:57 --> Total execution time: 0.0581
DEBUG - 2011-10-02 05:56:58 --> Config Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:56:58 --> URI Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Router Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Output Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Input Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:56:58 --> Language Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Loader Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Controller Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Model Class Initialized
DEBUG - 2011-10-02 05:56:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:56:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:56:59 --> Final output sent to browser
DEBUG - 2011-10-02 05:56:59 --> Total execution time: 0.5832
DEBUG - 2011-10-02 05:57:00 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:00 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:00 --> Router Class Initialized
ERROR - 2011-10-02 05:57:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:09 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:09 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:09 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:09 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:09 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:09 --> Total execution time: 0.0348
DEBUG - 2011-10-02 05:57:10 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:10 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:10 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:11 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:11 --> Total execution time: 0.5394
DEBUG - 2011-10-02 05:57:12 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:12 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:12 --> Router Class Initialized
ERROR - 2011-10-02 05:57:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:15 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:15 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:15 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:15 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:15 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:15 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:15 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:15 --> Total execution time: 0.0324
DEBUG - 2011-10-02 05:57:16 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:16 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:16 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:16 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:16 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:16 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:16 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:16 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:16 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:16 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:16 --> Total execution time: 0.0360
DEBUG - 2011-10-02 05:57:17 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:17 --> Total execution time: 0.8504
DEBUG - 2011-10-02 05:57:18 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:18 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:18 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:18 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:18 --> Router Class Initialized
ERROR - 2011-10-02 05:57:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:22 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:22 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:22 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:22 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:22 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:22 --> Total execution time: 0.0301
DEBUG - 2011-10-02 05:57:23 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:23 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:23 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:23 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:24 --> Total execution time: 0.7108
DEBUG - 2011-10-02 05:57:24 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:24 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:24 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:24 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:24 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:24 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:24 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:24 --> Total execution time: 0.0303
DEBUG - 2011-10-02 05:57:25 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:25 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:25 --> Router Class Initialized
ERROR - 2011-10-02 05:57:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:29 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:29 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:29 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:29 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:29 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:29 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:29 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:29 --> Total execution time: 0.0292
DEBUG - 2011-10-02 05:57:30 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:30 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:30 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:30 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:31 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:31 --> Total execution time: 0.6417
DEBUG - 2011-10-02 05:57:32 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:32 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:32 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:32 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:32 --> Router Class Initialized
ERROR - 2011-10-02 05:57:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:38 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:38 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:38 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:38 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:38 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:38 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:38 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:38 --> Total execution time: 0.0347
DEBUG - 2011-10-02 05:57:38 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:38 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:38 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:38 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:39 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:39 --> Total execution time: 0.6022
DEBUG - 2011-10-02 05:57:40 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:40 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:40 --> Router Class Initialized
ERROR - 2011-10-02 05:57:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:49 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:49 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:49 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:49 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:49 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:49 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:49 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:49 --> Total execution time: 0.0319
DEBUG - 2011-10-02 05:57:50 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:50 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:50 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:50 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:50 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:50 --> Total execution time: 0.5839
DEBUG - 2011-10-02 05:57:52 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:52 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:52 --> Router Class Initialized
ERROR - 2011-10-02 05:57:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 05:57:55 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:55 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:55 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Controller Class Initialized
ERROR - 2011-10-02 05:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 05:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 05:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:55 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:55 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 05:57:55 --> Helper loaded: url_helper
DEBUG - 2011-10-02 05:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 05:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 05:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 05:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 05:57:55 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:55 --> Total execution time: 0.0361
DEBUG - 2011-10-02 05:57:56 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:56 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Router Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Output Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Input Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 05:57:56 --> Language Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Loader Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Controller Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Model Class Initialized
DEBUG - 2011-10-02 05:57:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 05:57:56 --> Database Driver Class Initialized
DEBUG - 2011-10-02 05:57:57 --> Final output sent to browser
DEBUG - 2011-10-02 05:57:57 --> Total execution time: 0.5014
DEBUG - 2011-10-02 05:57:58 --> Config Class Initialized
DEBUG - 2011-10-02 05:57:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 05:57:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 05:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 05:57:58 --> URI Class Initialized
DEBUG - 2011-10-02 05:57:58 --> Router Class Initialized
ERROR - 2011-10-02 05:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 06:43:26 --> Config Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 06:43:26 --> URI Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Router Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Output Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Input Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 06:43:26 --> Language Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Loader Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Controller Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Model Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Model Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Model Class Initialized
DEBUG - 2011-10-02 06:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 06:43:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 06:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 06:43:27 --> Helper loaded: url_helper
DEBUG - 2011-10-02 06:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 06:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 06:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 06:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 06:43:27 --> Final output sent to browser
DEBUG - 2011-10-02 06:43:27 --> Total execution time: 1.2173
DEBUG - 2011-10-02 07:22:58 --> Config Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 07:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 07:22:58 --> URI Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Router Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Output Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Input Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 07:22:58 --> Language Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Loader Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Controller Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Model Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Model Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Model Class Initialized
DEBUG - 2011-10-02 07:22:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 07:22:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 07:22:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 07:22:59 --> Helper loaded: url_helper
DEBUG - 2011-10-02 07:22:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 07:22:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 07:22:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 07:22:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 07:22:59 --> Final output sent to browser
DEBUG - 2011-10-02 07:22:59 --> Total execution time: 1.4835
DEBUG - 2011-10-02 07:23:00 --> Config Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 07:23:00 --> URI Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Router Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Output Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Input Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 07:23:00 --> Language Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Loader Class Initialized
DEBUG - 2011-10-02 07:23:00 --> Controller Class Initialized
ERROR - 2011-10-02 07:23:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 07:23:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 07:23:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 07:23:01 --> Model Class Initialized
DEBUG - 2011-10-02 07:23:01 --> Model Class Initialized
DEBUG - 2011-10-02 07:23:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 07:23:01 --> Database Driver Class Initialized
DEBUG - 2011-10-02 07:23:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 07:23:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 07:23:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 07:23:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 07:23:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 07:23:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 07:23:01 --> Final output sent to browser
DEBUG - 2011-10-02 07:23:01 --> Total execution time: 0.1062
DEBUG - 2011-10-02 08:09:36 --> Config Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:09:36 --> URI Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Router Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Output Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Input Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:09:36 --> Language Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Loader Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Controller Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:09:36 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:09:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:09:37 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:09:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:09:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:09:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:09:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:09:37 --> Final output sent to browser
DEBUG - 2011-10-02 08:09:37 --> Total execution time: 1.2830
DEBUG - 2011-10-02 08:09:38 --> Config Class Initialized
DEBUG - 2011-10-02 08:09:38 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:09:38 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:09:38 --> URI Class Initialized
DEBUG - 2011-10-02 08:09:38 --> Router Class Initialized
ERROR - 2011-10-02 08:09:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:09:49 --> Config Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:09:49 --> URI Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Router Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Output Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Input Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:09:49 --> Language Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Loader Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Controller Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:09:49 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:09:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:09:49 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:09:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:09:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:09:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:09:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:09:49 --> Final output sent to browser
DEBUG - 2011-10-02 08:09:49 --> Total execution time: 0.4690
DEBUG - 2011-10-02 08:09:50 --> Config Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:09:50 --> URI Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Router Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Output Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Input Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:09:50 --> Language Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Loader Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Controller Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Model Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:09:50 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:09:50 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:09:50 --> Final output sent to browser
DEBUG - 2011-10-02 08:09:50 --> Total execution time: 0.0501
DEBUG - 2011-10-02 08:09:50 --> Config Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:09:50 --> URI Class Initialized
DEBUG - 2011-10-02 08:09:50 --> Router Class Initialized
ERROR - 2011-10-02 08:09:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:10:06 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:06 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:06 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:06 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:06 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:06 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:06 --> Total execution time: 0.5557
DEBUG - 2011-10-02 08:10:07 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:07 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:07 --> Router Class Initialized
ERROR - 2011-10-02 08:10:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:10:09 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:09 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:09 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:09 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:09 --> Total execution time: 0.0882
DEBUG - 2011-10-02 08:10:26 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:26 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:26 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:26 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:26 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:26 --> Total execution time: 0.2931
DEBUG - 2011-10-02 08:10:27 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:27 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Router Class Initialized
ERROR - 2011-10-02 08:10:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:10:27 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:27 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:27 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:27 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:27 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:27 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:27 --> Total execution time: 0.0469
DEBUG - 2011-10-02 08:10:35 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:35 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:35 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:35 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:36 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:36 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:36 --> Total execution time: 0.3371
DEBUG - 2011-10-02 08:10:37 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:37 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Router Class Initialized
ERROR - 2011-10-02 08:10:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:10:37 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:37 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:37 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:37 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:37 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:37 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:37 --> Total execution time: 0.0506
DEBUG - 2011-10-02 08:10:42 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:42 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:42 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:42 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:42 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:42 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:42 --> Total execution time: 0.4566
DEBUG - 2011-10-02 08:10:43 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:43 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Router Class Initialized
ERROR - 2011-10-02 08:10:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:10:43 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:43 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:43 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:43 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:44 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:44 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:44 --> Total execution time: 0.1534
DEBUG - 2011-10-02 08:10:48 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:48 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:48 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:48 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:48 --> Total execution time: 0.3339
DEBUG - 2011-10-02 08:10:49 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:49 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:49 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:49 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:49 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:49 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:49 --> Total execution time: 0.0518
DEBUG - 2011-10-02 08:10:49 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:49 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:49 --> Router Class Initialized
ERROR - 2011-10-02 08:10:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:10:58 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:58 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Router Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Output Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Input Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:10:58 --> Language Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Loader Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Controller Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Model Class Initialized
DEBUG - 2011-10-02 08:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:10:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:10:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:10:58 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:10:58 --> Final output sent to browser
DEBUG - 2011-10-02 08:10:58 --> Total execution time: 0.5492
DEBUG - 2011-10-02 08:10:59 --> Config Class Initialized
DEBUG - 2011-10-02 08:10:59 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:10:59 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:10:59 --> URI Class Initialized
DEBUG - 2011-10-02 08:10:59 --> Router Class Initialized
ERROR - 2011-10-02 08:10:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:11:00 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:00 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Router Class Initialized
ERROR - 2011-10-02 08:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:11:00 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:00 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:00 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:00 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:00 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:00 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:00 --> Total execution time: 0.0597
DEBUG - 2011-10-02 08:11:06 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:06 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:06 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:06 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:07 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:07 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:07 --> Total execution time: 0.4137
DEBUG - 2011-10-02 08:11:08 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:08 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:08 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:08 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:08 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:08 --> Total execution time: 0.1157
DEBUG - 2011-10-02 08:11:09 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:09 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:09 --> Router Class Initialized
ERROR - 2011-10-02 08:11:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:11:14 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:14 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:14 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:15 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:15 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:15 --> Total execution time: 0.6534
DEBUG - 2011-10-02 08:11:16 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:16 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:16 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:16 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:16 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:16 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:16 --> Total execution time: 0.1319
DEBUG - 2011-10-02 08:11:18 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:18 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:18 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:18 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:18 --> Router Class Initialized
ERROR - 2011-10-02 08:11:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:11:22 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:22 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:22 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:23 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:23 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:23 --> Total execution time: 0.4507
DEBUG - 2011-10-02 08:11:24 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:24 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:24 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:24 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:24 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:24 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:24 --> Total execution time: 0.1033
DEBUG - 2011-10-02 08:11:24 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:24 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:24 --> Router Class Initialized
ERROR - 2011-10-02 08:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:11:35 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:35 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:35 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:35 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:36 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:36 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:36 --> Total execution time: 0.6514
DEBUG - 2011-10-02 08:11:37 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:37 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:37 --> Router Class Initialized
ERROR - 2011-10-02 08:11:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:11:47 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:47 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:47 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:47 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:47 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:47 --> Total execution time: 0.0447
DEBUG - 2011-10-02 08:11:53 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:53 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:53 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:53 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:54 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:54 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:54 --> Total execution time: 0.5044
DEBUG - 2011-10-02 08:11:56 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:56 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Router Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Output Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Input Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:11:56 --> Language Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Loader Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Controller Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Model Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:11:56 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:11:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:11:56 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:11:56 --> Final output sent to browser
DEBUG - 2011-10-02 08:11:56 --> Total execution time: 0.0738
DEBUG - 2011-10-02 08:11:56 --> Config Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:11:56 --> URI Class Initialized
DEBUG - 2011-10-02 08:11:56 --> Router Class Initialized
ERROR - 2011-10-02 08:11:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:12:02 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:02 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:02 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:02 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:02 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:02 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:02 --> Total execution time: 0.6973
DEBUG - 2011-10-02 08:12:03 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:03 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:03 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:03 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:03 --> Router Class Initialized
ERROR - 2011-10-02 08:12:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:12:04 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:04 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:04 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:04 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:04 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:04 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:04 --> Total execution time: 0.0485
DEBUG - 2011-10-02 08:12:13 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:13 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:13 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:13 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:13 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:13 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:13 --> Total execution time: 0.2801
DEBUG - 2011-10-02 08:12:14 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:14 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:14 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:14 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:14 --> Total execution time: 0.0447
DEBUG - 2011-10-02 08:12:14 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:14 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:14 --> Router Class Initialized
ERROR - 2011-10-02 08:12:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:12:19 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:19 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:19 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:19 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:19 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:19 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:19 --> Total execution time: 0.2749
DEBUG - 2011-10-02 08:12:20 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:20 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:20 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:20 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:20 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:20 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:20 --> Total execution time: 0.0589
DEBUG - 2011-10-02 08:12:20 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:20 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:20 --> Router Class Initialized
ERROR - 2011-10-02 08:12:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:12:37 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:37 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:37 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:37 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:38 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:38 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:38 --> Total execution time: 0.6565
DEBUG - 2011-10-02 08:12:39 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:39 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:39 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:39 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:39 --> Router Class Initialized
ERROR - 2011-10-02 08:12:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:12:40 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:40 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:40 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:40 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:40 --> Total execution time: 0.0456
DEBUG - 2011-10-02 08:12:54 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:54 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:54 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:54 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:54 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:54 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:54 --> Total execution time: 0.1059
DEBUG - 2011-10-02 08:12:55 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:55 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:55 --> Router Class Initialized
ERROR - 2011-10-02 08:12:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:12:59 --> Config Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:12:59 --> URI Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Router Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Output Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Input Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:12:59 --> Language Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Loader Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Controller Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Model Class Initialized
DEBUG - 2011-10-02 08:12:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:12:59 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:12:59 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:12:59 --> Final output sent to browser
DEBUG - 2011-10-02 08:12:59 --> Total execution time: 0.0540
DEBUG - 2011-10-02 08:13:00 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:00 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:00 --> Router Class Initialized
ERROR - 2011-10-02 08:13:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:03 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:03 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:03 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:03 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:03 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:03 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:03 --> Total execution time: 0.0475
DEBUG - 2011-10-02 08:13:04 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:04 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:04 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:04 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:04 --> Router Class Initialized
ERROR - 2011-10-02 08:13:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:07 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:07 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:07 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:07 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:07 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:07 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:08 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:08 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:08 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:08 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:08 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:08 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:08 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:08 --> Total execution time: 0.4268
DEBUG - 2011-10-02 08:13:09 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:09 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:09 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:09 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:09 --> Total execution time: 0.0593
DEBUG - 2011-10-02 08:13:10 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:10 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:10 --> Router Class Initialized
ERROR - 2011-10-02 08:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:10 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:10 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:10 --> Router Class Initialized
ERROR - 2011-10-02 08:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:14 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:14 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:14 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:14 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:14 --> Total execution time: 0.1285
DEBUG - 2011-10-02 08:13:15 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:15 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:15 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:15 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:15 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:15 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:15 --> Total execution time: 0.0470
DEBUG - 2011-10-02 08:13:15 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:15 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:15 --> Router Class Initialized
ERROR - 2011-10-02 08:13:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:21 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:21 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:21 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:21 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:21 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:21 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:21 --> Total execution time: 0.0505
DEBUG - 2011-10-02 08:13:22 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:22 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:22 --> Router Class Initialized
ERROR - 2011-10-02 08:13:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:25 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:25 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:25 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:25 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:25 --> Total execution time: 0.0475
DEBUG - 2011-10-02 08:13:26 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:26 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:26 --> Router Class Initialized
ERROR - 2011-10-02 08:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:29 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:29 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:29 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:29 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:13:30 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:30 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:30 --> Total execution time: 0.0470
DEBUG - 2011-10-02 08:13:30 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:30 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:30 --> Router Class Initialized
ERROR - 2011-10-02 08:13:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:44 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:44 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:44 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Controller Class Initialized
ERROR - 2011-10-02 08:13:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 08:13:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 08:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 08:13:44 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:44 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 08:13:44 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:44 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:44 --> Total execution time: 0.0896
DEBUG - 2011-10-02 08:13:45 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:45 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:45 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:45 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:45 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:45 --> Total execution time: 0.5760
DEBUG - 2011-10-02 08:13:46 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:46 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:46 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:46 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:46 --> Router Class Initialized
ERROR - 2011-10-02 08:13:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:13:54 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:54 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:54 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Controller Class Initialized
ERROR - 2011-10-02 08:13:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 08:13:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 08:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 08:13:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:54 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 08:13:54 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:13:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:13:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:13:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:13:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:13:54 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:54 --> Total execution time: 0.0301
DEBUG - 2011-10-02 08:13:54 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:54 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Router Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Output Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Input Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:13:54 --> Language Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Loader Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Controller Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Model Class Initialized
DEBUG - 2011-10-02 08:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:13:54 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:13:55 --> Final output sent to browser
DEBUG - 2011-10-02 08:13:55 --> Total execution time: 0.6555
DEBUG - 2011-10-02 08:13:56 --> Config Class Initialized
DEBUG - 2011-10-02 08:13:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:13:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:13:56 --> URI Class Initialized
DEBUG - 2011-10-02 08:13:56 --> Router Class Initialized
ERROR - 2011-10-02 08:13:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:14:11 --> Config Class Initialized
DEBUG - 2011-10-02 08:14:11 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:14:11 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:14:11 --> URI Class Initialized
DEBUG - 2011-10-02 08:14:11 --> Router Class Initialized
ERROR - 2011-10-02 08:14:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:14:14 --> Config Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:14:14 --> URI Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Router Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Output Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Input Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:14:14 --> Language Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Loader Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Controller Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:14:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:14:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:14:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:14:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:14:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:14:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:14:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:14:14 --> Final output sent to browser
DEBUG - 2011-10-02 08:14:14 --> Total execution time: 0.0597
DEBUG - 2011-10-02 08:14:16 --> Config Class Initialized
DEBUG - 2011-10-02 08:14:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:14:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:14:16 --> URI Class Initialized
DEBUG - 2011-10-02 08:14:16 --> Router Class Initialized
ERROR - 2011-10-02 08:14:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:14:36 --> Config Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:14:36 --> URI Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Router Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Output Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Input Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:14:36 --> Language Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Loader Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Controller Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:14:36 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:14:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:14:36 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:14:36 --> Final output sent to browser
DEBUG - 2011-10-02 08:14:36 --> Total execution time: 0.2804
DEBUG - 2011-10-02 08:14:37 --> Config Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:14:37 --> URI Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Router Class Initialized
ERROR - 2011-10-02 08:14:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 08:14:37 --> Config Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 08:14:37 --> URI Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Router Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Output Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Input Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 08:14:37 --> Language Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Loader Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Controller Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Model Class Initialized
DEBUG - 2011-10-02 08:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 08:14:37 --> Database Driver Class Initialized
DEBUG - 2011-10-02 08:14:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 08:14:37 --> Helper loaded: url_helper
DEBUG - 2011-10-02 08:14:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 08:14:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 08:14:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 08:14:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 08:14:37 --> Final output sent to browser
DEBUG - 2011-10-02 08:14:37 --> Total execution time: 0.0507
DEBUG - 2011-10-02 09:37:00 --> Config Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:37:00 --> URI Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Router Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Output Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Input Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:37:00 --> Language Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Loader Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Controller Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Model Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Model Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Model Class Initialized
DEBUG - 2011-10-02 09:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:37:00 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:37:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:37:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:37:01 --> Final output sent to browser
DEBUG - 2011-10-02 09:37:01 --> Total execution time: 0.8565
DEBUG - 2011-10-02 09:41:42 --> Config Class Initialized
DEBUG - 2011-10-02 09:41:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:41:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:41:42 --> URI Class Initialized
DEBUG - 2011-10-02 09:41:42 --> Router Class Initialized
DEBUG - 2011-10-02 09:41:42 --> No URI present. Default controller set.
DEBUG - 2011-10-02 09:41:42 --> Output Class Initialized
DEBUG - 2011-10-02 09:41:42 --> Input Class Initialized
DEBUG - 2011-10-02 09:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:41:42 --> Language Class Initialized
DEBUG - 2011-10-02 09:41:43 --> Loader Class Initialized
DEBUG - 2011-10-02 09:41:43 --> Controller Class Initialized
DEBUG - 2011-10-02 09:41:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-02 09:41:44 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:41:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:41:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:41:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:41:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:41:44 --> Final output sent to browser
DEBUG - 2011-10-02 09:41:44 --> Total execution time: 1.1482
DEBUG - 2011-10-02 09:54:31 --> Config Class Initialized
DEBUG - 2011-10-02 09:54:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:54:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:54:31 --> URI Class Initialized
DEBUG - 2011-10-02 09:54:31 --> Router Class Initialized
DEBUG - 2011-10-02 09:54:31 --> Output Class Initialized
DEBUG - 2011-10-02 09:54:31 --> Input Class Initialized
DEBUG - 2011-10-02 09:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:54:31 --> Language Class Initialized
DEBUG - 2011-10-02 09:54:32 --> Loader Class Initialized
DEBUG - 2011-10-02 09:54:32 --> Controller Class Initialized
DEBUG - 2011-10-02 09:54:32 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:32 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:32 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:54:32 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:54:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:54:32 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:54:32 --> Final output sent to browser
DEBUG - 2011-10-02 09:54:32 --> Total execution time: 0.1083
DEBUG - 2011-10-02 09:54:34 --> Config Class Initialized
DEBUG - 2011-10-02 09:54:34 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:54:34 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:54:34 --> URI Class Initialized
DEBUG - 2011-10-02 09:54:34 --> Router Class Initialized
ERROR - 2011-10-02 09:54:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 09:54:51 --> Config Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:54:51 --> URI Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Router Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Output Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Input Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:54:51 --> Language Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Loader Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Controller Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:54:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:54:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:54:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:54:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:54:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:54:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:54:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:54:51 --> Final output sent to browser
DEBUG - 2011-10-02 09:54:51 --> Total execution time: 0.3533
DEBUG - 2011-10-02 09:54:52 --> Config Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:54:52 --> URI Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Router Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Output Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Input Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:54:52 --> Language Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Loader Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Controller Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Model Class Initialized
DEBUG - 2011-10-02 09:54:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:54:52 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:54:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:54:52 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:54:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:54:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:54:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:54:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:54:52 --> Final output sent to browser
DEBUG - 2011-10-02 09:54:52 --> Total execution time: 0.0589
DEBUG - 2011-10-02 09:54:53 --> Config Class Initialized
DEBUG - 2011-10-02 09:54:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:54:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:54:53 --> URI Class Initialized
DEBUG - 2011-10-02 09:54:53 --> Router Class Initialized
ERROR - 2011-10-02 09:54:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 09:55:15 --> Config Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:55:15 --> URI Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Router Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Output Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Input Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:55:15 --> Language Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Loader Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Controller Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:55:15 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:55:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:55:16 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:55:16 --> Final output sent to browser
DEBUG - 2011-10-02 09:55:16 --> Total execution time: 0.7421
DEBUG - 2011-10-02 09:55:17 --> Config Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:55:17 --> URI Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Router Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Output Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Input Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:55:17 --> Language Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Loader Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Controller Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:55:17 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:55:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:55:17 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:55:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:55:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:55:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:55:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:55:17 --> Final output sent to browser
DEBUG - 2011-10-02 09:55:17 --> Total execution time: 0.0567
DEBUG - 2011-10-02 09:55:17 --> Config Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:55:17 --> URI Class Initialized
DEBUG - 2011-10-02 09:55:17 --> Router Class Initialized
ERROR - 2011-10-02 09:55:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 09:55:40 --> Config Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:55:40 --> URI Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Router Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Output Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Input Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:55:40 --> Language Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Loader Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Controller Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:55:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:55:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:55:41 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:55:41 --> Final output sent to browser
DEBUG - 2011-10-02 09:55:41 --> Total execution time: 0.8906
DEBUG - 2011-10-02 09:55:42 --> Config Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:55:42 --> URI Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Router Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Output Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Input Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:55:42 --> Language Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Loader Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Controller Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Model Class Initialized
DEBUG - 2011-10-02 09:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:55:42 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:55:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:55:43 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:55:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:55:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:55:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:55:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:55:43 --> Final output sent to browser
DEBUG - 2011-10-02 09:55:43 --> Total execution time: 0.1339
DEBUG - 2011-10-02 09:55:43 --> Config Class Initialized
DEBUG - 2011-10-02 09:55:43 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:55:43 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:55:43 --> URI Class Initialized
DEBUG - 2011-10-02 09:55:43 --> Router Class Initialized
ERROR - 2011-10-02 09:55:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 09:59:36 --> Config Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:59:36 --> URI Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Router Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Output Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Input Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:59:36 --> Language Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Loader Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Controller Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Model Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Model Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Model Class Initialized
DEBUG - 2011-10-02 09:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:59:36 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:59:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 09:59:36 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:59:36 --> Final output sent to browser
DEBUG - 2011-10-02 09:59:36 --> Total execution time: 0.0879
DEBUG - 2011-10-02 09:59:38 --> Config Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Hooks Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Utf8 Class Initialized
DEBUG - 2011-10-02 09:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 09:59:38 --> URI Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Router Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Output Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Input Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 09:59:38 --> Language Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Loader Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Controller Class Initialized
ERROR - 2011-10-02 09:59:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 09:59:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 09:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 09:59:38 --> Model Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Model Class Initialized
DEBUG - 2011-10-02 09:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 09:59:38 --> Database Driver Class Initialized
DEBUG - 2011-10-02 09:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 09:59:38 --> Helper loaded: url_helper
DEBUG - 2011-10-02 09:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 09:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 09:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 09:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 09:59:38 --> Final output sent to browser
DEBUG - 2011-10-02 09:59:38 --> Total execution time: 0.0423
DEBUG - 2011-10-02 10:07:12 --> Config Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:07:12 --> URI Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Router Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Output Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Input Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:07:12 --> Language Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Loader Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Controller Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:07:12 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:07:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:07:13 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:07:13 --> Final output sent to browser
DEBUG - 2011-10-02 10:07:13 --> Total execution time: 0.4787
DEBUG - 2011-10-02 10:07:29 --> Config Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:07:29 --> URI Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Router Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Output Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Input Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:07:29 --> Language Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Loader Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Controller Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:07:29 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:07:29 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:07:29 --> Final output sent to browser
DEBUG - 2011-10-02 10:07:29 --> Total execution time: 0.4190
DEBUG - 2011-10-02 10:07:45 --> Config Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:07:45 --> URI Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Router Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Output Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Input Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:07:45 --> Language Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Loader Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Controller Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:07:45 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:07:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:07:46 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:07:46 --> Final output sent to browser
DEBUG - 2011-10-02 10:07:46 --> Total execution time: 0.2650
DEBUG - 2011-10-02 10:07:58 --> Config Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:07:58 --> URI Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Router Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Output Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Input Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:07:58 --> Language Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Loader Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Controller Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Model Class Initialized
DEBUG - 2011-10-02 10:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:07:59 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:07:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:07:59 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:07:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:07:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:07:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:07:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:07:59 --> Final output sent to browser
DEBUG - 2011-10-02 10:07:59 --> Total execution time: 0.3344
DEBUG - 2011-10-02 10:08:00 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:00 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:00 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:00 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:01 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:01 --> Total execution time: 0.7430
DEBUG - 2011-10-02 10:08:07 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:07 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:07 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:07 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:07 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:07 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:07 --> Total execution time: 0.0476
DEBUG - 2011-10-02 10:08:22 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:22 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:22 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:22 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:22 --> Total execution time: 0.2085
DEBUG - 2011-10-02 10:08:28 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:28 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:28 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:28 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:28 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:28 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:28 --> Total execution time: 0.0550
DEBUG - 2011-10-02 10:08:37 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:37 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:37 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:37 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:37 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:37 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:37 --> Total execution time: 0.2328
DEBUG - 2011-10-02 10:08:43 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:43 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:43 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:43 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:43 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:43 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:43 --> Total execution time: 0.1868
DEBUG - 2011-10-02 10:08:53 --> Config Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:08:53 --> URI Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Router Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Output Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Input Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:08:53 --> Language Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Loader Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Controller Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:08:53 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:08:53 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:08:53 --> Final output sent to browser
DEBUG - 2011-10-02 10:08:53 --> Total execution time: 0.1111
DEBUG - 2011-10-02 10:09:17 --> Config Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:09:17 --> URI Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Router Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Output Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Input Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:09:17 --> Language Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Loader Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Controller Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Model Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Model Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Model Class Initialized
DEBUG - 2011-10-02 10:09:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:09:17 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:09:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:09:17 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:09:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:09:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:09:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:09:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:09:17 --> Final output sent to browser
DEBUG - 2011-10-02 10:09:17 --> Total execution time: 0.0494
DEBUG - 2011-10-02 10:10:26 --> Config Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:10:26 --> URI Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Router Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Output Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Input Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:10:26 --> Language Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Loader Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Controller Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:10:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:10:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:10:26 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:10:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:10:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:10:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:10:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:10:26 --> Final output sent to browser
DEBUG - 2011-10-02 10:10:26 --> Total execution time: 0.3982
DEBUG - 2011-10-02 10:10:31 --> Config Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:10:31 --> URI Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Router Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Output Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Input Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:10:31 --> Language Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Loader Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Controller Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:10:31 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:10:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:10:31 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:10:31 --> Final output sent to browser
DEBUG - 2011-10-02 10:10:31 --> Total execution time: 0.0938
DEBUG - 2011-10-02 10:10:37 --> Config Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:10:37 --> URI Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Router Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Output Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Input Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:10:37 --> Language Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Loader Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Controller Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:10:37 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:10:37 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:10:37 --> Final output sent to browser
DEBUG - 2011-10-02 10:10:37 --> Total execution time: 0.2133
DEBUG - 2011-10-02 10:10:41 --> Config Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:10:41 --> URI Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Router Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Output Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Input Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:10:41 --> Language Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Loader Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Controller Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:10:41 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:10:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:10:41 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:10:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:10:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:10:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:10:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:10:41 --> Final output sent to browser
DEBUG - 2011-10-02 10:10:41 --> Total execution time: 0.0490
DEBUG - 2011-10-02 10:10:48 --> Config Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:10:48 --> URI Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Router Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Output Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Input Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:10:48 --> Language Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Loader Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Controller Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:10:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:10:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:10:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:10:48 --> Final output sent to browser
DEBUG - 2011-10-02 10:10:48 --> Total execution time: 0.2249
DEBUG - 2011-10-02 10:10:51 --> Config Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:10:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:10:51 --> URI Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Router Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Output Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Input Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:10:51 --> Language Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Loader Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Controller Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:10:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:10:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:10:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:10:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:10:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:10:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:10:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:10:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:10:51 --> Final output sent to browser
DEBUG - 2011-10-02 10:10:51 --> Total execution time: 0.0802
DEBUG - 2011-10-02 10:11:02 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:02 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:02 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:02 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:03 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:03 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:03 --> Total execution time: 1.3064
DEBUG - 2011-10-02 10:11:08 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:08 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:08 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:08 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:08 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:08 --> Total execution time: 0.0509
DEBUG - 2011-10-02 10:11:19 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:19 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:19 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:19 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:19 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:19 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:19 --> Total execution time: 0.3077
DEBUG - 2011-10-02 10:11:22 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:22 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:22 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:22 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:22 --> Total execution time: 0.0479
DEBUG - 2011-10-02 10:11:43 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:43 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:43 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:43 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:43 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:43 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:43 --> Total execution time: 0.3799
DEBUG - 2011-10-02 10:11:47 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:47 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:47 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:47 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:48 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:48 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:48 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:48 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:48 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:48 --> Total execution time: 0.1472
DEBUG - 2011-10-02 10:11:58 --> Config Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:11:58 --> URI Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Router Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Output Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Input Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:11:58 --> Language Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Loader Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Controller Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Model Class Initialized
DEBUG - 2011-10-02 10:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:11:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:11:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:11:58 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:11:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:11:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:11:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:11:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:11:58 --> Final output sent to browser
DEBUG - 2011-10-02 10:11:58 --> Total execution time: 0.2702
DEBUG - 2011-10-02 10:12:01 --> Config Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:12:01 --> URI Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Router Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Output Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Input Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:12:01 --> Language Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Loader Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Controller Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:12:01 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:12:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:12:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:12:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:12:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:12:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:12:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:12:01 --> Final output sent to browser
DEBUG - 2011-10-02 10:12:01 --> Total execution time: 0.0508
DEBUG - 2011-10-02 10:12:13 --> Config Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:12:13 --> URI Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Router Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Output Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Input Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:12:13 --> Language Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Loader Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Controller Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:12:13 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:12:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:12:13 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:12:13 --> Final output sent to browser
DEBUG - 2011-10-02 10:12:13 --> Total execution time: 0.2564
DEBUG - 2011-10-02 10:12:19 --> Config Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:12:19 --> URI Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Router Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Output Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Input Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:12:19 --> Language Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Loader Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Controller Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:12:19 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:12:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:12:19 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:12:19 --> Final output sent to browser
DEBUG - 2011-10-02 10:12:19 --> Total execution time: 0.0543
DEBUG - 2011-10-02 10:12:28 --> Config Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:12:28 --> URI Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Router Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Output Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Input Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:12:28 --> Language Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Loader Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Controller Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:12:28 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:12:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:12:28 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:12:28 --> Final output sent to browser
DEBUG - 2011-10-02 10:12:28 --> Total execution time: 0.3017
DEBUG - 2011-10-02 10:12:55 --> Config Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:12:55 --> URI Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Router Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Output Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Input Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:12:55 --> Language Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Loader Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Controller Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Model Class Initialized
DEBUG - 2011-10-02 10:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:12:55 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:12:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:12:56 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:12:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:12:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:12:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:12:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:12:56 --> Final output sent to browser
DEBUG - 2011-10-02 10:12:56 --> Total execution time: 0.3156
DEBUG - 2011-10-02 10:13:18 --> Config Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:13:18 --> URI Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Router Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Output Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Input Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:13:18 --> Language Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Loader Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Controller Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Model Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Model Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Model Class Initialized
DEBUG - 2011-10-02 10:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:13:18 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:13:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:13:18 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:13:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:13:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:13:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:13:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:13:18 --> Final output sent to browser
DEBUG - 2011-10-02 10:13:18 --> Total execution time: 0.0482
DEBUG - 2011-10-02 10:13:52 --> Config Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:13:52 --> URI Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Router Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Output Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Input Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:13:52 --> Language Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Loader Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Controller Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Model Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Model Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Model Class Initialized
DEBUG - 2011-10-02 10:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:13:52 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:13:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:13:52 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:13:52 --> Final output sent to browser
DEBUG - 2011-10-02 10:13:52 --> Total execution time: 0.1590
DEBUG - 2011-10-02 10:28:18 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:18 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:18 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Controller Class Initialized
ERROR - 2011-10-02 10:28:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:28:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:28:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:18 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:18 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:18 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:28:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:28:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:28:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:28:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:28:18 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:18 --> Total execution time: 0.0461
DEBUG - 2011-10-02 10:28:19 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:20 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:20 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Controller Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:20 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:20 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:20 --> Total execution time: 1.2348
DEBUG - 2011-10-02 10:28:24 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:24 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:24 --> Router Class Initialized
ERROR - 2011-10-02 10:28:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:28:25 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:25 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:25 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Controller Class Initialized
ERROR - 2011-10-02 10:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:25 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:28:25 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:25 --> Total execution time: 0.0318
DEBUG - 2011-10-02 10:28:26 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:26 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:26 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Controller Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:28 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:28 --> Total execution time: 1.9111
DEBUG - 2011-10-02 10:28:29 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:29 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:29 --> Router Class Initialized
ERROR - 2011-10-02 10:28:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:28:34 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:34 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:34 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Controller Class Initialized
ERROR - 2011-10-02 10:28:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:28:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:34 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:34 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:34 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:28:34 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:34 --> Total execution time: 0.0368
DEBUG - 2011-10-02 10:28:35 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:35 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:35 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Controller Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:35 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:36 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:36 --> Total execution time: 0.7276
DEBUG - 2011-10-02 10:28:36 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:36 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:36 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:36 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:36 --> Router Class Initialized
ERROR - 2011-10-02 10:28:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:28:53 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:53 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:53 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Controller Class Initialized
ERROR - 2011-10-02 10:28:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:28:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:28:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:53 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:28:53 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:28:53 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:53 --> Total execution time: 0.0292
DEBUG - 2011-10-02 10:28:54 --> Config Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:28:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:28:54 --> URI Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Router Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Output Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Input Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:28:54 --> Language Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Loader Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Controller Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Model Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:28:54 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:28:54 --> Final output sent to browser
DEBUG - 2011-10-02 10:28:54 --> Total execution time: 0.5657
DEBUG - 2011-10-02 10:29:09 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:09 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:09 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Controller Class Initialized
ERROR - 2011-10-02 10:29:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:29:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:29:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:29:09 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:29:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:29:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:29:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:29:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:29:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:29:09 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:09 --> Total execution time: 0.0320
DEBUG - 2011-10-02 10:29:10 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:10 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:10 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Controller Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:10 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:10 --> Total execution time: 0.6078
DEBUG - 2011-10-02 10:29:11 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:11 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:11 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:11 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:11 --> Router Class Initialized
ERROR - 2011-10-02 10:29:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:29:19 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:19 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:19 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Controller Class Initialized
ERROR - 2011-10-02 10:29:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:29:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:29:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:29:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:19 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:29:20 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:29:20 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:20 --> Total execution time: 0.0513
DEBUG - 2011-10-02 10:29:20 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:20 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:20 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Controller Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:20 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:21 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:21 --> Total execution time: 0.6544
DEBUG - 2011-10-02 10:29:21 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:21 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:21 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:21 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:21 --> Router Class Initialized
ERROR - 2011-10-02 10:29:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:29:25 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:25 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:25 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Controller Class Initialized
ERROR - 2011-10-02 10:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:29:25 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:29:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:29:25 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:25 --> Total execution time: 0.0299
DEBUG - 2011-10-02 10:29:26 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:26 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:26 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Controller Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:26 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:26 --> Total execution time: 0.6197
DEBUG - 2011-10-02 10:29:28 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:28 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:28 --> Router Class Initialized
ERROR - 2011-10-02 10:29:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:29:47 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:47 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Router Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Output Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Input Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:29:47 --> Language Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Loader Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Controller Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Model Class Initialized
DEBUG - 2011-10-02 10:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:29:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:29:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 10:29:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:29:48 --> Final output sent to browser
DEBUG - 2011-10-02 10:29:48 --> Total execution time: 0.6975
DEBUG - 2011-10-02 10:29:54 --> Config Class Initialized
DEBUG - 2011-10-02 10:29:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:29:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:29:54 --> URI Class Initialized
DEBUG - 2011-10-02 10:29:54 --> Router Class Initialized
ERROR - 2011-10-02 10:29:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:32:07 --> Config Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:32:07 --> URI Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Router Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Output Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Input Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:32:07 --> Language Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Loader Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Controller Class Initialized
ERROR - 2011-10-02 10:32:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:32:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:32:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:32:07 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:32:07 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:32:07 --> Final output sent to browser
DEBUG - 2011-10-02 10:32:07 --> Total execution time: 0.0378
DEBUG - 2011-10-02 10:32:08 --> Config Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:32:08 --> URI Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Router Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Output Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Input Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:32:08 --> Language Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Loader Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Controller Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:32:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:32:08 --> Final output sent to browser
DEBUG - 2011-10-02 10:32:08 --> Total execution time: 0.6654
DEBUG - 2011-10-02 10:32:10 --> Config Class Initialized
DEBUG - 2011-10-02 10:32:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:32:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:32:10 --> URI Class Initialized
DEBUG - 2011-10-02 10:32:10 --> Router Class Initialized
ERROR - 2011-10-02 10:32:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:32:22 --> Config Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:32:22 --> URI Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Router Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Output Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Input Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:32:22 --> Language Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Loader Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Controller Class Initialized
ERROR - 2011-10-02 10:32:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:32:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:32:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:32:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:32:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:32:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:32:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:32:22 --> Final output sent to browser
DEBUG - 2011-10-02 10:32:22 --> Total execution time: 0.0357
DEBUG - 2011-10-02 10:32:22 --> Config Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:32:22 --> URI Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Router Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Output Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Input Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:32:22 --> Language Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Loader Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Controller Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:32:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:32:23 --> Final output sent to browser
DEBUG - 2011-10-02 10:32:23 --> Total execution time: 0.5951
DEBUG - 2011-10-02 10:32:24 --> Config Class Initialized
DEBUG - 2011-10-02 10:32:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:32:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:32:24 --> URI Class Initialized
DEBUG - 2011-10-02 10:32:24 --> Router Class Initialized
ERROR - 2011-10-02 10:32:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:44:10 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:10 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Router Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Output Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Input Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:44:10 --> Language Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Loader Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Controller Class Initialized
ERROR - 2011-10-02 10:44:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:44:10 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:44:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:44:10 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:44:10 --> Final output sent to browser
DEBUG - 2011-10-02 10:44:10 --> Total execution time: 0.0329
DEBUG - 2011-10-02 10:44:12 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:12 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Router Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Output Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Input Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:44:12 --> Language Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Loader Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Controller Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:44:12 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:44:12 --> Final output sent to browser
DEBUG - 2011-10-02 10:44:12 --> Total execution time: 0.5001
DEBUG - 2011-10-02 10:44:13 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:13 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:13 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:13 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:13 --> Router Class Initialized
ERROR - 2011-10-02 10:44:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:44:15 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:15 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:15 --> Router Class Initialized
ERROR - 2011-10-02 10:44:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:44:22 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:22 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Router Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Output Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Input Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:44:22 --> Language Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Loader Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Controller Class Initialized
ERROR - 2011-10-02 10:44:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:44:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:44:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:44:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:44:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:44:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:44:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:44:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:44:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:44:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:44:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:44:22 --> Final output sent to browser
DEBUG - 2011-10-02 10:44:22 --> Total execution time: 0.0579
DEBUG - 2011-10-02 10:44:23 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:23 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Router Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Output Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Input Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:44:23 --> Language Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Loader Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Controller Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:44:23 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:44:23 --> Final output sent to browser
DEBUG - 2011-10-02 10:44:23 --> Total execution time: 0.6727
DEBUG - 2011-10-02 10:44:51 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:51 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Router Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Output Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Input Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:44:51 --> Language Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Loader Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Controller Class Initialized
ERROR - 2011-10-02 10:44:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:44:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:44:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:44:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:44:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:44:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:44:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:44:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:44:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:44:51 --> Final output sent to browser
DEBUG - 2011-10-02 10:44:51 --> Total execution time: 0.0384
DEBUG - 2011-10-02 10:44:52 --> Config Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:44:52 --> URI Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Router Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Output Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Input Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:44:52 --> Language Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Loader Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Controller Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Model Class Initialized
DEBUG - 2011-10-02 10:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:44:52 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:44:53 --> Final output sent to browser
DEBUG - 2011-10-02 10:44:53 --> Total execution time: 0.5577
DEBUG - 2011-10-02 10:45:06 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:06 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:06 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Controller Class Initialized
ERROR - 2011-10-02 10:45:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:45:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:45:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:06 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:06 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:06 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:45:06 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:06 --> Total execution time: 0.1397
DEBUG - 2011-10-02 10:45:07 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:07 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:07 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Controller Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:07 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:07 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:07 --> Total execution time: 0.9234
DEBUG - 2011-10-02 10:45:14 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:14 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:14 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Controller Class Initialized
ERROR - 2011-10-02 10:45:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:45:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:45:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:14 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:45:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:45:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:45:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:45:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:45:14 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:14 --> Total execution time: 0.0335
DEBUG - 2011-10-02 10:45:15 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:15 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:15 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Controller Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:15 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:16 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:16 --> Total execution time: 0.6502
DEBUG - 2011-10-02 10:45:26 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:26 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:26 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Controller Class Initialized
ERROR - 2011-10-02 10:45:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:45:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:26 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:45:26 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:26 --> Total execution time: 0.0307
DEBUG - 2011-10-02 10:45:30 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:30 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:30 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Controller Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:30 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:30 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:30 --> Total execution time: 0.5890
DEBUG - 2011-10-02 10:45:31 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:31 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:31 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Controller Class Initialized
ERROR - 2011-10-02 10:45:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:45:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:31 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:31 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:31 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:45:31 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:31 --> Total execution time: 0.0328
DEBUG - 2011-10-02 10:45:39 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:39 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:39 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Controller Class Initialized
ERROR - 2011-10-02 10:45:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:45:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:39 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:39 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:45:39 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:45:39 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:39 --> Total execution time: 0.0355
DEBUG - 2011-10-02 10:45:40 --> Config Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:45:40 --> URI Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Router Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Output Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Input Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:45:40 --> Language Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Loader Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Controller Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Model Class Initialized
DEBUG - 2011-10-02 10:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:45:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:45:41 --> Final output sent to browser
DEBUG - 2011-10-02 10:45:41 --> Total execution time: 0.6153
DEBUG - 2011-10-02 10:49:40 --> Config Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:49:40 --> URI Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Router Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Output Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Input Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:49:40 --> Language Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Loader Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Controller Class Initialized
ERROR - 2011-10-02 10:49:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:49:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:49:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:49:40 --> Model Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Model Class Initialized
DEBUG - 2011-10-02 10:49:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:49:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:49:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:49:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:49:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:49:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:49:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:49:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:49:40 --> Final output sent to browser
DEBUG - 2011-10-02 10:49:40 --> Total execution time: 0.0381
DEBUG - 2011-10-02 10:49:42 --> Config Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:49:42 --> URI Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Router Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Output Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Input Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:49:42 --> Language Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Loader Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Controller Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Model Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Model Class Initialized
DEBUG - 2011-10-02 10:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:49:42 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:49:43 --> Final output sent to browser
DEBUG - 2011-10-02 10:49:43 --> Total execution time: 0.5072
DEBUG - 2011-10-02 10:49:45 --> Config Class Initialized
DEBUG - 2011-10-02 10:49:45 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:49:45 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:49:45 --> URI Class Initialized
DEBUG - 2011-10-02 10:49:45 --> Router Class Initialized
ERROR - 2011-10-02 10:49:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:50:09 --> Config Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:50:09 --> URI Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Router Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Output Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Input Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:50:09 --> Language Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Loader Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Controller Class Initialized
ERROR - 2011-10-02 10:50:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:50:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:50:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:50:09 --> Model Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Model Class Initialized
DEBUG - 2011-10-02 10:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:50:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:50:10 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:50:10 --> Final output sent to browser
DEBUG - 2011-10-02 10:50:10 --> Total execution time: 0.8651
DEBUG - 2011-10-02 10:50:11 --> Config Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:50:11 --> URI Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Router Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Output Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Input Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:50:11 --> Language Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Loader Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Controller Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Model Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Model Class Initialized
DEBUG - 2011-10-02 10:50:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:50:11 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:50:12 --> Final output sent to browser
DEBUG - 2011-10-02 10:50:12 --> Total execution time: 0.8874
DEBUG - 2011-10-02 10:50:14 --> Config Class Initialized
DEBUG - 2011-10-02 10:50:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:50:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:50:14 --> URI Class Initialized
DEBUG - 2011-10-02 10:50:14 --> Router Class Initialized
ERROR - 2011-10-02 10:50:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:53:51 --> Config Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:53:51 --> URI Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Router Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Output Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Input Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:53:51 --> Language Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Loader Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Controller Class Initialized
ERROR - 2011-10-02 10:53:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:53:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:53:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Model Class Initialized
DEBUG - 2011-10-02 10:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:53:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:53:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:53:51 --> Final output sent to browser
DEBUG - 2011-10-02 10:53:51 --> Total execution time: 0.3283
DEBUG - 2011-10-02 10:53:53 --> Config Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:53:53 --> URI Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Router Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Output Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Input Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:53:53 --> Language Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Loader Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Controller Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Model Class Initialized
DEBUG - 2011-10-02 10:53:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:53:53 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:53:54 --> Final output sent to browser
DEBUG - 2011-10-02 10:53:54 --> Total execution time: 0.7207
DEBUG - 2011-10-02 10:53:55 --> Config Class Initialized
DEBUG - 2011-10-02 10:53:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:53:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:53:55 --> URI Class Initialized
DEBUG - 2011-10-02 10:53:55 --> Router Class Initialized
ERROR - 2011-10-02 10:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:53:56 --> Config Class Initialized
DEBUG - 2011-10-02 10:53:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:53:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:53:56 --> URI Class Initialized
DEBUG - 2011-10-02 10:53:56 --> Router Class Initialized
ERROR - 2011-10-02 10:53:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:53:57 --> Config Class Initialized
DEBUG - 2011-10-02 10:53:57 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:53:57 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:53:57 --> URI Class Initialized
DEBUG - 2011-10-02 10:53:57 --> Router Class Initialized
ERROR - 2011-10-02 10:53:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 10:54:08 --> Config Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:54:08 --> URI Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Router Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Output Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Input Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:54:08 --> Language Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Loader Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Controller Class Initialized
ERROR - 2011-10-02 10:54:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:54:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:54:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Model Class Initialized
DEBUG - 2011-10-02 10:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:54:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:54:08 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:54:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:54:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:54:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:54:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:54:08 --> Final output sent to browser
DEBUG - 2011-10-02 10:54:08 --> Total execution time: 0.0329
DEBUG - 2011-10-02 10:54:10 --> Config Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:54:10 --> URI Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Router Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Output Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Input Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:54:10 --> Language Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Loader Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Controller Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Model Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Model Class Initialized
DEBUG - 2011-10-02 10:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:54:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:54:11 --> Final output sent to browser
DEBUG - 2011-10-02 10:54:11 --> Total execution time: 0.6387
DEBUG - 2011-10-02 10:58:59 --> Config Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:58:59 --> URI Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Router Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Output Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Input Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:58:59 --> Language Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Loader Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Controller Class Initialized
ERROR - 2011-10-02 10:58:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 10:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 10:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:58:59 --> Model Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Model Class Initialized
DEBUG - 2011-10-02 10:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:58:59 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 10:58:59 --> Helper loaded: url_helper
DEBUG - 2011-10-02 10:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 10:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 10:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 10:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 10:58:59 --> Final output sent to browser
DEBUG - 2011-10-02 10:58:59 --> Total execution time: 0.0325
DEBUG - 2011-10-02 10:59:01 --> Config Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:59:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:59:01 --> URI Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Router Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Output Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Input Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 10:59:01 --> Language Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Loader Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Controller Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Model Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Model Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 10:59:01 --> Database Driver Class Initialized
DEBUG - 2011-10-02 10:59:01 --> Final output sent to browser
DEBUG - 2011-10-02 10:59:01 --> Total execution time: 0.5513
DEBUG - 2011-10-02 10:59:04 --> Config Class Initialized
DEBUG - 2011-10-02 10:59:04 --> Hooks Class Initialized
DEBUG - 2011-10-02 10:59:04 --> Utf8 Class Initialized
DEBUG - 2011-10-02 10:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 10:59:04 --> URI Class Initialized
DEBUG - 2011-10-02 10:59:04 --> Router Class Initialized
ERROR - 2011-10-02 10:59:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 11:43:12 --> Config Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 11:43:12 --> URI Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Router Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Output Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Input Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 11:43:12 --> Language Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Loader Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Controller Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Model Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Model Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Model Class Initialized
DEBUG - 2011-10-02 11:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 11:43:12 --> Database Driver Class Initialized
DEBUG - 2011-10-02 11:43:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 11:43:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 11:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 11:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 11:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 11:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 11:43:14 --> Final output sent to browser
DEBUG - 2011-10-02 11:43:14 --> Total execution time: 2.2333
DEBUG - 2011-10-02 11:53:10 --> Config Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 11:53:10 --> URI Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Router Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Output Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Input Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 11:53:10 --> Language Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Loader Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Controller Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Model Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Model Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Model Class Initialized
DEBUG - 2011-10-02 11:53:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 11:53:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 11:53:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 11:53:10 --> Helper loaded: url_helper
DEBUG - 2011-10-02 11:53:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 11:53:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 11:53:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 11:53:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 11:53:10 --> Final output sent to browser
DEBUG - 2011-10-02 11:53:10 --> Total execution time: 0.0532
DEBUG - 2011-10-02 11:53:14 --> Config Class Initialized
DEBUG - 2011-10-02 11:53:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 11:53:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 11:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 11:53:14 --> URI Class Initialized
DEBUG - 2011-10-02 11:53:14 --> Router Class Initialized
ERROR - 2011-10-02 11:53:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 11:53:14 --> Config Class Initialized
DEBUG - 2011-10-02 11:53:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 11:53:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 11:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 11:53:14 --> URI Class Initialized
DEBUG - 2011-10-02 11:53:14 --> Router Class Initialized
ERROR - 2011-10-02 11:53:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 11:53:25 --> Config Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 11:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 11:53:25 --> URI Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Router Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Output Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Input Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 11:53:25 --> Language Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Loader Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Controller Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Model Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Model Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Model Class Initialized
DEBUG - 2011-10-02 11:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 11:53:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 11:53:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 11:53:26 --> Helper loaded: url_helper
DEBUG - 2011-10-02 11:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 11:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 11:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 11:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 11:53:26 --> Final output sent to browser
DEBUG - 2011-10-02 11:53:26 --> Total execution time: 0.5256
DEBUG - 2011-10-02 12:12:10 --> Config Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:12:10 --> URI Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Router Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Output Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Input Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:12:10 --> Language Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Loader Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Controller Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Model Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Model Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Model Class Initialized
DEBUG - 2011-10-02 12:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:12:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:12:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:12:10 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:12:10 --> Final output sent to browser
DEBUG - 2011-10-02 12:12:10 --> Total execution time: 0.4136
DEBUG - 2011-10-02 12:12:14 --> Config Class Initialized
DEBUG - 2011-10-02 12:12:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:12:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:12:14 --> URI Class Initialized
DEBUG - 2011-10-02 12:12:14 --> Router Class Initialized
ERROR - 2011-10-02 12:12:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:12:16 --> Config Class Initialized
DEBUG - 2011-10-02 12:12:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:12:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:12:16 --> URI Class Initialized
DEBUG - 2011-10-02 12:12:16 --> Router Class Initialized
ERROR - 2011-10-02 12:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:17:00 --> Config Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:17:00 --> URI Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Router Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Output Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Input Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:17:00 --> Language Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Loader Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Controller Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Model Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Model Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Model Class Initialized
DEBUG - 2011-10-02 12:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:17:00 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:17:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:17:00 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:17:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:17:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:17:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:17:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:17:00 --> Final output sent to browser
DEBUG - 2011-10-02 12:17:00 --> Total execution time: 0.0516
DEBUG - 2011-10-02 12:17:02 --> Config Class Initialized
DEBUG - 2011-10-02 12:17:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:17:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:17:02 --> URI Class Initialized
DEBUG - 2011-10-02 12:17:02 --> Router Class Initialized
ERROR - 2011-10-02 12:17:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:21:20 --> Config Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:21:20 --> URI Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Router Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Output Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Input Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:21:20 --> Language Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Loader Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Controller Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:21:20 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:21:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:21:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:21:22 --> Final output sent to browser
DEBUG - 2011-10-02 12:21:22 --> Total execution time: 1.5477
DEBUG - 2011-10-02 12:21:22 --> Config Class Initialized
DEBUG - 2011-10-02 12:21:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:21:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:21:22 --> URI Class Initialized
DEBUG - 2011-10-02 12:21:22 --> Router Class Initialized
ERROR - 2011-10-02 12:21:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:21:30 --> Config Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:21:30 --> URI Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Router Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Output Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Input Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:21:30 --> Language Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Loader Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Controller Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:21:30 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:21:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:21:31 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:21:31 --> Final output sent to browser
DEBUG - 2011-10-02 12:21:31 --> Total execution time: 1.0178
DEBUG - 2011-10-02 12:21:32 --> Config Class Initialized
DEBUG - 2011-10-02 12:21:32 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:21:32 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:21:32 --> URI Class Initialized
DEBUG - 2011-10-02 12:21:32 --> Router Class Initialized
ERROR - 2011-10-02 12:21:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:21:54 --> Config Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:21:54 --> URI Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Router Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Output Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Input Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:21:54 --> Language Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Loader Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Controller Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Model Class Initialized
DEBUG - 2011-10-02 12:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:21:54 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:21:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:21:54 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:21:54 --> Final output sent to browser
DEBUG - 2011-10-02 12:21:54 --> Total execution time: 0.2675
DEBUG - 2011-10-02 12:21:55 --> Config Class Initialized
DEBUG - 2011-10-02 12:21:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:21:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:21:55 --> URI Class Initialized
DEBUG - 2011-10-02 12:21:55 --> Router Class Initialized
ERROR - 2011-10-02 12:21:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:22:00 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:00 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Router Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Output Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Input Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:22:00 --> Language Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Loader Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Controller Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:22:00 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:22:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:22:00 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:22:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:22:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:22:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:22:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:22:00 --> Final output sent to browser
DEBUG - 2011-10-02 12:22:00 --> Total execution time: 0.7439
DEBUG - 2011-10-02 12:22:01 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:01 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:01 --> Router Class Initialized
ERROR - 2011-10-02 12:22:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:22:09 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:09 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Router Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Output Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Input Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:22:09 --> Language Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Loader Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Controller Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:22:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:22:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:22:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:22:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:22:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:22:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:22:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:22:09 --> Final output sent to browser
DEBUG - 2011-10-02 12:22:09 --> Total execution time: 0.4000
DEBUG - 2011-10-02 12:22:10 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:10 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:10 --> Router Class Initialized
ERROR - 2011-10-02 12:22:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:22:15 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:15 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Router Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Output Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Input Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:22:15 --> Language Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Loader Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Controller Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:22:15 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:22:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:22:15 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:22:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:22:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:22:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:22:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:22:15 --> Final output sent to browser
DEBUG - 2011-10-02 12:22:15 --> Total execution time: 0.2388
DEBUG - 2011-10-02 12:22:16 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:16 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:16 --> Router Class Initialized
ERROR - 2011-10-02 12:22:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:22:21 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:21 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Router Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Output Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Input Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:22:21 --> Language Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Loader Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Controller Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:22:21 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:22:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:22:21 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:22:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:22:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:22:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:22:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:22:21 --> Final output sent to browser
DEBUG - 2011-10-02 12:22:21 --> Total execution time: 0.2466
DEBUG - 2011-10-02 12:22:22 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:22 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:22 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:22 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:22 --> Router Class Initialized
ERROR - 2011-10-02 12:22:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:22:27 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:27 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Router Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Output Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Input Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:22:27 --> Language Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Loader Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Controller Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Model Class Initialized
DEBUG - 2011-10-02 12:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:22:27 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:22:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:22:27 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:22:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:22:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:22:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:22:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:22:27 --> Final output sent to browser
DEBUG - 2011-10-02 12:22:27 --> Total execution time: 0.2951
DEBUG - 2011-10-02 12:22:28 --> Config Class Initialized
DEBUG - 2011-10-02 12:22:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:22:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:22:28 --> URI Class Initialized
DEBUG - 2011-10-02 12:22:28 --> Router Class Initialized
ERROR - 2011-10-02 12:22:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:50:19 --> Config Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:50:19 --> URI Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Router Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Output Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Input Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:50:19 --> Language Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Loader Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Controller Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Model Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Model Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Model Class Initialized
DEBUG - 2011-10-02 12:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:50:19 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:50:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:50:20 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:50:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:50:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:50:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:50:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:50:20 --> Final output sent to browser
DEBUG - 2011-10-02 12:50:20 --> Total execution time: 1.0319
DEBUG - 2011-10-02 12:50:25 --> Config Class Initialized
DEBUG - 2011-10-02 12:50:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:50:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:50:25 --> URI Class Initialized
DEBUG - 2011-10-02 12:50:25 --> Router Class Initialized
ERROR - 2011-10-02 12:50:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 12:50:39 --> Config Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Hooks Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Utf8 Class Initialized
DEBUG - 2011-10-02 12:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 12:50:39 --> URI Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Router Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Output Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Input Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 12:50:39 --> Language Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Loader Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Controller Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Model Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Model Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Model Class Initialized
DEBUG - 2011-10-02 12:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 12:50:39 --> Database Driver Class Initialized
DEBUG - 2011-10-02 12:50:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 12:50:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 12:50:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 12:50:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 12:50:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 12:50:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 12:50:40 --> Final output sent to browser
DEBUG - 2011-10-02 12:50:40 --> Total execution time: 0.7094
DEBUG - 2011-10-02 13:18:03 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:03 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Router Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Output Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Input Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:18:03 --> Language Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Loader Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Controller Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:18:03 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:18:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:18:03 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:18:03 --> Final output sent to browser
DEBUG - 2011-10-02 13:18:03 --> Total execution time: 0.3977
DEBUG - 2011-10-02 13:18:07 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:07 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:07 --> Router Class Initialized
ERROR - 2011-10-02 13:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:18:14 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:14 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Router Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Output Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Input Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:18:14 --> Language Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Loader Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Controller Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:18:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:18:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:18:14 --> Final output sent to browser
DEBUG - 2011-10-02 13:18:14 --> Total execution time: 0.3860
DEBUG - 2011-10-02 13:18:17 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:17 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:17 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:17 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:17 --> Router Class Initialized
ERROR - 2011-10-02 13:18:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:18:17 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:17 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:17 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:17 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:17 --> Router Class Initialized
ERROR - 2011-10-02 13:18:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:18:28 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:28 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Router Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Output Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Input Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:18:28 --> Language Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Loader Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Controller Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:18:28 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:18:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:18:29 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:18:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:18:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:18:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:18:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:18:29 --> Final output sent to browser
DEBUG - 2011-10-02 13:18:29 --> Total execution time: 1.0661
DEBUG - 2011-10-02 13:18:30 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:30 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Router Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Output Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Input Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:18:30 --> Language Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Loader Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Controller Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:18:30 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:18:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:18:30 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:18:30 --> Final output sent to browser
DEBUG - 2011-10-02 13:18:30 --> Total execution time: 0.0964
DEBUG - 2011-10-02 13:18:31 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:31 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:31 --> Router Class Initialized
ERROR - 2011-10-02 13:18:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:18:47 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:47 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Router Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Output Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Input Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:18:48 --> Language Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Loader Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Controller Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Model Class Initialized
DEBUG - 2011-10-02 13:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:18:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:18:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:18:48 --> Final output sent to browser
DEBUG - 2011-10-02 13:18:48 --> Total execution time: 0.4007
DEBUG - 2011-10-02 13:18:50 --> Config Class Initialized
DEBUG - 2011-10-02 13:18:50 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:18:50 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:18:50 --> URI Class Initialized
DEBUG - 2011-10-02 13:18:50 --> Router Class Initialized
ERROR - 2011-10-02 13:18:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:19:13 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:13 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Router Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Output Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Input Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:19:13 --> Language Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Loader Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Controller Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:19:13 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:19:13 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:19:13 --> Final output sent to browser
DEBUG - 2011-10-02 13:19:13 --> Total execution time: 0.6440
DEBUG - 2011-10-02 13:19:15 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:15 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:15 --> Router Class Initialized
ERROR - 2011-10-02 13:19:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:19:15 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:15 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:15 --> Router Class Initialized
ERROR - 2011-10-02 13:19:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:19:31 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:31 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Router Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Output Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Input Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:19:31 --> Language Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Loader Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Controller Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:19:31 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:19:31 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:19:31 --> Final output sent to browser
DEBUG - 2011-10-02 13:19:31 --> Total execution time: 0.2639
DEBUG - 2011-10-02 13:19:33 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:33 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:33 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:33 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:33 --> Router Class Initialized
ERROR - 2011-10-02 13:19:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:19:40 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:40 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Router Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Output Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Input Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:19:40 --> Language Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Loader Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Controller Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Model Class Initialized
DEBUG - 2011-10-02 13:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:19:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:19:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:19:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:19:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:19:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:19:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:19:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:19:40 --> Final output sent to browser
DEBUG - 2011-10-02 13:19:40 --> Total execution time: 0.2654
DEBUG - 2011-10-02 13:19:42 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:42 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:42 --> Router Class Initialized
ERROR - 2011-10-02 13:19:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:19:43 --> Config Class Initialized
DEBUG - 2011-10-02 13:19:43 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:19:43 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:19:43 --> URI Class Initialized
DEBUG - 2011-10-02 13:19:43 --> Router Class Initialized
ERROR - 2011-10-02 13:19:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:16 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:16 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:16 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:16 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:16 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:16 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:16 --> Total execution time: 0.3790
DEBUG - 2011-10-02 13:23:20 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:20 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:20 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:20 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:20 --> Router Class Initialized
ERROR - 2011-10-02 13:23:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:21 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:21 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:21 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:21 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:21 --> Router Class Initialized
ERROR - 2011-10-02 13:23:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:24 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:24 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:24 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:24 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:24 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:24 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:24 --> Total execution time: 0.2615
DEBUG - 2011-10-02 13:23:26 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:26 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:26 --> Router Class Initialized
ERROR - 2011-10-02 13:23:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:29 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:29 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:29 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:29 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:29 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:29 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:29 --> Total execution time: 0.0664
DEBUG - 2011-10-02 13:23:31 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:31 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:31 --> Router Class Initialized
ERROR - 2011-10-02 13:23:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:32 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:32 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:32 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:32 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:32 --> Router Class Initialized
ERROR - 2011-10-02 13:23:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:38 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:38 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:38 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:38 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:38 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:38 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:38 --> Total execution time: 0.0581
DEBUG - 2011-10-02 13:23:40 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:40 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:40 --> Router Class Initialized
ERROR - 2011-10-02 13:23:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:44 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:44 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:44 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:44 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:45 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:45 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:45 --> Total execution time: 0.3110
DEBUG - 2011-10-02 13:23:47 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:47 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:47 --> Router Class Initialized
ERROR - 2011-10-02 13:23:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:51 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:51 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:51 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:51 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:51 --> Total execution time: 0.6367
DEBUG - 2011-10-02 13:23:53 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:53 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:53 --> Router Class Initialized
ERROR - 2011-10-02 13:23:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:23:58 --> Config Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:23:58 --> URI Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Router Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Output Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Input Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:23:58 --> Language Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Loader Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Controller Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Model Class Initialized
DEBUG - 2011-10-02 13:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:23:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:23:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:23:58 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:23:58 --> Final output sent to browser
DEBUG - 2011-10-02 13:23:58 --> Total execution time: 0.0478
DEBUG - 2011-10-02 13:24:00 --> Config Class Initialized
DEBUG - 2011-10-02 13:24:00 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:24:00 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:24:00 --> URI Class Initialized
DEBUG - 2011-10-02 13:24:00 --> Router Class Initialized
ERROR - 2011-10-02 13:24:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:24:06 --> Config Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:24:06 --> URI Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Router Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Output Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Input Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:24:06 --> Language Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Loader Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Controller Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Model Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Model Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Model Class Initialized
DEBUG - 2011-10-02 13:24:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:24:06 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:24:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:24:06 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:24:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:24:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:24:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:24:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:24:06 --> Final output sent to browser
DEBUG - 2011-10-02 13:24:06 --> Total execution time: 0.2600
DEBUG - 2011-10-02 13:24:07 --> Config Class Initialized
DEBUG - 2011-10-02 13:24:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:24:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:24:07 --> URI Class Initialized
DEBUG - 2011-10-02 13:24:07 --> Router Class Initialized
ERROR - 2011-10-02 13:24:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 13:57:42 --> Config Class Initialized
DEBUG - 2011-10-02 13:57:42 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:57:42 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:57:42 --> URI Class Initialized
DEBUG - 2011-10-02 13:57:42 --> Router Class Initialized
DEBUG - 2011-10-02 13:57:42 --> Output Class Initialized
DEBUG - 2011-10-02 13:57:42 --> Input Class Initialized
DEBUG - 2011-10-02 13:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 13:57:42 --> Language Class Initialized
DEBUG - 2011-10-02 13:57:43 --> Loader Class Initialized
DEBUG - 2011-10-02 13:57:43 --> Controller Class Initialized
DEBUG - 2011-10-02 13:57:43 --> Model Class Initialized
DEBUG - 2011-10-02 13:57:43 --> Model Class Initialized
DEBUG - 2011-10-02 13:57:43 --> Model Class Initialized
DEBUG - 2011-10-02 13:57:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 13:57:43 --> Database Driver Class Initialized
DEBUG - 2011-10-02 13:57:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 13:57:44 --> Helper loaded: url_helper
DEBUG - 2011-10-02 13:57:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 13:57:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 13:57:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 13:57:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 13:57:44 --> Final output sent to browser
DEBUG - 2011-10-02 13:57:44 --> Total execution time: 1.9043
DEBUG - 2011-10-02 13:57:46 --> Config Class Initialized
DEBUG - 2011-10-02 13:57:46 --> Hooks Class Initialized
DEBUG - 2011-10-02 13:57:46 --> Utf8 Class Initialized
DEBUG - 2011-10-02 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 13:57:46 --> URI Class Initialized
DEBUG - 2011-10-02 13:57:46 --> Router Class Initialized
ERROR - 2011-10-02 13:57:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 14:02:04 --> Config Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:02:04 --> URI Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Router Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Output Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Input Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:02:04 --> Language Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Loader Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Controller Class Initialized
ERROR - 2011-10-02 14:02:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 14:02:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 14:02:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 14:02:04 --> Model Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Model Class Initialized
DEBUG - 2011-10-02 14:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:02:04 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:02:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 14:02:04 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:02:04 --> Final output sent to browser
DEBUG - 2011-10-02 14:02:04 --> Total execution time: 0.0704
DEBUG - 2011-10-02 14:02:05 --> Config Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:02:05 --> URI Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Router Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Output Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Input Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:02:05 --> Language Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Loader Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Controller Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Model Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Model Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:02:05 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:02:05 --> Final output sent to browser
DEBUG - 2011-10-02 14:02:05 --> Total execution time: 0.7516
DEBUG - 2011-10-02 14:02:06 --> Config Class Initialized
DEBUG - 2011-10-02 14:02:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:02:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:02:06 --> URI Class Initialized
DEBUG - 2011-10-02 14:02:06 --> Router Class Initialized
ERROR - 2011-10-02 14:02:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 14:02:07 --> Config Class Initialized
DEBUG - 2011-10-02 14:02:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:02:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:02:07 --> URI Class Initialized
DEBUG - 2011-10-02 14:02:07 --> Router Class Initialized
ERROR - 2011-10-02 14:02:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 14:30:51 --> Config Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:30:51 --> URI Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Router Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Output Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Input Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:30:51 --> Language Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Loader Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Controller Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Model Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Model Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Model Class Initialized
DEBUG - 2011-10-02 14:30:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:30:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:30:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 14:30:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:30:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:30:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:30:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:30:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:30:51 --> Final output sent to browser
DEBUG - 2011-10-02 14:30:51 --> Total execution time: 0.3162
DEBUG - 2011-10-02 14:30:53 --> Config Class Initialized
DEBUG - 2011-10-02 14:30:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:30:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:30:53 --> URI Class Initialized
DEBUG - 2011-10-02 14:30:53 --> Router Class Initialized
ERROR - 2011-10-02 14:30:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 14:31:08 --> Config Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:31:08 --> URI Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Router Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Output Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Input Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:31:08 --> Language Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Loader Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Controller Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:31:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:31:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 14:31:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:31:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:31:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:31:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:31:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:31:09 --> Final output sent to browser
DEBUG - 2011-10-02 14:31:09 --> Total execution time: 0.5002
DEBUG - 2011-10-02 14:31:21 --> Config Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:31:21 --> URI Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Router Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Output Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Input Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:31:21 --> Language Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Loader Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Controller Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:31:22 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:31:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 14:31:22 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:31:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:31:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:31:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:31:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:31:22 --> Final output sent to browser
DEBUG - 2011-10-02 14:31:22 --> Total execution time: 0.2306
DEBUG - 2011-10-02 14:31:29 --> Config Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:31:29 --> URI Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Router Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Output Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Input Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:31:29 --> Language Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Loader Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Controller Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:31:29 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:31:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 14:31:29 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:31:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:31:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:31:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:31:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:31:29 --> Final output sent to browser
DEBUG - 2011-10-02 14:31:29 --> Total execution time: 0.8074
DEBUG - 2011-10-02 14:31:34 --> Config Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:31:34 --> URI Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Router Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Output Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Input Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:31:34 --> Language Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Loader Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Controller Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:31:34 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:31:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 14:31:34 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:31:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:31:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:31:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:31:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:31:34 --> Final output sent to browser
DEBUG - 2011-10-02 14:31:34 --> Total execution time: 0.3370
DEBUG - 2011-10-02 14:31:39 --> Config Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:31:39 --> URI Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Router Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Output Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Input Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:31:39 --> Language Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Loader Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Controller Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Model Class Initialized
DEBUG - 2011-10-02 14:31:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:31:39 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:31:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 14:31:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:31:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:31:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:31:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:31:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:31:40 --> Final output sent to browser
DEBUG - 2011-10-02 14:31:40 --> Total execution time: 0.0559
DEBUG - 2011-10-02 14:57:39 --> Config Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:57:39 --> URI Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Router Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Output Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Input Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:57:39 --> Language Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Loader Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Controller Class Initialized
ERROR - 2011-10-02 14:57:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 14:57:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 14:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 14:57:39 --> Model Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Model Class Initialized
DEBUG - 2011-10-02 14:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:57:39 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 14:57:39 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:57:39 --> Final output sent to browser
DEBUG - 2011-10-02 14:57:39 --> Total execution time: 0.0455
DEBUG - 2011-10-02 14:57:41 --> Config Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:57:41 --> URI Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Router Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Output Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Input Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:57:41 --> Language Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Loader Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Controller Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Model Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Model Class Initialized
DEBUG - 2011-10-02 14:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:57:41 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:57:42 --> Final output sent to browser
DEBUG - 2011-10-02 14:57:42 --> Total execution time: 0.5975
DEBUG - 2011-10-02 14:57:45 --> Config Class Initialized
DEBUG - 2011-10-02 14:57:45 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:57:45 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:57:45 --> URI Class Initialized
DEBUG - 2011-10-02 14:57:45 --> Router Class Initialized
ERROR - 2011-10-02 14:57:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 14:58:13 --> Config Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:58:13 --> URI Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Router Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Output Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Input Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:58:13 --> Language Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Loader Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Controller Class Initialized
ERROR - 2011-10-02 14:58:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 14:58:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 14:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 14:58:13 --> Model Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Model Class Initialized
DEBUG - 2011-10-02 14:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:58:13 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 14:58:13 --> Helper loaded: url_helper
DEBUG - 2011-10-02 14:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 14:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 14:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 14:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 14:58:13 --> Final output sent to browser
DEBUG - 2011-10-02 14:58:13 --> Total execution time: 0.0485
DEBUG - 2011-10-02 14:58:14 --> Config Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:58:14 --> URI Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Router Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Output Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Input Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 14:58:14 --> Language Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Loader Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Controller Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Model Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Model Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 14:58:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 14:58:14 --> Final output sent to browser
DEBUG - 2011-10-02 14:58:14 --> Total execution time: 0.5625
DEBUG - 2011-10-02 14:58:16 --> Config Class Initialized
DEBUG - 2011-10-02 14:58:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:58:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:58:16 --> URI Class Initialized
DEBUG - 2011-10-02 14:58:16 --> Router Class Initialized
ERROR - 2011-10-02 14:58:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 14:58:23 --> Config Class Initialized
DEBUG - 2011-10-02 14:58:23 --> Hooks Class Initialized
DEBUG - 2011-10-02 14:58:23 --> Utf8 Class Initialized
DEBUG - 2011-10-02 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 14:58:23 --> URI Class Initialized
DEBUG - 2011-10-02 14:58:23 --> Router Class Initialized
ERROR - 2011-10-02 14:58:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 15:16:51 --> Config Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:16:51 --> URI Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Router Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Output Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Input Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:16:51 --> Language Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Loader Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Controller Class Initialized
ERROR - 2011-10-02 15:16:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:16:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:16:51 --> Model Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Model Class Initialized
DEBUG - 2011-10-02 15:16:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:16:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:16:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:16:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:16:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:16:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:16:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:16:51 --> Final output sent to browser
DEBUG - 2011-10-02 15:16:51 --> Total execution time: 0.1949
DEBUG - 2011-10-02 15:16:52 --> Config Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:16:52 --> URI Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Router Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Output Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Input Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:16:52 --> Language Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Loader Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Controller Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Model Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Model Class Initialized
DEBUG - 2011-10-02 15:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:16:52 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:16:53 --> Final output sent to browser
DEBUG - 2011-10-02 15:16:53 --> Total execution time: 0.6427
DEBUG - 2011-10-02 15:16:54 --> Config Class Initialized
DEBUG - 2011-10-02 15:16:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:16:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:16:54 --> URI Class Initialized
DEBUG - 2011-10-02 15:16:54 --> Router Class Initialized
ERROR - 2011-10-02 15:16:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 15:17:44 --> Config Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:17:44 --> URI Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Router Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Output Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Input Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:17:44 --> Language Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Loader Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Controller Class Initialized
ERROR - 2011-10-02 15:17:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:17:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:17:44 --> Model Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Model Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:17:44 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:17:44 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:17:44 --> Final output sent to browser
DEBUG - 2011-10-02 15:17:44 --> Total execution time: 0.0386
DEBUG - 2011-10-02 15:17:44 --> Config Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:17:44 --> URI Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Router Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Output Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Input Class Initialized
DEBUG - 2011-10-02 15:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:17:44 --> Language Class Initialized
DEBUG - 2011-10-02 15:17:45 --> Loader Class Initialized
DEBUG - 2011-10-02 15:17:45 --> Controller Class Initialized
DEBUG - 2011-10-02 15:17:45 --> Model Class Initialized
DEBUG - 2011-10-02 15:17:45 --> Model Class Initialized
DEBUG - 2011-10-02 15:17:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:17:45 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:17:45 --> Final output sent to browser
DEBUG - 2011-10-02 15:17:45 --> Total execution time: 0.5963
DEBUG - 2011-10-02 15:18:07 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:07 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:07 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:07 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:07 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:07 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:07 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:07 --> Total execution time: 0.0317
DEBUG - 2011-10-02 15:18:08 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:08 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:08 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:08 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:08 --> Total execution time: 0.6279
DEBUG - 2011-10-02 15:18:23 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:23 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:23 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:23 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:23 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:23 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:23 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:23 --> Total execution time: 0.0344
DEBUG - 2011-10-02 15:18:23 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:23 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:23 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:23 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:24 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:24 --> Total execution time: 0.5713
DEBUG - 2011-10-02 15:18:33 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:33 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:33 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:33 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:33 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:33 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:33 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:33 --> Total execution time: 0.0327
DEBUG - 2011-10-02 15:18:35 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:35 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:35 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:35 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:35 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:35 --> Total execution time: 0.5831
DEBUG - 2011-10-02 15:18:40 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:40 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:40 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:40 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:40 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:40 --> Total execution time: 0.0336
DEBUG - 2011-10-02 15:18:40 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:40 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:40 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:41 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:41 --> Total execution time: 0.5380
DEBUG - 2011-10-02 15:18:47 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:47 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:47 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:47 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:47 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:47 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:47 --> Total execution time: 0.0727
DEBUG - 2011-10-02 15:18:47 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:47 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:47 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:48 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:48 --> Total execution time: 0.7131
DEBUG - 2011-10-02 15:18:52 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:52 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:52 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:52 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:52 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:52 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:52 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:52 --> Total execution time: 0.0312
DEBUG - 2011-10-02 15:18:53 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:53 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:53 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:53 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:53 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:53 --> Total execution time: 0.5753
DEBUG - 2011-10-02 15:18:59 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:59 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:59 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Controller Class Initialized
ERROR - 2011-10-02 15:18:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:18:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:18:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:59 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:59 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:18:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:18:59 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:18:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:18:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:18:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:18:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:18:59 --> Final output sent to browser
DEBUG - 2011-10-02 15:18:59 --> Total execution time: 0.0373
DEBUG - 2011-10-02 15:18:59 --> Config Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:18:59 --> URI Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Router Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Output Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Input Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:18:59 --> Language Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Loader Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Controller Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Model Class Initialized
DEBUG - 2011-10-02 15:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:18:59 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:00 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:00 --> Total execution time: 0.6250
DEBUG - 2011-10-02 15:19:05 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:05 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:05 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Controller Class Initialized
ERROR - 2011-10-02 15:19:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:19:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:19:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:19:05 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:05 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:19:05 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:19:05 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:05 --> Total execution time: 0.0416
DEBUG - 2011-10-02 15:19:06 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:06 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:06 --> No URI present. Default controller set.
DEBUG - 2011-10-02 15:19:06 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:06 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Controller Class Initialized
DEBUG - 2011-10-02 15:19:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-02 15:19:06 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:19:06 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:06 --> Total execution time: 0.0742
DEBUG - 2011-10-02 15:19:06 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:06 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:06 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Controller Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:06 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:07 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:07 --> Total execution time: 0.5716
DEBUG - 2011-10-02 15:19:14 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:14 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:14 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Controller Class Initialized
ERROR - 2011-10-02 15:19:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:19:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:19:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:19:14 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:19:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:19:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:19:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:19:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:19:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:19:14 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:14 --> Total execution time: 0.0396
DEBUG - 2011-10-02 15:19:15 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:15 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:15 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Controller Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:15 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:15 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:15 --> Total execution time: 0.5793
DEBUG - 2011-10-02 15:19:18 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:18 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:18 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Controller Class Initialized
ERROR - 2011-10-02 15:19:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:19:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:19:18 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:18 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:19:18 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:19:18 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:18 --> Total execution time: 0.0354
DEBUG - 2011-10-02 15:19:19 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:19 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:19 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Controller Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:19 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:20 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:20 --> Total execution time: 0.6209
DEBUG - 2011-10-02 15:19:26 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:26 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:26 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Controller Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 15:19:26 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:19:26 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:26 --> Total execution time: 0.3082
DEBUG - 2011-10-02 15:19:44 --> Config Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:19:44 --> URI Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Router Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Output Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Input Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:19:44 --> Language Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Loader Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Controller Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Model Class Initialized
DEBUG - 2011-10-02 15:19:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:19:44 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:19:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 15:19:45 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:19:45 --> Final output sent to browser
DEBUG - 2011-10-02 15:19:45 --> Total execution time: 0.5268
DEBUG - 2011-10-02 15:27:36 --> Config Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:27:36 --> URI Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Router Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Output Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Input Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:27:36 --> Language Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Loader Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Controller Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Model Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Model Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Model Class Initialized
DEBUG - 2011-10-02 15:27:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:27:36 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:27:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 15:27:36 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:27:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:27:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:27:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:27:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:27:36 --> Final output sent to browser
DEBUG - 2011-10-02 15:27:36 --> Total execution time: 0.0482
DEBUG - 2011-10-02 15:29:27 --> Config Class Initialized
DEBUG - 2011-10-02 15:29:27 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:29:27 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:29:28 --> URI Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Router Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Output Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Input Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:29:28 --> Language Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Loader Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Controller Class Initialized
ERROR - 2011-10-02 15:29:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:29:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:29:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:29:28 --> Model Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Model Class Initialized
DEBUG - 2011-10-02 15:29:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:29:28 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:29:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:29:28 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:29:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:29:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:29:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:29:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:29:28 --> Final output sent to browser
DEBUG - 2011-10-02 15:29:28 --> Total execution time: 0.0316
DEBUG - 2011-10-02 15:35:03 --> Config Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:35:03 --> URI Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Router Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Output Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Input Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:35:03 --> Language Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Loader Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Controller Class Initialized
ERROR - 2011-10-02 15:35:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 15:35:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 15:35:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:35:03 --> Model Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Model Class Initialized
DEBUG - 2011-10-02 15:35:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:35:03 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:35:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 15:35:03 --> Helper loaded: url_helper
DEBUG - 2011-10-02 15:35:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 15:35:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 15:35:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 15:35:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 15:35:03 --> Final output sent to browser
DEBUG - 2011-10-02 15:35:03 --> Total execution time: 0.1412
DEBUG - 2011-10-02 15:35:09 --> Config Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:35:09 --> URI Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Router Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Output Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Input Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 15:35:09 --> Language Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Loader Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Controller Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Model Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Model Class Initialized
DEBUG - 2011-10-02 15:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 15:35:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 15:35:10 --> Final output sent to browser
DEBUG - 2011-10-02 15:35:10 --> Total execution time: 1.6042
DEBUG - 2011-10-02 15:35:30 --> Config Class Initialized
DEBUG - 2011-10-02 15:35:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:35:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:35:30 --> URI Class Initialized
DEBUG - 2011-10-02 15:35:30 --> Router Class Initialized
ERROR - 2011-10-02 15:35:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 15:35:30 --> Config Class Initialized
DEBUG - 2011-10-02 15:35:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 15:35:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 15:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 15:35:30 --> URI Class Initialized
DEBUG - 2011-10-02 15:35:30 --> Router Class Initialized
ERROR - 2011-10-02 15:35:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 16:43:48 --> Config Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 16:43:48 --> URI Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Router Class Initialized
ERROR - 2011-10-02 16:43:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-02 16:43:48 --> Config Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 16:43:48 --> URI Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Router Class Initialized
DEBUG - 2011-10-02 16:43:48 --> No URI present. Default controller set.
DEBUG - 2011-10-02 16:43:48 --> Output Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Input Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 16:43:48 --> Language Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Loader Class Initialized
DEBUG - 2011-10-02 16:43:48 --> Controller Class Initialized
DEBUG - 2011-10-02 16:43:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-02 16:43:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 16:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 16:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 16:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 16:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 16:43:48 --> Final output sent to browser
DEBUG - 2011-10-02 16:43:48 --> Total execution time: 0.0222
DEBUG - 2011-10-02 17:07:20 --> Config Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:07:20 --> URI Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Router Class Initialized
DEBUG - 2011-10-02 17:07:20 --> No URI present. Default controller set.
DEBUG - 2011-10-02 17:07:20 --> Output Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Input Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 17:07:20 --> Language Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Loader Class Initialized
DEBUG - 2011-10-02 17:07:20 --> Controller Class Initialized
DEBUG - 2011-10-02 17:07:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-02 17:07:20 --> Helper loaded: url_helper
DEBUG - 2011-10-02 17:07:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 17:07:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 17:07:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 17:07:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 17:07:20 --> Final output sent to browser
DEBUG - 2011-10-02 17:07:20 --> Total execution time: 0.0473
DEBUG - 2011-10-02 17:32:38 --> Config Class Initialized
DEBUG - 2011-10-02 17:32:38 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:32:38 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:32:38 --> URI Class Initialized
DEBUG - 2011-10-02 17:32:38 --> Router Class Initialized
DEBUG - 2011-10-02 17:32:38 --> Output Class Initialized
DEBUG - 2011-10-02 17:32:38 --> Input Class Initialized
DEBUG - 2011-10-02 17:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 17:32:38 --> Language Class Initialized
DEBUG - 2011-10-02 17:32:39 --> Loader Class Initialized
DEBUG - 2011-10-02 17:32:39 --> Controller Class Initialized
DEBUG - 2011-10-02 17:32:39 --> Model Class Initialized
DEBUG - 2011-10-02 17:32:39 --> Model Class Initialized
DEBUG - 2011-10-02 17:32:39 --> Model Class Initialized
DEBUG - 2011-10-02 17:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 17:32:39 --> Database Driver Class Initialized
DEBUG - 2011-10-02 17:32:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 17:32:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 17:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 17:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 17:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 17:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 17:32:40 --> Final output sent to browser
DEBUG - 2011-10-02 17:32:40 --> Total execution time: 2.2297
DEBUG - 2011-10-02 17:32:47 --> Config Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:32:47 --> URI Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Router Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Output Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Input Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 17:32:47 --> Language Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Loader Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Controller Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Model Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Model Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Model Class Initialized
DEBUG - 2011-10-02 17:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 17:32:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 17:32:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 17:32:47 --> Helper loaded: url_helper
DEBUG - 2011-10-02 17:32:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 17:32:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 17:32:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 17:32:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 17:32:47 --> Final output sent to browser
DEBUG - 2011-10-02 17:32:47 --> Total execution time: 0.1248
DEBUG - 2011-10-02 17:32:49 --> Config Class Initialized
DEBUG - 2011-10-02 17:32:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:32:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:32:49 --> URI Class Initialized
DEBUG - 2011-10-02 17:32:49 --> Router Class Initialized
ERROR - 2011-10-02 17:32:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 17:32:52 --> Config Class Initialized
DEBUG - 2011-10-02 17:32:52 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:32:52 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:32:52 --> URI Class Initialized
DEBUG - 2011-10-02 17:32:52 --> Router Class Initialized
ERROR - 2011-10-02 17:32:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 17:33:14 --> Config Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:33:14 --> URI Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Router Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Output Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Input Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 17:33:14 --> Language Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Loader Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Controller Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Model Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Model Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Model Class Initialized
DEBUG - 2011-10-02 17:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 17:33:14 --> Database Driver Class Initialized
DEBUG - 2011-10-02 17:33:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 17:33:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 17:33:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 17:33:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 17:33:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 17:33:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 17:33:14 --> Final output sent to browser
DEBUG - 2011-10-02 17:33:14 --> Total execution time: 0.3302
DEBUG - 2011-10-02 17:33:16 --> Config Class Initialized
DEBUG - 2011-10-02 17:33:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:33:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:33:16 --> URI Class Initialized
DEBUG - 2011-10-02 17:33:16 --> Router Class Initialized
ERROR - 2011-10-02 17:33:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 17:33:55 --> Config Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:33:55 --> URI Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Router Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Output Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Input Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 17:33:55 --> Language Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Loader Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Controller Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Model Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Model Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Model Class Initialized
DEBUG - 2011-10-02 17:33:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 17:33:55 --> Database Driver Class Initialized
DEBUG - 2011-10-02 17:33:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 17:33:55 --> Helper loaded: url_helper
DEBUG - 2011-10-02 17:33:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 17:33:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 17:33:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 17:33:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 17:33:55 --> Final output sent to browser
DEBUG - 2011-10-02 17:33:55 --> Total execution time: 0.1663
DEBUG - 2011-10-02 17:33:57 --> Config Class Initialized
DEBUG - 2011-10-02 17:33:57 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:33:57 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:33:57 --> URI Class Initialized
DEBUG - 2011-10-02 17:33:57 --> Router Class Initialized
ERROR - 2011-10-02 17:33:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 17:35:16 --> Config Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 17:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 17:35:16 --> URI Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Router Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Output Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Input Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 17:35:16 --> Language Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Loader Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Controller Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Model Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Model Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Model Class Initialized
DEBUG - 2011-10-02 17:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 17:35:16 --> Database Driver Class Initialized
DEBUG - 2011-10-02 17:35:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 17:35:16 --> Helper loaded: url_helper
DEBUG - 2011-10-02 17:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 17:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 17:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 17:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 17:35:16 --> Final output sent to browser
DEBUG - 2011-10-02 17:35:16 --> Total execution time: 0.0476
DEBUG - 2011-10-02 18:55:46 --> Config Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:55:46 --> URI Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Router Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Output Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Input Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:55:46 --> Language Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Loader Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Controller Class Initialized
ERROR - 2011-10-02 18:55:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:55:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:55:46 --> Model Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Model Class Initialized
DEBUG - 2011-10-02 18:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:55:46 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:55:46 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:55:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:55:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:55:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:55:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:55:46 --> Final output sent to browser
DEBUG - 2011-10-02 18:55:46 --> Total execution time: 0.2883
DEBUG - 2011-10-02 18:55:47 --> Config Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:55:47 --> URI Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Router Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Output Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Input Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:55:47 --> Language Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Loader Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Controller Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Model Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Model Class Initialized
DEBUG - 2011-10-02 18:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:55:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:55:48 --> Final output sent to browser
DEBUG - 2011-10-02 18:55:48 --> Total execution time: 0.8700
DEBUG - 2011-10-02 18:55:49 --> Config Class Initialized
DEBUG - 2011-10-02 18:55:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:55:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:55:49 --> URI Class Initialized
DEBUG - 2011-10-02 18:55:49 --> Router Class Initialized
ERROR - 2011-10-02 18:55:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 18:56:11 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:11 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:11 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Controller Class Initialized
ERROR - 2011-10-02 18:56:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:56:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:56:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:11 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:11 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:11 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:56:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:56:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:56:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:56:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:56:11 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:11 --> Total execution time: 0.0339
DEBUG - 2011-10-02 18:56:12 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:12 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:12 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Controller Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:12 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:13 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:13 --> Total execution time: 0.6386
DEBUG - 2011-10-02 18:56:24 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:24 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:24 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Controller Class Initialized
ERROR - 2011-10-02 18:56:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:24 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:24 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:24 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:56:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:56:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:56:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:56:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:56:24 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:24 --> Total execution time: 0.0329
DEBUG - 2011-10-02 18:56:25 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:25 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:25 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Controller Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:25 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Router Class Initialized
ERROR - 2011-10-02 18:56:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-02 18:56:25 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:25 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:25 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Controller Class Initialized
ERROR - 2011-10-02 18:56:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:56:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:25 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:56:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:56:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:56:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:56:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:56:25 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:25 --> Total execution time: 0.0417
DEBUG - 2011-10-02 18:56:26 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:26 --> Total execution time: 0.6997
DEBUG - 2011-10-02 18:56:40 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:40 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:40 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Controller Class Initialized
ERROR - 2011-10-02 18:56:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:56:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:40 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:40 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:40 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:56:40 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:40 --> Total execution time: 0.0394
DEBUG - 2011-10-02 18:56:41 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:41 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:41 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Controller Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:41 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:41 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:41 --> Total execution time: 0.7612
DEBUG - 2011-10-02 18:56:48 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:48 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:48 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Controller Class Initialized
ERROR - 2011-10-02 18:56:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:56:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:48 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:56:48 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:48 --> Total execution time: 0.0340
DEBUG - 2011-10-02 18:56:48 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:48 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:48 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Controller Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:49 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:49 --> Total execution time: 0.6159
DEBUG - 2011-10-02 18:56:54 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:54 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:54 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Controller Class Initialized
ERROR - 2011-10-02 18:56:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:56:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:56:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:54 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:54 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:56:54 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:56:54 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:54 --> Total execution time: 0.1403
DEBUG - 2011-10-02 18:56:55 --> Config Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:56:55 --> URI Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Router Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Output Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Input Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:56:55 --> Language Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Loader Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Controller Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Model Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:56:55 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:56:55 --> Final output sent to browser
DEBUG - 2011-10-02 18:56:55 --> Total execution time: 0.7173
DEBUG - 2011-10-02 18:57:01 --> Config Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:57:01 --> URI Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Router Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Output Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Input Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:57:01 --> Language Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Loader Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Controller Class Initialized
ERROR - 2011-10-02 18:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:57:01 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:57:01 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:57:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:57:01 --> Final output sent to browser
DEBUG - 2011-10-02 18:57:01 --> Total execution time: 0.0659
DEBUG - 2011-10-02 18:57:02 --> Config Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:57:02 --> URI Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Router Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Output Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Input Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:57:02 --> Language Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Loader Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Controller Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:57:02 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:57:02 --> Final output sent to browser
DEBUG - 2011-10-02 18:57:02 --> Total execution time: 0.7721
DEBUG - 2011-10-02 18:57:09 --> Config Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:57:09 --> URI Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Router Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Output Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Input Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:57:09 --> Language Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Loader Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Controller Class Initialized
ERROR - 2011-10-02 18:57:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 18:57:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 18:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:57:09 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:57:09 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 18:57:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 18:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 18:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 18:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 18:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 18:57:09 --> Final output sent to browser
DEBUG - 2011-10-02 18:57:09 --> Total execution time: 0.1365
DEBUG - 2011-10-02 18:57:10 --> Config Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 18:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 18:57:10 --> URI Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Router Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Output Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Input Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 18:57:10 --> Language Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Loader Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Controller Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Model Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 18:57:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 18:57:10 --> Final output sent to browser
DEBUG - 2011-10-02 18:57:10 --> Total execution time: 0.7106
DEBUG - 2011-10-02 20:25:27 --> Config Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Hooks Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Utf8 Class Initialized
DEBUG - 2011-10-02 20:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 20:25:27 --> URI Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Router Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Output Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Input Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 20:25:27 --> Language Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Loader Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Controller Class Initialized
ERROR - 2011-10-02 20:25:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 20:25:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 20:25:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 20:25:27 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 20:25:27 --> Database Driver Class Initialized
DEBUG - 2011-10-02 20:25:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 20:25:27 --> Helper loaded: url_helper
DEBUG - 2011-10-02 20:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 20:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 20:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 20:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 20:25:27 --> Final output sent to browser
DEBUG - 2011-10-02 20:25:27 --> Total execution time: 0.1574
DEBUG - 2011-10-02 20:25:31 --> Config Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 20:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 20:25:31 --> URI Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Router Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Output Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Input Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 20:25:31 --> Language Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Loader Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Controller Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 20:25:31 --> Database Driver Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Config Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 20:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 20:25:31 --> URI Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Router Class Initialized
ERROR - 2011-10-02 20:25:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 20:25:31 --> Config Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 20:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 20:25:31 --> URI Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Router Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Output Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Input Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 20:25:31 --> Language Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Loader Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Controller Class Initialized
ERROR - 2011-10-02 20:25:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 20:25:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 20:25:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 20:25:31 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 20:25:32 --> Database Driver Class Initialized
DEBUG - 2011-10-02 20:25:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 20:25:32 --> Helper loaded: url_helper
DEBUG - 2011-10-02 20:25:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 20:25:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 20:25:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 20:25:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 20:25:32 --> Final output sent to browser
DEBUG - 2011-10-02 20:25:32 --> Total execution time: 0.0352
DEBUG - 2011-10-02 20:25:32 --> Final output sent to browser
DEBUG - 2011-10-02 20:25:32 --> Total execution time: 0.8507
DEBUG - 2011-10-02 20:25:32 --> Config Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Hooks Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Utf8 Class Initialized
DEBUG - 2011-10-02 20:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 20:25:32 --> URI Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Router Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Output Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Input Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 20:25:32 --> Language Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Loader Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Controller Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Model Class Initialized
DEBUG - 2011-10-02 20:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 20:25:32 --> Database Driver Class Initialized
DEBUG - 2011-10-02 20:25:33 --> Final output sent to browser
DEBUG - 2011-10-02 20:25:33 --> Total execution time: 0.7729
DEBUG - 2011-10-02 20:25:35 --> Config Class Initialized
DEBUG - 2011-10-02 20:25:35 --> Hooks Class Initialized
DEBUG - 2011-10-02 20:25:35 --> Utf8 Class Initialized
DEBUG - 2011-10-02 20:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 20:25:35 --> URI Class Initialized
DEBUG - 2011-10-02 20:25:35 --> Router Class Initialized
ERROR - 2011-10-02 20:25:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 21:10:07 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:07 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Router Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Output Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Input Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:10:07 --> Language Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Loader Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Controller Class Initialized
ERROR - 2011-10-02 21:10:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 21:10:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 21:10:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:10:07 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:10:07 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:10:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:10:08 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:10:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:10:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:10:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:10:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:10:08 --> Final output sent to browser
DEBUG - 2011-10-02 21:10:08 --> Total execution time: 0.5703
DEBUG - 2011-10-02 21:10:08 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:08 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Router Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Output Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Input Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:10:08 --> Language Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Loader Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Controller Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:10:08 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:10:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:10:09 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:10:09 --> Final output sent to browser
DEBUG - 2011-10-02 21:10:09 --> Total execution time: 1.1766
DEBUG - 2011-10-02 21:10:10 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:10 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Router Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Output Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Input Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:10:10 --> Language Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Loader Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Controller Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:10:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:10:10 --> Final output sent to browser
DEBUG - 2011-10-02 21:10:10 --> Total execution time: 0.6391
DEBUG - 2011-10-02 21:10:14 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:14 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:14 --> Router Class Initialized
ERROR - 2011-10-02 21:10:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 21:10:29 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:29 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Router Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Output Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Input Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:10:29 --> Language Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Loader Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Controller Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:10:29 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:10:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:10:29 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:10:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:10:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:10:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:10:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:10:29 --> Final output sent to browser
DEBUG - 2011-10-02 21:10:29 --> Total execution time: 0.2435
DEBUG - 2011-10-02 21:10:51 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:51 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Router Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Output Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Input Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:10:51 --> Language Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Loader Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Controller Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:10:51 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:10:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:10:51 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:10:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:10:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:10:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:10:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:10:51 --> Final output sent to browser
DEBUG - 2011-10-02 21:10:51 --> Total execution time: 0.2052
DEBUG - 2011-10-02 21:10:56 --> Config Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:10:56 --> URI Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Router Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Output Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Input Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:10:56 --> Language Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Loader Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Controller Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Model Class Initialized
DEBUG - 2011-10-02 21:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:10:56 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:10:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:10:56 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:10:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:10:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:10:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:10:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:10:56 --> Final output sent to browser
DEBUG - 2011-10-02 21:10:56 --> Total execution time: 0.0502
DEBUG - 2011-10-02 21:11:01 --> Config Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:11:01 --> URI Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Router Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Output Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Input Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:11:01 --> Language Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Loader Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Controller Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:11:01 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:11:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:11:01 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:11:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:11:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:11:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:11:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:11:01 --> Final output sent to browser
DEBUG - 2011-10-02 21:11:01 --> Total execution time: 0.1346
DEBUG - 2011-10-02 21:11:12 --> Config Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:11:12 --> URI Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Router Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Output Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Input Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:11:12 --> Language Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Loader Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Controller Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:11:12 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:11:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:11:13 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:11:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:11:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:11:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:11:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:11:13 --> Final output sent to browser
DEBUG - 2011-10-02 21:11:13 --> Total execution time: 0.6081
DEBUG - 2011-10-02 21:11:16 --> Config Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:11:16 --> URI Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Router Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Output Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Input Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:11:16 --> Language Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Loader Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Controller Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:11:16 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:11:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:11:16 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:11:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:11:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:11:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:11:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:11:16 --> Final output sent to browser
DEBUG - 2011-10-02 21:11:16 --> Total execution time: 0.0545
DEBUG - 2011-10-02 21:11:28 --> Config Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:11:28 --> URI Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Router Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Output Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Input Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:11:28 --> Language Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Loader Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Controller Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:11:28 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:11:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:11:28 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:11:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:11:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:11:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:11:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:11:28 --> Final output sent to browser
DEBUG - 2011-10-02 21:11:28 --> Total execution time: 0.2501
DEBUG - 2011-10-02 21:11:31 --> Config Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:11:31 --> URI Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Router Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Output Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Input Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:11:31 --> Language Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Loader Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Controller Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Model Class Initialized
DEBUG - 2011-10-02 21:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:11:31 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:11:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 21:11:31 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:11:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:11:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:11:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:11:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:11:31 --> Final output sent to browser
DEBUG - 2011-10-02 21:11:31 --> Total execution time: 0.0717
DEBUG - 2011-10-02 21:13:10 --> Config Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:13:10 --> URI Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Router Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Output Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Input Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:13:10 --> Language Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Loader Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Controller Class Initialized
ERROR - 2011-10-02 21:13:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 21:13:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 21:13:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:13:10 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:13:10 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:13:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:13:10 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:13:10 --> Final output sent to browser
DEBUG - 2011-10-02 21:13:10 --> Total execution time: 0.0381
DEBUG - 2011-10-02 21:13:11 --> Config Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:13:11 --> URI Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Router Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Output Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Input Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:13:11 --> Language Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Loader Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Controller Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:13:11 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Final output sent to browser
DEBUG - 2011-10-02 21:13:12 --> Total execution time: 0.6678
DEBUG - 2011-10-02 21:13:12 --> Config Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:13:12 --> URI Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Router Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Output Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Input Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:13:12 --> Language Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Loader Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Controller Class Initialized
ERROR - 2011-10-02 21:13:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 21:13:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 21:13:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:13:12 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:13:12 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:13:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:13:12 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:13:12 --> Final output sent to browser
DEBUG - 2011-10-02 21:13:12 --> Total execution time: 0.0321
DEBUG - 2011-10-02 21:13:47 --> Config Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:13:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:13:47 --> URI Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Router Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Output Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Input Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:13:47 --> Language Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Loader Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Controller Class Initialized
ERROR - 2011-10-02 21:13:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 21:13:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 21:13:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:13:47 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:13:47 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:13:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:13:47 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:13:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:13:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:13:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:13:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:13:47 --> Final output sent to browser
DEBUG - 2011-10-02 21:13:47 --> Total execution time: 0.0837
DEBUG - 2011-10-02 21:13:49 --> Config Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:13:49 --> URI Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Router Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Output Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Input Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:13:49 --> Language Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Loader Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Controller Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Model Class Initialized
DEBUG - 2011-10-02 21:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:13:49 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:13:50 --> Final output sent to browser
DEBUG - 2011-10-02 21:13:50 --> Total execution time: 1.0122
DEBUG - 2011-10-02 21:14:06 --> Config Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Hooks Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Utf8 Class Initialized
DEBUG - 2011-10-02 21:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 21:14:06 --> URI Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Router Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Output Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Input Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 21:14:06 --> Language Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Loader Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Controller Class Initialized
ERROR - 2011-10-02 21:14:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 21:14:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 21:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:14:06 --> Model Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Model Class Initialized
DEBUG - 2011-10-02 21:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 21:14:06 --> Database Driver Class Initialized
DEBUG - 2011-10-02 21:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 21:14:06 --> Helper loaded: url_helper
DEBUG - 2011-10-02 21:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 21:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 21:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 21:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 21:14:06 --> Final output sent to browser
DEBUG - 2011-10-02 21:14:06 --> Total execution time: 0.0698
DEBUG - 2011-10-02 22:44:13 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:13 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Router Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Output Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Input Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:44:13 --> Language Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Loader Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Controller Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:44:13 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:44:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:44:14 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:44:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:44:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:44:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:44:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:44:14 --> Final output sent to browser
DEBUG - 2011-10-02 22:44:14 --> Total execution time: 0.8736
DEBUG - 2011-10-02 22:44:18 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:18 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:18 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:18 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:18 --> Router Class Initialized
ERROR - 2011-10-02 22:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:44:19 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:19 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:19 --> Router Class Initialized
ERROR - 2011-10-02 22:44:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:44:25 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:25 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Router Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Output Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Input Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:44:25 --> Language Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Loader Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Controller Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:44:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:44:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:44:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:44:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:44:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:44:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:44:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:44:25 --> Final output sent to browser
DEBUG - 2011-10-02 22:44:25 --> Total execution time: 0.3864
DEBUG - 2011-10-02 22:44:29 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:29 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:29 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:29 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:29 --> Router Class Initialized
ERROR - 2011-10-02 22:44:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:44:48 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:48 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Router Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Output Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Input Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:44:48 --> Language Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Loader Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Controller Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Model Class Initialized
DEBUG - 2011-10-02 22:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:44:48 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:44:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:44:48 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:44:48 --> Final output sent to browser
DEBUG - 2011-10-02 22:44:48 --> Total execution time: 0.3086
DEBUG - 2011-10-02 22:44:49 --> Config Class Initialized
DEBUG - 2011-10-02 22:44:49 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:44:49 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:44:49 --> URI Class Initialized
DEBUG - 2011-10-02 22:44:49 --> Router Class Initialized
ERROR - 2011-10-02 22:44:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:45:21 --> Config Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:45:21 --> URI Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Router Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Output Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Input Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:45:21 --> Language Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Loader Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Controller Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Model Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Model Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Model Class Initialized
DEBUG - 2011-10-02 22:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:45:21 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:45:21 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:45:21 --> Final output sent to browser
DEBUG - 2011-10-02 22:45:21 --> Total execution time: 0.0474
DEBUG - 2011-10-02 22:48:56 --> Config Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:48:56 --> URI Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Router Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Output Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Input Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:48:56 --> Language Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Loader Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Controller Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Model Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Model Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Model Class Initialized
DEBUG - 2011-10-02 22:48:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:48:56 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:48:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:48:56 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:48:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:48:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:48:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:48:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:48:56 --> Final output sent to browser
DEBUG - 2011-10-02 22:48:56 --> Total execution time: 0.2357
DEBUG - 2011-10-02 22:48:58 --> Config Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:48:58 --> URI Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Router Class Initialized
ERROR - 2011-10-02 22:48:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:48:58 --> Config Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:48:58 --> URI Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Router Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Output Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Input Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:48:58 --> Language Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Loader Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Controller Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Model Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Model Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Model Class Initialized
DEBUG - 2011-10-02 22:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:48:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:48:58 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:48:58 --> Final output sent to browser
DEBUG - 2011-10-02 22:48:58 --> Total execution time: 0.0486
DEBUG - 2011-10-02 22:49:05 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:05 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Router Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Output Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Input Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:49:05 --> Language Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Loader Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Controller Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:49:05 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:49:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:49:06 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:49:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:49:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:49:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:49:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:49:06 --> Final output sent to browser
DEBUG - 2011-10-02 22:49:06 --> Total execution time: 0.7987
DEBUG - 2011-10-02 22:49:07 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:07 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:07 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:07 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:07 --> Router Class Initialized
ERROR - 2011-10-02 22:49:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:49:17 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:17 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:17 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:17 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:17 --> Router Class Initialized
ERROR - 2011-10-02 22:49:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:49:19 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:19 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:19 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:19 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:19 --> Router Class Initialized
ERROR - 2011-10-02 22:49:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:49:25 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:25 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Router Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Output Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Input Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:49:25 --> Language Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Loader Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Controller Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:49:25 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:49:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:49:25 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:49:25 --> Final output sent to browser
DEBUG - 2011-10-02 22:49:25 --> Total execution time: 0.0488
DEBUG - 2011-10-02 22:49:26 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:26 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Router Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Output Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Input Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:49:26 --> Language Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Loader Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Controller Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:49:26 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:26 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:26 --> Router Class Initialized
ERROR - 2011-10-02 22:49:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 22:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:49:26 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:49:26 --> Final output sent to browser
DEBUG - 2011-10-02 22:49:26 --> Total execution time: 0.0649
DEBUG - 2011-10-02 22:49:30 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:30 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Router Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Output Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Input Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 22:49:30 --> Language Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Loader Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Controller Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Model Class Initialized
DEBUG - 2011-10-02 22:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 22:49:30 --> Database Driver Class Initialized
DEBUG - 2011-10-02 22:49:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-02 22:49:31 --> Helper loaded: url_helper
DEBUG - 2011-10-02 22:49:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 22:49:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 22:49:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 22:49:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 22:49:31 --> Final output sent to browser
DEBUG - 2011-10-02 22:49:31 --> Total execution time: 0.6345
DEBUG - 2011-10-02 22:49:32 --> Config Class Initialized
DEBUG - 2011-10-02 22:49:32 --> Hooks Class Initialized
DEBUG - 2011-10-02 22:49:32 --> Utf8 Class Initialized
DEBUG - 2011-10-02 22:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 22:49:32 --> URI Class Initialized
DEBUG - 2011-10-02 22:49:32 --> Router Class Initialized
ERROR - 2011-10-02 22:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 23:23:02 --> Config Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:23:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:23:02 --> URI Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Router Class Initialized
ERROR - 2011-10-02 23:23:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-02 23:23:02 --> Config Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:23:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:23:02 --> URI Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Router Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Output Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Input Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 23:23:02 --> Language Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Loader Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Controller Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Model Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Model Class Initialized
DEBUG - 2011-10-02 23:23:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 23:23:02 --> Database Driver Class Initialized
DEBUG - 2011-10-02 23:23:03 --> Final output sent to browser
DEBUG - 2011-10-02 23:23:03 --> Total execution time: 0.9379
DEBUG - 2011-10-02 23:23:04 --> Config Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:23:04 --> URI Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Router Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Output Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Input Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 23:23:04 --> Language Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Loader Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Controller Class Initialized
ERROR - 2011-10-02 23:23:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 23:23:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 23:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 23:23:04 --> Model Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Model Class Initialized
DEBUG - 2011-10-02 23:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 23:23:04 --> Database Driver Class Initialized
DEBUG - 2011-10-02 23:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 23:23:04 --> Helper loaded: url_helper
DEBUG - 2011-10-02 23:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 23:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 23:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 23:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 23:23:04 --> Final output sent to browser
DEBUG - 2011-10-02 23:23:04 --> Total execution time: 0.2219
DEBUG - 2011-10-02 23:58:02 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:02 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Router Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Output Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Input Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 23:58:02 --> Language Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Loader Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Controller Class Initialized
ERROR - 2011-10-02 23:58:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 23:58:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 23:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 23:58:02 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 23:58:02 --> Database Driver Class Initialized
DEBUG - 2011-10-02 23:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 23:58:02 --> Helper loaded: url_helper
DEBUG - 2011-10-02 23:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 23:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 23:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 23:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 23:58:02 --> Final output sent to browser
DEBUG - 2011-10-02 23:58:02 --> Total execution time: 0.0524
DEBUG - 2011-10-02 23:58:03 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:03 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Router Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Output Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Input Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 23:58:03 --> Language Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Loader Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Controller Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 23:58:03 --> Database Driver Class Initialized
DEBUG - 2011-10-02 23:58:04 --> Final output sent to browser
DEBUG - 2011-10-02 23:58:04 --> Total execution time: 0.8101
DEBUG - 2011-10-02 23:58:12 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:12 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:12 --> Router Class Initialized
ERROR - 2011-10-02 23:58:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 23:58:12 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:12 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:12 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:12 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:12 --> Router Class Initialized
ERROR - 2011-10-02 23:58:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 23:58:14 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:14 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:14 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:14 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:14 --> Router Class Initialized
ERROR - 2011-10-02 23:58:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-02 23:58:56 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:56 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Router Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Output Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Input Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 23:58:56 --> Language Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Loader Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Controller Class Initialized
ERROR - 2011-10-02 23:58:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-02 23:58:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-02 23:58:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 23:58:56 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 23:58:56 --> Database Driver Class Initialized
DEBUG - 2011-10-02 23:58:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-02 23:58:56 --> Helper loaded: url_helper
DEBUG - 2011-10-02 23:58:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-02 23:58:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-02 23:58:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-02 23:58:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-02 23:58:56 --> Final output sent to browser
DEBUG - 2011-10-02 23:58:56 --> Total execution time: 0.0320
DEBUG - 2011-10-02 23:58:58 --> Config Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Hooks Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Utf8 Class Initialized
DEBUG - 2011-10-02 23:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-02 23:58:58 --> URI Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Router Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Output Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Input Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-02 23:58:58 --> Language Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Loader Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Controller Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Model Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-02 23:58:58 --> Database Driver Class Initialized
DEBUG - 2011-10-02 23:58:58 --> Final output sent to browser
DEBUG - 2011-10-02 23:58:58 --> Total execution time: 0.6593

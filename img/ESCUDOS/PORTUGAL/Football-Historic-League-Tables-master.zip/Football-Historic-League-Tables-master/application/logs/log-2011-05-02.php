<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-02 00:01:03 --> Config Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:01:03 --> URI Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Router Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Output Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Input Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:01:03 --> Language Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Loader Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Controller Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Model Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Model Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Model Class Initialized
DEBUG - 2011-05-02 00:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 00:01:03 --> Database Driver Class Initialized
DEBUG - 2011-05-02 00:01:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 00:01:04 --> Helper loaded: url_helper
DEBUG - 2011-05-02 00:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 00:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 00:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 00:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 00:01:04 --> Final output sent to browser
DEBUG - 2011-05-02 00:01:04 --> Total execution time: 0.5158
DEBUG - 2011-05-02 00:12:37 --> Config Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:12:37 --> URI Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Router Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Output Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Input Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:12:37 --> Language Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Loader Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Controller Class Initialized
ERROR - 2011-05-02 00:12:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 00:12:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 00:12:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 00:12:37 --> Model Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Model Class Initialized
DEBUG - 2011-05-02 00:12:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 00:12:37 --> Database Driver Class Initialized
DEBUG - 2011-05-02 00:12:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 00:12:37 --> Helper loaded: url_helper
DEBUG - 2011-05-02 00:12:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 00:12:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 00:12:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 00:12:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 00:12:37 --> Final output sent to browser
DEBUG - 2011-05-02 00:12:37 --> Total execution time: 0.2989
DEBUG - 2011-05-02 00:13:50 --> Config Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:13:50 --> URI Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Router Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Output Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Input Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:13:50 --> Language Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Loader Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Controller Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Model Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Model Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 00:13:50 --> Database Driver Class Initialized
DEBUG - 2011-05-02 00:13:50 --> Final output sent to browser
DEBUG - 2011-05-02 00:13:50 --> Total execution time: 0.7280
DEBUG - 2011-05-02 00:14:14 --> Config Class Initialized
DEBUG - 2011-05-02 00:14:14 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:14:14 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:14:14 --> URI Class Initialized
DEBUG - 2011-05-02 00:14:14 --> Router Class Initialized
ERROR - 2011-05-02 00:14:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 00:55:27 --> Config Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:55:27 --> URI Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Router Class Initialized
DEBUG - 2011-05-02 00:55:27 --> No URI present. Default controller set.
DEBUG - 2011-05-02 00:55:27 --> Output Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Input Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:55:27 --> Language Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Loader Class Initialized
DEBUG - 2011-05-02 00:55:27 --> Controller Class Initialized
DEBUG - 2011-05-02 00:55:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 00:55:27 --> Helper loaded: url_helper
DEBUG - 2011-05-02 00:55:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 00:55:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 00:55:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 00:55:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 00:56:47 --> Config Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:56:47 --> URI Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Router Class Initialized
DEBUG - 2011-05-02 00:56:47 --> No URI present. Default controller set.
DEBUG - 2011-05-02 00:56:47 --> Output Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Input Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:56:47 --> Language Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Loader Class Initialized
DEBUG - 2011-05-02 00:56:47 --> Controller Class Initialized
DEBUG - 2011-05-02 00:56:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 00:56:47 --> Helper loaded: url_helper
DEBUG - 2011-05-02 00:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 00:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 00:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 00:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 00:57:22 --> Config Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:57:22 --> URI Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Router Class Initialized
DEBUG - 2011-05-02 00:57:22 --> No URI present. Default controller set.
DEBUG - 2011-05-02 00:57:22 --> Output Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Input Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:57:22 --> Language Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Loader Class Initialized
DEBUG - 2011-05-02 00:57:22 --> Controller Class Initialized
DEBUG - 2011-05-02 00:57:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 00:57:22 --> Helper loaded: url_helper
DEBUG - 2011-05-02 00:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 00:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 00:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 00:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 00:58:16 --> Config Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Hooks Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Utf8 Class Initialized
DEBUG - 2011-05-02 00:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 00:58:16 --> URI Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Router Class Initialized
DEBUG - 2011-05-02 00:58:16 --> No URI present. Default controller set.
DEBUG - 2011-05-02 00:58:16 --> Output Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Input Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 00:58:16 --> Language Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Loader Class Initialized
DEBUG - 2011-05-02 00:58:16 --> Controller Class Initialized
DEBUG - 2011-05-02 00:58:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 00:58:16 --> Helper loaded: url_helper
DEBUG - 2011-05-02 00:58:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 00:58:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 00:58:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 00:58:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 01:52:52 --> Config Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Hooks Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Utf8 Class Initialized
DEBUG - 2011-05-02 01:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 01:52:52 --> URI Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Router Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Output Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Input Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 01:52:52 --> Language Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Loader Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Controller Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Model Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Model Class Initialized
DEBUG - 2011-05-02 01:52:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 01:52:52 --> Database Driver Class Initialized
DEBUG - 2011-05-02 01:52:54 --> Final output sent to browser
DEBUG - 2011-05-02 01:52:54 --> Total execution time: 2.0346
DEBUG - 2011-05-02 02:22:45 --> Config Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Hooks Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Utf8 Class Initialized
DEBUG - 2011-05-02 02:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 02:22:45 --> URI Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Router Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Output Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Input Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 02:22:45 --> Language Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Loader Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Controller Class Initialized
ERROR - 2011-05-02 02:22:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 02:22:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 02:22:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 02:22:45 --> Model Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Model Class Initialized
DEBUG - 2011-05-02 02:22:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 02:22:45 --> Database Driver Class Initialized
DEBUG - 2011-05-02 02:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 02:22:47 --> Helper loaded: url_helper
DEBUG - 2011-05-02 02:22:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 02:22:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 02:22:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 02:22:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 02:22:47 --> Final output sent to browser
DEBUG - 2011-05-02 02:22:47 --> Total execution time: 1.3827
DEBUG - 2011-05-02 02:22:48 --> Config Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Hooks Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Utf8 Class Initialized
DEBUG - 2011-05-02 02:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 02:22:48 --> URI Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Router Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Output Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Input Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 02:22:48 --> Language Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Loader Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Controller Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Model Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Model Class Initialized
DEBUG - 2011-05-02 02:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 02:22:48 --> Database Driver Class Initialized
DEBUG - 2011-05-02 02:22:49 --> Final output sent to browser
DEBUG - 2011-05-02 02:22:49 --> Total execution time: 1.2973
DEBUG - 2011-05-02 02:22:50 --> Config Class Initialized
DEBUG - 2011-05-02 02:22:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 02:22:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 02:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 02:22:50 --> URI Class Initialized
DEBUG - 2011-05-02 02:22:50 --> Router Class Initialized
ERROR - 2011-05-02 02:22:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 02:22:50 --> Config Class Initialized
DEBUG - 2011-05-02 02:22:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 02:22:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 02:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 02:22:50 --> URI Class Initialized
DEBUG - 2011-05-02 02:22:50 --> Router Class Initialized
ERROR - 2011-05-02 02:22:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 02:22:51 --> Config Class Initialized
DEBUG - 2011-05-02 02:22:51 --> Hooks Class Initialized
DEBUG - 2011-05-02 02:22:51 --> Utf8 Class Initialized
DEBUG - 2011-05-02 02:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 02:22:51 --> URI Class Initialized
DEBUG - 2011-05-02 02:22:51 --> Router Class Initialized
ERROR - 2011-05-02 02:22:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:03:11 --> Config Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:03:11 --> URI Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Router Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Output Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Input Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:03:11 --> Language Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Loader Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Controller Class Initialized
ERROR - 2011-05-02 03:03:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 03:03:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 03:03:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:03:11 --> Model Class Initialized
DEBUG - 2011-05-02 03:03:11 --> Model Class Initialized
DEBUG - 2011-05-02 03:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:03:12 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:03:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:03:12 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:03:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:03:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:03:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:03:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:03:12 --> Final output sent to browser
DEBUG - 2011-05-02 03:03:12 --> Total execution time: 0.7760
DEBUG - 2011-05-02 03:03:13 --> Config Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:03:13 --> URI Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Router Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Output Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Input Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:03:13 --> Language Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Loader Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Controller Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Model Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Model Class Initialized
DEBUG - 2011-05-02 03:03:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:03:13 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:03:19 --> Final output sent to browser
DEBUG - 2011-05-02 03:03:19 --> Total execution time: 5.7294
DEBUG - 2011-05-02 03:03:21 --> Config Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:03:21 --> URI Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Router Class Initialized
ERROR - 2011-05-02 03:03:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:03:21 --> Config Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:03:21 --> URI Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Router Class Initialized
ERROR - 2011-05-02 03:03:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:03:21 --> Config Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:03:21 --> URI Class Initialized
DEBUG - 2011-05-02 03:03:21 --> Router Class Initialized
ERROR - 2011-05-02 03:03:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:09:27 --> Config Class Initialized
DEBUG - 2011-05-02 03:09:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:09:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:09:27 --> URI Class Initialized
DEBUG - 2011-05-02 03:09:27 --> Router Class Initialized
ERROR - 2011-05-02 03:09:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:09:49 --> Config Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:09:49 --> URI Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Router Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Output Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Input Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:09:49 --> Language Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Loader Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Controller Class Initialized
ERROR - 2011-05-02 03:09:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 03:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 03:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:09:49 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:09:49 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:09:49 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:09:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:09:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:09:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:09:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:09:49 --> Final output sent to browser
DEBUG - 2011-05-02 03:09:49 --> Total execution time: 0.1631
DEBUG - 2011-05-02 03:09:50 --> Config Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:09:50 --> URI Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Router Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Output Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Input Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:09:50 --> Language Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Loader Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Controller Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:09:50 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:09:51 --> Final output sent to browser
DEBUG - 2011-05-02 03:09:51 --> Total execution time: 0.7814
DEBUG - 2011-05-02 03:09:56 --> Config Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:09:56 --> URI Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Router Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Output Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Input Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:09:56 --> Language Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Loader Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Controller Class Initialized
ERROR - 2011-05-02 03:09:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 03:09:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 03:09:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:09:56 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:09:56 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:09:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:09:56 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:09:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:09:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:09:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:09:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:09:56 --> Final output sent to browser
DEBUG - 2011-05-02 03:09:56 --> Total execution time: 0.0284
DEBUG - 2011-05-02 03:09:58 --> Config Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:09:58 --> URI Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Router Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Output Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Input Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:09:58 --> Language Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Loader Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Controller Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Model Class Initialized
DEBUG - 2011-05-02 03:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:09:58 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:09:59 --> Final output sent to browser
DEBUG - 2011-05-02 03:09:59 --> Total execution time: 0.8328
DEBUG - 2011-05-02 03:12:31 --> Config Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:12:31 --> URI Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Router Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Output Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Input Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:12:31 --> Language Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Loader Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Controller Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Model Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Model Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Model Class Initialized
DEBUG - 2011-05-02 03:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:12:31 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:12:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:12:32 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:12:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:12:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:12:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:12:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:12:32 --> Final output sent to browser
DEBUG - 2011-05-02 03:12:32 --> Total execution time: 1.0632
DEBUG - 2011-05-02 03:28:40 --> Config Class Initialized
DEBUG - 2011-05-02 03:28:40 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:28:40 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:28:40 --> URI Class Initialized
DEBUG - 2011-05-02 03:28:40 --> Router Class Initialized
DEBUG - 2011-05-02 03:28:40 --> Output Class Initialized
DEBUG - 2011-05-02 03:28:40 --> Input Class Initialized
DEBUG - 2011-05-02 03:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:28:41 --> Language Class Initialized
DEBUG - 2011-05-02 03:28:41 --> Loader Class Initialized
DEBUG - 2011-05-02 03:28:41 --> Controller Class Initialized
ERROR - 2011-05-02 03:28:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 03:28:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 03:28:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:28:41 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:41 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:28:41 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:28:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:28:41 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:28:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:28:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:28:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:28:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:28:41 --> Final output sent to browser
DEBUG - 2011-05-02 03:28:41 --> Total execution time: 0.2904
DEBUG - 2011-05-02 03:28:42 --> Config Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:28:42 --> URI Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Router Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Output Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Input Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:28:42 --> Language Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Loader Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Controller Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:28:42 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:28:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:28:43 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:28:43 --> Final output sent to browser
DEBUG - 2011-05-02 03:28:43 --> Total execution time: 0.9998
DEBUG - 2011-05-02 03:28:47 --> Config Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:28:47 --> URI Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Router Class Initialized
ERROR - 2011-05-02 03:28:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:28:47 --> Config Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:28:47 --> URI Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Router Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Output Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Input Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:28:47 --> Language Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Loader Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Controller Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Model Class Initialized
DEBUG - 2011-05-02 03:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:28:47 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:28:49 --> Final output sent to browser
DEBUG - 2011-05-02 03:28:49 --> Total execution time: 1.2365
DEBUG - 2011-05-02 03:28:49 --> Config Class Initialized
DEBUG - 2011-05-02 03:28:49 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:28:49 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:28:49 --> URI Class Initialized
DEBUG - 2011-05-02 03:28:49 --> Router Class Initialized
ERROR - 2011-05-02 03:28:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:28:50 --> Config Class Initialized
DEBUG - 2011-05-02 03:28:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:28:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:28:50 --> URI Class Initialized
DEBUG - 2011-05-02 03:28:50 --> Router Class Initialized
ERROR - 2011-05-02 03:28:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:29:01 --> Config Class Initialized
DEBUG - 2011-05-02 03:29:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:29:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:29:01 --> URI Class Initialized
DEBUG - 2011-05-02 03:29:01 --> Router Class Initialized
ERROR - 2011-05-02 03:29:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:29:15 --> Config Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:29:15 --> URI Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Router Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Output Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Input Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:29:15 --> Language Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Loader Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Controller Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Model Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Model Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Model Class Initialized
DEBUG - 2011-05-02 03:29:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:29:15 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:29:16 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:29:16 --> Final output sent to browser
DEBUG - 2011-05-02 03:29:16 --> Total execution time: 0.5563
DEBUG - 2011-05-02 03:29:25 --> Config Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:29:25 --> URI Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Router Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Output Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Input Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:29:25 --> Language Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Loader Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Controller Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Model Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Model Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Model Class Initialized
DEBUG - 2011-05-02 03:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:29:25 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:29:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:29:25 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:29:25 --> Final output sent to browser
DEBUG - 2011-05-02 03:29:25 --> Total execution time: 0.0529
DEBUG - 2011-05-02 03:33:31 --> Config Class Initialized
DEBUG - 2011-05-02 03:33:31 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:33:31 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:33:31 --> URI Class Initialized
DEBUG - 2011-05-02 03:33:31 --> Router Class Initialized
ERROR - 2011-05-02 03:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:56:02 --> Config Class Initialized
DEBUG - 2011-05-02 03:56:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:56:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:56:02 --> URI Class Initialized
DEBUG - 2011-05-02 03:56:02 --> Router Class Initialized
DEBUG - 2011-05-02 03:56:02 --> Output Class Initialized
DEBUG - 2011-05-02 03:56:02 --> Input Class Initialized
DEBUG - 2011-05-02 03:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:56:02 --> Language Class Initialized
DEBUG - 2011-05-02 03:56:03 --> Loader Class Initialized
DEBUG - 2011-05-02 03:56:03 --> Controller Class Initialized
ERROR - 2011-05-02 03:56:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 03:56:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 03:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:56:03 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:03 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:56:04 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:56:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 03:56:04 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:56:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:56:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:56:05 --> Final output sent to browser
DEBUG - 2011-05-02 03:56:05 --> Total execution time: 3.7619
DEBUG - 2011-05-02 03:56:05 --> Config Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:56:05 --> URI Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Router Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Output Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Input Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:56:05 --> Language Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Loader Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Controller Class Initialized
DEBUG - 2011-05-02 03:56:05 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:06 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:56:06 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:56:06 --> Final output sent to browser
DEBUG - 2011-05-02 03:56:06 --> Total execution time: 0.8440
DEBUG - 2011-05-02 03:56:54 --> Config Class Initialized
DEBUG - 2011-05-02 03:56:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:56:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:56:54 --> URI Class Initialized
DEBUG - 2011-05-02 03:56:54 --> Router Class Initialized
ERROR - 2011-05-02 03:56:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:56:54 --> Config Class Initialized
DEBUG - 2011-05-02 03:56:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:56:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:56:54 --> URI Class Initialized
DEBUG - 2011-05-02 03:56:54 --> Router Class Initialized
ERROR - 2011-05-02 03:56:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:56:55 --> Config Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:56:55 --> URI Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Router Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Output Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Input Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:56:55 --> Language Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Loader Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Controller Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:56:55 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Config Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:56:59 --> URI Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Router Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Output Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Input Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:56:59 --> Language Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Loader Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Controller Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Model Class Initialized
DEBUG - 2011-05-02 03:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:56:59 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:56:59 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:56:59 --> Final output sent to browser
DEBUG - 2011-05-02 03:56:59 --> Total execution time: 4.2616
DEBUG - 2011-05-02 03:57:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:57:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:57:00 --> Final output sent to browser
DEBUG - 2011-05-02 03:57:00 --> Total execution time: 0.6443
DEBUG - 2011-05-02 03:57:04 --> Config Class Initialized
DEBUG - 2011-05-02 03:57:04 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:57:04 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:57:04 --> URI Class Initialized
DEBUG - 2011-05-02 03:57:04 --> Router Class Initialized
ERROR - 2011-05-02 03:57:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 03:57:12 --> Config Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:57:12 --> URI Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Router Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Output Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Input Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:57:12 --> Language Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Loader Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Controller Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Model Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Model Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Model Class Initialized
DEBUG - 2011-05-02 03:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:57:12 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:57:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:57:21 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:57:21 --> Final output sent to browser
DEBUG - 2011-05-02 03:57:21 --> Total execution time: 8.9029
DEBUG - 2011-05-02 03:57:23 --> Config Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:57:23 --> URI Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Router Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Output Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Input Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:57:23 --> Language Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Loader Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Controller Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Model Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Model Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Model Class Initialized
DEBUG - 2011-05-02 03:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:57:23 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:57:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:57:23 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:57:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:57:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:57:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:57:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:57:23 --> Final output sent to browser
DEBUG - 2011-05-02 03:57:23 --> Total execution time: 0.2100
DEBUG - 2011-05-02 03:58:01 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:01 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:01 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:01 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:04 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:04 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:04 --> Total execution time: 2.6908
DEBUG - 2011-05-02 03:58:08 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:08 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:08 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:08 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:08 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:08 --> Total execution time: 0.0455
DEBUG - 2011-05-02 03:58:16 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:16 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:16 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:16 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:20 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:20 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:20 --> Total execution time: 4.7929
DEBUG - 2011-05-02 03:58:22 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:22 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:22 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:22 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:22 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:22 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:22 --> Total execution time: 0.0964
DEBUG - 2011-05-02 03:58:32 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:32 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:32 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:32 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:33 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:33 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:33 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:33 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:33 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:33 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:33 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:33 --> Total execution time: 0.2339
DEBUG - 2011-05-02 03:58:34 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:34 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:34 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:34 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:34 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:34 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:34 --> Total execution time: 0.1430
DEBUG - 2011-05-02 03:58:48 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:48 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:48 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:48 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:48 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:48 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:48 --> Total execution time: 0.2100
DEBUG - 2011-05-02 03:58:49 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:49 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:49 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:49 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:49 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:49 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:49 --> Total execution time: 0.0931
DEBUG - 2011-05-02 03:58:56 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:56 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:56 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:56 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:57 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:57 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:57 --> Total execution time: 1.2905
DEBUG - 2011-05-02 03:58:58 --> Config Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:58:58 --> URI Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Router Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Output Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Input Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:58:58 --> Language Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Loader Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Controller Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Model Class Initialized
DEBUG - 2011-05-02 03:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:58:58 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:58:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:58:58 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:58:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:58:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:58:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:58:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:58:58 --> Final output sent to browser
DEBUG - 2011-05-02 03:58:58 --> Total execution time: 0.0570
DEBUG - 2011-05-02 03:59:03 --> Config Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:59:03 --> URI Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Router Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Output Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Input Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:59:03 --> Language Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Loader Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Controller Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Model Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Model Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Model Class Initialized
DEBUG - 2011-05-02 03:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:59:03 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:59:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:59:03 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:59:03 --> Final output sent to browser
DEBUG - 2011-05-02 03:59:03 --> Total execution time: 0.3431
DEBUG - 2011-05-02 03:59:07 --> Config Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Hooks Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Utf8 Class Initialized
DEBUG - 2011-05-02 03:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 03:59:07 --> URI Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Router Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Output Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Input Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 03:59:07 --> Language Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Loader Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Controller Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Model Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Model Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Model Class Initialized
DEBUG - 2011-05-02 03:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 03:59:07 --> Database Driver Class Initialized
DEBUG - 2011-05-02 03:59:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 03:59:07 --> Helper loaded: url_helper
DEBUG - 2011-05-02 03:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 03:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 03:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 03:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 03:59:07 --> Final output sent to browser
DEBUG - 2011-05-02 03:59:07 --> Total execution time: 0.1494
DEBUG - 2011-05-02 04:37:21 --> Config Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:37:21 --> URI Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Router Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Output Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Input Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:37:21 --> Language Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Loader Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Controller Class Initialized
ERROR - 2011-05-02 04:37:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 04:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 04:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:37:21 --> Model Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Model Class Initialized
DEBUG - 2011-05-02 04:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:37:21 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:37:21 --> Helper loaded: url_helper
DEBUG - 2011-05-02 04:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 04:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 04:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 04:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 04:37:21 --> Final output sent to browser
DEBUG - 2011-05-02 04:37:21 --> Total execution time: 0.4985
DEBUG - 2011-05-02 04:37:22 --> Config Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:37:22 --> URI Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Router Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Output Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Input Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:37:22 --> Language Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Loader Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Controller Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Model Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Model Class Initialized
DEBUG - 2011-05-02 04:37:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:37:22 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:37:24 --> Final output sent to browser
DEBUG - 2011-05-02 04:37:24 --> Total execution time: 2.0857
DEBUG - 2011-05-02 04:37:27 --> Config Class Initialized
DEBUG - 2011-05-02 04:37:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:37:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:37:27 --> URI Class Initialized
DEBUG - 2011-05-02 04:37:27 --> Router Class Initialized
ERROR - 2011-05-02 04:37:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 04:37:27 --> Config Class Initialized
DEBUG - 2011-05-02 04:37:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:37:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:37:27 --> URI Class Initialized
DEBUG - 2011-05-02 04:37:27 --> Router Class Initialized
ERROR - 2011-05-02 04:37:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 04:39:46 --> Config Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:39:46 --> URI Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Router Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Output Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Input Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:39:46 --> Language Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Loader Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Controller Class Initialized
ERROR - 2011-05-02 04:39:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 04:39:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 04:39:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:39:46 --> Model Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Model Class Initialized
DEBUG - 2011-05-02 04:39:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:39:46 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:39:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:39:46 --> Helper loaded: url_helper
DEBUG - 2011-05-02 04:39:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 04:39:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 04:39:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 04:39:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 04:39:46 --> Final output sent to browser
DEBUG - 2011-05-02 04:39:46 --> Total execution time: 0.0279
DEBUG - 2011-05-02 04:39:50 --> Config Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:39:50 --> URI Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Router Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Output Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Input Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:39:50 --> Language Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Loader Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Controller Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Model Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Model Class Initialized
DEBUG - 2011-05-02 04:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:39:50 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:39:52 --> Final output sent to browser
DEBUG - 2011-05-02 04:39:52 --> Total execution time: 1.7158
DEBUG - 2011-05-02 04:39:57 --> Config Class Initialized
DEBUG - 2011-05-02 04:39:57 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:39:57 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:39:57 --> URI Class Initialized
DEBUG - 2011-05-02 04:39:57 --> Router Class Initialized
ERROR - 2011-05-02 04:39:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 04:40:18 --> Config Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:40:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:40:18 --> URI Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Router Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Output Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Input Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:40:18 --> Language Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Loader Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Controller Class Initialized
ERROR - 2011-05-02 04:40:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 04:40:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 04:40:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:40:18 --> Model Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Model Class Initialized
DEBUG - 2011-05-02 04:40:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:40:18 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:40:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:40:18 --> Helper loaded: url_helper
DEBUG - 2011-05-02 04:40:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 04:40:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 04:40:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 04:40:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 04:40:18 --> Final output sent to browser
DEBUG - 2011-05-02 04:40:18 --> Total execution time: 0.0429
DEBUG - 2011-05-02 04:40:19 --> Config Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:40:19 --> URI Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Router Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Output Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Input Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:40:19 --> Language Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Loader Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Controller Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Model Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Model Class Initialized
DEBUG - 2011-05-02 04:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:40:19 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:40:22 --> Final output sent to browser
DEBUG - 2011-05-02 04:40:22 --> Total execution time: 2.3715
DEBUG - 2011-05-02 04:40:24 --> Config Class Initialized
DEBUG - 2011-05-02 04:40:24 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:40:24 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:40:24 --> URI Class Initialized
DEBUG - 2011-05-02 04:40:24 --> Router Class Initialized
ERROR - 2011-05-02 04:40:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 04:56:35 --> Config Class Initialized
DEBUG - 2011-05-02 04:56:35 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:56:35 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:56:35 --> URI Class Initialized
DEBUG - 2011-05-02 04:56:35 --> Router Class Initialized
DEBUG - 2011-05-02 04:56:35 --> Output Class Initialized
DEBUG - 2011-05-02 04:56:35 --> Input Class Initialized
DEBUG - 2011-05-02 04:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:56:36 --> Language Class Initialized
DEBUG - 2011-05-02 04:56:36 --> Loader Class Initialized
DEBUG - 2011-05-02 04:56:36 --> Controller Class Initialized
ERROR - 2011-05-02 04:56:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 04:56:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 04:56:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:56:36 --> Model Class Initialized
DEBUG - 2011-05-02 04:56:36 --> Model Class Initialized
DEBUG - 2011-05-02 04:56:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 04:56:38 --> Database Driver Class Initialized
DEBUG - 2011-05-02 04:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 04:56:39 --> Helper loaded: url_helper
DEBUG - 2011-05-02 04:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 04:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 04:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 04:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 04:56:39 --> Final output sent to browser
DEBUG - 2011-05-02 04:56:39 --> Total execution time: 3.7087
DEBUG - 2011-05-02 04:57:30 --> Config Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:57:30 --> URI Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Router Class Initialized
DEBUG - 2011-05-02 04:57:30 --> No URI present. Default controller set.
DEBUG - 2011-05-02 04:57:30 --> Output Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Input Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 04:57:30 --> Language Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Loader Class Initialized
DEBUG - 2011-05-02 04:57:30 --> Controller Class Initialized
DEBUG - 2011-05-02 04:57:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 04:57:31 --> Helper loaded: url_helper
DEBUG - 2011-05-02 04:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 04:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 04:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 04:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 04:57:31 --> Final output sent to browser
DEBUG - 2011-05-02 04:57:31 --> Total execution time: 0.3412
DEBUG - 2011-05-02 04:57:45 --> Config Class Initialized
DEBUG - 2011-05-02 04:57:45 --> Hooks Class Initialized
DEBUG - 2011-05-02 04:57:45 --> Utf8 Class Initialized
DEBUG - 2011-05-02 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 04:57:45 --> URI Class Initialized
DEBUG - 2011-05-02 04:57:45 --> Router Class Initialized
ERROR - 2011-05-02 04:57:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 05:02:15 --> Config Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:02:15 --> URI Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Router Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Output Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Input Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:02:15 --> Language Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Loader Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Controller Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Model Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Model Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Model Class Initialized
DEBUG - 2011-05-02 05:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:02:15 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:02:16 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:02:16 --> Final output sent to browser
DEBUG - 2011-05-02 05:02:16 --> Total execution time: 1.2255
DEBUG - 2011-05-02 05:02:19 --> Config Class Initialized
DEBUG - 2011-05-02 05:02:19 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:02:19 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:02:19 --> URI Class Initialized
DEBUG - 2011-05-02 05:02:19 --> Router Class Initialized
ERROR - 2011-05-02 05:02:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 05:12:23 --> Config Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:12:23 --> URI Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Router Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Output Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Input Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:12:23 --> Language Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Loader Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Controller Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Model Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Model Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Model Class Initialized
DEBUG - 2011-05-02 05:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:12:23 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:12:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:12:23 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:12:23 --> Final output sent to browser
DEBUG - 2011-05-02 05:12:23 --> Total execution time: 0.2270
DEBUG - 2011-05-02 05:12:24 --> Config Class Initialized
DEBUG - 2011-05-02 05:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:12:24 --> URI Class Initialized
DEBUG - 2011-05-02 05:12:24 --> Router Class Initialized
ERROR - 2011-05-02 05:12:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 05:12:43 --> Config Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:12:43 --> URI Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Router Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Output Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Input Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:12:43 --> Language Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Loader Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Controller Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Model Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Model Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Model Class Initialized
DEBUG - 2011-05-02 05:12:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:12:43 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:12:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:12:47 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:12:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:12:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:12:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:12:47 --> Final output sent to browser
DEBUG - 2011-05-02 05:12:47 --> Total execution time: 3.6486
DEBUG - 2011-05-02 05:13:10 --> Config Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:13:10 --> URI Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Router Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Output Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Input Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:13:10 --> Language Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Loader Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Controller Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:13:10 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:13:10 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:13:10 --> Final output sent to browser
DEBUG - 2011-05-02 05:13:10 --> Total execution time: 0.1147
DEBUG - 2011-05-02 05:13:30 --> Config Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:13:30 --> URI Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Router Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Output Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Input Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:13:30 --> Language Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Loader Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Controller Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:13:30 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:13:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:13:30 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:13:30 --> Final output sent to browser
DEBUG - 2011-05-02 05:13:30 --> Total execution time: 0.4283
DEBUG - 2011-05-02 05:13:31 --> Config Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:13:31 --> URI Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Router Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Output Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Input Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:13:31 --> Language Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Loader Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Controller Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:13:31 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:13:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:13:31 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:13:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:13:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:13:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:13:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:13:31 --> Final output sent to browser
DEBUG - 2011-05-02 05:13:31 --> Total execution time: 0.0584
DEBUG - 2011-05-02 05:13:32 --> Config Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:13:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:13:32 --> URI Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Router Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Output Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Input Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:13:32 --> Language Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Loader Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Controller Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:13:32 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:13:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:13:32 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:13:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:13:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:13:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:13:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:13:32 --> Final output sent to browser
DEBUG - 2011-05-02 05:13:32 --> Total execution time: 0.0491
DEBUG - 2011-05-02 05:13:45 --> Config Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:13:45 --> URI Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Router Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Output Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Input Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:13:45 --> Language Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Loader Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Controller Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:13:45 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:13:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:13:45 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:13:45 --> Final output sent to browser
DEBUG - 2011-05-02 05:13:45 --> Total execution time: 0.2825
DEBUG - 2011-05-02 05:13:46 --> Config Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:13:46 --> URI Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Router Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Output Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Input Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:13:46 --> Language Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Loader Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Controller Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Model Class Initialized
DEBUG - 2011-05-02 05:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:13:46 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:13:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:13:46 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:13:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:13:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:13:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:13:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:13:46 --> Final output sent to browser
DEBUG - 2011-05-02 05:13:46 --> Total execution time: 0.1031
DEBUG - 2011-05-02 05:14:05 --> Config Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:14:05 --> URI Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Router Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Output Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Input Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:14:05 --> Language Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Loader Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Controller Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:14:05 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:14:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:14:06 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:14:06 --> Final output sent to browser
DEBUG - 2011-05-02 05:14:06 --> Total execution time: 0.6684
DEBUG - 2011-05-02 05:14:08 --> Config Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:14:08 --> URI Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Router Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Output Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Input Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:14:08 --> Language Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Loader Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Controller Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:14:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:14:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:14:08 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:14:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:14:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:14:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:14:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:14:08 --> Final output sent to browser
DEBUG - 2011-05-02 05:14:08 --> Total execution time: 0.0447
DEBUG - 2011-05-02 05:14:21 --> Config Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:14:21 --> URI Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Router Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Output Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Input Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:14:21 --> Language Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Loader Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Controller Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:14:21 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:14:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:14:22 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:14:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:14:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:14:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:14:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:14:22 --> Final output sent to browser
DEBUG - 2011-05-02 05:14:22 --> Total execution time: 0.8432
DEBUG - 2011-05-02 05:14:27 --> Config Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:14:27 --> URI Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Router Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Output Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Input Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:14:27 --> Language Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Loader Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Controller Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:14:27 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:14:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:14:27 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:14:27 --> Final output sent to browser
DEBUG - 2011-05-02 05:14:27 --> Total execution time: 0.1159
DEBUG - 2011-05-02 05:14:32 --> Config Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:14:32 --> URI Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Router Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Output Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Input Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:14:32 --> Language Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Loader Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Controller Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:14:32 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:14:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:14:33 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:14:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:14:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:14:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:14:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:14:33 --> Final output sent to browser
DEBUG - 2011-05-02 05:14:33 --> Total execution time: 0.3136
DEBUG - 2011-05-02 05:14:41 --> Config Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:14:41 --> URI Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Router Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Output Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Input Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:14:41 --> Language Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Loader Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Controller Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Model Class Initialized
DEBUG - 2011-05-02 05:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:14:41 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:14:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 05:14:41 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:14:41 --> Final output sent to browser
DEBUG - 2011-05-02 05:14:41 --> Total execution time: 0.0621
DEBUG - 2011-05-02 05:42:27 --> Config Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:42:27 --> URI Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Router Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Output Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Input Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:42:27 --> Language Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Loader Class Initialized
DEBUG - 2011-05-02 05:42:27 --> Controller Class Initialized
ERROR - 2011-05-02 05:42:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 05:42:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 05:42:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 05:42:28 --> Model Class Initialized
DEBUG - 2011-05-02 05:42:28 --> Model Class Initialized
DEBUG - 2011-05-02 05:42:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:42:28 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:42:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 05:42:28 --> Helper loaded: url_helper
DEBUG - 2011-05-02 05:42:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 05:42:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 05:42:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 05:42:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 05:42:28 --> Final output sent to browser
DEBUG - 2011-05-02 05:42:28 --> Total execution time: 0.3756
DEBUG - 2011-05-02 05:42:29 --> Config Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:42:29 --> URI Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Router Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Output Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Input Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 05:42:29 --> Language Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Loader Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Controller Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Model Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Model Class Initialized
DEBUG - 2011-05-02 05:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 05:42:29 --> Database Driver Class Initialized
DEBUG - 2011-05-02 05:42:30 --> Final output sent to browser
DEBUG - 2011-05-02 05:42:30 --> Total execution time: 1.1705
DEBUG - 2011-05-02 05:42:32 --> Config Class Initialized
DEBUG - 2011-05-02 05:42:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:42:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:42:32 --> URI Class Initialized
DEBUG - 2011-05-02 05:42:32 --> Router Class Initialized
ERROR - 2011-05-02 05:42:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 05:42:33 --> Config Class Initialized
DEBUG - 2011-05-02 05:42:33 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:42:33 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:42:33 --> URI Class Initialized
DEBUG - 2011-05-02 05:42:33 --> Router Class Initialized
ERROR - 2011-05-02 05:42:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 05:42:33 --> Config Class Initialized
DEBUG - 2011-05-02 05:42:33 --> Hooks Class Initialized
DEBUG - 2011-05-02 05:42:33 --> Utf8 Class Initialized
DEBUG - 2011-05-02 05:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 05:42:33 --> URI Class Initialized
DEBUG - 2011-05-02 05:42:33 --> Router Class Initialized
ERROR - 2011-05-02 05:42:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 06:37:19 --> Config Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:37:19 --> URI Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Router Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Output Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Input Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:37:19 --> Language Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Loader Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Controller Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Model Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Model Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Model Class Initialized
DEBUG - 2011-05-02 06:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:37:19 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:37:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:37:20 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:37:20 --> Final output sent to browser
DEBUG - 2011-05-02 06:37:20 --> Total execution time: 0.6947
DEBUG - 2011-05-02 06:37:26 --> Config Class Initialized
DEBUG - 2011-05-02 06:37:26 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:37:26 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:37:26 --> URI Class Initialized
DEBUG - 2011-05-02 06:37:26 --> Router Class Initialized
ERROR - 2011-05-02 06:37:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 06:37:54 --> Config Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:37:54 --> URI Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Router Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Output Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Input Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:37:54 --> Language Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Loader Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Controller Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Model Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Model Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Model Class Initialized
DEBUG - 2011-05-02 06:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:37:54 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:37:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:37:55 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:37:55 --> Final output sent to browser
DEBUG - 2011-05-02 06:37:55 --> Total execution time: 0.4139
DEBUG - 2011-05-02 06:38:45 --> Config Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:38:45 --> URI Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Router Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Output Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Input Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:38:45 --> Language Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Loader Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Controller Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Model Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Model Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Model Class Initialized
DEBUG - 2011-05-02 06:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:38:45 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:38:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:38:46 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:38:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:38:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:38:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:38:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:38:46 --> Final output sent to browser
DEBUG - 2011-05-02 06:38:46 --> Total execution time: 0.4447
DEBUG - 2011-05-02 06:40:09 --> Config Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:40:09 --> URI Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Router Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Output Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Input Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:40:09 --> Language Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Loader Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Controller Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Model Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Model Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Model Class Initialized
DEBUG - 2011-05-02 06:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:40:09 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:40:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:40:09 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:40:09 --> Final output sent to browser
DEBUG - 2011-05-02 06:40:09 --> Total execution time: 0.5274
DEBUG - 2011-05-02 06:40:55 --> Config Class Initialized
DEBUG - 2011-05-02 06:40:55 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:40:55 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:40:55 --> URI Class Initialized
DEBUG - 2011-05-02 06:40:55 --> Router Class Initialized
DEBUG - 2011-05-02 06:40:55 --> Output Class Initialized
DEBUG - 2011-05-02 06:40:55 --> Input Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:40:56 --> Language Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Loader Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Controller Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Model Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Model Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Model Class Initialized
DEBUG - 2011-05-02 06:40:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:40:56 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:40:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:40:57 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:40:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:40:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:40:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:40:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:40:57 --> Final output sent to browser
DEBUG - 2011-05-02 06:40:57 --> Total execution time: 1.3747
DEBUG - 2011-05-02 06:41:04 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:04 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:04 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:04 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:04 --> Router Class Initialized
ERROR - 2011-05-02 06:41:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-02 06:41:05 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:05 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Router Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Output Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Input Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:41:05 --> Language Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Loader Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Controller Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:41:05 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:41:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:41:05 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:41:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:41:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:41:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:41:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:41:05 --> Final output sent to browser
DEBUG - 2011-05-02 06:41:05 --> Total execution time: 0.0765
DEBUG - 2011-05-02 06:41:18 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:18 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Router Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Output Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Input Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:41:18 --> Language Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Loader Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Controller Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:41:18 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:41:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:41:20 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:41:20 --> Final output sent to browser
DEBUG - 2011-05-02 06:41:20 --> Total execution time: 1.5346
DEBUG - 2011-05-02 06:41:43 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:43 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Router Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Output Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Input Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:41:43 --> Language Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Loader Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Controller Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:41:43 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:41:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:41:45 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:41:45 --> Final output sent to browser
DEBUG - 2011-05-02 06:41:45 --> Total execution time: 1.6694
DEBUG - 2011-05-02 06:41:46 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:46 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Router Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Output Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Input Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:41:46 --> Language Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Loader Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Controller Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:41:46 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:41:46 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:41:46 --> Final output sent to browser
DEBUG - 2011-05-02 06:41:46 --> Total execution time: 0.0731
DEBUG - 2011-05-02 06:41:46 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:46 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Router Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Output Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Input Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:41:46 --> Language Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Loader Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Controller Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:41:46 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:41:46 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:41:46 --> Final output sent to browser
DEBUG - 2011-05-02 06:41:46 --> Total execution time: 0.0555
DEBUG - 2011-05-02 06:41:47 --> Config Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 06:41:47 --> URI Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Router Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Output Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Input Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 06:41:47 --> Language Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Loader Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Controller Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Model Class Initialized
DEBUG - 2011-05-02 06:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 06:41:47 --> Database Driver Class Initialized
DEBUG - 2011-05-02 06:41:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 06:41:47 --> Helper loaded: url_helper
DEBUG - 2011-05-02 06:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 06:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 06:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 06:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 06:41:47 --> Final output sent to browser
DEBUG - 2011-05-02 06:41:47 --> Total execution time: 0.0884
DEBUG - 2011-05-02 07:07:52 --> Config Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:07:52 --> URI Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Router Class Initialized
DEBUG - 2011-05-02 07:07:52 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:07:52 --> Output Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Input Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:07:52 --> Language Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Loader Class Initialized
DEBUG - 2011-05-02 07:07:52 --> Controller Class Initialized
DEBUG - 2011-05-02 07:07:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:07:52 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:07:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:07:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:07:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:07:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:07:52 --> Final output sent to browser
DEBUG - 2011-05-02 07:07:52 --> Total execution time: 0.2394
DEBUG - 2011-05-02 07:07:53 --> Config Class Initialized
DEBUG - 2011-05-02 07:07:53 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:07:53 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:07:53 --> URI Class Initialized
DEBUG - 2011-05-02 07:07:53 --> Router Class Initialized
ERROR - 2011-05-02 07:07:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 07:07:54 --> Config Class Initialized
DEBUG - 2011-05-02 07:07:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:07:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:07:54 --> URI Class Initialized
DEBUG - 2011-05-02 07:07:54 --> Router Class Initialized
ERROR - 2011-05-02 07:07:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 07:07:55 --> Config Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:07:55 --> URI Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Router Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Output Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Input Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:07:55 --> Language Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Loader Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Controller Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Model Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Model Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Model Class Initialized
DEBUG - 2011-05-02 07:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:07:55 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:07:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:07:55 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:07:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:07:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:07:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:07:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:07:55 --> Final output sent to browser
DEBUG - 2011-05-02 07:07:55 --> Total execution time: 0.4996
DEBUG - 2011-05-02 07:08:08 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:08 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:08 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Controller Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:08:08 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:08:08 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:08 --> Total execution time: 0.2981
DEBUG - 2011-05-02 07:08:13 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:13 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:13 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Controller Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:13 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:08:13 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:08:13 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:13 --> Total execution time: 0.0507
DEBUG - 2011-05-02 07:08:14 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:14 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:14 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Controller Class Initialized
ERROR - 2011-05-02 07:08:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 07:08:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 07:08:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:08:14 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:14 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:08:14 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:08:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:08:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:08:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:08:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:08:14 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:14 --> Total execution time: 0.1408
DEBUG - 2011-05-02 07:08:15 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:15 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:15 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Controller Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:15 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:16 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:16 --> Total execution time: 1.1488
DEBUG - 2011-05-02 07:08:17 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:17 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:17 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:17 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:17 --> Router Class Initialized
ERROR - 2011-05-02 07:08:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 07:08:42 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:42 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:42 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Controller Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:42 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:08:43 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:08:43 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:43 --> Total execution time: 0.3435
DEBUG - 2011-05-02 07:08:43 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:43 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:43 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:44 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:44 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Controller Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:44 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:08:44 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:08:44 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:44 --> Total execution time: 0.0929
DEBUG - 2011-05-02 07:08:44 --> Config Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:08:44 --> URI Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Router Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Output Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Input Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:08:44 --> Language Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Loader Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Controller Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Model Class Initialized
DEBUG - 2011-05-02 07:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:08:44 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:08:44 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:08:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:08:44 --> Final output sent to browser
DEBUG - 2011-05-02 07:08:44 --> Total execution time: 0.0459
DEBUG - 2011-05-02 07:16:39 --> Config Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:16:39 --> URI Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Router Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Output Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Input Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:16:39 --> Language Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Loader Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Controller Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Model Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Model Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Model Class Initialized
DEBUG - 2011-05-02 07:16:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:16:39 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:16:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 07:16:39 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:16:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:16:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:16:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:16:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:16:39 --> Final output sent to browser
DEBUG - 2011-05-02 07:16:39 --> Total execution time: 0.0495
DEBUG - 2011-05-02 07:16:50 --> Config Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:16:50 --> URI Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Router Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Output Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Input Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:16:50 --> Language Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Loader Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Controller Class Initialized
ERROR - 2011-05-02 07:16:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 07:16:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 07:16:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:16:50 --> Model Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Model Class Initialized
DEBUG - 2011-05-02 07:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:16:50 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:16:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:16:50 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:16:50 --> Final output sent to browser
DEBUG - 2011-05-02 07:16:50 --> Total execution time: 0.0309
DEBUG - 2011-05-02 07:19:47 --> Config Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:19:47 --> URI Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Router Class Initialized
DEBUG - 2011-05-02 07:19:47 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:19:47 --> Output Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Input Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:19:47 --> Language Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Loader Class Initialized
DEBUG - 2011-05-02 07:19:47 --> Controller Class Initialized
DEBUG - 2011-05-02 07:19:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:19:47 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:19:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:19:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:19:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:19:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:19:47 --> Final output sent to browser
DEBUG - 2011-05-02 07:19:47 --> Total execution time: 0.0817
DEBUG - 2011-05-02 07:20:00 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:00 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Router Class Initialized
ERROR - 2011-05-02 07:20:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-02 07:20:00 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:00 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:00 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:00 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:00 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:00 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:00 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:00 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:00 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:00 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:00 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:00 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:00 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:00 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:00 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:00 --> Final output sent to browser
DEBUG - 2011-05-02 07:20:00 --> Total execution time: 0.0178
DEBUG - 2011-05-02 07:20:00 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:00 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:00 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:00 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:00 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:00 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:01 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:01 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Router Class Initialized
ERROR - 2011-05-02 07:20:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-02 07:20:01 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:01 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:01 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:01 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:01 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:01 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:01 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:01 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:01 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:01 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:01 --> Final output sent to browser
DEBUG - 2011-05-02 07:20:01 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Total execution time: 0.0146
DEBUG - 2011-05-02 07:20:01 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:01 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:01 --> Final output sent to browser
DEBUG - 2011-05-02 07:20:01 --> Total execution time: 0.0134
DEBUG - 2011-05-02 07:20:01 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:01 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Router Class Initialized
ERROR - 2011-05-02 07:20:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-02 07:20:01 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:01 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:01 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:01 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:01 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:01 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:01 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:01 --> Final output sent to browser
DEBUG - 2011-05-02 07:20:01 --> Total execution time: 0.0122
DEBUG - 2011-05-02 07:20:06 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:06 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:06 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:06 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:06 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:06 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:06 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:20:06 --> Final output sent to browser
DEBUG - 2011-05-02 07:20:06 --> Total execution time: 0.2159
DEBUG - 2011-05-02 07:20:16 --> Config Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:20:16 --> URI Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Router Class Initialized
DEBUG - 2011-05-02 07:20:16 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:20:16 --> Output Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Input Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:20:16 --> Language Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Loader Class Initialized
DEBUG - 2011-05-02 07:20:16 --> Controller Class Initialized
DEBUG - 2011-05-02 07:20:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:20:16 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:20:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:20:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:20:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:20:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:21:20 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:20 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Router Class Initialized
DEBUG - 2011-05-02 07:21:20 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:21:20 --> Output Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Input Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:21:20 --> Language Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Loader Class Initialized
DEBUG - 2011-05-02 07:21:20 --> Controller Class Initialized
DEBUG - 2011-05-02 07:21:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:21:20 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:21:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:21:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:21:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:21:21 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:21 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:21 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:21 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:21 --> Router Class Initialized
DEBUG - 2011-05-02 07:21:21 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:21:21 --> Output Class Initialized
DEBUG - 2011-05-02 07:21:21 --> Input Class Initialized
DEBUG - 2011-05-02 07:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:21:21 --> Language Class Initialized
DEBUG - 2011-05-02 07:21:22 --> Loader Class Initialized
DEBUG - 2011-05-02 07:21:22 --> Controller Class Initialized
DEBUG - 2011-05-02 07:21:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:21:22 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:21:22 --> Final output sent to browser
DEBUG - 2011-05-02 07:21:22 --> Total execution time: 0.0136
DEBUG - 2011-05-02 07:21:40 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:40 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Router Class Initialized
DEBUG - 2011-05-02 07:21:40 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:21:40 --> Output Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Input Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:21:40 --> Language Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Loader Class Initialized
DEBUG - 2011-05-02 07:21:40 --> Controller Class Initialized
DEBUG - 2011-05-02 07:21:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:21:40 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:21:40 --> Final output sent to browser
DEBUG - 2011-05-02 07:21:40 --> Total execution time: 0.0154
DEBUG - 2011-05-02 07:21:43 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:43 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:43 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:43 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:43 --> Router Class Initialized
ERROR - 2011-05-02 07:21:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 07:21:51 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:51 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Router Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Output Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Input Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:21:51 --> Language Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Loader Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Controller Class Initialized
ERROR - 2011-05-02 07:21:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 07:21:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 07:21:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:21:51 --> Model Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Model Class Initialized
DEBUG - 2011-05-02 07:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:21:51 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:21:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:21:51 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:21:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:21:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:21:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:21:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:21:51 --> Final output sent to browser
DEBUG - 2011-05-02 07:21:51 --> Total execution time: 0.0550
DEBUG - 2011-05-02 07:21:52 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:52 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Router Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Output Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Input Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:21:52 --> Language Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Loader Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Controller Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Model Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Model Class Initialized
DEBUG - 2011-05-02 07:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:21:52 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:21:53 --> Final output sent to browser
DEBUG - 2011-05-02 07:21:53 --> Total execution time: 0.6195
DEBUG - 2011-05-02 07:21:54 --> Config Class Initialized
DEBUG - 2011-05-02 07:21:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:21:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:21:54 --> URI Class Initialized
DEBUG - 2011-05-02 07:21:54 --> Router Class Initialized
ERROR - 2011-05-02 07:21:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 07:24:56 --> Config Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:24:56 --> URI Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Router Class Initialized
DEBUG - 2011-05-02 07:24:56 --> No URI present. Default controller set.
DEBUG - 2011-05-02 07:24:56 --> Output Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Input Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:24:56 --> Language Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Loader Class Initialized
DEBUG - 2011-05-02 07:24:56 --> Controller Class Initialized
DEBUG - 2011-05-02 07:24:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 07:24:56 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:24:56 --> Final output sent to browser
DEBUG - 2011-05-02 07:24:56 --> Total execution time: 0.4067
DEBUG - 2011-05-02 07:26:57 --> Config Class Initialized
DEBUG - 2011-05-02 07:26:57 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:26:57 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:26:57 --> URI Class Initialized
DEBUG - 2011-05-02 07:26:57 --> Router Class Initialized
DEBUG - 2011-05-02 07:26:57 --> Output Class Initialized
DEBUG - 2011-05-02 07:26:57 --> Input Class Initialized
DEBUG - 2011-05-02 07:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:26:57 --> Language Class Initialized
DEBUG - 2011-05-02 07:26:58 --> Loader Class Initialized
DEBUG - 2011-05-02 07:26:58 --> Controller Class Initialized
ERROR - 2011-05-02 07:26:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 07:26:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 07:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:26:58 --> Model Class Initialized
DEBUG - 2011-05-02 07:26:58 --> Model Class Initialized
DEBUG - 2011-05-02 07:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:26:58 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:26:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:26:59 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:26:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:26:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:26:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:26:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:26:59 --> Final output sent to browser
DEBUG - 2011-05-02 07:26:59 --> Total execution time: 1.1146
DEBUG - 2011-05-02 07:35:31 --> Config Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Hooks Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Utf8 Class Initialized
DEBUG - 2011-05-02 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 07:35:31 --> URI Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Router Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Output Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Input Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 07:35:31 --> Language Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Loader Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Controller Class Initialized
ERROR - 2011-05-02 07:35:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 07:35:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 07:35:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:35:31 --> Model Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Model Class Initialized
DEBUG - 2011-05-02 07:35:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 07:35:31 --> Database Driver Class Initialized
DEBUG - 2011-05-02 07:35:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 07:35:31 --> Helper loaded: url_helper
DEBUG - 2011-05-02 07:35:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 07:35:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 07:35:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 07:35:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 07:35:31 --> Final output sent to browser
DEBUG - 2011-05-02 07:35:31 --> Total execution time: 0.2412
DEBUG - 2011-05-02 08:07:57 --> Config Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:07:57 --> URI Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Router Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Output Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Input Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:07:57 --> Language Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Loader Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Controller Class Initialized
ERROR - 2011-05-02 08:07:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 08:07:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 08:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:07:57 --> Model Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Model Class Initialized
DEBUG - 2011-05-02 08:07:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:07:57 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:07:57 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:07:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:07:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:07:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:07:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:07:58 --> Final output sent to browser
DEBUG - 2011-05-02 08:07:58 --> Total execution time: 0.3664
DEBUG - 2011-05-02 08:07:59 --> Config Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:07:59 --> URI Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Router Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Output Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Input Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:07:59 --> Language Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Loader Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Controller Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Model Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Model Class Initialized
DEBUG - 2011-05-02 08:07:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:07:59 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:08:00 --> Final output sent to browser
DEBUG - 2011-05-02 08:08:00 --> Total execution time: 1.1936
DEBUG - 2011-05-02 08:08:03 --> Config Class Initialized
DEBUG - 2011-05-02 08:08:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:08:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:08:03 --> URI Class Initialized
DEBUG - 2011-05-02 08:08:03 --> Router Class Initialized
ERROR - 2011-05-02 08:08:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 08:08:06 --> Config Class Initialized
DEBUG - 2011-05-02 08:08:06 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:08:06 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:08:06 --> URI Class Initialized
DEBUG - 2011-05-02 08:08:06 --> Router Class Initialized
ERROR - 2011-05-02 08:08:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 08:08:16 --> Config Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:08:16 --> URI Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Router Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Output Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Input Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:08:16 --> Language Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Loader Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Controller Class Initialized
ERROR - 2011-05-02 08:08:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 08:08:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 08:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:08:16 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:08:16 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:08:16 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:08:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:08:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:08:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:08:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:08:16 --> Final output sent to browser
DEBUG - 2011-05-02 08:08:16 --> Total execution time: 0.0322
DEBUG - 2011-05-02 08:08:17 --> Config Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:08:17 --> URI Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Router Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Output Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Input Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:08:17 --> Language Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Loader Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Controller Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:08:17 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:08:18 --> Final output sent to browser
DEBUG - 2011-05-02 08:08:18 --> Total execution time: 0.7093
DEBUG - 2011-05-02 08:08:35 --> Config Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:08:35 --> URI Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Router Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Output Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Input Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:08:35 --> Language Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Loader Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Controller Class Initialized
ERROR - 2011-05-02 08:08:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 08:08:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 08:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:08:35 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:08:35 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:08:35 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:08:35 --> Final output sent to browser
DEBUG - 2011-05-02 08:08:35 --> Total execution time: 0.0309
DEBUG - 2011-05-02 08:08:36 --> Config Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:08:36 --> URI Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Router Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Output Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Input Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:08:36 --> Language Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Loader Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Controller Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Model Class Initialized
DEBUG - 2011-05-02 08:08:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:08:36 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:08:37 --> Final output sent to browser
DEBUG - 2011-05-02 08:08:37 --> Total execution time: 0.6214
DEBUG - 2011-05-02 08:09:00 --> Config Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:09:00 --> URI Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Router Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Output Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Input Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:09:00 --> Language Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Loader Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Controller Class Initialized
ERROR - 2011-05-02 08:09:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 08:09:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 08:09:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:09:00 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:09:00 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:09:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:09:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:09:00 --> Final output sent to browser
DEBUG - 2011-05-02 08:09:00 --> Total execution time: 0.0638
DEBUG - 2011-05-02 08:09:01 --> Config Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:09:01 --> URI Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Router Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Output Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Input Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:09:01 --> Language Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Loader Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Controller Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:09:01 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:09:02 --> Final output sent to browser
DEBUG - 2011-05-02 08:09:02 --> Total execution time: 1.2019
DEBUG - 2011-05-02 08:09:43 --> Config Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:09:43 --> URI Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Router Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Output Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Input Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:09:43 --> Language Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Loader Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Controller Class Initialized
ERROR - 2011-05-02 08:09:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 08:09:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 08:09:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:09:43 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:09:43 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:09:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 08:09:43 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:09:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:09:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:09:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:09:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:09:43 --> Final output sent to browser
DEBUG - 2011-05-02 08:09:43 --> Total execution time: 0.1791
DEBUG - 2011-05-02 08:09:46 --> Config Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:09:46 --> URI Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Router Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Output Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Input Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:09:46 --> Language Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Loader Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Controller Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Model Class Initialized
DEBUG - 2011-05-02 08:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:09:46 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:09:49 --> Final output sent to browser
DEBUG - 2011-05-02 08:09:49 --> Total execution time: 2.5523
DEBUG - 2011-05-02 08:41:14 --> Config Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:41:14 --> URI Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Router Class Initialized
DEBUG - 2011-05-02 08:41:14 --> No URI present. Default controller set.
DEBUG - 2011-05-02 08:41:14 --> Output Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Input Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:41:14 --> Language Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Loader Class Initialized
DEBUG - 2011-05-02 08:41:14 --> Controller Class Initialized
DEBUG - 2011-05-02 08:41:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 08:41:14 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:41:14 --> Final output sent to browser
DEBUG - 2011-05-02 08:41:14 --> Total execution time: 0.6063
DEBUG - 2011-05-02 08:41:18 --> Config Class Initialized
DEBUG - 2011-05-02 08:41:18 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:41:18 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:41:18 --> URI Class Initialized
DEBUG - 2011-05-02 08:41:18 --> Router Class Initialized
ERROR - 2011-05-02 08:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 08:50:14 --> Config Class Initialized
DEBUG - 2011-05-02 08:50:14 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:50:14 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:50:14 --> URI Class Initialized
DEBUG - 2011-05-02 08:50:14 --> Router Class Initialized
DEBUG - 2011-05-02 08:50:14 --> No URI present. Default controller set.
DEBUG - 2011-05-02 08:50:15 --> Output Class Initialized
DEBUG - 2011-05-02 08:50:16 --> Input Class Initialized
DEBUG - 2011-05-02 08:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:50:16 --> Language Class Initialized
DEBUG - 2011-05-02 08:50:17 --> Loader Class Initialized
DEBUG - 2011-05-02 08:50:17 --> Controller Class Initialized
DEBUG - 2011-05-02 08:50:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 08:50:18 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:50:18 --> Final output sent to browser
DEBUG - 2011-05-02 08:50:18 --> Total execution time: 5.0696
DEBUG - 2011-05-02 08:50:25 --> Config Class Initialized
DEBUG - 2011-05-02 08:50:25 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:50:25 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:50:25 --> URI Class Initialized
DEBUG - 2011-05-02 08:50:25 --> Router Class Initialized
DEBUG - 2011-05-02 08:50:26 --> Output Class Initialized
DEBUG - 2011-05-02 08:50:26 --> Input Class Initialized
DEBUG - 2011-05-02 08:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 08:50:26 --> Language Class Initialized
DEBUG - 2011-05-02 08:50:26 --> Loader Class Initialized
DEBUG - 2011-05-02 08:50:26 --> Controller Class Initialized
DEBUG - 2011-05-02 08:50:27 --> Model Class Initialized
DEBUG - 2011-05-02 08:50:27 --> Model Class Initialized
DEBUG - 2011-05-02 08:50:27 --> Model Class Initialized
DEBUG - 2011-05-02 08:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 08:50:27 --> Database Driver Class Initialized
DEBUG - 2011-05-02 08:50:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 08:50:28 --> Helper loaded: url_helper
DEBUG - 2011-05-02 08:50:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 08:50:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 08:50:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 08:50:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 08:50:28 --> Final output sent to browser
DEBUG - 2011-05-02 08:50:28 --> Total execution time: 2.4375
DEBUG - 2011-05-02 08:50:29 --> Config Class Initialized
DEBUG - 2011-05-02 08:50:29 --> Hooks Class Initialized
DEBUG - 2011-05-02 08:50:29 --> Utf8 Class Initialized
DEBUG - 2011-05-02 08:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 08:50:29 --> URI Class Initialized
DEBUG - 2011-05-02 08:50:29 --> Router Class Initialized
ERROR - 2011-05-02 08:50:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 09:32:53 --> Config Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:32:53 --> URI Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Router Class Initialized
DEBUG - 2011-05-02 09:32:53 --> No URI present. Default controller set.
DEBUG - 2011-05-02 09:32:53 --> Output Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Input Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:32:53 --> Language Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Loader Class Initialized
DEBUG - 2011-05-02 09:32:53 --> Controller Class Initialized
DEBUG - 2011-05-02 09:32:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 09:32:54 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:32:54 --> Final output sent to browser
DEBUG - 2011-05-02 09:32:54 --> Total execution time: 0.4485
DEBUG - 2011-05-02 09:32:56 --> Config Class Initialized
DEBUG - 2011-05-02 09:32:56 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:32:56 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:32:56 --> URI Class Initialized
DEBUG - 2011-05-02 09:32:56 --> Router Class Initialized
ERROR - 2011-05-02 09:32:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 09:34:02 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:02 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:02 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:02 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:02 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:02 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:02 --> Total execution time: 0.3928
DEBUG - 2011-05-02 09:34:04 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:04 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:04 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:04 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:04 --> Router Class Initialized
ERROR - 2011-05-02 09:34:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 09:34:08 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:08 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:08 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:08 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:08 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:08 --> Total execution time: 0.6626
DEBUG - 2011-05-02 09:34:10 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:10 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:10 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:10 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:10 --> Router Class Initialized
ERROR - 2011-05-02 09:34:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 09:34:13 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:13 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:13 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:13 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:13 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:13 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:13 --> Total execution time: 0.0468
DEBUG - 2011-05-02 09:34:15 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:15 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:15 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:15 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:15 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:15 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:15 --> Total execution time: 0.3230
DEBUG - 2011-05-02 09:34:16 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:16 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:16 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:16 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:16 --> Router Class Initialized
ERROR - 2011-05-02 09:34:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 09:34:19 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:19 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:19 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:19 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:19 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:19 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:19 --> Total execution time: 0.1671
DEBUG - 2011-05-02 09:34:27 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:27 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:27 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:27 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:27 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:27 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:27 --> Total execution time: 0.1880
DEBUG - 2011-05-02 09:34:28 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:28 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Router Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Output Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Input Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 09:34:28 --> Language Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Loader Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Controller Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Model Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 09:34:28 --> Database Driver Class Initialized
DEBUG - 2011-05-02 09:34:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 09:34:28 --> Helper loaded: url_helper
DEBUG - 2011-05-02 09:34:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 09:34:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 09:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 09:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 09:34:28 --> Final output sent to browser
DEBUG - 2011-05-02 09:34:28 --> Total execution time: 0.1196
DEBUG - 2011-05-02 09:34:28 --> Config Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:34:28 --> URI Class Initialized
DEBUG - 2011-05-02 09:34:28 --> Router Class Initialized
ERROR - 2011-05-02 09:34:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 09:55:29 --> Config Class Initialized
DEBUG - 2011-05-02 09:55:29 --> Hooks Class Initialized
DEBUG - 2011-05-02 09:55:29 --> Utf8 Class Initialized
DEBUG - 2011-05-02 09:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 09:55:29 --> URI Class Initialized
DEBUG - 2011-05-02 09:55:29 --> Router Class Initialized
ERROR - 2011-05-02 09:55:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-02 10:01:51 --> Config Class Initialized
DEBUG - 2011-05-02 10:01:51 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:01:51 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:01:51 --> URI Class Initialized
DEBUG - 2011-05-02 10:01:51 --> Router Class Initialized
ERROR - 2011-05-02 10:01:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 10:46:27 --> Config Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:46:27 --> URI Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Router Class Initialized
DEBUG - 2011-05-02 10:46:27 --> No URI present. Default controller set.
DEBUG - 2011-05-02 10:46:27 --> Output Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Input Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 10:46:27 --> Language Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Loader Class Initialized
DEBUG - 2011-05-02 10:46:27 --> Controller Class Initialized
DEBUG - 2011-05-02 10:46:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 10:46:27 --> Helper loaded: url_helper
DEBUG - 2011-05-02 10:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 10:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 10:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 10:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 10:46:27 --> Final output sent to browser
DEBUG - 2011-05-02 10:46:27 --> Total execution time: 0.2364
DEBUG - 2011-05-02 10:46:29 --> Config Class Initialized
DEBUG - 2011-05-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:46:29 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:46:29 --> URI Class Initialized
DEBUG - 2011-05-02 10:46:30 --> Router Class Initialized
ERROR - 2011-05-02 10:46:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 10:46:50 --> Config Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:46:50 --> URI Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Router Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Output Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Input Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 10:46:50 --> Language Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Loader Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Controller Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Model Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Model Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Model Class Initialized
DEBUG - 2011-05-02 10:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 10:46:50 --> Database Driver Class Initialized
DEBUG - 2011-05-02 10:46:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 10:46:51 --> Helper loaded: url_helper
DEBUG - 2011-05-02 10:46:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 10:46:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 10:46:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 10:46:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 10:46:51 --> Final output sent to browser
DEBUG - 2011-05-02 10:46:51 --> Total execution time: 0.6273
DEBUG - 2011-05-02 10:46:53 --> Config Class Initialized
DEBUG - 2011-05-02 10:46:53 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:46:53 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:46:53 --> URI Class Initialized
DEBUG - 2011-05-02 10:46:53 --> Router Class Initialized
ERROR - 2011-05-02 10:46:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 10:47:02 --> Config Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:47:02 --> URI Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Router Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Output Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Input Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 10:47:02 --> Language Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Loader Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Controller Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Model Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Model Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Model Class Initialized
DEBUG - 2011-05-02 10:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 10:47:02 --> Database Driver Class Initialized
DEBUG - 2011-05-02 10:47:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 10:47:02 --> Helper loaded: url_helper
DEBUG - 2011-05-02 10:47:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 10:47:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 10:47:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 10:47:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 10:47:02 --> Final output sent to browser
DEBUG - 2011-05-02 10:47:02 --> Total execution time: 0.2115
DEBUG - 2011-05-02 10:53:32 --> Config Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:53:32 --> URI Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Router Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Output Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Input Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 10:53:32 --> Language Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Loader Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Controller Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Model Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Model Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Model Class Initialized
DEBUG - 2011-05-02 10:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 10:53:32 --> Database Driver Class Initialized
DEBUG - 2011-05-02 10:53:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 10:53:32 --> Helper loaded: url_helper
DEBUG - 2011-05-02 10:53:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 10:53:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 10:53:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 10:53:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 10:53:32 --> Final output sent to browser
DEBUG - 2011-05-02 10:53:32 --> Total execution time: 0.1572
DEBUG - 2011-05-02 10:53:58 --> Config Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Hooks Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Utf8 Class Initialized
DEBUG - 2011-05-02 10:53:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 10:53:58 --> URI Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Router Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Output Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Input Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 10:53:58 --> Language Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Loader Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Controller Class Initialized
ERROR - 2011-05-02 10:53:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 10:53:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 10:53:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 10:53:58 --> Model Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Model Class Initialized
DEBUG - 2011-05-02 10:53:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 10:53:58 --> Database Driver Class Initialized
DEBUG - 2011-05-02 10:53:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 10:53:58 --> Helper loaded: url_helper
DEBUG - 2011-05-02 10:53:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 10:53:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 10:53:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 10:53:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 10:53:58 --> Final output sent to browser
DEBUG - 2011-05-02 10:53:58 --> Total execution time: 0.1084
DEBUG - 2011-05-02 12:07:00 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:00 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Router Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Output Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Input Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:07:00 --> Language Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Loader Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Controller Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:07:00 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:07:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:07:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:07:00 --> Final output sent to browser
DEBUG - 2011-05-02 12:07:00 --> Total execution time: 0.5184
DEBUG - 2011-05-02 12:07:02 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:02 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Router Class Initialized
ERROR - 2011-05-02 12:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 12:07:02 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:02 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Router Class Initialized
ERROR - 2011-05-02 12:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 12:07:02 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:02 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:02 --> Router Class Initialized
ERROR - 2011-05-02 12:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 12:07:15 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:15 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Router Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Output Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Input Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:07:15 --> Language Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Loader Class Initialized
DEBUG - 2011-05-02 12:07:15 --> Controller Class Initialized
ERROR - 2011-05-02 12:07:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 12:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 12:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:07:16 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:07:16 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:07:16 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:07:16 --> Final output sent to browser
DEBUG - 2011-05-02 12:07:16 --> Total execution time: 0.1375
DEBUG - 2011-05-02 12:07:16 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:16 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Router Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Output Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Input Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:07:16 --> Language Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Loader Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Controller Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:07:16 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:07:17 --> Final output sent to browser
DEBUG - 2011-05-02 12:07:17 --> Total execution time: 0.7324
DEBUG - 2011-05-02 12:07:37 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:37 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Router Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Output Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Input Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:07:37 --> Language Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Loader Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Controller Class Initialized
ERROR - 2011-05-02 12:07:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 12:07:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 12:07:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:07:37 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:07:37 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:07:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:07:37 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:07:37 --> Final output sent to browser
DEBUG - 2011-05-02 12:07:37 --> Total execution time: 0.1442
DEBUG - 2011-05-02 12:07:37 --> Config Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:07:37 --> URI Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Router Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Output Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Input Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:07:37 --> Language Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Loader Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Controller Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Model Class Initialized
DEBUG - 2011-05-02 12:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:07:37 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:07:38 --> Final output sent to browser
DEBUG - 2011-05-02 12:07:38 --> Total execution time: 0.8484
DEBUG - 2011-05-02 12:46:45 --> Config Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:46:45 --> URI Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Router Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Output Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Input Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:46:45 --> Language Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Loader Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Controller Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Model Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Model Class Initialized
DEBUG - 2011-05-02 12:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:46:45 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:46:46 --> Final output sent to browser
DEBUG - 2011-05-02 12:46:46 --> Total execution time: 1.1286
DEBUG - 2011-05-02 12:47:02 --> Config Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:47:02 --> URI Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Router Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Output Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Input Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:47:02 --> Language Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Loader Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Controller Class Initialized
ERROR - 2011-05-02 12:47:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 12:47:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 12:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:47:02 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:47:02 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:47:02 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:47:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:47:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:47:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:47:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:47:02 --> Final output sent to browser
DEBUG - 2011-05-02 12:47:02 --> Total execution time: 0.2848
DEBUG - 2011-05-02 12:47:03 --> Config Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:47:03 --> URI Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Router Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Output Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Input Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:47:03 --> Language Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Loader Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Controller Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:47:03 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:47:04 --> Final output sent to browser
DEBUG - 2011-05-02 12:47:04 --> Total execution time: 0.4669
DEBUG - 2011-05-02 12:47:05 --> Config Class Initialized
DEBUG - 2011-05-02 12:47:05 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:47:05 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:47:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:47:05 --> URI Class Initialized
DEBUG - 2011-05-02 12:47:05 --> Router Class Initialized
ERROR - 2011-05-02 12:47:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 12:47:08 --> Config Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:47:08 --> URI Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Router Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Output Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Input Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:47:08 --> Language Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Loader Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Controller Class Initialized
ERROR - 2011-05-02 12:47:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 12:47:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 12:47:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:47:08 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:47:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:47:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 12:47:08 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:47:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:47:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:47:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:47:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:47:08 --> Final output sent to browser
DEBUG - 2011-05-02 12:47:08 --> Total execution time: 0.0438
DEBUG - 2011-05-02 12:47:18 --> Config Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:47:18 --> URI Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Router Class Initialized
DEBUG - 2011-05-02 12:47:18 --> No URI present. Default controller set.
DEBUG - 2011-05-02 12:47:18 --> Output Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Input Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:47:18 --> Language Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Loader Class Initialized
DEBUG - 2011-05-02 12:47:18 --> Controller Class Initialized
DEBUG - 2011-05-02 12:47:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-02 12:47:18 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:47:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:47:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:47:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:47:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:47:18 --> Final output sent to browser
DEBUG - 2011-05-02 12:47:18 --> Total execution time: 0.0686
DEBUG - 2011-05-02 12:47:44 --> Config Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:47:44 --> URI Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Router Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Output Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Input Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:47:44 --> Language Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Loader Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Controller Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Model Class Initialized
DEBUG - 2011-05-02 12:47:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:47:44 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:47:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:47:45 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:47:45 --> Final output sent to browser
DEBUG - 2011-05-02 12:47:45 --> Total execution time: 0.8903
DEBUG - 2011-05-02 12:48:34 --> Config Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:48:34 --> URI Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Router Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Output Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Input Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:48:34 --> Language Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Loader Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Controller Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Model Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Model Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Model Class Initialized
DEBUG - 2011-05-02 12:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:48:34 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:48:34 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:48:34 --> Final output sent to browser
DEBUG - 2011-05-02 12:48:34 --> Total execution time: 0.6309
DEBUG - 2011-05-02 12:48:45 --> Config Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:48:45 --> URI Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Router Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Output Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Input Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:48:45 --> Language Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Loader Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Controller Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Model Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Model Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Model Class Initialized
DEBUG - 2011-05-02 12:48:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:48:45 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:48:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:48:45 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:48:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:48:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:48:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:48:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:48:45 --> Final output sent to browser
DEBUG - 2011-05-02 12:48:45 --> Total execution time: 0.1013
DEBUG - 2011-05-02 12:50:00 --> Config Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:50:00 --> URI Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Router Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Output Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Input Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:50:00 --> Language Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Loader Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Controller Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Model Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Model Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Model Class Initialized
DEBUG - 2011-05-02 12:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:50:00 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:50:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:50:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:50:00 --> Final output sent to browser
DEBUG - 2011-05-02 12:50:00 --> Total execution time: 0.2155
DEBUG - 2011-05-02 12:50:17 --> Config Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:50:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:50:17 --> URI Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Router Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Output Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Input Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:50:17 --> Language Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Loader Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Controller Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Model Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Model Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Model Class Initialized
DEBUG - 2011-05-02 12:50:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:50:17 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:50:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:50:17 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:50:17 --> Final output sent to browser
DEBUG - 2011-05-02 12:50:17 --> Total execution time: 0.0469
DEBUG - 2011-05-02 12:53:42 --> Config Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Hooks Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Utf8 Class Initialized
DEBUG - 2011-05-02 12:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 12:53:42 --> URI Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Router Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Output Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Input Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 12:53:42 --> Language Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Loader Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Controller Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Model Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Model Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Model Class Initialized
DEBUG - 2011-05-02 12:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 12:53:42 --> Database Driver Class Initialized
DEBUG - 2011-05-02 12:53:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 12:53:42 --> Helper loaded: url_helper
DEBUG - 2011-05-02 12:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 12:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 12:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 12:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 12:53:42 --> Final output sent to browser
DEBUG - 2011-05-02 12:53:42 --> Total execution time: 0.4283
DEBUG - 2011-05-02 13:50:59 --> Config Class Initialized
DEBUG - 2011-05-02 13:50:59 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:50:59 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:50:59 --> URI Class Initialized
DEBUG - 2011-05-02 13:50:59 --> Router Class Initialized
DEBUG - 2011-05-02 13:50:59 --> Output Class Initialized
DEBUG - 2011-05-02 13:51:00 --> Input Class Initialized
DEBUG - 2011-05-02 13:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:51:00 --> Language Class Initialized
DEBUG - 2011-05-02 13:51:00 --> Loader Class Initialized
DEBUG - 2011-05-02 13:51:00 --> Controller Class Initialized
ERROR - 2011-05-02 13:51:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 13:51:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 13:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 13:51:01 --> Model Class Initialized
DEBUG - 2011-05-02 13:51:01 --> Model Class Initialized
DEBUG - 2011-05-02 13:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:51:01 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:51:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 13:51:02 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:51:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:51:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:51:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:51:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:51:02 --> Final output sent to browser
DEBUG - 2011-05-02 13:51:02 --> Total execution time: 4.3418
DEBUG - 2011-05-02 13:51:04 --> Config Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:51:04 --> URI Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Router Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Output Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Input Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:51:04 --> Language Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Loader Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Controller Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Model Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Model Class Initialized
DEBUG - 2011-05-02 13:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:51:04 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:51:05 --> Final output sent to browser
DEBUG - 2011-05-02 13:51:05 --> Total execution time: 1.0578
DEBUG - 2011-05-02 13:57:03 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:03 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Router Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Output Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Input Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:57:03 --> Language Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Loader Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Controller Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:57:03 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:57:03 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:57:03 --> Final output sent to browser
DEBUG - 2011-05-02 13:57:03 --> Total execution time: 0.7787
DEBUG - 2011-05-02 13:57:06 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:06 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:06 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:06 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:06 --> Router Class Initialized
ERROR - 2011-05-02 13:57:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 13:57:22 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:22 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Router Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Output Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Input Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:57:22 --> Language Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Loader Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Controller Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:57:22 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:57:22 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:57:22 --> Final output sent to browser
DEBUG - 2011-05-02 13:57:22 --> Total execution time: 0.4567
DEBUG - 2011-05-02 13:57:24 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:24 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Router Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Output Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Input Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:57:24 --> Language Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Loader Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Controller Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:57:24 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:57:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:57:24 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:57:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:57:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:57:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:57:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:57:24 --> Final output sent to browser
DEBUG - 2011-05-02 13:57:24 --> Total execution time: 0.0946
DEBUG - 2011-05-02 13:57:24 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:24 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:24 --> Router Class Initialized
ERROR - 2011-05-02 13:57:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 13:57:40 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:40 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Router Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Output Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Input Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:57:40 --> Language Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Loader Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Controller Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:57:40 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:57:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:57:40 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:57:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:57:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:57:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:57:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:57:40 --> Final output sent to browser
DEBUG - 2011-05-02 13:57:40 --> Total execution time: 0.3047
DEBUG - 2011-05-02 13:57:41 --> Config Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:57:41 --> URI Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Router Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Output Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Input Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:57:41 --> Language Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Loader Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Controller Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Model Class Initialized
DEBUG - 2011-05-02 13:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:57:41 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:57:42 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:57:42 --> Final output sent to browser
DEBUG - 2011-05-02 13:57:42 --> Total execution time: 0.0705
DEBUG - 2011-05-02 13:58:01 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:01 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:01 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:01 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:02 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:02 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:02 --> Total execution time: 0.7545
DEBUG - 2011-05-02 13:58:03 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:03 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:03 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:03 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:03 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:03 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:03 --> Total execution time: 0.0550
DEBUG - 2011-05-02 13:58:04 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:04 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:04 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:04 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:04 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:04 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:04 --> Total execution time: 0.0477
DEBUG - 2011-05-02 13:58:12 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:12 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:12 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:12 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:12 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:12 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:12 --> Total execution time: 0.1817
DEBUG - 2011-05-02 13:58:13 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:13 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:13 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:13 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:13 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:13 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:13 --> Total execution time: 0.0560
DEBUG - 2011-05-02 13:58:29 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:29 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:29 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:29 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:30 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:30 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:30 --> Total execution time: 0.5796
DEBUG - 2011-05-02 13:58:32 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:32 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:32 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:32 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:32 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:32 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:32 --> Total execution time: 0.0550
DEBUG - 2011-05-02 13:58:40 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:40 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:40 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:40 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:40 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:40 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:40 --> Total execution time: 0.4947
DEBUG - 2011-05-02 13:58:42 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:42 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:42 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:42 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:42 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:42 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:42 --> Total execution time: 0.1710
DEBUG - 2011-05-02 13:58:52 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:52 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:52 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:52 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:52 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:52 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:52 --> Total execution time: 0.3080
DEBUG - 2011-05-02 13:58:54 --> Config Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:58:54 --> URI Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Router Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Output Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Input Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:58:54 --> Language Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Loader Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Controller Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Model Class Initialized
DEBUG - 2011-05-02 13:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:58:54 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:58:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:58:54 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:58:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:58:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:58:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:58:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:58:54 --> Final output sent to browser
DEBUG - 2011-05-02 13:58:54 --> Total execution time: 0.0618
DEBUG - 2011-05-02 13:59:17 --> Config Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:59:17 --> URI Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Router Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Output Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Input Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:59:17 --> Language Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Loader Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Controller Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Model Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Model Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Model Class Initialized
DEBUG - 2011-05-02 13:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:59:17 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:59:17 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:59:17 --> Final output sent to browser
DEBUG - 2011-05-02 13:59:17 --> Total execution time: 0.2281
DEBUG - 2011-05-02 13:59:18 --> Config Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Hooks Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Utf8 Class Initialized
DEBUG - 2011-05-02 13:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 13:59:18 --> URI Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Router Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Output Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Input Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 13:59:18 --> Language Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Loader Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Controller Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Model Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Model Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Model Class Initialized
DEBUG - 2011-05-02 13:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 13:59:18 --> Database Driver Class Initialized
DEBUG - 2011-05-02 13:59:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 13:59:18 --> Helper loaded: url_helper
DEBUG - 2011-05-02 13:59:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 13:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 13:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 13:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 13:59:18 --> Final output sent to browser
DEBUG - 2011-05-02 13:59:18 --> Total execution time: 0.0597
DEBUG - 2011-05-02 14:07:47 --> Config Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:07:47 --> URI Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Router Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Output Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Input Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:07:47 --> Language Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Loader Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Controller Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Model Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Model Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Model Class Initialized
DEBUG - 2011-05-02 14:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:07:47 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 14:07:47 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:07:47 --> Final output sent to browser
DEBUG - 2011-05-02 14:07:47 --> Total execution time: 0.1852
DEBUG - 2011-05-02 14:07:48 --> Config Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:07:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:07:48 --> URI Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Router Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Output Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Input Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:07:48 --> Language Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Loader Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Controller Class Initialized
ERROR - 2011-05-02 14:07:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:07:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:07:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:07:48 --> Model Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Model Class Initialized
DEBUG - 2011-05-02 14:07:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:07:48 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:07:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:07:48 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:07:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:07:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:07:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:07:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:07:48 --> Final output sent to browser
DEBUG - 2011-05-02 14:07:48 --> Total execution time: 0.0776
DEBUG - 2011-05-02 14:18:06 --> Config Class Initialized
DEBUG - 2011-05-02 14:18:06 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:18:06 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:18:06 --> URI Class Initialized
DEBUG - 2011-05-02 14:18:06 --> Router Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Output Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Input Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:18:07 --> Language Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Loader Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Controller Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:18:07 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:18:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 14:18:07 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:18:07 --> Final output sent to browser
DEBUG - 2011-05-02 14:18:07 --> Total execution time: 0.8779
DEBUG - 2011-05-02 14:44:33 --> Config Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:44:33 --> URI Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Router Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Output Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Input Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:44:33 --> Language Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Loader Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Controller Class Initialized
ERROR - 2011-05-02 14:44:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:44:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:44:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:44:33 --> Model Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Model Class Initialized
DEBUG - 2011-05-02 14:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:44:33 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:44:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:44:33 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:44:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:44:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:44:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:44:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:44:33 --> Final output sent to browser
DEBUG - 2011-05-02 14:44:33 --> Total execution time: 0.4396
DEBUG - 2011-05-02 14:44:35 --> Config Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:44:35 --> URI Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Router Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Output Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Input Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:44:35 --> Language Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Loader Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Controller Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Model Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Model Class Initialized
DEBUG - 2011-05-02 14:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:44:35 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:44:36 --> Final output sent to browser
DEBUG - 2011-05-02 14:44:36 --> Total execution time: 0.7520
DEBUG - 2011-05-02 14:44:37 --> Config Class Initialized
DEBUG - 2011-05-02 14:44:37 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:44:37 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:44:37 --> URI Class Initialized
DEBUG - 2011-05-02 14:44:37 --> Router Class Initialized
ERROR - 2011-05-02 14:44:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:00 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:00 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:00 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:00 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:00 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:00 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:00 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:00 --> Total execution time: 0.0679
DEBUG - 2011-05-02 14:45:01 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:01 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:01 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:01 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:02 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:02 --> Total execution time: 0.7241
DEBUG - 2011-05-02 14:45:03 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:03 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:03 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:03 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:03 --> Router Class Initialized
ERROR - 2011-05-02 14:45:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:08 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:08 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:08 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:08 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:08 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:08 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:08 --> Total execution time: 0.0464
DEBUG - 2011-05-02 14:45:08 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:08 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:08 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:08 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:09 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:09 --> Total execution time: 0.6428
DEBUG - 2011-05-02 14:45:10 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:10 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:10 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:10 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:10 --> Router Class Initialized
ERROR - 2011-05-02 14:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:19 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:19 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:19 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:19 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:19 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:19 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:19 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:19 --> Total execution time: 0.0382
DEBUG - 2011-05-02 14:45:19 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:19 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:19 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:19 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:22 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:22 --> Total execution time: 2.7092
DEBUG - 2011-05-02 14:45:23 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:23 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:23 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:23 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:23 --> Router Class Initialized
ERROR - 2011-05-02 14:45:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:31 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:31 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:31 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:31 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:31 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:31 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:31 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:31 --> Total execution time: 0.0404
DEBUG - 2011-05-02 14:45:32 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:32 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:32 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:32 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:33 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:33 --> Total execution time: 0.6428
DEBUG - 2011-05-02 14:45:34 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:34 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:34 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:34 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:34 --> Router Class Initialized
ERROR - 2011-05-02 14:45:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:41 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:41 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:41 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:41 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:41 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:41 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:41 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:41 --> Total execution time: 0.0357
DEBUG - 2011-05-02 14:45:41 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:41 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:41 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:41 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:42 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:42 --> Total execution time: 0.6542
DEBUG - 2011-05-02 14:45:43 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:43 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:43 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:43 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:43 --> Router Class Initialized
ERROR - 2011-05-02 14:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:46 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:46 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:46 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:46 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:46 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:46 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:46 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:46 --> Total execution time: 0.0274
DEBUG - 2011-05-02 14:45:47 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:47 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:47 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:47 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:47 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:47 --> Total execution time: 0.5197
DEBUG - 2011-05-02 14:45:49 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:49 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:49 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:49 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:49 --> Router Class Initialized
ERROR - 2011-05-02 14:45:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:52 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:52 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:52 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:52 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:52 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:52 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:52 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:52 --> Total execution time: 0.0488
DEBUG - 2011-05-02 14:45:53 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:53 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:53 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:53 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:54 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:54 --> Total execution time: 0.7755
DEBUG - 2011-05-02 14:45:55 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:55 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:55 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:55 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:55 --> Router Class Initialized
ERROR - 2011-05-02 14:45:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:45:58 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:58 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:58 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Controller Class Initialized
ERROR - 2011-05-02 14:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:58 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:58 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:45:58 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:45:58 --> Final output sent to browser
DEBUG - 2011-05-02 14:45:58 --> Total execution time: 0.0295
DEBUG - 2011-05-02 14:45:59 --> Config Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:45:59 --> URI Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Router Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Output Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Input Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:45:59 --> Language Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Loader Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Controller Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Model Class Initialized
DEBUG - 2011-05-02 14:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:45:59 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:46:00 --> Final output sent to browser
DEBUG - 2011-05-02 14:46:00 --> Total execution time: 1.2218
DEBUG - 2011-05-02 14:46:01 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:01 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:01 --> Router Class Initialized
ERROR - 2011-05-02 14:46:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:46:06 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:06 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:06 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:06 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Router Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Output Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Input Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:46:07 --> Language Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Loader Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Controller Class Initialized
ERROR - 2011-05-02 14:46:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:46:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:46:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:46:07 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:46:07 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:46:07 --> Final output sent to browser
DEBUG - 2011-05-02 14:46:07 --> Total execution time: 0.0820
DEBUG - 2011-05-02 14:46:07 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:07 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Router Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Output Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Input Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:46:07 --> Language Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Loader Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Controller Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:46:07 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:46:08 --> Final output sent to browser
DEBUG - 2011-05-02 14:46:08 --> Total execution time: 0.9853
DEBUG - 2011-05-02 14:46:11 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:11 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:11 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:11 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:11 --> Router Class Initialized
ERROR - 2011-05-02 14:46:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:46:17 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:17 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Router Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Output Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Input Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:46:17 --> Language Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Loader Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Controller Class Initialized
ERROR - 2011-05-02 14:46:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 14:46:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 14:46:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:46:17 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:46:17 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:46:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 14:46:17 --> Helper loaded: url_helper
DEBUG - 2011-05-02 14:46:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 14:46:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 14:46:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 14:46:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 14:46:17 --> Final output sent to browser
DEBUG - 2011-05-02 14:46:17 --> Total execution time: 0.0730
DEBUG - 2011-05-02 14:46:18 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:18 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Router Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Output Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Input Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:46:18 --> Language Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Loader Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Controller Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Model Class Initialized
DEBUG - 2011-05-02 14:46:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:46:18 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:46:19 --> Final output sent to browser
DEBUG - 2011-05-02 14:46:19 --> Total execution time: 0.6179
DEBUG - 2011-05-02 14:46:20 --> Config Class Initialized
DEBUG - 2011-05-02 14:46:20 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:46:20 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:46:20 --> URI Class Initialized
DEBUG - 2011-05-02 14:46:20 --> Router Class Initialized
ERROR - 2011-05-02 14:46:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 14:53:24 --> Config Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Hooks Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Utf8 Class Initialized
DEBUG - 2011-05-02 14:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 14:53:24 --> URI Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Router Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Output Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Input Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 14:53:24 --> Language Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Loader Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Controller Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Model Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Model Class Initialized
DEBUG - 2011-05-02 14:53:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 14:53:24 --> Database Driver Class Initialized
DEBUG - 2011-05-02 14:53:25 --> Final output sent to browser
DEBUG - 2011-05-02 14:53:25 --> Total execution time: 0.6059
DEBUG - 2011-05-02 15:44:20 --> Config Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Hooks Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Utf8 Class Initialized
DEBUG - 2011-05-02 15:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 15:44:20 --> URI Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Router Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Output Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Input Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 15:44:20 --> Language Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Loader Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Controller Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Model Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Model Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Model Class Initialized
DEBUG - 2011-05-02 15:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 15:44:21 --> Database Driver Class Initialized
DEBUG - 2011-05-02 15:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 15:44:21 --> Helper loaded: url_helper
DEBUG - 2011-05-02 15:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 15:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 15:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 15:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 15:44:21 --> Final output sent to browser
DEBUG - 2011-05-02 15:44:21 --> Total execution time: 1.6029
DEBUG - 2011-05-02 15:45:05 --> Config Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Hooks Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Utf8 Class Initialized
DEBUG - 2011-05-02 15:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 15:45:05 --> URI Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Router Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Output Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Input Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 15:45:05 --> Language Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Loader Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Controller Class Initialized
ERROR - 2011-05-02 15:45:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 15:45:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 15:45:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 15:45:05 --> Model Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Model Class Initialized
DEBUG - 2011-05-02 15:45:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 15:45:05 --> Database Driver Class Initialized
DEBUG - 2011-05-02 15:45:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 15:45:05 --> Helper loaded: url_helper
DEBUG - 2011-05-02 15:45:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 15:45:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 15:45:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 15:45:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 15:45:05 --> Final output sent to browser
DEBUG - 2011-05-02 15:45:05 --> Total execution time: 0.3105
DEBUG - 2011-05-02 16:41:29 --> Config Class Initialized
DEBUG - 2011-05-02 16:41:29 --> Hooks Class Initialized
DEBUG - 2011-05-02 16:41:29 --> Utf8 Class Initialized
DEBUG - 2011-05-02 16:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 16:41:29 --> URI Class Initialized
DEBUG - 2011-05-02 16:41:29 --> Router Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Output Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Input Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 16:41:30 --> Language Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Loader Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Controller Class Initialized
ERROR - 2011-05-02 16:41:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 16:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 16:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 16:41:30 --> Model Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Model Class Initialized
DEBUG - 2011-05-02 16:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 16:41:30 --> Database Driver Class Initialized
DEBUG - 2011-05-02 16:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 16:41:30 --> Helper loaded: url_helper
DEBUG - 2011-05-02 16:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 16:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 16:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 16:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 16:41:30 --> Final output sent to browser
DEBUG - 2011-05-02 16:41:30 --> Total execution time: 1.6516
DEBUG - 2011-05-02 16:41:31 --> Config Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Hooks Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Utf8 Class Initialized
DEBUG - 2011-05-02 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 16:41:31 --> URI Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Router Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Output Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Input Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 16:41:31 --> Language Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Loader Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Controller Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Model Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Model Class Initialized
DEBUG - 2011-05-02 16:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 16:41:31 --> Database Driver Class Initialized
DEBUG - 2011-05-02 16:41:32 --> Final output sent to browser
DEBUG - 2011-05-02 16:41:32 --> Total execution time: 0.7844
DEBUG - 2011-05-02 16:41:33 --> Config Class Initialized
DEBUG - 2011-05-02 16:41:33 --> Hooks Class Initialized
DEBUG - 2011-05-02 16:41:33 --> Utf8 Class Initialized
DEBUG - 2011-05-02 16:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 16:41:33 --> URI Class Initialized
DEBUG - 2011-05-02 16:41:33 --> Router Class Initialized
ERROR - 2011-05-02 16:41:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 17:41:01 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:01 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Router Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Output Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Input Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:41:01 --> Language Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Loader Class Initialized
DEBUG - 2011-05-02 17:41:01 --> Controller Class Initialized
ERROR - 2011-05-02 17:41:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 17:41:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 17:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:41:02 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:02 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:41:02 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:41:02 --> Helper loaded: url_helper
DEBUG - 2011-05-02 17:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 17:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 17:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 17:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 17:41:02 --> Final output sent to browser
DEBUG - 2011-05-02 17:41:02 --> Total execution time: 1.2071
DEBUG - 2011-05-02 17:41:04 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:04 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Router Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Output Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Input Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:41:04 --> Language Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Loader Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Controller Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:41:04 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:41:05 --> Final output sent to browser
DEBUG - 2011-05-02 17:41:05 --> Total execution time: 1.1281
DEBUG - 2011-05-02 17:41:07 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:07 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:07 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:07 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:07 --> Router Class Initialized
ERROR - 2011-05-02 17:41:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 17:41:08 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:08 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:08 --> Router Class Initialized
ERROR - 2011-05-02 17:41:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 17:41:08 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:08 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:08 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:08 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:08 --> Router Class Initialized
ERROR - 2011-05-02 17:41:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 17:41:42 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:42 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Router Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Output Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Input Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:41:42 --> Language Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Loader Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Controller Class Initialized
ERROR - 2011-05-02 17:41:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 17:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 17:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:41:42 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:41:42 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:41:42 --> Helper loaded: url_helper
DEBUG - 2011-05-02 17:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 17:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 17:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 17:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 17:41:42 --> Final output sent to browser
DEBUG - 2011-05-02 17:41:42 --> Total execution time: 0.0290
DEBUG - 2011-05-02 17:41:44 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:44 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Router Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Output Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Input Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:41:44 --> Language Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Loader Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Controller Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:41:44 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:41:44 --> Final output sent to browser
DEBUG - 2011-05-02 17:41:44 --> Total execution time: 0.8063
DEBUG - 2011-05-02 17:41:54 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:54 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Router Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Output Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Input Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:41:54 --> Language Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Loader Class Initialized
DEBUG - 2011-05-02 17:41:54 --> Controller Class Initialized
ERROR - 2011-05-02 17:41:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 17:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 17:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:41:54 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:55 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:41:55 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:41:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:41:55 --> Helper loaded: url_helper
DEBUG - 2011-05-02 17:41:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 17:41:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 17:41:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 17:41:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 17:41:55 --> Final output sent to browser
DEBUG - 2011-05-02 17:41:55 --> Total execution time: 0.0296
DEBUG - 2011-05-02 17:41:56 --> Config Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:41:56 --> URI Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Router Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Output Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Input Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:41:56 --> Language Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Loader Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Controller Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Model Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:41:56 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:41:56 --> Final output sent to browser
DEBUG - 2011-05-02 17:41:56 --> Total execution time: 0.6728
DEBUG - 2011-05-02 17:42:05 --> Config Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:42:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:42:05 --> URI Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Router Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Output Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Input Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:42:05 --> Language Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Loader Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Controller Class Initialized
ERROR - 2011-05-02 17:42:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 17:42:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 17:42:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:42:05 --> Model Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Model Class Initialized
DEBUG - 2011-05-02 17:42:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:42:05 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:42:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:42:05 --> Helper loaded: url_helper
DEBUG - 2011-05-02 17:42:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 17:42:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 17:42:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 17:42:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 17:42:05 --> Final output sent to browser
DEBUG - 2011-05-02 17:42:05 --> Total execution time: 0.0326
DEBUG - 2011-05-02 17:42:06 --> Config Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:42:06 --> URI Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Router Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Output Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Input Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:42:06 --> Language Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Loader Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Controller Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Model Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Model Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:42:06 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:42:06 --> Final output sent to browser
DEBUG - 2011-05-02 17:42:06 --> Total execution time: 0.7232
DEBUG - 2011-05-02 17:42:07 --> Config Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Hooks Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Utf8 Class Initialized
DEBUG - 2011-05-02 17:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 17:42:07 --> URI Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Router Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Output Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Input Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 17:42:07 --> Language Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Loader Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Controller Class Initialized
ERROR - 2011-05-02 17:42:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 17:42:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 17:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:42:07 --> Model Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Model Class Initialized
DEBUG - 2011-05-02 17:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 17:42:07 --> Database Driver Class Initialized
DEBUG - 2011-05-02 17:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 17:42:07 --> Helper loaded: url_helper
DEBUG - 2011-05-02 17:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 17:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 17:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 17:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 17:42:07 --> Final output sent to browser
DEBUG - 2011-05-02 17:42:07 --> Total execution time: 0.0272
DEBUG - 2011-05-02 18:12:15 --> Config Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Hooks Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Utf8 Class Initialized
DEBUG - 2011-05-02 18:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 18:12:15 --> URI Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Router Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Output Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Input Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 18:12:15 --> Language Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Loader Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Controller Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Model Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Model Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Model Class Initialized
DEBUG - 2011-05-02 18:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 18:12:15 --> Database Driver Class Initialized
DEBUG - 2011-05-02 18:12:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-02 18:12:15 --> Helper loaded: url_helper
DEBUG - 2011-05-02 18:12:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 18:12:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 18:12:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 18:12:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 18:12:15 --> Final output sent to browser
DEBUG - 2011-05-02 18:12:15 --> Total execution time: 0.3248
DEBUG - 2011-05-02 18:12:32 --> Config Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Hooks Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Utf8 Class Initialized
DEBUG - 2011-05-02 18:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 18:12:32 --> URI Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Router Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Output Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Input Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 18:12:32 --> Language Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Loader Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Controller Class Initialized
ERROR - 2011-05-02 18:12:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 18:12:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 18:12:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 18:12:32 --> Model Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Model Class Initialized
DEBUG - 2011-05-02 18:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 18:12:32 --> Database Driver Class Initialized
DEBUG - 2011-05-02 18:12:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 18:12:32 --> Helper loaded: url_helper
DEBUG - 2011-05-02 18:12:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 18:12:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 18:12:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 18:12:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 18:12:32 --> Final output sent to browser
DEBUG - 2011-05-02 18:12:32 --> Total execution time: 0.0502
DEBUG - 2011-05-02 20:45:33 --> Config Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Hooks Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Utf8 Class Initialized
DEBUG - 2011-05-02 20:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 20:45:33 --> URI Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Router Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Output Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Input Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 20:45:33 --> Language Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Loader Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Controller Class Initialized
ERROR - 2011-05-02 20:45:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 20:45:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 20:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 20:45:33 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 20:45:33 --> Database Driver Class Initialized
DEBUG - 2011-05-02 20:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 20:45:34 --> Helper loaded: url_helper
DEBUG - 2011-05-02 20:45:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 20:45:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 20:45:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 20:45:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 20:45:34 --> Final output sent to browser
DEBUG - 2011-05-02 20:45:34 --> Total execution time: 0.3413
DEBUG - 2011-05-02 20:45:34 --> Config Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Hooks Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Utf8 Class Initialized
DEBUG - 2011-05-02 20:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 20:45:34 --> URI Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Router Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Output Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Input Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 20:45:34 --> Language Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Loader Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Controller Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 20:45:34 --> Database Driver Class Initialized
DEBUG - 2011-05-02 20:45:35 --> Final output sent to browser
DEBUG - 2011-05-02 20:45:35 --> Total execution time: 0.6131
DEBUG - 2011-05-02 20:45:36 --> Config Class Initialized
DEBUG - 2011-05-02 20:45:36 --> Hooks Class Initialized
DEBUG - 2011-05-02 20:45:36 --> Utf8 Class Initialized
DEBUG - 2011-05-02 20:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 20:45:36 --> URI Class Initialized
DEBUG - 2011-05-02 20:45:36 --> Router Class Initialized
ERROR - 2011-05-02 20:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 20:45:38 --> Config Class Initialized
DEBUG - 2011-05-02 20:45:38 --> Hooks Class Initialized
DEBUG - 2011-05-02 20:45:38 --> Utf8 Class Initialized
DEBUG - 2011-05-02 20:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 20:45:38 --> URI Class Initialized
DEBUG - 2011-05-02 20:45:38 --> Router Class Initialized
ERROR - 2011-05-02 20:45:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-02 20:45:58 --> Config Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Hooks Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Utf8 Class Initialized
DEBUG - 2011-05-02 20:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 20:45:58 --> URI Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Router Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Output Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Input Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 20:45:58 --> Language Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Loader Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Controller Class Initialized
ERROR - 2011-05-02 20:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-02 20:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-02 20:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 20:45:58 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 20:45:58 --> Database Driver Class Initialized
DEBUG - 2011-05-02 20:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-02 20:45:58 --> Helper loaded: url_helper
DEBUG - 2011-05-02 20:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-02 20:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-02 20:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-02 20:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-02 20:45:58 --> Final output sent to browser
DEBUG - 2011-05-02 20:45:58 --> Total execution time: 0.0302
DEBUG - 2011-05-02 20:45:59 --> Config Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Hooks Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Utf8 Class Initialized
DEBUG - 2011-05-02 20:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-02 20:45:59 --> URI Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Router Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Output Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Input Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-02 20:45:59 --> Language Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Loader Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Controller Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Model Class Initialized
DEBUG - 2011-05-02 20:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-02 20:45:59 --> Database Driver Class Initialized
DEBUG - 2011-05-02 20:46:00 --> Final output sent to browser
DEBUG - 2011-05-02 20:46:00 --> Total execution time: 0.9593

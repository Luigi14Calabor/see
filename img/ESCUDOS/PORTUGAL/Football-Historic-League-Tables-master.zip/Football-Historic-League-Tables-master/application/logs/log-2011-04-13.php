<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-13 00:27:51 --> Config Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 00:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 00:27:51 --> URI Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Router Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Output Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Input Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 00:27:51 --> Language Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Loader Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Controller Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Model Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Model Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Model Class Initialized
DEBUG - 2011-04-13 00:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 00:27:51 --> Database Driver Class Initialized
DEBUG - 2011-04-13 00:27:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 00:27:51 --> Helper loaded: url_helper
DEBUG - 2011-04-13 00:27:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 00:27:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 00:27:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 00:27:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 00:27:51 --> Final output sent to browser
DEBUG - 2011-04-13 00:27:51 --> Total execution time: 0.4079
DEBUG - 2011-04-13 02:06:53 --> Config Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:06:53 --> URI Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Router Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Output Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Input Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 02:06:53 --> Language Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Loader Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Controller Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Model Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Model Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Model Class Initialized
DEBUG - 2011-04-13 02:06:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 02:06:53 --> Database Driver Class Initialized
DEBUG - 2011-04-13 02:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 02:07:01 --> Helper loaded: url_helper
DEBUG - 2011-04-13 02:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 02:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 02:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 02:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 02:07:01 --> Final output sent to browser
DEBUG - 2011-04-13 02:07:01 --> Total execution time: 8.0993
DEBUG - 2011-04-13 02:19:41 --> Config Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:19:41 --> URI Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Router Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Output Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Input Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 02:19:41 --> Language Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Loader Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Controller Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 02:19:41 --> Database Driver Class Initialized
DEBUG - 2011-04-13 02:19:52 --> Config Class Initialized
DEBUG - 2011-04-13 02:19:52 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:19:52 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:19:52 --> URI Class Initialized
DEBUG - 2011-04-13 02:19:52 --> Router Class Initialized
DEBUG - 2011-04-13 02:19:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 02:19:54 --> Output Class Initialized
DEBUG - 2011-04-13 02:19:54 --> Input Class Initialized
DEBUG - 2011-04-13 02:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 02:19:54 --> Language Class Initialized
DEBUG - 2011-04-13 02:19:55 --> Loader Class Initialized
DEBUG - 2011-04-13 02:19:55 --> Controller Class Initialized
ERROR - 2011-04-13 02:19:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 02:19:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 02:19:56 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:56 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 02:19:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 02:19:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 02:19:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 02:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 02:19:56 --> Final output sent to browser
DEBUG - 2011-04-13 02:19:56 --> Total execution time: 15.4833
DEBUG - 2011-04-13 02:19:56 --> Final output sent to browser
DEBUG - 2011-04-13 02:19:56 --> Total execution time: 3.5405
DEBUG - 2011-04-13 02:19:57 --> Config Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:19:57 --> URI Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Router Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Output Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Input Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 02:19:57 --> Language Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Loader Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Controller Class Initialized
ERROR - 2011-04-13 02:19:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 02:19:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 02:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 02:19:57 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Model Class Initialized
DEBUG - 2011-04-13 02:19:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 02:19:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 02:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 02:19:57 --> Helper loaded: url_helper
DEBUG - 2011-04-13 02:19:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 02:19:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 02:19:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 02:19:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 02:19:57 --> Final output sent to browser
DEBUG - 2011-04-13 02:19:57 --> Total execution time: 0.0476
DEBUG - 2011-04-13 02:20:04 --> Config Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:20:04 --> URI Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Router Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Output Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Input Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 02:20:04 --> Language Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Loader Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Controller Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Model Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Model Class Initialized
DEBUG - 2011-04-13 02:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 02:20:04 --> Database Driver Class Initialized
DEBUG - 2011-04-13 02:20:05 --> Final output sent to browser
DEBUG - 2011-04-13 02:20:05 --> Total execution time: 1.5432
DEBUG - 2011-04-13 02:20:17 --> Config Class Initialized
DEBUG - 2011-04-13 02:20:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:20:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:20:17 --> URI Class Initialized
DEBUG - 2011-04-13 02:20:17 --> Router Class Initialized
ERROR - 2011-04-13 02:20:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 02:21:35 --> Config Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 02:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 02:21:35 --> URI Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Router Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Output Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Input Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 02:21:35 --> Language Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Loader Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Controller Class Initialized
ERROR - 2011-04-13 02:21:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 02:21:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 02:21:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 02:21:35 --> Model Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Model Class Initialized
DEBUG - 2011-04-13 02:21:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 02:21:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 02:21:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 02:21:35 --> Helper loaded: url_helper
DEBUG - 2011-04-13 02:21:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 02:21:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 02:21:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 02:21:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 02:21:35 --> Final output sent to browser
DEBUG - 2011-04-13 02:21:35 --> Total execution time: 0.0381
DEBUG - 2011-04-13 04:18:42 --> Config Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:18:42 --> URI Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Router Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Output Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Input Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:18:42 --> Language Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Loader Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Controller Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Model Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Model Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Model Class Initialized
DEBUG - 2011-04-13 04:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:18:42 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:18:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 04:18:43 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:18:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:18:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:18:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:18:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:18:43 --> Final output sent to browser
DEBUG - 2011-04-13 04:18:43 --> Total execution time: 1.9081
DEBUG - 2011-04-13 04:18:44 --> Config Class Initialized
DEBUG - 2011-04-13 04:18:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:18:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:18:44 --> URI Class Initialized
DEBUG - 2011-04-13 04:18:44 --> Router Class Initialized
DEBUG - 2011-04-13 04:18:46 --> Output Class Initialized
DEBUG - 2011-04-13 04:18:46 --> Input Class Initialized
DEBUG - 2011-04-13 04:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:18:46 --> Language Class Initialized
DEBUG - 2011-04-13 04:18:46 --> Loader Class Initialized
DEBUG - 2011-04-13 04:18:46 --> Controller Class Initialized
ERROR - 2011-04-13 04:18:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:18:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:18:48 --> Model Class Initialized
DEBUG - 2011-04-13 04:18:48 --> Model Class Initialized
DEBUG - 2011-04-13 04:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:18:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:18:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:18:48 --> Final output sent to browser
DEBUG - 2011-04-13 04:18:48 --> Total execution time: 4.1058
DEBUG - 2011-04-13 04:36:38 --> Config Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:36:38 --> URI Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Router Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Output Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Input Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:36:38 --> Language Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Loader Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Controller Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Model Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Model Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Model Class Initialized
DEBUG - 2011-04-13 04:36:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:36:38 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:36:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 04:36:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:36:38 --> Final output sent to browser
DEBUG - 2011-04-13 04:36:38 --> Total execution time: 0.7264
DEBUG - 2011-04-13 04:36:42 --> Config Class Initialized
DEBUG - 2011-04-13 04:36:42 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:36:42 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:36:42 --> URI Class Initialized
DEBUG - 2011-04-13 04:36:42 --> Router Class Initialized
ERROR - 2011-04-13 04:36:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:36:44 --> Config Class Initialized
DEBUG - 2011-04-13 04:36:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:36:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:36:44 --> URI Class Initialized
DEBUG - 2011-04-13 04:36:44 --> Router Class Initialized
ERROR - 2011-04-13 04:36:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:41:13 --> Config Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:41:13 --> URI Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Router Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Output Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Input Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:41:13 --> Language Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Loader Class Initialized
DEBUG - 2011-04-13 04:41:13 --> Controller Class Initialized
ERROR - 2011-04-13 04:41:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:41:14 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:14 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:41:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:41:15 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:41:16 --> Final output sent to browser
DEBUG - 2011-04-13 04:41:16 --> Total execution time: 2.8015
DEBUG - 2011-04-13 04:41:17 --> Config Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:41:17 --> URI Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Router Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Output Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Input Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:41:17 --> Language Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Loader Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Controller Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:41:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:41:18 --> Final output sent to browser
DEBUG - 2011-04-13 04:41:18 --> Total execution time: 1.0369
DEBUG - 2011-04-13 04:41:20 --> Config Class Initialized
DEBUG - 2011-04-13 04:41:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:41:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:41:20 --> URI Class Initialized
DEBUG - 2011-04-13 04:41:20 --> Router Class Initialized
ERROR - 2011-04-13 04:41:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:41:43 --> Config Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:41:43 --> URI Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Router Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Output Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Input Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:41:43 --> Language Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Loader Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Controller Class Initialized
ERROR - 2011-04-13 04:41:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:41:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:41:43 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:41:43 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:41:43 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:41:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:41:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:41:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:41:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:41:43 --> Final output sent to browser
DEBUG - 2011-04-13 04:41:43 --> Total execution time: 0.0308
DEBUG - 2011-04-13 04:41:44 --> Config Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:41:44 --> URI Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Router Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Output Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Input Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:41:44 --> Language Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Loader Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Controller Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Model Class Initialized
DEBUG - 2011-04-13 04:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:41:44 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:41:46 --> Final output sent to browser
DEBUG - 2011-04-13 04:41:46 --> Total execution time: 1.7050
DEBUG - 2011-04-13 04:41:47 --> Config Class Initialized
DEBUG - 2011-04-13 04:41:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:41:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:41:47 --> URI Class Initialized
DEBUG - 2011-04-13 04:41:47 --> Router Class Initialized
ERROR - 2011-04-13 04:41:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:42:07 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:07 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:07 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Controller Class Initialized
ERROR - 2011-04-13 04:42:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:42:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:07 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:07 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:42:07 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:07 --> Total execution time: 0.0307
DEBUG - 2011-04-13 04:42:08 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:08 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:08 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Controller Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:08 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:09 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:09 --> Total execution time: 1.0106
DEBUG - 2011-04-13 04:42:11 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:11 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:11 --> Router Class Initialized
ERROR - 2011-04-13 04:42:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:42:23 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:23 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:23 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Controller Class Initialized
ERROR - 2011-04-13 04:42:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:42:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:23 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:23 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:23 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:42:23 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:23 --> Total execution time: 0.0281
DEBUG - 2011-04-13 04:42:24 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:24 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:24 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Controller Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:25 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:25 --> Total execution time: 0.5106
DEBUG - 2011-04-13 04:42:26 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:26 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:26 --> Router Class Initialized
ERROR - 2011-04-13 04:42:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:42:33 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:33 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:33 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Controller Class Initialized
ERROR - 2011-04-13 04:42:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:42:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:42:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:33 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:33 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:33 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:42:33 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:33 --> Total execution time: 0.0417
DEBUG - 2011-04-13 04:42:34 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:34 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:34 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Controller Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:35 --> Total execution time: 0.6393
DEBUG - 2011-04-13 04:42:35 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:35 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:35 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Controller Class Initialized
ERROR - 2011-04-13 04:42:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:42:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:42:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:35 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:35 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:42:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:42:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:42:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:42:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:42:35 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:35 --> Total execution time: 0.0423
DEBUG - 2011-04-13 04:42:38 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:38 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:38 --> Router Class Initialized
ERROR - 2011-04-13 04:42:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:42:48 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:48 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:48 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Controller Class Initialized
ERROR - 2011-04-13 04:42:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:42:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:42:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:48 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:42:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:42:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:42:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:42:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:42:48 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:48 --> Total execution time: 0.0331
DEBUG - 2011-04-13 04:42:49 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:49 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:49 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Controller Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:50 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:50 --> Total execution time: 1.0652
DEBUG - 2011-04-13 04:42:51 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:51 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:51 --> Router Class Initialized
ERROR - 2011-04-13 04:42:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:42:58 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:58 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:58 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Controller Class Initialized
ERROR - 2011-04-13 04:42:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:42:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:58 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:58 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:42:58 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:42:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:42:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:42:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:42:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:42:58 --> Final output sent to browser
DEBUG - 2011-04-13 04:42:58 --> Total execution time: 0.0297
DEBUG - 2011-04-13 04:42:59 --> Config Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:42:59 --> URI Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Router Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Output Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Input Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:42:59 --> Language Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Loader Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Controller Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Model Class Initialized
DEBUG - 2011-04-13 04:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:42:59 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:00 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:00 --> Total execution time: 1.0609
DEBUG - 2011-04-13 04:43:01 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:01 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:01 --> Router Class Initialized
ERROR - 2011-04-13 04:43:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:43:12 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:12 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Router Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Output Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Input Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:43:12 --> Language Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Loader Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Controller Class Initialized
ERROR - 2011-04-13 04:43:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:43:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:43:12 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:43:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:43:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:43:12 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:12 --> Total execution time: 0.0268
DEBUG - 2011-04-13 04:43:14 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:14 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Router Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Output Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Input Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:43:14 --> Language Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Loader Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Controller Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:43:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:16 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:16 --> Total execution time: 2.1781
DEBUG - 2011-04-13 04:43:17 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:17 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:17 --> Router Class Initialized
ERROR - 2011-04-13 04:43:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:43:34 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:34 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Router Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Output Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Input Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:43:34 --> Language Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Loader Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Controller Class Initialized
ERROR - 2011-04-13 04:43:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:43:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:43:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:43:34 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:43:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:43:34 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:43:34 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:34 --> Total execution time: 0.0308
DEBUG - 2011-04-13 04:43:35 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:35 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Router Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Output Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Input Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:43:35 --> Language Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Loader Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Controller Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:43:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:35 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:35 --> Total execution time: 0.4954
DEBUG - 2011-04-13 04:43:37 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:37 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:37 --> Router Class Initialized
ERROR - 2011-04-13 04:43:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:43:55 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:55 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Router Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Output Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Input Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:43:55 --> Language Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Loader Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Controller Class Initialized
ERROR - 2011-04-13 04:43:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:43:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:43:55 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:43:55 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:43:55 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:43:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:43:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:43:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:43:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:43:55 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:55 --> Total execution time: 0.0351
DEBUG - 2011-04-13 04:43:56 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:56 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Router Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Output Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Input Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:43:56 --> Language Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Loader Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Controller Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Model Class Initialized
DEBUG - 2011-04-13 04:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:43:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:43:57 --> Final output sent to browser
DEBUG - 2011-04-13 04:43:57 --> Total execution time: 1.3400
DEBUG - 2011-04-13 04:43:59 --> Config Class Initialized
DEBUG - 2011-04-13 04:43:59 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:43:59 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:43:59 --> URI Class Initialized
DEBUG - 2011-04-13 04:43:59 --> Router Class Initialized
ERROR - 2011-04-13 04:43:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:44:27 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:27 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Router Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Output Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Input Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:44:27 --> Language Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Loader Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Controller Class Initialized
ERROR - 2011-04-13 04:44:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:44:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:44:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:44:27 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:44:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:44:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:44:27 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:44:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:44:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:44:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:44:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:44:27 --> Final output sent to browser
DEBUG - 2011-04-13 04:44:27 --> Total execution time: 0.1853
DEBUG - 2011-04-13 04:44:29 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:29 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Router Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Output Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Input Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:44:29 --> Language Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Loader Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Controller Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:44:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:44:29 --> Final output sent to browser
DEBUG - 2011-04-13 04:44:29 --> Total execution time: 0.5844
DEBUG - 2011-04-13 04:44:31 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:31 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:31 --> Router Class Initialized
ERROR - 2011-04-13 04:44:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:44:38 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:38 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Router Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Output Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Input Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:44:38 --> Language Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Loader Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Controller Class Initialized
ERROR - 2011-04-13 04:44:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:44:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:44:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:44:38 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:44:38 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:44:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:44:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:44:38 --> Final output sent to browser
DEBUG - 2011-04-13 04:44:38 --> Total execution time: 0.0307
DEBUG - 2011-04-13 04:44:39 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:39 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Router Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Output Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Input Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:44:39 --> Language Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Loader Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Controller Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:44:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:44:40 --> Final output sent to browser
DEBUG - 2011-04-13 04:44:40 --> Total execution time: 0.5945
DEBUG - 2011-04-13 04:44:41 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:41 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:41 --> Router Class Initialized
ERROR - 2011-04-13 04:44:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:44:44 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:44 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Router Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Output Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Input Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:44:44 --> Language Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Loader Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Controller Class Initialized
ERROR - 2011-04-13 04:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 04:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 04:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:44:44 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:44:44 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 04:44:44 --> Helper loaded: url_helper
DEBUG - 2011-04-13 04:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 04:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 04:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 04:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 04:44:44 --> Final output sent to browser
DEBUG - 2011-04-13 04:44:44 --> Total execution time: 0.0286
DEBUG - 2011-04-13 04:44:45 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:45 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Router Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Output Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Input Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 04:44:45 --> Language Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Loader Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Controller Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Model Class Initialized
DEBUG - 2011-04-13 04:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 04:44:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 04:44:46 --> Final output sent to browser
DEBUG - 2011-04-13 04:44:46 --> Total execution time: 0.5066
DEBUG - 2011-04-13 04:44:47 --> Config Class Initialized
DEBUG - 2011-04-13 04:44:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:44:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:44:47 --> URI Class Initialized
DEBUG - 2011-04-13 04:44:47 --> Router Class Initialized
ERROR - 2011-04-13 04:44:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 04:48:26 --> Config Class Initialized
DEBUG - 2011-04-13 04:48:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 04:48:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 04:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 04:48:26 --> URI Class Initialized
DEBUG - 2011-04-13 04:48:26 --> Router Class Initialized
ERROR - 2011-04-13 04:48:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 05:58:45 --> Config Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:58:45 --> URI Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Router Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Output Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Input Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 05:58:45 --> Language Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Loader Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Controller Class Initialized
ERROR - 2011-04-13 05:58:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 05:58:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 05:58:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 05:58:45 --> Model Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Model Class Initialized
DEBUG - 2011-04-13 05:58:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 05:58:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 05:58:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 05:58:45 --> Helper loaded: url_helper
DEBUG - 2011-04-13 05:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 05:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 05:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 05:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 05:58:46 --> Final output sent to browser
DEBUG - 2011-04-13 05:58:46 --> Total execution time: 0.7099
DEBUG - 2011-04-13 05:58:50 --> Config Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:58:50 --> URI Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Router Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Output Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Input Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 05:58:50 --> Language Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Loader Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Controller Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Model Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Model Class Initialized
DEBUG - 2011-04-13 05:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 05:58:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 05:58:51 --> Final output sent to browser
DEBUG - 2011-04-13 05:58:51 --> Total execution time: 1.0638
DEBUG - 2011-04-13 05:58:53 --> Config Class Initialized
DEBUG - 2011-04-13 05:58:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:58:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:58:53 --> URI Class Initialized
DEBUG - 2011-04-13 05:58:53 --> Router Class Initialized
ERROR - 2011-04-13 05:58:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 05:58:55 --> Config Class Initialized
DEBUG - 2011-04-13 05:58:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:58:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:58:55 --> URI Class Initialized
DEBUG - 2011-04-13 05:58:55 --> Router Class Initialized
ERROR - 2011-04-13 05:58:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 05:59:44 --> Config Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:59:44 --> URI Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Router Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Output Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Input Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 05:59:44 --> Language Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Loader Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Controller Class Initialized
ERROR - 2011-04-13 05:59:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 05:59:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 05:59:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 05:59:44 --> Model Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Model Class Initialized
DEBUG - 2011-04-13 05:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 05:59:44 --> Database Driver Class Initialized
DEBUG - 2011-04-13 05:59:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 05:59:44 --> Helper loaded: url_helper
DEBUG - 2011-04-13 05:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 05:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 05:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 05:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 05:59:44 --> Final output sent to browser
DEBUG - 2011-04-13 05:59:44 --> Total execution time: 0.2359
DEBUG - 2011-04-13 05:59:46 --> Config Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:59:46 --> URI Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Router Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Output Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Input Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 05:59:46 --> Language Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Loader Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Controller Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Model Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Model Class Initialized
DEBUG - 2011-04-13 05:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 05:59:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 05:59:49 --> Final output sent to browser
DEBUG - 2011-04-13 05:59:49 --> Total execution time: 2.6608
DEBUG - 2011-04-13 05:59:52 --> Config Class Initialized
DEBUG - 2011-04-13 05:59:52 --> Hooks Class Initialized
DEBUG - 2011-04-13 05:59:52 --> Utf8 Class Initialized
DEBUG - 2011-04-13 05:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 05:59:52 --> URI Class Initialized
DEBUG - 2011-04-13 05:59:52 --> Router Class Initialized
ERROR - 2011-04-13 05:59:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:00:17 --> Config Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:00:17 --> URI Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Router Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Output Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Input Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:00:17 --> Language Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Loader Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Controller Class Initialized
ERROR - 2011-04-13 06:00:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:00:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:00:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:00:17 --> Model Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Model Class Initialized
DEBUG - 2011-04-13 06:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:00:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:00:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:00:17 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:00:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:00:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:00:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:00:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:00:17 --> Final output sent to browser
DEBUG - 2011-04-13 06:00:17 --> Total execution time: 0.0625
DEBUG - 2011-04-13 06:00:20 --> Config Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:00:20 --> URI Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Router Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Output Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Input Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:00:20 --> Language Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Loader Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Controller Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Model Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Model Class Initialized
DEBUG - 2011-04-13 06:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:00:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:00:21 --> Final output sent to browser
DEBUG - 2011-04-13 06:00:21 --> Total execution time: 0.9954
DEBUG - 2011-04-13 06:00:25 --> Config Class Initialized
DEBUG - 2011-04-13 06:00:25 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:00:25 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:00:25 --> URI Class Initialized
DEBUG - 2011-04-13 06:00:25 --> Router Class Initialized
ERROR - 2011-04-13 06:00:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:01:03 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:03 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Router Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Output Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Input Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:01:03 --> Language Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Loader Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Controller Class Initialized
ERROR - 2011-04-13 06:01:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:01:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:01:03 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:01:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:01:03 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:01:03 --> Final output sent to browser
DEBUG - 2011-04-13 06:01:03 --> Total execution time: 0.0425
DEBUG - 2011-04-13 06:01:06 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:06 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Router Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Output Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Input Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:01:06 --> Language Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Loader Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Controller Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:01:06 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:01:07 --> Final output sent to browser
DEBUG - 2011-04-13 06:01:07 --> Total execution time: 1.6422
DEBUG - 2011-04-13 06:01:11 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:11 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:11 --> Router Class Initialized
ERROR - 2011-04-13 06:01:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:01:14 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:14 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Router Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Output Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Input Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:01:14 --> Language Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Loader Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Controller Class Initialized
ERROR - 2011-04-13 06:01:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:01:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:01:14 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:01:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:01:14 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:01:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:01:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:01:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:01:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:01:14 --> Final output sent to browser
DEBUG - 2011-04-13 06:01:14 --> Total execution time: 0.0405
DEBUG - 2011-04-13 06:01:17 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:17 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Router Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Output Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Input Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:01:17 --> Language Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Loader Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Controller Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:01:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:01:19 --> Final output sent to browser
DEBUG - 2011-04-13 06:01:19 --> Total execution time: 1.9913
DEBUG - 2011-04-13 06:01:22 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:22 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:22 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:22 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:22 --> Router Class Initialized
ERROR - 2011-04-13 06:01:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:01:35 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:35 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Router Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Output Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Input Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:01:35 --> Language Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Loader Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Controller Class Initialized
ERROR - 2011-04-13 06:01:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:01:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:01:35 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:01:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:01:35 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:01:35 --> Final output sent to browser
DEBUG - 2011-04-13 06:01:35 --> Total execution time: 0.1172
DEBUG - 2011-04-13 06:01:37 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:37 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Router Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Output Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Input Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:01:37 --> Language Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Loader Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Controller Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Model Class Initialized
DEBUG - 2011-04-13 06:01:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:01:37 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:01:38 --> Final output sent to browser
DEBUG - 2011-04-13 06:01:38 --> Total execution time: 0.6403
DEBUG - 2011-04-13 06:01:41 --> Config Class Initialized
DEBUG - 2011-04-13 06:01:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:01:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:01:41 --> URI Class Initialized
DEBUG - 2011-04-13 06:01:41 --> Router Class Initialized
ERROR - 2011-04-13 06:01:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:02:19 --> Config Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:02:19 --> URI Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Router Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Output Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Input Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:02:19 --> Language Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Loader Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Controller Class Initialized
ERROR - 2011-04-13 06:02:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 06:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:02:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:02:19 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:02:19 --> Final output sent to browser
DEBUG - 2011-04-13 06:02:19 --> Total execution time: 0.0352
DEBUG - 2011-04-13 06:02:25 --> Config Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:02:25 --> URI Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Router Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Output Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Input Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:02:25 --> Language Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Loader Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Controller Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Model Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Model Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:02:25 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:02:25 --> Final output sent to browser
DEBUG - 2011-04-13 06:02:25 --> Total execution time: 0.5980
DEBUG - 2011-04-13 06:02:29 --> Config Class Initialized
DEBUG - 2011-04-13 06:02:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:02:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:02:29 --> URI Class Initialized
DEBUG - 2011-04-13 06:02:29 --> Router Class Initialized
ERROR - 2011-04-13 06:02:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:30:28 --> Config Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:30:29 --> URI Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Router Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Output Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Input Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:30:29 --> Language Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Loader Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Controller Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Model Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Model Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Model Class Initialized
DEBUG - 2011-04-13 06:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:30:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 06:30:31 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:30:31 --> Final output sent to browser
DEBUG - 2011-04-13 06:30:31 --> Total execution time: 2.8353
DEBUG - 2011-04-13 06:35:41 --> Config Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:35:41 --> URI Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Router Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Output Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Input Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:35:41 --> Language Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Loader Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Controller Class Initialized
ERROR - 2011-04-13 06:35:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:35:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:35:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:35:41 --> Model Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Model Class Initialized
DEBUG - 2011-04-13 06:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:35:41 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:35:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:35:41 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:35:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:35:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:35:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:35:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:35:41 --> Final output sent to browser
DEBUG - 2011-04-13 06:35:41 --> Total execution time: 0.1379
DEBUG - 2011-04-13 06:35:43 --> Config Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:35:43 --> URI Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Router Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Output Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Input Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:35:43 --> Language Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Loader Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Controller Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Model Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Model Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:35:43 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:35:43 --> Final output sent to browser
DEBUG - 2011-04-13 06:35:43 --> Total execution time: 0.6478
DEBUG - 2011-04-13 06:35:45 --> Config Class Initialized
DEBUG - 2011-04-13 06:35:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:35:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:35:45 --> URI Class Initialized
DEBUG - 2011-04-13 06:35:45 --> Router Class Initialized
ERROR - 2011-04-13 06:35:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 06:36:03 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:03 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:03 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Controller Class Initialized
ERROR - 2011-04-13 06:36:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:36:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:36:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:03 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:03 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:36:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:36:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:36:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:36:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:36:03 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:03 --> Total execution time: 0.0390
DEBUG - 2011-04-13 06:36:04 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:04 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:04 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Controller Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:04 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:05 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:05 --> Total execution time: 0.5497
DEBUG - 2011-04-13 06:36:10 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:10 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:10 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Controller Class Initialized
ERROR - 2011-04-13 06:36:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:36:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:10 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:10 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:10 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:36:10 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:10 --> Total execution time: 0.0408
DEBUG - 2011-04-13 06:36:11 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:11 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:11 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Controller Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:11 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:12 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:12 --> Total execution time: 0.5976
DEBUG - 2011-04-13 06:36:26 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:26 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:26 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Controller Class Initialized
ERROR - 2011-04-13 06:36:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:36:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:36:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:26 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:26 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:26 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:36:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:36:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:36:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:36:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:36:26 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:26 --> Total execution time: 0.0529
DEBUG - 2011-04-13 06:36:27 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:27 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:27 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Controller Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:27 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:27 --> Total execution time: 0.5087
DEBUG - 2011-04-13 06:36:38 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:38 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:38 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Controller Class Initialized
ERROR - 2011-04-13 06:36:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:36:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:36:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:38 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:38 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:36:38 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:38 --> Total execution time: 0.0878
DEBUG - 2011-04-13 06:36:39 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:39 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:39 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Controller Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:39 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:39 --> Total execution time: 0.6468
DEBUG - 2011-04-13 06:36:47 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:47 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:47 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Controller Class Initialized
ERROR - 2011-04-13 06:36:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:36:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:47 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:36:47 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:36:47 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:47 --> Total execution time: 0.0286
DEBUG - 2011-04-13 06:36:48 --> Config Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:36:48 --> URI Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Router Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Output Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Input Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:36:48 --> Language Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Loader Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Controller Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Model Class Initialized
DEBUG - 2011-04-13 06:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:36:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:36:49 --> Final output sent to browser
DEBUG - 2011-04-13 06:36:49 --> Total execution time: 0.5613
DEBUG - 2011-04-13 06:37:04 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:04 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:04 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Controller Class Initialized
ERROR - 2011-04-13 06:37:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:37:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:04 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:04 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:04 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:37:04 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:04 --> Total execution time: 0.0316
DEBUG - 2011-04-13 06:37:05 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:05 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:05 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Controller Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:05 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:06 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:06 --> Total execution time: 0.6398
DEBUG - 2011-04-13 06:37:13 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:13 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:13 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Controller Class Initialized
ERROR - 2011-04-13 06:37:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:37:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:37:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:13 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:13 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:13 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:37:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:37:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:37:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:37:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:37:13 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:13 --> Total execution time: 0.0469
DEBUG - 2011-04-13 06:37:14 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:14 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:14 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Controller Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:14 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:14 --> Total execution time: 0.7599
DEBUG - 2011-04-13 06:37:20 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:20 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:20 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Controller Class Initialized
ERROR - 2011-04-13 06:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:20 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:20 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:37:20 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:20 --> Total execution time: 0.0292
DEBUG - 2011-04-13 06:37:21 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:21 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:21 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Controller Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:22 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:22 --> Total execution time: 0.5846
DEBUG - 2011-04-13 06:37:24 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:24 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:24 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Controller Class Initialized
ERROR - 2011-04-13 06:37:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:37:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:24 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:24 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:37:24 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:24 --> Total execution time: 0.0364
DEBUG - 2011-04-13 06:37:25 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:25 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:25 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Controller Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:25 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:26 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:26 --> Total execution time: 0.9525
DEBUG - 2011-04-13 06:37:31 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:31 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:31 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Controller Class Initialized
ERROR - 2011-04-13 06:37:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:37:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:37:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:31 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:31 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:31 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:37:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:37:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:37:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:37:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:37:31 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:31 --> Total execution time: 0.1870
DEBUG - 2011-04-13 06:37:32 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:32 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:32 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Controller Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:32 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:32 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:32 --> Total execution time: 0.5661
DEBUG - 2011-04-13 06:37:43 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:43 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:43 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Controller Class Initialized
ERROR - 2011-04-13 06:37:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:37:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:37:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:43 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:43 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:37:43 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:37:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:37:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:37:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:37:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:37:43 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:43 --> Total execution time: 0.0277
DEBUG - 2011-04-13 06:37:44 --> Config Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:37:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:37:44 --> URI Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Router Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Output Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Input Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:37:44 --> Language Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Loader Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Controller Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Model Class Initialized
DEBUG - 2011-04-13 06:37:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:37:44 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:37:45 --> Final output sent to browser
DEBUG - 2011-04-13 06:37:45 --> Total execution time: 0.5241
DEBUG - 2011-04-13 06:38:12 --> Config Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:38:12 --> URI Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Router Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Output Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Input Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:38:12 --> Language Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Loader Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Controller Class Initialized
ERROR - 2011-04-13 06:38:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 06:38:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 06:38:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:38:12 --> Model Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Model Class Initialized
DEBUG - 2011-04-13 06:38:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:38:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:38:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 06:38:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 06:38:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 06:38:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 06:38:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 06:38:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 06:38:12 --> Final output sent to browser
DEBUG - 2011-04-13 06:38:12 --> Total execution time: 0.0564
DEBUG - 2011-04-13 06:38:13 --> Config Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 06:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 06:38:13 --> URI Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Router Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Output Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Input Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 06:38:13 --> Language Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Loader Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Controller Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Model Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Model Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 06:38:13 --> Database Driver Class Initialized
DEBUG - 2011-04-13 06:38:13 --> Final output sent to browser
DEBUG - 2011-04-13 06:38:13 --> Total execution time: 0.6801
DEBUG - 2011-04-13 07:02:29 --> Config Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:02:29 --> URI Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Router Class Initialized
DEBUG - 2011-04-13 07:02:29 --> No URI present. Default controller set.
DEBUG - 2011-04-13 07:02:29 --> Output Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Input Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:02:29 --> Language Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Loader Class Initialized
DEBUG - 2011-04-13 07:02:29 --> Controller Class Initialized
DEBUG - 2011-04-13 07:02:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 07:02:29 --> Helper loaded: url_helper
DEBUG - 2011-04-13 07:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 07:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 07:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 07:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 07:02:29 --> Final output sent to browser
DEBUG - 2011-04-13 07:02:29 --> Total execution time: 0.2488
DEBUG - 2011-04-13 07:02:44 --> Config Class Initialized
DEBUG - 2011-04-13 07:02:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:02:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:02:44 --> URI Class Initialized
DEBUG - 2011-04-13 07:02:44 --> Router Class Initialized
ERROR - 2011-04-13 07:02:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 07:03:10 --> Config Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:03:10 --> URI Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Router Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Output Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Input Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:03:10 --> Language Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Loader Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Controller Class Initialized
ERROR - 2011-04-13 07:03:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 07:03:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 07:03:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 07:03:10 --> Model Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Model Class Initialized
DEBUG - 2011-04-13 07:03:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 07:03:10 --> Database Driver Class Initialized
DEBUG - 2011-04-13 07:03:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 07:03:10 --> Helper loaded: url_helper
DEBUG - 2011-04-13 07:03:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 07:03:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 07:03:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 07:03:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 07:03:10 --> Final output sent to browser
DEBUG - 2011-04-13 07:03:10 --> Total execution time: 0.2246
DEBUG - 2011-04-13 07:03:15 --> Config Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:03:15 --> URI Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Router Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Output Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Input Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:03:15 --> Language Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Loader Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Controller Class Initialized
DEBUG - 2011-04-13 07:03:15 --> Model Class Initialized
DEBUG - 2011-04-13 07:03:17 --> Model Class Initialized
DEBUG - 2011-04-13 07:03:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 07:03:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 07:03:17 --> Final output sent to browser
DEBUG - 2011-04-13 07:03:17 --> Total execution time: 2.6557
DEBUG - 2011-04-13 07:03:31 --> Config Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:03:31 --> URI Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Router Class Initialized
DEBUG - 2011-04-13 07:03:31 --> No URI present. Default controller set.
DEBUG - 2011-04-13 07:03:31 --> Output Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Input Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:03:31 --> Language Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Loader Class Initialized
DEBUG - 2011-04-13 07:03:31 --> Controller Class Initialized
DEBUG - 2011-04-13 07:03:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 07:03:31 --> Helper loaded: url_helper
DEBUG - 2011-04-13 07:03:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 07:03:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 07:03:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 07:03:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 07:03:31 --> Final output sent to browser
DEBUG - 2011-04-13 07:03:31 --> Total execution time: 0.0146
DEBUG - 2011-04-13 07:21:49 --> Config Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:21:49 --> URI Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Router Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Output Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Input Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:21:49 --> Language Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Loader Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Controller Class Initialized
ERROR - 2011-04-13 07:21:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 07:21:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 07:21:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 07:21:49 --> Model Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Model Class Initialized
DEBUG - 2011-04-13 07:21:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 07:21:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 07:21:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 07:21:49 --> Helper loaded: url_helper
DEBUG - 2011-04-13 07:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 07:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 07:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 07:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 07:21:49 --> Final output sent to browser
DEBUG - 2011-04-13 07:21:49 --> Total execution time: 0.2656
DEBUG - 2011-04-13 07:21:50 --> Config Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:21:50 --> URI Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Router Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Output Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Input Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:21:50 --> Language Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Loader Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Controller Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Model Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Model Class Initialized
DEBUG - 2011-04-13 07:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 07:21:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 07:21:51 --> Final output sent to browser
DEBUG - 2011-04-13 07:21:51 --> Total execution time: 0.8385
DEBUG - 2011-04-13 07:22:07 --> Config Class Initialized
DEBUG - 2011-04-13 07:22:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:22:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:22:07 --> URI Class Initialized
DEBUG - 2011-04-13 07:22:07 --> Router Class Initialized
DEBUG - 2011-04-13 07:22:08 --> Output Class Initialized
DEBUG - 2011-04-13 07:22:08 --> Input Class Initialized
DEBUG - 2011-04-13 07:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:22:08 --> Language Class Initialized
DEBUG - 2011-04-13 07:22:08 --> Loader Class Initialized
DEBUG - 2011-04-13 07:22:08 --> Controller Class Initialized
DEBUG - 2011-04-13 07:22:08 --> Model Class Initialized
DEBUG - 2011-04-13 07:22:09 --> Model Class Initialized
DEBUG - 2011-04-13 07:22:09 --> Model Class Initialized
DEBUG - 2011-04-13 07:22:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 07:22:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 07:22:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 07:22:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 07:22:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 07:22:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 07:22:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 07:22:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 07:22:09 --> Final output sent to browser
DEBUG - 2011-04-13 07:22:09 --> Total execution time: 1.9975
DEBUG - 2011-04-13 07:22:13 --> Config Class Initialized
DEBUG - 2011-04-13 07:22:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:22:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:22:13 --> URI Class Initialized
DEBUG - 2011-04-13 07:22:13 --> Router Class Initialized
ERROR - 2011-04-13 07:22:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 07:23:02 --> Config Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 07:23:03 --> URI Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Router Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Output Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Input Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 07:23:03 --> Language Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Loader Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Controller Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Model Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Model Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Model Class Initialized
DEBUG - 2011-04-13 07:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 07:23:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 07:23:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 07:23:03 --> Helper loaded: url_helper
DEBUG - 2011-04-13 07:23:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 07:23:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 07:23:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 07:23:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 07:23:03 --> Final output sent to browser
DEBUG - 2011-04-13 07:23:03 --> Total execution time: 1.0485
DEBUG - 2011-04-13 08:29:27 --> Config Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:29:27 --> URI Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Router Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Output Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Input Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:29:27 --> Language Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Loader Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Controller Class Initialized
ERROR - 2011-04-13 08:29:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 08:29:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 08:29:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 08:29:27 --> Model Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Model Class Initialized
DEBUG - 2011-04-13 08:29:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:29:28 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:29:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 08:29:28 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:29:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:29:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:29:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:29:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:29:28 --> Final output sent to browser
DEBUG - 2011-04-13 08:29:28 --> Total execution time: 1.2049
DEBUG - 2011-04-13 08:30:15 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:15 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:15 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:15 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:16 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:16 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:16 --> Total execution time: 0.3497
DEBUG - 2011-04-13 08:30:17 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:17 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:17 --> Router Class Initialized
ERROR - 2011-04-13 08:30:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:30:22 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:22 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:22 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:22 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:22 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:22 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:22 --> Total execution time: 0.5486
DEBUG - 2011-04-13 08:30:24 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:24 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:24 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:24 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:24 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:24 --> Total execution time: 0.0458
DEBUG - 2011-04-13 08:30:24 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:24 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:24 --> Router Class Initialized
ERROR - 2011-04-13 08:30:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:30:49 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:49 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:49 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:49 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:49 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:49 --> Total execution time: 0.3345
DEBUG - 2011-04-13 08:30:50 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:50 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:50 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:50 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:50 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:50 --> Total execution time: 0.1023
DEBUG - 2011-04-13 08:30:50 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:50 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:50 --> Router Class Initialized
ERROR - 2011-04-13 08:30:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:30:53 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:53 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:53 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:53 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:53 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:53 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:53 --> Total execution time: 0.0583
DEBUG - 2011-04-13 08:30:56 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:56 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Router Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Output Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Input Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:30:56 --> Language Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Loader Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Controller Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Model Class Initialized
DEBUG - 2011-04-13 08:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:30:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:30:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:30:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:30:56 --> Final output sent to browser
DEBUG - 2011-04-13 08:30:56 --> Total execution time: 0.2672
DEBUG - 2011-04-13 08:30:57 --> Config Class Initialized
DEBUG - 2011-04-13 08:30:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:30:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:30:57 --> URI Class Initialized
DEBUG - 2011-04-13 08:30:57 --> Router Class Initialized
ERROR - 2011-04-13 08:30:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:31:02 --> Config Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:31:02 --> URI Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Router Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Output Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Input Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:31:02 --> Language Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Loader Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Controller Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Model Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Model Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Model Class Initialized
DEBUG - 2011-04-13 08:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:31:02 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:31:02 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:31:02 --> Final output sent to browser
DEBUG - 2011-04-13 08:31:02 --> Total execution time: 0.2267
DEBUG - 2011-04-13 08:32:12 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:12 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Router Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Output Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Input Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:32:12 --> Language Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Loader Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Controller Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:32:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:32:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:32:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:32:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:32:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:32:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:32:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:32:12 --> Final output sent to browser
DEBUG - 2011-04-13 08:32:12 --> Total execution time: 0.2103
DEBUG - 2011-04-13 08:32:14 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:14 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:14 --> Router Class Initialized
ERROR - 2011-04-13 08:32:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:32:29 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:29 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Router Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Output Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Input Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:32:29 --> Language Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Loader Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Controller Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:32:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:32:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:32:30 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:32:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:32:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:32:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:32:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:32:30 --> Final output sent to browser
DEBUG - 2011-04-13 08:32:30 --> Total execution time: 0.2606
DEBUG - 2011-04-13 08:32:31 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:31 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:31 --> Router Class Initialized
ERROR - 2011-04-13 08:32:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:32:39 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:39 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Router Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Output Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Input Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:32:39 --> Language Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Loader Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Controller Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:32:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:32:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:32:39 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:32:39 --> Final output sent to browser
DEBUG - 2011-04-13 08:32:39 --> Total execution time: 0.1326
DEBUG - 2011-04-13 08:32:39 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:39 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:39 --> Router Class Initialized
ERROR - 2011-04-13 08:32:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:32:57 --> Config Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:32:57 --> URI Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Router Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Output Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Input Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:32:57 --> Language Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Loader Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Controller Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Model Class Initialized
DEBUG - 2011-04-13 08:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:32:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:32:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:32:57 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:32:57 --> Final output sent to browser
DEBUG - 2011-04-13 08:32:57 --> Total execution time: 0.1032
DEBUG - 2011-04-13 08:33:01 --> Config Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:33:01 --> URI Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Router Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Output Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Input Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:33:01 --> Language Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Loader Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Controller Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Model Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Model Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Model Class Initialized
DEBUG - 2011-04-13 08:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:33:01 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:33:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:33:01 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:33:01 --> Final output sent to browser
DEBUG - 2011-04-13 08:33:01 --> Total execution time: 0.0604
DEBUG - 2011-04-13 08:34:00 --> Config Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:34:00 --> URI Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Router Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Output Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Input Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:34:00 --> Language Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Loader Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Controller Class Initialized
ERROR - 2011-04-13 08:34:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 08:34:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 08:34:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 08:34:00 --> Model Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Model Class Initialized
DEBUG - 2011-04-13 08:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:34:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:34:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 08:34:00 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:34:00 --> Final output sent to browser
DEBUG - 2011-04-13 08:34:00 --> Total execution time: 0.0321
DEBUG - 2011-04-13 08:34:03 --> Config Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:34:03 --> URI Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Router Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Output Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Input Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:34:03 --> Language Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Loader Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Controller Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Model Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Model Class Initialized
DEBUG - 2011-04-13 08:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:34:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:34:04 --> Final output sent to browser
DEBUG - 2011-04-13 08:34:04 --> Total execution time: 0.6638
DEBUG - 2011-04-13 08:34:13 --> Config Class Initialized
DEBUG - 2011-04-13 08:34:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:34:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:34:13 --> URI Class Initialized
DEBUG - 2011-04-13 08:34:13 --> Router Class Initialized
ERROR - 2011-04-13 08:34:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:34:15 --> Config Class Initialized
DEBUG - 2011-04-13 08:34:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:34:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:34:15 --> URI Class Initialized
DEBUG - 2011-04-13 08:34:15 --> Router Class Initialized
ERROR - 2011-04-13 08:34:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:34:18 --> Config Class Initialized
DEBUG - 2011-04-13 08:34:18 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:34:18 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:34:18 --> URI Class Initialized
DEBUG - 2011-04-13 08:34:18 --> Router Class Initialized
ERROR - 2011-04-13 08:34:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:45:16 --> Config Class Initialized
DEBUG - 2011-04-13 08:45:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:45:16 --> Config Class Initialized
DEBUG - 2011-04-13 08:45:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:45:17 --> URI Class Initialized
DEBUG - 2011-04-13 08:45:17 --> URI Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Router Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Router Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Output Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Output Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Input Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Input Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:45:17 --> Language Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Language Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Loader Class Initialized
DEBUG - 2011-04-13 08:45:17 --> Loader Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Controller Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Controller Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Config Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:45:18 --> URI Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Router Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Output Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Input Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:45:18 --> Language Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Loader Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Controller Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:18 --> Model Class Initialized
DEBUG - 2011-04-13 08:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:45:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:45:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:45:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:45:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:45:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:45:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:45:21 --> Final output sent to browser
DEBUG - 2011-04-13 08:45:21 --> Total execution time: 5.0746
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:45:21 --> Final output sent to browser
DEBUG - 2011-04-13 08:45:21 --> Total execution time: 2.8496
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:45:21 --> Final output sent to browser
DEBUG - 2011-04-13 08:45:21 --> Total execution time: 5.0847
DEBUG - 2011-04-13 08:45:22 --> Config Class Initialized
DEBUG - 2011-04-13 08:45:22 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:45:22 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:45:22 --> URI Class Initialized
DEBUG - 2011-04-13 08:45:22 --> Router Class Initialized
ERROR - 2011-04-13 08:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:45:23 --> Config Class Initialized
DEBUG - 2011-04-13 08:45:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:45:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:45:23 --> URI Class Initialized
DEBUG - 2011-04-13 08:45:23 --> Router Class Initialized
ERROR - 2011-04-13 08:45:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:47:51 --> Config Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:47:51 --> URI Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Router Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Output Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Input Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:47:51 --> Language Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Loader Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Controller Class Initialized
ERROR - 2011-04-13 08:47:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 08:47:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 08:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 08:47:51 --> Model Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Model Class Initialized
DEBUG - 2011-04-13 08:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:47:51 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 08:47:51 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:47:51 --> Final output sent to browser
DEBUG - 2011-04-13 08:47:51 --> Total execution time: 0.1876
DEBUG - 2011-04-13 08:47:53 --> Config Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:47:53 --> URI Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Router Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Output Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Input Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:47:53 --> Language Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Loader Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Controller Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Model Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Model Class Initialized
DEBUG - 2011-04-13 08:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:47:53 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:47:54 --> Final output sent to browser
DEBUG - 2011-04-13 08:47:54 --> Total execution time: 0.5920
DEBUG - 2011-04-13 08:47:55 --> Config Class Initialized
DEBUG - 2011-04-13 08:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:47:55 --> URI Class Initialized
DEBUG - 2011-04-13 08:47:55 --> Router Class Initialized
ERROR - 2011-04-13 08:47:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:48:45 --> Config Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:48:45 --> URI Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Router Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Output Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Input Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:48:45 --> Language Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Loader Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Controller Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Model Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Model Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Model Class Initialized
DEBUG - 2011-04-13 08:48:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:48:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:48:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:48:47 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:48:47 --> Final output sent to browser
DEBUG - 2011-04-13 08:48:47 --> Total execution time: 2.0524
DEBUG - 2011-04-13 08:48:50 --> Config Class Initialized
DEBUG - 2011-04-13 08:48:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:48:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:48:50 --> URI Class Initialized
DEBUG - 2011-04-13 08:48:50 --> Router Class Initialized
ERROR - 2011-04-13 08:48:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:48:59 --> Config Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:48:59 --> URI Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Router Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Output Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Input Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:48:59 --> Language Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Loader Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Controller Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Model Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Model Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Model Class Initialized
DEBUG - 2011-04-13 08:48:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:48:59 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:49:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:49:00 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:49:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:49:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:49:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:49:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:49:00 --> Final output sent to browser
DEBUG - 2011-04-13 08:49:00 --> Total execution time: 0.7625
DEBUG - 2011-04-13 08:49:02 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:02 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:02 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:02 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:02 --> Router Class Initialized
ERROR - 2011-04-13 08:49:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:49:11 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:11 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Router Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Output Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Input Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:49:11 --> Language Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Loader Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Controller Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:49:11 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:49:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:49:11 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:49:11 --> Final output sent to browser
DEBUG - 2011-04-13 08:49:11 --> Total execution time: 0.0625
DEBUG - 2011-04-13 08:49:12 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:12 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Router Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Output Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Input Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:49:12 --> Language Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Loader Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Controller Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:49:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:49:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:49:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:49:12 --> Final output sent to browser
DEBUG - 2011-04-13 08:49:12 --> Total execution time: 0.0613
DEBUG - 2011-04-13 08:49:13 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:13 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Router Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Output Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Input Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:49:13 --> Language Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Loader Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Controller Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:49:13 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:49:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:49:14 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:49:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:49:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:49:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:49:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:49:14 --> Final output sent to browser
DEBUG - 2011-04-13 08:49:14 --> Total execution time: 0.7455
DEBUG - 2011-04-13 08:49:16 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:16 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:16 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:16 --> Router Class Initialized
ERROR - 2011-04-13 08:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:49:39 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:39 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Router Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Output Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Input Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:49:39 --> Language Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Loader Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Controller Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Model Class Initialized
DEBUG - 2011-04-13 08:49:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:49:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:49:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:49:41 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:49:41 --> Final output sent to browser
DEBUG - 2011-04-13 08:49:41 --> Total execution time: 1.8479
DEBUG - 2011-04-13 08:49:43 --> Config Class Initialized
DEBUG - 2011-04-13 08:49:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:49:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:49:43 --> URI Class Initialized
DEBUG - 2011-04-13 08:49:43 --> Router Class Initialized
ERROR - 2011-04-13 08:49:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 08:50:12 --> Config Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:50:12 --> URI Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Router Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Output Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Input Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:50:12 --> Language Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Loader Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Controller Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Model Class Initialized
DEBUG - 2011-04-13 08:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:50:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:50:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:50:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:50:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:50:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:50:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:50:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:50:12 --> Final output sent to browser
DEBUG - 2011-04-13 08:50:12 --> Total execution time: 0.5581
DEBUG - 2011-04-13 08:50:16 --> Config Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:50:16 --> URI Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Router Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Output Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Input Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 08:50:16 --> Language Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Loader Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Controller Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Model Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Model Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Model Class Initialized
DEBUG - 2011-04-13 08:50:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 08:50:16 --> Database Driver Class Initialized
DEBUG - 2011-04-13 08:50:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 08:50:17 --> Helper loaded: url_helper
DEBUG - 2011-04-13 08:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 08:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 08:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 08:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 08:50:17 --> Final output sent to browser
DEBUG - 2011-04-13 08:50:17 --> Total execution time: 0.1705
DEBUG - 2011-04-13 08:50:19 --> Config Class Initialized
DEBUG - 2011-04-13 08:50:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 08:50:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 08:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 08:50:19 --> URI Class Initialized
DEBUG - 2011-04-13 08:50:19 --> Router Class Initialized
ERROR - 2011-04-13 08:50:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:00:49 --> Config Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:00:49 --> URI Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Router Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Output Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Input Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:00:49 --> Language Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Loader Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Controller Class Initialized
ERROR - 2011-04-13 10:00:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:00:49 --> Model Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Model Class Initialized
DEBUG - 2011-04-13 10:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:00:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:00:49 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:00:49 --> Final output sent to browser
DEBUG - 2011-04-13 10:00:49 --> Total execution time: 0.3928
DEBUG - 2011-04-13 10:00:51 --> Config Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:00:51 --> URI Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Router Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Output Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Input Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:00:51 --> Language Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Loader Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Controller Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Model Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Model Class Initialized
DEBUG - 2011-04-13 10:00:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:00:51 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:00:52 --> Final output sent to browser
DEBUG - 2011-04-13 10:00:52 --> Total execution time: 0.8505
DEBUG - 2011-04-13 10:00:55 --> Config Class Initialized
DEBUG - 2011-04-13 10:00:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:00:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:00:55 --> URI Class Initialized
DEBUG - 2011-04-13 10:00:55 --> Router Class Initialized
ERROR - 2011-04-13 10:00:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:00:55 --> Config Class Initialized
DEBUG - 2011-04-13 10:00:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:00:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:00:55 --> URI Class Initialized
DEBUG - 2011-04-13 10:00:55 --> Router Class Initialized
ERROR - 2011-04-13 10:00:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:00:56 --> Config Class Initialized
DEBUG - 2011-04-13 10:00:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:00:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:00:56 --> URI Class Initialized
DEBUG - 2011-04-13 10:00:56 --> Router Class Initialized
ERROR - 2011-04-13 10:00:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:01:21 --> Config Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:01:21 --> URI Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Router Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Output Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Input Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:01:21 --> Language Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Loader Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Controller Class Initialized
ERROR - 2011-04-13 10:01:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:01:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:01:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:01:21 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:01:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:01:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:01:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:01:21 --> Final output sent to browser
DEBUG - 2011-04-13 10:01:21 --> Total execution time: 0.1598
DEBUG - 2011-04-13 10:01:22 --> Config Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:01:22 --> URI Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Router Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Output Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Input Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:01:22 --> Language Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Loader Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Controller Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:01:22 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:01:23 --> Final output sent to browser
DEBUG - 2011-04-13 10:01:23 --> Total execution time: 1.1523
DEBUG - 2011-04-13 10:01:40 --> Config Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:01:40 --> URI Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Router Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Output Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Input Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:01:40 --> Language Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Loader Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Controller Class Initialized
ERROR - 2011-04-13 10:01:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:01:40 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:01:40 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:01:40 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:01:40 --> Final output sent to browser
DEBUG - 2011-04-13 10:01:40 --> Total execution time: 0.0531
DEBUG - 2011-04-13 10:01:46 --> Config Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:01:47 --> URI Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Router Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Output Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Input Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:01:47 --> Language Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Loader Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Controller Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Model Class Initialized
DEBUG - 2011-04-13 10:01:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:01:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:01:50 --> Final output sent to browser
DEBUG - 2011-04-13 10:01:50 --> Total execution time: 3.9780
DEBUG - 2011-04-13 10:02:10 --> Config Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:02:10 --> URI Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Router Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Output Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Input Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:02:10 --> Language Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Loader Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Controller Class Initialized
ERROR - 2011-04-13 10:02:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:02:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:02:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:02:10 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:02:10 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:02:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:02:10 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:02:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:02:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:02:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:02:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:02:10 --> Final output sent to browser
DEBUG - 2011-04-13 10:02:10 --> Total execution time: 0.2052
DEBUG - 2011-04-13 10:02:12 --> Config Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:02:12 --> URI Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Router Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Output Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Input Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:02:12 --> Language Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Loader Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Controller Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:02:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:02:13 --> Final output sent to browser
DEBUG - 2011-04-13 10:02:13 --> Total execution time: 1.0350
DEBUG - 2011-04-13 10:02:32 --> Config Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:02:32 --> URI Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Router Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Output Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Input Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:02:32 --> Language Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Loader Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Controller Class Initialized
ERROR - 2011-04-13 10:02:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:02:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:02:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:02:32 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:02:32 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:02:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:02:32 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:02:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:02:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:02:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:02:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:02:32 --> Final output sent to browser
DEBUG - 2011-04-13 10:02:32 --> Total execution time: 0.5483
DEBUG - 2011-04-13 10:02:34 --> Config Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:02:34 --> URI Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Router Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Output Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Input Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:02:34 --> Language Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Loader Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Controller Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Model Class Initialized
DEBUG - 2011-04-13 10:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:02:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:02:35 --> Final output sent to browser
DEBUG - 2011-04-13 10:02:35 --> Total execution time: 0.7527
DEBUG - 2011-04-13 10:14:47 --> Config Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:14:47 --> URI Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Router Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Output Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Input Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:14:47 --> Language Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Loader Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Controller Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Model Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Model Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Model Class Initialized
DEBUG - 2011-04-13 10:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:14:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:14:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:14:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:14:48 --> Final output sent to browser
DEBUG - 2011-04-13 10:14:48 --> Total execution time: 1.2533
DEBUG - 2011-04-13 10:14:50 --> Config Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:14:50 --> URI Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Router Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Output Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Input Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:14:50 --> Language Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Loader Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Controller Class Initialized
ERROR - 2011-04-13 10:14:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:14:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:14:50 --> Model Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Model Class Initialized
DEBUG - 2011-04-13 10:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:14:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:14:50 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:14:50 --> Final output sent to browser
DEBUG - 2011-04-13 10:14:50 --> Total execution time: 0.3059
DEBUG - 2011-04-13 10:33:23 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:23 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:23 --> Router Class Initialized
DEBUG - 2011-04-13 10:33:23 --> Output Class Initialized
DEBUG - 2011-04-13 10:33:23 --> Input Class Initialized
DEBUG - 2011-04-13 10:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:33:23 --> Language Class Initialized
DEBUG - 2011-04-13 10:33:24 --> Loader Class Initialized
DEBUG - 2011-04-13 10:33:24 --> Controller Class Initialized
DEBUG - 2011-04-13 10:33:24 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:24 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:24 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:33:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:33:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:33:24 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:33:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:33:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:33:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:33:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:33:24 --> Final output sent to browser
DEBUG - 2011-04-13 10:33:24 --> Total execution time: 1.2114
DEBUG - 2011-04-13 10:33:27 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:27 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:27 --> Router Class Initialized
ERROR - 2011-04-13 10:33:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:33:27 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:27 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:27 --> Router Class Initialized
ERROR - 2011-04-13 10:33:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:33:28 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:28 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:28 --> Router Class Initialized
ERROR - 2011-04-13 10:33:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 10:33:37 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:37 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Router Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Output Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Input Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:33:37 --> Language Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Loader Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Controller Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:33:37 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:33:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:33:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:33:38 --> Final output sent to browser
DEBUG - 2011-04-13 10:33:38 --> Total execution time: 0.9413
DEBUG - 2011-04-13 10:33:39 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:39 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Router Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Output Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Input Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:33:39 --> Language Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Loader Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Controller Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:33:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:33:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:33:39 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:33:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:33:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:33:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:33:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:33:39 --> Final output sent to browser
DEBUG - 2011-04-13 10:33:39 --> Total execution time: 0.1842
DEBUG - 2011-04-13 10:33:45 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:45 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Router Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Output Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Input Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:33:45 --> Language Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Loader Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Controller Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:33:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:33:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:33:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:33:46 --> Final output sent to browser
DEBUG - 2011-04-13 10:33:46 --> Total execution time: 1.1780
DEBUG - 2011-04-13 10:33:47 --> Config Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:33:47 --> URI Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Router Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Output Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Input Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:33:47 --> Language Class Initialized
DEBUG - 2011-04-13 10:33:47 --> Loader Class Initialized
DEBUG - 2011-04-13 10:33:48 --> Controller Class Initialized
DEBUG - 2011-04-13 10:33:48 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:48 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:48 --> Model Class Initialized
DEBUG - 2011-04-13 10:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:33:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:33:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:33:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:33:48 --> Final output sent to browser
DEBUG - 2011-04-13 10:33:48 --> Total execution time: 0.3154
DEBUG - 2011-04-13 10:34:10 --> Config Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:34:10 --> URI Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Router Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Output Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Input Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:34:10 --> Language Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Loader Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Controller Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Model Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Model Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Model Class Initialized
DEBUG - 2011-04-13 10:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:34:10 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:34:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:34:11 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:34:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:34:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:34:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:34:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:34:11 --> Final output sent to browser
DEBUG - 2011-04-13 10:34:11 --> Total execution time: 1.0181
DEBUG - 2011-04-13 10:34:13 --> Config Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:34:13 --> URI Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Router Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Output Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Input Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:34:13 --> Language Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Loader Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Controller Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Model Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Model Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Model Class Initialized
DEBUG - 2011-04-13 10:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:34:13 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:34:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:34:13 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:34:13 --> Final output sent to browser
DEBUG - 2011-04-13 10:34:13 --> Total execution time: 0.1425
DEBUG - 2011-04-13 10:36:52 --> Config Class Initialized
DEBUG - 2011-04-13 10:36:52 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:36:52 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:36:52 --> URI Class Initialized
DEBUG - 2011-04-13 10:36:52 --> Router Class Initialized
ERROR - 2011-04-13 10:36:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 10:36:54 --> Config Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:36:54 --> URI Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Router Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Output Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Input Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:36:54 --> Language Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Loader Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Controller Class Initialized
ERROR - 2011-04-13 10:36:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:36:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:36:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:36:54 --> Model Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Model Class Initialized
DEBUG - 2011-04-13 10:36:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:36:54 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:36:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:36:54 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:36:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:36:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:36:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:36:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:36:54 --> Final output sent to browser
DEBUG - 2011-04-13 10:36:54 --> Total execution time: 0.1276
DEBUG - 2011-04-13 10:43:46 --> Config Class Initialized
DEBUG - 2011-04-13 10:43:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:43:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:43:46 --> URI Class Initialized
DEBUG - 2011-04-13 10:43:46 --> Router Class Initialized
ERROR - 2011-04-13 10:43:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 10:45:19 --> Config Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:45:19 --> URI Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Router Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Output Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Input Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:45:19 --> Language Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Loader Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Controller Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Model Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Model Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Model Class Initialized
DEBUG - 2011-04-13 10:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:45:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:45:20 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:45:20 --> Final output sent to browser
DEBUG - 2011-04-13 10:45:20 --> Total execution time: 0.3592
DEBUG - 2011-04-13 10:49:12 --> Config Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:49:12 --> URI Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Router Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Output Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Input Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:49:12 --> Language Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Loader Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Controller Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Model Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Model Class Initialized
DEBUG - 2011-04-13 10:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:49:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:49:14 --> Final output sent to browser
DEBUG - 2011-04-13 10:49:14 --> Total execution time: 1.8592
DEBUG - 2011-04-13 10:53:15 --> Config Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:53:15 --> URI Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Router Class Initialized
DEBUG - 2011-04-13 10:53:15 --> No URI present. Default controller set.
DEBUG - 2011-04-13 10:53:15 --> Output Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Input Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:53:15 --> Language Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Loader Class Initialized
DEBUG - 2011-04-13 10:53:15 --> Controller Class Initialized
DEBUG - 2011-04-13 10:53:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 10:53:15 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:53:15 --> Final output sent to browser
DEBUG - 2011-04-13 10:53:15 --> Total execution time: 0.1261
DEBUG - 2011-04-13 10:53:41 --> Config Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:53:41 --> URI Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Router Class Initialized
ERROR - 2011-04-13 10:53:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 10:53:41 --> Config Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:53:41 --> URI Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Router Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Output Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Input Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:53:41 --> Language Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Loader Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Controller Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Model Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Model Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Model Class Initialized
DEBUG - 2011-04-13 10:53:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:53:41 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:53:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 10:53:41 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:53:41 --> Final output sent to browser
DEBUG - 2011-04-13 10:53:41 --> Total execution time: 0.3743
DEBUG - 2011-04-13 10:54:12 --> Config Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 10:54:12 --> URI Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Router Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Output Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Input Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 10:54:12 --> Language Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Loader Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Controller Class Initialized
ERROR - 2011-04-13 10:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 10:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 10:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:54:12 --> Model Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Model Class Initialized
DEBUG - 2011-04-13 10:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 10:54:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 10:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 10:54:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 10:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 10:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 10:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 10:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 10:54:12 --> Final output sent to browser
DEBUG - 2011-04-13 10:54:12 --> Total execution time: 0.0943
DEBUG - 2011-04-13 11:02:23 --> Config Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 11:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 11:02:23 --> URI Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Router Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Output Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Input Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 11:02:23 --> Language Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Loader Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Controller Class Initialized
ERROR - 2011-04-13 11:02:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 11:02:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 11:02:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 11:02:23 --> Model Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Model Class Initialized
DEBUG - 2011-04-13 11:02:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 11:02:23 --> Database Driver Class Initialized
DEBUG - 2011-04-13 11:02:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 11:02:23 --> Helper loaded: url_helper
DEBUG - 2011-04-13 11:02:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 11:02:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 11:02:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 11:02:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 11:02:23 --> Final output sent to browser
DEBUG - 2011-04-13 11:02:23 --> Total execution time: 0.3466
DEBUG - 2011-04-13 11:15:46 --> Config Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 11:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 11:15:46 --> URI Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Router Class Initialized
DEBUG - 2011-04-13 11:15:46 --> No URI present. Default controller set.
DEBUG - 2011-04-13 11:15:46 --> Output Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Input Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 11:15:46 --> Language Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Loader Class Initialized
DEBUG - 2011-04-13 11:15:46 --> Controller Class Initialized
DEBUG - 2011-04-13 11:15:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 11:15:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 11:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 11:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 11:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 11:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 11:15:46 --> Final output sent to browser
DEBUG - 2011-04-13 11:15:46 --> Total execution time: 0.0842
DEBUG - 2011-04-13 11:17:53 --> Config Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 11:17:53 --> URI Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Router Class Initialized
DEBUG - 2011-04-13 11:17:53 --> No URI present. Default controller set.
DEBUG - 2011-04-13 11:17:53 --> Output Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Input Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 11:17:53 --> Language Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Loader Class Initialized
DEBUG - 2011-04-13 11:17:53 --> Controller Class Initialized
DEBUG - 2011-04-13 11:17:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 11:17:54 --> Helper loaded: url_helper
DEBUG - 2011-04-13 11:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 11:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 11:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 11:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 11:17:54 --> Final output sent to browser
DEBUG - 2011-04-13 11:17:54 --> Total execution time: 0.1678
DEBUG - 2011-04-13 11:17:58 --> Config Class Initialized
DEBUG - 2011-04-13 11:17:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 11:17:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 11:17:58 --> URI Class Initialized
DEBUG - 2011-04-13 11:17:58 --> Router Class Initialized
ERROR - 2011-04-13 11:17:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 11:18:00 --> Config Class Initialized
DEBUG - 2011-04-13 11:18:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 11:18:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 11:18:00 --> URI Class Initialized
DEBUG - 2011-04-13 11:18:00 --> Router Class Initialized
ERROR - 2011-04-13 11:18:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 12:06:06 --> Config Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:06:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:06:06 --> URI Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Router Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Output Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Input Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:06:06 --> Language Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Loader Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Controller Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Model Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Model Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Model Class Initialized
DEBUG - 2011-04-13 12:06:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:06:06 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:06:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 12:06:06 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:06:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:06:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:06:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:06:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:06:06 --> Final output sent to browser
DEBUG - 2011-04-13 12:06:06 --> Total execution time: 0.5985
DEBUG - 2011-04-13 12:06:14 --> Config Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:06:14 --> URI Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Router Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Output Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Input Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:06:14 --> Language Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Loader Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Controller Class Initialized
ERROR - 2011-04-13 12:06:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 12:06:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 12:06:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:06:14 --> Model Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Model Class Initialized
DEBUG - 2011-04-13 12:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:06:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:06:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:06:14 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:06:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:06:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:06:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:06:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:06:14 --> Final output sent to browser
DEBUG - 2011-04-13 12:06:14 --> Total execution time: 0.7250
DEBUG - 2011-04-13 12:16:09 --> Config Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:16:09 --> URI Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Router Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Output Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Input Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:16:09 --> Language Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Loader Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Controller Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:16:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:16:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 12:16:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:16:09 --> Final output sent to browser
DEBUG - 2011-04-13 12:16:09 --> Total execution time: 0.2623
DEBUG - 2011-04-13 12:16:13 --> Config Class Initialized
DEBUG - 2011-04-13 12:16:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:16:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:16:13 --> URI Class Initialized
DEBUG - 2011-04-13 12:16:13 --> Router Class Initialized
ERROR - 2011-04-13 12:16:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 12:16:46 --> Config Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:16:46 --> URI Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Router Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Output Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Input Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:16:46 --> Language Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Loader Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Controller Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:16:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:16:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 12:16:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:16:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:16:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:16:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:16:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:16:46 --> Final output sent to browser
DEBUG - 2011-04-13 12:16:46 --> Total execution time: 0.0509
DEBUG - 2011-04-13 12:16:58 --> Config Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:16:58 --> URI Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Router Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Output Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Input Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:16:58 --> Language Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Loader Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Controller Class Initialized
ERROR - 2011-04-13 12:16:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 12:16:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 12:16:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:16:58 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Model Class Initialized
DEBUG - 2011-04-13 12:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:16:58 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:16:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:16:58 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:16:58 --> Final output sent to browser
DEBUG - 2011-04-13 12:16:58 --> Total execution time: 0.0789
DEBUG - 2011-04-13 12:16:59 --> Config Class Initialized
DEBUG - 2011-04-13 12:16:59 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:16:59 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:16:59 --> URI Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Router Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Output Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Input Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:17:00 --> Language Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Loader Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Controller Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Model Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Model Class Initialized
DEBUG - 2011-04-13 12:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:17:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:17:01 --> Final output sent to browser
DEBUG - 2011-04-13 12:17:01 --> Total execution time: 1.4276
DEBUG - 2011-04-13 12:17:04 --> Config Class Initialized
DEBUG - 2011-04-13 12:17:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:17:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:17:04 --> URI Class Initialized
DEBUG - 2011-04-13 12:17:04 --> Router Class Initialized
ERROR - 2011-04-13 12:17:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 12:19:46 --> Config Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:19:46 --> URI Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Router Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Output Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Input Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:19:46 --> Language Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Loader Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Controller Class Initialized
ERROR - 2011-04-13 12:19:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 12:19:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 12:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:19:46 --> Model Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Model Class Initialized
DEBUG - 2011-04-13 12:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:19:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:19:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:19:46 --> Final output sent to browser
DEBUG - 2011-04-13 12:19:46 --> Total execution time: 0.0307
DEBUG - 2011-04-13 12:19:47 --> Config Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:19:47 --> URI Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Router Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Output Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Input Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:19:47 --> Language Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Loader Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Controller Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Model Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Model Class Initialized
DEBUG - 2011-04-13 12:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:19:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:19:48 --> Final output sent to browser
DEBUG - 2011-04-13 12:19:48 --> Total execution time: 0.6546
DEBUG - 2011-04-13 12:20:00 --> Config Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:20:00 --> URI Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Router Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Output Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Input Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:20:00 --> Language Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Loader Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Controller Class Initialized
ERROR - 2011-04-13 12:20:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 12:20:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 12:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:20:00 --> Model Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Model Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:20:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:20:00 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:20:00 --> Final output sent to browser
DEBUG - 2011-04-13 12:20:00 --> Total execution time: 0.0796
DEBUG - 2011-04-13 12:20:00 --> Config Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:20:00 --> URI Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Router Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Output Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Input Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:20:00 --> Language Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Loader Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Controller Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Model Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Model Class Initialized
DEBUG - 2011-04-13 12:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:20:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:20:01 --> Final output sent to browser
DEBUG - 2011-04-13 12:20:01 --> Total execution time: 0.5734
DEBUG - 2011-04-13 12:31:20 --> Config Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 12:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 12:31:20 --> URI Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Router Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Output Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Input Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 12:31:20 --> Language Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Loader Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Controller Class Initialized
ERROR - 2011-04-13 12:31:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 12:31:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 12:31:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:31:20 --> Model Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Model Class Initialized
DEBUG - 2011-04-13 12:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 12:31:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 12:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 12:31:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 12:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 12:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 12:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 12:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 12:31:21 --> Final output sent to browser
DEBUG - 2011-04-13 12:31:21 --> Total execution time: 0.0792
DEBUG - 2011-04-13 13:12:32 --> Config Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Hooks Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Utf8 Class Initialized
DEBUG - 2011-04-13 13:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 13:12:32 --> URI Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Router Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Output Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Input Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 13:12:32 --> Language Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Loader Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Controller Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Model Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Model Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Model Class Initialized
DEBUG - 2011-04-13 13:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 13:12:32 --> Database Driver Class Initialized
DEBUG - 2011-04-13 13:12:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 13:12:33 --> Helper loaded: url_helper
DEBUG - 2011-04-13 13:12:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 13:12:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 13:12:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 13:12:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 13:12:33 --> Final output sent to browser
DEBUG - 2011-04-13 13:12:33 --> Total execution time: 0.8374
DEBUG - 2011-04-13 13:12:39 --> Config Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 13:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 13:12:39 --> URI Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Router Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Output Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Input Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 13:12:39 --> Language Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Loader Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Controller Class Initialized
ERROR - 2011-04-13 13:12:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 13:12:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 13:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 13:12:39 --> Model Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Model Class Initialized
DEBUG - 2011-04-13 13:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 13:12:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 13:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 13:12:39 --> Helper loaded: url_helper
DEBUG - 2011-04-13 13:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 13:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 13:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 13:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 13:12:39 --> Final output sent to browser
DEBUG - 2011-04-13 13:12:39 --> Total execution time: 0.1312
DEBUG - 2011-04-13 14:38:33 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:33 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Router Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Output Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Input Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:38:33 --> Language Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Loader Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Controller Class Initialized
ERROR - 2011-04-13 14:38:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:38:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:38:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:38:33 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:38:33 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:38:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:38:33 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:38:33 --> Final output sent to browser
DEBUG - 2011-04-13 14:38:33 --> Total execution time: 0.4532
DEBUG - 2011-04-13 14:38:34 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:34 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Router Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Output Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Input Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:38:34 --> Language Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Loader Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Controller Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:38:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:38:35 --> Final output sent to browser
DEBUG - 2011-04-13 14:38:35 --> Total execution time: 0.6065
DEBUG - 2011-04-13 14:38:37 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:37 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:37 --> Router Class Initialized
ERROR - 2011-04-13 14:38:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:38:42 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:42 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Router Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Output Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Input Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:38:42 --> Language Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Loader Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Controller Class Initialized
ERROR - 2011-04-13 14:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:38:42 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:38:42 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:38:42 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:38:42 --> Final output sent to browser
DEBUG - 2011-04-13 14:38:42 --> Total execution time: 0.0293
DEBUG - 2011-04-13 14:38:43 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:43 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Router Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Output Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Input Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:38:43 --> Language Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Loader Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Controller Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:38:43 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:38:44 --> Final output sent to browser
DEBUG - 2011-04-13 14:38:44 --> Total execution time: 0.6113
DEBUG - 2011-04-13 14:38:45 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:45 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:45 --> Router Class Initialized
ERROR - 2011-04-13 14:38:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:38:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Router Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Output Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Input Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:38:56 --> Language Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Loader Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Controller Class Initialized
ERROR - 2011-04-13 14:38:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:38:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:38:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:38:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:38:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:38:56 --> Final output sent to browser
DEBUG - 2011-04-13 14:38:56 --> Total execution time: 0.0986
DEBUG - 2011-04-13 14:38:57 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:57 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Router Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Output Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Input Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:38:57 --> Language Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Loader Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Controller Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Model Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:38:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:38:57 --> Final output sent to browser
DEBUG - 2011-04-13 14:38:57 --> Total execution time: 0.5014
DEBUG - 2011-04-13 14:38:59 --> Config Class Initialized
DEBUG - 2011-04-13 14:38:59 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:38:59 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:38:59 --> URI Class Initialized
DEBUG - 2011-04-13 14:38:59 --> Router Class Initialized
ERROR - 2011-04-13 14:38:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:39:24 --> Config Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:39:24 --> URI Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Router Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Output Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Input Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:39:24 --> Language Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Loader Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Controller Class Initialized
ERROR - 2011-04-13 14:39:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:39:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:39:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:39:24 --> Model Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Model Class Initialized
DEBUG - 2011-04-13 14:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:39:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:39:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:39:24 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:39:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:39:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:39:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:39:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:39:24 --> Final output sent to browser
DEBUG - 2011-04-13 14:39:24 --> Total execution time: 0.0290
DEBUG - 2011-04-13 14:39:26 --> Config Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:39:26 --> URI Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Router Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Output Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Input Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:39:26 --> Language Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Loader Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Controller Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Model Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Model Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:39:26 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:39:26 --> Final output sent to browser
DEBUG - 2011-04-13 14:39:26 --> Total execution time: 0.5459
DEBUG - 2011-04-13 14:39:28 --> Config Class Initialized
DEBUG - 2011-04-13 14:39:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:39:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:39:28 --> URI Class Initialized
DEBUG - 2011-04-13 14:39:28 --> Router Class Initialized
ERROR - 2011-04-13 14:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:40:17 --> Config Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:40:17 --> URI Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Router Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Output Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Input Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:40:17 --> Language Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Loader Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Controller Class Initialized
ERROR - 2011-04-13 14:40:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:40:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:40:17 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:40:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:40:17 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:40:17 --> Final output sent to browser
DEBUG - 2011-04-13 14:40:17 --> Total execution time: 0.0406
DEBUG - 2011-04-13 14:40:19 --> Config Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:40:19 --> URI Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Router Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Output Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Input Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:40:19 --> Language Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Loader Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Controller Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:40:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:40:20 --> Final output sent to browser
DEBUG - 2011-04-13 14:40:20 --> Total execution time: 0.9265
DEBUG - 2011-04-13 14:40:23 --> Config Class Initialized
DEBUG - 2011-04-13 14:40:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:40:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:40:23 --> URI Class Initialized
DEBUG - 2011-04-13 14:40:23 --> Router Class Initialized
ERROR - 2011-04-13 14:40:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:40:52 --> Config Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:40:52 --> URI Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Router Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Output Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Input Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:40:52 --> Language Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Loader Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Controller Class Initialized
ERROR - 2011-04-13 14:40:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:40:52 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:40:52 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:40:52 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:40:52 --> Final output sent to browser
DEBUG - 2011-04-13 14:40:52 --> Total execution time: 0.0330
DEBUG - 2011-04-13 14:40:53 --> Config Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:40:53 --> URI Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Router Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Output Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Input Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:40:53 --> Language Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Loader Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Controller Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Model Class Initialized
DEBUG - 2011-04-13 14:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:40:53 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:40:54 --> Final output sent to browser
DEBUG - 2011-04-13 14:40:54 --> Total execution time: 0.6130
DEBUG - 2011-04-13 14:40:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:40:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:40:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:40:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:40:56 --> Router Class Initialized
ERROR - 2011-04-13 14:40:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:41:14 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:14 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:14 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Controller Class Initialized
ERROR - 2011-04-13 14:41:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:14 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:14 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:41:14 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:14 --> Total execution time: 0.0333
DEBUG - 2011-04-13 14:41:15 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:15 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:15 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Controller Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:15 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:16 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:16 --> Total execution time: 0.7639
DEBUG - 2011-04-13 14:41:18 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:18 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:18 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:18 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:18 --> Router Class Initialized
ERROR - 2011-04-13 14:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:41:27 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:27 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:27 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Controller Class Initialized
ERROR - 2011-04-13 14:41:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:41:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:41:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:27 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:27 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:41:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:41:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:41:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:41:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:41:27 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:27 --> Total execution time: 0.0343
DEBUG - 2011-04-13 14:41:28 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:28 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:28 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Controller Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:28 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:29 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:29 --> Total execution time: 0.5376
DEBUG - 2011-04-13 14:41:31 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:31 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:31 --> Router Class Initialized
ERROR - 2011-04-13 14:41:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:41:36 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:36 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:36 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Controller Class Initialized
ERROR - 2011-04-13 14:41:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:41:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:41:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:36 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:36 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:36 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:41:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:41:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:41:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:41:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:41:36 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:36 --> Total execution time: 0.0326
DEBUG - 2011-04-13 14:41:37 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:37 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:37 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Controller Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:37 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:38 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:38 --> Total execution time: 0.6956
DEBUG - 2011-04-13 14:41:41 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:41 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:41 --> Router Class Initialized
ERROR - 2011-04-13 14:41:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:41:45 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:45 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:45 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Controller Class Initialized
ERROR - 2011-04-13 14:41:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:45 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:45 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:41:45 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:45 --> Total execution time: 0.0321
DEBUG - 2011-04-13 14:41:46 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:46 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:46 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Controller Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:46 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Router Class Initialized
ERROR - 2011-04-13 14:41:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 14:41:46 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:46 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Router Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Output Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Input Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:41:46 --> Language Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Loader Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Controller Class Initialized
ERROR - 2011-04-13 14:41:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:41:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:41:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:46 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Model Class Initialized
DEBUG - 2011-04-13 14:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:41:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:41:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:41:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:41:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:41:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:41:46 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:46 --> Total execution time: 0.1055
DEBUG - 2011-04-13 14:41:46 --> Final output sent to browser
DEBUG - 2011-04-13 14:41:46 --> Total execution time: 0.7487
DEBUG - 2011-04-13 14:41:48 --> Config Class Initialized
DEBUG - 2011-04-13 14:41:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:41:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:41:48 --> URI Class Initialized
DEBUG - 2011-04-13 14:41:48 --> Router Class Initialized
ERROR - 2011-04-13 14:41:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:42:01 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:01 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Router Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Output Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Input Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:42:01 --> Language Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Loader Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Controller Class Initialized
ERROR - 2011-04-13 14:42:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:42:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:42:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:42:01 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:42:01 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:42:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:42:01 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:42:01 --> Final output sent to browser
DEBUG - 2011-04-13 14:42:01 --> Total execution time: 0.0350
DEBUG - 2011-04-13 14:42:02 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:02 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Router Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Output Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Input Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:42:02 --> Language Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Loader Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Controller Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:42:02 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:42:02 --> Final output sent to browser
DEBUG - 2011-04-13 14:42:02 --> Total execution time: 0.5461
DEBUG - 2011-04-13 14:42:04 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:04 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:04 --> Router Class Initialized
ERROR - 2011-04-13 14:42:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:42:34 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:34 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Router Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Output Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Input Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:42:34 --> Language Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Loader Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Controller Class Initialized
ERROR - 2011-04-13 14:42:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:42:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:42:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:42:34 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:42:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:42:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:42:34 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:42:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:42:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:42:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:42:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:42:34 --> Final output sent to browser
DEBUG - 2011-04-13 14:42:34 --> Total execution time: 0.0338
DEBUG - 2011-04-13 14:42:35 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:35 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Router Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Output Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Input Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:42:35 --> Language Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Loader Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Controller Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:42:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:42:35 --> Final output sent to browser
DEBUG - 2011-04-13 14:42:35 --> Total execution time: 0.5701
DEBUG - 2011-04-13 14:42:37 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:37 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:37 --> Router Class Initialized
ERROR - 2011-04-13 14:42:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:42:48 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:48 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Router Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Output Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Input Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:42:48 --> Language Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Loader Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Controller Class Initialized
ERROR - 2011-04-13 14:42:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:42:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:42:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:42:48 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:42:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:42:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:42:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:42:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:42:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:42:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:42:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:42:48 --> Final output sent to browser
DEBUG - 2011-04-13 14:42:48 --> Total execution time: 0.0292
DEBUG - 2011-04-13 14:42:49 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:49 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Router Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Output Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Input Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:42:49 --> Language Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Loader Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Controller Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Model Class Initialized
DEBUG - 2011-04-13 14:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:42:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:42:50 --> Final output sent to browser
DEBUG - 2011-04-13 14:42:50 --> Total execution time: 0.9399
DEBUG - 2011-04-13 14:42:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:42:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:42:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:42:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:42:56 --> Router Class Initialized
ERROR - 2011-04-13 14:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:43:16 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:16 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Router Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Output Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Input Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:43:16 --> Language Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Loader Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Controller Class Initialized
ERROR - 2011-04-13 14:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:43:16 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:43:16 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:43:16 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:43:16 --> Final output sent to browser
DEBUG - 2011-04-13 14:43:16 --> Total execution time: 0.0564
DEBUG - 2011-04-13 14:43:17 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:17 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Router Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Output Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Input Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:43:17 --> Language Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Loader Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Controller Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:43:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:43:18 --> Final output sent to browser
DEBUG - 2011-04-13 14:43:18 --> Total execution time: 0.5933
DEBUG - 2011-04-13 14:43:21 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:21 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:21 --> Router Class Initialized
ERROR - 2011-04-13 14:43:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:43:32 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:32 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Router Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Output Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Input Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:43:32 --> Language Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Loader Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Controller Class Initialized
ERROR - 2011-04-13 14:43:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:43:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:43:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:43:32 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:43:32 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:43:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:43:32 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:43:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:43:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:43:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:43:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:43:32 --> Final output sent to browser
DEBUG - 2011-04-13 14:43:32 --> Total execution time: 0.0731
DEBUG - 2011-04-13 14:43:33 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:33 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Router Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Output Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Input Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:43:33 --> Language Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Loader Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Controller Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:43:33 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:43:34 --> Final output sent to browser
DEBUG - 2011-04-13 14:43:34 --> Total execution time: 0.5150
DEBUG - 2011-04-13 14:43:36 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:36 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:36 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:36 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:36 --> Router Class Initialized
ERROR - 2011-04-13 14:43:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:43:55 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:55 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Router Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Output Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Input Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:43:55 --> Language Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Loader Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Controller Class Initialized
ERROR - 2011-04-13 14:43:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:43:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:43:55 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:43:55 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:43:55 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:43:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:43:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:43:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:43:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:43:55 --> Final output sent to browser
DEBUG - 2011-04-13 14:43:55 --> Total execution time: 0.0826
DEBUG - 2011-04-13 14:43:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:43:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Router Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Output Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Input Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:43:56 --> Language Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Loader Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Controller Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:43:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:43:57 --> Final output sent to browser
DEBUG - 2011-04-13 14:43:57 --> Total execution time: 0.6103
DEBUG - 2011-04-13 14:44:00 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:00 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:00 --> Router Class Initialized
ERROR - 2011-04-13 14:44:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:44:08 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:08 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Router Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Output Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Input Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:44:08 --> Language Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Loader Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Controller Class Initialized
ERROR - 2011-04-13 14:44:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:44:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:44:08 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:44:08 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:44:08 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:44:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:44:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:44:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:44:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:44:08 --> Final output sent to browser
DEBUG - 2011-04-13 14:44:08 --> Total execution time: 0.1276
DEBUG - 2011-04-13 14:44:10 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:10 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Router Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Output Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Input Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:44:10 --> Language Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Loader Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Controller Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:44:10 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:44:11 --> Final output sent to browser
DEBUG - 2011-04-13 14:44:11 --> Total execution time: 0.6679
DEBUG - 2011-04-13 14:44:14 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:14 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:14 --> Router Class Initialized
ERROR - 2011-04-13 14:44:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:44:20 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:20 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Router Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Output Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Input Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:44:20 --> Language Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Loader Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Controller Class Initialized
ERROR - 2011-04-13 14:44:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:44:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:44:20 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:44:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:44:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:44:20 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:44:20 --> Final output sent to browser
DEBUG - 2011-04-13 14:44:20 --> Total execution time: 0.0551
DEBUG - 2011-04-13 14:44:21 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:21 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Router Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Output Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Input Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:44:21 --> Language Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Loader Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Controller Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Model Class Initialized
DEBUG - 2011-04-13 14:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:44:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:44:22 --> Final output sent to browser
DEBUG - 2011-04-13 14:44:22 --> Total execution time: 0.5235
DEBUG - 2011-04-13 14:44:26 --> Config Class Initialized
DEBUG - 2011-04-13 14:44:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:44:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:44:26 --> URI Class Initialized
DEBUG - 2011-04-13 14:44:26 --> Router Class Initialized
ERROR - 2011-04-13 14:44:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:45:17 --> Config Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:45:17 --> URI Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Router Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Output Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Input Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:45:17 --> Language Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Loader Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Controller Class Initialized
ERROR - 2011-04-13 14:45:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:45:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:45:17 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:45:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:45:17 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:45:17 --> Final output sent to browser
DEBUG - 2011-04-13 14:45:17 --> Total execution time: 0.0539
DEBUG - 2011-04-13 14:45:19 --> Config Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:45:19 --> URI Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Router Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Output Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Input Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:45:19 --> Language Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Loader Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Controller Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:45:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:45:19 --> Final output sent to browser
DEBUG - 2011-04-13 14:45:19 --> Total execution time: 0.5620
DEBUG - 2011-04-13 14:45:21 --> Config Class Initialized
DEBUG - 2011-04-13 14:45:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:45:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:45:21 --> URI Class Initialized
DEBUG - 2011-04-13 14:45:21 --> Router Class Initialized
ERROR - 2011-04-13 14:45:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:45:50 --> Config Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:45:50 --> URI Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Router Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Output Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Input Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:45:50 --> Language Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Loader Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Controller Class Initialized
ERROR - 2011-04-13 14:45:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:45:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:45:50 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:45:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:45:50 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:45:50 --> Final output sent to browser
DEBUG - 2011-04-13 14:45:50 --> Total execution time: 0.0274
DEBUG - 2011-04-13 14:45:51 --> Config Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:45:51 --> URI Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Router Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Output Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Input Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:45:51 --> Language Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Loader Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Controller Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Model Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:45:51 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:45:51 --> Final output sent to browser
DEBUG - 2011-04-13 14:45:51 --> Total execution time: 0.5698
DEBUG - 2011-04-13 14:45:53 --> Config Class Initialized
DEBUG - 2011-04-13 14:45:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:45:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:45:53 --> URI Class Initialized
DEBUG - 2011-04-13 14:45:53 --> Router Class Initialized
ERROR - 2011-04-13 14:45:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:46:08 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:08 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:08 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:08 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:08 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:08 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:08 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:08 --> Total execution time: 0.0365
DEBUG - 2011-04-13 14:46:09 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:09 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:09 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:09 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:09 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:09 --> Total execution time: 0.0672
DEBUG - 2011-04-13 14:46:11 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:11 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:11 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Controller Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:11 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:11 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:11 --> Total execution time: 0.5258
DEBUG - 2011-04-13 14:46:17 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:17 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:17 --> Router Class Initialized
ERROR - 2011-04-13 14:46:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:46:26 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:26 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:26 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:26 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:26 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:26 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:26 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:26 --> Total execution time: 0.0290
DEBUG - 2011-04-13 14:46:27 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:27 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:27 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:27 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:27 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:27 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:27 --> Total execution time: 0.0437
DEBUG - 2011-04-13 14:46:27 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:27 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:27 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Controller Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:36 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:36 --> Total execution time: 8.5253
DEBUG - 2011-04-13 14:46:37 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:37 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:37 --> Router Class Initialized
ERROR - 2011-04-13 14:46:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:46:47 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:47 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:47 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:47 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:47 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:47 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:47 --> Total execution time: 0.0332
DEBUG - 2011-04-13 14:46:48 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:48 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:48 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:48 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:48 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:48 --> Total execution time: 0.0300
DEBUG - 2011-04-13 14:46:48 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:48 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:48 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Controller Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:49 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:49 --> Total execution time: 0.5529
DEBUG - 2011-04-13 14:46:50 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:50 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:50 --> Router Class Initialized
ERROR - 2011-04-13 14:46:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:46:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:56 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:56 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:56 --> Total execution time: 0.0291
DEBUG - 2011-04-13 14:46:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:56 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Controller Class Initialized
ERROR - 2011-04-13 14:46:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:46:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:46:56 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:56 --> Total execution time: 0.0376
DEBUG - 2011-04-13 14:46:56 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:56 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:56 --> Router Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Output Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Input Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:46:57 --> Language Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Loader Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Controller Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Model Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:46:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:46:57 --> Final output sent to browser
DEBUG - 2011-04-13 14:46:57 --> Total execution time: 0.6480
DEBUG - 2011-04-13 14:46:59 --> Config Class Initialized
DEBUG - 2011-04-13 14:46:59 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:46:59 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:46:59 --> URI Class Initialized
DEBUG - 2011-04-13 14:46:59 --> Router Class Initialized
ERROR - 2011-04-13 14:46:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:47:07 --> Config Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:47:07 --> URI Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Router Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Output Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Input Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:47:07 --> Language Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Loader Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Controller Class Initialized
ERROR - 2011-04-13 14:47:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:47:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:47:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:47:07 --> Model Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Model Class Initialized
DEBUG - 2011-04-13 14:47:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:47:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:47:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:47:07 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:47:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:47:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:47:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:47:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:47:07 --> Final output sent to browser
DEBUG - 2011-04-13 14:47:07 --> Total execution time: 0.0478
DEBUG - 2011-04-13 14:47:08 --> Config Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:47:08 --> URI Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Router Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Output Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Input Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:47:08 --> Language Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Loader Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Controller Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Model Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Model Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:47:08 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:47:08 --> Final output sent to browser
DEBUG - 2011-04-13 14:47:08 --> Total execution time: 0.5613
DEBUG - 2011-04-13 14:47:09 --> Config Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:47:09 --> URI Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Router Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Output Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Input Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 14:47:09 --> Language Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Loader Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Controller Class Initialized
ERROR - 2011-04-13 14:47:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 14:47:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 14:47:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:47:09 --> Model Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Model Class Initialized
DEBUG - 2011-04-13 14:47:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 14:47:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 14:47:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 14:47:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 14:47:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 14:47:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 14:47:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 14:47:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 14:47:09 --> Final output sent to browser
DEBUG - 2011-04-13 14:47:09 --> Total execution time: 0.0540
DEBUG - 2011-04-13 14:47:10 --> Config Class Initialized
DEBUG - 2011-04-13 14:47:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:47:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:47:10 --> URI Class Initialized
DEBUG - 2011-04-13 14:47:10 --> Router Class Initialized
ERROR - 2011-04-13 14:47:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 14:49:49 --> Config Class Initialized
DEBUG - 2011-04-13 14:49:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 14:49:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 14:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 14:49:49 --> URI Class Initialized
DEBUG - 2011-04-13 14:49:49 --> Router Class Initialized
ERROR - 2011-04-13 14:49:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 15:01:30 --> Config Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:01:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:01:30 --> URI Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Router Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Output Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Input Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:01:30 --> Language Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Loader Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Controller Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:01:30 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:01:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:01:30 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:01:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:01:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:01:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:01:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:01:30 --> Final output sent to browser
DEBUG - 2011-04-13 15:01:30 --> Total execution time: 0.2464
DEBUG - 2011-04-13 15:01:33 --> Config Class Initialized
DEBUG - 2011-04-13 15:01:33 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:01:33 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:01:33 --> URI Class Initialized
DEBUG - 2011-04-13 15:01:33 --> Router Class Initialized
ERROR - 2011-04-13 15:01:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 15:01:57 --> Config Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:01:57 --> URI Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Router Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Output Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Input Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:01:57 --> Language Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Loader Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Controller Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:01:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:01:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:01:57 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:01:57 --> Final output sent to browser
DEBUG - 2011-04-13 15:01:57 --> Total execution time: 0.1899
DEBUG - 2011-04-13 15:01:58 --> Config Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:01:58 --> URI Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Router Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Output Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Input Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:01:58 --> Language Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Loader Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Controller Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Model Class Initialized
DEBUG - 2011-04-13 15:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:01:58 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:01:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:01:58 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:01:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:01:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:01:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:01:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:01:58 --> Final output sent to browser
DEBUG - 2011-04-13 15:01:58 --> Total execution time: 0.0415
DEBUG - 2011-04-13 15:02:05 --> Config Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:02:05 --> URI Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Router Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Output Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Input Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:02:05 --> Language Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Loader Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Controller Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:02:05 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:02:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:02:05 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:02:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:02:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:02:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:02:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:02:05 --> Final output sent to browser
DEBUG - 2011-04-13 15:02:05 --> Total execution time: 0.1932
DEBUG - 2011-04-13 15:02:19 --> Config Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:02:19 --> URI Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Router Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Output Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Input Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:02:19 --> Language Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Loader Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Controller Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:02:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:02:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:02:19 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:02:19 --> Final output sent to browser
DEBUG - 2011-04-13 15:02:19 --> Total execution time: 0.2351
DEBUG - 2011-04-13 15:02:20 --> Config Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:02:20 --> URI Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Router Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Output Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Input Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:02:20 --> Language Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Loader Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Controller Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:02:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:02:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:02:20 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:02:20 --> Final output sent to browser
DEBUG - 2011-04-13 15:02:20 --> Total execution time: 0.0434
DEBUG - 2011-04-13 15:02:56 --> Config Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:02:56 --> URI Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Router Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Output Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Input Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:02:56 --> Language Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Loader Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Controller Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Model Class Initialized
DEBUG - 2011-04-13 15:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:02:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:02:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:02:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:02:56 --> Final output sent to browser
DEBUG - 2011-04-13 15:02:56 --> Total execution time: 0.0521
DEBUG - 2011-04-13 15:04:38 --> Config Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:04:38 --> URI Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Router Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Output Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Input Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:04:38 --> Language Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Loader Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Controller Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Model Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Model Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Model Class Initialized
DEBUG - 2011-04-13 15:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:04:38 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:04:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:04:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:04:38 --> Final output sent to browser
DEBUG - 2011-04-13 15:04:38 --> Total execution time: 0.0770
DEBUG - 2011-04-13 15:08:37 --> Config Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:08:37 --> URI Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Router Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Output Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Input Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:08:37 --> Language Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Loader Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Controller Class Initialized
ERROR - 2011-04-13 15:08:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:08:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:08:37 --> Model Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Model Class Initialized
DEBUG - 2011-04-13 15:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:08:37 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:08:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:08:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:08:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:08:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:08:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:08:38 --> Final output sent to browser
DEBUG - 2011-04-13 15:08:38 --> Total execution time: 1.7717
DEBUG - 2011-04-13 15:08:58 --> Config Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:08:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:08:58 --> URI Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Router Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Output Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Input Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:08:58 --> Language Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Loader Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Controller Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Model Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Model Class Initialized
DEBUG - 2011-04-13 15:08:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:08:58 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:08:59 --> Final output sent to browser
DEBUG - 2011-04-13 15:08:59 --> Total execution time: 0.6335
DEBUG - 2011-04-13 15:11:12 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:12 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:12 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Controller Class Initialized
ERROR - 2011-04-13 15:11:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:11:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:11:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:12 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:11:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:11:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:11:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:11:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:11:12 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:12 --> Total execution time: 0.0318
DEBUG - 2011-04-13 15:11:12 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:12 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:12 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Controller Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:13 --> Total execution time: 0.5054
DEBUG - 2011-04-13 15:11:13 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:13 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Router Class Initialized
ERROR - 2011-04-13 15:11:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 15:11:13 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:13 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:13 --> Router Class Initialized
ERROR - 2011-04-13 15:11:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 15:11:35 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:35 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:35 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Controller Class Initialized
ERROR - 2011-04-13 15:11:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:11:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:35 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:35 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:11:35 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:35 --> Total execution time: 0.0523
DEBUG - 2011-04-13 15:11:36 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:36 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:36 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Controller Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:36 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:36 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:36 --> Total execution time: 0.6193
DEBUG - 2011-04-13 15:11:40 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:40 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:40 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Controller Class Initialized
ERROR - 2011-04-13 15:11:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:11:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:40 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:40 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:40 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:11:40 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:40 --> Total execution time: 0.0279
DEBUG - 2011-04-13 15:11:40 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:40 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:40 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Controller Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:40 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:41 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:41 --> Total execution time: 0.6208
DEBUG - 2011-04-13 15:11:42 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:42 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:42 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Controller Class Initialized
ERROR - 2011-04-13 15:11:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:42 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:42 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:42 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:11:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:11:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:11:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:11:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:11:42 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:42 --> Total execution time: 0.0545
DEBUG - 2011-04-13 15:11:45 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:45 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:45 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Controller Class Initialized
ERROR - 2011-04-13 15:11:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:11:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:45 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:11:45 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:11:45 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:45 --> Total execution time: 0.0318
DEBUG - 2011-04-13 15:11:45 --> Config Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:11:45 --> URI Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Router Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Output Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Input Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:11:45 --> Language Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Loader Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Controller Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Model Class Initialized
DEBUG - 2011-04-13 15:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:11:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:11:46 --> Final output sent to browser
DEBUG - 2011-04-13 15:11:46 --> Total execution time: 0.7003
DEBUG - 2011-04-13 15:12:12 --> Config Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:12:12 --> URI Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Router Class Initialized
DEBUG - 2011-04-13 15:12:12 --> No URI present. Default controller set.
DEBUG - 2011-04-13 15:12:12 --> Output Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Input Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:12:12 --> Language Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Loader Class Initialized
DEBUG - 2011-04-13 15:12:12 --> Controller Class Initialized
DEBUG - 2011-04-13 15:12:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 15:12:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:12:12 --> Final output sent to browser
DEBUG - 2011-04-13 15:12:12 --> Total execution time: 0.0678
DEBUG - 2011-04-13 15:12:20 --> Config Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:12:20 --> URI Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Router Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Output Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Input Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:12:20 --> Language Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Loader Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Controller Class Initialized
ERROR - 2011-04-13 15:12:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 15:12:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 15:12:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:12:20 --> Model Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Model Class Initialized
DEBUG - 2011-04-13 15:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:12:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 15:12:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:12:21 --> Final output sent to browser
DEBUG - 2011-04-13 15:12:21 --> Total execution time: 0.0339
DEBUG - 2011-04-13 15:12:21 --> Config Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:12:21 --> URI Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Router Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Output Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Input Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:12:21 --> Language Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Loader Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Controller Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Model Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Model Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:12:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:12:21 --> Final output sent to browser
DEBUG - 2011-04-13 15:12:21 --> Total execution time: 0.4588
DEBUG - 2011-04-13 15:16:39 --> Config Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:16:39 --> URI Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Router Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Output Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Input Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:16:39 --> Language Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Loader Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Controller Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Model Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Model Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Model Class Initialized
DEBUG - 2011-04-13 15:16:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 15:16:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 15:16:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 15:16:39 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:16:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:16:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:16:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:16:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:16:39 --> Final output sent to browser
DEBUG - 2011-04-13 15:16:39 --> Total execution time: 0.0907
DEBUG - 2011-04-13 15:39:08 --> Config Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 15:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 15:39:08 --> URI Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Router Class Initialized
DEBUG - 2011-04-13 15:39:08 --> No URI present. Default controller set.
DEBUG - 2011-04-13 15:39:08 --> Output Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Input Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 15:39:08 --> Language Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Loader Class Initialized
DEBUG - 2011-04-13 15:39:08 --> Controller Class Initialized
DEBUG - 2011-04-13 15:39:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 15:39:08 --> Helper loaded: url_helper
DEBUG - 2011-04-13 15:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 15:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 15:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 15:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 15:39:09 --> Final output sent to browser
DEBUG - 2011-04-13 15:39:09 --> Total execution time: 0.3825
DEBUG - 2011-04-13 17:28:02 --> Config Class Initialized
DEBUG - 2011-04-13 17:28:02 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:28:02 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:28:02 --> URI Class Initialized
DEBUG - 2011-04-13 17:28:02 --> Router Class Initialized
ERROR - 2011-04-13 17:28:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 17:42:12 --> Config Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:42:12 --> URI Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Router Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Output Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Input Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:42:12 --> Language Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Loader Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Controller Class Initialized
ERROR - 2011-04-13 17:42:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 17:42:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 17:42:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:42:12 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:42:12 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:42:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:42:12 --> Helper loaded: url_helper
DEBUG - 2011-04-13 17:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 17:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 17:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 17:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 17:42:12 --> Final output sent to browser
DEBUG - 2011-04-13 17:42:12 --> Total execution time: 0.4417
DEBUG - 2011-04-13 17:42:13 --> Config Class Initialized
DEBUG - 2011-04-13 17:42:13 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:42:13 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:42:13 --> URI Class Initialized
DEBUG - 2011-04-13 17:42:13 --> Router Class Initialized
DEBUG - 2011-04-13 17:42:13 --> Output Class Initialized
DEBUG - 2011-04-13 17:42:13 --> Input Class Initialized
DEBUG - 2011-04-13 17:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:42:13 --> Language Class Initialized
DEBUG - 2011-04-13 17:42:14 --> Loader Class Initialized
DEBUG - 2011-04-13 17:42:14 --> Controller Class Initialized
DEBUG - 2011-04-13 17:42:14 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:14 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:42:14 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:42:14 --> Final output sent to browser
DEBUG - 2011-04-13 17:42:14 --> Total execution time: 0.9656
DEBUG - 2011-04-13 17:42:15 --> Config Class Initialized
DEBUG - 2011-04-13 17:42:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:42:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:42:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:42:15 --> URI Class Initialized
DEBUG - 2011-04-13 17:42:15 --> Router Class Initialized
ERROR - 2011-04-13 17:42:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 17:42:46 --> Config Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:42:46 --> URI Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Router Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Output Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Input Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:42:46 --> Language Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Loader Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Controller Class Initialized
ERROR - 2011-04-13 17:42:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 17:42:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 17:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:42:46 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:42:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:42:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 17:42:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 17:42:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 17:42:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 17:42:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 17:42:46 --> Final output sent to browser
DEBUG - 2011-04-13 17:42:46 --> Total execution time: 0.0585
DEBUG - 2011-04-13 17:42:47 --> Config Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:42:47 --> URI Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Router Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Output Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Input Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:42:47 --> Language Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Loader Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Controller Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Model Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:42:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:42:47 --> Final output sent to browser
DEBUG - 2011-04-13 17:42:47 --> Total execution time: 0.4921
DEBUG - 2011-04-13 17:42:48 --> Config Class Initialized
DEBUG - 2011-04-13 17:42:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:42:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:42:48 --> URI Class Initialized
DEBUG - 2011-04-13 17:42:48 --> Router Class Initialized
ERROR - 2011-04-13 17:42:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 17:43:06 --> Config Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:43:06 --> URI Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Router Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Output Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Input Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:43:06 --> Language Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Loader Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Controller Class Initialized
ERROR - 2011-04-13 17:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 17:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 17:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:43:06 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:43:06 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:43:06 --> Helper loaded: url_helper
DEBUG - 2011-04-13 17:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 17:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 17:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 17:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 17:43:06 --> Final output sent to browser
DEBUG - 2011-04-13 17:43:06 --> Total execution time: 0.0333
DEBUG - 2011-04-13 17:43:07 --> Config Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:43:07 --> URI Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Router Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Output Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Input Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:43:07 --> Language Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Loader Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Controller Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:43:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:43:08 --> Final output sent to browser
DEBUG - 2011-04-13 17:43:08 --> Total execution time: 0.6792
DEBUG - 2011-04-13 17:43:09 --> Config Class Initialized
DEBUG - 2011-04-13 17:43:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:43:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:43:09 --> URI Class Initialized
DEBUG - 2011-04-13 17:43:09 --> Router Class Initialized
ERROR - 2011-04-13 17:43:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 17:43:55 --> Config Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:43:55 --> URI Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Router Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Output Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Input Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:43:55 --> Language Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Loader Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Controller Class Initialized
ERROR - 2011-04-13 17:43:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 17:43:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 17:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:43:55 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:43:55 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 17:43:55 --> Helper loaded: url_helper
DEBUG - 2011-04-13 17:43:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 17:43:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 17:43:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 17:43:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 17:43:55 --> Final output sent to browser
DEBUG - 2011-04-13 17:43:55 --> Total execution time: 0.0305
DEBUG - 2011-04-13 17:43:56 --> Config Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:43:56 --> URI Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Router Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Output Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Input Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:43:56 --> Language Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Loader Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Controller Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Model Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 17:43:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 17:43:56 --> Final output sent to browser
DEBUG - 2011-04-13 17:43:56 --> Total execution time: 0.6811
DEBUG - 2011-04-13 17:43:57 --> Config Class Initialized
DEBUG - 2011-04-13 17:43:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:43:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:43:57 --> URI Class Initialized
DEBUG - 2011-04-13 17:43:57 --> Router Class Initialized
ERROR - 2011-04-13 17:43:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 17:57:02 --> Config Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-13 17:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 17:57:02 --> URI Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Router Class Initialized
DEBUG - 2011-04-13 17:57:02 --> No URI present. Default controller set.
DEBUG - 2011-04-13 17:57:02 --> Output Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Input Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 17:57:02 --> Language Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Loader Class Initialized
DEBUG - 2011-04-13 17:57:02 --> Controller Class Initialized
DEBUG - 2011-04-13 17:57:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-13 17:57:02 --> Helper loaded: url_helper
DEBUG - 2011-04-13 17:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 17:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 17:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 17:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 17:57:02 --> Final output sent to browser
DEBUG - 2011-04-13 17:57:02 --> Total execution time: 0.0936
DEBUG - 2011-04-13 18:02:28 --> Config Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:02:28 --> URI Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Router Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Output Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Input Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:02:28 --> Language Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Loader Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Controller Class Initialized
ERROR - 2011-04-13 18:02:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:02:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:02:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:02:28 --> Model Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Model Class Initialized
DEBUG - 2011-04-13 18:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:02:28 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:02:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:02:28 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:02:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:02:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:02:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:02:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:02:28 --> Final output sent to browser
DEBUG - 2011-04-13 18:02:28 --> Total execution time: 0.0525
DEBUG - 2011-04-13 18:02:29 --> Config Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:02:29 --> URI Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Router Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Output Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Input Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:02:29 --> Language Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Loader Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Controller Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Model Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Model Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:02:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:02:29 --> Final output sent to browser
DEBUG - 2011-04-13 18:02:29 --> Total execution time: 0.4666
DEBUG - 2011-04-13 18:02:30 --> Config Class Initialized
DEBUG - 2011-04-13 18:02:30 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:02:30 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:02:30 --> URI Class Initialized
DEBUG - 2011-04-13 18:02:30 --> Router Class Initialized
ERROR - 2011-04-13 18:02:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:03:21 --> Config Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:03:21 --> URI Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Router Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Output Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Input Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:03:21 --> Language Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Loader Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Controller Class Initialized
ERROR - 2011-04-13 18:03:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:03:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:03:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:03:21 --> Model Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Model Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:03:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:03:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:03:21 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:03:21 --> Final output sent to browser
DEBUG - 2011-04-13 18:03:21 --> Total execution time: 0.0828
DEBUG - 2011-04-13 18:03:21 --> Config Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:03:21 --> URI Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Router Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Output Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Input Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:03:21 --> Language Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Loader Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Controller Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Model Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Model Class Initialized
DEBUG - 2011-04-13 18:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:03:21 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:03:22 --> Final output sent to browser
DEBUG - 2011-04-13 18:03:22 --> Total execution time: 0.9758
DEBUG - 2011-04-13 18:03:23 --> Config Class Initialized
DEBUG - 2011-04-13 18:03:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:03:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:03:23 --> URI Class Initialized
DEBUG - 2011-04-13 18:03:23 --> Router Class Initialized
ERROR - 2011-04-13 18:03:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:04:39 --> Config Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:04:39 --> URI Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Router Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Output Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Input Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:04:39 --> Language Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Loader Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Controller Class Initialized
ERROR - 2011-04-13 18:04:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:04:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:04:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:04:39 --> Model Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Model Class Initialized
DEBUG - 2011-04-13 18:04:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:04:39 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:04:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:04:40 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:04:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:04:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:04:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:04:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:04:40 --> Final output sent to browser
DEBUG - 2011-04-13 18:04:40 --> Total execution time: 0.0588
DEBUG - 2011-04-13 18:04:40 --> Config Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:04:40 --> URI Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Router Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Output Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Input Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:04:40 --> Language Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Loader Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Controller Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Model Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Model Class Initialized
DEBUG - 2011-04-13 18:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:04:40 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:04:41 --> Final output sent to browser
DEBUG - 2011-04-13 18:04:41 --> Total execution time: 0.7688
DEBUG - 2011-04-13 18:04:41 --> Config Class Initialized
DEBUG - 2011-04-13 18:04:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:04:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:04:41 --> URI Class Initialized
DEBUG - 2011-04-13 18:04:41 --> Router Class Initialized
ERROR - 2011-04-13 18:04:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:05:07 --> Config Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:05:07 --> URI Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Router Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Output Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Input Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:05:07 --> Language Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Loader Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Controller Class Initialized
ERROR - 2011-04-13 18:05:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:05:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:05:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:05:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:05:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:05:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:05:07 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:05:07 --> Final output sent to browser
DEBUG - 2011-04-13 18:05:07 --> Total execution time: 0.0478
DEBUG - 2011-04-13 18:05:07 --> Config Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:05:07 --> URI Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Router Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Output Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Input Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:05:07 --> Language Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Loader Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Controller Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:05:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:05:08 --> Final output sent to browser
DEBUG - 2011-04-13 18:05:08 --> Total execution time: 0.8322
DEBUG - 2011-04-13 18:05:09 --> Config Class Initialized
DEBUG - 2011-04-13 18:05:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:05:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:05:09 --> URI Class Initialized
DEBUG - 2011-04-13 18:05:09 --> Router Class Initialized
ERROR - 2011-04-13 18:05:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:05:56 --> Config Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:05:56 --> URI Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Router Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Output Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Input Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:05:56 --> Language Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Loader Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Controller Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:05:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:05:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 18:05:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:05:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:05:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:05:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:05:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:05:56 --> Final output sent to browser
DEBUG - 2011-04-13 18:05:56 --> Total execution time: 0.4045
DEBUG - 2011-04-13 18:06:00 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:00 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:00 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Controller Class Initialized
ERROR - 2011-04-13 18:06:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:06:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:06:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:00 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:00 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:06:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:06:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:06:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:06:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:06:00 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:00 --> Total execution time: 0.0339
DEBUG - 2011-04-13 18:06:01 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:01 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:01 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Controller Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:01 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:01 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:01 --> Total execution time: 0.6034
DEBUG - 2011-04-13 18:06:02 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:02 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:02 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:02 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:02 --> Router Class Initialized
ERROR - 2011-04-13 18:06:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:06:08 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:09 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:09 --> Router Class Initialized
ERROR - 2011-04-13 18:06:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:06:09 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:09 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:09 --> Router Class Initialized
ERROR - 2011-04-13 18:06:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:06:19 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:19 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:19 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Controller Class Initialized
ERROR - 2011-04-13 18:06:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:06:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:19 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:19 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:06:19 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:19 --> Total execution time: 0.0422
DEBUG - 2011-04-13 18:06:19 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:19 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:19 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Controller Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:20 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:20 --> Total execution time: 0.6645
DEBUG - 2011-04-13 18:06:20 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:20 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:20 --> Router Class Initialized
ERROR - 2011-04-13 18:06:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:06:26 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:26 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:26 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Controller Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:26 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 18:06:26 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:06:26 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:26 --> Total execution time: 0.2671
DEBUG - 2011-04-13 18:06:33 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:33 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:33 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Controller Class Initialized
ERROR - 2011-04-13 18:06:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:06:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:33 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:33 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:33 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:06:33 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:33 --> Total execution time: 0.0771
DEBUG - 2011-04-13 18:06:34 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:34 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:34 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Controller Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:34 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:34 --> Total execution time: 0.5612
DEBUG - 2011-04-13 18:06:35 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:35 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:35 --> Router Class Initialized
ERROR - 2011-04-13 18:06:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:06:46 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:46 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:46 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Controller Class Initialized
ERROR - 2011-04-13 18:06:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:06:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:06:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:46 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:46 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:46 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:06:46 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:46 --> Total execution time: 0.0313
DEBUG - 2011-04-13 18:06:47 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:47 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:47 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Controller Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:47 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:47 --> Total execution time: 0.6514
DEBUG - 2011-04-13 18:06:48 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:48 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:48 --> Router Class Initialized
ERROR - 2011-04-13 18:06:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:06:56 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:56 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:56 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Controller Class Initialized
ERROR - 2011-04-13 18:06:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:06:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:06:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:06:56 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:56 --> Total execution time: 0.0294
DEBUG - 2011-04-13 18:06:56 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:56 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Router Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Output Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Input Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:06:56 --> Language Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Loader Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Controller Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:06:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:06:57 --> Final output sent to browser
DEBUG - 2011-04-13 18:06:57 --> Total execution time: 0.5266
DEBUG - 2011-04-13 18:06:58 --> Config Class Initialized
DEBUG - 2011-04-13 18:06:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:06:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:06:58 --> URI Class Initialized
DEBUG - 2011-04-13 18:06:58 --> Router Class Initialized
ERROR - 2011-04-13 18:06:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:07:03 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:03 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Router Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Output Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Input Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:07:03 --> Language Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Loader Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Controller Class Initialized
ERROR - 2011-04-13 18:07:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:07:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:07:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:07:03 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:07:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:07:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:07:03 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:07:03 --> Final output sent to browser
DEBUG - 2011-04-13 18:07:03 --> Total execution time: 0.0518
DEBUG - 2011-04-13 18:07:03 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:03 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Router Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Output Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Input Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:07:03 --> Language Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Loader Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Controller Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:07:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:07:04 --> Final output sent to browser
DEBUG - 2011-04-13 18:07:04 --> Total execution time: 0.5165
DEBUG - 2011-04-13 18:07:04 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:04 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:04 --> Router Class Initialized
ERROR - 2011-04-13 18:07:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:07:07 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:07 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Router Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Output Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Input Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:07:07 --> Language Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Loader Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Controller Class Initialized
ERROR - 2011-04-13 18:07:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:07:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:07:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:07:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:07:07 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:07:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:07:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:07:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:07:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:07:07 --> Final output sent to browser
DEBUG - 2011-04-13 18:07:07 --> Total execution time: 0.0446
DEBUG - 2011-04-13 18:07:07 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:07 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Router Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Output Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Input Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:07:07 --> Language Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Loader Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Controller Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:07:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:07:08 --> Final output sent to browser
DEBUG - 2011-04-13 18:07:08 --> Total execution time: 0.7729
DEBUG - 2011-04-13 18:07:09 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:09 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:09 --> Router Class Initialized
ERROR - 2011-04-13 18:07:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:07:11 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:11 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Router Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Output Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Input Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:07:11 --> Language Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Loader Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Controller Class Initialized
ERROR - 2011-04-13 18:07:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:07:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:07:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:07:11 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:07:11 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:07:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:07:11 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:07:11 --> Final output sent to browser
DEBUG - 2011-04-13 18:07:11 --> Total execution time: 0.1375
DEBUG - 2011-04-13 18:07:11 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:11 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Router Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Output Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Input Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:07:11 --> Language Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Loader Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Controller Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Model Class Initialized
DEBUG - 2011-04-13 18:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:07:11 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:07:12 --> Final output sent to browser
DEBUG - 2011-04-13 18:07:12 --> Total execution time: 0.5481
DEBUG - 2011-04-13 18:07:12 --> Config Class Initialized
DEBUG - 2011-04-13 18:07:12 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:07:12 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:07:12 --> URI Class Initialized
DEBUG - 2011-04-13 18:07:12 --> Router Class Initialized
ERROR - 2011-04-13 18:07:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:08:20 --> Config Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:08:20 --> URI Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Router Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Output Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Input Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:08:20 --> Language Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Loader Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Controller Class Initialized
ERROR - 2011-04-13 18:08:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:08:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:08:20 --> Model Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Model Class Initialized
DEBUG - 2011-04-13 18:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:08:20 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:08:20 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:08:20 --> Final output sent to browser
DEBUG - 2011-04-13 18:08:20 --> Total execution time: 0.0357
DEBUG - 2011-04-13 18:08:24 --> Config Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:08:24 --> URI Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Router Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Output Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Input Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:08:24 --> Language Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Loader Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Controller Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Model Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Model Class Initialized
DEBUG - 2011-04-13 18:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:08:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:08:31 --> Final output sent to browser
DEBUG - 2011-04-13 18:08:31 --> Total execution time: 6.5572
DEBUG - 2011-04-13 18:39:47 --> Config Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:39:47 --> URI Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Router Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Output Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Input Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:39:47 --> Language Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Loader Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Controller Class Initialized
ERROR - 2011-04-13 18:39:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:39:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:39:47 --> Model Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Model Class Initialized
DEBUG - 2011-04-13 18:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:39:47 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:39:47 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:39:47 --> Final output sent to browser
DEBUG - 2011-04-13 18:39:47 --> Total execution time: 0.2815
DEBUG - 2011-04-13 18:39:49 --> Config Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:39:49 --> URI Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Router Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Output Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Input Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:39:49 --> Language Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Loader Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Controller Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Model Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Model Class Initialized
DEBUG - 2011-04-13 18:39:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:39:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:39:50 --> Final output sent to browser
DEBUG - 2011-04-13 18:39:50 --> Total execution time: 0.5900
DEBUG - 2011-04-13 18:39:51 --> Config Class Initialized
DEBUG - 2011-04-13 18:39:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:39:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:39:51 --> URI Class Initialized
DEBUG - 2011-04-13 18:39:51 --> Router Class Initialized
ERROR - 2011-04-13 18:39:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 18:40:22 --> Config Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:40:22 --> URI Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Router Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Output Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Input Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:40:22 --> Language Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Loader Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Controller Class Initialized
ERROR - 2011-04-13 18:40:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:40:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:40:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:40:22 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:40:22 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:40:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:40:22 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:40:22 --> Final output sent to browser
DEBUG - 2011-04-13 18:40:22 --> Total execution time: 0.0768
DEBUG - 2011-04-13 18:40:23 --> Config Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:40:23 --> URI Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Router Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Output Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Input Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:40:23 --> Language Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Loader Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Controller Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:40:23 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:40:24 --> Final output sent to browser
DEBUG - 2011-04-13 18:40:24 --> Total execution time: 0.6469
DEBUG - 2011-04-13 18:40:33 --> Config Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:40:33 --> URI Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Router Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Output Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Input Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:40:33 --> Language Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Loader Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Controller Class Initialized
ERROR - 2011-04-13 18:40:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:40:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:40:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:40:33 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:40:33 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:40:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:40:33 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:40:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:40:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:40:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:40:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:40:33 --> Final output sent to browser
DEBUG - 2011-04-13 18:40:33 --> Total execution time: 0.0714
DEBUG - 2011-04-13 18:40:34 --> Config Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:40:34 --> URI Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Router Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Output Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Input Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:40:34 --> Language Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Loader Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Controller Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:40:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:40:35 --> Final output sent to browser
DEBUG - 2011-04-13 18:40:35 --> Total execution time: 0.8143
DEBUG - 2011-04-13 18:40:51 --> Config Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:40:51 --> URI Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Router Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Output Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Input Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:40:51 --> Language Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Loader Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Controller Class Initialized
ERROR - 2011-04-13 18:40:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:40:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:40:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:40:51 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:40:51 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:40:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:40:51 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:40:51 --> Final output sent to browser
DEBUG - 2011-04-13 18:40:51 --> Total execution time: 0.0317
DEBUG - 2011-04-13 18:40:52 --> Config Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:40:52 --> URI Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Router Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Output Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Input Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:40:52 --> Language Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Loader Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Controller Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Model Class Initialized
DEBUG - 2011-04-13 18:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:40:52 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:40:53 --> Final output sent to browser
DEBUG - 2011-04-13 18:40:53 --> Total execution time: 0.5808
DEBUG - 2011-04-13 18:41:00 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:00 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:00 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Controller Class Initialized
ERROR - 2011-04-13 18:41:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:41:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:00 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:00 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:41:00 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:00 --> Total execution time: 0.0279
DEBUG - 2011-04-13 18:41:00 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:00 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:00 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Controller Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:00 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:01 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:01 --> Total execution time: 0.5718
DEBUG - 2011-04-13 18:41:27 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:27 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:27 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Controller Class Initialized
ERROR - 2011-04-13 18:41:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:41:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:41:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:27 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:27 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:41:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:41:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:41:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:41:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:41:27 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:27 --> Total execution time: 0.0320
DEBUG - 2011-04-13 18:41:28 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:28 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:28 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Controller Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:29 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:29 --> Total execution time: 0.6533
DEBUG - 2011-04-13 18:41:49 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:49 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:49 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Controller Class Initialized
ERROR - 2011-04-13 18:41:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:41:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:41:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:49 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:49 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:41:49 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:49 --> Total execution time: 0.0334
DEBUG - 2011-04-13 18:41:50 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:50 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:50 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Controller Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:50 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:50 --> Total execution time: 0.5238
DEBUG - 2011-04-13 18:41:56 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:56 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:56 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Controller Class Initialized
ERROR - 2011-04-13 18:41:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:41:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:41:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:41:56 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:56 --> Total execution time: 0.0303
DEBUG - 2011-04-13 18:41:57 --> Config Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:41:57 --> URI Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Router Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Output Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Input Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:41:57 --> Language Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Loader Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Controller Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Model Class Initialized
DEBUG - 2011-04-13 18:41:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:41:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:41:58 --> Final output sent to browser
DEBUG - 2011-04-13 18:41:58 --> Total execution time: 0.4550
DEBUG - 2011-04-13 18:42:04 --> Config Class Initialized
DEBUG - 2011-04-13 18:42:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:42:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:42:04 --> URI Class Initialized
DEBUG - 2011-04-13 18:42:04 --> Router Class Initialized
DEBUG - 2011-04-13 18:42:04 --> Output Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Input Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:42:05 --> Language Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Loader Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Controller Class Initialized
ERROR - 2011-04-13 18:42:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:42:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:42:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:42:05 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:42:05 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:42:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:42:05 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:42:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:42:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:42:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:42:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:42:05 --> Final output sent to browser
DEBUG - 2011-04-13 18:42:05 --> Total execution time: 0.0545
DEBUG - 2011-04-13 18:42:05 --> Config Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:42:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:42:05 --> URI Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Router Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Output Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Input Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:42:05 --> Language Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Loader Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Controller Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:42:05 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:42:06 --> Final output sent to browser
DEBUG - 2011-04-13 18:42:06 --> Total execution time: 0.5596
DEBUG - 2011-04-13 18:42:15 --> Config Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:42:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:42:15 --> URI Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Router Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Output Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Input Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:42:15 --> Language Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Loader Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Controller Class Initialized
ERROR - 2011-04-13 18:42:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:42:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:42:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:42:15 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:42:15 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:42:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:42:15 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:42:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:42:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:42:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:42:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:42:15 --> Final output sent to browser
DEBUG - 2011-04-13 18:42:15 --> Total execution time: 0.0571
DEBUG - 2011-04-13 18:42:16 --> Config Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:42:16 --> URI Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Router Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Output Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Input Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:42:16 --> Language Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Loader Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Controller Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:42:16 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:42:17 --> Final output sent to browser
DEBUG - 2011-04-13 18:42:17 --> Total execution time: 0.6021
DEBUG - 2011-04-13 18:42:27 --> Config Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:42:27 --> URI Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Router Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Output Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Input Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:42:27 --> Language Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Loader Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Controller Class Initialized
ERROR - 2011-04-13 18:42:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:42:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:42:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:42:27 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:42:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:42:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:42:27 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:42:27 --> Final output sent to browser
DEBUG - 2011-04-13 18:42:27 --> Total execution time: 0.0293
DEBUG - 2011-04-13 18:42:27 --> Config Class Initialized
DEBUG - 2011-04-13 18:42:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:42:28 --> URI Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Router Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Output Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Input Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:42:28 --> Language Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Loader Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Controller Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Model Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:42:28 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:42:28 --> Final output sent to browser
DEBUG - 2011-04-13 18:42:28 --> Total execution time: 0.5168
DEBUG - 2011-04-13 18:59:42 --> Config Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:59:42 --> URI Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Router Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Output Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Input Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:59:42 --> Language Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Loader Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Controller Class Initialized
ERROR - 2011-04-13 18:59:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:59:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:59:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:59:42 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:59:42 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:59:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:59:42 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:59:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:59:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:59:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:59:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:59:42 --> Final output sent to browser
DEBUG - 2011-04-13 18:59:42 --> Total execution time: 0.0649
DEBUG - 2011-04-13 18:59:43 --> Config Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:59:43 --> URI Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Router Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Output Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Input Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:59:43 --> Language Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Loader Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Controller Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:59:43 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:59:44 --> Final output sent to browser
DEBUG - 2011-04-13 18:59:44 --> Total execution time: 0.7463
DEBUG - 2011-04-13 18:59:48 --> Config Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:59:48 --> URI Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Router Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Output Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Input Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:59:48 --> Language Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Loader Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Controller Class Initialized
ERROR - 2011-04-13 18:59:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:59:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:59:48 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:59:48 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:59:48 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:59:48 --> Final output sent to browser
DEBUG - 2011-04-13 18:59:48 --> Total execution time: 0.0386
DEBUG - 2011-04-13 18:59:49 --> Config Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:59:49 --> URI Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Router Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Output Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Input Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:59:49 --> Language Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Loader Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Controller Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:59:49 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:59:50 --> Final output sent to browser
DEBUG - 2011-04-13 18:59:50 --> Total execution time: 0.6691
DEBUG - 2011-04-13 18:59:55 --> Config Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:59:55 --> URI Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Router Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Output Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Input Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:59:55 --> Language Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Loader Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Controller Class Initialized
ERROR - 2011-04-13 18:59:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 18:59:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 18:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:59:55 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:59:55 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 18:59:55 --> Helper loaded: url_helper
DEBUG - 2011-04-13 18:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 18:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 18:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 18:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 18:59:55 --> Final output sent to browser
DEBUG - 2011-04-13 18:59:55 --> Total execution time: 0.0324
DEBUG - 2011-04-13 18:59:55 --> Config Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 18:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 18:59:55 --> URI Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Router Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Output Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Input Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 18:59:55 --> Language Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Loader Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Controller Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Model Class Initialized
DEBUG - 2011-04-13 18:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 18:59:55 --> Database Driver Class Initialized
DEBUG - 2011-04-13 18:59:56 --> Final output sent to browser
DEBUG - 2011-04-13 18:59:56 --> Total execution time: 0.5158
DEBUG - 2011-04-13 19:00:03 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:03 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:03 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Controller Class Initialized
ERROR - 2011-04-13 19:00:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:00:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:03 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:03 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:00:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:00:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:00:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:00:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:00:03 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:03 --> Total execution time: 0.2687
DEBUG - 2011-04-13 19:00:04 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:05 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:05 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Controller Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:05 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:05 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:05 --> Total execution time: 0.8491
DEBUG - 2011-04-13 19:00:09 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:09 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:09 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Controller Class Initialized
ERROR - 2011-04-13 19:00:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:00:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:00:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:00:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:00:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:00:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:00:09 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:09 --> Total execution time: 0.1186
DEBUG - 2011-04-13 19:00:10 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:10 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:10 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Controller Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:10 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:11 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:11 --> Total execution time: 0.6837
DEBUG - 2011-04-13 19:00:14 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:14 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:14 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Controller Class Initialized
ERROR - 2011-04-13 19:00:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:00:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:00:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:14 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:15 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:15 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:00:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:00:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:00:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:00:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:00:15 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:15 --> Total execution time: 0.0283
DEBUG - 2011-04-13 19:00:15 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:15 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:15 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Controller Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:15 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:16 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:16 --> Total execution time: 0.5339
DEBUG - 2011-04-13 19:00:29 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:29 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:29 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Controller Class Initialized
ERROR - 2011-04-13 19:00:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:00:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:00:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:29 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:29 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:00:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:00:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:00:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:00:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:00:29 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:29 --> Total execution time: 0.0305
DEBUG - 2011-04-13 19:00:30 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:30 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:30 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Controller Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:30 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:30 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:30 --> Total execution time: 0.5088
DEBUG - 2011-04-13 19:00:40 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:40 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:40 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Controller Class Initialized
ERROR - 2011-04-13 19:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:40 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:40 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:40 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:00:40 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:40 --> Total execution time: 0.0280
DEBUG - 2011-04-13 19:00:41 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:41 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:41 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Controller Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:41 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:41 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:41 --> Total execution time: 0.5984
DEBUG - 2011-04-13 19:00:56 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:56 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:56 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Controller Class Initialized
ERROR - 2011-04-13 19:00:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:00:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:00:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:56 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:00:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:00:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:00:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:00:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:00:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:00:56 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:56 --> Total execution time: 0.0399
DEBUG - 2011-04-13 19:00:57 --> Config Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:00:57 --> URI Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Router Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Output Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Input Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:00:57 --> Language Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Loader Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Controller Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Model Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:00:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:00:57 --> Final output sent to browser
DEBUG - 2011-04-13 19:00:57 --> Total execution time: 0.5708
DEBUG - 2011-04-13 19:11:09 --> Config Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:11:09 --> URI Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Router Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Output Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Input Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:11:09 --> Language Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Loader Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Controller Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Model Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Model Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Model Class Initialized
DEBUG - 2011-04-13 19:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:11:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:11:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 19:11:10 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:11:10 --> Final output sent to browser
DEBUG - 2011-04-13 19:11:10 --> Total execution time: 0.5206
DEBUG - 2011-04-13 19:11:18 --> Config Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:11:18 --> URI Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Router Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Output Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Input Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:11:18 --> Language Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Loader Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Controller Class Initialized
ERROR - 2011-04-13 19:11:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:11:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:11:18 --> Model Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Model Class Initialized
DEBUG - 2011-04-13 19:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:11:18 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:11:18 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:11:18 --> Final output sent to browser
DEBUG - 2011-04-13 19:11:18 --> Total execution time: 0.0453
DEBUG - 2011-04-13 19:12:25 --> Config Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:12:25 --> URI Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Router Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Output Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Input Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:12:25 --> Language Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Loader Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Controller Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Model Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Model Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Model Class Initialized
DEBUG - 2011-04-13 19:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:12:25 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:12:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 19:12:25 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:12:25 --> Final output sent to browser
DEBUG - 2011-04-13 19:12:25 --> Total execution time: 0.0555
DEBUG - 2011-04-13 19:12:30 --> Config Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:12:30 --> URI Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Router Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Output Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Input Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:12:30 --> Language Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Loader Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Controller Class Initialized
ERROR - 2011-04-13 19:12:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:12:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:12:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:12:30 --> Model Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Model Class Initialized
DEBUG - 2011-04-13 19:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:12:30 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:12:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:12:30 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:12:30 --> Final output sent to browser
DEBUG - 2011-04-13 19:12:30 --> Total execution time: 0.0275
DEBUG - 2011-04-13 19:17:27 --> Config Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:17:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:17:27 --> URI Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Router Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Output Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Input Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:17:27 --> Language Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Loader Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Controller Class Initialized
ERROR - 2011-04-13 19:17:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 19:17:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 19:17:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:17:27 --> Model Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Model Class Initialized
DEBUG - 2011-04-13 19:17:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:17:27 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:17:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 19:17:27 --> Helper loaded: url_helper
DEBUG - 2011-04-13 19:17:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 19:17:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 19:17:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 19:17:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 19:17:27 --> Final output sent to browser
DEBUG - 2011-04-13 19:17:27 --> Total execution time: 0.0305
DEBUG - 2011-04-13 19:17:28 --> Config Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 19:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 19:17:28 --> URI Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Router Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Output Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Input Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 19:17:28 --> Language Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Loader Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Controller Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Model Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Model Class Initialized
DEBUG - 2011-04-13 19:17:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 19:17:28 --> Database Driver Class Initialized
DEBUG - 2011-04-13 19:17:29 --> Final output sent to browser
DEBUG - 2011-04-13 19:17:29 --> Total execution time: 0.4991
DEBUG - 2011-04-13 20:03:45 --> Config Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Hooks Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Utf8 Class Initialized
DEBUG - 2011-04-13 20:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 20:03:45 --> URI Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Router Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Output Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Input Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 20:03:45 --> Language Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Loader Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Controller Class Initialized
ERROR - 2011-04-13 20:03:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 20:03:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 20:03:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 20:03:45 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 20:03:45 --> Database Driver Class Initialized
DEBUG - 2011-04-13 20:03:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 20:03:45 --> Helper loaded: url_helper
DEBUG - 2011-04-13 20:03:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 20:03:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 20:03:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 20:03:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 20:03:46 --> Final output sent to browser
DEBUG - 2011-04-13 20:03:46 --> Total execution time: 0.1988
DEBUG - 2011-04-13 20:03:53 --> Config Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 20:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 20:03:53 --> URI Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Router Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Output Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Input Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 20:03:53 --> Language Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Loader Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Controller Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 20:03:53 --> Database Driver Class Initialized
DEBUG - 2011-04-13 20:03:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 20:03:54 --> Helper loaded: url_helper
DEBUG - 2011-04-13 20:03:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 20:03:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 20:03:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 20:03:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 20:03:54 --> Final output sent to browser
DEBUG - 2011-04-13 20:03:54 --> Total execution time: 0.7375
DEBUG - 2011-04-13 20:03:55 --> Config Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Hooks Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Utf8 Class Initialized
DEBUG - 2011-04-13 20:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 20:03:55 --> URI Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Router Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Output Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Input Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 20:03:55 --> Language Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Loader Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Controller Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 20:03:55 --> Database Driver Class Initialized
DEBUG - 2011-04-13 20:03:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 20:03:55 --> Helper loaded: url_helper
DEBUG - 2011-04-13 20:03:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 20:03:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 20:03:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 20:03:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 20:03:55 --> Final output sent to browser
DEBUG - 2011-04-13 20:03:55 --> Total execution time: 0.0469
DEBUG - 2011-04-13 20:03:56 --> Config Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 20:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 20:03:56 --> URI Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Router Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Output Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Input Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 20:03:56 --> Language Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Loader Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Controller Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 20:03:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 20:03:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 20:03:56 --> Final output sent to browser
DEBUG - 2011-04-13 20:03:56 --> Total execution time: 0.0465
DEBUG - 2011-04-13 20:03:56 --> Config Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 20:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 20:03:56 --> URI Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Router Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Output Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Input Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 20:03:56 --> Language Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Loader Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Controller Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 20:03:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 20:03:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 20:03:56 --> Final output sent to browser
DEBUG - 2011-04-13 20:03:56 --> Total execution time: 0.0461
DEBUG - 2011-04-13 20:03:56 --> Config Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 20:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 20:03:56 --> URI Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Router Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Output Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Input Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 20:03:56 --> Language Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Loader Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Controller Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Model Class Initialized
DEBUG - 2011-04-13 20:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 20:03:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 20:03:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 20:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 20:03:56 --> Final output sent to browser
DEBUG - 2011-04-13 20:03:56 --> Total execution time: 0.0447
DEBUG - 2011-04-13 21:00:29 --> Config Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Hooks Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Utf8 Class Initialized
DEBUG - 2011-04-13 21:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 21:00:29 --> URI Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Router Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Output Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Input Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 21:00:29 --> Language Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Loader Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Controller Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Model Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Model Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Model Class Initialized
DEBUG - 2011-04-13 21:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 21:00:29 --> Database Driver Class Initialized
DEBUG - 2011-04-13 21:00:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 21:00:29 --> Helper loaded: url_helper
DEBUG - 2011-04-13 21:00:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 21:00:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 21:00:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 21:00:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 21:00:29 --> Final output sent to browser
DEBUG - 2011-04-13 21:00:29 --> Total execution time: 0.5901
DEBUG - 2011-04-13 21:01:04 --> Config Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 21:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 21:01:04 --> URI Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Router Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Output Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Input Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 21:01:04 --> Language Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Loader Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Controller Class Initialized
ERROR - 2011-04-13 21:01:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 21:01:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 21:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 21:01:04 --> Model Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Model Class Initialized
DEBUG - 2011-04-13 21:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 21:01:04 --> Database Driver Class Initialized
DEBUG - 2011-04-13 21:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 21:01:04 --> Helper loaded: url_helper
DEBUG - 2011-04-13 21:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 21:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 21:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 21:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 21:01:04 --> Final output sent to browser
DEBUG - 2011-04-13 21:01:04 --> Total execution time: 0.1196
DEBUG - 2011-04-13 21:54:08 --> Config Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 21:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 21:54:08 --> URI Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Router Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Output Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Input Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 21:54:08 --> Language Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Loader Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Controller Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Model Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Model Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Model Class Initialized
DEBUG - 2011-04-13 21:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 21:54:08 --> Database Driver Class Initialized
DEBUG - 2011-04-13 21:54:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-13 21:54:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 21:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 21:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 21:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 21:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 21:54:09 --> Final output sent to browser
DEBUG - 2011-04-13 21:54:09 --> Total execution time: 0.9890
DEBUG - 2011-04-13 21:54:34 --> Config Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 21:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 21:54:34 --> URI Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Router Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Output Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Input Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 21:54:34 --> Language Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Loader Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Controller Class Initialized
ERROR - 2011-04-13 21:54:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 21:54:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 21:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 21:54:34 --> Model Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Model Class Initialized
DEBUG - 2011-04-13 21:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 21:54:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 21:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 21:54:34 --> Helper loaded: url_helper
DEBUG - 2011-04-13 21:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 21:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 21:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 21:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 21:54:34 --> Final output sent to browser
DEBUG - 2011-04-13 21:54:34 --> Total execution time: 0.0906
DEBUG - 2011-04-13 22:00:24 --> Config Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:00:24 --> URI Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Router Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Output Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Input Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:00:24 --> Language Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Loader Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Controller Class Initialized
ERROR - 2011-04-13 22:00:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:00:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:00:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:00:24 --> Model Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Model Class Initialized
DEBUG - 2011-04-13 22:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:00:24 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:00:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:00:24 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:00:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:00:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:00:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:00:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:00:24 --> Final output sent to browser
DEBUG - 2011-04-13 22:00:24 --> Total execution time: 0.0472
DEBUG - 2011-04-13 22:00:25 --> Config Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:00:25 --> URI Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Router Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Output Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Input Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:00:25 --> Language Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Loader Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Controller Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Model Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Model Class Initialized
DEBUG - 2011-04-13 22:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:00:25 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:00:26 --> Final output sent to browser
DEBUG - 2011-04-13 22:00:26 --> Total execution time: 0.6725
DEBUG - 2011-04-13 22:00:28 --> Config Class Initialized
DEBUG - 2011-04-13 22:00:28 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:00:28 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:00:28 --> URI Class Initialized
DEBUG - 2011-04-13 22:00:28 --> Router Class Initialized
ERROR - 2011-04-13 22:00:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 22:00:30 --> Config Class Initialized
DEBUG - 2011-04-13 22:00:30 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:00:30 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:00:30 --> URI Class Initialized
DEBUG - 2011-04-13 22:00:30 --> Router Class Initialized
ERROR - 2011-04-13 22:00:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 22:01:56 --> Config Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:01:56 --> URI Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Router Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Output Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Input Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:01:56 --> Language Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Loader Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Controller Class Initialized
ERROR - 2011-04-13 22:01:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:01:56 --> Model Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Model Class Initialized
DEBUG - 2011-04-13 22:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:01:56 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:01:56 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:01:56 --> Final output sent to browser
DEBUG - 2011-04-13 22:01:56 --> Total execution time: 0.0427
DEBUG - 2011-04-13 22:01:57 --> Config Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:01:57 --> URI Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Router Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Output Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Input Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:01:57 --> Language Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Loader Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Controller Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Model Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Model Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:01:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:01:57 --> Final output sent to browser
DEBUG - 2011-04-13 22:01:57 --> Total execution time: 0.5643
DEBUG - 2011-04-13 22:02:06 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:06 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:06 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:06 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:06 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:06 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:06 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:06 --> Total execution time: 0.0323
DEBUG - 2011-04-13 22:02:07 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:07 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:07 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:07 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:08 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:08 --> Total execution time: 0.6890
DEBUG - 2011-04-13 22:02:18 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:18 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:18 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:18 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:18 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:18 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:18 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:18 --> Total execution time: 0.0290
DEBUG - 2011-04-13 22:02:19 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:19 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:19 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:19 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:20 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:20 --> Total execution time: 0.5364
DEBUG - 2011-04-13 22:02:25 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:25 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:25 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:25 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:25 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:25 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:25 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:25 --> Total execution time: 0.0297
DEBUG - 2011-04-13 22:02:26 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:26 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:26 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:26 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:26 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:26 --> Total execution time: 0.6370
DEBUG - 2011-04-13 22:02:34 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:34 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:34 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:34 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:34 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:34 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:34 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:34 --> Total execution time: 0.0293
DEBUG - 2011-04-13 22:02:35 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:35 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:35 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:35 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:36 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:36 --> Total execution time: 1.3210
DEBUG - 2011-04-13 22:02:40 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:40 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:40 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:40 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:40 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:40 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:40 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:40 --> Total execution time: 0.0858
DEBUG - 2011-04-13 22:02:41 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:41 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:41 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:41 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:41 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:41 --> Total execution time: 0.5220
DEBUG - 2011-04-13 22:02:52 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:52 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:52 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:52 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:52 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:52 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:52 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:52 --> Total execution time: 0.0393
DEBUG - 2011-04-13 22:02:53 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:53 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:53 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:53 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:55 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:55 --> Total execution time: 1.3320
DEBUG - 2011-04-13 22:02:57 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:57 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:57 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Controller Class Initialized
ERROR - 2011-04-13 22:02:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:02:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:02:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:57 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:57 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:02:57 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:02:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:02:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:02:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:02:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:02:57 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:57 --> Total execution time: 0.0976
DEBUG - 2011-04-13 22:02:58 --> Config Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:02:58 --> URI Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Router Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Output Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Input Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:02:58 --> Language Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Loader Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Controller Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Model Class Initialized
DEBUG - 2011-04-13 22:02:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:02:58 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:02:59 --> Final output sent to browser
DEBUG - 2011-04-13 22:02:59 --> Total execution time: 0.5873
DEBUG - 2011-04-13 22:03:03 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:03 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Router Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Output Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Input Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:03:03 --> Language Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Loader Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Controller Class Initialized
ERROR - 2011-04-13 22:03:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:03:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:03 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:03:03 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:03 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:03:03 --> Final output sent to browser
DEBUG - 2011-04-13 22:03:03 --> Total execution time: 0.0313
DEBUG - 2011-04-13 22:03:04 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:04 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Router Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Output Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Input Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:03:04 --> Language Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Loader Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Controller Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:03:04 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:04 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:04 --> Router Class Initialized
ERROR - 2011-04-13 22:03:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-13 22:03:04 --> Final output sent to browser
DEBUG - 2011-04-13 22:03:04 --> Total execution time: 0.7293
DEBUG - 2011-04-13 22:03:05 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:05 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Router Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Output Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Input Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:03:05 --> Language Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Loader Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Controller Class Initialized
ERROR - 2011-04-13 22:03:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:03:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:05 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:03:05 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:03:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:05 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:03:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:03:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:03:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:03:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:03:05 --> Final output sent to browser
DEBUG - 2011-04-13 22:03:05 --> Total execution time: 0.0393
DEBUG - 2011-04-13 22:03:08 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:08 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Router Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Output Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Input Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:03:08 --> Language Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Loader Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Controller Class Initialized
ERROR - 2011-04-13 22:03:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:03:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:08 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:03:08 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:08 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:03:08 --> Final output sent to browser
DEBUG - 2011-04-13 22:03:08 --> Total execution time: 0.0310
DEBUG - 2011-04-13 22:03:09 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:09 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Router Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Output Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Input Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:03:09 --> Language Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Loader Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Controller Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:03:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Config Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:03:09 --> URI Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Router Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Output Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Input Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:03:09 --> Language Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Loader Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Controller Class Initialized
ERROR - 2011-04-13 22:03:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:03:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:09 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Model Class Initialized
DEBUG - 2011-04-13 22:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:03:09 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:03:09 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:03:09 --> Final output sent to browser
DEBUG - 2011-04-13 22:03:09 --> Total execution time: 0.0384
DEBUG - 2011-04-13 22:03:10 --> Final output sent to browser
DEBUG - 2011-04-13 22:03:10 --> Total execution time: 0.5974
DEBUG - 2011-04-13 22:30:16 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:16 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:16 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Controller Class Initialized
ERROR - 2011-04-13 22:30:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:30:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:30:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:16 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:16 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:16 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:30:16 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:16 --> Total execution time: 0.2800
DEBUG - 2011-04-13 22:30:17 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:17 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:17 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Controller Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:17 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:18 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:18 --> Total execution time: 0.6033
DEBUG - 2011-04-13 22:30:19 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:19 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:19 --> Router Class Initialized
ERROR - 2011-04-13 22:30:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 22:30:19 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:19 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:19 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:19 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:19 --> Router Class Initialized
ERROR - 2011-04-13 22:30:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 22:30:21 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:21 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:21 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:21 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:21 --> Router Class Initialized
ERROR - 2011-04-13 22:30:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-13 22:30:31 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:31 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:31 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Controller Class Initialized
ERROR - 2011-04-13 22:30:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:30:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:30:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:31 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:31 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:31 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:30:31 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:31 --> Total execution time: 0.0301
DEBUG - 2011-04-13 22:30:31 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:31 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:31 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Controller Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:31 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:32 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:32 --> Total execution time: 0.5708
DEBUG - 2011-04-13 22:30:38 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:38 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:38 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Controller Class Initialized
ERROR - 2011-04-13 22:30:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:38 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:38 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:38 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:30:38 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:38 --> Total execution time: 0.0300
DEBUG - 2011-04-13 22:30:38 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:38 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:38 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Controller Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:38 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:39 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:39 --> Total execution time: 0.6188
DEBUG - 2011-04-13 22:30:43 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:43 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:43 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Controller Class Initialized
ERROR - 2011-04-13 22:30:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:30:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:43 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:43 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:43 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:30:43 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:43 --> Total execution time: 0.0277
DEBUG - 2011-04-13 22:30:44 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:44 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:44 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Controller Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:44 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:44 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:44 --> Total execution time: 0.7294
DEBUG - 2011-04-13 22:30:50 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:50 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:50 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Controller Class Initialized
ERROR - 2011-04-13 22:30:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-13 22:30:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-13 22:30:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-13 22:30:50 --> Helper loaded: url_helper
DEBUG - 2011-04-13 22:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-13 22:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-13 22:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-13 22:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-13 22:30:50 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:50 --> Total execution time: 0.0359
DEBUG - 2011-04-13 22:30:50 --> Config Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-13 22:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-13 22:30:50 --> URI Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Router Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Output Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Input Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-13 22:30:50 --> Language Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Loader Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Controller Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Model Class Initialized
DEBUG - 2011-04-13 22:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-13 22:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-13 22:30:51 --> Final output sent to browser
DEBUG - 2011-04-13 22:30:51 --> Total execution time: 0.9264

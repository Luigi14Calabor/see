<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-10 00:49:44 --> Config Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:49:44 --> URI Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Router Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Output Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Input Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:49:44 --> Language Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Loader Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Controller Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:49:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:49:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:49:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:49:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:49:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:49:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:49:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:49:44 --> Final output sent to browser
DEBUG - 2011-09-10 00:49:44 --> Total execution time: 0.5990
DEBUG - 2011-09-10 00:49:47 --> Config Class Initialized
DEBUG - 2011-09-10 00:49:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:49:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:49:47 --> URI Class Initialized
DEBUG - 2011-09-10 00:49:47 --> Router Class Initialized
ERROR - 2011-09-10 00:49:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 00:49:47 --> Config Class Initialized
DEBUG - 2011-09-10 00:49:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:49:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:49:47 --> URI Class Initialized
DEBUG - 2011-09-10 00:49:47 --> Router Class Initialized
ERROR - 2011-09-10 00:49:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 00:49:54 --> Config Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:49:54 --> URI Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Router Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Output Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Input Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:49:54 --> Language Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Loader Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Controller Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:49:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:49:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:49:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:49:54 --> Final output sent to browser
DEBUG - 2011-09-10 00:49:54 --> Total execution time: 0.3808
DEBUG - 2011-09-10 00:49:56 --> Config Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:49:56 --> URI Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Router Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Output Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Input Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:49:56 --> Language Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Loader Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Controller Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Model Class Initialized
DEBUG - 2011-09-10 00:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:49:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:49:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:49:56 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:49:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:49:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:49:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:49:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:49:56 --> Final output sent to browser
DEBUG - 2011-09-10 00:49:56 --> Total execution time: 0.0490
DEBUG - 2011-09-10 00:50:12 --> Config Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:50:12 --> URI Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Router Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Output Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Input Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:50:12 --> Language Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Loader Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Controller Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:50:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:50:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:50:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:50:15 --> Final output sent to browser
DEBUG - 2011-09-10 00:50:15 --> Total execution time: 3.1830
DEBUG - 2011-09-10 00:50:16 --> Config Class Initialized
DEBUG - 2011-09-10 00:50:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:50:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:50:16 --> URI Class Initialized
DEBUG - 2011-09-10 00:50:16 --> Router Class Initialized
DEBUG - 2011-09-10 00:50:16 --> Output Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Input Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:50:17 --> Language Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Loader Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Controller Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:50:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:50:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:50:17 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:50:17 --> Final output sent to browser
DEBUG - 2011-09-10 00:50:17 --> Total execution time: 0.0519
DEBUG - 2011-09-10 00:50:30 --> Config Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:50:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:50:30 --> URI Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Router Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Output Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Input Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:50:30 --> Language Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Loader Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Controller Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:50:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:50:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:50:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:50:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:50:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:50:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:50:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:50:30 --> Final output sent to browser
DEBUG - 2011-09-10 00:50:30 --> Total execution time: 0.2766
DEBUG - 2011-09-10 00:50:31 --> Config Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 00:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 00:50:31 --> URI Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Router Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Output Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Input Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 00:50:31 --> Language Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Loader Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Controller Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Model Class Initialized
DEBUG - 2011-09-10 00:50:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 00:50:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 00:50:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 00:50:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 00:50:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 00:50:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 00:50:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 00:50:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 00:50:31 --> Final output sent to browser
DEBUG - 2011-09-10 00:50:31 --> Total execution time: 0.0524
DEBUG - 2011-09-10 01:08:13 --> Config Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:08:13 --> URI Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Router Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Output Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Input Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 01:08:13 --> Language Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Loader Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Controller Class Initialized
ERROR - 2011-09-10 01:08:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 01:08:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 01:08:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 01:08:13 --> Model Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Model Class Initialized
DEBUG - 2011-09-10 01:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 01:08:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 01:08:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 01:08:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 01:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 01:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 01:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 01:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 01:08:13 --> Final output sent to browser
DEBUG - 2011-09-10 01:08:13 --> Total execution time: 0.0501
DEBUG - 2011-09-10 01:10:14 --> Config Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:10:14 --> URI Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Router Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Output Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Input Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 01:10:14 --> Language Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Loader Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Controller Class Initialized
ERROR - 2011-09-10 01:10:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 01:10:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 01:10:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 01:10:14 --> Model Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Model Class Initialized
DEBUG - 2011-09-10 01:10:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 01:10:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 01:10:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 01:10:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 01:10:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 01:10:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 01:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 01:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 01:10:14 --> Final output sent to browser
DEBUG - 2011-09-10 01:10:14 --> Total execution time: 0.0285
DEBUG - 2011-09-10 01:10:15 --> Config Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:10:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:10:15 --> URI Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Router Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Output Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Input Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 01:10:15 --> Language Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Loader Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Controller Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Model Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Model Class Initialized
DEBUG - 2011-09-10 01:10:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 01:10:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 01:10:16 --> Final output sent to browser
DEBUG - 2011-09-10 01:10:16 --> Total execution time: 1.0865
DEBUG - 2011-09-10 01:10:18 --> Config Class Initialized
DEBUG - 2011-09-10 01:10:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:10:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:10:18 --> URI Class Initialized
DEBUG - 2011-09-10 01:10:18 --> Router Class Initialized
ERROR - 2011-09-10 01:10:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 01:10:18 --> Config Class Initialized
DEBUG - 2011-09-10 01:10:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:10:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:10:18 --> URI Class Initialized
DEBUG - 2011-09-10 01:10:18 --> Router Class Initialized
ERROR - 2011-09-10 01:10:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 01:10:19 --> Config Class Initialized
DEBUG - 2011-09-10 01:10:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:10:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:10:19 --> URI Class Initialized
DEBUG - 2011-09-10 01:10:19 --> Router Class Initialized
ERROR - 2011-09-10 01:10:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 01:17:42 --> Config Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 01:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 01:17:42 --> URI Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Router Class Initialized
DEBUG - 2011-09-10 01:17:42 --> No URI present. Default controller set.
DEBUG - 2011-09-10 01:17:42 --> Output Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Input Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 01:17:42 --> Language Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Loader Class Initialized
DEBUG - 2011-09-10 01:17:42 --> Controller Class Initialized
DEBUG - 2011-09-10 01:17:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 01:17:42 --> Helper loaded: url_helper
DEBUG - 2011-09-10 01:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 01:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 01:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 01:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 01:17:42 --> Final output sent to browser
DEBUG - 2011-09-10 01:17:42 --> Total execution time: 0.0485
DEBUG - 2011-09-10 03:05:13 --> Config Class Initialized
DEBUG - 2011-09-10 03:05:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 03:05:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 03:05:13 --> URI Class Initialized
DEBUG - 2011-09-10 03:05:13 --> Router Class Initialized
DEBUG - 2011-09-10 03:05:13 --> No URI present. Default controller set.
DEBUG - 2011-09-10 03:05:13 --> Output Class Initialized
DEBUG - 2011-09-10 03:05:13 --> Input Class Initialized
DEBUG - 2011-09-10 03:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 03:05:13 --> Language Class Initialized
DEBUG - 2011-09-10 03:05:14 --> Loader Class Initialized
DEBUG - 2011-09-10 03:05:14 --> Controller Class Initialized
DEBUG - 2011-09-10 03:05:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 03:05:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 03:05:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 03:05:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 03:05:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 03:05:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 03:05:14 --> Final output sent to browser
DEBUG - 2011-09-10 03:05:14 --> Total execution time: 0.9824
DEBUG - 2011-09-10 03:23:25 --> Config Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 03:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 03:23:25 --> URI Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Router Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Output Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Input Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 03:23:25 --> Language Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Loader Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Controller Class Initialized
DEBUG - 2011-09-10 03:23:25 --> Model Class Initialized
DEBUG - 2011-09-10 03:23:26 --> Model Class Initialized
DEBUG - 2011-09-10 03:23:26 --> Model Class Initialized
DEBUG - 2011-09-10 03:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 03:23:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 03:23:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 03:23:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 03:23:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 03:23:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 03:23:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 03:23:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 03:23:27 --> Final output sent to browser
DEBUG - 2011-09-10 03:23:27 --> Total execution time: 1.4791
DEBUG - 2011-09-10 03:25:29 --> Config Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 03:25:29 --> URI Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Router Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Output Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Input Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 03:25:29 --> Language Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Loader Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Controller Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Model Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Model Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Model Class Initialized
DEBUG - 2011-09-10 03:25:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 03:25:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 03:25:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 03:25:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 03:25:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 03:25:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 03:25:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 03:25:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 03:25:33 --> Final output sent to browser
DEBUG - 2011-09-10 03:25:33 --> Total execution time: 3.7209
DEBUG - 2011-09-10 03:25:51 --> Config Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 03:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 03:25:51 --> URI Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Router Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Output Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Input Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 03:25:51 --> Language Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Loader Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Controller Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Model Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Model Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Model Class Initialized
DEBUG - 2011-09-10 03:25:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 03:25:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 03:25:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 03:25:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 03:25:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 03:25:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 03:25:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 03:25:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 03:25:51 --> Final output sent to browser
DEBUG - 2011-09-10 03:25:51 --> Total execution time: 0.0476
DEBUG - 2011-09-10 04:34:55 --> Config Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:34:55 --> URI Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Router Class Initialized
DEBUG - 2011-09-10 04:34:55 --> No URI present. Default controller set.
DEBUG - 2011-09-10 04:34:55 --> Output Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Input Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:34:55 --> Language Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Loader Class Initialized
DEBUG - 2011-09-10 04:34:55 --> Controller Class Initialized
DEBUG - 2011-09-10 04:34:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 04:34:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 04:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 04:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 04:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 04:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 04:34:55 --> Final output sent to browser
DEBUG - 2011-09-10 04:34:55 --> Total execution time: 0.1668
DEBUG - 2011-09-10 04:36:32 --> Config Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:36:32 --> URI Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Router Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Output Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Input Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:36:32 --> Language Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Loader Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Controller Class Initialized
ERROR - 2011-09-10 04:36:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 04:36:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 04:36:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:36:32 --> Model Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Model Class Initialized
DEBUG - 2011-09-10 04:36:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:36:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:36:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:36:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 04:36:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 04:36:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 04:36:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 04:36:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 04:36:32 --> Final output sent to browser
DEBUG - 2011-09-10 04:36:32 --> Total execution time: 0.4898
DEBUG - 2011-09-10 04:38:01 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:01 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Router Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Output Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Input Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:38:01 --> Language Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Loader Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Controller Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:38:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:38:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 04:38:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 04:38:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 04:38:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 04:38:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 04:38:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 04:38:03 --> Final output sent to browser
DEBUG - 2011-09-10 04:38:03 --> Total execution time: 1.2738
DEBUG - 2011-09-10 04:38:05 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:05 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:05 --> Router Class Initialized
ERROR - 2011-09-10 04:38:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 04:38:05 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:05 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:05 --> Router Class Initialized
ERROR - 2011-09-10 04:38:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 04:38:07 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:07 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:07 --> Router Class Initialized
ERROR - 2011-09-10 04:38:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 04:38:13 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:13 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Router Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Output Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Input Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:38:13 --> Language Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Loader Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Controller Class Initialized
ERROR - 2011-09-10 04:38:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 04:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 04:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:38:13 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:38:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:38:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 04:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 04:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 04:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 04:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 04:38:13 --> Final output sent to browser
DEBUG - 2011-09-10 04:38:13 --> Total execution time: 0.0315
DEBUG - 2011-09-10 04:38:14 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:14 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Router Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Output Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Input Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:38:14 --> Language Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Loader Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Controller Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:38:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:38:15 --> Final output sent to browser
DEBUG - 2011-09-10 04:38:15 --> Total execution time: 0.7718
DEBUG - 2011-09-10 04:38:42 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:42 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Router Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Output Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Input Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:38:42 --> Language Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Loader Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Controller Class Initialized
ERROR - 2011-09-10 04:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 04:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 04:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:38:42 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:38:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:38:42 --> Helper loaded: url_helper
DEBUG - 2011-09-10 04:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 04:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 04:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 04:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 04:38:42 --> Final output sent to browser
DEBUG - 2011-09-10 04:38:42 --> Total execution time: 0.0275
DEBUG - 2011-09-10 04:38:43 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:43 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Router Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Output Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Input Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:38:43 --> Language Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Loader Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Controller Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:38:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Config Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 04:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 04:38:44 --> URI Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Router Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Output Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Input Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 04:38:44 --> Language Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Loader Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Controller Class Initialized
ERROR - 2011-09-10 04:38:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 04:38:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 04:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:38:44 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Model Class Initialized
DEBUG - 2011-09-10 04:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 04:38:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 04:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 04:38:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 04:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 04:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 04:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 04:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 04:38:44 --> Final output sent to browser
DEBUG - 2011-09-10 04:38:44 --> Total execution time: 0.0297
DEBUG - 2011-09-10 04:38:45 --> Final output sent to browser
DEBUG - 2011-09-10 04:38:45 --> Total execution time: 1.7830
DEBUG - 2011-09-10 05:18:42 --> Config Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:18:42 --> URI Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Router Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Output Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Input Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:18:42 --> Language Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Loader Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Controller Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Model Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Model Class Initialized
DEBUG - 2011-09-10 05:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:18:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:18:43 --> Final output sent to browser
DEBUG - 2011-09-10 05:18:43 --> Total execution time: 1.0228
DEBUG - 2011-09-10 05:29:07 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:07 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Router Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Output Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Input Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:29:07 --> Language Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Loader Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Controller Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:29:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:29:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:29:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:29:08 --> Final output sent to browser
DEBUG - 2011-09-10 05:29:08 --> Total execution time: 0.8317
DEBUG - 2011-09-10 05:29:12 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:12 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:12 --> Router Class Initialized
ERROR - 2011-09-10 05:29:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:29:19 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:19 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Router Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Output Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Input Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:29:19 --> Language Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Loader Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Controller Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:29:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:29:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:29:19 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:29:19 --> Final output sent to browser
DEBUG - 2011-09-10 05:29:19 --> Total execution time: 0.0479
DEBUG - 2011-09-10 05:29:21 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:21 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Router Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Output Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Input Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:29:21 --> Language Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Loader Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Controller Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:29:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:29:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:29:21 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:29:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:29:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:29:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:29:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:29:21 --> Final output sent to browser
DEBUG - 2011-09-10 05:29:21 --> Total execution time: 0.0731
DEBUG - 2011-09-10 05:29:21 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:21 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:21 --> Router Class Initialized
ERROR - 2011-09-10 05:29:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:29:30 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:30 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Router Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Output Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Input Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:29:30 --> Language Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Loader Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Controller Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:29:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:29:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:29:31 --> Final output sent to browser
DEBUG - 2011-09-10 05:29:31 --> Total execution time: 0.3313
DEBUG - 2011-09-10 05:29:32 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:32 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Router Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Output Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Input Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:29:32 --> Language Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Loader Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Controller Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Model Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:29:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:29:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:29:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:29:32 --> Final output sent to browser
DEBUG - 2011-09-10 05:29:32 --> Total execution time: 0.0427
DEBUG - 2011-09-10 05:29:32 --> Config Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:29:32 --> URI Class Initialized
DEBUG - 2011-09-10 05:29:32 --> Router Class Initialized
ERROR - 2011-09-10 05:29:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:30:03 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:03 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:03 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:30:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:30:05 --> Final output sent to browser
DEBUG - 2011-09-10 05:30:05 --> Total execution time: 1.8676
DEBUG - 2011-09-10 05:30:07 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:07 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Router Class Initialized
ERROR - 2011-09-10 05:30:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:30:07 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:07 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:07 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:30:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:30:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:30:08 --> Final output sent to browser
DEBUG - 2011-09-10 05:30:08 --> Total execution time: 0.4236
DEBUG - 2011-09-10 05:30:11 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:11 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:11 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:30:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:30:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:30:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:30:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:30:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:30:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:30:15 --> Final output sent to browser
DEBUG - 2011-09-10 05:30:15 --> Total execution time: 3.4096
DEBUG - 2011-09-10 05:30:17 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:17 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:17 --> Router Class Initialized
ERROR - 2011-09-10 05:30:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:30:34 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:34 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:34 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:30:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:30:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:30:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:30:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:30:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:30:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:30:35 --> Final output sent to browser
DEBUG - 2011-09-10 05:30:35 --> Total execution time: 0.2816
DEBUG - 2011-09-10 05:30:37 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:37 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:37 --> Router Class Initialized
ERROR - 2011-09-10 05:30:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:30:42 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:42 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:42 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:30:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:30:43 --> Final output sent to browser
DEBUG - 2011-09-10 05:30:43 --> Total execution time: 0.1513
DEBUG - 2011-09-10 05:30:56 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:56 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:56 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:30:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:30:56 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:30:56 --> Final output sent to browser
DEBUG - 2011-09-10 05:30:56 --> Total execution time: 0.0771
DEBUG - 2011-09-10 05:30:59 --> Config Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:30:59 --> URI Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Router Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Output Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Input Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:30:59 --> Language Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Loader Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Controller Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Model Class Initialized
DEBUG - 2011-09-10 05:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:30:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:00 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:00 --> Total execution time: 1.0794
DEBUG - 2011-09-10 05:31:01 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:01 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:01 --> Router Class Initialized
ERROR - 2011-09-10 05:31:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:31:14 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:14 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:14 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:14 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:14 --> Total execution time: 0.0467
DEBUG - 2011-09-10 05:31:15 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:15 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:15 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:16 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:16 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:16 --> Total execution time: 0.2697
DEBUG - 2011-09-10 05:31:17 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:17 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:17 --> Router Class Initialized
ERROR - 2011-09-10 05:31:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:31:23 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:23 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:23 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:23 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:23 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:23 --> Total execution time: 0.0700
DEBUG - 2011-09-10 05:31:30 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:30 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:30 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:31 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:31 --> Total execution time: 0.4123
DEBUG - 2011-09-10 05:31:32 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:32 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:32 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:32 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:32 --> Total execution time: 0.0543
DEBUG - 2011-09-10 05:31:33 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:33 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:33 --> Router Class Initialized
ERROR - 2011-09-10 05:31:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:31:41 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:41 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:41 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:41 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:41 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:41 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:41 --> Total execution time: 0.3903
DEBUG - 2011-09-10 05:31:43 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:43 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:43 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:31:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:31:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:31:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:31:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:31:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:31:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:31:43 --> Final output sent to browser
DEBUG - 2011-09-10 05:31:43 --> Total execution time: 0.0536
DEBUG - 2011-09-10 05:31:43 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:43 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:43 --> Router Class Initialized
ERROR - 2011-09-10 05:31:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:31:59 --> Config Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:31:59 --> URI Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Router Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Output Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Input Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:31:59 --> Language Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Loader Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Controller Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Model Class Initialized
DEBUG - 2011-09-10 05:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:31:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:32:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:32:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:32:00 --> Final output sent to browser
DEBUG - 2011-09-10 05:32:00 --> Total execution time: 0.2244
DEBUG - 2011-09-10 05:32:01 --> Config Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:32:01 --> URI Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Router Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Output Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Input Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:32:01 --> Language Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Loader Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Controller Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Model Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Model Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Model Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:32:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:32:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:32:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:32:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:32:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:32:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:32:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:32:01 --> Final output sent to browser
DEBUG - 2011-09-10 05:32:01 --> Total execution time: 0.0517
DEBUG - 2011-09-10 05:32:01 --> Config Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:32:01 --> URI Class Initialized
DEBUG - 2011-09-10 05:32:01 --> Router Class Initialized
ERROR - 2011-09-10 05:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 05:46:10 --> Config Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:46:10 --> URI Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Router Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Output Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Input Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:46:10 --> Language Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Loader Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Controller Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Model Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Model Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Model Class Initialized
DEBUG - 2011-09-10 05:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:46:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:46:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 05:46:10 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:46:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:46:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:46:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:46:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:46:10 --> Final output sent to browser
DEBUG - 2011-09-10 05:46:10 --> Total execution time: 0.0858
DEBUG - 2011-09-10 05:46:11 --> Config Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 05:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 05:46:11 --> URI Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Router Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Output Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Input Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 05:46:11 --> Language Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Loader Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Controller Class Initialized
ERROR - 2011-09-10 05:46:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 05:46:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 05:46:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 05:46:11 --> Model Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Model Class Initialized
DEBUG - 2011-09-10 05:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 05:46:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 05:46:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 05:46:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 05:46:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 05:46:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 05:46:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 05:46:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 05:46:11 --> Final output sent to browser
DEBUG - 2011-09-10 05:46:11 --> Total execution time: 0.0874
DEBUG - 2011-09-10 06:19:45 --> Config Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 06:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 06:19:45 --> URI Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Router Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Output Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Input Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 06:19:45 --> Language Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Loader Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Controller Class Initialized
ERROR - 2011-09-10 06:19:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 06:19:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 06:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 06:19:45 --> Model Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Model Class Initialized
DEBUG - 2011-09-10 06:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 06:19:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 06:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 06:19:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 06:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 06:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 06:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 06:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 06:19:46 --> Final output sent to browser
DEBUG - 2011-09-10 06:19:46 --> Total execution time: 0.6333
DEBUG - 2011-09-10 06:19:47 --> Config Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 06:19:47 --> URI Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Router Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Output Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Input Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 06:19:47 --> Language Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Loader Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Controller Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Model Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Model Class Initialized
DEBUG - 2011-09-10 06:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 06:19:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 06:19:48 --> Final output sent to browser
DEBUG - 2011-09-10 06:19:48 --> Total execution time: 0.9120
DEBUG - 2011-09-10 06:19:51 --> Config Class Initialized
DEBUG - 2011-09-10 06:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 06:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 06:19:51 --> URI Class Initialized
DEBUG - 2011-09-10 06:19:51 --> Router Class Initialized
ERROR - 2011-09-10 06:19:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 06:19:51 --> Config Class Initialized
DEBUG - 2011-09-10 06:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 06:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 06:19:51 --> URI Class Initialized
DEBUG - 2011-09-10 06:19:51 --> Router Class Initialized
ERROR - 2011-09-10 06:19:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 06:19:52 --> Config Class Initialized
DEBUG - 2011-09-10 06:19:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 06:19:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 06:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 06:19:52 --> URI Class Initialized
DEBUG - 2011-09-10 06:19:52 --> Router Class Initialized
ERROR - 2011-09-10 06:19:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 07:21:12 --> Config Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:21:12 --> URI Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Router Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Output Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Input Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:21:12 --> Language Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Loader Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Controller Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Model Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Model Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Model Class Initialized
DEBUG - 2011-09-10 07:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:21:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:21:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 07:21:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:21:13 --> Final output sent to browser
DEBUG - 2011-09-10 07:21:13 --> Total execution time: 0.8909
DEBUG - 2011-09-10 07:21:15 --> Config Class Initialized
DEBUG - 2011-09-10 07:21:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:21:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:21:15 --> URI Class Initialized
DEBUG - 2011-09-10 07:21:15 --> Router Class Initialized
ERROR - 2011-09-10 07:21:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 07:26:06 --> Config Class Initialized
DEBUG - 2011-09-10 07:26:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:26:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:26:06 --> URI Class Initialized
DEBUG - 2011-09-10 07:26:06 --> Router Class Initialized
ERROR - 2011-09-10 07:26:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 07:26:09 --> Config Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:26:09 --> URI Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Router Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Output Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Input Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:26:09 --> Language Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Loader Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Controller Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Model Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Model Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Model Class Initialized
DEBUG - 2011-09-10 07:26:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:26:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:26:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 07:26:09 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:26:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:26:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:26:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:26:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:26:09 --> Final output sent to browser
DEBUG - 2011-09-10 07:26:09 --> Total execution time: 0.0838
DEBUG - 2011-09-10 07:27:56 --> Config Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:27:56 --> URI Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Router Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Output Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Input Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:27:56 --> Language Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Loader Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Controller Class Initialized
ERROR - 2011-09-10 07:27:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 07:27:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 07:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:27:56 --> Model Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Model Class Initialized
DEBUG - 2011-09-10 07:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:27:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:27:56 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:27:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:27:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:27:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:27:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:27:56 --> Final output sent to browser
DEBUG - 2011-09-10 07:27:56 --> Total execution time: 0.0881
DEBUG - 2011-09-10 07:35:30 --> Config Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:35:30 --> URI Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Router Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Output Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Input Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:35:30 --> Language Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Loader Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Controller Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Model Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Model Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Model Class Initialized
DEBUG - 2011-09-10 07:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:35:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 07:35:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:35:30 --> Final output sent to browser
DEBUG - 2011-09-10 07:35:30 --> Total execution time: 0.0622
DEBUG - 2011-09-10 07:36:34 --> Config Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:36:34 --> URI Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Router Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Output Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Input Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:36:34 --> Language Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Loader Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Controller Class Initialized
ERROR - 2011-09-10 07:36:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 07:36:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 07:36:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:36:34 --> Model Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Model Class Initialized
DEBUG - 2011-09-10 07:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:36:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:36:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:36:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:36:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:36:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:36:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:36:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:36:34 --> Final output sent to browser
DEBUG - 2011-09-10 07:36:34 --> Total execution time: 0.0290
DEBUG - 2011-09-10 07:37:03 --> Config Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:37:03 --> URI Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Router Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Output Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Input Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:37:03 --> Language Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Loader Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Controller Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Model Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Model Class Initialized
DEBUG - 2011-09-10 07:37:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:37:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:37:04 --> Final output sent to browser
DEBUG - 2011-09-10 07:37:04 --> Total execution time: 0.6724
DEBUG - 2011-09-10 07:44:55 --> Config Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:44:55 --> URI Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Router Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Output Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Input Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:44:55 --> Language Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Loader Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Controller Class Initialized
ERROR - 2011-09-10 07:44:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 07:44:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 07:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:44:55 --> Model Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Model Class Initialized
DEBUG - 2011-09-10 07:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:44:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:44:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:44:55 --> Final output sent to browser
DEBUG - 2011-09-10 07:44:55 --> Total execution time: 0.0293
DEBUG - 2011-09-10 07:55:02 --> Config Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 07:55:02 --> URI Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Router Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Output Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Input Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 07:55:02 --> Language Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Loader Class Initialized
DEBUG - 2011-09-10 07:55:02 --> Controller Class Initialized
ERROR - 2011-09-10 07:55:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 07:55:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 07:55:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:55:02 --> Model Class Initialized
DEBUG - 2011-09-10 07:55:03 --> Model Class Initialized
DEBUG - 2011-09-10 07:55:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 07:55:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 07:55:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 07:55:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 07:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 07:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 07:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 07:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 07:55:04 --> Final output sent to browser
DEBUG - 2011-09-10 07:55:04 --> Total execution time: 2.2643
DEBUG - 2011-09-10 08:09:18 --> Config Class Initialized
DEBUG - 2011-09-10 08:09:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:09:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:09:18 --> URI Class Initialized
DEBUG - 2011-09-10 08:09:18 --> Router Class Initialized
ERROR - 2011-09-10 08:09:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 08:10:57 --> Config Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:10:57 --> URI Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Router Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Output Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Input Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:10:57 --> Language Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Loader Class Initialized
DEBUG - 2011-09-10 08:10:57 --> Controller Class Initialized
ERROR - 2011-09-10 08:10:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:10:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:10:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:10:58 --> Model Class Initialized
DEBUG - 2011-09-10 08:10:58 --> Model Class Initialized
DEBUG - 2011-09-10 08:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:10:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:10:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:10:58 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:10:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:10:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:10:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:10:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:10:58 --> Final output sent to browser
DEBUG - 2011-09-10 08:10:58 --> Total execution time: 0.2800
DEBUG - 2011-09-10 08:12:04 --> Config Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:12:04 --> URI Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Router Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Output Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Input Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:12:04 --> Language Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Loader Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Controller Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Model Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Model Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Model Class Initialized
DEBUG - 2011-09-10 08:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:12:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:12:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:12:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:12:04 --> Final output sent to browser
DEBUG - 2011-09-10 08:12:04 --> Total execution time: 0.3600
DEBUG - 2011-09-10 08:15:01 --> Config Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:15:01 --> URI Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Router Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Output Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Input Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:15:01 --> Language Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Loader Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Controller Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:15:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:15:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:15:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:15:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:15:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:15:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:15:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:15:01 --> Final output sent to browser
DEBUG - 2011-09-10 08:15:01 --> Total execution time: 0.0838
DEBUG - 2011-09-10 08:15:04 --> Config Class Initialized
DEBUG - 2011-09-10 08:15:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:15:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:15:04 --> URI Class Initialized
DEBUG - 2011-09-10 08:15:04 --> Router Class Initialized
ERROR - 2011-09-10 08:15:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:15:10 --> Config Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:15:10 --> URI Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Router Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Output Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Input Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:15:10 --> Language Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Loader Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Controller Class Initialized
ERROR - 2011-09-10 08:15:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:15:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:15:10 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:15:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:15:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:15:10 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:15:10 --> Final output sent to browser
DEBUG - 2011-09-10 08:15:10 --> Total execution time: 0.0755
DEBUG - 2011-09-10 08:15:11 --> Config Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:15:11 --> URI Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Router Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Output Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Input Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:15:11 --> Language Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Loader Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Controller Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Model Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:15:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:15:11 --> Final output sent to browser
DEBUG - 2011-09-10 08:15:11 --> Total execution time: 0.6927
DEBUG - 2011-09-10 08:15:13 --> Config Class Initialized
DEBUG - 2011-09-10 08:15:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:15:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:15:13 --> URI Class Initialized
DEBUG - 2011-09-10 08:15:13 --> Router Class Initialized
ERROR - 2011-09-10 08:15:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:47:03 --> Config Class Initialized
DEBUG - 2011-09-10 08:47:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:47:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:47:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:47:03 --> URI Class Initialized
DEBUG - 2011-09-10 08:47:03 --> Router Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Output Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Input Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:47:04 --> Language Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Loader Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Controller Class Initialized
ERROR - 2011-09-10 08:47:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:47:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:47:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:47:04 --> Model Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Model Class Initialized
DEBUG - 2011-09-10 08:47:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:47:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:47:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:47:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:47:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:47:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:47:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:47:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:47:04 --> Final output sent to browser
DEBUG - 2011-09-10 08:47:04 --> Total execution time: 0.2900
DEBUG - 2011-09-10 08:50:38 --> Config Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:50:38 --> URI Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Router Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Output Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Input Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:50:38 --> Language Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Loader Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Controller Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Model Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Model Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Model Class Initialized
DEBUG - 2011-09-10 08:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:50:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:50:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:50:39 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:50:39 --> Final output sent to browser
DEBUG - 2011-09-10 08:50:39 --> Total execution time: 1.1097
DEBUG - 2011-09-10 08:51:14 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:14 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:14 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Controller Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:51:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:51:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:51:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:51:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:51:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:51:14 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:14 --> Total execution time: 0.0465
DEBUG - 2011-09-10 08:51:18 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:18 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:18 --> Router Class Initialized
ERROR - 2011-09-10 08:51:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:51:18 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:18 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:18 --> Router Class Initialized
ERROR - 2011-09-10 08:51:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:51:28 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:28 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:28 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Controller Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:51:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:51:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:51:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:51:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:51:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:51:29 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:29 --> Total execution time: 0.7612
DEBUG - 2011-09-10 08:51:43 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:43 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:43 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Controller Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:51:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:51:44 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:44 --> Total execution time: 0.8121
DEBUG - 2011-09-10 08:51:46 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:46 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:46 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Controller Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:51:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:51:46 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:46 --> Total execution time: 0.0455
DEBUG - 2011-09-10 08:51:49 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:49 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:49 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Controller Class Initialized
ERROR - 2011-09-10 08:51:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:51:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:51:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:51:49 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:49 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:51:49 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:51:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:51:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:51:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:51:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:51:49 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:49 --> Total execution time: 0.0273
DEBUG - 2011-09-10 08:51:50 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:50 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:50 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Controller Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:51 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:51 --> Total execution time: 0.6873
DEBUG - 2011-09-10 08:51:56 --> Config Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:51:56 --> URI Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Router Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Output Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Input Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:51:56 --> Language Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Loader Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Controller Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Model Class Initialized
DEBUG - 2011-09-10 08:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:51:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:51:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:51:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:51:57 --> Final output sent to browser
DEBUG - 2011-09-10 08:51:57 --> Total execution time: 1.1464
DEBUG - 2011-09-10 08:52:02 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:02 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:02 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:02 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:52:02 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:02 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:02 --> Total execution time: 0.0554
DEBUG - 2011-09-10 08:52:07 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:07 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:07 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:07 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:07 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:07 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:07 --> Total execution time: 0.0340
DEBUG - 2011-09-10 08:52:08 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:08 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:08 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:09 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:09 --> Total execution time: 1.0559
DEBUG - 2011-09-10 08:52:11 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:11 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Router Class Initialized
ERROR - 2011-09-10 08:52:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:11 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:11 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:11 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:52:12 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:12 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:12 --> Total execution time: 0.4941
DEBUG - 2011-09-10 08:52:13 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:13 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:13 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 08:52:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:13 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:13 --> Total execution time: 0.0505
DEBUG - 2011-09-10 08:52:22 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:22 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:22 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:22 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:22 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:22 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:22 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:22 --> Total execution time: 0.0362
DEBUG - 2011-09-10 08:52:23 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:23 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:23 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:24 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:24 --> Total execution time: 0.5461
DEBUG - 2011-09-10 08:52:25 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:25 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:25 --> Router Class Initialized
ERROR - 2011-09-10 08:52:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:35 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:35 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:35 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:35 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:35 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:35 --> Total execution time: 0.1714
DEBUG - 2011-09-10 08:52:36 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:36 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:36 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:36 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:37 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:37 --> Total execution time: 0.6245
DEBUG - 2011-09-10 08:52:40 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:40 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:40 --> Router Class Initialized
ERROR - 2011-09-10 08:52:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:48 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:48 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:48 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:48 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:48 --> Total execution time: 0.0461
DEBUG - 2011-09-10 08:52:48 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:48 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:48 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:48 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:48 --> Total execution time: 0.0515
DEBUG - 2011-09-10 08:52:48 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:48 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:48 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:49 --> Total execution time: 0.5897
DEBUG - 2011-09-10 08:52:49 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:49 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:49 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Controller Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:49 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:51 --> Total execution time: 1.1204
DEBUG - 2011-09-10 08:52:51 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:51 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Router Class Initialized
ERROR - 2011-09-10 08:52:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:51 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:51 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Router Class Initialized
ERROR - 2011-09-10 08:52:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:51 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:51 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:51 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:51 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:52 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:52 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:52 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:52 --> Router Class Initialized
ERROR - 2011-09-10 08:52:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:52 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:52 --> Total execution time: 0.2022
DEBUG - 2011-09-10 08:52:52 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:52 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:52 --> Router Class Initialized
ERROR - 2011-09-10 08:52:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:52:58 --> Config Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:52:58 --> URI Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Router Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Output Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Input Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:52:58 --> Language Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Loader Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Controller Class Initialized
ERROR - 2011-09-10 08:52:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:52:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:52:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:58 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Model Class Initialized
DEBUG - 2011-09-10 08:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:52:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:52:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:52:59 --> Final output sent to browser
DEBUG - 2011-09-10 08:52:59 --> Total execution time: 0.2116
DEBUG - 2011-09-10 08:53:00 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:00 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Router Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Output Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Input Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:53:00 --> Language Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Loader Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Controller Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:53:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:00 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Router Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Output Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Input Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:53:00 --> Language Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Loader Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Controller Class Initialized
ERROR - 2011-09-10 08:53:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:53:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:53:00 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:53:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:53:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:53:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:53:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:53:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:53:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:53:00 --> Final output sent to browser
DEBUG - 2011-09-10 08:53:00 --> Total execution time: 0.0281
DEBUG - 2011-09-10 08:53:00 --> Final output sent to browser
DEBUG - 2011-09-10 08:53:00 --> Total execution time: 0.5467
DEBUG - 2011-09-10 08:53:02 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:02 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:02 --> Router Class Initialized
ERROR - 2011-09-10 08:53:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:53:53 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:53 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Router Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Output Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Input Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:53:53 --> Language Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Loader Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Controller Class Initialized
ERROR - 2011-09-10 08:53:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:53:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:53:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:53:53 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:53:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:53:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:53:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:53:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:53:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:53:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:53:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:53:54 --> Final output sent to browser
DEBUG - 2011-09-10 08:53:54 --> Total execution time: 0.0277
DEBUG - 2011-09-10 08:53:54 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:54 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Router Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Output Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Input Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:53:54 --> Language Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Loader Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Controller Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Model Class Initialized
DEBUG - 2011-09-10 08:53:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:53:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:53:55 --> Final output sent to browser
DEBUG - 2011-09-10 08:53:55 --> Total execution time: 0.4999
DEBUG - 2011-09-10 08:53:56 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:56 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:56 --> Router Class Initialized
ERROR - 2011-09-10 08:53:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:53:57 --> Config Class Initialized
DEBUG - 2011-09-10 08:53:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:53:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:53:57 --> URI Class Initialized
DEBUG - 2011-09-10 08:53:57 --> Router Class Initialized
ERROR - 2011-09-10 08:53:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 08:59:57 --> Config Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 08:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 08:59:57 --> URI Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Router Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Output Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Input Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 08:59:57 --> Language Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Loader Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Controller Class Initialized
ERROR - 2011-09-10 08:59:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 08:59:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 08:59:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:59:57 --> Model Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Model Class Initialized
DEBUG - 2011-09-10 08:59:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 08:59:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 08:59:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 08:59:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 08:59:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 08:59:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 08:59:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 08:59:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 08:59:57 --> Final output sent to browser
DEBUG - 2011-09-10 08:59:57 --> Total execution time: 0.0279
DEBUG - 2011-09-10 09:00:03 --> Config Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:00:03 --> URI Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Router Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Output Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Input Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:00:03 --> Language Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Loader Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Controller Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Model Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Model Class Initialized
DEBUG - 2011-09-10 09:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:00:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:00:04 --> Final output sent to browser
DEBUG - 2011-09-10 09:00:04 --> Total execution time: 0.7371
DEBUG - 2011-09-10 09:00:06 --> Config Class Initialized
DEBUG - 2011-09-10 09:00:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:00:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:00:06 --> URI Class Initialized
DEBUG - 2011-09-10 09:00:06 --> Router Class Initialized
ERROR - 2011-09-10 09:00:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:00:50 --> Config Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:00:50 --> URI Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Router Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Output Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Input Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:00:50 --> Language Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Loader Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Controller Class Initialized
ERROR - 2011-09-10 09:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:00:50 --> Model Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Model Class Initialized
DEBUG - 2011-09-10 09:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:00:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:00:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:00:50 --> Final output sent to browser
DEBUG - 2011-09-10 09:00:50 --> Total execution time: 0.0903
DEBUG - 2011-09-10 09:00:53 --> Config Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:00:53 --> URI Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Router Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Output Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Input Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:00:53 --> Language Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Loader Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Controller Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Model Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Model Class Initialized
DEBUG - 2011-09-10 09:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:00:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:00:54 --> Final output sent to browser
DEBUG - 2011-09-10 09:00:54 --> Total execution time: 0.5692
DEBUG - 2011-09-10 09:01:13 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:13 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:13 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Controller Class Initialized
ERROR - 2011-09-10 09:01:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:01:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:01:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:13 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:01:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:01:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:01:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:01:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:01:13 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:13 --> Total execution time: 0.0271
DEBUG - 2011-09-10 09:01:14 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:14 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:14 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Controller Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:14 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:14 --> Total execution time: 0.5803
DEBUG - 2011-09-10 09:01:15 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:15 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:15 --> Router Class Initialized
ERROR - 2011-09-10 09:01:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:01:26 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:26 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:26 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Controller Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:01:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:01:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:01:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:01:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:01:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:01:26 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:26 --> Total execution time: 0.0491
DEBUG - 2011-09-10 09:01:27 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:27 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:27 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Controller Class Initialized
ERROR - 2011-09-10 09:01:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:01:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:01:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:27 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:01:27 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:27 --> Total execution time: 0.0323
DEBUG - 2011-09-10 09:01:28 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:28 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:28 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Controller Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:28 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:28 --> Total execution time: 0.4198
DEBUG - 2011-09-10 09:01:29 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:29 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:29 --> Router Class Initialized
ERROR - 2011-09-10 09:01:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:01:33 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:33 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:33 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Controller Class Initialized
ERROR - 2011-09-10 09:01:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:01:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:01:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:33 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:01:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:01:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:01:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:01:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:01:33 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:33 --> Total execution time: 0.0411
DEBUG - 2011-09-10 09:01:33 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:33 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:33 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Controller Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:34 --> Total execution time: 0.5930
DEBUG - 2011-09-10 09:01:34 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:34 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Router Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Output Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Input Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:01:34 --> Language Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Loader Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Controller Class Initialized
ERROR - 2011-09-10 09:01:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:01:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:34 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Model Class Initialized
DEBUG - 2011-09-10 09:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:01:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:01:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:01:34 --> Final output sent to browser
DEBUG - 2011-09-10 09:01:34 --> Total execution time: 0.0303
DEBUG - 2011-09-10 09:01:35 --> Config Class Initialized
DEBUG - 2011-09-10 09:01:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:01:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:01:35 --> URI Class Initialized
DEBUG - 2011-09-10 09:01:35 --> Router Class Initialized
ERROR - 2011-09-10 09:01:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:02:04 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:04 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Router Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Output Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Input Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:02:04 --> Language Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Loader Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Controller Class Initialized
ERROR - 2011-09-10 09:02:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:02:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:02:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:02:04 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:02:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:02:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:02:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:02:04 --> Final output sent to browser
DEBUG - 2011-09-10 09:02:04 --> Total execution time: 0.0312
DEBUG - 2011-09-10 09:02:05 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:05 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Router Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Output Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Input Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:02:05 --> Language Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Loader Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Controller Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:02:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:02:06 --> Final output sent to browser
DEBUG - 2011-09-10 09:02:06 --> Total execution time: 0.6617
DEBUG - 2011-09-10 09:02:07 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:07 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:07 --> Router Class Initialized
ERROR - 2011-09-10 09:02:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:02:08 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:08 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:08 --> Router Class Initialized
ERROR - 2011-09-10 09:02:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:02:29 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:29 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Router Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Output Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Input Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:02:29 --> Language Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Loader Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Controller Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:02:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:02:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:02:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:02:29 --> Final output sent to browser
DEBUG - 2011-09-10 09:02:29 --> Total execution time: 0.5487
DEBUG - 2011-09-10 09:02:36 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:36 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Router Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Output Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Input Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:02:36 --> Language Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Loader Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Controller Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:02:36 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:02:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:02:36 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:02:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:02:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:02:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:02:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:02:36 --> Final output sent to browser
DEBUG - 2011-09-10 09:02:36 --> Total execution time: 0.0416
DEBUG - 2011-09-10 09:02:56 --> Config Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:02:56 --> URI Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Router Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Output Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Input Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:02:56 --> Language Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Loader Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Controller Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:02:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:02:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:02:56 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:02:56 --> Final output sent to browser
DEBUG - 2011-09-10 09:02:56 --> Total execution time: 0.2209
DEBUG - 2011-09-10 09:03:12 --> Config Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:03:12 --> URI Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Router Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Output Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Input Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:03:12 --> Language Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Loader Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Controller Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:03:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:03:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:03:12 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:03:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:03:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:03:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:03:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:03:12 --> Final output sent to browser
DEBUG - 2011-09-10 09:03:12 --> Total execution time: 0.0456
DEBUG - 2011-09-10 09:03:36 --> Config Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:03:36 --> URI Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Router Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Output Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Input Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:03:36 --> Language Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Loader Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Controller Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:03:36 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:03:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:03:36 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:03:36 --> Final output sent to browser
DEBUG - 2011-09-10 09:03:36 --> Total execution time: 0.4295
DEBUG - 2011-09-10 09:03:38 --> Config Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:03:38 --> URI Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Router Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Output Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Input Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:03:38 --> Language Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Loader Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Controller Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Model Class Initialized
DEBUG - 2011-09-10 09:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:03:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:03:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:03:39 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:03:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:03:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:03:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:03:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:03:39 --> Final output sent to browser
DEBUG - 2011-09-10 09:03:39 --> Total execution time: 0.0568
DEBUG - 2011-09-10 09:04:02 --> Config Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:04:02 --> URI Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Router Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Output Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Input Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:04:02 --> Language Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Loader Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Controller Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:04:02 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:04:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:04:02 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:04:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:04:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:04:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:04:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:04:02 --> Final output sent to browser
DEBUG - 2011-09-10 09:04:02 --> Total execution time: 0.4634
DEBUG - 2011-09-10 09:04:05 --> Config Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:04:05 --> URI Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Router Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Output Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Input Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:04:05 --> Language Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Loader Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Controller Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:04:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:04:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:04:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:04:06 --> Final output sent to browser
DEBUG - 2011-09-10 09:04:06 --> Total execution time: 0.0431
DEBUG - 2011-09-10 09:04:26 --> Config Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:04:26 --> URI Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Router Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Output Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Input Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:04:26 --> Language Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Loader Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Controller Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:04:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:04:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:04:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:04:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:04:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:04:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:04:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:04:27 --> Final output sent to browser
DEBUG - 2011-09-10 09:04:27 --> Total execution time: 0.5623
DEBUG - 2011-09-10 09:04:31 --> Config Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:04:31 --> URI Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Router Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Output Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Input Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:04:31 --> Language Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Loader Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Controller Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:04:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:04:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:04:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:04:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:04:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:04:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:04:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:04:31 --> Final output sent to browser
DEBUG - 2011-09-10 09:04:31 --> Total execution time: 0.0479
DEBUG - 2011-09-10 09:04:55 --> Config Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:04:55 --> URI Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Router Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Output Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Input Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:04:55 --> Language Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Loader Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Controller Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Model Class Initialized
DEBUG - 2011-09-10 09:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:04:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:04:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:04:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:04:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:04:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:04:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:04:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:04:55 --> Final output sent to browser
DEBUG - 2011-09-10 09:04:55 --> Total execution time: 0.0483
DEBUG - 2011-09-10 09:05:11 --> Config Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:05:11 --> URI Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Router Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Output Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Input Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:05:11 --> Language Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Loader Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Controller Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Model Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Model Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Model Class Initialized
DEBUG - 2011-09-10 09:05:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:05:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:05:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:05:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:05:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:05:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:05:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:05:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:05:11 --> Final output sent to browser
DEBUG - 2011-09-10 09:05:11 --> Total execution time: 0.6340
DEBUG - 2011-09-10 09:11:46 --> Config Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:11:46 --> URI Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Router Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Output Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Input Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:11:46 --> Language Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Loader Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Controller Class Initialized
ERROR - 2011-09-10 09:11:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:11:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:11:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:11:46 --> Model Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Model Class Initialized
DEBUG - 2011-09-10 09:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:11:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:11:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:11:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:11:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:11:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:11:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:11:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:11:46 --> Final output sent to browser
DEBUG - 2011-09-10 09:11:46 --> Total execution time: 0.0405
DEBUG - 2011-09-10 09:11:47 --> Config Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:11:47 --> URI Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Router Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Output Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Input Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:11:47 --> Language Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Loader Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Controller Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Model Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Model Class Initialized
DEBUG - 2011-09-10 09:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:11:48 --> Final output sent to browser
DEBUG - 2011-09-10 09:11:48 --> Total execution time: 0.8994
DEBUG - 2011-09-10 09:11:50 --> Config Class Initialized
DEBUG - 2011-09-10 09:11:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:11:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:11:50 --> URI Class Initialized
DEBUG - 2011-09-10 09:11:50 --> Router Class Initialized
ERROR - 2011-09-10 09:11:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:11:51 --> Config Class Initialized
DEBUG - 2011-09-10 09:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:11:51 --> URI Class Initialized
DEBUG - 2011-09-10 09:11:51 --> Router Class Initialized
ERROR - 2011-09-10 09:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:16:49 --> Config Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:16:49 --> URI Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Router Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Output Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Input Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:16:49 --> Language Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Loader Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Controller Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Model Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Model Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Model Class Initialized
DEBUG - 2011-09-10 09:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:16:49 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:16:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:16:49 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:16:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:16:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:16:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:16:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:16:49 --> Final output sent to browser
DEBUG - 2011-09-10 09:16:49 --> Total execution time: 0.1004
DEBUG - 2011-09-10 09:17:04 --> Config Class Initialized
DEBUG - 2011-09-10 09:17:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:17:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:17:04 --> URI Class Initialized
DEBUG - 2011-09-10 09:17:04 --> Router Class Initialized
ERROR - 2011-09-10 09:17:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 09:27:35 --> Config Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:27:35 --> URI Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Router Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Output Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Input Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:27:35 --> Language Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Loader Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Controller Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Model Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Model Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Model Class Initialized
DEBUG - 2011-09-10 09:27:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:27:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:27:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:27:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:27:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:27:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:27:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:27:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:27:35 --> Final output sent to browser
DEBUG - 2011-09-10 09:27:35 --> Total execution time: 0.1516
DEBUG - 2011-09-10 09:29:51 --> Config Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:29:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:29:51 --> URI Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Router Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Output Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Input Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:29:51 --> Language Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Loader Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Controller Class Initialized
ERROR - 2011-09-10 09:29:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:29:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:29:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:29:51 --> Model Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Model Class Initialized
DEBUG - 2011-09-10 09:29:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:29:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:29:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:29:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:29:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:29:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:29:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:29:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:29:51 --> Final output sent to browser
DEBUG - 2011-09-10 09:29:51 --> Total execution time: 0.0279
DEBUG - 2011-09-10 09:29:53 --> Config Class Initialized
DEBUG - 2011-09-10 09:29:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:29:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:29:53 --> URI Class Initialized
DEBUG - 2011-09-10 09:29:53 --> Router Class Initialized
DEBUG - 2011-09-10 09:29:53 --> Output Class Initialized
DEBUG - 2011-09-10 09:29:53 --> Input Class Initialized
DEBUG - 2011-09-10 09:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:29:54 --> Language Class Initialized
DEBUG - 2011-09-10 09:29:54 --> Loader Class Initialized
DEBUG - 2011-09-10 09:29:54 --> Controller Class Initialized
DEBUG - 2011-09-10 09:29:54 --> Model Class Initialized
DEBUG - 2011-09-10 09:29:54 --> Model Class Initialized
DEBUG - 2011-09-10 09:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:29:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:29:54 --> Final output sent to browser
DEBUG - 2011-09-10 09:29:54 --> Total execution time: 0.8189
DEBUG - 2011-09-10 09:30:34 --> Config Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:30:34 --> URI Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Router Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Output Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Input Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:30:34 --> Language Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Loader Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Controller Class Initialized
ERROR - 2011-09-10 09:30:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:30:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:30:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:30:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:30:34 --> Final output sent to browser
DEBUG - 2011-09-10 09:30:34 --> Total execution time: 0.0285
DEBUG - 2011-09-10 09:30:34 --> Config Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:30:34 --> URI Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Router Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Output Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Input Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:30:34 --> Language Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Loader Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Controller Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Model Class Initialized
DEBUG - 2011-09-10 09:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:30:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:30:35 --> Final output sent to browser
DEBUG - 2011-09-10 09:30:35 --> Total execution time: 0.5678
DEBUG - 2011-09-10 09:40:58 --> Config Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:40:58 --> URI Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Router Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Output Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Input Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:40:58 --> Language Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Loader Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Controller Class Initialized
ERROR - 2011-09-10 09:40:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:40:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:40:58 --> Model Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Model Class Initialized
DEBUG - 2011-09-10 09:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:40:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:40:58 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:40:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:40:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:40:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:40:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:40:58 --> Final output sent to browser
DEBUG - 2011-09-10 09:40:58 --> Total execution time: 0.0304
DEBUG - 2011-09-10 09:40:59 --> Config Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:40:59 --> URI Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Router Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Output Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Input Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:40:59 --> Language Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Loader Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Controller Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Model Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Model Class Initialized
DEBUG - 2011-09-10 09:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:40:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:41:00 --> Final output sent to browser
DEBUG - 2011-09-10 09:41:00 --> Total execution time: 0.5457
DEBUG - 2011-09-10 09:41:02 --> Config Class Initialized
DEBUG - 2011-09-10 09:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:41:02 --> URI Class Initialized
DEBUG - 2011-09-10 09:41:02 --> Router Class Initialized
ERROR - 2011-09-10 09:41:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:41:03 --> Config Class Initialized
DEBUG - 2011-09-10 09:41:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:41:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:41:03 --> URI Class Initialized
DEBUG - 2011-09-10 09:41:03 --> Router Class Initialized
ERROR - 2011-09-10 09:41:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:41:56 --> Config Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:41:56 --> URI Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Router Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Output Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Input Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:41:56 --> Language Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Loader Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Controller Class Initialized
ERROR - 2011-09-10 09:41:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:41:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:41:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:41:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:41:56 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:41:56 --> Final output sent to browser
DEBUG - 2011-09-10 09:41:56 --> Total execution time: 0.0307
DEBUG - 2011-09-10 09:41:56 --> Config Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:41:56 --> URI Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Router Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Output Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Input Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:41:56 --> Language Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Loader Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Controller Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Model Class Initialized
DEBUG - 2011-09-10 09:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:41:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:41:57 --> Final output sent to browser
DEBUG - 2011-09-10 09:41:57 --> Total execution time: 0.5736
DEBUG - 2011-09-10 09:42:02 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:02 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:02 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:02 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:02 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:02 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:02 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:02 --> Total execution time: 0.1503
DEBUG - 2011-09-10 09:42:11 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:11 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:11 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:11 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:11 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:11 --> Total execution time: 0.0960
DEBUG - 2011-09-10 09:42:12 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:12 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:12 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Controller Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:13 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:13 --> Total execution time: 0.5286
DEBUG - 2011-09-10 09:42:17 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:17 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:17 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:17 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:17 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:17 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:17 --> Total execution time: 0.0276
DEBUG - 2011-09-10 09:42:20 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:20 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:20 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:20 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:21 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:21 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:21 --> Total execution time: 0.0300
DEBUG - 2011-09-10 09:42:21 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:21 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:21 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Controller Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:22 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:22 --> Total execution time: 0.5838
DEBUG - 2011-09-10 09:42:29 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:29 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:29 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:29 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:29 --> Total execution time: 0.0348
DEBUG - 2011-09-10 09:42:29 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:29 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:29 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Controller Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:30 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:30 --> Total execution time: 0.5424
DEBUG - 2011-09-10 09:42:39 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:39 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:39 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:39 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:39 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:39 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:39 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:39 --> Total execution time: 0.0279
DEBUG - 2011-09-10 09:42:39 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:39 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:39 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Controller Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:39 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:40 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:40 --> Total execution time: 0.4612
DEBUG - 2011-09-10 09:42:59 --> Config Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:42:59 --> URI Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Router Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Output Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Input Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:42:59 --> Language Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Loader Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Controller Class Initialized
ERROR - 2011-09-10 09:42:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:42:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:59 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Model Class Initialized
DEBUG - 2011-09-10 09:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:42:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:42:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:42:59 --> Final output sent to browser
DEBUG - 2011-09-10 09:42:59 --> Total execution time: 0.0297
DEBUG - 2011-09-10 09:43:00 --> Config Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:43:00 --> URI Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Router Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Output Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Input Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:43:00 --> Language Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Loader Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Controller Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Model Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Model Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:43:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:43:00 --> Final output sent to browser
DEBUG - 2011-09-10 09:43:00 --> Total execution time: 0.5658
DEBUG - 2011-09-10 09:43:30 --> Config Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:43:30 --> URI Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Router Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Output Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Input Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:43:30 --> Language Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Loader Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Controller Class Initialized
ERROR - 2011-09-10 09:43:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 09:43:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 09:43:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:43:30 --> Model Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Model Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:43:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:43:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 09:43:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:43:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:43:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:43:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:43:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:43:30 --> Final output sent to browser
DEBUG - 2011-09-10 09:43:30 --> Total execution time: 0.0318
DEBUG - 2011-09-10 09:43:30 --> Config Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:43:30 --> URI Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Router Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Output Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Input Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:43:30 --> Language Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Loader Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Controller Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Model Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Model Class Initialized
DEBUG - 2011-09-10 09:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:43:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:43:31 --> Final output sent to browser
DEBUG - 2011-09-10 09:43:31 --> Total execution time: 0.5789
DEBUG - 2011-09-10 09:57:37 --> Config Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:57:37 --> URI Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Router Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Output Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Input Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 09:57:37 --> Language Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Loader Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Controller Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Model Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Model Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Model Class Initialized
DEBUG - 2011-09-10 09:57:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 09:57:37 --> Database Driver Class Initialized
DEBUG - 2011-09-10 09:57:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 09:57:37 --> Helper loaded: url_helper
DEBUG - 2011-09-10 09:57:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 09:57:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 09:57:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 09:57:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 09:57:37 --> Final output sent to browser
DEBUG - 2011-09-10 09:57:37 --> Total execution time: 0.2285
DEBUG - 2011-09-10 09:57:39 --> Config Class Initialized
DEBUG - 2011-09-10 09:57:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:57:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:57:39 --> URI Class Initialized
DEBUG - 2011-09-10 09:57:39 --> Router Class Initialized
ERROR - 2011-09-10 09:57:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 09:57:40 --> Config Class Initialized
DEBUG - 2011-09-10 09:57:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 09:57:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 09:57:40 --> URI Class Initialized
DEBUG - 2011-09-10 09:57:40 --> Router Class Initialized
ERROR - 2011-09-10 09:57:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:03:59 --> Config Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:03:59 --> URI Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Router Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Output Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Input Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:03:59 --> Language Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Loader Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Controller Class Initialized
ERROR - 2011-09-10 10:03:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:03:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:03:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:03:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:03:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:03:59 --> Final output sent to browser
DEBUG - 2011-09-10 10:03:59 --> Total execution time: 0.0438
DEBUG - 2011-09-10 10:04:00 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:00 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:00 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:01 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:01 --> Total execution time: 0.9602
DEBUG - 2011-09-10 10:04:03 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:03 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:03 --> Router Class Initialized
ERROR - 2011-09-10 10:04:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:06 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:06 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:06 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Controller Class Initialized
ERROR - 2011-09-10 10:04:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:04:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:06 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:06 --> Total execution time: 0.0334
DEBUG - 2011-09-10 10:04:07 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:07 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:07 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:07 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:07 --> Total execution time: 0.4977
DEBUG - 2011-09-10 10:04:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:08 --> Router Class Initialized
ERROR - 2011-09-10 10:04:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:19 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:19 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:19 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:04:19 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:19 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:19 --> Total execution time: 0.0759
DEBUG - 2011-09-10 10:04:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:21 --> Router Class Initialized
ERROR - 2011-09-10 10:04:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:24 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:24 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:24 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Controller Class Initialized
ERROR - 2011-09-10 10:04:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:04:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:04:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:24 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:24 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:24 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:24 --> Total execution time: 0.1832
DEBUG - 2011-09-10 10:04:25 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:25 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:25 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:26 --> Total execution time: 0.6678
DEBUG - 2011-09-10 10:04:26 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:26 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:26 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Controller Class Initialized
ERROR - 2011-09-10 10:04:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:04:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:04:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:26 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:26 --> Total execution time: 0.0311
DEBUG - 2011-09-10 10:04:28 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:28 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:28 --> Router Class Initialized
ERROR - 2011-09-10 10:04:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:30 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:30 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:30 --> Router Class Initialized
ERROR - 2011-09-10 10:04:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 10:04:30 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:30 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:30 --> Router Class Initialized
ERROR - 2011-09-10 10:04:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 10:04:31 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:31 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:31 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Controller Class Initialized
ERROR - 2011-09-10 10:04:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:04:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:04:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:31 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:31 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:31 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:31 --> Total execution time: 0.0885
DEBUG - 2011-09-10 10:04:31 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:31 --> Total execution time: 0.5142
DEBUG - 2011-09-10 10:04:37 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:37 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:37 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Controller Class Initialized
ERROR - 2011-09-10 10:04:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:04:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:04:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:37 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:37 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:37 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:37 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:37 --> Total execution time: 0.0640
DEBUG - 2011-09-10 10:04:37 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:38 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:38 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:38 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:38 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:39 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:39 --> Total execution time: 1.0735
DEBUG - 2011-09-10 10:04:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:04:39 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:39 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:39 --> Total execution time: 0.8164
DEBUG - 2011-09-10 10:04:40 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:40 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:40 --> Router Class Initialized
ERROR - 2011-09-10 10:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:40 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:40 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:40 --> Router Class Initialized
ERROR - 2011-09-10 10:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:41 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:41 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:41 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:41 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:04:41 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:41 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:41 --> Total execution time: 0.1153
DEBUG - 2011-09-10 10:04:46 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:46 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:46 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Controller Class Initialized
ERROR - 2011-09-10 10:04:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:04:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:04:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:04:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:46 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:46 --> Total execution time: 0.0340
DEBUG - 2011-09-10 10:04:47 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:47 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:47 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:48 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:48 --> Total execution time: 1.0518
DEBUG - 2011-09-10 10:04:50 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:50 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:50 --> Router Class Initialized
ERROR - 2011-09-10 10:04:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:04:54 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:54 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Router Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Output Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Input Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:04:54 --> Language Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Loader Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Controller Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:04:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:04:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:04:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:04:54 --> Final output sent to browser
DEBUG - 2011-09-10 10:04:54 --> Total execution time: 0.0565
DEBUG - 2011-09-10 10:04:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:04:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:04:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:04:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:04:55 --> Router Class Initialized
ERROR - 2011-09-10 10:04:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:05:03 --> Config Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:05:03 --> URI Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Router Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Output Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Input Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:05:03 --> Language Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Loader Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Controller Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Model Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Model Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Model Class Initialized
DEBUG - 2011-09-10 10:05:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:05:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:05:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:05:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:05:04 --> Total execution time: 0.7468
DEBUG - 2011-09-10 10:05:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:05:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Router Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Output Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Input Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:05:04 --> Language Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Loader Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Controller Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:05:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:05:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:05:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:05:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:05:04 --> Total execution time: 0.0428
DEBUG - 2011-09-10 10:05:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:05:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:05:04 --> Router Class Initialized
ERROR - 2011-09-10 10:05:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:15:16 --> Config Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:15:16 --> URI Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Router Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Output Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Input Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:15:16 --> Language Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Loader Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Controller Class Initialized
ERROR - 2011-09-10 10:15:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:15:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:15:16 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:15:16 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:15:16 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:15:16 --> Final output sent to browser
DEBUG - 2011-09-10 10:15:16 --> Total execution time: 0.0287
DEBUG - 2011-09-10 10:15:17 --> Config Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:15:17 --> URI Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Router Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Output Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Input Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:15:17 --> Language Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Loader Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Controller Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:15:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:15:17 --> Final output sent to browser
DEBUG - 2011-09-10 10:15:17 --> Total execution time: 0.4466
DEBUG - 2011-09-10 10:15:18 --> Config Class Initialized
DEBUG - 2011-09-10 10:15:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:15:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:15:18 --> URI Class Initialized
DEBUG - 2011-09-10 10:15:18 --> Router Class Initialized
ERROR - 2011-09-10 10:15:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:15:19 --> Config Class Initialized
DEBUG - 2011-09-10 10:15:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:15:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:15:19 --> URI Class Initialized
DEBUG - 2011-09-10 10:15:19 --> Router Class Initialized
ERROR - 2011-09-10 10:15:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:15:19 --> Config Class Initialized
DEBUG - 2011-09-10 10:15:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:15:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:15:19 --> URI Class Initialized
DEBUG - 2011-09-10 10:15:19 --> Router Class Initialized
ERROR - 2011-09-10 10:15:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:15:22 --> Config Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:15:22 --> URI Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Router Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Output Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Input Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:15:22 --> Language Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Loader Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Controller Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Model Class Initialized
DEBUG - 2011-09-10 10:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:15:22 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:15:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:15:22 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:15:22 --> Final output sent to browser
DEBUG - 2011-09-10 10:15:22 --> Total execution time: 0.0436
DEBUG - 2011-09-10 10:16:25 --> Config Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:16:25 --> URI Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Router Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Output Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Input Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:16:25 --> Language Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Loader Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Controller Class Initialized
ERROR - 2011-09-10 10:16:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:16:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:25 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:16:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:25 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:16:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:16:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:16:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:16:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:16:25 --> Final output sent to browser
DEBUG - 2011-09-10 10:16:25 --> Total execution time: 0.0275
DEBUG - 2011-09-10 10:16:26 --> Config Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:16:26 --> URI Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Router Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Output Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Input Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:16:26 --> Language Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Loader Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Controller Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:16:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:16:26 --> Final output sent to browser
DEBUG - 2011-09-10 10:16:26 --> Total execution time: 0.5807
DEBUG - 2011-09-10 10:16:28 --> Config Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:16:28 --> URI Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Router Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Output Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Input Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:16:28 --> Language Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Loader Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Controller Class Initialized
ERROR - 2011-09-10 10:16:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:16:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:28 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:16:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:28 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:16:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:16:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:16:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:16:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:16:28 --> Final output sent to browser
DEBUG - 2011-09-10 10:16:28 --> Total execution time: 0.0287
DEBUG - 2011-09-10 10:16:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:16:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:16:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Controller Class Initialized
ERROR - 2011-09-10 10:16:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:16:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:16:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:16:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:16:55 --> Total execution time: 0.0280
DEBUG - 2011-09-10 10:16:56 --> Config Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:16:56 --> URI Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Router Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Output Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Input Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:16:56 --> Language Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Loader Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Controller Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:16:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Config Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:16:56 --> URI Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Router Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Output Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Input Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:16:56 --> Language Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Loader Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Controller Class Initialized
ERROR - 2011-09-10 10:16:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:16:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:56 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Model Class Initialized
DEBUG - 2011-09-10 10:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:16:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:16:56 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:16:56 --> Final output sent to browser
DEBUG - 2011-09-10 10:16:56 --> Total execution time: 0.0285
DEBUG - 2011-09-10 10:16:56 --> Final output sent to browser
DEBUG - 2011-09-10 10:16:56 --> Total execution time: 0.5047
DEBUG - 2011-09-10 10:17:05 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:05 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:05 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Controller Class Initialized
ERROR - 2011-09-10 10:17:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:17:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:05 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:17:05 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:05 --> Total execution time: 0.0304
DEBUG - 2011-09-10 10:17:05 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:05 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:05 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:06 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Controller Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:06 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:06 --> Total execution time: 0.5801
DEBUG - 2011-09-10 10:17:16 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:16 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:16 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Controller Class Initialized
ERROR - 2011-09-10 10:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:16 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:16 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:16 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:17:16 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:16 --> Total execution time: 0.0311
DEBUG - 2011-09-10 10:17:17 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:17 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:17 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Controller Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:17 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:17 --> Total execution time: 0.5396
DEBUG - 2011-09-10 10:17:19 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:19 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:19 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Controller Class Initialized
ERROR - 2011-09-10 10:17:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:17:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:17:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:19 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:17:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:17:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:17:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:17:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:17:19 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:19 --> Total execution time: 0.0271
DEBUG - 2011-09-10 10:17:20 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:20 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:20 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Controller Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:20 --> Total execution time: 0.4975
DEBUG - 2011-09-10 10:17:20 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:20 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:20 --> Router Class Initialized
ERROR - 2011-09-10 10:17:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:17:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:21 --> Router Class Initialized
ERROR - 2011-09-10 10:17:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:17:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:21 --> Router Class Initialized
ERROR - 2011-09-10 10:17:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:17:51 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:51 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:51 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Controller Class Initialized
ERROR - 2011-09-10 10:17:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:17:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:17:51 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:51 --> Total execution time: 0.0290
DEBUG - 2011-09-10 10:17:51 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:51 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:51 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Controller Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:51 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:51 --> Total execution time: 0.5108
DEBUG - 2011-09-10 10:17:52 --> Config Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:17:52 --> URI Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Router Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Output Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Input Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:17:52 --> Language Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Loader Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Controller Class Initialized
ERROR - 2011-09-10 10:17:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:17:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:17:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:52 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Model Class Initialized
DEBUG - 2011-09-10 10:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:17:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:17:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:17:52 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:17:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:17:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:17:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:17:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:17:52 --> Final output sent to browser
DEBUG - 2011-09-10 10:17:52 --> Total execution time: 0.0888
DEBUG - 2011-09-10 10:18:13 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:13 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:13 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Controller Class Initialized
ERROR - 2011-09-10 10:18:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:18:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:18:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:13 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:13 --> Total execution time: 0.0300
DEBUG - 2011-09-10 10:18:13 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:13 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:13 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:14 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:14 --> Total execution time: 0.5263
DEBUG - 2011-09-10 10:18:15 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:15 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:15 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:18:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:15 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:15 --> Total execution time: 0.0453
DEBUG - 2011-09-10 10:18:17 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:17 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:17 --> Router Class Initialized
ERROR - 2011-09-10 10:18:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:18:20 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:20 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:20 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Controller Class Initialized
ERROR - 2011-09-10 10:18:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:18:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:20 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:20 --> Total execution time: 0.0274
DEBUG - 2011-09-10 10:18:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:21 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:22 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:22 --> Total execution time: 0.5043
DEBUG - 2011-09-10 10:18:23 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:23 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:23 --> Router Class Initialized
ERROR - 2011-09-10 10:18:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:18:31 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:31 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:31 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Controller Class Initialized
ERROR - 2011-09-10 10:18:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:18:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:18:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:31 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:31 --> Total execution time: 0.0303
DEBUG - 2011-09-10 10:18:31 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:31 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:31 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:31 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:31 --> Total execution time: 0.4879
DEBUG - 2011-09-10 10:18:44 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:44 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:44 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Controller Class Initialized
ERROR - 2011-09-10 10:18:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:18:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:44 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:44 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:44 --> Total execution time: 0.0488
DEBUG - 2011-09-10 10:18:44 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:44 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:44 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:45 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:45 --> Total execution time: 0.4684
DEBUG - 2011-09-10 10:18:54 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:54 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:54 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Controller Class Initialized
ERROR - 2011-09-10 10:18:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:18:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:54 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:54 --> Total execution time: 0.0296
DEBUG - 2011-09-10 10:18:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:18:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:55 --> Total execution time: 0.3178
DEBUG - 2011-09-10 10:18:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Controller Class Initialized
ERROR - 2011-09-10 10:18:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:18:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:18:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:55 --> Total execution time: 0.0305
DEBUG - 2011-09-10 10:18:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:56 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:56 --> Total execution time: 0.5195
DEBUG - 2011-09-10 10:18:57 --> Config Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:18:57 --> URI Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Router Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Output Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Input Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:18:57 --> Language Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Loader Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Controller Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:18:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:18:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:18:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:18:57 --> Final output sent to browser
DEBUG - 2011-09-10 10:18:57 --> Total execution time: 0.1289
DEBUG - 2011-09-10 10:19:06 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:06 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:06 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:06 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:06 --> Total execution time: 0.3252
DEBUG - 2011-09-10 10:19:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:08 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:08 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:08 --> Total execution time: 0.0674
DEBUG - 2011-09-10 10:19:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:08 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Controller Class Initialized
ERROR - 2011-09-10 10:19:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:19:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:08 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:08 --> Total execution time: 0.0336
DEBUG - 2011-09-10 10:19:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:08 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:09 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:09 --> Total execution time: 0.5574
DEBUG - 2011-09-10 10:19:20 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:20 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:20 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:20 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:20 --> Total execution time: 0.0569
DEBUG - 2011-09-10 10:19:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:21 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Controller Class Initialized
ERROR - 2011-09-10 10:19:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:19:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:21 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:21 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:21 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:21 --> Total execution time: 0.0272
DEBUG - 2011-09-10 10:19:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:21 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:22 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:22 --> Total execution time: 0.5709
DEBUG - 2011-09-10 10:19:23 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:23 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:23 --> Router Class Initialized
ERROR - 2011-09-10 10:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:19:26 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:26 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:26 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:26 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:26 --> Total execution time: 0.2751
DEBUG - 2011-09-10 10:19:33 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:33 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:33 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Controller Class Initialized
ERROR - 2011-09-10 10:19:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:33 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:33 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:33 --> Total execution time: 0.0313
DEBUG - 2011-09-10 10:19:33 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:33 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:33 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:34 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:34 --> Total execution time: 0.6472
DEBUG - 2011-09-10 10:19:36 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:36 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:36 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:36 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:37 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:37 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:37 --> Total execution time: 0.8310
DEBUG - 2011-09-10 10:19:39 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:39 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:39 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:39 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:39 --> Router Class Initialized
ERROR - 2011-09-10 10:19:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:39 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:39 --> Total execution time: 0.0814
DEBUG - 2011-09-10 10:19:45 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:45 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:45 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Controller Class Initialized
ERROR - 2011-09-10 10:19:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:19:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:19:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:45 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:45 --> Total execution time: 0.1997
DEBUG - 2011-09-10 10:19:46 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:46 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:46 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:47 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:47 --> Total execution time: 1.5825
DEBUG - 2011-09-10 10:19:50 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:50 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Router Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Output Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Input Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:19:50 --> Language Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Loader Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Controller Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Model Class Initialized
DEBUG - 2011-09-10 10:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:19:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:19:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:19:51 --> Final output sent to browser
DEBUG - 2011-09-10 10:19:51 --> Total execution time: 0.7006
DEBUG - 2011-09-10 10:19:53 --> Config Class Initialized
DEBUG - 2011-09-10 10:19:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:19:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:19:53 --> URI Class Initialized
DEBUG - 2011-09-10 10:19:53 --> Router Class Initialized
ERROR - 2011-09-10 10:19:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:20:02 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:02 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:02 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Controller Class Initialized
ERROR - 2011-09-10 10:20:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:20:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:20:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:20:02 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:02 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:20:02 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:02 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:02 --> Total execution time: 0.1679
DEBUG - 2011-09-10 10:20:03 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:03 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:03 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:04 --> Total execution time: 0.5607
DEBUG - 2011-09-10 10:20:15 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:15 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:15 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:20:19 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:19 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:19 --> Total execution time: 3.2192
DEBUG - 2011-09-10 10:20:21 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:21 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:21 --> Router Class Initialized
ERROR - 2011-09-10 10:20:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:20:32 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:32 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:32 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:20:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:33 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:33 --> Total execution time: 0.2635
DEBUG - 2011-09-10 10:20:34 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:34 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:34 --> Router Class Initialized
ERROR - 2011-09-10 10:20:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:20:45 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:45 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:45 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:20:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:45 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:45 --> Total execution time: 0.2543
DEBUG - 2011-09-10 10:20:47 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:47 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:47 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Controller Class Initialized
ERROR - 2011-09-10 10:20:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:20:47 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:20:47 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:47 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:47 --> Total execution time: 0.0275
DEBUG - 2011-09-10 10:20:47 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:47 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:47 --> Router Class Initialized
ERROR - 2011-09-10 10:20:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:20:48 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:48 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:48 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:49 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:49 --> Total execution time: 0.5238
DEBUG - 2011-09-10 10:20:53 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:53 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:53 --> Router Class Initialized
ERROR - 2011-09-10 10:20:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:20:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:20:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:55 --> Total execution time: 0.2395
DEBUG - 2011-09-10 10:20:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Controller Class Initialized
ERROR - 2011-09-10 10:20:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:20:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:20:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:55 --> Total execution time: 0.0263
DEBUG - 2011-09-10 10:20:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:56 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:56 --> Total execution time: 0.4052
DEBUG - 2011-09-10 10:20:57 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:57 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:57 --> Router Class Initialized
ERROR - 2011-09-10 10:20:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:20:58 --> Config Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:20:58 --> URI Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Router Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Output Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Input Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:20:58 --> Language Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Loader Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Controller Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:20:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:20:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:20:58 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:20:58 --> Final output sent to browser
DEBUG - 2011-09-10 10:20:58 --> Total execution time: 0.0511
DEBUG - 2011-09-10 10:21:01 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:01 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:01 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:01 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:01 --> Total execution time: 0.0288
DEBUG - 2011-09-10 10:21:01 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:01 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:01 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:21:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:01 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:01 --> Total execution time: 0.0453
DEBUG - 2011-09-10 10:21:01 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:01 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:01 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:01 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:01 --> Total execution time: 0.5411
DEBUG - 2011-09-10 10:21:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:04 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:21:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:04 --> Total execution time: 0.2462
DEBUG - 2011-09-10 10:21:05 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:05 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:05 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:21:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:05 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:05 --> Total execution time: 0.0468
DEBUG - 2011-09-10 10:21:05 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:05 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:05 --> Router Class Initialized
ERROR - 2011-09-10 10:21:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:21:11 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:11 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:11 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:11 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:11 --> Total execution time: 0.0283
DEBUG - 2011-09-10 10:21:11 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:11 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:11 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:12 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:12 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:21:12 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:12 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:12 --> Total execution time: 0.2122
DEBUG - 2011-09-10 10:21:12 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:12 --> Total execution time: 0.4506
DEBUG - 2011-09-10 10:21:13 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:13 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:13 --> Router Class Initialized
ERROR - 2011-09-10 10:21:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:21:14 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:14 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:14 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:14 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:14 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:14 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:14 --> Total execution time: 0.0458
DEBUG - 2011-09-10 10:21:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:14 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:14 --> Total execution time: 0.0282
DEBUG - 2011-09-10 10:21:14 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:14 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:14 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:15 --> Total execution time: 0.5311
DEBUG - 2011-09-10 10:21:15 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:15 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:15 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:15 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:15 --> Total execution time: 0.0305
DEBUG - 2011-09-10 10:21:16 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:16 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:16 --> Router Class Initialized
ERROR - 2011-09-10 10:21:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:21:24 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:24 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:24 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:24 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:24 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:24 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:24 --> Total execution time: 0.0357
DEBUG - 2011-09-10 10:21:25 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:25 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:25 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:25 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:25 --> Total execution time: 0.8737
DEBUG - 2011-09-10 10:21:28 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:28 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:28 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:28 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:28 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:28 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:28 --> Total execution time: 0.0279
DEBUG - 2011-09-10 10:21:29 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:29 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:29 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:30 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:30 --> Total execution time: 0.4711
DEBUG - 2011-09-10 10:21:32 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:32 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Router Class Initialized
ERROR - 2011-09-10 10:21:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:21:32 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:32 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:32 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:21:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:32 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:32 --> Total execution time: 0.0480
DEBUG - 2011-09-10 10:21:33 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:33 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:33 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:33 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:33 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:33 --> Total execution time: 0.0280
DEBUG - 2011-09-10 10:21:34 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:34 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:34 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:34 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:34 --> Total execution time: 0.5042
DEBUG - 2011-09-10 10:21:35 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:35 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:35 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:35 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:35 --> Total execution time: 0.0298
DEBUG - 2011-09-10 10:21:36 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:36 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:36 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:36 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:36 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:36 --> Total execution time: 0.5643
DEBUG - 2011-09-10 10:21:37 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:37 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:37 --> Router Class Initialized
ERROR - 2011-09-10 10:21:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:21:54 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:54 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:54 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:54 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:54 --> Total execution time: 0.0326
DEBUG - 2011-09-10 10:21:54 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:54 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:54 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:55 --> Total execution time: 0.6258
DEBUG - 2011-09-10 10:21:57 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:57 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:57 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:57 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:57 --> Total execution time: 0.0281
DEBUG - 2011-09-10 10:21:57 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:58 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:58 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Controller Class Initialized
ERROR - 2011-09-10 10:21:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:21:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:21:58 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:21:58 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:58 --> Total execution time: 0.0378
DEBUG - 2011-09-10 10:21:58 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:58 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:58 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Config Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:21:59 --> URI Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Router Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Output Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Input Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:21:59 --> Language Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Loader Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Controller Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:21:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:21:59 --> Final output sent to browser
DEBUG - 2011-09-10 10:21:59 --> Total execution time: 0.6743
DEBUG - 2011-09-10 10:22:00 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:00 --> Total execution time: 0.6938
DEBUG - 2011-09-10 10:22:00 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:00 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:00 --> Router Class Initialized
ERROR - 2011-09-10 10:22:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:22:01 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:01 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:01 --> Router Class Initialized
ERROR - 2011-09-10 10:22:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:22:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:04 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:04 --> Total execution time: 0.0421
DEBUG - 2011-09-10 10:22:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:04 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:04 --> Total execution time: 0.5712
DEBUG - 2011-09-10 10:22:06 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:06 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:06 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:06 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:06 --> Total execution time: 0.0271
DEBUG - 2011-09-10 10:22:07 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:07 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:07 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:07 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:07 --> Total execution time: 0.4718
DEBUG - 2011-09-10 10:22:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:08 --> Router Class Initialized
ERROR - 2011-09-10 10:22:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:22:10 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:10 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:10 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:10 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:10 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:10 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:10 --> Total execution time: 0.0341
DEBUG - 2011-09-10 10:22:11 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:11 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:11 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:11 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:11 --> Total execution time: 0.6365
DEBUG - 2011-09-10 10:22:12 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:12 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:12 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:12 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:12 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:12 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:12 --> Total execution time: 0.0293
DEBUG - 2011-09-10 10:22:13 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:13 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:13 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:13 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:13 --> Total execution time: 0.0344
DEBUG - 2011-09-10 10:22:14 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:14 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Router Class Initialized
ERROR - 2011-09-10 10:22:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:22:14 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:14 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:14 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:14 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:14 --> Total execution time: 0.0292
DEBUG - 2011-09-10 10:22:18 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:18 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:18 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:18 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:18 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:18 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:18 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:18 --> Total execution time: 0.0743
DEBUG - 2011-09-10 10:22:19 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:19 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:19 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:19 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:19 --> Total execution time: 0.6047
DEBUG - 2011-09-10 10:22:27 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:27 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:27 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:27 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:27 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:27 --> Total execution time: 0.0348
DEBUG - 2011-09-10 10:22:27 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:27 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:27 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:28 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:28 --> Total execution time: 0.5446
DEBUG - 2011-09-10 10:22:29 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:29 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:29 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:29 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:29 --> Total execution time: 0.0309
DEBUG - 2011-09-10 10:22:30 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:30 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:30 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:31 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:31 --> Total execution time: 0.5878
DEBUG - 2011-09-10 10:22:32 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:32 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:32 --> Router Class Initialized
ERROR - 2011-09-10 10:22:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:22:46 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:46 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:46 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:46 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:46 --> Total execution time: 0.0656
DEBUG - 2011-09-10 10:22:46 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:46 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:46 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:47 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:47 --> Total execution time: 0.5690
DEBUG - 2011-09-10 10:22:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Controller Class Initialized
ERROR - 2011-09-10 10:22:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:22:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:22:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:22:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:22:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:55 --> Total execution time: 0.0296
DEBUG - 2011-09-10 10:22:55 --> Config Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:22:55 --> URI Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Router Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Output Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Input Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:22:55 --> Language Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Loader Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Controller Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Model Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:22:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:22:55 --> Final output sent to browser
DEBUG - 2011-09-10 10:22:55 --> Total execution time: 0.5286
DEBUG - 2011-09-10 10:23:00 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:00 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:00 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Controller Class Initialized
ERROR - 2011-09-10 10:23:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:23:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:00 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:00 --> Total execution time: 0.0314
DEBUG - 2011-09-10 10:23:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:04 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Controller Class Initialized
ERROR - 2011-09-10 10:23:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:23:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:04 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:04 --> Total execution time: 0.0309
DEBUG - 2011-09-10 10:23:04 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:04 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:04 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Controller Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:05 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:05 --> Total execution time: 0.6913
DEBUG - 2011-09-10 10:23:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:08 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Controller Class Initialized
ERROR - 2011-09-10 10:23:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:23:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:08 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:08 --> Total execution time: 0.0404
DEBUG - 2011-09-10 10:23:09 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:09 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:09 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Controller Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:09 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:09 --> Total execution time: 0.6247
DEBUG - 2011-09-10 10:23:12 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:12 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:12 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Controller Class Initialized
ERROR - 2011-09-10 10:23:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:23:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:12 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:12 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:12 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:12 --> Total execution time: 0.0268
DEBUG - 2011-09-10 10:23:13 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:13 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:13 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Controller Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:14 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:14 --> Total execution time: 0.7284
DEBUG - 2011-09-10 10:23:35 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:35 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:35 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Controller Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:23:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:35 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:35 --> Total execution time: 0.0431
DEBUG - 2011-09-10 10:23:47 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:47 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:47 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Controller Class Initialized
ERROR - 2011-09-10 10:23:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:23:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:47 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:47 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:47 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:47 --> Total execution time: 0.0280
DEBUG - 2011-09-10 10:23:57 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:57 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:57 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Controller Class Initialized
ERROR - 2011-09-10 10:23:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:23:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:23:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:23:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:57 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:57 --> Total execution time: 0.0285
DEBUG - 2011-09-10 10:23:59 --> Config Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:23:59 --> URI Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Router Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Output Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Input Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:23:59 --> Language Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Loader Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Controller Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:23:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:23:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:23:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:23:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:23:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:23:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:23:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:23:59 --> Final output sent to browser
DEBUG - 2011-09-10 10:23:59 --> Total execution time: 0.2339
DEBUG - 2011-09-10 10:24:11 --> Config Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:24:11 --> URI Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Router Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Output Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Input Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:24:11 --> Language Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Loader Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Controller Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:24:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:24:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:24:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:24:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:24:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:24:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:24:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:24:11 --> Final output sent to browser
DEBUG - 2011-09-10 10:24:11 --> Total execution time: 0.0458
DEBUG - 2011-09-10 10:24:17 --> Config Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:24:17 --> URI Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Router Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Output Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Input Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:24:17 --> Language Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Loader Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Controller Class Initialized
ERROR - 2011-09-10 10:24:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:24:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:24:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:24:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:24:17 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:24:17 --> Final output sent to browser
DEBUG - 2011-09-10 10:24:17 --> Total execution time: 0.0308
DEBUG - 2011-09-10 10:24:17 --> Config Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:24:17 --> URI Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Router Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Output Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Input Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:24:17 --> Language Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Loader Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Controller Class Initialized
ERROR - 2011-09-10 10:24:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:24:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:24:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Model Class Initialized
DEBUG - 2011-09-10 10:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:24:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:24:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:24:18 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:24:18 --> Final output sent to browser
DEBUG - 2011-09-10 10:24:18 --> Total execution time: 0.0274
DEBUG - 2011-09-10 10:25:42 --> Config Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:25:42 --> URI Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Router Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Output Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Input Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:25:42 --> Language Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Loader Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Controller Class Initialized
ERROR - 2011-09-10 10:25:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:25:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:25:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:25:42 --> Model Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Model Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:25:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:25:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:25:42 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:25:42 --> Final output sent to browser
DEBUG - 2011-09-10 10:25:42 --> Total execution time: 0.0280
DEBUG - 2011-09-10 10:25:42 --> Config Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:25:42 --> URI Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Router Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Output Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Input Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:25:42 --> Language Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Loader Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Controller Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Model Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Model Class Initialized
DEBUG - 2011-09-10 10:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:25:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:25:43 --> Final output sent to browser
DEBUG - 2011-09-10 10:25:43 --> Total execution time: 0.6015
DEBUG - 2011-09-10 10:25:59 --> Config Class Initialized
DEBUG - 2011-09-10 10:25:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:25:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:25:59 --> URI Class Initialized
DEBUG - 2011-09-10 10:25:59 --> Router Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Output Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Input Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:26:00 --> Language Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Loader Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Controller Class Initialized
ERROR - 2011-09-10 10:26:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:26:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:26:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:26:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:26:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:26:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:26:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:26:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:26:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:26:00 --> Final output sent to browser
DEBUG - 2011-09-10 10:26:00 --> Total execution time: 0.0271
DEBUG - 2011-09-10 10:26:00 --> Config Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:26:00 --> URI Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Router Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Output Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Input Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:26:00 --> Language Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Loader Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Controller Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:26:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:26:01 --> Final output sent to browser
DEBUG - 2011-09-10 10:26:01 --> Total execution time: 0.5532
DEBUG - 2011-09-10 10:26:20 --> Config Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:26:20 --> URI Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Router Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Output Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Input Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:26:20 --> Language Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Loader Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Controller Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Model Class Initialized
DEBUG - 2011-09-10 10:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:26:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:26:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:26:20 --> Final output sent to browser
DEBUG - 2011-09-10 10:26:20 --> Total execution time: 0.0415
DEBUG - 2011-09-10 10:26:23 --> Config Class Initialized
DEBUG - 2011-09-10 10:26:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:26:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:26:23 --> URI Class Initialized
DEBUG - 2011-09-10 10:26:23 --> Router Class Initialized
ERROR - 2011-09-10 10:26:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:27:40 --> Config Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:27:40 --> URI Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Router Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Output Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Input Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:27:40 --> Language Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Loader Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Controller Class Initialized
ERROR - 2011-09-10 10:27:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:27:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:27:40 --> Model Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Model Class Initialized
DEBUG - 2011-09-10 10:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:27:40 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:27:40 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:27:40 --> Final output sent to browser
DEBUG - 2011-09-10 10:27:40 --> Total execution time: 0.0282
DEBUG - 2011-09-10 10:27:41 --> Config Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:27:41 --> URI Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Router Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Output Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Input Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:27:41 --> Language Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Loader Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Controller Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Model Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Model Class Initialized
DEBUG - 2011-09-10 10:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:27:41 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:27:42 --> Final output sent to browser
DEBUG - 2011-09-10 10:27:42 --> Total execution time: 0.4528
DEBUG - 2011-09-10 10:27:44 --> Config Class Initialized
DEBUG - 2011-09-10 10:27:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:27:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:27:44 --> URI Class Initialized
DEBUG - 2011-09-10 10:27:44 --> Router Class Initialized
ERROR - 2011-09-10 10:27:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:27:44 --> Config Class Initialized
DEBUG - 2011-09-10 10:27:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:27:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:27:44 --> URI Class Initialized
DEBUG - 2011-09-10 10:27:44 --> Router Class Initialized
ERROR - 2011-09-10 10:27:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:40:35 --> Config Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:40:35 --> URI Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Router Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Output Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Input Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:40:35 --> Language Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Loader Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Controller Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Model Class Initialized
DEBUG - 2011-09-10 10:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:40:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:40:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:40:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:40:35 --> Final output sent to browser
DEBUG - 2011-09-10 10:40:35 --> Total execution time: 0.1668
DEBUG - 2011-09-10 10:41:13 --> Config Class Initialized
DEBUG - 2011-09-10 10:41:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:41:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:41:13 --> URI Class Initialized
DEBUG - 2011-09-10 10:41:13 --> Router Class Initialized
ERROR - 2011-09-10 10:41:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:41:14 --> Config Class Initialized
DEBUG - 2011-09-10 10:41:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:41:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:41:15 --> URI Class Initialized
DEBUG - 2011-09-10 10:41:15 --> Router Class Initialized
ERROR - 2011-09-10 10:41:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:41:16 --> Config Class Initialized
DEBUG - 2011-09-10 10:41:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:41:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:41:16 --> URI Class Initialized
DEBUG - 2011-09-10 10:41:16 --> Router Class Initialized
ERROR - 2011-09-10 10:41:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:41:34 --> Config Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:41:34 --> URI Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Router Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Output Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Input Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:41:34 --> Language Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Loader Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Controller Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Model Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Model Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Model Class Initialized
DEBUG - 2011-09-10 10:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:41:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:41:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:41:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:41:34 --> Final output sent to browser
DEBUG - 2011-09-10 10:41:34 --> Total execution time: 0.1323
DEBUG - 2011-09-10 10:41:44 --> Config Class Initialized
DEBUG - 2011-09-10 10:41:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:41:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:41:44 --> URI Class Initialized
DEBUG - 2011-09-10 10:41:44 --> Router Class Initialized
DEBUG - 2011-09-10 10:41:44 --> Output Class Initialized
DEBUG - 2011-09-10 10:41:44 --> Input Class Initialized
DEBUG - 2011-09-10 10:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:41:44 --> Language Class Initialized
DEBUG - 2011-09-10 10:41:45 --> Loader Class Initialized
DEBUG - 2011-09-10 10:41:45 --> Controller Class Initialized
DEBUG - 2011-09-10 10:41:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:41:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:41:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:41:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:41:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:41:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:41:45 --> Final output sent to browser
DEBUG - 2011-09-10 10:41:45 --> Total execution time: 0.0623
DEBUG - 2011-09-10 10:42:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:42:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:42:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:42:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:42:08 --> Router Class Initialized
ERROR - 2011-09-10 10:42:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:42:29 --> Config Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:42:29 --> URI Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Router Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Output Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Input Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:42:29 --> Language Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Loader Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Controller Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:42:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:42:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:42:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:42:30 --> Final output sent to browser
DEBUG - 2011-09-10 10:42:30 --> Total execution time: 0.0518
DEBUG - 2011-09-10 10:43:57 --> Config Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:43:57 --> URI Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Router Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Output Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Input Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:43:57 --> Language Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Loader Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Controller Class Initialized
ERROR - 2011-09-10 10:43:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:43:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:43:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:43:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Model Class Initialized
DEBUG - 2011-09-10 10:43:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:43:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:43:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:43:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:43:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:43:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:43:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:43:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:43:57 --> Final output sent to browser
DEBUG - 2011-09-10 10:43:57 --> Total execution time: 0.0273
DEBUG - 2011-09-10 10:43:59 --> Config Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:43:59 --> URI Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Router Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Output Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Input Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:43:59 --> Language Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Loader Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Controller Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Model Class Initialized
DEBUG - 2011-09-10 10:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:43:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:44:00 --> Final output sent to browser
DEBUG - 2011-09-10 10:44:00 --> Total execution time: 0.6044
DEBUG - 2011-09-10 10:44:03 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:03 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:03 --> Router Class Initialized
ERROR - 2011-09-10 10:44:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:44:08 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:08 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Router Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Output Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Input Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:44:08 --> Language Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Loader Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Controller Class Initialized
ERROR - 2011-09-10 10:44:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:44:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:44:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:44:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:44:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:44:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:44:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:44:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:44:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:44:08 --> Final output sent to browser
DEBUG - 2011-09-10 10:44:08 --> Total execution time: 0.0325
DEBUG - 2011-09-10 10:44:09 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:09 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Router Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Output Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Input Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:44:09 --> Language Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Loader Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Controller Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:44:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:44:10 --> Final output sent to browser
DEBUG - 2011-09-10 10:44:10 --> Total execution time: 0.5656
DEBUG - 2011-09-10 10:44:11 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:11 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:11 --> Router Class Initialized
ERROR - 2011-09-10 10:44:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:44:29 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:29 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Router Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Output Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Input Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:44:29 --> Language Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Loader Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Controller Class Initialized
ERROR - 2011-09-10 10:44:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 10:44:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 10:44:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:44:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:44:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:44:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 10:44:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:44:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:44:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:44:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:44:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:44:29 --> Final output sent to browser
DEBUG - 2011-09-10 10:44:29 --> Total execution time: 0.0301
DEBUG - 2011-09-10 10:44:29 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:29 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Router Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Output Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Input Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:44:29 --> Language Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Loader Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Controller Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Model Class Initialized
DEBUG - 2011-09-10 10:44:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:44:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:44:30 --> Final output sent to browser
DEBUG - 2011-09-10 10:44:30 --> Total execution time: 0.5055
DEBUG - 2011-09-10 10:44:32 --> Config Class Initialized
DEBUG - 2011-09-10 10:44:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:44:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:44:32 --> URI Class Initialized
DEBUG - 2011-09-10 10:44:32 --> Router Class Initialized
ERROR - 2011-09-10 10:44:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:57:51 --> Config Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:57:51 --> URI Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Router Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Output Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Input Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:57:51 --> Language Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Loader Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Controller Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Model Class Initialized
DEBUG - 2011-09-10 10:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:57:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:57:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:57:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:57:51 --> Final output sent to browser
DEBUG - 2011-09-10 10:57:51 --> Total execution time: 0.0483
DEBUG - 2011-09-10 10:57:58 --> Config Class Initialized
DEBUG - 2011-09-10 10:57:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:57:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:57:58 --> URI Class Initialized
DEBUG - 2011-09-10 10:57:58 --> Router Class Initialized
ERROR - 2011-09-10 10:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:57:58 --> Config Class Initialized
DEBUG - 2011-09-10 10:57:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:57:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:57:58 --> URI Class Initialized
DEBUG - 2011-09-10 10:57:58 --> Router Class Initialized
ERROR - 2011-09-10 10:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 10:58:19 --> Config Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:58:19 --> URI Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Router Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Output Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Input Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:58:19 --> Language Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Loader Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Controller Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Model Class Initialized
DEBUG - 2011-09-10 10:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:58:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:58:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:58:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:58:20 --> Final output sent to browser
DEBUG - 2011-09-10 10:58:20 --> Total execution time: 0.6851
DEBUG - 2011-09-10 10:58:45 --> Config Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:58:45 --> URI Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Router Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Output Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Input Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:58:45 --> Language Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Loader Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Controller Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Model Class Initialized
DEBUG - 2011-09-10 10:58:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:58:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:58:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:58:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:58:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:58:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:58:45 --> Final output sent to browser
DEBUG - 2011-09-10 10:58:45 --> Total execution time: 0.2862
DEBUG - 2011-09-10 10:59:24 --> Config Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Hooks Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Utf8 Class Initialized
DEBUG - 2011-09-10 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 10:59:24 --> URI Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Router Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Output Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Input Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 10:59:24 --> Language Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Loader Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Controller Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Model Class Initialized
DEBUG - 2011-09-10 10:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 10:59:24 --> Database Driver Class Initialized
DEBUG - 2011-09-10 10:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 10:59:25 --> Helper loaded: url_helper
DEBUG - 2011-09-10 10:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 10:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 10:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 10:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 10:59:25 --> Final output sent to browser
DEBUG - 2011-09-10 10:59:25 --> Total execution time: 0.8528
DEBUG - 2011-09-10 11:03:51 --> Config Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:03:51 --> URI Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Router Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Output Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Input Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:03:51 --> Language Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Loader Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Controller Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Model Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Model Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Model Class Initialized
DEBUG - 2011-09-10 11:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:03:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:03:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 11:03:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:03:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:03:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:03:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:03:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:03:51 --> Final output sent to browser
DEBUG - 2011-09-10 11:03:51 --> Total execution time: 0.0473
DEBUG - 2011-09-10 11:11:45 --> Config Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:11:45 --> URI Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Router Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Output Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Input Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:11:45 --> Language Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Loader Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Controller Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:11:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:11:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 11:11:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:11:45 --> Final output sent to browser
DEBUG - 2011-09-10 11:11:45 --> Total execution time: 0.0644
DEBUG - 2011-09-10 11:11:48 --> Config Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:11:48 --> URI Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Router Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Output Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Input Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:11:48 --> Language Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Loader Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Controller Class Initialized
ERROR - 2011-09-10 11:11:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 11:11:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 11:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 11:11:48 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:11:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 11:11:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:11:48 --> Final output sent to browser
DEBUG - 2011-09-10 11:11:48 --> Total execution time: 0.0280
DEBUG - 2011-09-10 11:11:48 --> Config Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:11:48 --> URI Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Router Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Output Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Input Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:11:48 --> Language Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Loader Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Controller Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Model Class Initialized
DEBUG - 2011-09-10 11:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:11:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:11:49 --> Final output sent to browser
DEBUG - 2011-09-10 11:11:49 --> Total execution time: 0.5973
DEBUG - 2011-09-10 11:11:51 --> Config Class Initialized
DEBUG - 2011-09-10 11:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:11:51 --> URI Class Initialized
DEBUG - 2011-09-10 11:11:51 --> Router Class Initialized
ERROR - 2011-09-10 11:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:11:51 --> Config Class Initialized
DEBUG - 2011-09-10 11:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:11:51 --> URI Class Initialized
DEBUG - 2011-09-10 11:11:51 --> Router Class Initialized
ERROR - 2011-09-10 11:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:12:23 --> Config Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:12:23 --> URI Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Router Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Output Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Input Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:12:23 --> Language Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Loader Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Controller Class Initialized
ERROR - 2011-09-10 11:12:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 11:12:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 11:12:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 11:12:23 --> Model Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Model Class Initialized
DEBUG - 2011-09-10 11:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:12:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:12:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 11:12:23 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:12:23 --> Final output sent to browser
DEBUG - 2011-09-10 11:12:23 --> Total execution time: 0.0275
DEBUG - 2011-09-10 11:12:25 --> Config Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:12:25 --> URI Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Router Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Output Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Input Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:12:25 --> Language Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Loader Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Controller Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Model Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Model Class Initialized
DEBUG - 2011-09-10 11:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:12:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:12:26 --> Final output sent to browser
DEBUG - 2011-09-10 11:12:26 --> Total execution time: 0.4931
DEBUG - 2011-09-10 11:12:29 --> Config Class Initialized
DEBUG - 2011-09-10 11:12:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:12:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:12:29 --> URI Class Initialized
DEBUG - 2011-09-10 11:12:29 --> Router Class Initialized
ERROR - 2011-09-10 11:12:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:22:03 --> Config Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:22:03 --> URI Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Router Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Output Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Input Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:22:03 --> Language Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Loader Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Controller Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Model Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Model Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Model Class Initialized
DEBUG - 2011-09-10 11:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:22:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:22:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 11:22:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:22:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:22:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:22:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:22:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:22:03 --> Final output sent to browser
DEBUG - 2011-09-10 11:22:03 --> Total execution time: 0.0517
DEBUG - 2011-09-10 11:22:06 --> Config Class Initialized
DEBUG - 2011-09-10 11:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:22:06 --> URI Class Initialized
DEBUG - 2011-09-10 11:22:06 --> Router Class Initialized
ERROR - 2011-09-10 11:22:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:41:47 --> Config Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:41:47 --> URI Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Router Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Output Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Input Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:41:47 --> Language Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Loader Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Controller Class Initialized
ERROR - 2011-09-10 11:41:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 11:41:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 11:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 11:41:47 --> Model Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Model Class Initialized
DEBUG - 2011-09-10 11:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:41:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 11:41:47 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:41:47 --> Final output sent to browser
DEBUG - 2011-09-10 11:41:47 --> Total execution time: 0.0365
DEBUG - 2011-09-10 11:41:51 --> Config Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:41:51 --> URI Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Router Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Output Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Input Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:41:51 --> Language Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Loader Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Controller Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Model Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Model Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:41:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:41:51 --> Final output sent to browser
DEBUG - 2011-09-10 11:41:51 --> Total execution time: 0.6612
DEBUG - 2011-09-10 11:41:53 --> Config Class Initialized
DEBUG - 2011-09-10 11:41:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:41:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:41:53 --> URI Class Initialized
DEBUG - 2011-09-10 11:41:53 --> Router Class Initialized
ERROR - 2011-09-10 11:41:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:44:10 --> Config Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:44:10 --> URI Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Router Class Initialized
DEBUG - 2011-09-10 11:44:10 --> No URI present. Default controller set.
DEBUG - 2011-09-10 11:44:10 --> Output Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Input Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:44:10 --> Language Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Loader Class Initialized
DEBUG - 2011-09-10 11:44:10 --> Controller Class Initialized
DEBUG - 2011-09-10 11:44:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 11:44:10 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:44:10 --> Final output sent to browser
DEBUG - 2011-09-10 11:44:10 --> Total execution time: 0.0966
DEBUG - 2011-09-10 11:51:39 --> Config Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:51:39 --> URI Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Router Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Output Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Input Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:51:39 --> Language Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Loader Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Controller Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Model Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Model Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Model Class Initialized
DEBUG - 2011-09-10 11:51:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:51:39 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:51:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 11:51:39 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:51:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:51:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:51:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:51:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:51:39 --> Final output sent to browser
DEBUG - 2011-09-10 11:51:39 --> Total execution time: 0.2595
DEBUG - 2011-09-10 11:51:59 --> Config Class Initialized
DEBUG - 2011-09-10 11:51:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:51:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:51:59 --> URI Class Initialized
DEBUG - 2011-09-10 11:51:59 --> Router Class Initialized
ERROR - 2011-09-10 11:51:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:52:00 --> Config Class Initialized
DEBUG - 2011-09-10 11:52:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:52:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:52:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:52:00 --> URI Class Initialized
DEBUG - 2011-09-10 11:52:00 --> Router Class Initialized
ERROR - 2011-09-10 11:52:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 11:52:32 --> Config Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:52:32 --> URI Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Router Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Output Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Input Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:52:32 --> Language Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Loader Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Controller Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Model Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Model Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Model Class Initialized
DEBUG - 2011-09-10 11:52:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:52:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:52:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 11:52:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:52:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:52:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:52:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:52:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:52:32 --> Final output sent to browser
DEBUG - 2011-09-10 11:52:32 --> Total execution time: 0.0489
DEBUG - 2011-09-10 11:53:01 --> Config Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 11:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 11:53:01 --> URI Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Router Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Output Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Input Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 11:53:01 --> Language Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Loader Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Controller Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Model Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Model Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Model Class Initialized
DEBUG - 2011-09-10 11:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 11:53:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 11:53:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 11:53:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 11:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 11:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 11:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 11:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 11:53:01 --> Final output sent to browser
DEBUG - 2011-09-10 11:53:01 --> Total execution time: 0.0684
DEBUG - 2011-09-10 12:16:26 --> Config Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:16:26 --> URI Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Router Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Output Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Input Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:16:26 --> Language Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Loader Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Controller Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:16:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:16:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:16:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:16:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:16:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:16:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:16:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:16:26 --> Final output sent to browser
DEBUG - 2011-09-10 12:16:26 --> Total execution time: 0.2839
DEBUG - 2011-09-10 12:16:30 --> Config Class Initialized
DEBUG - 2011-09-10 12:16:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:16:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:16:30 --> URI Class Initialized
DEBUG - 2011-09-10 12:16:30 --> Router Class Initialized
ERROR - 2011-09-10 12:16:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:16:31 --> Config Class Initialized
DEBUG - 2011-09-10 12:16:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:16:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:16:31 --> URI Class Initialized
DEBUG - 2011-09-10 12:16:31 --> Router Class Initialized
ERROR - 2011-09-10 12:16:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:16:48 --> Config Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:16:48 --> URI Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Router Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Output Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Input Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:16:48 --> Language Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Loader Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Controller Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:16:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:16:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:16:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:16:48 --> Final output sent to browser
DEBUG - 2011-09-10 12:16:48 --> Total execution time: 0.2195
DEBUG - 2011-09-10 12:16:49 --> Config Class Initialized
DEBUG - 2011-09-10 12:16:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:16:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:16:49 --> URI Class Initialized
DEBUG - 2011-09-10 12:16:49 --> Router Class Initialized
ERROR - 2011-09-10 12:16:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 12:16:50 --> Config Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:16:50 --> URI Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Router Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Output Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Input Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:16:50 --> Language Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Loader Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Controller Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:16:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:16:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:16:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:16:50 --> Final output sent to browser
DEBUG - 2011-09-10 12:16:50 --> Total execution time: 0.0470
DEBUG - 2011-09-10 12:17:11 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:11 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:11 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:11 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:11 --> Total execution time: 0.2449
DEBUG - 2011-09-10 12:17:14 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:14 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:14 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:14 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:14 --> Total execution time: 0.0449
DEBUG - 2011-09-10 12:17:34 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:34 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:34 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:34 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:34 --> Total execution time: 0.4656
DEBUG - 2011-09-10 12:17:38 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:38 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:38 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:38 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:38 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:38 --> Total execution time: 0.0479
DEBUG - 2011-09-10 12:17:44 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:44 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:44 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:44 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:44 --> Total execution time: 0.2721
DEBUG - 2011-09-10 12:17:46 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:46 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:46 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:46 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:46 --> Total execution time: 0.0517
DEBUG - 2011-09-10 12:17:50 --> Config Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:17:50 --> URI Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Router Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Output Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Input Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:17:50 --> Language Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Loader Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Controller Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:17:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:17:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:17:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:17:50 --> Final output sent to browser
DEBUG - 2011-09-10 12:17:50 --> Total execution time: 0.0613
DEBUG - 2011-09-10 12:18:04 --> Config Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:18:04 --> URI Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Router Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Output Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Input Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:18:04 --> Language Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Loader Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Controller Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:18:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:18:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:18:04 --> Final output sent to browser
DEBUG - 2011-09-10 12:18:04 --> Total execution time: 0.2997
DEBUG - 2011-09-10 12:18:05 --> Config Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:18:05 --> URI Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Router Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Output Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Input Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:18:05 --> Language Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Loader Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Controller Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:18:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:18:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:18:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:18:05 --> Final output sent to browser
DEBUG - 2011-09-10 12:18:05 --> Total execution time: 0.0723
DEBUG - 2011-09-10 12:18:11 --> Config Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:18:11 --> URI Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Router Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Output Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Input Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:18:11 --> Language Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Loader Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Controller Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:18:11 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:18:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:18:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:18:11 --> Final output sent to browser
DEBUG - 2011-09-10 12:18:11 --> Total execution time: 0.4158
DEBUG - 2011-09-10 12:18:13 --> Config Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:18:13 --> URI Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Router Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Output Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Input Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:18:13 --> Language Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Loader Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Controller Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Model Class Initialized
DEBUG - 2011-09-10 12:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:18:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:18:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:18:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:18:13 --> Final output sent to browser
DEBUG - 2011-09-10 12:18:13 --> Total execution time: 0.3187
DEBUG - 2011-09-10 12:23:04 --> Config Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:23:04 --> URI Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Router Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Output Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Input Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:23:04 --> Language Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Loader Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Controller Class Initialized
ERROR - 2011-09-10 12:23:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:23:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:23:04 --> Model Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Model Class Initialized
DEBUG - 2011-09-10 12:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:23:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:23:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:23:04 --> Final output sent to browser
DEBUG - 2011-09-10 12:23:04 --> Total execution time: 0.0287
DEBUG - 2011-09-10 12:23:06 --> Config Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:23:06 --> URI Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Router Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Output Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Input Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:23:06 --> Language Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Loader Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Controller Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Model Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Model Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:23:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:23:06 --> Final output sent to browser
DEBUG - 2011-09-10 12:23:06 --> Total execution time: 0.5736
DEBUG - 2011-09-10 12:23:11 --> Config Class Initialized
DEBUG - 2011-09-10 12:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:23:11 --> URI Class Initialized
DEBUG - 2011-09-10 12:23:11 --> Router Class Initialized
ERROR - 2011-09-10 12:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:29:52 --> Config Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:29:52 --> URI Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Router Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Output Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Input Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:29:52 --> Language Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Loader Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Controller Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Model Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Model Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Model Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:29:52 --> Config Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:29:52 --> URI Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:29:52 --> Router Class Initialized
ERROR - 2011-09-10 12:29:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:29:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:29:52 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:29:52 --> Final output sent to browser
DEBUG - 2011-09-10 12:29:52 --> Total execution time: 0.0469
DEBUG - 2011-09-10 12:29:53 --> Config Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:29:53 --> URI Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Router Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Output Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Input Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:29:53 --> Language Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Loader Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Controller Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Model Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Model Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Model Class Initialized
DEBUG - 2011-09-10 12:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:29:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:29:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:29:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:29:53 --> Final output sent to browser
DEBUG - 2011-09-10 12:29:53 --> Total execution time: 0.0468
DEBUG - 2011-09-10 12:33:38 --> Config Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:33:38 --> URI Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Router Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Output Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Input Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:33:38 --> Language Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Loader Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Controller Class Initialized
ERROR - 2011-09-10 12:33:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:33:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:33:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:33:38 --> Model Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Model Class Initialized
DEBUG - 2011-09-10 12:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:33:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:33:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:33:38 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:33:38 --> Final output sent to browser
DEBUG - 2011-09-10 12:33:38 --> Total execution time: 0.0268
DEBUG - 2011-09-10 12:39:55 --> Config Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:39:55 --> URI Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Config Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:39:55 --> URI Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Router Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Output Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Router Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Input Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:39:55 --> Language Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Output Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Input Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:39:55 --> Language Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Loader Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Controller Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Loader Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Controller Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-09-10 12:39:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:39:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:39:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:39:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:39:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:39:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:39:55 --> Final output sent to browser
DEBUG - 2011-09-10 12:39:55 --> Total execution time: 0.0786
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:39:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:39:55 --> Final output sent to browser
DEBUG - 2011-09-10 12:39:55 --> Total execution time: 0.0551
DEBUG - 2011-09-10 12:43:19 --> Config Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:43:19 --> URI Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Router Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Output Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Input Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:43:19 --> Language Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Loader Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Controller Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Model Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Model Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Model Class Initialized
DEBUG - 2011-09-10 12:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:43:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:43:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:43:19 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:43:19 --> Final output sent to browser
DEBUG - 2011-09-10 12:43:19 --> Total execution time: 0.0464
DEBUG - 2011-09-10 12:43:21 --> Config Class Initialized
DEBUG - 2011-09-10 12:43:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:43:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:43:21 --> URI Class Initialized
DEBUG - 2011-09-10 12:43:21 --> Router Class Initialized
ERROR - 2011-09-10 12:43:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:49:37 --> Config Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:49:37 --> URI Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Router Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Output Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Input Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:49:37 --> Language Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Loader Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Controller Class Initialized
ERROR - 2011-09-10 12:49:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:49:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:49:37 --> Model Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Model Class Initialized
DEBUG - 2011-09-10 12:49:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:49:37 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:49:37 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:49:37 --> Final output sent to browser
DEBUG - 2011-09-10 12:49:37 --> Total execution time: 0.0290
DEBUG - 2011-09-10 12:49:50 --> Config Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:49:50 --> URI Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Router Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Output Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Input Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:49:50 --> Language Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Loader Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Controller Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:49:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:49:50 --> Final output sent to browser
DEBUG - 2011-09-10 12:49:50 --> Total execution time: 0.6164
DEBUG - 2011-09-10 12:50:50 --> Config Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:50:50 --> URI Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Router Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Output Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Input Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:50:50 --> Language Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Loader Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Controller Class Initialized
ERROR - 2011-09-10 12:50:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:50:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:50:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:50:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:50:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:50:50 --> Final output sent to browser
DEBUG - 2011-09-10 12:50:50 --> Total execution time: 0.0501
DEBUG - 2011-09-10 12:50:54 --> Config Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:50:54 --> URI Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Router Class Initialized
ERROR - 2011-09-10 12:50:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:50:54 --> Config Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:50:54 --> URI Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Router Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Output Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Input Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:50:54 --> Language Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Loader Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Controller Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:50:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:50:54 --> Final output sent to browser
DEBUG - 2011-09-10 12:50:54 --> Total execution time: 0.8248
DEBUG - 2011-09-10 12:50:56 --> Config Class Initialized
DEBUG - 2011-09-10 12:50:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:50:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:50:56 --> URI Class Initialized
DEBUG - 2011-09-10 12:50:56 --> Router Class Initialized
ERROR - 2011-09-10 12:50:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:50:59 --> Config Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:50:59 --> URI Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Router Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Output Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Input Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:50:59 --> Language Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Loader Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Controller Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Model Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:50:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:50:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:50:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:50:59 --> Final output sent to browser
DEBUG - 2011-09-10 12:50:59 --> Total execution time: 0.0887
DEBUG - 2011-09-10 12:50:59 --> Config Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:50:59 --> URI Class Initialized
DEBUG - 2011-09-10 12:50:59 --> Router Class Initialized
ERROR - 2011-09-10 12:50:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:51:02 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:02 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:02 --> Router Class Initialized
ERROR - 2011-09-10 12:51:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:51:18 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:18 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:18 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:19 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:19 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:19 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:19 --> Total execution time: 0.3798
DEBUG - 2011-09-10 12:51:20 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:20 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:20 --> Router Class Initialized
ERROR - 2011-09-10 12:51:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:51:31 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:31 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:31 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:32 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:32 --> Total execution time: 0.6098
DEBUG - 2011-09-10 12:51:33 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:33 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:33 --> Router Class Initialized
ERROR - 2011-09-10 12:51:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:51:42 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:42 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:42 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:43 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:43 --> Total execution time: 1.0435
DEBUG - 2011-09-10 12:51:44 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:44 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:44 --> Router Class Initialized
ERROR - 2011-09-10 12:51:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:51:45 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:45 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:45 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:45 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:45 --> Total execution time: 0.0612
DEBUG - 2011-09-10 12:51:50 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:50 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:50 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:50 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:50 --> Total execution time: 0.2703
DEBUG - 2011-09-10 12:51:51 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:51 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:51 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:51 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:51 --> Total execution time: 0.1163
DEBUG - 2011-09-10 12:51:51 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:51 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:51 --> Router Class Initialized
ERROR - 2011-09-10 12:51:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:51:58 --> Config Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:51:58 --> URI Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Router Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Output Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Input Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:51:58 --> Language Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Loader Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Controller Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Model Class Initialized
DEBUG - 2011-09-10 12:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:51:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:51:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:51:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:51:59 --> Final output sent to browser
DEBUG - 2011-09-10 12:51:59 --> Total execution time: 0.2367
DEBUG - 2011-09-10 12:52:00 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:00 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:00 --> Router Class Initialized
ERROR - 2011-09-10 12:52:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:52:10 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:10 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Router Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Output Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Input Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:52:10 --> Language Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Loader Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Controller Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:52:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:52:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:52:11 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:52:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:52:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:52:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:52:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:52:11 --> Final output sent to browser
DEBUG - 2011-09-10 12:52:11 --> Total execution time: 0.2600
DEBUG - 2011-09-10 12:52:12 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:12 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:12 --> Router Class Initialized
ERROR - 2011-09-10 12:52:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:52:20 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:20 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Router Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Output Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Input Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:52:20 --> Language Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Loader Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Controller Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:52:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:52:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:52:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:52:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:52:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:52:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:52:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:52:20 --> Final output sent to browser
DEBUG - 2011-09-10 12:52:20 --> Total execution time: 0.2255
DEBUG - 2011-09-10 12:52:22 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:22 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:22 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:22 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:22 --> Router Class Initialized
ERROR - 2011-09-10 12:52:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:52:27 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:27 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Router Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Output Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Input Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:52:27 --> Language Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Loader Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Controller Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:52:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:52:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:52:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:52:27 --> Final output sent to browser
DEBUG - 2011-09-10 12:52:27 --> Total execution time: 0.2234
DEBUG - 2011-09-10 12:52:28 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:28 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:28 --> Router Class Initialized
ERROR - 2011-09-10 12:52:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:52:29 --> Config Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:52:29 --> URI Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Router Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Output Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Input Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:52:29 --> Language Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Loader Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Controller Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:52:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:52:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:52:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 12:52:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:52:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:52:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:52:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:52:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:52:30 --> Final output sent to browser
DEBUG - 2011-09-10 12:52:30 --> Total execution time: 0.1772
DEBUG - 2011-09-10 12:55:43 --> Config Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:55:43 --> URI Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Router Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Output Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Input Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:55:43 --> Language Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Loader Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Controller Class Initialized
ERROR - 2011-09-10 12:55:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:55:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:55:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:55:43 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:55:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:55:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:55:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:55:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:55:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:55:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:55:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:55:43 --> Final output sent to browser
DEBUG - 2011-09-10 12:55:43 --> Total execution time: 0.0345
DEBUG - 2011-09-10 12:55:44 --> Config Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:55:44 --> URI Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Router Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Output Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Input Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:55:44 --> Language Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Loader Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Controller Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:55:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:55:44 --> Final output sent to browser
DEBUG - 2011-09-10 12:55:44 --> Total execution time: 0.4920
DEBUG - 2011-09-10 12:55:45 --> Config Class Initialized
DEBUG - 2011-09-10 12:55:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:55:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:55:45 --> URI Class Initialized
DEBUG - 2011-09-10 12:55:45 --> Router Class Initialized
ERROR - 2011-09-10 12:55:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 12:55:51 --> Config Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:55:51 --> URI Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Router Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Output Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Input Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:55:51 --> Language Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Loader Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Controller Class Initialized
ERROR - 2011-09-10 12:55:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:55:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:55:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:55:51 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:55:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:55:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:55:51 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:55:51 --> Final output sent to browser
DEBUG - 2011-09-10 12:55:51 --> Total execution time: 0.0282
DEBUG - 2011-09-10 12:55:51 --> Config Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:55:51 --> URI Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Router Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Output Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Input Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:55:51 --> Language Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Loader Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Controller Class Initialized
DEBUG - 2011-09-10 12:55:51 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:52 --> Model Class Initialized
DEBUG - 2011-09-10 12:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:55:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:55:52 --> Final output sent to browser
DEBUG - 2011-09-10 12:55:52 --> Total execution time: 0.5012
DEBUG - 2011-09-10 12:56:29 --> Config Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:56:29 --> URI Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Router Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Output Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Input Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:56:29 --> Language Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Loader Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Controller Class Initialized
ERROR - 2011-09-10 12:56:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:56:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:56:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:56:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:56:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:56:29 --> Final output sent to browser
DEBUG - 2011-09-10 12:56:29 --> Total execution time: 0.0398
DEBUG - 2011-09-10 12:56:30 --> Config Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:56:30 --> URI Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Router Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Output Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Input Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:56:30 --> Language Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Loader Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Controller Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Model Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Model Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:56:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:56:30 --> Final output sent to browser
DEBUG - 2011-09-10 12:56:30 --> Total execution time: 0.7377
DEBUG - 2011-09-10 12:57:00 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:00 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:00 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Controller Class Initialized
ERROR - 2011-09-10 12:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:00 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:57:00 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:00 --> Total execution time: 0.0309
DEBUG - 2011-09-10 12:57:01 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:01 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:01 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Controller Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:02 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:02 --> Total execution time: 0.5592
DEBUG - 2011-09-10 12:57:08 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:08 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:08 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Controller Class Initialized
ERROR - 2011-09-10 12:57:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:57:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:57:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:08 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:57:08 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:08 --> Total execution time: 0.0317
DEBUG - 2011-09-10 12:57:09 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:09 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:09 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Controller Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:10 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:10 --> Total execution time: 1.0011
DEBUG - 2011-09-10 12:57:22 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:22 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:22 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Controller Class Initialized
ERROR - 2011-09-10 12:57:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:57:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:22 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:22 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:22 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:57:22 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:22 --> Total execution time: 0.0282
DEBUG - 2011-09-10 12:57:23 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:23 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:23 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Controller Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:23 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:23 --> Total execution time: 0.6958
DEBUG - 2011-09-10 12:57:29 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:29 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:29 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Controller Class Initialized
ERROR - 2011-09-10 12:57:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:57:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:57:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:57:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:57:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:57:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:57:29 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:29 --> Total execution time: 0.0408
DEBUG - 2011-09-10 12:57:30 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:30 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Router Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Output Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Input Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:57:30 --> Language Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Loader Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Controller Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Model Class Initialized
DEBUG - 2011-09-10 12:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:57:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:57:31 --> Final output sent to browser
DEBUG - 2011-09-10 12:57:31 --> Total execution time: 0.6424
DEBUG - 2011-09-10 12:57:51 --> Config Class Initialized
DEBUG - 2011-09-10 12:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:57:51 --> URI Class Initialized
DEBUG - 2011-09-10 12:57:51 --> Router Class Initialized
ERROR - 2011-09-10 12:57:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 12:58:01 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:01 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:01 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Controller Class Initialized
ERROR - 2011-09-10 12:58:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:58:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:58:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:01 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:58:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:58:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:58:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:58:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:58:01 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:01 --> Total execution time: 0.0336
DEBUG - 2011-09-10 12:58:02 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:02 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:02 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Controller Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:02 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:04 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:04 --> Total execution time: 1.6876
DEBUG - 2011-09-10 12:58:15 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:15 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:15 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Controller Class Initialized
ERROR - 2011-09-10 12:58:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:58:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:58:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:15 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:58:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:58:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:58:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:58:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:58:15 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:15 --> Total execution time: 0.0263
DEBUG - 2011-09-10 12:58:15 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:15 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:15 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Controller Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:16 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:16 --> Total execution time: 0.7628
DEBUG - 2011-09-10 12:58:27 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:27 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:27 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Controller Class Initialized
ERROR - 2011-09-10 12:58:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:58:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:27 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:58:27 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:27 --> Total execution time: 0.0344
DEBUG - 2011-09-10 12:58:28 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:28 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:28 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Controller Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:29 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:29 --> Total execution time: 0.7352
DEBUG - 2011-09-10 12:58:57 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:57 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:57 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Controller Class Initialized
ERROR - 2011-09-10 12:58:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:58:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:58:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:57 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:58:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:58:57 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:57 --> Total execution time: 0.0628
DEBUG - 2011-09-10 12:58:57 --> Config Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:58:57 --> URI Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Router Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Output Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Input Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:58:57 --> Language Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Loader Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Controller Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Model Class Initialized
DEBUG - 2011-09-10 12:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:58:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:58:58 --> Final output sent to browser
DEBUG - 2011-09-10 12:58:58 --> Total execution time: 0.6487
DEBUG - 2011-09-10 12:59:16 --> Config Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:59:16 --> URI Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Router Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Output Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Input Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:59:16 --> Language Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Loader Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Controller Class Initialized
ERROR - 2011-09-10 12:59:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:59:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:59:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:59:16 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:59:16 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:59:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:59:16 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:59:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:59:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:59:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:59:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:59:16 --> Final output sent to browser
DEBUG - 2011-09-10 12:59:16 --> Total execution time: 0.0281
DEBUG - 2011-09-10 12:59:16 --> Config Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:59:16 --> URI Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Router Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Output Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Input Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:59:16 --> Language Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Loader Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Controller Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:59:16 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:59:17 --> Final output sent to browser
DEBUG - 2011-09-10 12:59:17 --> Total execution time: 0.6205
DEBUG - 2011-09-10 12:59:33 --> Config Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:59:33 --> URI Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Router Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Output Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Input Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:59:33 --> Language Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Loader Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Controller Class Initialized
ERROR - 2011-09-10 12:59:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:59:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:59:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:59:33 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:59:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:59:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:59:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:59:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:59:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:59:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:59:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:59:33 --> Final output sent to browser
DEBUG - 2011-09-10 12:59:33 --> Total execution time: 0.1740
DEBUG - 2011-09-10 12:59:34 --> Config Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:59:34 --> URI Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Router Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Output Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Input Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:59:34 --> Language Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Loader Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Controller Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:59:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:59:35 --> Final output sent to browser
DEBUG - 2011-09-10 12:59:35 --> Total execution time: 0.8120
DEBUG - 2011-09-10 12:59:55 --> Config Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:59:55 --> URI Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Router Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Output Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Input Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:59:55 --> Language Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Loader Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Controller Class Initialized
ERROR - 2011-09-10 12:59:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 12:59:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 12:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:59:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:59:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 12:59:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 12:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 12:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 12:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 12:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 12:59:55 --> Final output sent to browser
DEBUG - 2011-09-10 12:59:55 --> Total execution time: 0.0262
DEBUG - 2011-09-10 12:59:56 --> Config Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Hooks Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Utf8 Class Initialized
DEBUG - 2011-09-10 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 12:59:56 --> URI Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Router Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Output Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Input Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 12:59:56 --> Language Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Loader Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Controller Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Model Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 12:59:56 --> Database Driver Class Initialized
DEBUG - 2011-09-10 12:59:56 --> Final output sent to browser
DEBUG - 2011-09-10 12:59:56 --> Total execution time: 0.5923
DEBUG - 2011-09-10 13:00:09 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:09 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:09 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Controller Class Initialized
ERROR - 2011-09-10 13:00:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:00:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:09 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:00:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:00:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:00:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:00:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:00:09 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:09 --> Total execution time: 0.0320
DEBUG - 2011-09-10 13:00:09 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:09 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:09 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Controller Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:10 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:10 --> Total execution time: 0.5353
DEBUG - 2011-09-10 13:00:25 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:25 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:25 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Controller Class Initialized
ERROR - 2011-09-10 13:00:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:00:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:00:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:25 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:00:25 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:25 --> Total execution time: 0.0283
DEBUG - 2011-09-10 13:00:25 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:25 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:25 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Controller Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:27 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:27 --> Total execution time: 1.6962
DEBUG - 2011-09-10 13:00:38 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:38 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:38 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Controller Class Initialized
ERROR - 2011-09-10 13:00:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:00:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:00:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:38 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:38 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:00:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:00:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:00:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:00:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:00:38 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:38 --> Total execution time: 0.0300
DEBUG - 2011-09-10 13:00:39 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:39 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:39 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Controller Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:39 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:39 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:39 --> Total execution time: 0.6377
DEBUG - 2011-09-10 13:00:40 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:40 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:40 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Controller Class Initialized
ERROR - 2011-09-10 13:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:40 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:40 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:40 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:00:40 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:40 --> Total execution time: 0.1443
DEBUG - 2011-09-10 13:00:42 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:42 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:42 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Controller Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:42 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:42 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:42 --> Total execution time: 0.4645
DEBUG - 2011-09-10 13:00:55 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:55 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:55 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Controller Class Initialized
ERROR - 2011-09-10 13:00:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:00:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:55 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:00:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:00:55 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:55 --> Total execution time: 0.0620
DEBUG - 2011-09-10 13:00:55 --> Config Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:00:55 --> URI Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Router Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Output Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Input Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:00:55 --> Language Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Loader Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Controller Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Model Class Initialized
DEBUG - 2011-09-10 13:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:00:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:00:56 --> Final output sent to browser
DEBUG - 2011-09-10 13:00:56 --> Total execution time: 0.5352
DEBUG - 2011-09-10 13:01:06 --> Config Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:01:06 --> URI Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Router Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Output Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Input Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:01:06 --> Language Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Loader Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Controller Class Initialized
ERROR - 2011-09-10 13:01:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:01:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:01:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:01:06 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:01:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:01:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:01:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:01:06 --> Final output sent to browser
DEBUG - 2011-09-10 13:01:06 --> Total execution time: 0.1270
DEBUG - 2011-09-10 13:01:07 --> Config Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:01:07 --> URI Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Router Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Output Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Input Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:01:07 --> Language Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Loader Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Controller Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:01:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:01:07 --> Final output sent to browser
DEBUG - 2011-09-10 13:01:07 --> Total execution time: 0.5556
DEBUG - 2011-09-10 13:01:23 --> Config Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:01:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:01:23 --> URI Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Router Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Output Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Input Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:01:23 --> Language Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Loader Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Controller Class Initialized
ERROR - 2011-09-10 13:01:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:01:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:01:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:01:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:01:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:01:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:01:23 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:01:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:01:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:01:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:01:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:01:23 --> Final output sent to browser
DEBUG - 2011-09-10 13:01:23 --> Total execution time: 0.0300
DEBUG - 2011-09-10 13:01:23 --> Config Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:01:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:01:23 --> URI Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Router Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Output Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Input Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:01:23 --> Language Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Loader Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Controller Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:01:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:01:24 --> Final output sent to browser
DEBUG - 2011-09-10 13:01:24 --> Total execution time: 0.4568
DEBUG - 2011-09-10 13:01:52 --> Config Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:01:52 --> URI Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Router Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Output Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Input Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:01:52 --> Language Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Loader Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Controller Class Initialized
ERROR - 2011-09-10 13:01:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:01:52 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:01:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:01:52 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:01:52 --> Final output sent to browser
DEBUG - 2011-09-10 13:01:52 --> Total execution time: 0.0281
DEBUG - 2011-09-10 13:01:53 --> Config Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:01:53 --> URI Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Router Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Output Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Input Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:01:53 --> Language Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Loader Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Controller Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Model Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:01:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:01:53 --> Final output sent to browser
DEBUG - 2011-09-10 13:01:53 --> Total execution time: 0.4976
DEBUG - 2011-09-10 13:02:15 --> Config Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:02:15 --> URI Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Router Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Output Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Input Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:02:15 --> Language Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Loader Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Controller Class Initialized
ERROR - 2011-09-10 13:02:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:02:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:02:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:02:15 --> Model Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Model Class Initialized
DEBUG - 2011-09-10 13:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:02:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:02:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:02:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:02:15 --> Final output sent to browser
DEBUG - 2011-09-10 13:02:15 --> Total execution time: 0.0729
DEBUG - 2011-09-10 13:02:16 --> Config Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:02:16 --> URI Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Router Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Output Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Input Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:02:16 --> Language Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Loader Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Controller Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Model Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Model Class Initialized
DEBUG - 2011-09-10 13:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:02:16 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:02:17 --> Final output sent to browser
DEBUG - 2011-09-10 13:02:17 --> Total execution time: 0.5184
DEBUG - 2011-09-10 13:03:24 --> Config Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:03:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:03:24 --> URI Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Router Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Output Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Input Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:03:24 --> Language Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Loader Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Controller Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:03:24 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:03:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:03:24 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:03:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:03:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:03:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:03:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:03:24 --> Final output sent to browser
DEBUG - 2011-09-10 13:03:24 --> Total execution time: 0.0461
DEBUG - 2011-09-10 13:03:29 --> Config Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:03:29 --> URI Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Router Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Output Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Input Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:03:29 --> Language Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Loader Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Controller Class Initialized
ERROR - 2011-09-10 13:03:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:03:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:03:29 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:03:29 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:03:29 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:03:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:03:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:03:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:03:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:03:29 --> Final output sent to browser
DEBUG - 2011-09-10 13:03:29 --> Total execution time: 0.0271
DEBUG - 2011-09-10 13:03:31 --> Config Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:03:31 --> URI Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Router Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Output Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Input Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:03:31 --> Language Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Loader Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Controller Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Model Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:03:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:03:31 --> Final output sent to browser
DEBUG - 2011-09-10 13:03:31 --> Total execution time: 0.5477
DEBUG - 2011-09-10 13:03:32 --> Config Class Initialized
DEBUG - 2011-09-10 13:03:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:03:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:03:32 --> URI Class Initialized
DEBUG - 2011-09-10 13:03:32 --> Router Class Initialized
ERROR - 2011-09-10 13:03:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:04:06 --> Config Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:04:06 --> URI Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Router Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Output Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Input Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:04:06 --> Language Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Loader Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Controller Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Model Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Model Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Model Class Initialized
DEBUG - 2011-09-10 13:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:04:06 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:04:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:04:07 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:04:07 --> Final output sent to browser
DEBUG - 2011-09-10 13:04:07 --> Total execution time: 0.4476
DEBUG - 2011-09-10 13:16:27 --> Config Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:16:27 --> URI Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Router Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Output Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Input Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:16:27 --> Language Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Loader Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Controller Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Model Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Model Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Model Class Initialized
DEBUG - 2011-09-10 13:16:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:16:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:16:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:16:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:16:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:16:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:16:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:16:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:16:27 --> Final output sent to browser
DEBUG - 2011-09-10 13:16:27 --> Total execution time: 0.0498
DEBUG - 2011-09-10 13:16:30 --> Config Class Initialized
DEBUG - 2011-09-10 13:16:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:16:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:16:30 --> URI Class Initialized
DEBUG - 2011-09-10 13:16:30 --> Router Class Initialized
ERROR - 2011-09-10 13:16:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:16:47 --> Config Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:16:47 --> URI Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Router Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Output Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Input Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:16:47 --> Language Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Loader Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Controller Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Model Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Model Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Model Class Initialized
DEBUG - 2011-09-10 13:16:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:16:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:16:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:16:47 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:16:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:16:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:16:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:16:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:16:47 --> Final output sent to browser
DEBUG - 2011-09-10 13:16:47 --> Total execution time: 0.2170
DEBUG - 2011-09-10 13:17:02 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:02 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:02 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Controller Class Initialized
ERROR - 2011-09-10 13:17:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:17:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:17:02 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:02 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:17:02 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:17:02 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:02 --> Total execution time: 0.0268
DEBUG - 2011-09-10 13:17:03 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:03 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:03 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Controller Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:03 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:03 --> Total execution time: 0.5445
DEBUG - 2011-09-10 13:17:04 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:04 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:04 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Controller Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:17:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:17:04 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:04 --> Total execution time: 0.0452
DEBUG - 2011-09-10 13:17:04 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:04 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:04 --> Router Class Initialized
ERROR - 2011-09-10 13:17:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:17:05 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:05 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:05 --> Router Class Initialized
ERROR - 2011-09-10 13:17:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:17:09 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:09 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:09 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Controller Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:17:09 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:17:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:17:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:17:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:17:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:17:09 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:09 --> Total execution time: 0.0597
DEBUG - 2011-09-10 13:17:23 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:23 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:23 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Controller Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:17:23 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:17:23 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:23 --> Total execution time: 0.0856
DEBUG - 2011-09-10 13:17:25 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:25 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:25 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Controller Class Initialized
ERROR - 2011-09-10 13:17:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:17:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:17:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:17:25 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:17:25 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:25 --> Total execution time: 0.0745
DEBUG - 2011-09-10 13:17:25 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:25 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:25 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Controller Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:25 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:27 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:27 --> Total execution time: 1.0772
DEBUG - 2011-09-10 13:17:50 --> Config Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:17:50 --> URI Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Router Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Output Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Input Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:17:50 --> Language Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Loader Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Controller Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Model Class Initialized
DEBUG - 2011-09-10 13:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:17:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:17:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:17:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:17:50 --> Final output sent to browser
DEBUG - 2011-09-10 13:17:50 --> Total execution time: 0.0425
DEBUG - 2011-09-10 13:33:23 --> Config Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:33:23 --> URI Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Router Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Output Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Input Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:33:23 --> Language Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Loader Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Controller Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Model Class Initialized
DEBUG - 2011-09-10 13:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:33:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:33:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:33:23 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:33:23 --> Final output sent to browser
DEBUG - 2011-09-10 13:33:23 --> Total execution time: 0.0611
DEBUG - 2011-09-10 13:33:25 --> Config Class Initialized
DEBUG - 2011-09-10 13:33:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:33:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:33:25 --> URI Class Initialized
DEBUG - 2011-09-10 13:33:25 --> Router Class Initialized
ERROR - 2011-09-10 13:33:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:53:45 --> Config Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:53:45 --> URI Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Router Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Output Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Input Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:53:45 --> Language Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Loader Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Controller Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Model Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Model Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Model Class Initialized
DEBUG - 2011-09-10 13:53:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:53:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:53:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:53:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:53:46 --> Final output sent to browser
DEBUG - 2011-09-10 13:53:46 --> Total execution time: 0.0685
DEBUG - 2011-09-10 13:53:50 --> Config Class Initialized
DEBUG - 2011-09-10 13:53:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:53:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:53:50 --> URI Class Initialized
DEBUG - 2011-09-10 13:53:50 --> Router Class Initialized
ERROR - 2011-09-10 13:53:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:54:12 --> Config Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:54:12 --> URI Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Router Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Output Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Input Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:54:12 --> Language Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Loader Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Controller Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:54:12 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:54:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:54:12 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:54:12 --> Final output sent to browser
DEBUG - 2011-09-10 13:54:12 --> Total execution time: 0.3387
DEBUG - 2011-09-10 13:54:33 --> Config Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:54:33 --> URI Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Router Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Output Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Input Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:54:33 --> Language Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Loader Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Controller Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:54:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:54:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:54:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:54:34 --> Final output sent to browser
DEBUG - 2011-09-10 13:54:34 --> Total execution time: 0.4014
DEBUG - 2011-09-10 13:54:43 --> Config Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:54:43 --> URI Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Router Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Output Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Input Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:54:43 --> Language Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Loader Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Controller Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:54:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:54:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:54:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:54:43 --> Final output sent to browser
DEBUG - 2011-09-10 13:54:43 --> Total execution time: 0.3847
DEBUG - 2011-09-10 13:54:44 --> Config Class Initialized
DEBUG - 2011-09-10 13:54:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:54:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:54:44 --> URI Class Initialized
DEBUG - 2011-09-10 13:54:44 --> Router Class Initialized
ERROR - 2011-09-10 13:54:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:54:51 --> Config Class Initialized
DEBUG - 2011-09-10 13:54:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:54:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:54:51 --> URI Class Initialized
DEBUG - 2011-09-10 13:54:51 --> Router Class Initialized
ERROR - 2011-09-10 13:54:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:54:53 --> Config Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:54:53 --> URI Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Router Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Output Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Input Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:54:53 --> Language Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Loader Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Controller Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Model Class Initialized
DEBUG - 2011-09-10 13:54:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:54:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:54:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:54:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:54:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:54:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:54:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:54:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:54:53 --> Final output sent to browser
DEBUG - 2011-09-10 13:54:53 --> Total execution time: 0.2613
DEBUG - 2011-09-10 13:55:00 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:00 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:00 --> Router Class Initialized
ERROR - 2011-09-10 13:55:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:55:10 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:10 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Router Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Output Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Input Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:55:10 --> Language Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Loader Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Controller Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:55:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:55:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:55:10 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:55:10 --> Final output sent to browser
DEBUG - 2011-09-10 13:55:10 --> Total execution time: 0.4618
DEBUG - 2011-09-10 13:55:22 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:22 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:22 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:22 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:22 --> Router Class Initialized
ERROR - 2011-09-10 13:55:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:55:23 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:23 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:23 --> Router Class Initialized
ERROR - 2011-09-10 13:55:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:55:26 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:26 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Router Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Output Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Input Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:55:26 --> Language Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Loader Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Controller Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:55:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:55:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:55:26 --> Final output sent to browser
DEBUG - 2011-09-10 13:55:26 --> Total execution time: 0.4400
DEBUG - 2011-09-10 13:55:28 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:28 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:28 --> Router Class Initialized
ERROR - 2011-09-10 13:55:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:55:34 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:34 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Router Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Output Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Input Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:55:34 --> Language Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Loader Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Controller Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:55:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:55:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:55:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:55:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:55:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:55:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:55:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:55:34 --> Final output sent to browser
DEBUG - 2011-09-10 13:55:34 --> Total execution time: 0.3007
DEBUG - 2011-09-10 13:55:37 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:37 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:37 --> Router Class Initialized
ERROR - 2011-09-10 13:55:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:55:46 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:46 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Router Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Output Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Input Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:55:46 --> Language Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Loader Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Controller Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Model Class Initialized
DEBUG - 2011-09-10 13:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:55:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:55:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 13:55:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:55:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:55:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:55:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:55:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:55:46 --> Final output sent to browser
DEBUG - 2011-09-10 13:55:46 --> Total execution time: 0.1932
DEBUG - 2011-09-10 13:55:51 --> Config Class Initialized
DEBUG - 2011-09-10 13:55:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:55:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:55:51 --> URI Class Initialized
DEBUG - 2011-09-10 13:55:51 --> Router Class Initialized
ERROR - 2011-09-10 13:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:56:45 --> Config Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:56:45 --> URI Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Router Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Output Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Input Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:56:45 --> Language Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Loader Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Controller Class Initialized
ERROR - 2011-09-10 13:56:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:56:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:56:45 --> Model Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Model Class Initialized
DEBUG - 2011-09-10 13:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:56:45 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:56:45 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:56:45 --> Final output sent to browser
DEBUG - 2011-09-10 13:56:45 --> Total execution time: 0.1467
DEBUG - 2011-09-10 13:56:46 --> Config Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:56:46 --> URI Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Router Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Output Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Input Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:56:46 --> Language Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Loader Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Controller Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Model Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Model Class Initialized
DEBUG - 2011-09-10 13:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:56:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:56:47 --> Final output sent to browser
DEBUG - 2011-09-10 13:56:47 --> Total execution time: 0.7796
DEBUG - 2011-09-10 13:57:15 --> Config Class Initialized
DEBUG - 2011-09-10 13:57:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:57:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:57:15 --> URI Class Initialized
DEBUG - 2011-09-10 13:57:15 --> Router Class Initialized
ERROR - 2011-09-10 13:57:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:57:27 --> Config Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:57:27 --> URI Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Router Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Output Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Input Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:57:27 --> Language Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Loader Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Controller Class Initialized
ERROR - 2011-09-10 13:57:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:57:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:57:27 --> Model Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Model Class Initialized
DEBUG - 2011-09-10 13:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:57:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:57:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:57:27 --> Final output sent to browser
DEBUG - 2011-09-10 13:57:27 --> Total execution time: 0.0446
DEBUG - 2011-09-10 13:57:28 --> Config Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:57:28 --> URI Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Router Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Output Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Input Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:57:28 --> Language Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Loader Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Controller Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Model Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Model Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:57:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:57:28 --> Final output sent to browser
DEBUG - 2011-09-10 13:57:28 --> Total execution time: 0.6692
DEBUG - 2011-09-10 13:58:58 --> Config Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:58:58 --> URI Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Router Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Output Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Input Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:58:58 --> Language Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Loader Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Controller Class Initialized
ERROR - 2011-09-10 13:58:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 13:58:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 13:58:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:58:58 --> Model Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Model Class Initialized
DEBUG - 2011-09-10 13:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:58:58 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:58:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 13:58:58 --> Helper loaded: url_helper
DEBUG - 2011-09-10 13:58:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 13:58:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 13:58:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 13:58:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 13:58:58 --> Final output sent to browser
DEBUG - 2011-09-10 13:58:58 --> Total execution time: 0.0393
DEBUG - 2011-09-10 13:58:59 --> Config Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:58:59 --> URI Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Router Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Output Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Input Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 13:58:59 --> Language Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Loader Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Controller Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Model Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Model Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 13:58:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 13:58:59 --> Final output sent to browser
DEBUG - 2011-09-10 13:58:59 --> Total execution time: 0.4471
DEBUG - 2011-09-10 13:59:03 --> Config Class Initialized
DEBUG - 2011-09-10 13:59:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:59:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:59:03 --> URI Class Initialized
DEBUG - 2011-09-10 13:59:03 --> Router Class Initialized
ERROR - 2011-09-10 13:59:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 13:59:04 --> Config Class Initialized
DEBUG - 2011-09-10 13:59:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 13:59:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 13:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 13:59:04 --> URI Class Initialized
DEBUG - 2011-09-10 13:59:04 --> Router Class Initialized
ERROR - 2011-09-10 13:59:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:09:00 --> Config Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:09:00 --> URI Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Router Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Output Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Input Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:09:00 --> Language Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Loader Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Controller Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Model Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Model Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Model Class Initialized
DEBUG - 2011-09-10 14:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:09:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:09:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 14:09:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:09:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:09:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:09:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:09:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:09:01 --> Final output sent to browser
DEBUG - 2011-09-10 14:09:01 --> Total execution time: 0.4849
DEBUG - 2011-09-10 14:09:03 --> Config Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:09:03 --> URI Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Router Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Output Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Input Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:09:03 --> Language Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Loader Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Controller Class Initialized
ERROR - 2011-09-10 14:09:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 14:09:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 14:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:09:03 --> Model Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Model Class Initialized
DEBUG - 2011-09-10 14:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:09:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:09:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:09:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:09:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:09:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:09:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:09:03 --> Final output sent to browser
DEBUG - 2011-09-10 14:09:03 --> Total execution time: 0.0313
DEBUG - 2011-09-10 14:13:38 --> Config Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:13:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:13:38 --> URI Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Router Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Output Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Input Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:13:38 --> Language Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Loader Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Controller Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Model Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Model Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Model Class Initialized
DEBUG - 2011-09-10 14:13:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:13:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:13:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 14:13:38 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:13:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:13:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:13:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:13:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:13:38 --> Final output sent to browser
DEBUG - 2011-09-10 14:13:38 --> Total execution time: 0.1244
DEBUG - 2011-09-10 14:22:05 --> Config Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:22:05 --> URI Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Router Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Output Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Input Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:22:05 --> Language Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Loader Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Controller Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Model Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Model Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Model Class Initialized
DEBUG - 2011-09-10 14:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:22:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:22:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 14:22:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:22:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:22:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:22:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:22:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:22:05 --> Final output sent to browser
DEBUG - 2011-09-10 14:22:05 --> Total execution time: 0.0634
DEBUG - 2011-09-10 14:30:07 --> Config Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:30:07 --> URI Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Router Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Output Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Input Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:30:07 --> Language Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Loader Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Controller Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Model Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Model Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Model Class Initialized
DEBUG - 2011-09-10 14:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:30:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:30:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 14:30:07 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:30:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:30:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:30:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:30:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:30:07 --> Final output sent to browser
DEBUG - 2011-09-10 14:30:07 --> Total execution time: 0.0627
DEBUG - 2011-09-10 14:48:57 --> Config Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:48:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:48:57 --> URI Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Router Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Output Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Input Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:48:57 --> Language Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Loader Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Controller Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Model Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Model Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Model Class Initialized
DEBUG - 2011-09-10 14:48:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:48:57 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:48:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 14:48:57 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:48:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:48:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:48:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:48:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:48:57 --> Final output sent to browser
DEBUG - 2011-09-10 14:48:57 --> Total execution time: 0.0436
DEBUG - 2011-09-10 14:48:58 --> Config Class Initialized
DEBUG - 2011-09-10 14:48:58 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:48:58 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:48:58 --> URI Class Initialized
DEBUG - 2011-09-10 14:48:58 --> Router Class Initialized
ERROR - 2011-09-10 14:48:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:48:59 --> Config Class Initialized
DEBUG - 2011-09-10 14:48:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:48:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:48:59 --> URI Class Initialized
DEBUG - 2011-09-10 14:48:59 --> Router Class Initialized
ERROR - 2011-09-10 14:48:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:53:49 --> Config Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:53:49 --> URI Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Router Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Output Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Input Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:53:49 --> Language Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Loader Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Controller Class Initialized
ERROR - 2011-09-10 14:53:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 14:53:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 14:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:53:49 --> Model Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Model Class Initialized
DEBUG - 2011-09-10 14:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:53:49 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:53:49 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:53:49 --> Final output sent to browser
DEBUG - 2011-09-10 14:53:49 --> Total execution time: 0.0276
DEBUG - 2011-09-10 14:53:50 --> Config Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:53:50 --> URI Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Router Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Output Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Input Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:53:50 --> Language Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Loader Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Controller Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Model Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Model Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:53:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:53:50 --> Final output sent to browser
DEBUG - 2011-09-10 14:53:50 --> Total execution time: 0.5183
DEBUG - 2011-09-10 14:53:52 --> Config Class Initialized
DEBUG - 2011-09-10 14:53:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:53:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:53:52 --> URI Class Initialized
DEBUG - 2011-09-10 14:53:52 --> Router Class Initialized
ERROR - 2011-09-10 14:53:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:54:48 --> Config Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:54:48 --> URI Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Router Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Output Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Input Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:54:48 --> Language Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Loader Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Controller Class Initialized
ERROR - 2011-09-10 14:54:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 14:54:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 14:54:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:54:48 --> Model Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Model Class Initialized
DEBUG - 2011-09-10 14:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:54:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:54:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:54:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:54:48 --> Final output sent to browser
DEBUG - 2011-09-10 14:54:48 --> Total execution time: 0.0329
DEBUG - 2011-09-10 14:54:49 --> Config Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:54:49 --> URI Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Router Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Output Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Input Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:54:49 --> Language Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Loader Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Controller Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Model Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Model Class Initialized
DEBUG - 2011-09-10 14:54:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:54:49 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:54:50 --> Final output sent to browser
DEBUG - 2011-09-10 14:54:50 --> Total execution time: 0.6501
DEBUG - 2011-09-10 14:54:52 --> Config Class Initialized
DEBUG - 2011-09-10 14:54:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:54:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:54:52 --> URI Class Initialized
DEBUG - 2011-09-10 14:54:52 --> Router Class Initialized
ERROR - 2011-09-10 14:54:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:54:54 --> Config Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:54:54 --> URI Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Router Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Output Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Input Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:54:54 --> Language Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Loader Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Controller Class Initialized
ERROR - 2011-09-10 14:54:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 14:54:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 14:54:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:54:54 --> Model Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Model Class Initialized
DEBUG - 2011-09-10 14:54:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:54:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:54:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:54:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:54:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:54:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:54:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:54:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:54:54 --> Final output sent to browser
DEBUG - 2011-09-10 14:54:54 --> Total execution time: 0.0358
DEBUG - 2011-09-10 14:55:09 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:09 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Router Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Output Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Input Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:55:09 --> Language Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Loader Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Controller Class Initialized
ERROR - 2011-09-10 14:55:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 14:55:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 14:55:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:55:09 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:55:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:55:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:55:09 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:55:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:55:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:55:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:55:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:55:09 --> Final output sent to browser
DEBUG - 2011-09-10 14:55:09 --> Total execution time: 0.0282
DEBUG - 2011-09-10 14:55:09 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:09 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:09 --> Router Class Initialized
ERROR - 2011-09-10 14:55:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:55:10 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:10 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Router Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Output Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Input Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:55:10 --> Language Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Loader Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Controller Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:55:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:55:11 --> Final output sent to browser
DEBUG - 2011-09-10 14:55:11 --> Total execution time: 0.5362
DEBUG - 2011-09-10 14:55:12 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:12 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:12 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:12 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:12 --> Router Class Initialized
ERROR - 2011-09-10 14:55:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 14:55:26 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:26 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Router Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Output Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Input Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:55:26 --> Language Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Loader Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Controller Class Initialized
ERROR - 2011-09-10 14:55:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 14:55:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 14:55:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:55:26 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:55:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:55:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 14:55:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 14:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 14:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 14:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 14:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 14:55:26 --> Final output sent to browser
DEBUG - 2011-09-10 14:55:26 --> Total execution time: 0.1830
DEBUG - 2011-09-10 14:55:26 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:26 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Router Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Output Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Input Class Initialized
DEBUG - 2011-09-10 14:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 14:55:26 --> Language Class Initialized
DEBUG - 2011-09-10 14:55:27 --> Loader Class Initialized
DEBUG - 2011-09-10 14:55:27 --> Controller Class Initialized
DEBUG - 2011-09-10 14:55:27 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:27 --> Model Class Initialized
DEBUG - 2011-09-10 14:55:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 14:55:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 14:55:28 --> Final output sent to browser
DEBUG - 2011-09-10 14:55:28 --> Total execution time: 1.8807
DEBUG - 2011-09-10 14:55:30 --> Config Class Initialized
DEBUG - 2011-09-10 14:55:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 14:55:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 14:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 14:55:30 --> URI Class Initialized
DEBUG - 2011-09-10 14:55:30 --> Router Class Initialized
ERROR - 2011-09-10 14:55:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 15:00:50 --> Config Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:00:50 --> URI Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Router Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Output Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Input Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:00:50 --> Language Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Loader Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Controller Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Model Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Model Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Model Class Initialized
DEBUG - 2011-09-10 15:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:00:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:00:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 15:00:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:00:50 --> Final output sent to browser
DEBUG - 2011-09-10 15:00:50 --> Total execution time: 0.0884
DEBUG - 2011-09-10 15:02:04 --> Config Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:02:04 --> URI Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Router Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Output Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Input Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:02:04 --> Language Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Loader Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Controller Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:02:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:02:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 15:02:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:02:04 --> Final output sent to browser
DEBUG - 2011-09-10 15:02:04 --> Total execution time: 0.0461
DEBUG - 2011-09-10 15:02:10 --> Config Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:02:10 --> URI Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Router Class Initialized
ERROR - 2011-09-10 15:02:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 15:02:10 --> Config Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:02:10 --> URI Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Router Class Initialized
ERROR - 2011-09-10 15:02:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 15:02:10 --> Config Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:02:10 --> URI Class Initialized
DEBUG - 2011-09-10 15:02:10 --> Router Class Initialized
ERROR - 2011-09-10 15:02:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 15:02:31 --> Config Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:02:31 --> URI Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Router Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Output Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Input Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:02:31 --> Language Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Loader Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Controller Class Initialized
ERROR - 2011-09-10 15:02:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 15:02:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 15:02:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 15:02:31 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:02:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:02:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 15:02:32 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:02:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:02:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:02:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:02:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:02:32 --> Final output sent to browser
DEBUG - 2011-09-10 15:02:32 --> Total execution time: 0.0284
DEBUG - 2011-09-10 15:02:32 --> Config Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:02:32 --> URI Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Router Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Output Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Input Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:02:32 --> Language Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Loader Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Controller Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Model Class Initialized
DEBUG - 2011-09-10 15:02:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:02:32 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:02:33 --> Final output sent to browser
DEBUG - 2011-09-10 15:02:33 --> Total execution time: 0.5062
DEBUG - 2011-09-10 15:03:08 --> Config Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:03:08 --> URI Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Router Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Output Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Input Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:03:08 --> Language Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Loader Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Controller Class Initialized
ERROR - 2011-09-10 15:03:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 15:03:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 15:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 15:03:08 --> Model Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Model Class Initialized
DEBUG - 2011-09-10 15:03:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:03:08 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 15:03:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:03:08 --> Final output sent to browser
DEBUG - 2011-09-10 15:03:08 --> Total execution time: 0.0299
DEBUG - 2011-09-10 15:03:10 --> Config Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:03:10 --> URI Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Router Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Output Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Input Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:03:10 --> Language Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Loader Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Controller Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Model Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Model Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:03:10 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:03:10 --> Final output sent to browser
DEBUG - 2011-09-10 15:03:10 --> Total execution time: 0.5916
DEBUG - 2011-09-10 15:11:52 --> Config Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:11:52 --> URI Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Router Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Output Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Input Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:11:52 --> Language Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Loader Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Controller Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Model Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Model Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Model Class Initialized
DEBUG - 2011-09-10 15:11:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:11:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:11:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 15:11:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:11:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:11:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:11:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:11:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:11:53 --> Final output sent to browser
DEBUG - 2011-09-10 15:11:53 --> Total execution time: 0.0831
DEBUG - 2011-09-10 15:13:44 --> Config Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:13:44 --> URI Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Router Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Output Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Input Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:13:44 --> Language Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Loader Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Controller Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Model Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Model Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Model Class Initialized
DEBUG - 2011-09-10 15:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:13:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:13:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 15:13:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:13:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:13:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:13:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:13:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:13:44 --> Final output sent to browser
DEBUG - 2011-09-10 15:13:44 --> Total execution time: 0.0583
DEBUG - 2011-09-10 15:13:48 --> Config Class Initialized
DEBUG - 2011-09-10 15:13:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:13:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:13:48 --> URI Class Initialized
DEBUG - 2011-09-10 15:13:48 --> Router Class Initialized
ERROR - 2011-09-10 15:13:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 15:14:43 --> Config Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:14:43 --> URI Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Router Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Output Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Input Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:14:43 --> Language Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Loader Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Controller Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Model Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Model Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Model Class Initialized
DEBUG - 2011-09-10 15:14:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:14:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:14:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 15:14:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:14:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:14:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:14:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:14:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:14:43 --> Final output sent to browser
DEBUG - 2011-09-10 15:14:43 --> Total execution time: 0.2112
DEBUG - 2011-09-10 15:15:04 --> Config Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 15:15:04 --> URI Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Router Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Output Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Input Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 15:15:04 --> Language Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Loader Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Controller Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Model Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Model Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Model Class Initialized
DEBUG - 2011-09-10 15:15:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 15:15:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 15:15:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 15:15:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 15:15:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 15:15:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 15:15:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 15:15:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 15:15:05 --> Final output sent to browser
DEBUG - 2011-09-10 15:15:05 --> Total execution time: 0.9641
DEBUG - 2011-09-10 16:11:51 --> Config Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:11:51 --> URI Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Router Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Output Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Input Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:11:51 --> Language Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Loader Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Controller Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Model Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Model Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Model Class Initialized
DEBUG - 2011-09-10 16:11:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:11:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:11:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 16:11:52 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:11:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:11:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:11:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:11:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:11:52 --> Final output sent to browser
DEBUG - 2011-09-10 16:11:52 --> Total execution time: 1.1537
DEBUG - 2011-09-10 16:11:57 --> Config Class Initialized
DEBUG - 2011-09-10 16:11:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:11:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:11:57 --> URI Class Initialized
DEBUG - 2011-09-10 16:11:57 --> Router Class Initialized
ERROR - 2011-09-10 16:11:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 16:16:44 --> Config Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:16:44 --> URI Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Router Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Output Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Input Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:16:44 --> Language Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Loader Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Controller Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Model Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Model Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Model Class Initialized
DEBUG - 2011-09-10 16:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:16:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:16:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 16:16:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:16:44 --> Final output sent to browser
DEBUG - 2011-09-10 16:16:44 --> Total execution time: 0.0584
DEBUG - 2011-09-10 16:18:50 --> Config Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:18:50 --> URI Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Router Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Output Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Input Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:18:50 --> Language Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Loader Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Controller Class Initialized
ERROR - 2011-09-10 16:18:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 16:18:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 16:18:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:18:50 --> Model Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Model Class Initialized
DEBUG - 2011-09-10 16:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:18:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:18:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:18:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:18:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:18:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:18:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:18:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:18:50 --> Final output sent to browser
DEBUG - 2011-09-10 16:18:50 --> Total execution time: 0.0666
DEBUG - 2011-09-10 16:19:36 --> Config Class Initialized
DEBUG - 2011-09-10 16:19:36 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:19:36 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:19:36 --> URI Class Initialized
DEBUG - 2011-09-10 16:19:36 --> Router Class Initialized
ERROR - 2011-09-10 16:19:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 16:19:37 --> Config Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:19:37 --> URI Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Router Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Output Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Input Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:19:37 --> Language Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Loader Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Controller Class Initialized
ERROR - 2011-09-10 16:19:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 16:19:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 16:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:19:37 --> Model Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Model Class Initialized
DEBUG - 2011-09-10 16:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:19:37 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:19:37 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:19:37 --> Final output sent to browser
DEBUG - 2011-09-10 16:19:37 --> Total execution time: 0.0281
DEBUG - 2011-09-10 16:19:39 --> Config Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:19:39 --> URI Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Router Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Output Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Input Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:19:39 --> Language Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Loader Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Controller Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Model Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Model Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:19:39 --> Final output sent to browser
DEBUG - 2011-09-10 16:19:39 --> Total execution time: 0.5471
DEBUG - 2011-09-10 16:19:42 --> Config Class Initialized
DEBUG - 2011-09-10 16:19:42 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:19:42 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:19:42 --> URI Class Initialized
DEBUG - 2011-09-10 16:19:42 --> Router Class Initialized
ERROR - 2011-09-10 16:19:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 16:23:48 --> Config Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:23:48 --> URI Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Router Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Output Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Input Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:23:48 --> Language Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Loader Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Controller Class Initialized
ERROR - 2011-09-10 16:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 16:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 16:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:23:48 --> Model Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Model Class Initialized
DEBUG - 2011-09-10 16:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:23:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:23:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:23:48 --> Final output sent to browser
DEBUG - 2011-09-10 16:23:48 --> Total execution time: 0.0349
DEBUG - 2011-09-10 16:45:55 --> Config Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:45:55 --> URI Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Router Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Output Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Input Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:45:55 --> Language Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Loader Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Controller Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Model Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Model Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Model Class Initialized
DEBUG - 2011-09-10 16:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:45:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:45:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 16:45:55 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:45:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:45:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:45:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:45:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:45:55 --> Final output sent to browser
DEBUG - 2011-09-10 16:45:55 --> Total execution time: 0.2510
DEBUG - 2011-09-10 16:56:06 --> Config Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:56:06 --> URI Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Router Class Initialized
ERROR - 2011-09-10 16:56:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 16:56:06 --> Config Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:56:06 --> URI Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Router Class Initialized
DEBUG - 2011-09-10 16:56:06 --> No URI present. Default controller set.
DEBUG - 2011-09-10 16:56:06 --> Output Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Input Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:56:06 --> Language Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Loader Class Initialized
DEBUG - 2011-09-10 16:56:06 --> Controller Class Initialized
DEBUG - 2011-09-10 16:56:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 16:56:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:56:06 --> Final output sent to browser
DEBUG - 2011-09-10 16:56:06 --> Total execution time: 0.1054
DEBUG - 2011-09-10 16:56:07 --> Config Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:56:07 --> URI Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Router Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Output Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Input Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:56:07 --> Language Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Loader Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Controller Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-10 16:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:56:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 16:56:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:56:08 --> Final output sent to browser
DEBUG - 2011-09-10 16:56:08 --> Total execution time: 0.1567
DEBUG - 2011-09-10 16:56:17 --> Config Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Hooks Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Utf8 Class Initialized
DEBUG - 2011-09-10 16:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 16:56:17 --> URI Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Router Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Output Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Input Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 16:56:17 --> Language Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Loader Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Controller Class Initialized
ERROR - 2011-09-10 16:56:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 16:56:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 16:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:56:17 --> Model Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Model Class Initialized
DEBUG - 2011-09-10 16:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 16:56:17 --> Database Driver Class Initialized
DEBUG - 2011-09-10 16:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 16:56:17 --> Helper loaded: url_helper
DEBUG - 2011-09-10 16:56:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 16:56:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 16:56:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 16:56:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 16:56:17 --> Final output sent to browser
DEBUG - 2011-09-10 16:56:17 --> Total execution time: 0.1401
DEBUG - 2011-09-10 17:09:34 --> Config Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Hooks Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Utf8 Class Initialized
DEBUG - 2011-09-10 17:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 17:09:34 --> URI Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Router Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Output Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Input Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 17:09:34 --> Language Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Loader Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Controller Class Initialized
ERROR - 2011-09-10 17:09:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 17:09:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 17:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 17:09:34 --> Model Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Model Class Initialized
DEBUG - 2011-09-10 17:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 17:09:34 --> Database Driver Class Initialized
DEBUG - 2011-09-10 17:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 17:09:34 --> Helper loaded: url_helper
DEBUG - 2011-09-10 17:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 17:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 17:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 17:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 17:57:31 --> Config Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 17:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 17:57:31 --> URI Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Router Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Output Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Input Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 17:57:31 --> Language Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Loader Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Controller Class Initialized
ERROR - 2011-09-10 17:57:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 17:57:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 17:57:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 17:57:31 --> Model Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Model Class Initialized
DEBUG - 2011-09-10 17:57:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 17:57:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 17:57:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 17:57:31 --> Helper loaded: url_helper
DEBUG - 2011-09-10 17:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 17:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 17:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 17:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 17:57:31 --> Final output sent to browser
DEBUG - 2011-09-10 17:57:31 --> Total execution time: 0.0554
DEBUG - 2011-09-10 17:57:38 --> Config Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Hooks Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Utf8 Class Initialized
DEBUG - 2011-09-10 17:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 17:57:38 --> URI Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Router Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Output Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Input Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 17:57:38 --> Language Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Loader Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Controller Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Model Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Model Class Initialized
DEBUG - 2011-09-10 17:57:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 17:57:38 --> Database Driver Class Initialized
DEBUG - 2011-09-10 17:57:39 --> Final output sent to browser
DEBUG - 2011-09-10 17:57:39 --> Total execution time: 0.7185
DEBUG - 2011-09-10 17:57:45 --> Config Class Initialized
DEBUG - 2011-09-10 17:57:45 --> Hooks Class Initialized
DEBUG - 2011-09-10 17:57:45 --> Utf8 Class Initialized
DEBUG - 2011-09-10 17:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 17:57:45 --> URI Class Initialized
DEBUG - 2011-09-10 17:57:45 --> Router Class Initialized
ERROR - 2011-09-10 17:57:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:00:20 --> Config Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:00:20 --> URI Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Router Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Output Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Input Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:00:20 --> Language Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Loader Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Controller Class Initialized
ERROR - 2011-09-10 18:00:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 18:00:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 18:00:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:00:20 --> Model Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Model Class Initialized
DEBUG - 2011-09-10 18:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:00:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:00:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:00:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:00:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:00:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:00:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:00:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:00:20 --> Final output sent to browser
DEBUG - 2011-09-10 18:00:20 --> Total execution time: 0.0279
DEBUG - 2011-09-10 18:00:21 --> Config Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:00:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:00:21 --> URI Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Router Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Output Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Input Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:00:21 --> Language Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Loader Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Controller Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Model Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Model Class Initialized
DEBUG - 2011-09-10 18:00:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:00:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:00:22 --> Final output sent to browser
DEBUG - 2011-09-10 18:00:22 --> Total execution time: 0.7008
DEBUG - 2011-09-10 18:00:23 --> Config Class Initialized
DEBUG - 2011-09-10 18:00:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:00:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:00:23 --> URI Class Initialized
DEBUG - 2011-09-10 18:00:23 --> Router Class Initialized
ERROR - 2011-09-10 18:00:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:00:23 --> Config Class Initialized
DEBUG - 2011-09-10 18:00:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:00:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:00:23 --> URI Class Initialized
DEBUG - 2011-09-10 18:00:23 --> Router Class Initialized
ERROR - 2011-09-10 18:00:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:25:47 --> Config Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:25:47 --> URI Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Router Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Output Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Input Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:25:47 --> Language Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Loader Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Controller Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Model Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Model Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Model Class Initialized
DEBUG - 2011-09-10 18:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:25:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:25:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:25:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:25:48 --> Final output sent to browser
DEBUG - 2011-09-10 18:25:48 --> Total execution time: 0.2204
DEBUG - 2011-09-10 18:25:50 --> Config Class Initialized
DEBUG - 2011-09-10 18:25:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:25:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:25:50 --> URI Class Initialized
DEBUG - 2011-09-10 18:25:50 --> Router Class Initialized
ERROR - 2011-09-10 18:25:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:25:50 --> Config Class Initialized
DEBUG - 2011-09-10 18:25:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:25:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:25:50 --> URI Class Initialized
DEBUG - 2011-09-10 18:25:50 --> Router Class Initialized
ERROR - 2011-09-10 18:25:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:26:09 --> Config Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:26:09 --> URI Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Router Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Output Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Input Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:26:09 --> Language Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Loader Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Controller Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:26:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:26:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:26:09 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:26:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:26:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:26:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:26:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:26:09 --> Final output sent to browser
DEBUG - 2011-09-10 18:26:09 --> Total execution time: 0.2042
DEBUG - 2011-09-10 18:26:26 --> Config Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:26:26 --> URI Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Router Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Output Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Input Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:26:26 --> Language Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Loader Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Controller Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:26:26 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:26:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:26:26 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:26:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:26:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:26:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:26:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:26:26 --> Final output sent to browser
DEBUG - 2011-09-10 18:26:26 --> Total execution time: 0.3022
DEBUG - 2011-09-10 18:26:41 --> Config Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:26:41 --> URI Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Router Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Output Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Input Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:26:41 --> Language Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Loader Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Controller Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:26:41 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:26:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:26:42 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:26:42 --> Final output sent to browser
DEBUG - 2011-09-10 18:26:42 --> Total execution time: 0.3256
DEBUG - 2011-09-10 18:26:53 --> Config Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:26:53 --> URI Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Router Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Output Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Input Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:26:53 --> Language Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Loader Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Controller Class Initialized
ERROR - 2011-09-10 18:26:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 18:26:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 18:26:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:26:53 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:26:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:26:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:26:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:26:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:26:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:26:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:26:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:26:53 --> Final output sent to browser
DEBUG - 2011-09-10 18:26:53 --> Total execution time: 0.0265
DEBUG - 2011-09-10 18:26:55 --> Config Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:26:55 --> URI Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Router Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Output Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Input Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:26:55 --> Language Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Loader Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Controller Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Model Class Initialized
DEBUG - 2011-09-10 18:26:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:26:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:26:56 --> Final output sent to browser
DEBUG - 2011-09-10 18:26:56 --> Total execution time: 0.5135
DEBUG - 2011-09-10 18:26:57 --> Config Class Initialized
DEBUG - 2011-09-10 18:26:57 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:26:57 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:26:57 --> URI Class Initialized
DEBUG - 2011-09-10 18:26:57 --> Router Class Initialized
ERROR - 2011-09-10 18:26:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:27:04 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:04 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:04 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Controller Class Initialized
ERROR - 2011-09-10 18:27:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 18:27:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 18:27:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:27:04 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:27:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:27:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:27:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:27:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:27:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:27:04 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:04 --> Total execution time: 0.0321
DEBUG - 2011-09-10 18:27:04 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:04 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:04 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Controller Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:05 --> Total execution time: 0.6090
DEBUG - 2011-09-10 18:27:05 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:05 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:05 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Controller Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:27:06 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:27:06 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:06 --> Total execution time: 0.5193
DEBUG - 2011-09-10 18:27:06 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:06 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:06 --> Router Class Initialized
ERROR - 2011-09-10 18:27:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:27:16 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:16 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:16 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Controller Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:16 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:27:16 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:27:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:27:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:27:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:27:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:27:16 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:16 --> Total execution time: 0.2966
DEBUG - 2011-09-10 18:27:44 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:44 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:44 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Controller Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:27:44 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:27:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:27:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:27:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:27:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:27:44 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:44 --> Total execution time: 0.2243
DEBUG - 2011-09-10 18:27:46 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:46 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:46 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Controller Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:27:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:27:46 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:46 --> Total execution time: 0.0488
DEBUG - 2011-09-10 18:27:46 --> Config Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:27:46 --> URI Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Router Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Output Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Input Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:27:46 --> Language Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Loader Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Controller Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Model Class Initialized
DEBUG - 2011-09-10 18:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:27:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:27:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:27:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:27:46 --> Final output sent to browser
DEBUG - 2011-09-10 18:27:46 --> Total execution time: 0.0469
DEBUG - 2011-09-10 18:44:47 --> Config Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:44:47 --> URI Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Router Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Output Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Input Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:44:47 --> Language Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Loader Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Controller Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Model Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Model Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Model Class Initialized
DEBUG - 2011-09-10 18:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:44:47 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:44:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:44:47 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:44:47 --> Final output sent to browser
DEBUG - 2011-09-10 18:44:47 --> Total execution time: 0.0449
DEBUG - 2011-09-10 18:44:49 --> Config Class Initialized
DEBUG - 2011-09-10 18:44:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:44:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:44:49 --> URI Class Initialized
DEBUG - 2011-09-10 18:44:49 --> Router Class Initialized
ERROR - 2011-09-10 18:44:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:44:49 --> Config Class Initialized
DEBUG - 2011-09-10 18:44:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:44:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:44:49 --> URI Class Initialized
DEBUG - 2011-09-10 18:44:49 --> Router Class Initialized
ERROR - 2011-09-10 18:44:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:44:50 --> Config Class Initialized
DEBUG - 2011-09-10 18:44:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:44:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:44:50 --> URI Class Initialized
DEBUG - 2011-09-10 18:44:50 --> Router Class Initialized
ERROR - 2011-09-10 18:44:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 18:45:00 --> Config Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:45:00 --> URI Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Router Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Output Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Input Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:45:00 --> Language Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Loader Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Controller Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:45:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:45:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:45:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:45:00 --> Final output sent to browser
DEBUG - 2011-09-10 18:45:00 --> Total execution time: 0.0450
DEBUG - 2011-09-10 18:45:09 --> Config Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:45:09 --> URI Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Router Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Output Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Input Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:45:09 --> Language Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Loader Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Controller Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:45:09 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:45:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:45:09 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:45:09 --> Final output sent to browser
DEBUG - 2011-09-10 18:45:09 --> Total execution time: 0.0444
DEBUG - 2011-09-10 18:45:14 --> Config Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:45:14 --> URI Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Router Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Output Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Input Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:45:14 --> Language Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Loader Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Controller Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:45:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:45:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:45:14 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:45:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:45:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:45:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:45:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:45:14 --> Final output sent to browser
DEBUG - 2011-09-10 18:45:14 --> Total execution time: 0.0445
DEBUG - 2011-09-10 18:45:27 --> Config Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:45:27 --> URI Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Router Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Output Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Input Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:45:27 --> Language Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Loader Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Controller Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:45:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:45:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:45:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:45:27 --> Final output sent to browser
DEBUG - 2011-09-10 18:45:27 --> Total execution time: 0.2910
DEBUG - 2011-09-10 18:45:40 --> Config Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:45:40 --> URI Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Router Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Output Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Input Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:45:40 --> Language Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Loader Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Controller Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Model Class Initialized
DEBUG - 2011-09-10 18:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:45:40 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:45:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:45:41 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:45:41 --> Final output sent to browser
DEBUG - 2011-09-10 18:45:41 --> Total execution time: 0.7991
DEBUG - 2011-09-10 18:46:00 --> Config Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:46:00 --> URI Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Router Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Output Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Input Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:46:00 --> Language Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Loader Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Controller Class Initialized
ERROR - 2011-09-10 18:46:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 18:46:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 18:46:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:46:00 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:46:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:46:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:46:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:46:00 --> Final output sent to browser
DEBUG - 2011-09-10 18:46:00 --> Total execution time: 0.0280
DEBUG - 2011-09-10 18:46:01 --> Config Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:46:01 --> URI Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Router Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Output Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Input Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:46:01 --> Language Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Loader Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Controller Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:46:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:46:01 --> Final output sent to browser
DEBUG - 2011-09-10 18:46:01 --> Total execution time: 0.4949
DEBUG - 2011-09-10 18:46:33 --> Config Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:46:33 --> URI Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Router Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Output Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Input Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:46:33 --> Language Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Loader Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Controller Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:46:33 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:46:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:46:33 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:46:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:46:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:46:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:46:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:46:33 --> Final output sent to browser
DEBUG - 2011-09-10 18:46:33 --> Total execution time: 0.0462
DEBUG - 2011-09-10 18:46:43 --> Config Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:46:43 --> URI Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Router Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Output Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Input Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:46:43 --> Language Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Loader Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Controller Class Initialized
ERROR - 2011-09-10 18:46:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 18:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 18:46:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:46:43 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:46:43 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:46:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 18:46:43 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:46:43 --> Final output sent to browser
DEBUG - 2011-09-10 18:46:43 --> Total execution time: 0.0339
DEBUG - 2011-09-10 18:46:44 --> Config Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:46:44 --> URI Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Router Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Output Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Input Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:46:44 --> Language Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Loader Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Controller Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Model Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:46:44 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:46:44 --> Final output sent to browser
DEBUG - 2011-09-10 18:46:44 --> Total execution time: 0.5280
DEBUG - 2011-09-10 18:50:03 --> Config Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:50:03 --> URI Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Router Class Initialized
DEBUG - 2011-09-10 18:50:03 --> No URI present. Default controller set.
DEBUG - 2011-09-10 18:50:03 --> Output Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Input Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:50:03 --> Language Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Loader Class Initialized
DEBUG - 2011-09-10 18:50:03 --> Controller Class Initialized
DEBUG - 2011-09-10 18:50:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 18:50:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:50:03 --> Final output sent to browser
DEBUG - 2011-09-10 18:50:03 --> Total execution time: 0.0129
DEBUG - 2011-09-10 18:52:53 --> Config Class Initialized
DEBUG - 2011-09-10 18:52:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:52:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:52:53 --> URI Class Initialized
DEBUG - 2011-09-10 18:52:53 --> Router Class Initialized
ERROR - 2011-09-10 18:52:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 18:52:54 --> Config Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:52:54 --> URI Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Router Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Output Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Input Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:52:54 --> Language Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Loader Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Controller Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Model Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Model Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Model Class Initialized
DEBUG - 2011-09-10 18:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:52:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:52:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:52:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:52:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:52:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:52:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:52:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:52:54 --> Final output sent to browser
DEBUG - 2011-09-10 18:52:54 --> Total execution time: 0.0441
DEBUG - 2011-09-10 18:57:41 --> Config Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:57:41 --> URI Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Router Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Output Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Input Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:57:41 --> Language Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Loader Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Controller Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Model Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Model Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Model Class Initialized
DEBUG - 2011-09-10 18:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:57:41 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:57:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:57:41 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:57:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:57:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:57:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:57:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:57:41 --> Final output sent to browser
DEBUG - 2011-09-10 18:57:41 --> Total execution time: 0.0444
DEBUG - 2011-09-10 18:58:03 --> Config Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:58:03 --> URI Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Router Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Output Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Input Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:58:03 --> Language Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Loader Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Controller Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:58:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:58:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:58:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:58:03 --> Final output sent to browser
DEBUG - 2011-09-10 18:58:03 --> Total execution time: 0.2504
DEBUG - 2011-09-10 18:58:48 --> Config Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:58:48 --> URI Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Router Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Output Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Input Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:58:48 --> Language Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Loader Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Controller Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:58:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:58:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:58:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:58:48 --> Final output sent to browser
DEBUG - 2011-09-10 18:58:48 --> Total execution time: 0.1480
DEBUG - 2011-09-10 18:58:49 --> Config Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Hooks Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Utf8 Class Initialized
DEBUG - 2011-09-10 18:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 18:58:49 --> URI Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Router Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Output Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Input Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 18:58:49 --> Language Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Loader Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Controller Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Model Class Initialized
DEBUG - 2011-09-10 18:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 18:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-10 18:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 18:58:49 --> Helper loaded: url_helper
DEBUG - 2011-09-10 18:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 18:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 18:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 18:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 18:58:49 --> Final output sent to browser
DEBUG - 2011-09-10 18:58:49 --> Total execution time: 0.0414
DEBUG - 2011-09-10 19:07:27 --> Config Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:07:27 --> URI Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Router Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Output Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Input Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:07:27 --> Language Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Loader Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Controller Class Initialized
ERROR - 2011-09-10 19:07:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 19:07:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 19:07:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:07:27 --> Model Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Model Class Initialized
DEBUG - 2011-09-10 19:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:07:27 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:07:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:07:27 --> Helper loaded: url_helper
DEBUG - 2011-09-10 19:07:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 19:07:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 19:07:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 19:07:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 19:07:27 --> Final output sent to browser
DEBUG - 2011-09-10 19:07:27 --> Total execution time: 0.0547
DEBUG - 2011-09-10 19:07:44 --> Config Class Initialized
DEBUG - 2011-09-10 19:07:44 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:07:44 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:07:44 --> URI Class Initialized
DEBUG - 2011-09-10 19:07:44 --> Router Class Initialized
ERROR - 2011-09-10 19:07:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-10 19:09:50 --> Config Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:09:50 --> URI Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Router Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Output Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Input Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:09:50 --> Language Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Loader Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Controller Class Initialized
ERROR - 2011-09-10 19:09:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 19:09:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 19:09:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:09:50 --> Model Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Model Class Initialized
DEBUG - 2011-09-10 19:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:09:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:09:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:09:50 --> Helper loaded: url_helper
DEBUG - 2011-09-10 19:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 19:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 19:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 19:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 19:09:50 --> Final output sent to browser
DEBUG - 2011-09-10 19:09:50 --> Total execution time: 0.0304
DEBUG - 2011-09-10 19:09:51 --> Config Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:09:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:09:51 --> URI Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Router Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Output Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Input Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:09:51 --> Language Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Loader Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Controller Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Model Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Model Class Initialized
DEBUG - 2011-09-10 19:09:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:09:51 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:09:52 --> Final output sent to browser
DEBUG - 2011-09-10 19:09:52 --> Total execution time: 0.8102
DEBUG - 2011-09-10 19:09:55 --> Config Class Initialized
DEBUG - 2011-09-10 19:09:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:09:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:09:55 --> URI Class Initialized
DEBUG - 2011-09-10 19:09:55 --> Router Class Initialized
ERROR - 2011-09-10 19:09:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 19:09:55 --> Config Class Initialized
DEBUG - 2011-09-10 19:09:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:09:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:09:55 --> URI Class Initialized
DEBUG - 2011-09-10 19:09:55 --> Router Class Initialized
ERROR - 2011-09-10 19:09:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 19:14:03 --> Config Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:14:03 --> URI Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Router Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Output Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Input Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:14:03 --> Language Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Loader Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Controller Class Initialized
ERROR - 2011-09-10 19:14:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 19:14:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 19:14:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:14:03 --> Model Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Model Class Initialized
DEBUG - 2011-09-10 19:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:14:03 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:14:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:14:03 --> Helper loaded: url_helper
DEBUG - 2011-09-10 19:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 19:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 19:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 19:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 19:14:03 --> Final output sent to browser
DEBUG - 2011-09-10 19:14:03 --> Total execution time: 0.0476
DEBUG - 2011-09-10 19:14:04 --> Config Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:14:04 --> URI Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Router Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Output Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Input Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:14:04 --> Language Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Loader Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Controller Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Model Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Model Class Initialized
DEBUG - 2011-09-10 19:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:14:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:14:05 --> Final output sent to browser
DEBUG - 2011-09-10 19:14:05 --> Total execution time: 0.9349
DEBUG - 2011-09-10 19:14:06 --> Config Class Initialized
DEBUG - 2011-09-10 19:14:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:14:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:14:06 --> URI Class Initialized
DEBUG - 2011-09-10 19:14:06 --> Router Class Initialized
ERROR - 2011-09-10 19:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 19:14:06 --> Config Class Initialized
DEBUG - 2011-09-10 19:14:06 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:14:06 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:14:06 --> URI Class Initialized
DEBUG - 2011-09-10 19:14:06 --> Router Class Initialized
ERROR - 2011-09-10 19:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 19:18:30 --> Config Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:18:30 --> URI Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Router Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Output Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Input Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:18:30 --> Language Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Loader Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Controller Class Initialized
ERROR - 2011-09-10 19:18:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 19:18:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 19:18:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:18:30 --> Model Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Model Class Initialized
DEBUG - 2011-09-10 19:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:18:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:18:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 19:18:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 19:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 19:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 19:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 19:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 19:18:30 --> Final output sent to browser
DEBUG - 2011-09-10 19:18:30 --> Total execution time: 0.0272
DEBUG - 2011-09-10 19:18:31 --> Config Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 19:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 19:18:31 --> URI Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Router Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Output Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Input Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 19:18:31 --> Language Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Loader Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Controller Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Model Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Model Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 19:18:31 --> Database Driver Class Initialized
DEBUG - 2011-09-10 19:18:31 --> Final output sent to browser
DEBUG - 2011-09-10 19:18:31 --> Total execution time: 0.5743
DEBUG - 2011-09-10 20:19:52 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:52 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Router Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Output Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Input Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:19:52 --> Language Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Loader Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Controller Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:19:52 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:19:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:19:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:19:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:19:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:19:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:19:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:19:53 --> Final output sent to browser
DEBUG - 2011-09-10 20:19:53 --> Total execution time: 0.4251
DEBUG - 2011-09-10 20:19:54 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:54 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Router Class Initialized
ERROR - 2011-09-10 20:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 20:19:54 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:54 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Router Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Output Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Input Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:19:54 --> Language Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Loader Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Controller Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:54 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Router Class Initialized
ERROR - 2011-09-10 20:19:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2011-09-10 20:19:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 20:19:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 20:19:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:19:54 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:19:54 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:19:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:19:54 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:19:54 --> Final output sent to browser
DEBUG - 2011-09-10 20:19:54 --> Total execution time: 0.0931
DEBUG - 2011-09-10 20:19:55 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:55 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Router Class Initialized
ERROR - 2011-09-10 20:19:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 20:19:55 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:55 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Router Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Output Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Input Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:19:55 --> Language Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Loader Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Controller Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:19:55 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:19:55 --> Final output sent to browser
DEBUG - 2011-09-10 20:19:55 --> Total execution time: 0.6060
DEBUG - 2011-09-10 20:19:59 --> Config Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:19:59 --> URI Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Router Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Output Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Input Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:19:59 --> Language Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Loader Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Controller Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Model Class Initialized
DEBUG - 2011-09-10 20:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:19:59 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:19:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:19:59 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:19:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:19:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:19:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:19:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:19:59 --> Final output sent to browser
DEBUG - 2011-09-10 20:19:59 --> Total execution time: 0.0474
DEBUG - 2011-09-10 20:20:35 --> Config Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:20:35 --> URI Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Router Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Output Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Input Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:20:35 --> Language Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Loader Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Controller Class Initialized
ERROR - 2011-09-10 20:20:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 20:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 20:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:20:35 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:20:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:20:35 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:20:35 --> Final output sent to browser
DEBUG - 2011-09-10 20:20:35 --> Total execution time: 0.0296
DEBUG - 2011-09-10 20:20:35 --> Config Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:20:35 --> URI Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Router Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Output Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Input Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:20:35 --> Language Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Loader Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Controller Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:20:35 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:20:36 --> Final output sent to browser
DEBUG - 2011-09-10 20:20:36 --> Total execution time: 0.6394
DEBUG - 2011-09-10 20:20:46 --> Config Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:20:46 --> URI Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Router Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Output Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Input Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:20:46 --> Language Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Loader Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Controller Class Initialized
ERROR - 2011-09-10 20:20:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 20:20:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 20:20:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:20:46 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:20:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:20:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:20:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:20:46 --> Final output sent to browser
DEBUG - 2011-09-10 20:20:46 --> Total execution time: 0.0406
DEBUG - 2011-09-10 20:20:46 --> Config Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:20:46 --> URI Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Router Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Output Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Input Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:20:46 --> Language Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Loader Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Controller Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Model Class Initialized
DEBUG - 2011-09-10 20:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:20:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:20:47 --> Final output sent to browser
DEBUG - 2011-09-10 20:20:47 --> Total execution time: 0.6591
DEBUG - 2011-09-10 20:21:04 --> Config Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:21:04 --> URI Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Router Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Output Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Input Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:21:04 --> Language Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Loader Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Controller Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Model Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Model Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Model Class Initialized
DEBUG - 2011-09-10 20:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:21:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:21:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:21:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:21:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:21:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:21:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:21:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:21:04 --> Final output sent to browser
DEBUG - 2011-09-10 20:21:04 --> Total execution time: 0.2999
DEBUG - 2011-09-10 20:21:07 --> Config Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:21:07 --> URI Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Router Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Output Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Input Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:21:07 --> Language Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Loader Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Controller Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Model Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Model Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Model Class Initialized
DEBUG - 2011-09-10 20:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:21:07 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:21:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:21:08 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:21:08 --> Final output sent to browser
DEBUG - 2011-09-10 20:21:08 --> Total execution time: 1.1748
DEBUG - 2011-09-10 20:29:22 --> Config Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:29:22 --> URI Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Router Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Output Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Input Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:29:22 --> Language Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Loader Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Controller Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Model Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Model Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Model Class Initialized
DEBUG - 2011-09-10 20:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:29:22 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:29:22 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:29:22 --> Final output sent to browser
DEBUG - 2011-09-10 20:29:22 --> Total execution time: 0.2394
DEBUG - 2011-09-10 20:29:31 --> Config Class Initialized
DEBUG - 2011-09-10 20:29:31 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:29:31 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:29:31 --> URI Class Initialized
DEBUG - 2011-09-10 20:29:31 --> Router Class Initialized
ERROR - 2011-09-10 20:29:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 20:30:15 --> Config Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:30:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:30:15 --> URI Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Router Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Output Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Input Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:30:15 --> Language Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Loader Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Controller Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Model Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Model Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Model Class Initialized
DEBUG - 2011-09-10 20:30:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:30:15 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:30:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:30:15 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:30:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:30:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:30:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:30:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:30:15 --> Final output sent to browser
DEBUG - 2011-09-10 20:30:15 --> Total execution time: 0.1013
DEBUG - 2011-09-10 20:34:00 --> Config Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:34:00 --> URI Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Router Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Output Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Input Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:34:00 --> Language Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Loader Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Controller Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Model Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Model Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Model Class Initialized
DEBUG - 2011-09-10 20:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:34:00 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:34:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:34:00 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:34:00 --> Final output sent to browser
DEBUG - 2011-09-10 20:34:00 --> Total execution time: 0.0666
DEBUG - 2011-09-10 20:34:01 --> Config Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:34:01 --> URI Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Router Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Output Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Input Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:34:01 --> Language Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Loader Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Controller Class Initialized
ERROR - 2011-09-10 20:34:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 20:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 20:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:34:01 --> Model Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Model Class Initialized
DEBUG - 2011-09-10 20:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:34:01 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 20:34:01 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 20:34:01 --> Final output sent to browser
DEBUG - 2011-09-10 20:34:01 --> Total execution time: 0.0280
DEBUG - 2011-09-10 20:54:04 --> Config Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 20:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 20:54:04 --> URI Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Router Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Output Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Input Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 20:54:04 --> Language Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Loader Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Controller Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Model Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Model Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Model Class Initialized
DEBUG - 2011-09-10 20:54:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 20:54:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 20:54:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 20:54:05 --> Helper loaded: url_helper
DEBUG - 2011-09-10 20:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 20:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 20:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 20:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 21:26:48 --> Config Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Hooks Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Utf8 Class Initialized
DEBUG - 2011-09-10 21:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 21:26:48 --> URI Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Router Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Output Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Input Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 21:26:48 --> Language Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Loader Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Controller Class Initialized
ERROR - 2011-09-10 21:26:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 21:26:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 21:26:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 21:26:48 --> Model Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Model Class Initialized
DEBUG - 2011-09-10 21:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 21:26:48 --> Database Driver Class Initialized
DEBUG - 2011-09-10 21:26:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 21:26:48 --> Helper loaded: url_helper
DEBUG - 2011-09-10 21:26:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 21:26:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 21:26:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 21:26:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 21:26:48 --> Final output sent to browser
DEBUG - 2011-09-10 21:26:48 --> Total execution time: 0.0296
DEBUG - 2011-09-10 21:26:50 --> Config Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Hooks Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Utf8 Class Initialized
DEBUG - 2011-09-10 21:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 21:26:50 --> URI Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Router Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Output Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Input Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 21:26:50 --> Language Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Loader Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Controller Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Model Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Model Class Initialized
DEBUG - 2011-09-10 21:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 21:26:50 --> Database Driver Class Initialized
DEBUG - 2011-09-10 21:26:51 --> Final output sent to browser
DEBUG - 2011-09-10 21:26:51 --> Total execution time: 0.7121
DEBUG - 2011-09-10 21:26:52 --> Config Class Initialized
DEBUG - 2011-09-10 21:26:52 --> Hooks Class Initialized
DEBUG - 2011-09-10 21:26:52 --> Utf8 Class Initialized
DEBUG - 2011-09-10 21:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 21:26:52 --> URI Class Initialized
DEBUG - 2011-09-10 21:26:52 --> Router Class Initialized
ERROR - 2011-09-10 21:26:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 21:47:53 --> Config Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 21:47:53 --> URI Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Router Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Output Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Input Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 21:47:53 --> Language Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Loader Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Controller Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Model Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Model Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Model Class Initialized
DEBUG - 2011-09-10 21:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 21:47:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 21:47:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 21:47:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 21:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 21:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 21:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 21:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 21:47:54 --> Final output sent to browser
DEBUG - 2011-09-10 21:47:54 --> Total execution time: 0.2272
DEBUG - 2011-09-10 21:47:55 --> Config Class Initialized
DEBUG - 2011-09-10 21:47:55 --> Hooks Class Initialized
DEBUG - 2011-09-10 21:47:55 --> Utf8 Class Initialized
DEBUG - 2011-09-10 21:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 21:47:55 --> URI Class Initialized
DEBUG - 2011-09-10 21:47:55 --> Router Class Initialized
ERROR - 2011-09-10 21:47:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 22:21:13 --> Config Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:21:13 --> URI Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Router Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Output Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Input Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:21:13 --> Language Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Loader Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Controller Class Initialized
ERROR - 2011-09-10 22:21:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 22:21:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 22:21:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 22:21:13 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:21:13 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:21:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 22:21:13 --> Helper loaded: url_helper
DEBUG - 2011-09-10 22:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 22:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 22:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 22:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 22:21:13 --> Final output sent to browser
DEBUG - 2011-09-10 22:21:13 --> Total execution time: 0.0598
DEBUG - 2011-09-10 22:21:14 --> Config Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:21:14 --> URI Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Router Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Output Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Input Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:21:14 --> Language Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Loader Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Controller Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:21:14 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:21:15 --> Final output sent to browser
DEBUG - 2011-09-10 22:21:15 --> Total execution time: 0.5490
DEBUG - 2011-09-10 22:21:46 --> Config Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:21:46 --> URI Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Router Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Output Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Input Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:21:46 --> Language Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Loader Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Controller Class Initialized
ERROR - 2011-09-10 22:21:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 22:21:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 22:21:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 22:21:46 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:21:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:21:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 22:21:46 --> Helper loaded: url_helper
DEBUG - 2011-09-10 22:21:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 22:21:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 22:21:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 22:21:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 22:21:46 --> Final output sent to browser
DEBUG - 2011-09-10 22:21:46 --> Total execution time: 0.0274
DEBUG - 2011-09-10 22:21:46 --> Config Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:21:46 --> URI Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Router Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Output Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Input Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:21:46 --> Language Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Loader Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Controller Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Model Class Initialized
DEBUG - 2011-09-10 22:21:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:21:46 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:21:47 --> Final output sent to browser
DEBUG - 2011-09-10 22:21:47 --> Total execution time: 0.5464
DEBUG - 2011-09-10 22:33:53 --> Config Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:33:53 --> URI Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Router Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Output Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Input Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:33:53 --> Language Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Loader Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Controller Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Model Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Model Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Model Class Initialized
DEBUG - 2011-09-10 22:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:33:53 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 22:33:53 --> Helper loaded: url_helper
DEBUG - 2011-09-10 22:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 22:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 22:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 22:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 22:33:53 --> Final output sent to browser
DEBUG - 2011-09-10 22:33:53 --> Total execution time: 0.4025
DEBUG - 2011-09-10 22:34:28 --> Config Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:34:28 --> URI Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Router Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Output Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Input Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:34:28 --> Language Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Loader Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Controller Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Model Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Model Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Model Class Initialized
DEBUG - 2011-09-10 22:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:34:28 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:34:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 22:34:28 --> Helper loaded: url_helper
DEBUG - 2011-09-10 22:34:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 22:34:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 22:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 22:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 22:34:28 --> Final output sent to browser
DEBUG - 2011-09-10 22:34:28 --> Total execution time: 0.0484
DEBUG - 2011-09-10 22:34:30 --> Config Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:34:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:34:30 --> URI Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Router Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Output Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Input Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:34:30 --> Language Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Loader Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Controller Class Initialized
ERROR - 2011-09-10 22:34:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 22:34:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 22:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 22:34:30 --> Model Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Model Class Initialized
DEBUG - 2011-09-10 22:34:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 22:34:30 --> Database Driver Class Initialized
DEBUG - 2011-09-10 22:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 22:34:30 --> Helper loaded: url_helper
DEBUG - 2011-09-10 22:34:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 22:34:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 22:34:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 22:34:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 22:34:30 --> Final output sent to browser
DEBUG - 2011-09-10 22:34:30 --> Total execution time: 0.0285
DEBUG - 2011-09-10 22:34:37 --> Config Class Initialized
DEBUG - 2011-09-10 22:34:37 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:34:37 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:34:37 --> URI Class Initialized
DEBUG - 2011-09-10 22:34:37 --> Router Class Initialized
ERROR - 2011-09-10 22:34:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 22:41:19 --> Config Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Hooks Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Utf8 Class Initialized
DEBUG - 2011-09-10 22:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 22:41:19 --> URI Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Router Class Initialized
DEBUG - 2011-09-10 22:41:19 --> No URI present. Default controller set.
DEBUG - 2011-09-10 22:41:19 --> Output Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Input Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 22:41:19 --> Language Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Loader Class Initialized
DEBUG - 2011-09-10 22:41:19 --> Controller Class Initialized
DEBUG - 2011-09-10 22:41:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-10 22:41:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 22:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 22:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 22:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 22:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 22:41:20 --> Final output sent to browser
DEBUG - 2011-09-10 22:41:20 --> Total execution time: 0.0391
DEBUG - 2011-09-10 23:15:21 --> Config Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:15:21 --> URI Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Router Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Output Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Input Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:15:21 --> Language Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Loader Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Controller Class Initialized
ERROR - 2011-09-10 23:15:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 23:15:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 23:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:15:21 --> Model Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Model Class Initialized
DEBUG - 2011-09-10 23:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:15:21 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:15:21 --> Helper loaded: url_helper
DEBUG - 2011-09-10 23:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 23:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 23:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 23:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 23:15:21 --> Final output sent to browser
DEBUG - 2011-09-10 23:15:21 --> Total execution time: 0.1560
DEBUG - 2011-09-10 23:15:23 --> Config Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:15:23 --> URI Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Router Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Output Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Input Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:15:23 --> Language Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Loader Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Controller Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Model Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Model Class Initialized
DEBUG - 2011-09-10 23:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:15:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:15:24 --> Final output sent to browser
DEBUG - 2011-09-10 23:15:24 --> Total execution time: 0.7695
DEBUG - 2011-09-10 23:15:25 --> Config Class Initialized
DEBUG - 2011-09-10 23:15:25 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:15:25 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:15:25 --> URI Class Initialized
DEBUG - 2011-09-10 23:15:25 --> Router Class Initialized
ERROR - 2011-09-10 23:15:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-10 23:16:04 --> Config Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:16:04 --> URI Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Router Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Output Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Input Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:16:04 --> Language Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Loader Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Controller Class Initialized
ERROR - 2011-09-10 23:16:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 23:16:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 23:16:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:16:04 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:16:04 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:16:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:16:04 --> Helper loaded: url_helper
DEBUG - 2011-09-10 23:16:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 23:16:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 23:16:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 23:16:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 23:16:04 --> Final output sent to browser
DEBUG - 2011-09-10 23:16:04 --> Total execution time: 0.0354
DEBUG - 2011-09-10 23:16:05 --> Config Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:16:05 --> URI Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Router Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Output Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Input Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:16:05 --> Language Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Loader Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Controller Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:16:05 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:16:06 --> Final output sent to browser
DEBUG - 2011-09-10 23:16:06 --> Total execution time: 0.8051
DEBUG - 2011-09-10 23:16:20 --> Config Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:16:20 --> URI Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Router Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Output Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Input Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:16:20 --> Language Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Loader Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Controller Class Initialized
ERROR - 2011-09-10 23:16:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 23:16:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 23:16:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:16:20 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:16:20 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:16:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:16:20 --> Helper loaded: url_helper
DEBUG - 2011-09-10 23:16:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 23:16:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 23:16:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 23:16:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 23:16:20 --> Final output sent to browser
DEBUG - 2011-09-10 23:16:20 --> Total execution time: 0.0317
DEBUG - 2011-09-10 23:16:40 --> Config Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:16:40 --> URI Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Router Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Output Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Input Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:16:40 --> Language Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Loader Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Controller Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Model Class Initialized
DEBUG - 2011-09-10 23:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:16:40 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-10 23:16:41 --> Helper loaded: url_helper
DEBUG - 2011-09-10 23:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 23:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 23:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 23:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 23:16:41 --> Final output sent to browser
DEBUG - 2011-09-10 23:16:41 --> Total execution time: 0.3951
DEBUG - 2011-09-10 23:46:23 --> Config Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Hooks Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Utf8 Class Initialized
DEBUG - 2011-09-10 23:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-10 23:46:23 --> URI Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Router Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Output Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Input Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-10 23:46:23 --> Language Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Loader Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Controller Class Initialized
ERROR - 2011-09-10 23:46:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-10 23:46:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-10 23:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:46:23 --> Model Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Model Class Initialized
DEBUG - 2011-09-10 23:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-10 23:46:23 --> Database Driver Class Initialized
DEBUG - 2011-09-10 23:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-10 23:46:23 --> Helper loaded: url_helper
DEBUG - 2011-09-10 23:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-10 23:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-10 23:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-10 23:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-10 23:46:23 --> Final output sent to browser
DEBUG - 2011-09-10 23:46:23 --> Total execution time: 0.0317

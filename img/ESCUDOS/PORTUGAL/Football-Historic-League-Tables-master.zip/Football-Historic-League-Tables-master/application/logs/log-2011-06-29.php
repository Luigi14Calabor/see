<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-29 02:49:52 --> Config Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Hooks Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Utf8 Class Initialized
DEBUG - 2011-06-29 02:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 02:49:52 --> URI Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Router Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Output Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Input Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 02:49:52 --> Language Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Loader Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Controller Class Initialized
ERROR - 2011-06-29 02:49:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 02:49:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 02:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 02:49:52 --> Model Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Model Class Initialized
DEBUG - 2011-06-29 02:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 02:49:52 --> Database Driver Class Initialized
DEBUG - 2011-06-29 02:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 02:49:53 --> Helper loaded: url_helper
DEBUG - 2011-06-29 02:49:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 02:49:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 02:49:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 02:49:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 02:49:53 --> Final output sent to browser
DEBUG - 2011-06-29 02:49:53 --> Total execution time: 0.8091
DEBUG - 2011-06-29 07:49:22 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:22 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Router Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Output Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Input Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:49:22 --> Language Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Loader Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Controller Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:49:22 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:49:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:49:25 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:49:25 --> Final output sent to browser
DEBUG - 2011-06-29 07:49:25 --> Total execution time: 3.5031
DEBUG - 2011-06-29 07:49:32 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:32 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:32 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:32 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:32 --> Router Class Initialized
ERROR - 2011-06-29 07:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:49:33 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:34 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:34 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:34 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:34 --> Router Class Initialized
ERROR - 2011-06-29 07:49:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:49:34 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:34 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:34 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:34 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:34 --> Router Class Initialized
ERROR - 2011-06-29 07:49:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:49:49 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:49 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Router Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Output Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Input Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:49:49 --> Language Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Loader Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Controller Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:49:49 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:49:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:49:49 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:49:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:49:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:49:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:49:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:49:49 --> Final output sent to browser
DEBUG - 2011-06-29 07:49:49 --> Total execution time: 0.4402
DEBUG - 2011-06-29 07:49:56 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:56 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Router Class Initialized
ERROR - 2011-06-29 07:49:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-29 07:49:56 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:56 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Router Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Output Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Input Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:49:56 --> Language Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Loader Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Controller Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Model Class Initialized
DEBUG - 2011-06-29 07:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:49:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:49:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:49:56 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:49:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:49:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:49:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:49:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:49:56 --> Final output sent to browser
DEBUG - 2011-06-29 07:49:56 --> Total execution time: 0.0452
DEBUG - 2011-06-29 07:49:57 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:57 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:57 --> Router Class Initialized
ERROR - 2011-06-29 07:49:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:49:58 --> Config Class Initialized
DEBUG - 2011-06-29 07:49:58 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:49:58 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:49:58 --> URI Class Initialized
DEBUG - 2011-06-29 07:49:58 --> Router Class Initialized
ERROR - 2011-06-29 07:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:01 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:01 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:01 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:01 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:01 --> Router Class Initialized
ERROR - 2011-06-29 07:50:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:02 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:02 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:02 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:02 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:03 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:03 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:03 --> Total execution time: 0.5749
DEBUG - 2011-06-29 07:50:04 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:04 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:04 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:04 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:04 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:04 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:04 --> Total execution time: 0.0439
DEBUG - 2011-06-29 07:50:06 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:06 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:06 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:06 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:06 --> Router Class Initialized
ERROR - 2011-06-29 07:50:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:07 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:07 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:07 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:07 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:07 --> Router Class Initialized
ERROR - 2011-06-29 07:50:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:08 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:08 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:08 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:08 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:08 --> Router Class Initialized
ERROR - 2011-06-29 07:50:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:19 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:19 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:19 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:19 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:19 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:19 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:19 --> Total execution time: 0.2685
DEBUG - 2011-06-29 07:50:23 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:23 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:23 --> Router Class Initialized
ERROR - 2011-06-29 07:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:23 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:23 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:23 --> Router Class Initialized
ERROR - 2011-06-29 07:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:24 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:24 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Router Class Initialized
ERROR - 2011-06-29 07:50:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:24 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:24 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Router Class Initialized
ERROR - 2011-06-29 07:50:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:24 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:24 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:24 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:24 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:24 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:24 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:24 --> Total execution time: 0.0599
DEBUG - 2011-06-29 07:50:24 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:24 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:24 --> Router Class Initialized
ERROR - 2011-06-29 07:50:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:30 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:30 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:30 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:30 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:30 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:30 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:30 --> Total execution time: 0.2141
DEBUG - 2011-06-29 07:50:32 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:32 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:32 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:32 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:32 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:32 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:32 --> Total execution time: 0.0459
DEBUG - 2011-06-29 07:50:34 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:34 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:34 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:34 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:34 --> Router Class Initialized
ERROR - 2011-06-29 07:50:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:34 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:34 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:34 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:34 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:34 --> Router Class Initialized
ERROR - 2011-06-29 07:50:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:35 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:35 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Router Class Initialized
ERROR - 2011-06-29 07:50:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:35 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:35 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Router Class Initialized
ERROR - 2011-06-29 07:50:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:35 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:35 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:35 --> Router Class Initialized
ERROR - 2011-06-29 07:50:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:38 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:38 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:38 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:38 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:39 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:39 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:39 --> Total execution time: 1.3453
DEBUG - 2011-06-29 07:50:41 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:41 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:41 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:41 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:41 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:41 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:41 --> Total execution time: 0.0461
DEBUG - 2011-06-29 07:50:43 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:43 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:43 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:43 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:43 --> Router Class Initialized
ERROR - 2011-06-29 07:50:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:44 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:44 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:44 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:44 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:44 --> Router Class Initialized
ERROR - 2011-06-29 07:50:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:44 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:44 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:45 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:45 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:45 --> Router Class Initialized
ERROR - 2011-06-29 07:50:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:52 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:52 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:52 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:52 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:52 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:52 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:52 --> Total execution time: 0.3327
DEBUG - 2011-06-29 07:50:56 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:56 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:56 --> Router Class Initialized
ERROR - 2011-06-29 07:50:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:56 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:56 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:56 --> Router Class Initialized
ERROR - 2011-06-29 07:50:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:57 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:57 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Router Class Initialized
ERROR - 2011-06-29 07:50:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:57 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:57 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Router Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Output Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Input Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:50:57 --> Language Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Loader Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Controller Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Model Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:50:57 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:50:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:50:57 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:50:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:50:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:50:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:50:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:50:57 --> Final output sent to browser
DEBUG - 2011-06-29 07:50:57 --> Total execution time: 0.0471
DEBUG - 2011-06-29 07:50:57 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:57 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:57 --> Router Class Initialized
ERROR - 2011-06-29 07:50:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:50:58 --> Config Class Initialized
DEBUG - 2011-06-29 07:50:58 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:50:58 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:50:58 --> URI Class Initialized
DEBUG - 2011-06-29 07:50:58 --> Router Class Initialized
ERROR - 2011-06-29 07:50:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:03 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:03 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:03 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:03 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:03 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:03 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:03 --> Total execution time: 0.2581
DEBUG - 2011-06-29 07:51:07 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:07 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:07 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:07 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:07 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:07 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:07 --> Total execution time: 0.0754
DEBUG - 2011-06-29 07:51:07 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:07 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Router Class Initialized
ERROR - 2011-06-29 07:51:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:07 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:07 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:07 --> Router Class Initialized
ERROR - 2011-06-29 07:51:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:08 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:08 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:08 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:08 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:08 --> Router Class Initialized
ERROR - 2011-06-29 07:51:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:09 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:09 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:09 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:09 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:09 --> Router Class Initialized
ERROR - 2011-06-29 07:51:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:09 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:09 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:09 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:09 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:09 --> Router Class Initialized
ERROR - 2011-06-29 07:51:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:17 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:17 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:17 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:17 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:18 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:18 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:18 --> Total execution time: 0.4010
DEBUG - 2011-06-29 07:51:19 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:19 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:19 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:19 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:19 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:19 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:19 --> Total execution time: 0.0577
DEBUG - 2011-06-29 07:51:20 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:20 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:20 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:20 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:20 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:20 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:20 --> Total execution time: 0.0411
DEBUG - 2011-06-29 07:51:22 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:22 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:22 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:22 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:22 --> Router Class Initialized
ERROR - 2011-06-29 07:51:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:22 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:22 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:22 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:22 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:22 --> Router Class Initialized
ERROR - 2011-06-29 07:51:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:23 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:23 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Router Class Initialized
ERROR - 2011-06-29 07:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:23 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:23 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Router Class Initialized
ERROR - 2011-06-29 07:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:23 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:23 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:23 --> Router Class Initialized
ERROR - 2011-06-29 07:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:26 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:26 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:26 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:26 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:26 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:26 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:26 --> Total execution time: 0.3048
DEBUG - 2011-06-29 07:51:29 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:29 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:29 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:29 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:29 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:29 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:29 --> Total execution time: 0.0463
DEBUG - 2011-06-29 07:51:31 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:31 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:31 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:31 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:31 --> Router Class Initialized
ERROR - 2011-06-29 07:51:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:31 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:31 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:31 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:31 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:31 --> Router Class Initialized
ERROR - 2011-06-29 07:51:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:32 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:32 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:32 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:32 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Router Class Initialized
ERROR - 2011-06-29 07:51:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:32 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:32 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:32 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:32 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:32 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:32 --> Total execution time: 0.0458
DEBUG - 2011-06-29 07:51:33 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:33 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:33 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:33 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:33 --> Router Class Initialized
ERROR - 2011-06-29 07:51:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:34 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:34 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:34 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:34 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:35 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:35 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:35 --> Total execution time: 0.3760
DEBUG - 2011-06-29 07:51:37 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:37 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:37 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:37 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:37 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:37 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:37 --> Total execution time: 0.0630
DEBUG - 2011-06-29 07:51:39 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:39 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:39 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:39 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:39 --> Router Class Initialized
ERROR - 2011-06-29 07:51:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:40 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:40 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:40 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:40 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:40 --> Router Class Initialized
ERROR - 2011-06-29 07:51:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:41 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:41 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:41 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:41 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:41 --> Router Class Initialized
ERROR - 2011-06-29 07:51:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:44 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:44 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:44 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:44 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:44 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:44 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:44 --> Total execution time: 0.2600
DEBUG - 2011-06-29 07:51:46 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:46 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:46 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:46 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:46 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:46 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:46 --> Total execution time: 0.0450
DEBUG - 2011-06-29 07:51:46 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:46 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:46 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:46 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:46 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:46 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:46 --> Total execution time: 0.0414
DEBUG - 2011-06-29 07:51:48 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:48 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:48 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:48 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:48 --> Router Class Initialized
ERROR - 2011-06-29 07:51:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:49 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:49 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:49 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:49 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:49 --> Router Class Initialized
ERROR - 2011-06-29 07:51:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:50 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:50 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:50 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:50 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:50 --> Router Class Initialized
ERROR - 2011-06-29 07:51:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:52 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:52 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:52 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:52 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:52 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:52 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:52 --> Total execution time: 0.2007
DEBUG - 2011-06-29 07:51:53 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:53 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Router Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Output Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Input Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 07:51:53 --> Language Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Loader Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Controller Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Model Class Initialized
DEBUG - 2011-06-29 07:51:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 07:51:53 --> Database Driver Class Initialized
DEBUG - 2011-06-29 07:51:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 07:51:53 --> Helper loaded: url_helper
DEBUG - 2011-06-29 07:51:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 07:51:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 07:51:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 07:51:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 07:51:53 --> Final output sent to browser
DEBUG - 2011-06-29 07:51:53 --> Total execution time: 0.0484
DEBUG - 2011-06-29 07:51:55 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:55 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:55 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:55 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:55 --> Router Class Initialized
ERROR - 2011-06-29 07:51:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:56 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:56 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:56 --> Router Class Initialized
ERROR - 2011-06-29 07:51:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:56 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:56 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:56 --> Router Class Initialized
ERROR - 2011-06-29 07:51:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:57 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:57 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:57 --> Router Class Initialized
ERROR - 2011-06-29 07:51:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 07:51:57 --> Config Class Initialized
DEBUG - 2011-06-29 07:51:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 07:51:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 07:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 07:51:57 --> URI Class Initialized
DEBUG - 2011-06-29 07:51:57 --> Router Class Initialized
ERROR - 2011-06-29 07:51:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 09:29:20 --> Config Class Initialized
DEBUG - 2011-06-29 09:29:20 --> Hooks Class Initialized
DEBUG - 2011-06-29 09:29:21 --> Utf8 Class Initialized
DEBUG - 2011-06-29 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 09:29:21 --> URI Class Initialized
DEBUG - 2011-06-29 09:29:21 --> Router Class Initialized
ERROR - 2011-06-29 09:29:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-29 10:32:56 --> Config Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:32:56 --> URI Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Router Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Output Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Input Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:32:56 --> Language Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Loader Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Controller Class Initialized
ERROR - 2011-06-29 10:32:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:32:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:32:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:32:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:32:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:32:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:32:56 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:32:56 --> Final output sent to browser
DEBUG - 2011-06-29 10:32:56 --> Total execution time: 0.5768
DEBUG - 2011-06-29 10:32:56 --> Config Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:32:56 --> URI Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Router Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Output Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Input Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:32:56 --> Language Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Loader Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Controller Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:32:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:32:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 10:32:57 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:32:57 --> Final output sent to browser
DEBUG - 2011-06-29 10:32:57 --> Total execution time: 0.8872
DEBUG - 2011-06-29 10:40:14 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:14 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:14 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Controller Class Initialized
ERROR - 2011-06-29 10:40:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:40:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:40:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:14 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:14 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:14 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:40:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:40:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:40:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:40:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:40:14 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:14 --> Total execution time: 0.6992
DEBUG - 2011-06-29 10:40:15 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:15 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:15 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Controller Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:15 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:16 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:16 --> Total execution time: 0.6734
DEBUG - 2011-06-29 10:40:17 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:17 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:17 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:17 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:17 --> Router Class Initialized
ERROR - 2011-06-29 10:40:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 10:40:36 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:36 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:36 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Controller Class Initialized
ERROR - 2011-06-29 10:40:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:40:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:36 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:36 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:36 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:40:36 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:36 --> Total execution time: 0.0313
DEBUG - 2011-06-29 10:40:36 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:36 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:36 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Controller Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:36 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:37 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:37 --> Total execution time: 0.5812
DEBUG - 2011-06-29 10:40:51 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:51 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:51 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Controller Class Initialized
ERROR - 2011-06-29 10:40:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:40:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:40:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:51 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:51 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:51 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:40:51 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:51 --> Total execution time: 0.0291
DEBUG - 2011-06-29 10:40:52 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:52 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:52 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Controller Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:52 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:52 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:52 --> Total execution time: 0.5527
DEBUG - 2011-06-29 10:40:59 --> Config Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:40:59 --> URI Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Router Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Output Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Input Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:40:59 --> Language Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Loader Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Controller Class Initialized
ERROR - 2011-06-29 10:40:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:40:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:40:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:59 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Model Class Initialized
DEBUG - 2011-06-29 10:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:40:59 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:40:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:40:59 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:40:59 --> Final output sent to browser
DEBUG - 2011-06-29 10:40:59 --> Total execution time: 0.0284
DEBUG - 2011-06-29 10:41:02 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:02 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:02 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:02 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:02 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:02 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:02 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:02 --> Total execution time: 0.0299
DEBUG - 2011-06-29 10:41:02 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:02 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:02 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Controller Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:02 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:03 --> Total execution time: 0.6153
DEBUG - 2011-06-29 10:41:03 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:03 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:03 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:03 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:03 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:03 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:03 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:03 --> Total execution time: 0.0270
DEBUG - 2011-06-29 10:41:08 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:08 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:08 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:08 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:08 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:08 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:08 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:08 --> Total execution time: 0.0293
DEBUG - 2011-06-29 10:41:12 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:12 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:12 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:12 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:12 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:12 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:12 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:12 --> Total execution time: 0.0352
DEBUG - 2011-06-29 10:41:13 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:13 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:13 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:13 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:13 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:13 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:13 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:13 --> Total execution time: 0.0285
DEBUG - 2011-06-29 10:41:14 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:14 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:14 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Controller Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:14 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:14 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:14 --> Total execution time: 0.5326
DEBUG - 2011-06-29 10:41:32 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:32 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:32 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:32 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:32 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:32 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:32 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:32 --> Total execution time: 0.0751
DEBUG - 2011-06-29 10:41:33 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:33 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:33 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Controller Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:33 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:33 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:33 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:33 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:33 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:33 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:33 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:33 --> Total execution time: 0.0554
DEBUG - 2011-06-29 10:41:33 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:33 --> Total execution time: 0.5828
DEBUG - 2011-06-29 10:41:33 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:33 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:33 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:33 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:33 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:33 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:33 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:33 --> Total execution time: 0.1173
DEBUG - 2011-06-29 10:41:43 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:43 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:43 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:43 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:43 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:43 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:43 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:43 --> Total execution time: 0.0295
DEBUG - 2011-06-29 10:41:44 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:44 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:44 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Controller Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:44 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:45 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:45 --> Total execution time: 0.6035
DEBUG - 2011-06-29 10:41:48 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:48 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:48 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:48 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:48 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:48 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:48 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:48 --> Total execution time: 0.0299
DEBUG - 2011-06-29 10:41:56 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:56 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:56 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:56 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:56 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:56 --> Total execution time: 0.0267
DEBUG - 2011-06-29 10:41:57 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:57 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:57 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Controller Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:57 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:58 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:58 --> Total execution time: 0.7668
DEBUG - 2011-06-29 10:41:59 --> Config Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:41:59 --> URI Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Router Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Output Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Input Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:41:59 --> Language Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Loader Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Controller Class Initialized
ERROR - 2011-06-29 10:41:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:41:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:59 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Model Class Initialized
DEBUG - 2011-06-29 10:41:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:41:59 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:41:59 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:41:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:41:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:41:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:41:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:41:59 --> Final output sent to browser
DEBUG - 2011-06-29 10:41:59 --> Total execution time: 0.0280
DEBUG - 2011-06-29 10:42:06 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:06 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:06 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:06 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:06 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:06 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:06 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:06 --> Total execution time: 0.0386
DEBUG - 2011-06-29 10:42:06 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:06 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:06 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Controller Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:06 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:07 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:07 --> Total execution time: 0.6151
DEBUG - 2011-06-29 10:42:08 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:08 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:08 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:08 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:08 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:08 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:08 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:08 --> Total execution time: 0.0286
DEBUG - 2011-06-29 10:42:23 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:23 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:23 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:23 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:23 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:23 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:23 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:23 --> Total execution time: 0.0888
DEBUG - 2011-06-29 10:42:24 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:24 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:24 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Controller Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:24 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:24 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:24 --> Total execution time: 0.5104
DEBUG - 2011-06-29 10:42:25 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:25 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:25 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:25 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:25 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:25 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:25 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:25 --> Total execution time: 0.0294
DEBUG - 2011-06-29 10:42:30 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:30 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:30 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:30 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:30 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:30 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:30 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:30 --> Total execution time: 0.0385
DEBUG - 2011-06-29 10:42:30 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:30 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:30 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Controller Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:30 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:31 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:31 --> Total execution time: 0.6112
DEBUG - 2011-06-29 10:42:46 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:46 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:46 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:46 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:46 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:46 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:46 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:46 --> Total execution time: 0.0266
DEBUG - 2011-06-29 10:42:46 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:46 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:46 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Controller Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:46 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:47 --> Total execution time: 0.4891
DEBUG - 2011-06-29 10:42:47 --> Config Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Hooks Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Utf8 Class Initialized
DEBUG - 2011-06-29 10:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 10:42:47 --> URI Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Router Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Output Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Input Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 10:42:47 --> Language Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Loader Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Controller Class Initialized
ERROR - 2011-06-29 10:42:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 10:42:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 10:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:47 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Model Class Initialized
DEBUG - 2011-06-29 10:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 10:42:47 --> Database Driver Class Initialized
DEBUG - 2011-06-29 10:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 10:42:47 --> Helper loaded: url_helper
DEBUG - 2011-06-29 10:42:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 10:42:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 10:42:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 10:42:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 10:42:47 --> Final output sent to browser
DEBUG - 2011-06-29 10:42:47 --> Total execution time: 0.0270
DEBUG - 2011-06-29 14:46:56 --> Config Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 14:46:56 --> URI Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Router Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Output Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Input Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 14:46:56 --> Language Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Loader Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Controller Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Model Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Model Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Model Class Initialized
DEBUG - 2011-06-29 14:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 14:46:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 14:46:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 14:46:57 --> Helper loaded: url_helper
DEBUG - 2011-06-29 14:46:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 14:46:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 14:46:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 14:46:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 14:46:57 --> Final output sent to browser
DEBUG - 2011-06-29 14:46:57 --> Total execution time: 0.5853
DEBUG - 2011-06-29 15:40:40 --> Config Class Initialized
DEBUG - 2011-06-29 15:40:40 --> Hooks Class Initialized
DEBUG - 2011-06-29 15:40:40 --> Utf8 Class Initialized
DEBUG - 2011-06-29 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 15:40:40 --> URI Class Initialized
DEBUG - 2011-06-29 15:40:40 --> Router Class Initialized
ERROR - 2011-06-29 15:40:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-29 15:40:41 --> Config Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Hooks Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Utf8 Class Initialized
DEBUG - 2011-06-29 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 15:40:41 --> URI Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Router Class Initialized
DEBUG - 2011-06-29 15:40:41 --> No URI present. Default controller set.
DEBUG - 2011-06-29 15:40:41 --> Output Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Input Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 15:40:41 --> Language Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Loader Class Initialized
DEBUG - 2011-06-29 15:40:41 --> Controller Class Initialized
DEBUG - 2011-06-29 15:40:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-29 15:40:41 --> Helper loaded: url_helper
DEBUG - 2011-06-29 15:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 15:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 15:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 15:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 15:40:41 --> Final output sent to browser
DEBUG - 2011-06-29 15:40:41 --> Total execution time: 0.3900
DEBUG - 2011-06-29 20:53:27 --> Config Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:53:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:53:27 --> URI Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Router Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Output Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Input Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:53:27 --> Language Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Loader Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Controller Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Model Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Model Class Initialized
DEBUG - 2011-06-29 20:53:27 --> Model Class Initialized
DEBUG - 2011-06-29 20:53:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:53:28 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:53:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:53:29 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:53:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:53:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:53:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:53:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:53:29 --> Final output sent to browser
DEBUG - 2011-06-29 20:53:29 --> Total execution time: 2.3219
DEBUG - 2011-06-29 20:53:36 --> Config Class Initialized
DEBUG - 2011-06-29 20:53:36 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:53:36 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:53:36 --> URI Class Initialized
DEBUG - 2011-06-29 20:53:36 --> Router Class Initialized
ERROR - 2011-06-29 20:53:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-29 20:53:37 --> Config Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:53:37 --> URI Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Router Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Output Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Input Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:53:37 --> Language Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Loader Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Controller Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Model Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Model Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Model Class Initialized
DEBUG - 2011-06-29 20:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:53:37 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:53:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:53:37 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:53:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:53:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:53:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:53:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:53:37 --> Final output sent to browser
DEBUG - 2011-06-29 20:53:37 --> Total execution time: 0.0468
DEBUG - 2011-06-29 20:53:38 --> Config Class Initialized
DEBUG - 2011-06-29 20:53:38 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:53:38 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:53:38 --> URI Class Initialized
DEBUG - 2011-06-29 20:53:38 --> Router Class Initialized
ERROR - 2011-06-29 20:53:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 20:53:38 --> Config Class Initialized
DEBUG - 2011-06-29 20:53:38 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:53:38 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:53:38 --> URI Class Initialized
DEBUG - 2011-06-29 20:53:38 --> Router Class Initialized
ERROR - 2011-06-29 20:53:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-29 20:54:56 --> Config Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:54:56 --> URI Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Router Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Output Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Input Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:54:56 --> Language Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Loader Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Controller Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:54:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:54:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:54:57 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:54:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:54:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:54:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:54:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:54:57 --> Final output sent to browser
DEBUG - 2011-06-29 20:54:57 --> Total execution time: 0.3026
DEBUG - 2011-06-29 20:54:58 --> Config Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:54:58 --> URI Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Router Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Output Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Input Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:54:58 --> Language Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Loader Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Controller Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:54:58 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:54:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:54:58 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:54:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:54:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:54:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:54:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:54:58 --> Final output sent to browser
DEBUG - 2011-06-29 20:54:58 --> Total execution time: 0.0413
DEBUG - 2011-06-29 20:54:59 --> Config Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:54:59 --> URI Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Router Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Output Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Input Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:54:59 --> Language Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Loader Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Controller Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Model Class Initialized
DEBUG - 2011-06-29 20:54:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:54:59 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:54:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:54:59 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:54:59 --> Final output sent to browser
DEBUG - 2011-06-29 20:54:59 --> Total execution time: 0.0398
DEBUG - 2011-06-29 20:55:12 --> Config Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:55:12 --> URI Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Router Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Output Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Input Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:55:12 --> Language Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Loader Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Controller Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:55:12 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:55:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:55:12 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:55:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:55:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:55:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:55:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:55:12 --> Final output sent to browser
DEBUG - 2011-06-29 20:55:12 --> Total execution time: 0.2787
DEBUG - 2011-06-29 20:55:14 --> Config Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:55:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:55:14 --> URI Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Router Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Output Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Input Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:55:14 --> Language Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Loader Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Controller Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:55:14 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:55:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:55:14 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:55:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:55:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:55:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:55:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:55:14 --> Final output sent to browser
DEBUG - 2011-06-29 20:55:14 --> Total execution time: 0.0468
DEBUG - 2011-06-29 20:55:28 --> Config Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:55:28 --> URI Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Router Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Output Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Input Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:55:28 --> Language Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Loader Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Controller Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:55:28 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:55:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:55:28 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:55:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:55:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:55:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:55:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:55:28 --> Final output sent to browser
DEBUG - 2011-06-29 20:55:28 --> Total execution time: 0.2270
DEBUG - 2011-06-29 20:55:40 --> Config Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:55:40 --> URI Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Router Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Output Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Input Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:55:40 --> Language Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Loader Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Controller Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Model Class Initialized
DEBUG - 2011-06-29 20:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:55:40 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:55:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:55:41 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:55:41 --> Final output sent to browser
DEBUG - 2011-06-29 20:55:41 --> Total execution time: 0.3525
DEBUG - 2011-06-29 20:56:05 --> Config Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:56:05 --> URI Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Router Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Output Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Input Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:56:05 --> Language Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Loader Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Controller Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:56:05 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:56:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:56:06 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:56:06 --> Final output sent to browser
DEBUG - 2011-06-29 20:56:06 --> Total execution time: 0.5851
DEBUG - 2011-06-29 20:56:31 --> Config Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:56:31 --> URI Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Router Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Output Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Input Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:56:31 --> Language Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Loader Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Controller Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:56:31 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:56:31 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:56:31 --> Final output sent to browser
DEBUG - 2011-06-29 20:56:31 --> Total execution time: 0.2914
DEBUG - 2011-06-29 20:56:43 --> Config Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:56:43 --> URI Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Router Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Output Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Input Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:56:43 --> Language Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Loader Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Controller Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:56:43 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:56:43 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:56:43 --> Final output sent to browser
DEBUG - 2011-06-29 20:56:43 --> Total execution time: 0.2062
DEBUG - 2011-06-29 20:56:56 --> Config Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:56:56 --> URI Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Router Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Output Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Input Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:56:56 --> Language Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Loader Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Controller Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Model Class Initialized
DEBUG - 2011-06-29 20:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:56:56 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:56:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:56:57 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:56:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:56:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:56:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:56:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:56:57 --> Final output sent to browser
DEBUG - 2011-06-29 20:56:57 --> Total execution time: 0.2105
DEBUG - 2011-06-29 20:57:13 --> Config Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:57:13 --> URI Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Router Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Output Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Input Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:57:13 --> Language Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Loader Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Controller Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:57:13 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:57:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:57:14 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:57:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:57:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:57:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:57:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:57:14 --> Final output sent to browser
DEBUG - 2011-06-29 20:57:14 --> Total execution time: 0.4316
DEBUG - 2011-06-29 20:57:34 --> Config Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:57:34 --> URI Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Router Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Output Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Input Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:57:34 --> Language Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Loader Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Controller Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:57:34 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:57:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:57:34 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:57:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:57:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:57:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:57:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:57:34 --> Final output sent to browser
DEBUG - 2011-06-29 20:57:34 --> Total execution time: 0.2212
DEBUG - 2011-06-29 20:57:58 --> Config Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:57:58 --> URI Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Router Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Output Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Input Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:57:58 --> Language Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Loader Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Controller Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Model Class Initialized
DEBUG - 2011-06-29 20:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:57:58 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:57:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:57:59 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:57:59 --> Final output sent to browser
DEBUG - 2011-06-29 20:57:59 --> Total execution time: 0.4835
DEBUG - 2011-06-29 20:58:08 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:08 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:08 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:08 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:09 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:09 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:09 --> Total execution time: 0.9203
DEBUG - 2011-06-29 20:58:18 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:18 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:18 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:18 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:19 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:19 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:19 --> Total execution time: 0.4126
DEBUG - 2011-06-29 20:58:33 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:33 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:33 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:33 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:33 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:33 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:33 --> Total execution time: 0.2811
DEBUG - 2011-06-29 20:58:47 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:47 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:47 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:47 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:47 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:47 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:47 --> Total execution time: 0.7590
DEBUG - 2011-06-29 20:58:49 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:49 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:49 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:49 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:49 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:49 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:49 --> Total execution time: 0.0438
DEBUG - 2011-06-29 20:58:57 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:57 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:57 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:57 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:57 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:57 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:57 --> Total execution time: 0.4859
DEBUG - 2011-06-29 20:58:59 --> Config Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:58:59 --> URI Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Router Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Output Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Input Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:58:59 --> Language Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Loader Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Controller Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Model Class Initialized
DEBUG - 2011-06-29 20:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:58:59 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:58:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:58:59 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:58:59 --> Final output sent to browser
DEBUG - 2011-06-29 20:58:59 --> Total execution time: 0.0461
DEBUG - 2011-06-29 20:59:00 --> Config Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:59:00 --> URI Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Router Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Output Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Input Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:59:00 --> Language Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Loader Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Controller Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:59:00 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:59:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:59:00 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:59:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:59:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:59:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:59:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:59:00 --> Final output sent to browser
DEBUG - 2011-06-29 20:59:00 --> Total execution time: 0.0476
DEBUG - 2011-06-29 20:59:06 --> Config Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:59:06 --> URI Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Router Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Output Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Input Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:59:06 --> Language Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Loader Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Controller Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:59:06 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:59:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:59:07 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:59:07 --> Final output sent to browser
DEBUG - 2011-06-29 20:59:07 --> Total execution time: 0.3690
DEBUG - 2011-06-29 20:59:08 --> Config Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:59:08 --> URI Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Router Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Output Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Input Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:59:08 --> Language Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Loader Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Controller Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:59:08 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:59:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:59:08 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:59:08 --> Final output sent to browser
DEBUG - 2011-06-29 20:59:08 --> Total execution time: 0.0687
DEBUG - 2011-06-29 20:59:20 --> Config Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:59:20 --> URI Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Router Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Output Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Input Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:59:20 --> Language Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Loader Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Controller Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:59:20 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:59:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:59:20 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:59:20 --> Final output sent to browser
DEBUG - 2011-06-29 20:59:20 --> Total execution time: 0.3204
DEBUG - 2011-06-29 20:59:24 --> Config Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Hooks Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Utf8 Class Initialized
DEBUG - 2011-06-29 20:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 20:59:24 --> URI Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Router Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Output Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Input Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 20:59:24 --> Language Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Loader Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Controller Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Model Class Initialized
DEBUG - 2011-06-29 20:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 20:59:24 --> Database Driver Class Initialized
DEBUG - 2011-06-29 20:59:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 20:59:24 --> Helper loaded: url_helper
DEBUG - 2011-06-29 20:59:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 20:59:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 20:59:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 20:59:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 20:59:24 --> Final output sent to browser
DEBUG - 2011-06-29 20:59:24 --> Total execution time: 0.0536
DEBUG - 2011-06-29 21:01:15 --> Config Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:01:15 --> URI Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Router Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Output Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Input Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:01:15 --> Language Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Loader Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Controller Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:01:15 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:01:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:01:15 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:01:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:01:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:01:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:01:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:01:15 --> Final output sent to browser
DEBUG - 2011-06-29 21:01:15 --> Total execution time: 0.2987
DEBUG - 2011-06-29 21:01:16 --> Config Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:01:16 --> URI Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Router Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Output Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Input Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:01:16 --> Language Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Loader Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Controller Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:01:17 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:01:17 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:01:17 --> Final output sent to browser
DEBUG - 2011-06-29 21:01:17 --> Total execution time: 0.0553
DEBUG - 2011-06-29 21:01:17 --> Config Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:01:17 --> URI Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Router Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Output Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Input Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:01:17 --> Language Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Loader Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Controller Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Model Class Initialized
DEBUG - 2011-06-29 21:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:01:17 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:01:17 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:01:17 --> Final output sent to browser
DEBUG - 2011-06-29 21:01:17 --> Total execution time: 0.0521
DEBUG - 2011-06-29 21:02:32 --> Config Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:02:32 --> URI Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Router Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Output Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Input Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:02:32 --> Language Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Loader Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Controller Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:02:32 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:02:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:02:33 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:02:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:02:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:02:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:02:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:02:33 --> Final output sent to browser
DEBUG - 2011-06-29 21:02:33 --> Total execution time: 0.3814
DEBUG - 2011-06-29 21:02:35 --> Config Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:02:35 --> URI Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Router Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Output Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Input Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:02:35 --> Language Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Loader Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Controller Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:02:35 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:02:35 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:02:35 --> Final output sent to browser
DEBUG - 2011-06-29 21:02:35 --> Total execution time: 0.0419
DEBUG - 2011-06-29 21:02:35 --> Config Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:02:35 --> URI Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Router Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Output Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Input Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:02:35 --> Language Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Loader Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Controller Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:02:35 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:02:35 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:02:35 --> Final output sent to browser
DEBUG - 2011-06-29 21:02:35 --> Total execution time: 0.0430
DEBUG - 2011-06-29 21:03:09 --> Config Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:03:09 --> URI Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Router Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Output Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Input Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:03:09 --> Language Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Loader Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Controller Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:03:09 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:03:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:03:09 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:03:09 --> Final output sent to browser
DEBUG - 2011-06-29 21:03:09 --> Total execution time: 0.5838
DEBUG - 2011-06-29 21:03:15 --> Config Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:03:15 --> URI Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Router Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Output Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Input Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:03:15 --> Language Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Loader Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Controller Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:03:15 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:03:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:03:15 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:03:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:03:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:03:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:03:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:03:15 --> Final output sent to browser
DEBUG - 2011-06-29 21:03:15 --> Total execution time: 0.0570
DEBUG - 2011-06-29 21:03:22 --> Config Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:03:22 --> URI Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Router Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Output Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Input Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:03:22 --> Language Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Loader Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Controller Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:03:22 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:03:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:03:22 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:03:22 --> Final output sent to browser
DEBUG - 2011-06-29 21:03:22 --> Total execution time: 0.5524
DEBUG - 2011-06-29 21:03:25 --> Config Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:03:25 --> URI Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Router Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Output Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Input Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:03:25 --> Language Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Loader Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Controller Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:03:25 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:03:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:03:25 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:03:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:03:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:03:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:03:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:03:25 --> Final output sent to browser
DEBUG - 2011-06-29 21:03:25 --> Total execution time: 0.0609
DEBUG - 2011-06-29 21:04:01 --> Config Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:04:01 --> URI Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Router Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Output Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Input Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:04:01 --> Language Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Loader Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Controller Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Model Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Model Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Model Class Initialized
DEBUG - 2011-06-29 21:04:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:04:01 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:04:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:04:01 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:04:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:04:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:04:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:04:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:04:01 --> Final output sent to browser
DEBUG - 2011-06-29 21:04:01 --> Total execution time: 0.0984
DEBUG - 2011-06-29 21:06:12 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:12 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:12 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:12 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:13 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:13 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:13 --> Total execution time: 0.5520
DEBUG - 2011-06-29 21:06:17 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:17 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:17 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:17 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:17 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:17 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:17 --> Total execution time: 0.0397
DEBUG - 2011-06-29 21:06:23 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:23 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:23 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:23 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:23 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:23 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:23 --> Total execution time: 0.4450
DEBUG - 2011-06-29 21:06:25 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:25 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:25 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:25 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:25 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:25 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:25 --> Total execution time: 0.0962
DEBUG - 2011-06-29 21:06:25 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:25 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:25 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:25 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:25 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:25 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:25 --> Total execution time: 0.0461
DEBUG - 2011-06-29 21:06:33 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:33 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:33 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:33 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:33 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:33 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:33 --> Total execution time: 0.1771
DEBUG - 2011-06-29 21:06:35 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:35 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:35 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:35 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:35 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:35 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:35 --> Total execution time: 0.0399
DEBUG - 2011-06-29 21:06:42 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:42 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:42 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:42 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:43 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:43 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:43 --> Total execution time: 0.2336
DEBUG - 2011-06-29 21:06:45 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:45 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:45 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:45 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:45 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:45 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:45 --> Total execution time: 0.0446
DEBUG - 2011-06-29 21:06:52 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:52 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:52 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:52 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:52 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:52 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:52 --> Total execution time: 0.3001
DEBUG - 2011-06-29 21:06:54 --> Config Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Hooks Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Utf8 Class Initialized
DEBUG - 2011-06-29 21:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 21:06:54 --> URI Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Router Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Output Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Input Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 21:06:54 --> Language Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Loader Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Controller Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Model Class Initialized
DEBUG - 2011-06-29 21:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 21:06:54 --> Database Driver Class Initialized
DEBUG - 2011-06-29 21:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-29 21:06:54 --> Helper loaded: url_helper
DEBUG - 2011-06-29 21:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 21:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 21:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 21:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 21:06:54 --> Final output sent to browser
DEBUG - 2011-06-29 21:06:54 --> Total execution time: 0.0403
DEBUG - 2011-06-29 22:00:48 --> Config Class Initialized
DEBUG - 2011-06-29 22:00:48 --> Hooks Class Initialized
DEBUG - 2011-06-29 22:00:48 --> Utf8 Class Initialized
DEBUG - 2011-06-29 22:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 22:00:48 --> URI Class Initialized
DEBUG - 2011-06-29 22:00:49 --> Router Class Initialized
DEBUG - 2011-06-29 22:00:49 --> Output Class Initialized
DEBUG - 2011-06-29 22:00:49 --> Input Class Initialized
DEBUG - 2011-06-29 22:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 22:00:50 --> Language Class Initialized
DEBUG - 2011-06-29 22:00:52 --> Loader Class Initialized
DEBUG - 2011-06-29 22:00:52 --> Controller Class Initialized
ERROR - 2011-06-29 22:00:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-29 22:00:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-29 22:00:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 22:00:54 --> Model Class Initialized
DEBUG - 2011-06-29 22:00:54 --> Model Class Initialized
DEBUG - 2011-06-29 22:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 22:00:54 --> Database Driver Class Initialized
DEBUG - 2011-06-29 22:00:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-29 22:00:54 --> Helper loaded: url_helper
DEBUG - 2011-06-29 22:00:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-29 22:00:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-29 22:00:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-29 22:00:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-29 22:00:54 --> Final output sent to browser
DEBUG - 2011-06-29 22:00:54 --> Total execution time: 7.9892
DEBUG - 2011-06-29 22:01:01 --> Config Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Hooks Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Utf8 Class Initialized
DEBUG - 2011-06-29 22:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-29 22:01:01 --> URI Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Router Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Output Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Input Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-29 22:01:01 --> Language Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Loader Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Controller Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Model Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Model Class Initialized
DEBUG - 2011-06-29 22:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-29 22:01:01 --> Database Driver Class Initialized
DEBUG - 2011-06-29 22:01:02 --> Final output sent to browser
DEBUG - 2011-06-29 22:01:02 --> Total execution time: 1.4804

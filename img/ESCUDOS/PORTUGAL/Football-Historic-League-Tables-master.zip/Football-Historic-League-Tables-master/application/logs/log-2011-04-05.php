<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-05 00:03:15 --> Config Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:03:15 --> URI Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Router Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Output Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Input Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:03:15 --> Language Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Loader Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Controller Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Model Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Model Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Model Class Initialized
DEBUG - 2011-04-05 00:03:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:03:15 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:03:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 00:03:16 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:03:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:03:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:03:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:03:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:03:16 --> Final output sent to browser
DEBUG - 2011-04-05 00:03:16 --> Total execution time: 0.4833
DEBUG - 2011-04-05 00:28:39 --> Config Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:28:39 --> URI Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Router Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Output Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Input Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:28:39 --> Language Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Loader Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Controller Class Initialized
ERROR - 2011-04-05 00:28:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:28:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:28:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:28:39 --> Model Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Model Class Initialized
DEBUG - 2011-04-05 00:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:28:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:28:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:28:39 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:28:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:28:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:28:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:28:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:28:39 --> Final output sent to browser
DEBUG - 2011-04-05 00:28:39 --> Total execution time: 0.2710
DEBUG - 2011-04-05 00:29:50 --> Config Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:29:50 --> URI Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Router Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Output Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Input Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:29:50 --> Language Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Loader Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Controller Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Model Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Model Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Model Class Initialized
DEBUG - 2011-04-05 00:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:29:50 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:29:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 00:29:50 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:29:50 --> Final output sent to browser
DEBUG - 2011-04-05 00:29:50 --> Total execution time: 0.9446
DEBUG - 2011-04-05 00:29:53 --> Config Class Initialized
DEBUG - 2011-04-05 00:29:53 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:29:53 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:29:53 --> URI Class Initialized
DEBUG - 2011-04-05 00:29:53 --> Router Class Initialized
ERROR - 2011-04-05 00:29:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:34:14 --> Config Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:34:14 --> URI Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Router Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Output Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Input Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:34:14 --> Language Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Loader Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Controller Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Model Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Model Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Model Class Initialized
DEBUG - 2011-04-05 00:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:34:14 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:34:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 00:34:14 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:34:14 --> Final output sent to browser
DEBUG - 2011-04-05 00:34:14 --> Total execution time: 0.0557
DEBUG - 2011-04-05 00:34:18 --> Config Class Initialized
DEBUG - 2011-04-05 00:34:18 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:34:18 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:34:18 --> URI Class Initialized
DEBUG - 2011-04-05 00:34:18 --> Router Class Initialized
ERROR - 2011-04-05 00:34:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:36:18 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:18 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Router Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Output Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Input Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:36:18 --> Language Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Loader Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Controller Class Initialized
ERROR - 2011-04-05 00:36:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:36:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:36:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:36:18 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:36:18 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:36:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:36:18 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:36:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:36:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:36:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:36:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:36:18 --> Final output sent to browser
DEBUG - 2011-04-05 00:36:18 --> Total execution time: 0.0370
DEBUG - 2011-04-05 00:36:20 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:20 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Router Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Output Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Input Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:36:20 --> Language Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Loader Class Initialized
DEBUG - 2011-04-05 00:36:20 --> Controller Class Initialized
DEBUG - 2011-04-05 00:36:21 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:21 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:36:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:36:22 --> Final output sent to browser
DEBUG - 2011-04-05 00:36:22 --> Total execution time: 1.1935
DEBUG - 2011-04-05 00:36:24 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:24 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:24 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:24 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:24 --> Router Class Initialized
ERROR - 2011-04-05 00:36:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:36:41 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:41 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Router Class Initialized
DEBUG - 2011-04-05 00:36:41 --> No URI present. Default controller set.
DEBUG - 2011-04-05 00:36:41 --> Output Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Input Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:36:41 --> Language Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Loader Class Initialized
DEBUG - 2011-04-05 00:36:41 --> Controller Class Initialized
DEBUG - 2011-04-05 00:36:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 00:36:41 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:36:41 --> Final output sent to browser
DEBUG - 2011-04-05 00:36:41 --> Total execution time: 0.0628
DEBUG - 2011-04-05 00:36:43 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:43 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:43 --> Router Class Initialized
ERROR - 2011-04-05 00:36:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:36:47 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:47 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Router Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Output Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Input Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:36:47 --> Language Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Loader Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Controller Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:36:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:36:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 00:36:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:36:47 --> Final output sent to browser
DEBUG - 2011-04-05 00:36:47 --> Total execution time: 0.0541
DEBUG - 2011-04-05 00:36:48 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:48 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:48 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:48 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:48 --> Router Class Initialized
ERROR - 2011-04-05 00:36:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:36:56 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:56 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Router Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Output Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Input Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:36:56 --> Language Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Loader Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Controller Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:36:56 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:36:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 00:36:56 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:36:56 --> Final output sent to browser
DEBUG - 2011-04-05 00:36:56 --> Total execution time: 0.2863
DEBUG - 2011-04-05 00:36:58 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:58 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Router Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Output Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Input Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:36:58 --> Language Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Loader Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Controller Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Model Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:36:58 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:36:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 00:36:58 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:36:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:36:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:36:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:36:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:36:58 --> Final output sent to browser
DEBUG - 2011-04-05 00:36:58 --> Total execution time: 0.0557
DEBUG - 2011-04-05 00:36:58 --> Config Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:36:58 --> URI Class Initialized
DEBUG - 2011-04-05 00:36:58 --> Router Class Initialized
ERROR - 2011-04-05 00:36:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:54:34 --> Config Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:54:34 --> URI Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Router Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Output Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Input Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:54:34 --> Language Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Loader Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Controller Class Initialized
ERROR - 2011-04-05 00:54:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:54:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:54:34 --> Model Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Model Class Initialized
DEBUG - 2011-04-05 00:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:54:34 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:54:34 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:54:34 --> Final output sent to browser
DEBUG - 2011-04-05 00:54:34 --> Total execution time: 0.3249
DEBUG - 2011-04-05 00:54:36 --> Config Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:54:36 --> URI Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Router Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Output Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Input Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:54:36 --> Language Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Loader Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Controller Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Model Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Model Class Initialized
DEBUG - 2011-04-05 00:54:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:54:36 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:54:37 --> Final output sent to browser
DEBUG - 2011-04-05 00:54:37 --> Total execution time: 0.8922
DEBUG - 2011-04-05 00:54:41 --> Config Class Initialized
DEBUG - 2011-04-05 00:54:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:54:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:54:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:54:41 --> URI Class Initialized
DEBUG - 2011-04-05 00:54:41 --> Router Class Initialized
ERROR - 2011-04-05 00:54:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 00:55:49 --> Config Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:55:49 --> URI Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Router Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Output Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Input Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:55:49 --> Language Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Loader Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Controller Class Initialized
ERROR - 2011-04-05 00:55:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:55:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:55:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:55:49 --> Model Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Model Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:55:49 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:55:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:55:49 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:55:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:55:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:55:49 --> Final output sent to browser
DEBUG - 2011-04-05 00:55:49 --> Total execution time: 0.0351
DEBUG - 2011-04-05 00:55:49 --> Config Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:55:49 --> URI Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Router Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Output Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Input Class Initialized
DEBUG - 2011-04-05 00:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:55:49 --> Language Class Initialized
DEBUG - 2011-04-05 00:55:50 --> Loader Class Initialized
DEBUG - 2011-04-05 00:55:50 --> Controller Class Initialized
DEBUG - 2011-04-05 00:55:50 --> Model Class Initialized
DEBUG - 2011-04-05 00:55:50 --> Model Class Initialized
DEBUG - 2011-04-05 00:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:55:50 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:55:50 --> Final output sent to browser
DEBUG - 2011-04-05 00:55:50 --> Total execution time: 0.8094
DEBUG - 2011-04-05 00:56:06 --> Config Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:56:06 --> URI Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Router Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Output Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Input Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:56:06 --> Language Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Loader Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Controller Class Initialized
ERROR - 2011-04-05 00:56:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:56:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:56:06 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:56:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:56:06 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:56:06 --> Final output sent to browser
DEBUG - 2011-04-05 00:56:06 --> Total execution time: 0.0298
DEBUG - 2011-04-05 00:56:06 --> Config Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:56:06 --> URI Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Router Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Output Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Input Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:56:06 --> Language Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Loader Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Controller Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:56:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:56:07 --> Final output sent to browser
DEBUG - 2011-04-05 00:56:07 --> Total execution time: 0.8293
DEBUG - 2011-04-05 00:56:52 --> Config Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:56:52 --> URI Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Router Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Output Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Input Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:56:52 --> Language Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Loader Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Controller Class Initialized
ERROR - 2011-04-05 00:56:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:56:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:56:52 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:56:52 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:56:52 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:56:52 --> Final output sent to browser
DEBUG - 2011-04-05 00:56:52 --> Total execution time: 0.0291
DEBUG - 2011-04-05 00:56:54 --> Config Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:56:54 --> URI Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Router Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Output Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Input Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:56:54 --> Language Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Loader Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Controller Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Model Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:56:54 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:56:54 --> Final output sent to browser
DEBUG - 2011-04-05 00:56:54 --> Total execution time: 0.7259
DEBUG - 2011-04-05 00:57:04 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:04 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:04 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Controller Class Initialized
ERROR - 2011-04-05 00:57:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:57:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:04 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:04 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:04 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:57:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:57:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:57:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:57:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:57:04 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:04 --> Total execution time: 0.0422
DEBUG - 2011-04-05 00:57:05 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:05 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:05 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Controller Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:05 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:05 --> Total execution time: 0.7248
DEBUG - 2011-04-05 00:57:22 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:22 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:22 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Controller Class Initialized
ERROR - 2011-04-05 00:57:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:57:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:22 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:22 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:22 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:57:22 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:22 --> Total execution time: 0.0331
DEBUG - 2011-04-05 00:57:22 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:22 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:22 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Controller Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:22 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:23 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:23 --> Total execution time: 0.9868
DEBUG - 2011-04-05 00:57:39 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:39 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:39 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Controller Class Initialized
ERROR - 2011-04-05 00:57:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:57:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:39 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:39 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:57:39 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:39 --> Total execution time: 0.0672
DEBUG - 2011-04-05 00:57:40 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:40 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:40 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Controller Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:41 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:41 --> Total execution time: 0.7819
DEBUG - 2011-04-05 00:57:59 --> Config Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:57:59 --> URI Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Router Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Output Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Input Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:57:59 --> Language Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Loader Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Controller Class Initialized
ERROR - 2011-04-05 00:57:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 00:57:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 00:57:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:59 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Model Class Initialized
DEBUG - 2011-04-05 00:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:57:59 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:57:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 00:57:59 --> Helper loaded: url_helper
DEBUG - 2011-04-05 00:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 00:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 00:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 00:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 00:57:59 --> Final output sent to browser
DEBUG - 2011-04-05 00:57:59 --> Total execution time: 0.0297
DEBUG - 2011-04-05 00:58:00 --> Config Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Hooks Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Utf8 Class Initialized
DEBUG - 2011-04-05 00:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 00:58:00 --> URI Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Router Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Output Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Input Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 00:58:00 --> Language Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Loader Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Controller Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Model Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Model Class Initialized
DEBUG - 2011-04-05 00:58:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 00:58:00 --> Database Driver Class Initialized
DEBUG - 2011-04-05 00:58:01 --> Final output sent to browser
DEBUG - 2011-04-05 00:58:01 --> Total execution time: 0.7299
DEBUG - 2011-04-05 01:23:45 --> Config Class Initialized
DEBUG - 2011-04-05 01:23:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:23:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:23:45 --> URI Class Initialized
DEBUG - 2011-04-05 01:23:45 --> Router Class Initialized
ERROR - 2011-04-05 01:23:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 01:23:45 --> Config Class Initialized
DEBUG - 2011-04-05 01:23:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:23:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:23:45 --> URI Class Initialized
DEBUG - 2011-04-05 01:23:45 --> Router Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Output Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Input Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:23:46 --> Language Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Loader Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Controller Class Initialized
ERROR - 2011-04-05 01:23:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:23:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:23:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:23:46 --> Model Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Model Class Initialized
DEBUG - 2011-04-05 01:23:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:23:46 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:23:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:23:46 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:23:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:23:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:23:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:23:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:23:46 --> Final output sent to browser
DEBUG - 2011-04-05 01:23:46 --> Total execution time: 0.1982
DEBUG - 2011-04-05 01:24:16 --> Config Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:24:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:24:16 --> URI Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Router Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Output Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Input Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:24:16 --> Language Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Loader Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Controller Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Model Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Model Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Model Class Initialized
DEBUG - 2011-04-05 01:24:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:24:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:24:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 01:24:16 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:24:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:24:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:24:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:24:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:24:16 --> Final output sent to browser
DEBUG - 2011-04-05 01:24:16 --> Total execution time: 0.3516
DEBUG - 2011-04-05 01:25:49 --> Config Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:25:49 --> URI Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Router Class Initialized
DEBUG - 2011-04-05 01:25:49 --> No URI present. Default controller set.
DEBUG - 2011-04-05 01:25:49 --> Output Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Input Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:25:49 --> Language Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Loader Class Initialized
DEBUG - 2011-04-05 01:25:49 --> Controller Class Initialized
DEBUG - 2011-04-05 01:25:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 01:25:49 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:25:49 --> Final output sent to browser
DEBUG - 2011-04-05 01:25:49 --> Total execution time: 0.0443
DEBUG - 2011-04-05 01:56:28 --> Config Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:56:28 --> URI Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Router Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Output Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Input Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:56:28 --> Language Class Initialized
DEBUG - 2011-04-05 01:56:28 --> Loader Class Initialized
DEBUG - 2011-04-05 01:56:29 --> Controller Class Initialized
ERROR - 2011-04-05 01:56:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:56:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:56:31 --> Model Class Initialized
DEBUG - 2011-04-05 01:56:31 --> Model Class Initialized
DEBUG - 2011-04-05 01:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:56:32 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:56:33 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:56:33 --> Final output sent to browser
DEBUG - 2011-04-05 01:56:33 --> Total execution time: 5.1438
DEBUG - 2011-04-05 01:56:35 --> Config Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:56:35 --> URI Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Router Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Output Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Input Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:56:35 --> Language Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Loader Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Controller Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Model Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Model Class Initialized
DEBUG - 2011-04-05 01:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:56:35 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:56:38 --> Final output sent to browser
DEBUG - 2011-04-05 01:56:38 --> Total execution time: 3.8462
DEBUG - 2011-04-05 01:56:40 --> Config Class Initialized
DEBUG - 2011-04-05 01:56:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:56:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:56:40 --> URI Class Initialized
DEBUG - 2011-04-05 01:56:40 --> Router Class Initialized
ERROR - 2011-04-05 01:56:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 01:56:43 --> Config Class Initialized
DEBUG - 2011-04-05 01:56:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:56:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:56:43 --> URI Class Initialized
DEBUG - 2011-04-05 01:56:43 --> Router Class Initialized
ERROR - 2011-04-05 01:56:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 01:57:01 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:01 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:01 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Controller Class Initialized
ERROR - 2011-04-05 01:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:01 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:01 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:57:01 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:01 --> Total execution time: 0.0316
DEBUG - 2011-04-05 01:57:01 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:01 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:01 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Controller Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:03 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:03 --> Total execution time: 1.7771
DEBUG - 2011-04-05 01:57:15 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:15 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:15 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Controller Class Initialized
ERROR - 2011-04-05 01:57:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:57:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:15 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:15 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:15 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:57:15 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:15 --> Total execution time: 0.0826
DEBUG - 2011-04-05 01:57:16 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:16 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:16 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Controller Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:17 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:17 --> Total execution time: 1.4207
DEBUG - 2011-04-05 01:57:26 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:26 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:26 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Controller Class Initialized
ERROR - 2011-04-05 01:57:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:57:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:57:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:26 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:26 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:26 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:57:26 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:26 --> Total execution time: 0.1192
DEBUG - 2011-04-05 01:57:27 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:27 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:27 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Controller Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:27 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:28 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:28 --> Total execution time: 0.9841
DEBUG - 2011-04-05 01:57:37 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:37 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:37 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Controller Class Initialized
ERROR - 2011-04-05 01:57:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:57:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:57:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:37 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:37 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:57:37 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:57:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:57:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:57:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:57:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:57:37 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:37 --> Total execution time: 0.0521
DEBUG - 2011-04-05 01:57:38 --> Config Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:57:38 --> URI Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Router Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Output Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Input Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:57:38 --> Language Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Loader Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Controller Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Model Class Initialized
DEBUG - 2011-04-05 01:57:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:57:38 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:57:42 --> Final output sent to browser
DEBUG - 2011-04-05 01:57:42 --> Total execution time: 4.0418
DEBUG - 2011-04-05 01:58:02 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:02 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:02 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:02 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:02 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:02 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:02 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:02 --> Total execution time: 0.0455
DEBUG - 2011-04-05 01:58:03 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:03 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:03 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:03 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:04 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:04 --> Total execution time: 0.7603
DEBUG - 2011-04-05 01:58:13 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:13 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:13 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:13 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:13 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:13 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:13 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:13 --> Total execution time: 0.0289
DEBUG - 2011-04-05 01:58:14 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:14 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:14 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:14 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:15 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:15 --> Total execution time: 0.8808
DEBUG - 2011-04-05 01:58:21 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:21 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:21 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:21 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:21 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:21 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:21 --> Total execution time: 0.0496
DEBUG - 2011-04-05 01:58:21 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:21 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:21 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:22 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:22 --> Total execution time: 1.1009
DEBUG - 2011-04-05 01:58:34 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:34 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:34 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:34 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:34 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:34 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:34 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:34 --> Total execution time: 0.0500
DEBUG - 2011-04-05 01:58:35 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:35 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:35 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:35 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:35 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:35 --> Total execution time: 0.8186
DEBUG - 2011-04-05 01:58:39 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:39 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:39 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:39 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:39 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:39 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:39 --> Total execution time: 0.0361
DEBUG - 2011-04-05 01:58:40 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:40 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:40 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:41 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:41 --> Total execution time: 0.7991
DEBUG - 2011-04-05 01:58:51 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:51 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:51 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:51 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:51 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:51 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:51 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:51 --> Total execution time: 0.0311
DEBUG - 2011-04-05 01:58:52 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:52 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:52 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:52 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:52 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:52 --> Total execution time: 0.8380
DEBUG - 2011-04-05 01:58:58 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:58 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:58 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Controller Class Initialized
ERROR - 2011-04-05 01:58:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:58:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:58:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:58 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:58 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:58:58 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:58:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:58:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:58:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:58:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:58:58 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:58 --> Total execution time: 0.0621
DEBUG - 2011-04-05 01:58:58 --> Config Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:58:58 --> URI Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Router Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Output Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Input Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:58:58 --> Language Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Loader Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Controller Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Model Class Initialized
DEBUG - 2011-04-05 01:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:58:58 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:58:59 --> Final output sent to browser
DEBUG - 2011-04-05 01:58:59 --> Total execution time: 0.8516
DEBUG - 2011-04-05 01:59:07 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:07 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:07 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:07 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:07 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:07 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:07 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:07 --> Total execution time: 0.0640
DEBUG - 2011-04-05 01:59:10 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:10 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:10 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:10 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:10 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:10 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:10 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:10 --> Total execution time: 0.0572
DEBUG - 2011-04-05 01:59:11 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:11 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:11 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Controller Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:11 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:12 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:12 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:12 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:12 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:12 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:12 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:12 --> Total execution time: 0.0463
DEBUG - 2011-04-05 01:59:12 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:12 --> Total execution time: 0.9999
DEBUG - 2011-04-05 01:59:19 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:19 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:19 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:19 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:19 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:19 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:19 --> Total execution time: 0.0293
DEBUG - 2011-04-05 01:59:19 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:19 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:19 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Controller Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:20 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:20 --> Total execution time: 0.7641
DEBUG - 2011-04-05 01:59:28 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:28 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:28 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:28 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:28 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:28 --> Total execution time: 0.0322
DEBUG - 2011-04-05 01:59:29 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:29 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:29 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Controller Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:29 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:30 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:30 --> Total execution time: 1.6573
DEBUG - 2011-04-05 01:59:37 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:37 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:37 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:37 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:37 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:37 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:37 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:37 --> Total execution time: 0.0348
DEBUG - 2011-04-05 01:59:38 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:38 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:38 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Controller Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:38 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:38 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:38 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:38 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:38 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:38 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:38 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:38 --> Total execution time: 0.0327
DEBUG - 2011-04-05 01:59:39 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:39 --> Total execution time: 1.7512
DEBUG - 2011-04-05 01:59:45 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:45 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:45 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:45 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:45 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:45 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:45 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:45 --> Total execution time: 0.0307
DEBUG - 2011-04-05 01:59:46 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:46 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:46 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Controller Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:46 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Config Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 01:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 01:59:47 --> URI Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Router Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Output Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Input Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 01:59:47 --> Language Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Loader Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Controller Class Initialized
ERROR - 2011-04-05 01:59:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 01:59:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 01:59:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:47 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Model Class Initialized
DEBUG - 2011-04-05 01:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 01:59:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 01:59:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 01:59:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 01:59:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 01:59:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 01:59:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 01:59:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 01:59:47 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:47 --> Total execution time: 0.0780
DEBUG - 2011-04-05 01:59:48 --> Final output sent to browser
DEBUG - 2011-04-05 01:59:48 --> Total execution time: 2.6030
DEBUG - 2011-04-05 02:00:03 --> Config Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 02:00:03 --> URI Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Router Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Output Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Input Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 02:00:03 --> Language Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Loader Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Controller Class Initialized
ERROR - 2011-04-05 02:00:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 02:00:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 02:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 02:00:03 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 02:00:03 --> Database Driver Class Initialized
DEBUG - 2011-04-05 02:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 02:00:03 --> Helper loaded: url_helper
DEBUG - 2011-04-05 02:00:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 02:00:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 02:00:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 02:00:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 02:00:03 --> Final output sent to browser
DEBUG - 2011-04-05 02:00:03 --> Total execution time: 0.1688
DEBUG - 2011-04-05 02:00:04 --> Config Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 02:00:04 --> URI Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Router Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Output Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Input Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 02:00:04 --> Language Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Loader Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Controller Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 02:00:04 --> Database Driver Class Initialized
DEBUG - 2011-04-05 02:00:07 --> Final output sent to browser
DEBUG - 2011-04-05 02:00:07 --> Total execution time: 3.6349
DEBUG - 2011-04-05 02:00:46 --> Config Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Hooks Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Utf8 Class Initialized
DEBUG - 2011-04-05 02:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 02:00:46 --> URI Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Router Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Output Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Input Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 02:00:46 --> Language Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Loader Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Controller Class Initialized
ERROR - 2011-04-05 02:00:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 02:00:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 02:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 02:00:46 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 02:00:46 --> Database Driver Class Initialized
DEBUG - 2011-04-05 02:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 02:00:46 --> Helper loaded: url_helper
DEBUG - 2011-04-05 02:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 02:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 02:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 02:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 02:00:46 --> Final output sent to browser
DEBUG - 2011-04-05 02:00:46 --> Total execution time: 0.4482
DEBUG - 2011-04-05 02:00:47 --> Config Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 02:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 02:00:47 --> URI Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Router Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Output Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Input Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 02:00:47 --> Language Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Loader Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Controller Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Model Class Initialized
DEBUG - 2011-04-05 02:00:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 02:00:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 02:00:48 --> Final output sent to browser
DEBUG - 2011-04-05 02:00:48 --> Total execution time: 0.6831
DEBUG - 2011-04-05 02:01:57 --> Config Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 02:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 02:01:57 --> URI Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Router Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Output Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Input Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 02:01:57 --> Language Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Loader Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Controller Class Initialized
ERROR - 2011-04-05 02:01:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 02:01:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 02:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 02:01:57 --> Model Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Model Class Initialized
DEBUG - 2011-04-05 02:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 02:01:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 02:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 02:01:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 02:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 02:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 02:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 02:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 02:01:57 --> Final output sent to browser
DEBUG - 2011-04-05 02:01:57 --> Total execution time: 0.0278
DEBUG - 2011-04-05 02:59:00 --> Config Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Hooks Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Utf8 Class Initialized
DEBUG - 2011-04-05 02:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 02:59:00 --> URI Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Router Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Output Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Input Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 02:59:00 --> Language Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Loader Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Controller Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Model Class Initialized
DEBUG - 2011-04-05 02:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 02:59:00 --> Database Driver Class Initialized
DEBUG - 2011-04-05 02:59:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 02:59:02 --> Helper loaded: url_helper
DEBUG - 2011-04-05 02:59:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 02:59:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 02:59:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 02:59:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 02:59:02 --> Final output sent to browser
DEBUG - 2011-04-05 02:59:02 --> Total execution time: 2.0360
DEBUG - 2011-04-05 03:48:32 --> Config Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Hooks Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Utf8 Class Initialized
DEBUG - 2011-04-05 03:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 03:48:32 --> URI Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Router Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Output Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Input Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 03:48:32 --> Language Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Loader Class Initialized
DEBUG - 2011-04-05 03:48:32 --> Controller Class Initialized
ERROR - 2011-04-05 03:48:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 03:48:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 03:48:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 03:48:32 --> Model Class Initialized
DEBUG - 2011-04-05 03:48:33 --> Model Class Initialized
DEBUG - 2011-04-05 03:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 03:48:33 --> Database Driver Class Initialized
DEBUG - 2011-04-05 03:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 03:48:33 --> Helper loaded: url_helper
DEBUG - 2011-04-05 03:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 03:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 03:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 03:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 03:48:33 --> Final output sent to browser
DEBUG - 2011-04-05 03:48:33 --> Total execution time: 1.2372
DEBUG - 2011-04-05 03:48:35 --> Config Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 03:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 03:48:35 --> URI Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Router Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Output Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Input Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 03:48:35 --> Language Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Loader Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Controller Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Model Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Model Class Initialized
DEBUG - 2011-04-05 03:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 03:48:35 --> Database Driver Class Initialized
DEBUG - 2011-04-05 03:48:36 --> Final output sent to browser
DEBUG - 2011-04-05 03:48:36 --> Total execution time: 1.5109
DEBUG - 2011-04-05 03:48:38 --> Config Class Initialized
DEBUG - 2011-04-05 03:48:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 03:48:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 03:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 03:48:38 --> URI Class Initialized
DEBUG - 2011-04-05 03:48:38 --> Router Class Initialized
ERROR - 2011-04-05 03:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 04:05:14 --> Config Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 04:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 04:05:14 --> URI Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Router Class Initialized
ERROR - 2011-04-05 04:05:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 04:05:14 --> Config Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 04:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 04:05:14 --> URI Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Router Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Output Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Input Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 04:05:14 --> Language Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Loader Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Controller Class Initialized
ERROR - 2011-04-05 04:05:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 04:05:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 04:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 04:05:14 --> Model Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Model Class Initialized
DEBUG - 2011-04-05 04:05:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 04:05:14 --> Database Driver Class Initialized
DEBUG - 2011-04-05 04:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 04:05:15 --> Helper loaded: url_helper
DEBUG - 2011-04-05 04:05:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 04:05:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 04:05:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 04:05:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 04:05:15 --> Final output sent to browser
DEBUG - 2011-04-05 04:05:15 --> Total execution time: 0.6203
DEBUG - 2011-04-05 05:08:02 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:02 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Router Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Output Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Input Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:08:02 --> Language Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Loader Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Controller Class Initialized
ERROR - 2011-04-05 05:08:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 05:08:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 05:08:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:08:02 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:08:02 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:08:03 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:08:03 --> Final output sent to browser
DEBUG - 2011-04-05 05:08:03 --> Total execution time: 0.4976
DEBUG - 2011-04-05 05:08:04 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:04 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Router Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Output Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Input Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:08:04 --> Language Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Loader Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Controller Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:08:04 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:08:07 --> Final output sent to browser
DEBUG - 2011-04-05 05:08:07 --> Total execution time: 3.4549
DEBUG - 2011-04-05 05:08:10 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:10 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:10 --> Router Class Initialized
ERROR - 2011-04-05 05:08:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:08:10 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:10 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:10 --> Router Class Initialized
ERROR - 2011-04-05 05:08:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:08:13 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:13 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:13 --> Router Class Initialized
ERROR - 2011-04-05 05:08:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:08:19 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:19 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Router Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Output Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Input Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:08:19 --> Language Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Loader Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Controller Class Initialized
ERROR - 2011-04-05 05:08:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 05:08:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 05:08:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:08:19 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:08:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:08:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:08:19 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:08:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:08:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:08:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:08:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:08:19 --> Final output sent to browser
DEBUG - 2011-04-05 05:08:19 --> Total execution time: 0.0482
DEBUG - 2011-04-05 05:08:20 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:20 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Router Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Output Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Input Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:08:20 --> Language Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Loader Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Controller Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:08:20 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:08:30 --> Final output sent to browser
DEBUG - 2011-04-05 05:08:30 --> Total execution time: 9.5723
DEBUG - 2011-04-05 05:08:47 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:47 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Router Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Output Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Input Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:08:47 --> Language Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Loader Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Controller Class Initialized
ERROR - 2011-04-05 05:08:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 05:08:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 05:08:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:08:47 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:08:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:08:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:08:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:08:47 --> Final output sent to browser
DEBUG - 2011-04-05 05:08:47 --> Total execution time: 0.0279
DEBUG - 2011-04-05 05:08:48 --> Config Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:08:48 --> URI Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Router Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Output Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Input Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:08:48 --> Language Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Loader Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Controller Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Model Class Initialized
DEBUG - 2011-04-05 05:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:08:48 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:08:51 --> Final output sent to browser
DEBUG - 2011-04-05 05:08:51 --> Total execution time: 2.6969
DEBUG - 2011-04-05 05:09:25 --> Config Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:09:25 --> URI Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Router Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Output Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Input Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:09:25 --> Language Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Loader Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Controller Class Initialized
ERROR - 2011-04-05 05:09:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 05:09:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 05:09:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:09:25 --> Model Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Model Class Initialized
DEBUG - 2011-04-05 05:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:09:25 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:09:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:09:25 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:09:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:09:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:09:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:09:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:09:25 --> Final output sent to browser
DEBUG - 2011-04-05 05:09:25 --> Total execution time: 0.0379
DEBUG - 2011-04-05 05:09:26 --> Config Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:09:26 --> URI Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Router Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Output Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Input Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:09:26 --> Language Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Loader Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Controller Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Model Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Model Class Initialized
DEBUG - 2011-04-05 05:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:09:26 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:09:27 --> Final output sent to browser
DEBUG - 2011-04-05 05:09:27 --> Total execution time: 0.8953
DEBUG - 2011-04-05 05:12:05 --> Config Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:12:05 --> URI Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Router Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Output Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Input Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:12:05 --> Language Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Loader Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Controller Class Initialized
ERROR - 2011-04-05 05:12:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 05:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 05:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:12:05 --> Model Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Model Class Initialized
DEBUG - 2011-04-05 05:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:12:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:12:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:12:05 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:12:05 --> Final output sent to browser
DEBUG - 2011-04-05 05:12:05 --> Total execution time: 0.0743
DEBUG - 2011-04-05 05:19:13 --> Config Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:19:13 --> URI Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Router Class Initialized
DEBUG - 2011-04-05 05:19:13 --> No URI present. Default controller set.
DEBUG - 2011-04-05 05:19:13 --> Output Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Input Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:19:13 --> Language Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Loader Class Initialized
DEBUG - 2011-04-05 05:19:13 --> Controller Class Initialized
DEBUG - 2011-04-05 05:19:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 05:19:13 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:19:13 --> Final output sent to browser
DEBUG - 2011-04-05 05:19:13 --> Total execution time: 0.3696
DEBUG - 2011-04-05 05:19:17 --> Config Class Initialized
DEBUG - 2011-04-05 05:19:17 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:19:17 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:19:17 --> URI Class Initialized
DEBUG - 2011-04-05 05:19:17 --> Router Class Initialized
ERROR - 2011-04-05 05:19:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:19:19 --> Config Class Initialized
DEBUG - 2011-04-05 05:19:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:19:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:19:19 --> URI Class Initialized
DEBUG - 2011-04-05 05:19:19 --> Router Class Initialized
ERROR - 2011-04-05 05:19:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:19:43 --> Config Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:19:43 --> URI Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Router Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Output Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Input Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:19:43 --> Language Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Loader Class Initialized
DEBUG - 2011-04-05 05:19:43 --> Controller Class Initialized
DEBUG - 2011-04-05 05:19:44 --> Model Class Initialized
DEBUG - 2011-04-05 05:19:45 --> Model Class Initialized
DEBUG - 2011-04-05 05:19:46 --> Model Class Initialized
DEBUG - 2011-04-05 05:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:19:49 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:19:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 05:19:56 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:19:56 --> Final output sent to browser
DEBUG - 2011-04-05 05:19:56 --> Total execution time: 13.3312
DEBUG - 2011-04-05 05:20:29 --> Config Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:20:29 --> URI Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Router Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Output Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Input Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:20:29 --> Language Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Loader Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Controller Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Model Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Model Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Model Class Initialized
DEBUG - 2011-04-05 05:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:20:29 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:20:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 05:20:30 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:20:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:20:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:20:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:20:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:20:30 --> Final output sent to browser
DEBUG - 2011-04-05 05:20:30 --> Total execution time: 0.5341
DEBUG - 2011-04-05 05:20:32 --> Config Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:20:32 --> URI Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Router Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Output Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Input Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:20:32 --> Language Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Loader Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Controller Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Model Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Model Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Model Class Initialized
DEBUG - 2011-04-05 05:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:20:32 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 05:20:32 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:20:32 --> Final output sent to browser
DEBUG - 2011-04-05 05:20:32 --> Total execution time: 0.0599
DEBUG - 2011-04-05 05:56:28 --> Config Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:56:28 --> URI Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Router Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Output Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Input Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:56:28 --> Language Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Loader Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Controller Class Initialized
ERROR - 2011-04-05 05:56:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 05:56:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 05:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:56:28 --> Model Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Model Class Initialized
DEBUG - 2011-04-05 05:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:56:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 05:56:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:56:29 --> Final output sent to browser
DEBUG - 2011-04-05 05:56:29 --> Total execution time: 1.2625
DEBUG - 2011-04-05 05:56:30 --> Config Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:56:30 --> URI Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Router Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Output Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Input Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:56:30 --> Language Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Loader Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Controller Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Model Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Model Class Initialized
DEBUG - 2011-04-05 05:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:56:30 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:56:31 --> Final output sent to browser
DEBUG - 2011-04-05 05:56:31 --> Total execution time: 1.1772
DEBUG - 2011-04-05 05:56:32 --> Config Class Initialized
DEBUG - 2011-04-05 05:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:56:32 --> URI Class Initialized
DEBUG - 2011-04-05 05:56:32 --> Router Class Initialized
ERROR - 2011-04-05 05:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:56:33 --> Config Class Initialized
DEBUG - 2011-04-05 05:56:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:56:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:56:33 --> URI Class Initialized
DEBUG - 2011-04-05 05:56:33 --> Router Class Initialized
ERROR - 2011-04-05 05:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 05:57:08 --> Config Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:57:08 --> URI Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Router Class Initialized
DEBUG - 2011-04-05 05:57:08 --> No URI present. Default controller set.
DEBUG - 2011-04-05 05:57:08 --> Output Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Input Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:57:08 --> Language Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Loader Class Initialized
DEBUG - 2011-04-05 05:57:08 --> Controller Class Initialized
DEBUG - 2011-04-05 05:57:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 05:57:08 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:57:08 --> Final output sent to browser
DEBUG - 2011-04-05 05:57:08 --> Total execution time: 0.1275
DEBUG - 2011-04-05 05:57:16 --> Config Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 05:57:16 --> URI Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Router Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Output Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Input Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 05:57:16 --> Language Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Loader Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Controller Class Initialized
DEBUG - 2011-04-05 05:57:16 --> Model Class Initialized
DEBUG - 2011-04-05 05:57:17 --> Model Class Initialized
DEBUG - 2011-04-05 05:57:17 --> Model Class Initialized
DEBUG - 2011-04-05 05:57:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 05:57:17 --> Database Driver Class Initialized
DEBUG - 2011-04-05 05:57:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 05:57:17 --> Helper loaded: url_helper
DEBUG - 2011-04-05 05:57:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 05:57:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 05:57:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 05:57:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 05:57:17 --> Final output sent to browser
DEBUG - 2011-04-05 05:57:17 --> Total execution time: 1.2047
DEBUG - 2011-04-05 06:04:41 --> Config Class Initialized
DEBUG - 2011-04-05 06:04:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:04:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:04:41 --> URI Class Initialized
DEBUG - 2011-04-05 06:04:41 --> Router Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Output Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Input Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:04:42 --> Language Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Loader Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Controller Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Model Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Model Class Initialized
DEBUG - 2011-04-05 06:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:04:42 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:04:44 --> Final output sent to browser
DEBUG - 2011-04-05 06:04:44 --> Total execution time: 3.7466
DEBUG - 2011-04-05 06:11:33 --> Config Class Initialized
DEBUG - 2011-04-05 06:11:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:11:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:11:33 --> URI Class Initialized
DEBUG - 2011-04-05 06:11:33 --> Router Class Initialized
DEBUG - 2011-04-05 06:11:34 --> Output Class Initialized
DEBUG - 2011-04-05 06:11:34 --> Input Class Initialized
DEBUG - 2011-04-05 06:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:11:34 --> Language Class Initialized
DEBUG - 2011-04-05 06:11:35 --> Loader Class Initialized
DEBUG - 2011-04-05 06:11:35 --> Controller Class Initialized
DEBUG - 2011-04-05 06:11:36 --> Model Class Initialized
DEBUG - 2011-04-05 06:11:36 --> Model Class Initialized
DEBUG - 2011-04-05 06:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:11:36 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:11:37 --> Final output sent to browser
DEBUG - 2011-04-05 06:11:37 --> Total execution time: 6.9174
DEBUG - 2011-04-05 06:20:38 --> Config Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:20:38 --> URI Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Router Class Initialized
DEBUG - 2011-04-05 06:20:38 --> No URI present. Default controller set.
DEBUG - 2011-04-05 06:20:38 --> Output Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Input Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:20:38 --> Language Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Loader Class Initialized
DEBUG - 2011-04-05 06:20:38 --> Controller Class Initialized
DEBUG - 2011-04-05 06:20:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 06:20:38 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:20:38 --> Final output sent to browser
DEBUG - 2011-04-05 06:20:38 --> Total execution time: 0.2350
DEBUG - 2011-04-05 06:20:41 --> Config Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:20:41 --> URI Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Router Class Initialized
DEBUG - 2011-04-05 06:20:41 --> No URI present. Default controller set.
DEBUG - 2011-04-05 06:20:41 --> Output Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Input Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:20:41 --> Language Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Loader Class Initialized
DEBUG - 2011-04-05 06:20:41 --> Controller Class Initialized
DEBUG - 2011-04-05 06:20:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 06:20:41 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:20:41 --> Final output sent to browser
DEBUG - 2011-04-05 06:20:41 --> Total execution time: 0.0148
DEBUG - 2011-04-05 06:37:06 --> Config Class Initialized
DEBUG - 2011-04-05 06:37:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:37:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:37:06 --> URI Class Initialized
DEBUG - 2011-04-05 06:37:06 --> Router Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Output Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Input Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:37:07 --> Language Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Loader Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Controller Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Model Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Model Class Initialized
DEBUG - 2011-04-05 06:37:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:37:07 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:37:08 --> Final output sent to browser
DEBUG - 2011-04-05 06:37:08 --> Total execution time: 1.7122
DEBUG - 2011-04-05 06:43:20 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:20 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:20 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:20 --> Controller Class Initialized
ERROR - 2011-04-05 06:43:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:43:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:43:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:21 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:21 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:21 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:21 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:21 --> Total execution time: 1.7246
DEBUG - 2011-04-05 06:43:24 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:24 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:24 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Controller Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:24 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:25 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:25 --> Total execution time: 0.8309
DEBUG - 2011-04-05 06:43:26 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:26 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:26 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:26 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:26 --> Router Class Initialized
ERROR - 2011-04-05 06:43:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 06:43:34 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:34 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:34 --> No URI present. Default controller set.
DEBUG - 2011-04-05 06:43:34 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:34 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:34 --> Controller Class Initialized
DEBUG - 2011-04-05 06:43:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 06:43:34 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:34 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:34 --> Total execution time: 0.2191
DEBUG - 2011-04-05 06:43:36 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:36 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:36 --> Router Class Initialized
ERROR - 2011-04-05 06:43:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 06:43:38 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:39 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:39 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Controller Class Initialized
ERROR - 2011-04-05 06:43:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:43:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:43:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:39 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:39 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:39 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:39 --> Total execution time: 0.1554
DEBUG - 2011-04-05 06:43:39 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:39 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:39 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Controller Class Initialized
DEBUG - 2011-04-05 06:43:39 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:40 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:41 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:41 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Controller Class Initialized
ERROR - 2011-04-05 06:43:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:43:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:41 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:41 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:41 --> Total execution time: 1.1239
DEBUG - 2011-04-05 06:43:41 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:41 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:41 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:41 --> Total execution time: 0.0854
DEBUG - 2011-04-05 06:43:41 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:41 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:41 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Controller Class Initialized
ERROR - 2011-04-05 06:43:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:43:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:41 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:41 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:41 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:41 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:41 --> Total execution time: 0.0712
DEBUG - 2011-04-05 06:43:41 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:41 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:41 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Controller Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:41 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:42 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:42 --> Total execution time: 0.6779
DEBUG - 2011-04-05 06:43:43 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:43 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:43 --> Router Class Initialized
ERROR - 2011-04-05 06:43:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 06:43:45 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:45 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:45 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Controller Class Initialized
ERROR - 2011-04-05 06:43:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:43:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:43:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:45 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:45 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:45 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:45 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:45 --> Total execution time: 0.0327
DEBUG - 2011-04-05 06:43:46 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:46 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:46 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Controller Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:46 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:46 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:46 --> Total execution time: 0.6627
DEBUG - 2011-04-05 06:43:47 --> Config Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:43:47 --> URI Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Router Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Output Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Input Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:43:47 --> Language Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Loader Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Controller Class Initialized
ERROR - 2011-04-05 06:43:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:43:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:43:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:47 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Model Class Initialized
DEBUG - 2011-04-05 06:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:43:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:43:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:43:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:43:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:43:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:43:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:43:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:43:47 --> Final output sent to browser
DEBUG - 2011-04-05 06:43:47 --> Total execution time: 0.0695
DEBUG - 2011-04-05 06:44:35 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:35 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:35 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Controller Class Initialized
ERROR - 2011-04-05 06:44:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:44:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:44:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:35 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:35 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:35 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:44:35 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:35 --> Total execution time: 0.2831
DEBUG - 2011-04-05 06:44:36 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:36 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:36 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Controller Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:36 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:39 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:39 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Controller Class Initialized
ERROR - 2011-04-05 06:44:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:44:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:44:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:39 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:39 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:44:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:44:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:44:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:44:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:44:39 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:39 --> Total execution time: 0.0374
DEBUG - 2011-04-05 06:44:40 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:40 --> Total execution time: 4.1688
DEBUG - 2011-04-05 06:44:49 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:49 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:49 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Controller Class Initialized
ERROR - 2011-04-05 06:44:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:44:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:49 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:49 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:49 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:44:49 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:49 --> Total execution time: 0.0291
DEBUG - 2011-04-05 06:44:49 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:49 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:49 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Controller Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:49 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:51 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:51 --> Total execution time: 1.3843
DEBUG - 2011-04-05 06:44:52 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:52 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:52 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Controller Class Initialized
ERROR - 2011-04-05 06:44:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:44:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:52 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:52 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:52 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:44:52 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:52 --> Total execution time: 0.0525
DEBUG - 2011-04-05 06:44:57 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:57 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:57 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Controller Class Initialized
ERROR - 2011-04-05 06:44:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:44:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:57 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:44:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 06:44:57 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:57 --> Total execution time: 0.1207
DEBUG - 2011-04-05 06:44:57 --> Config Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:44:57 --> URI Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Router Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Output Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Input Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:44:57 --> Language Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Loader Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Controller Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Model Class Initialized
DEBUG - 2011-04-05 06:44:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:44:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:44:59 --> Final output sent to browser
DEBUG - 2011-04-05 06:44:59 --> Total execution time: 1.6885
DEBUG - 2011-04-05 06:46:11 --> Config Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 06:46:11 --> URI Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Router Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Output Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Input Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 06:46:11 --> Language Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Loader Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Controller Class Initialized
ERROR - 2011-04-05 06:46:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 06:46:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 06:46:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:46:11 --> Model Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Model Class Initialized
DEBUG - 2011-04-05 06:46:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 06:46:11 --> Database Driver Class Initialized
DEBUG - 2011-04-05 06:46:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 06:46:11 --> Helper loaded: url_helper
DEBUG - 2011-04-05 06:46:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 06:46:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 06:46:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 06:46:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:00:44 --> Config Class Initialized
DEBUG - 2011-04-05 07:00:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:00:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:00:44 --> URI Class Initialized
DEBUG - 2011-04-05 07:00:44 --> Router Class Initialized
DEBUG - 2011-04-05 07:00:44 --> Output Class Initialized
DEBUG - 2011-04-05 07:00:44 --> Input Class Initialized
DEBUG - 2011-04-05 07:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:00:44 --> Language Class Initialized
DEBUG - 2011-04-05 07:00:45 --> Loader Class Initialized
DEBUG - 2011-04-05 07:00:45 --> Controller Class Initialized
ERROR - 2011-04-05 07:00:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 07:00:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 07:00:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:00:45 --> Model Class Initialized
DEBUG - 2011-04-05 07:00:45 --> Model Class Initialized
DEBUG - 2011-04-05 07:00:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:00:45 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:00:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:00:46 --> Helper loaded: url_helper
DEBUG - 2011-04-05 07:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 07:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 07:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 07:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:00:46 --> Final output sent to browser
DEBUG - 2011-04-05 07:00:46 --> Total execution time: 1.6749
DEBUG - 2011-04-05 07:42:16 --> Config Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:42:16 --> URI Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Router Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Output Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Input Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:42:16 --> Language Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Loader Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Controller Class Initialized
ERROR - 2011-04-05 07:42:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 07:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 07:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:42:16 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:42:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:42:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:42:16 --> Helper loaded: url_helper
DEBUG - 2011-04-05 07:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 07:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 07:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 07:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:42:16 --> Final output sent to browser
DEBUG - 2011-04-05 07:42:16 --> Total execution time: 0.5997
DEBUG - 2011-04-05 07:42:17 --> Config Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:42:17 --> URI Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Router Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Output Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Input Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:42:17 --> Language Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Loader Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Controller Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:42:17 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:42:18 --> Final output sent to browser
DEBUG - 2011-04-05 07:42:18 --> Total execution time: 0.9059
DEBUG - 2011-04-05 07:42:47 --> Config Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:42:47 --> URI Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Router Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Output Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Input Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:42:47 --> Language Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Loader Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Controller Class Initialized
ERROR - 2011-04-05 07:42:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 07:42:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 07:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:42:47 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:42:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:42:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 07:42:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 07:42:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 07:42:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 07:42:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:42:47 --> Final output sent to browser
DEBUG - 2011-04-05 07:42:47 --> Total execution time: 0.2563
DEBUG - 2011-04-05 07:42:48 --> Config Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:42:48 --> URI Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Router Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Output Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Input Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:42:48 --> Language Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Loader Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Controller Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Model Class Initialized
DEBUG - 2011-04-05 07:42:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:42:48 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:42:49 --> Final output sent to browser
DEBUG - 2011-04-05 07:42:49 --> Total execution time: 1.5993
DEBUG - 2011-04-05 07:55:49 --> Config Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:55:49 --> URI Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Router Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Output Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Input Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:55:49 --> Language Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Loader Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Controller Class Initialized
ERROR - 2011-04-05 07:55:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 07:55:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 07:55:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:55:49 --> Model Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Model Class Initialized
DEBUG - 2011-04-05 07:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:55:49 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:55:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:55:50 --> Helper loaded: url_helper
DEBUG - 2011-04-05 07:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 07:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 07:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 07:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:55:50 --> Final output sent to browser
DEBUG - 2011-04-05 07:55:50 --> Total execution time: 0.4949
DEBUG - 2011-04-05 07:55:53 --> Config Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:55:53 --> URI Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Router Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Output Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Input Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:55:53 --> Language Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Loader Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Controller Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Model Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Model Class Initialized
DEBUG - 2011-04-05 07:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:55:53 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:55:55 --> Final output sent to browser
DEBUG - 2011-04-05 07:55:55 --> Total execution time: 1.6428
DEBUG - 2011-04-05 07:56:14 --> Config Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:56:14 --> URI Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Router Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Output Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Input Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:56:14 --> Language Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Loader Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Controller Class Initialized
ERROR - 2011-04-05 07:56:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 07:56:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 07:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:56:14 --> Model Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Model Class Initialized
DEBUG - 2011-04-05 07:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:56:14 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:56:14 --> Helper loaded: url_helper
DEBUG - 2011-04-05 07:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 07:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 07:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 07:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:56:14 --> Final output sent to browser
DEBUG - 2011-04-05 07:56:14 --> Total execution time: 0.0413
DEBUG - 2011-04-05 07:57:10 --> Config Class Initialized
DEBUG - 2011-04-05 07:57:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 07:57:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 07:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 07:57:10 --> URI Class Initialized
DEBUG - 2011-04-05 07:57:10 --> Router Class Initialized
DEBUG - 2011-04-05 07:57:10 --> Output Class Initialized
DEBUG - 2011-04-05 07:57:10 --> Input Class Initialized
DEBUG - 2011-04-05 07:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 07:57:11 --> Language Class Initialized
DEBUG - 2011-04-05 07:57:11 --> Loader Class Initialized
DEBUG - 2011-04-05 07:57:11 --> Controller Class Initialized
ERROR - 2011-04-05 07:57:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 07:57:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 07:57:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:57:11 --> Model Class Initialized
DEBUG - 2011-04-05 07:57:11 --> Model Class Initialized
DEBUG - 2011-04-05 07:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 07:57:11 --> Database Driver Class Initialized
DEBUG - 2011-04-05 07:57:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 07:57:11 --> Helper loaded: url_helper
DEBUG - 2011-04-05 07:57:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 07:57:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 07:57:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 07:57:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 07:57:11 --> Final output sent to browser
DEBUG - 2011-04-05 07:57:11 --> Total execution time: 0.0294
DEBUG - 2011-04-05 08:05:49 --> Config Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:05:49 --> URI Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Router Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Output Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Input Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 08:05:49 --> Language Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Loader Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Controller Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Model Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Model Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Model Class Initialized
DEBUG - 2011-04-05 08:05:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 08:05:49 --> Database Driver Class Initialized
DEBUG - 2011-04-05 08:05:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 08:05:50 --> Helper loaded: url_helper
DEBUG - 2011-04-05 08:05:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 08:05:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 08:05:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 08:05:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 08:05:50 --> Final output sent to browser
DEBUG - 2011-04-05 08:05:50 --> Total execution time: 1.1316
DEBUG - 2011-04-05 08:14:03 --> Config Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:14:03 --> URI Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Router Class Initialized
DEBUG - 2011-04-05 08:14:03 --> No URI present. Default controller set.
DEBUG - 2011-04-05 08:14:03 --> Output Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Input Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 08:14:03 --> Language Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Loader Class Initialized
DEBUG - 2011-04-05 08:14:03 --> Controller Class Initialized
DEBUG - 2011-04-05 08:14:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 08:14:04 --> Helper loaded: url_helper
DEBUG - 2011-04-05 08:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 08:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 08:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 08:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 08:14:04 --> Final output sent to browser
DEBUG - 2011-04-05 08:14:04 --> Total execution time: 0.2642
DEBUG - 2011-04-05 08:14:13 --> Config Class Initialized
DEBUG - 2011-04-05 08:14:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:14:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:14:13 --> URI Class Initialized
DEBUG - 2011-04-05 08:14:13 --> Router Class Initialized
ERROR - 2011-04-05 08:14:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 08:14:28 --> Config Class Initialized
DEBUG - 2011-04-05 08:14:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:14:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:14:28 --> URI Class Initialized
DEBUG - 2011-04-05 08:14:28 --> Router Class Initialized
ERROR - 2011-04-05 08:14:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 08:14:32 --> Config Class Initialized
DEBUG - 2011-04-05 08:14:32 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:14:32 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:14:32 --> URI Class Initialized
DEBUG - 2011-04-05 08:14:32 --> Router Class Initialized
ERROR - 2011-04-05 08:14:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 08:14:35 --> Config Class Initialized
DEBUG - 2011-04-05 08:14:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:14:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:14:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:14:35 --> URI Class Initialized
DEBUG - 2011-04-05 08:14:35 --> Router Class Initialized
ERROR - 2011-04-05 08:14:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 08:30:14 --> Config Class Initialized
DEBUG - 2011-04-05 08:30:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 08:30:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 08:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 08:30:14 --> URI Class Initialized
DEBUG - 2011-04-05 08:30:14 --> Router Class Initialized
ERROR - 2011-04-05 08:30:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 09:04:17 --> Config Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Hooks Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Utf8 Class Initialized
DEBUG - 2011-04-05 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 09:04:17 --> URI Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Router Class Initialized
DEBUG - 2011-04-05 09:04:17 --> No URI present. Default controller set.
DEBUG - 2011-04-05 09:04:17 --> Output Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Input Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 09:04:17 --> Language Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Loader Class Initialized
DEBUG - 2011-04-05 09:04:17 --> Controller Class Initialized
DEBUG - 2011-04-05 09:04:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 09:04:18 --> Helper loaded: url_helper
DEBUG - 2011-04-05 09:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 09:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 09:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 09:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 09:04:18 --> Final output sent to browser
DEBUG - 2011-04-05 09:04:18 --> Total execution time: 0.2782
DEBUG - 2011-04-05 09:22:09 --> Config Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 09:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 09:22:09 --> URI Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Router Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Output Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Input Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 09:22:09 --> Language Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Loader Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Controller Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Model Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Model Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Model Class Initialized
DEBUG - 2011-04-05 09:22:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 09:22:09 --> Database Driver Class Initialized
DEBUG - 2011-04-05 09:22:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 09:22:18 --> Helper loaded: url_helper
DEBUG - 2011-04-05 09:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 09:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 09:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 09:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 09:22:18 --> Final output sent to browser
DEBUG - 2011-04-05 09:22:18 --> Total execution time: 9.2707
DEBUG - 2011-04-05 09:33:56 --> Config Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Hooks Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Utf8 Class Initialized
DEBUG - 2011-04-05 09:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 09:33:56 --> URI Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Router Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Output Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Input Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 09:33:56 --> Language Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Loader Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Controller Class Initialized
ERROR - 2011-04-05 09:33:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 09:33:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 09:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 09:33:56 --> Model Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Model Class Initialized
DEBUG - 2011-04-05 09:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 09:33:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 09:33:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 09:33:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 09:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 09:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 09:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 09:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 09:33:57 --> Final output sent to browser
DEBUG - 2011-04-05 09:33:57 --> Total execution time: 0.4555
DEBUG - 2011-04-05 10:26:14 --> Config Class Initialized
DEBUG - 2011-04-05 10:26:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 10:26:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 10:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 10:26:16 --> URI Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Router Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Output Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Input Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 10:26:16 --> Language Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Loader Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Controller Class Initialized
ERROR - 2011-04-05 10:26:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 10:26:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 10:26:16 --> Model Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Model Class Initialized
DEBUG - 2011-04-05 10:26:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 10:26:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 10:26:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 10:26:17 --> Helper loaded: url_helper
DEBUG - 2011-04-05 10:26:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 10:26:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 10:26:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 10:26:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 10:26:17 --> Final output sent to browser
DEBUG - 2011-04-05 10:26:17 --> Total execution time: 2.5638
DEBUG - 2011-04-05 10:57:44 --> Config Class Initialized
DEBUG - 2011-04-05 10:57:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 10:57:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 10:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 10:57:44 --> URI Class Initialized
DEBUG - 2011-04-05 10:57:44 --> Router Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Output Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Input Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 10:57:45 --> Language Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Loader Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Controller Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Model Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Model Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Model Class Initialized
DEBUG - 2011-04-05 10:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 10:57:45 --> Database Driver Class Initialized
ERROR - 2011-04-05 10:57:45 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-04-05 10:57:45 --> Unable to connect to the database
DEBUG - 2011-04-05 10:57:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-04-05 10:57:56 --> Config Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Hooks Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Utf8 Class Initialized
DEBUG - 2011-04-05 10:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 10:57:56 --> URI Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Router Class Initialized
DEBUG - 2011-04-05 10:57:56 --> No URI present. Default controller set.
DEBUG - 2011-04-05 10:57:56 --> Output Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Input Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 10:57:56 --> Language Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Loader Class Initialized
DEBUG - 2011-04-05 10:57:56 --> Controller Class Initialized
DEBUG - 2011-04-05 10:57:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 10:57:56 --> Helper loaded: url_helper
DEBUG - 2011-04-05 10:57:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 10:57:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 10:57:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 10:57:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 10:57:56 --> Final output sent to browser
DEBUG - 2011-04-05 10:57:56 --> Total execution time: 0.3778
DEBUG - 2011-04-05 10:58:02 --> Config Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Hooks Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Utf8 Class Initialized
DEBUG - 2011-04-05 10:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 10:58:02 --> URI Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Router Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Output Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Input Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 10:58:02 --> Language Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Loader Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Controller Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Model Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Model Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Model Class Initialized
DEBUG - 2011-04-05 10:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 10:58:02 --> Database Driver Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Config Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Hooks Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Utf8 Class Initialized
DEBUG - 2011-04-05 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 10:58:26 --> URI Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Router Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Output Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Input Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 10:58:26 --> Language Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Loader Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Controller Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Model Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Model Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Model Class Initialized
DEBUG - 2011-04-05 10:58:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 10:58:26 --> Database Driver Class Initialized
ERROR - 2011-04-05 10:58:26 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-04-05 10:58:26 --> Unable to connect to the database
DEBUG - 2011-04-05 10:58:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-04-05 11:07:53 --> DB Transaction Failure
ERROR - 2011-04-05 11:07:53 --> Query error: Query execution was interrupted
DEBUG - 2011-04-05 11:07:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-04-05 11:24:23 --> Config Class Initialized
DEBUG - 2011-04-05 11:24:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:24:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:24:23 --> URI Class Initialized
DEBUG - 2011-04-05 11:24:23 --> Router Class Initialized
DEBUG - 2011-04-05 11:24:23 --> Output Class Initialized
DEBUG - 2011-04-05 11:24:23 --> Input Class Initialized
DEBUG - 2011-04-05 11:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 11:24:23 --> Language Class Initialized
DEBUG - 2011-04-05 11:24:24 --> Loader Class Initialized
DEBUG - 2011-04-05 11:24:24 --> Controller Class Initialized
ERROR - 2011-04-05 11:24:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 11:24:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 11:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 11:24:24 --> Model Class Initialized
DEBUG - 2011-04-05 11:24:24 --> Model Class Initialized
DEBUG - 2011-04-05 11:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 11:24:24 --> Database Driver Class Initialized
ERROR - 2011-04-05 11:24:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-04-05 11:24:24 --> Unable to connect to the database
DEBUG - 2011-04-05 11:24:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-04-05 11:24:25 --> Config Class Initialized
DEBUG - 2011-04-05 11:24:25 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:24:25 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:24:25 --> URI Class Initialized
DEBUG - 2011-04-05 11:24:25 --> Router Class Initialized
ERROR - 2011-04-05 11:24:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 11:31:03 --> Config Class Initialized
DEBUG - 2011-04-05 11:31:04 --> Config Class Initialized
DEBUG - 2011-04-05 11:31:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:31:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:31:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:31:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:31:06 --> URI Class Initialized
DEBUG - 2011-04-05 11:31:06 --> URI Class Initialized
DEBUG - 2011-04-05 11:31:06 --> Router Class Initialized
DEBUG - 2011-04-05 11:31:06 --> Router Class Initialized
DEBUG - 2011-04-05 11:31:07 --> Output Class Initialized
DEBUG - 2011-04-05 11:31:07 --> Output Class Initialized
DEBUG - 2011-04-05 11:31:08 --> Input Class Initialized
DEBUG - 2011-04-05 11:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 11:31:08 --> Input Class Initialized
DEBUG - 2011-04-05 11:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 11:31:08 --> Language Class Initialized
DEBUG - 2011-04-05 11:31:08 --> Language Class Initialized
DEBUG - 2011-04-05 11:31:09 --> Loader Class Initialized
DEBUG - 2011-04-05 11:31:09 --> Loader Class Initialized
DEBUG - 2011-04-05 11:31:09 --> Controller Class Initialized
DEBUG - 2011-04-05 11:31:09 --> Controller Class Initialized
ERROR - 2011-04-05 11:31:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 11:31:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 11:31:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 11:31:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 11:31:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 11:31:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 11:31:13 --> Model Class Initialized
DEBUG - 2011-04-05 11:31:13 --> Model Class Initialized
DEBUG - 2011-04-05 11:31:13 --> Model Class Initialized
DEBUG - 2011-04-05 11:31:13 --> Model Class Initialized
DEBUG - 2011-04-05 11:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 11:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 11:51:34 --> Config Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:51:34 --> URI Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Router Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Output Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Input Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 11:51:34 --> Language Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Loader Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Controller Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Model Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Model Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Model Class Initialized
DEBUG - 2011-04-05 11:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 11:51:35 --> Database Driver Class Initialized
DEBUG - 2011-04-05 11:51:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 11:51:36 --> Helper loaded: url_helper
DEBUG - 2011-04-05 11:51:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 11:51:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 11:51:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 11:51:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 11:51:36 --> Final output sent to browser
DEBUG - 2011-04-05 11:51:36 --> Total execution time: 2.0403
DEBUG - 2011-04-05 11:51:39 --> Config Class Initialized
DEBUG - 2011-04-05 11:51:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:51:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:51:39 --> URI Class Initialized
DEBUG - 2011-04-05 11:51:39 --> Router Class Initialized
ERROR - 2011-04-05 11:51:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 11:51:41 --> Config Class Initialized
DEBUG - 2011-04-05 11:51:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:51:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:51:41 --> URI Class Initialized
DEBUG - 2011-04-05 11:51:41 --> Router Class Initialized
ERROR - 2011-04-05 11:51:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 11:52:07 --> Config Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:52:07 --> URI Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Router Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Output Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Input Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 11:52:07 --> Language Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Loader Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Controller Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Model Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Model Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Model Class Initialized
DEBUG - 2011-04-05 11:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 11:52:07 --> Database Driver Class Initialized
DEBUG - 2011-04-05 11:52:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 11:52:07 --> Helper loaded: url_helper
DEBUG - 2011-04-05 11:52:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 11:52:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 11:52:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 11:52:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 11:52:07 --> Final output sent to browser
DEBUG - 2011-04-05 11:52:07 --> Total execution time: 0.2048
DEBUG - 2011-04-05 11:52:10 --> Config Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:52:10 --> URI Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Router Class Initialized
ERROR - 2011-04-05 11:52:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 11:52:10 --> Config Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 11:52:10 --> URI Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Router Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Output Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Input Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 11:52:10 --> Language Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Loader Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Controller Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Model Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Model Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Model Class Initialized
DEBUG - 2011-04-05 11:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 11:52:10 --> Database Driver Class Initialized
DEBUG - 2011-04-05 11:52:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 11:52:10 --> Helper loaded: url_helper
DEBUG - 2011-04-05 11:52:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 11:52:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 11:52:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 11:52:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 11:52:10 --> Final output sent to browser
DEBUG - 2011-04-05 11:52:10 --> Total execution time: 0.0457
DEBUG - 2011-04-05 12:15:25 --> Config Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:15:25 --> URI Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Router Class Initialized
DEBUG - 2011-04-05 12:15:25 --> No URI present. Default controller set.
DEBUG - 2011-04-05 12:15:25 --> Output Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Input Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:15:25 --> Language Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Loader Class Initialized
DEBUG - 2011-04-05 12:15:25 --> Controller Class Initialized
DEBUG - 2011-04-05 12:15:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 12:15:25 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:15:25 --> Final output sent to browser
DEBUG - 2011-04-05 12:15:25 --> Total execution time: 0.5797
DEBUG - 2011-04-05 12:15:36 --> Config Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:15:36 --> URI Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Router Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Output Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Input Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:15:36 --> Language Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Loader Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Controller Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Model Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Model Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Model Class Initialized
DEBUG - 2011-04-05 12:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:15:37 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:15:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:15:37 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:15:37 --> Final output sent to browser
DEBUG - 2011-04-05 12:15:37 --> Total execution time: 0.5673
DEBUG - 2011-04-05 12:16:08 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:08 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:08 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:08 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:09 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:09 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:09 --> Total execution time: 0.9572
DEBUG - 2011-04-05 12:16:10 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:10 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:10 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:10 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:10 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:10 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:10 --> Total execution time: 0.0458
DEBUG - 2011-04-05 12:16:10 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:10 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:10 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:10 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:10 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:10 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:10 --> Total execution time: 0.0710
DEBUG - 2011-04-05 12:16:29 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:29 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:29 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:29 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:29 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:29 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:29 --> Total execution time: 0.5489
DEBUG - 2011-04-05 12:16:36 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:36 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:36 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:36 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:36 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:36 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:36 --> Total execution time: 0.1534
DEBUG - 2011-04-05 12:16:44 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:44 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:44 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:45 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:45 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:45 --> Total execution time: 1.4502
DEBUG - 2011-04-05 12:16:48 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:48 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:48 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:48 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:48 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:48 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:48 --> Total execution time: 0.0913
DEBUG - 2011-04-05 12:16:58 --> Config Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:16:58 --> URI Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Router Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Output Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Input Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:16:58 --> Language Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Loader Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Controller Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Model Class Initialized
DEBUG - 2011-04-05 12:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:16:58 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:16:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:16:58 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:16:58 --> Final output sent to browser
DEBUG - 2011-04-05 12:16:58 --> Total execution time: 0.2248
DEBUG - 2011-04-05 12:17:04 --> Config Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:17:04 --> URI Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Router Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Output Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Input Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:17:04 --> Language Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Loader Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Controller Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:17:04 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:17:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:17:04 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:17:04 --> Final output sent to browser
DEBUG - 2011-04-05 12:17:04 --> Total execution time: 0.0681
DEBUG - 2011-04-05 12:17:31 --> Config Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:17:31 --> URI Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Router Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Output Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Input Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:17:31 --> Language Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Loader Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Controller Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:17:31 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:17:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:17:32 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:17:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:17:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:17:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:17:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:17:32 --> Final output sent to browser
DEBUG - 2011-04-05 12:17:32 --> Total execution time: 1.1003
DEBUG - 2011-04-05 12:17:34 --> Config Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:17:34 --> URI Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Router Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Output Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Input Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:17:34 --> Language Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Loader Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Controller Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:17:34 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:17:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:17:34 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:17:34 --> Final output sent to browser
DEBUG - 2011-04-05 12:17:34 --> Total execution time: 0.1784
DEBUG - 2011-04-05 12:17:44 --> Config Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:17:44 --> URI Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Router Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Output Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Input Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:17:44 --> Language Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Loader Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Controller Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:17:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:17:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:17:45 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:17:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:17:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:17:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:17:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:17:45 --> Final output sent to browser
DEBUG - 2011-04-05 12:17:45 --> Total execution time: 1.3575
DEBUG - 2011-04-05 12:17:47 --> Config Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:17:47 --> URI Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Router Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Output Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Input Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:17:47 --> Language Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Loader Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Controller Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Model Class Initialized
DEBUG - 2011-04-05 12:17:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:17:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:17:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:17:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:17:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:17:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:17:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:17:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:17:47 --> Final output sent to browser
DEBUG - 2011-04-05 12:17:47 --> Total execution time: 0.1714
DEBUG - 2011-04-05 12:18:04 --> Config Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:18:05 --> URI Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Router Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Output Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Input Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:18:05 --> Language Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Loader Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Controller Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Model Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Model Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Model Class Initialized
DEBUG - 2011-04-05 12:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:18:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:18:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:18:05 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:18:05 --> Final output sent to browser
DEBUG - 2011-04-05 12:18:05 --> Total execution time: 0.7420
DEBUG - 2011-04-05 12:18:08 --> Config Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:18:08 --> URI Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Router Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Output Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Input Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:18:08 --> Language Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Loader Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Controller Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Model Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Model Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Model Class Initialized
DEBUG - 2011-04-05 12:18:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:18:08 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:18:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:18:08 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:18:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:18:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:18:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:18:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:18:08 --> Final output sent to browser
DEBUG - 2011-04-05 12:18:08 --> Total execution time: 0.1134
DEBUG - 2011-04-05 12:26:14 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:14 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Router Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Output Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Input Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:26:14 --> Language Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Loader Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Controller Class Initialized
ERROR - 2011-04-05 12:26:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:26:14 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:26:14 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:26:14 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:26:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:26:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:26:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:26:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:26:14 --> Final output sent to browser
DEBUG - 2011-04-05 12:26:14 --> Total execution time: 0.7565
DEBUG - 2011-04-05 12:26:15 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:15 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Router Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Output Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Input Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:26:15 --> Language Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Loader Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Controller Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:26:15 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:26:16 --> Final output sent to browser
DEBUG - 2011-04-05 12:26:16 --> Total execution time: 0.8112
DEBUG - 2011-04-05 12:26:17 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:17 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:17 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:17 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:17 --> Router Class Initialized
ERROR - 2011-04-05 12:26:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:26:18 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:18 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:18 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:18 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:18 --> Router Class Initialized
ERROR - 2011-04-05 12:26:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:26:18 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:18 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:18 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:18 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:18 --> Router Class Initialized
ERROR - 2011-04-05 12:26:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:26:28 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:28 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Router Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Output Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Input Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:26:28 --> Language Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Loader Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Controller Class Initialized
ERROR - 2011-04-05 12:26:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:26:28 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:26:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:26:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:26:28 --> Final output sent to browser
DEBUG - 2011-04-05 12:26:28 --> Total execution time: 0.0853
DEBUG - 2011-04-05 12:26:29 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:29 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Router Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Output Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Input Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:26:29 --> Language Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Loader Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Controller Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:26:29 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:26:30 --> Final output sent to browser
DEBUG - 2011-04-05 12:26:30 --> Total execution time: 1.6659
DEBUG - 2011-04-05 12:26:41 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:41 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Router Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Output Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Input Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:26:41 --> Language Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Loader Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Controller Class Initialized
ERROR - 2011-04-05 12:26:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:26:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:26:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:26:41 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:26:41 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:26:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:26:41 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:26:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:26:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:26:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:26:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:26:41 --> Final output sent to browser
DEBUG - 2011-04-05 12:26:41 --> Total execution time: 0.0298
DEBUG - 2011-04-05 12:26:42 --> Config Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:26:42 --> URI Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Router Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Output Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Input Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:26:42 --> Language Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Loader Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Controller Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Model Class Initialized
DEBUG - 2011-04-05 12:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:26:42 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:26:43 --> Final output sent to browser
DEBUG - 2011-04-05 12:26:43 --> Total execution time: 1.0841
DEBUG - 2011-04-05 12:38:20 --> Config Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:38:20 --> URI Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Router Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Output Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Input Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:38:20 --> Language Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Loader Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Controller Class Initialized
ERROR - 2011-04-05 12:38:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:38:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:38:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:38:20 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:38:20 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:38:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:38:20 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:38:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:38:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:38:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:38:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:38:20 --> Final output sent to browser
DEBUG - 2011-04-05 12:38:20 --> Total execution time: 0.0805
DEBUG - 2011-04-05 12:38:22 --> Config Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:38:22 --> URI Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Router Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Output Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Input Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:38:22 --> Language Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Loader Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Controller Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:38:22 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:38:22 --> Final output sent to browser
DEBUG - 2011-04-05 12:38:22 --> Total execution time: 0.7324
DEBUG - 2011-04-05 12:38:24 --> Config Class Initialized
DEBUG - 2011-04-05 12:38:24 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:38:24 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:38:24 --> URI Class Initialized
DEBUG - 2011-04-05 12:38:24 --> Router Class Initialized
ERROR - 2011-04-05 12:38:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:38:31 --> Config Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:38:31 --> URI Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Router Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Output Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Input Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:38:31 --> Language Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Loader Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Controller Class Initialized
ERROR - 2011-04-05 12:38:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:38:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:38:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:38:31 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:38:31 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:38:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:38:31 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:38:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:38:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:38:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:38:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:38:31 --> Final output sent to browser
DEBUG - 2011-04-05 12:38:32 --> Total execution time: 0.0292
DEBUG - 2011-04-05 12:38:32 --> Config Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:38:32 --> URI Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Router Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Output Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Input Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:38:32 --> Language Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Loader Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Controller Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Model Class Initialized
DEBUG - 2011-04-05 12:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:38:32 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:38:33 --> Final output sent to browser
DEBUG - 2011-04-05 12:38:33 --> Total execution time: 1.0907
DEBUG - 2011-04-05 12:38:34 --> Config Class Initialized
DEBUG - 2011-04-05 12:38:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:38:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:38:34 --> URI Class Initialized
DEBUG - 2011-04-05 12:38:34 --> Router Class Initialized
ERROR - 2011-04-05 12:38:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:39:02 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:02 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:02 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:02 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:02 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:02 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:02 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:02 --> Total execution time: 0.0308
DEBUG - 2011-04-05 12:39:03 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:03 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:03 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Controller Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:03 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:04 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:04 --> Total execution time: 1.1490
DEBUG - 2011-04-05 12:39:04 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:04 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:04 --> Router Class Initialized
ERROR - 2011-04-05 12:39:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:39:18 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:18 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:18 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:18 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:18 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:18 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:18 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:18 --> Total execution time: 0.0337
DEBUG - 2011-04-05 12:39:19 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:19 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:19 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Controller Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:20 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:20 --> Total execution time: 1.2150
DEBUG - 2011-04-05 12:39:21 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:21 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:21 --> Router Class Initialized
ERROR - 2011-04-05 12:39:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:39:32 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:32 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:32 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:32 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:32 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:32 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:32 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:32 --> Total execution time: 0.2512
DEBUG - 2011-04-05 12:39:33 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:33 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:33 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Controller Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:33 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:35 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:35 --> Total execution time: 2.3527
DEBUG - 2011-04-05 12:39:36 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:36 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:36 --> Router Class Initialized
ERROR - 2011-04-05 12:39:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:39:40 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:40 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:40 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:40 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:40 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:40 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:40 --> Total execution time: 0.0299
DEBUG - 2011-04-05 12:39:41 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:41 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:41 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Controller Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:41 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:42 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:42 --> Total execution time: 0.5382
DEBUG - 2011-04-05 12:39:43 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:43 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:43 --> Router Class Initialized
ERROR - 2011-04-05 12:39:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:39:50 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:50 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:50 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:50 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:50 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:50 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:50 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:50 --> Total execution time: 0.0341
DEBUG - 2011-04-05 12:39:51 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:51 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:51 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Controller Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:51 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:52 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:52 --> Total execution time: 0.7703
DEBUG - 2011-04-05 12:39:53 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:53 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:53 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:53 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:53 --> Router Class Initialized
ERROR - 2011-04-05 12:39:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:39:56 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:56 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:56 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:56 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:56 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:56 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:56 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:56 --> Total execution time: 0.0332
DEBUG - 2011-04-05 12:39:57 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:57 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:57 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Controller Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:57 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Router Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Output Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Input Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:39:57 --> Language Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Loader Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Controller Class Initialized
ERROR - 2011-04-05 12:39:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:39:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:57 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Model Class Initialized
DEBUG - 2011-04-05 12:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:39:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:39:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:39:57 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:57 --> Total execution time: 0.0436
DEBUG - 2011-04-05 12:39:58 --> Final output sent to browser
DEBUG - 2011-04-05 12:39:58 --> Total execution time: 1.0706
DEBUG - 2011-04-05 12:39:59 --> Config Class Initialized
DEBUG - 2011-04-05 12:39:59 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:39:59 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:39:59 --> URI Class Initialized
DEBUG - 2011-04-05 12:39:59 --> Router Class Initialized
ERROR - 2011-04-05 12:39:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:00 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:00 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:00 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:00 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:00 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:00 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:00 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:00 --> Total execution time: 0.0349
DEBUG - 2011-04-05 12:40:01 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:01 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:01 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:01 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:01 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:01 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:01 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:01 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:01 --> Total execution time: 0.1100
DEBUG - 2011-04-05 12:40:01 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:01 --> Total execution time: 0.7353
DEBUG - 2011-04-05 12:40:03 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:03 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:03 --> Router Class Initialized
ERROR - 2011-04-05 12:40:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:05 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:05 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:05 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:05 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:05 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:05 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:05 --> Total execution time: 0.1255
DEBUG - 2011-04-05 12:40:06 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:06 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:06 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:06 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:06 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:06 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:06 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:06 --> Total execution time: 0.0738
DEBUG - 2011-04-05 12:40:07 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:07 --> Total execution time: 0.7547
DEBUG - 2011-04-05 12:40:08 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:08 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:08 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:08 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:08 --> Router Class Initialized
ERROR - 2011-04-05 12:40:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:09 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:09 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:09 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:09 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:09 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:09 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:09 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:09 --> Total execution time: 0.0331
DEBUG - 2011-04-05 12:40:10 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:10 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:10 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:10 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:10 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:10 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:10 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:10 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:10 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:10 --> Total execution time: 0.0296
DEBUG - 2011-04-05 12:40:12 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:12 --> Total execution time: 1.9252
DEBUG - 2011-04-05 12:40:13 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:13 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:13 --> Router Class Initialized
ERROR - 2011-04-05 12:40:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:16 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:16 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:16 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:16 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:16 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:16 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:16 --> Total execution time: 0.0273
DEBUG - 2011-04-05 12:40:16 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:16 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:16 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:17 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:17 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:17 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:17 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:17 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:17 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:17 --> Total execution time: 0.0648
DEBUG - 2011-04-05 12:40:18 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:18 --> Total execution time: 1.4625
DEBUG - 2011-04-05 12:40:19 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:19 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:19 --> Router Class Initialized
ERROR - 2011-04-05 12:40:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:21 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:21 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:21 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:21 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:21 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:21 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:21 --> Total execution time: 0.0275
DEBUG - 2011-04-05 12:40:21 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:21 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:21 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:22 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:22 --> Total execution time: 0.8079
DEBUG - 2011-04-05 12:40:23 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:23 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:23 --> Router Class Initialized
ERROR - 2011-04-05 12:40:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:27 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:27 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:27 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:27 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:27 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:27 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:27 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:27 --> Total execution time: 0.0786
DEBUG - 2011-04-05 12:40:28 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:28 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:28 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:29 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:29 --> Total execution time: 0.9978
DEBUG - 2011-04-05 12:40:30 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:30 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:30 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:30 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:30 --> Router Class Initialized
ERROR - 2011-04-05 12:40:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:40:38 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:38 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:38 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Controller Class Initialized
ERROR - 2011-04-05 12:40:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:40:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:38 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:38 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:40:38 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:40:38 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:38 --> Total execution time: 0.0299
DEBUG - 2011-04-05 12:40:38 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:38 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Router Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Output Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Input Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:40:38 --> Language Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Loader Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Controller Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Model Class Initialized
DEBUG - 2011-04-05 12:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:40:38 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:40:39 --> Final output sent to browser
DEBUG - 2011-04-05 12:40:39 --> Total execution time: 0.6018
DEBUG - 2011-04-05 12:40:40 --> Config Class Initialized
DEBUG - 2011-04-05 12:40:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:40:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:40:40 --> URI Class Initialized
DEBUG - 2011-04-05 12:40:40 --> Router Class Initialized
ERROR - 2011-04-05 12:40:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:41:39 --> Config Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:41:39 --> URI Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Router Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Output Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Input Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:41:39 --> Language Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Loader Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Controller Class Initialized
ERROR - 2011-04-05 12:41:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:41:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:41:39 --> Model Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Model Class Initialized
DEBUG - 2011-04-05 12:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:41:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:41:39 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:41:39 --> Final output sent to browser
DEBUG - 2011-04-05 12:41:39 --> Total execution time: 0.0310
DEBUG - 2011-04-05 12:41:40 --> Config Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:41:40 --> URI Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Router Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Output Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Input Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:41:40 --> Language Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Loader Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Controller Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Model Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Model Class Initialized
DEBUG - 2011-04-05 12:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:41:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:41:41 --> Final output sent to browser
DEBUG - 2011-04-05 12:41:41 --> Total execution time: 0.7074
DEBUG - 2011-04-05 12:41:42 --> Config Class Initialized
DEBUG - 2011-04-05 12:41:42 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:41:42 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:41:42 --> URI Class Initialized
DEBUG - 2011-04-05 12:41:42 --> Router Class Initialized
ERROR - 2011-04-05 12:41:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:42:43 --> Config Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:42:43 --> URI Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Router Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Output Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Input Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:42:43 --> Language Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Loader Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Controller Class Initialized
ERROR - 2011-04-05 12:42:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:42:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:42:43 --> Model Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Model Class Initialized
DEBUG - 2011-04-05 12:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:42:43 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:42:43 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:42:43 --> Final output sent to browser
DEBUG - 2011-04-05 12:42:43 --> Total execution time: 0.0425
DEBUG - 2011-04-05 12:42:44 --> Config Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:42:44 --> URI Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Router Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Output Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Input Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:42:44 --> Language Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Loader Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Controller Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Config Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:42:44 --> URI Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Router Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Output Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Input Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:42:44 --> Language Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Loader Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Controller Class Initialized
ERROR - 2011-04-05 12:42:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 12:42:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 12:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:42:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Model Class Initialized
DEBUG - 2011-04-05 12:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 12:42:44 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:42:44 --> Final output sent to browser
DEBUG - 2011-04-05 12:42:44 --> Total execution time: 0.0317
DEBUG - 2011-04-05 12:42:45 --> Final output sent to browser
DEBUG - 2011-04-05 12:42:45 --> Total execution time: 0.7612
DEBUG - 2011-04-05 12:42:46 --> Config Class Initialized
DEBUG - 2011-04-05 12:42:46 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:42:46 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:42:46 --> URI Class Initialized
DEBUG - 2011-04-05 12:42:46 --> Router Class Initialized
ERROR - 2011-04-05 12:42:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 12:54:06 --> Config Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 12:54:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 12:54:06 --> URI Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Router Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Output Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Input Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 12:54:06 --> Language Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Loader Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Controller Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Model Class Initialized
DEBUG - 2011-04-05 12:54:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 12:54:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 12:54:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 12:54:07 --> Helper loaded: url_helper
DEBUG - 2011-04-05 12:54:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 12:54:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 12:54:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 12:54:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 12:54:07 --> Final output sent to browser
DEBUG - 2011-04-05 12:54:07 --> Total execution time: 1.2318
DEBUG - 2011-04-05 13:00:06 --> Config Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 13:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 13:00:06 --> URI Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Router Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Output Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Input Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 13:00:06 --> Language Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Loader Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Controller Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Model Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Model Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Model Class Initialized
DEBUG - 2011-04-05 13:00:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 13:00:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 13:00:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 13:00:08 --> Helper loaded: url_helper
DEBUG - 2011-04-05 13:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 13:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 13:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 13:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 13:00:08 --> Final output sent to browser
DEBUG - 2011-04-05 13:00:08 --> Total execution time: 2.5814
DEBUG - 2011-04-05 13:00:11 --> Config Class Initialized
DEBUG - 2011-04-05 13:00:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 13:00:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 13:00:11 --> URI Class Initialized
DEBUG - 2011-04-05 13:00:11 --> Router Class Initialized
ERROR - 2011-04-05 13:00:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 13:32:37 --> Config Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Hooks Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Utf8 Class Initialized
DEBUG - 2011-04-05 13:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 13:32:37 --> URI Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Router Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Output Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Input Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 13:32:37 --> Language Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Loader Class Initialized
DEBUG - 2011-04-05 13:32:37 --> Controller Class Initialized
ERROR - 2011-04-05 13:32:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 13:32:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 13:32:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 13:32:38 --> Model Class Initialized
DEBUG - 2011-04-05 13:32:38 --> Model Class Initialized
DEBUG - 2011-04-05 13:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 13:32:38 --> Database Driver Class Initialized
DEBUG - 2011-04-05 13:32:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 13:32:38 --> Helper loaded: url_helper
DEBUG - 2011-04-05 13:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 13:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 13:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 13:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 13:32:38 --> Final output sent to browser
DEBUG - 2011-04-05 13:32:38 --> Total execution time: 0.4429
DEBUG - 2011-04-05 13:32:39 --> Config Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 13:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 13:32:39 --> URI Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Router Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Output Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Input Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 13:32:39 --> Language Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Loader Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Controller Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Model Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Model Class Initialized
DEBUG - 2011-04-05 13:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 13:32:39 --> Database Driver Class Initialized
DEBUG - 2011-04-05 13:32:40 --> Final output sent to browser
DEBUG - 2011-04-05 13:32:40 --> Total execution time: 1.0967
DEBUG - 2011-04-05 14:16:36 --> Config Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:16:36 --> URI Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Router Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Output Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Input Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 14:16:36 --> Language Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Loader Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Controller Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Model Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Model Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Model Class Initialized
DEBUG - 2011-04-05 14:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 14:16:37 --> Database Driver Class Initialized
DEBUG - 2011-04-05 14:16:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 14:16:38 --> Helper loaded: url_helper
DEBUG - 2011-04-05 14:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 14:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 14:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 14:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 14:16:38 --> Final output sent to browser
DEBUG - 2011-04-05 14:16:38 --> Total execution time: 2.0929
DEBUG - 2011-04-05 14:16:51 --> Config Class Initialized
DEBUG - 2011-04-05 14:16:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:16:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:16:51 --> URI Class Initialized
DEBUG - 2011-04-05 14:16:51 --> Router Class Initialized
ERROR - 2011-04-05 14:16:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 14:17:30 --> Config Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:17:30 --> URI Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Router Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Output Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Input Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 14:17:30 --> Language Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Loader Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Controller Class Initialized
ERROR - 2011-04-05 14:17:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 14:17:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 14:17:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 14:17:30 --> Model Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Model Class Initialized
DEBUG - 2011-04-05 14:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 14:17:30 --> Database Driver Class Initialized
DEBUG - 2011-04-05 14:17:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 14:17:30 --> Helper loaded: url_helper
DEBUG - 2011-04-05 14:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 14:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 14:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 14:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 14:17:30 --> Final output sent to browser
DEBUG - 2011-04-05 14:17:30 --> Total execution time: 0.0940
DEBUG - 2011-04-05 14:17:31 --> Config Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:17:31 --> URI Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Router Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Output Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Input Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 14:17:31 --> Language Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Loader Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Controller Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Model Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Model Class Initialized
DEBUG - 2011-04-05 14:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 14:17:31 --> Database Driver Class Initialized
DEBUG - 2011-04-05 14:17:32 --> Final output sent to browser
DEBUG - 2011-04-05 14:17:32 --> Total execution time: 0.8141
DEBUG - 2011-04-05 14:17:50 --> Config Class Initialized
DEBUG - 2011-04-05 14:17:50 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:17:50 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:17:50 --> URI Class Initialized
DEBUG - 2011-04-05 14:17:50 --> Router Class Initialized
ERROR - 2011-04-05 14:17:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 14:43:15 --> Config Class Initialized
DEBUG - 2011-04-05 14:43:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:43:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:43:15 --> URI Class Initialized
DEBUG - 2011-04-05 14:43:15 --> Router Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Output Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Input Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 14:43:16 --> Language Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Loader Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Controller Class Initialized
ERROR - 2011-04-05 14:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 14:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 14:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 14:43:16 --> Model Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Model Class Initialized
DEBUG - 2011-04-05 14:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 14:43:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 14:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 14:43:16 --> Helper loaded: url_helper
DEBUG - 2011-04-05 14:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 14:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 14:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 14:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 14:43:16 --> Final output sent to browser
DEBUG - 2011-04-05 14:43:16 --> Total execution time: 0.4945
DEBUG - 2011-04-05 14:43:17 --> Config Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Hooks Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Utf8 Class Initialized
DEBUG - 2011-04-05 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 14:43:17 --> URI Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Router Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Output Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Input Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 14:43:17 --> Language Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Loader Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Controller Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Model Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Model Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 14:43:17 --> Database Driver Class Initialized
DEBUG - 2011-04-05 14:43:17 --> Final output sent to browser
DEBUG - 2011-04-05 14:43:17 --> Total execution time: 0.7460
DEBUG - 2011-04-05 15:16:34 --> Config Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:16:34 --> URI Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Router Class Initialized
DEBUG - 2011-04-05 15:16:34 --> No URI present. Default controller set.
DEBUG - 2011-04-05 15:16:34 --> Output Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Input Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:16:34 --> Language Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Loader Class Initialized
DEBUG - 2011-04-05 15:16:34 --> Controller Class Initialized
DEBUG - 2011-04-05 15:16:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 15:16:34 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:16:34 --> Final output sent to browser
DEBUG - 2011-04-05 15:16:34 --> Total execution time: 0.2310
DEBUG - 2011-04-05 15:16:37 --> Config Class Initialized
DEBUG - 2011-04-05 15:16:37 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:16:37 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:16:37 --> URI Class Initialized
DEBUG - 2011-04-05 15:16:37 --> Router Class Initialized
ERROR - 2011-04-05 15:16:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:16:39 --> Config Class Initialized
DEBUG - 2011-04-05 15:16:39 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:16:39 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:16:39 --> URI Class Initialized
DEBUG - 2011-04-05 15:16:39 --> Router Class Initialized
ERROR - 2011-04-05 15:16:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:16:44 --> Config Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:16:44 --> URI Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Router Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Output Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Input Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:16:44 --> Language Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Loader Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Controller Class Initialized
ERROR - 2011-04-05 15:16:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:16:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:16:44 --> Model Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Model Class Initialized
DEBUG - 2011-04-05 15:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:16:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:16:44 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:16:44 --> Final output sent to browser
DEBUG - 2011-04-05 15:16:44 --> Total execution time: 0.2434
DEBUG - 2011-04-05 15:16:45 --> Config Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:16:45 --> URI Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Router Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Output Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Input Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:16:45 --> Language Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Loader Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Controller Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Model Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Model Class Initialized
DEBUG - 2011-04-05 15:16:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:16:45 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:16:51 --> Final output sent to browser
DEBUG - 2011-04-05 15:16:51 --> Total execution time: 5.8736
DEBUG - 2011-04-05 15:16:52 --> Config Class Initialized
DEBUG - 2011-04-05 15:16:52 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:16:52 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:16:52 --> URI Class Initialized
DEBUG - 2011-04-05 15:16:52 --> Router Class Initialized
ERROR - 2011-04-05 15:16:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:17:09 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:09 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Router Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Output Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Input Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:17:09 --> Language Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Loader Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Controller Class Initialized
ERROR - 2011-04-05 15:17:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:17:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:17:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:17:09 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:17:09 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:17:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:17:09 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:17:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:17:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:17:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:17:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:17:09 --> Final output sent to browser
DEBUG - 2011-04-05 15:17:09 --> Total execution time: 0.0286
DEBUG - 2011-04-05 15:17:11 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:11 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Router Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Output Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Input Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:17:11 --> Language Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Loader Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Controller Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:17:11 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:17:26 --> Final output sent to browser
DEBUG - 2011-04-05 15:17:26 --> Total execution time: 14.8759
DEBUG - 2011-04-05 15:17:29 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:29 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:29 --> Router Class Initialized
ERROR - 2011-04-05 15:17:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:17:33 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:33 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Router Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Output Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Input Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:17:33 --> Language Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Loader Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Controller Class Initialized
ERROR - 2011-04-05 15:17:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:17:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:17:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:17:33 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:17:33 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:17:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:17:33 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:17:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:17:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:17:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:17:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:17:33 --> Final output sent to browser
DEBUG - 2011-04-05 15:17:33 --> Total execution time: 0.0342
DEBUG - 2011-04-05 15:17:34 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:34 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Router Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Output Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Input Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:17:34 --> Language Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Loader Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Controller Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:17:34 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:17:35 --> Final output sent to browser
DEBUG - 2011-04-05 15:17:35 --> Total execution time: 1.0084
DEBUG - 2011-04-05 15:17:37 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:37 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:37 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:37 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:37 --> Router Class Initialized
ERROR - 2011-04-05 15:17:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:17:43 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:43 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Router Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Output Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Input Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:17:43 --> Language Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Loader Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Controller Class Initialized
ERROR - 2011-04-05 15:17:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:17:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:17:43 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:17:43 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:17:43 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:17:43 --> Final output sent to browser
DEBUG - 2011-04-05 15:17:43 --> Total execution time: 0.0298
DEBUG - 2011-04-05 15:17:44 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:44 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Router Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Output Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Input Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:17:44 --> Language Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Loader Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Controller Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Model Class Initialized
DEBUG - 2011-04-05 15:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:17:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:17:49 --> Final output sent to browser
DEBUG - 2011-04-05 15:17:49 --> Total execution time: 4.4840
DEBUG - 2011-04-05 15:17:51 --> Config Class Initialized
DEBUG - 2011-04-05 15:17:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:17:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:17:51 --> URI Class Initialized
DEBUG - 2011-04-05 15:17:51 --> Router Class Initialized
ERROR - 2011-04-05 15:17:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:18:03 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:03 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Router Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Output Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Input Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:18:03 --> Language Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Loader Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Controller Class Initialized
ERROR - 2011-04-05 15:18:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:18:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:18:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:18:03 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:18:03 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:18:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:18:03 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:18:03 --> Final output sent to browser
DEBUG - 2011-04-05 15:18:03 --> Total execution time: 0.0295
DEBUG - 2011-04-05 15:18:05 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:05 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Router Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Output Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Input Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:18:05 --> Language Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Loader Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Controller Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:18:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:18:06 --> Final output sent to browser
DEBUG - 2011-04-05 15:18:06 --> Total execution time: 0.7232
DEBUG - 2011-04-05 15:18:07 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:07 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:07 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:07 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:07 --> Router Class Initialized
ERROR - 2011-04-05 15:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:18:19 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:19 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Router Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Output Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Input Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:18:19 --> Language Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Loader Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Controller Class Initialized
ERROR - 2011-04-05 15:18:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:18:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:18:19 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:18:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:18:19 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:18:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:18:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:18:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:18:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:18:19 --> Final output sent to browser
DEBUG - 2011-04-05 15:18:19 --> Total execution time: 0.0274
DEBUG - 2011-04-05 15:18:20 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:20 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Router Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Output Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Input Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:18:20 --> Language Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Loader Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Controller Class Initialized
ERROR - 2011-04-05 15:18:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 15:18:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 15:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:18:20 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:18:20 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 15:18:20 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:18:20 --> Final output sent to browser
DEBUG - 2011-04-05 15:18:20 --> Total execution time: 0.0310
DEBUG - 2011-04-05 15:18:20 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:20 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Router Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Output Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Input Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:18:20 --> Language Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Loader Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Controller Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Model Class Initialized
DEBUG - 2011-04-05 15:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:18:20 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:18:21 --> Final output sent to browser
DEBUG - 2011-04-05 15:18:21 --> Total execution time: 0.6389
DEBUG - 2011-04-05 15:18:23 --> Config Class Initialized
DEBUG - 2011-04-05 15:18:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:18:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:18:23 --> URI Class Initialized
DEBUG - 2011-04-05 15:18:23 --> Router Class Initialized
ERROR - 2011-04-05 15:18:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 15:20:12 --> Config Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:20:12 --> URI Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Router Class Initialized
DEBUG - 2011-04-05 15:20:12 --> No URI present. Default controller set.
DEBUG - 2011-04-05 15:20:12 --> Output Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Input Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:20:12 --> Language Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Loader Class Initialized
DEBUG - 2011-04-05 15:20:12 --> Controller Class Initialized
DEBUG - 2011-04-05 15:20:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 15:20:12 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:20:12 --> Final output sent to browser
DEBUG - 2011-04-05 15:20:12 --> Total execution time: 0.0155
DEBUG - 2011-04-05 15:27:33 --> Config Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:27:33 --> URI Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Router Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Output Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Input Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:27:33 --> Language Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Loader Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Controller Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Model Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Model Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:27:33 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:27:33 --> Final output sent to browser
DEBUG - 2011-04-05 15:27:33 --> Total execution time: 0.5961
DEBUG - 2011-04-05 15:29:11 --> Config Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 15:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 15:29:11 --> URI Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Router Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Output Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Input Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 15:29:11 --> Language Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Loader Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Controller Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Model Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Model Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Model Class Initialized
DEBUG - 2011-04-05 15:29:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 15:29:11 --> Database Driver Class Initialized
DEBUG - 2011-04-05 15:29:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 15:29:11 --> Helper loaded: url_helper
DEBUG - 2011-04-05 15:29:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 15:29:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 15:29:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 15:29:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 15:29:11 --> Final output sent to browser
DEBUG - 2011-04-05 15:29:11 --> Total execution time: 0.2848
DEBUG - 2011-04-05 16:09:57 --> Config Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:09:57 --> URI Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Router Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Output Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Input Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:09:57 --> Language Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Loader Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Controller Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Model Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Model Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Model Class Initialized
DEBUG - 2011-04-05 16:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:09:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:09:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:09:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:09:57 --> Final output sent to browser
DEBUG - 2011-04-05 16:09:57 --> Total execution time: 0.5988
DEBUG - 2011-04-05 16:10:09 --> Config Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:10:09 --> URI Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Router Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Output Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Input Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:10:09 --> Language Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Loader Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Controller Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:10:09 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:10:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:10:09 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:10:09 --> Final output sent to browser
DEBUG - 2011-04-05 16:10:09 --> Total execution time: 0.0471
DEBUG - 2011-04-05 16:10:13 --> Config Class Initialized
DEBUG - 2011-04-05 16:10:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:10:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:10:13 --> URI Class Initialized
DEBUG - 2011-04-05 16:10:13 --> Router Class Initialized
ERROR - 2011-04-05 16:10:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 16:10:33 --> Config Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:10:33 --> URI Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Router Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Output Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Input Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:10:33 --> Language Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Loader Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Controller Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:10:33 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:10:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:10:33 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:10:33 --> Final output sent to browser
DEBUG - 2011-04-05 16:10:33 --> Total execution time: 0.2555
DEBUG - 2011-04-05 16:10:35 --> Config Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:10:35 --> URI Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Router Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Output Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Input Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:10:35 --> Language Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Loader Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Controller Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:10:35 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:10:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:10:35 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:10:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:10:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:10:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:10:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:10:35 --> Final output sent to browser
DEBUG - 2011-04-05 16:10:35 --> Total execution time: 0.0485
DEBUG - 2011-04-05 16:10:36 --> Config Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:10:36 --> URI Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Router Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Output Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Input Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:10:36 --> Language Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Loader Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Controller Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Model Class Initialized
DEBUG - 2011-04-05 16:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:10:36 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:10:36 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:10:36 --> Final output sent to browser
DEBUG - 2011-04-05 16:10:36 --> Total execution time: 0.0468
DEBUG - 2011-04-05 16:11:01 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:01 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:01 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:02 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:02 --> Final output sent to browser
DEBUG - 2011-04-05 16:11:02 --> Total execution time: 0.6966
DEBUG - 2011-04-05 16:11:11 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:11 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:11 --> Router Class Initialized
ERROR - 2011-04-05 16:11:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 16:11:54 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:54 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:54 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:54 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:54 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:55 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> Final output sent to browser
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Total execution time: 0.0812
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
ERROR - 2011-04-05 16:11:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:55 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
ERROR - 2011-04-05 16:11:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:55 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:55 --> Final output sent to browser
DEBUG - 2011-04-05 16:11:55 --> Total execution time: 0.0736
DEBUG - 2011-04-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:55 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:55 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:55 --> Final output sent to browser
DEBUG - 2011-04-05 16:11:55 --> Total execution time: 0.1519
DEBUG - 2011-04-05 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Config Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:11:56 --> URI Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Router Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Output Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Input Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:11:56 --> Language Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Loader Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Controller Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Model Class Initialized
DEBUG - 2011-04-05 16:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:56 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:56 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:11:56 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:11:56 --> Final output sent to browser
DEBUG - 2011-04-05 16:11:56 --> Total execution time: 0.1891
DEBUG - 2011-04-05 16:12:00 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:00 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:00 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:00 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:00 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:00 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:00 --> Total execution time: 0.0543
DEBUG - 2011-04-05 16:12:03 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:03 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:03 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:03 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:04 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:04 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:04 --> Total execution time: 0.2721
DEBUG - 2011-04-05 16:12:04 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:04 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:04 --> Router Class Initialized
ERROR - 2011-04-05 16:12:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 16:12:05 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:05 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:05 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:05 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:05 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:05 --> Total execution time: 0.0449
DEBUG - 2011-04-05 16:12:06 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:06 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:06 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:06 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:06 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:06 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:06 --> Total execution time: 0.0876
DEBUG - 2011-04-05 16:12:09 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:09 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:09 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:09 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:09 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:16 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:16 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:16 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:16 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:16 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:16 --> Total execution time: 0.0692
DEBUG - 2011-04-05 16:12:23 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:23 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:23 --> Router Class Initialized
ERROR - 2011-04-05 16:12:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 16:12:24 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:24 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:24 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:24 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:24 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:24 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:24 --> Total execution time: 0.1159
DEBUG - 2011-04-05 16:12:57 --> Config Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:12:57 --> URI Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Router Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Output Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Input Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:12:57 --> Language Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Loader Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Controller Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Model Class Initialized
DEBUG - 2011-04-05 16:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:12:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:12:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:12:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:12:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:12:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:12:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:12:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:12:57 --> Final output sent to browser
DEBUG - 2011-04-05 16:12:57 --> Total execution time: 0.0500
DEBUG - 2011-04-05 16:13:19 --> Config Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:13:19 --> URI Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Router Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Output Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Input Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:13:19 --> Language Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Loader Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Controller Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Model Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Model Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Model Class Initialized
DEBUG - 2011-04-05 16:13:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:13:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:13:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:13:19 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:13:19 --> Final output sent to browser
DEBUG - 2011-04-05 16:13:19 --> Total execution time: 0.0946
DEBUG - 2011-04-05 16:13:23 --> Config Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:13:23 --> URI Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Router Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Output Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Input Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:13:23 --> Language Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Loader Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Controller Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Model Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Model Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Model Class Initialized
DEBUG - 2011-04-05 16:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:13:23 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:13:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:13:23 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:13:23 --> Final output sent to browser
DEBUG - 2011-04-05 16:13:23 --> Total execution time: 0.0449
DEBUG - 2011-04-05 16:13:44 --> Config Class Initialized
DEBUG - 2011-04-05 16:13:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:13:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:13:44 --> URI Class Initialized
DEBUG - 2011-04-05 16:13:44 --> Router Class Initialized
DEBUG - 2011-04-05 16:13:44 --> Output Class Initialized
DEBUG - 2011-04-05 16:13:44 --> Input Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Config Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:17:07 --> URI Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Router Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Output Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Input Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:17:07 --> Language Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Loader Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Controller Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Model Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Model Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Model Class Initialized
DEBUG - 2011-04-05 16:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:17:07 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:17:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:17:07 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:17:07 --> Final output sent to browser
DEBUG - 2011-04-05 16:17:07 --> Total execution time: 0.0506
DEBUG - 2011-04-05 16:18:23 --> Config Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:18:23 --> URI Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Router Class Initialized
ERROR - 2011-04-05 16:18:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 16:18:23 --> Config Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:18:23 --> URI Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Router Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Output Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Input Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:18:23 --> Language Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Loader Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Controller Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:18:23 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:18:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:18:23 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:18:23 --> Final output sent to browser
DEBUG - 2011-04-05 16:18:23 --> Total execution time: 0.0594
DEBUG - 2011-04-05 16:18:28 --> Config Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:18:28 --> URI Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Router Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Output Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Input Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:18:28 --> Language Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Loader Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Controller Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:18:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:18:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:18:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:18:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:18:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:18:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:18:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:18:28 --> Final output sent to browser
DEBUG - 2011-04-05 16:18:28 --> Total execution time: 0.0443
DEBUG - 2011-04-05 16:18:30 --> Config Class Initialized
DEBUG - 2011-04-05 16:18:30 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:18:30 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:18:30 --> URI Class Initialized
DEBUG - 2011-04-05 16:18:30 --> Router Class Initialized
ERROR - 2011-04-05 16:18:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 16:18:47 --> Config Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:18:47 --> URI Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Router Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Output Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Input Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:18:47 --> Language Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Loader Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Controller Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:18:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:18:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:18:47 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:18:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:18:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:18:47 --> Final output sent to browser
DEBUG - 2011-04-05 16:18:47 --> Total execution time: 0.2312
DEBUG - 2011-04-05 16:18:48 --> Config Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:18:48 --> URI Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Router Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Output Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Input Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:18:48 --> Language Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Loader Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Controller Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Model Class Initialized
DEBUG - 2011-04-05 16:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:18:48 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:18:48 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:18:48 --> Final output sent to browser
DEBUG - 2011-04-05 16:18:48 --> Total execution time: 0.0442
DEBUG - 2011-04-05 16:20:40 --> Config Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:20:40 --> URI Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Router Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Output Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Input Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:20:40 --> Language Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Loader Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Controller Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:20:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:20:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:20:40 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:20:40 --> Final output sent to browser
DEBUG - 2011-04-05 16:20:40 --> Total execution time: 0.0528
DEBUG - 2011-04-05 16:20:42 --> Config Class Initialized
DEBUG - 2011-04-05 16:20:42 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:20:42 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:20:42 --> URI Class Initialized
DEBUG - 2011-04-05 16:20:42 --> Router Class Initialized
ERROR - 2011-04-05 16:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 16:20:51 --> Config Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:20:51 --> URI Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Router Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Output Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Input Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:20:51 --> Language Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Loader Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Controller Class Initialized
ERROR - 2011-04-05 16:20:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 16:20:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 16:20:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 16:20:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:20:51 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:20:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 16:20:51 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:20:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:20:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:20:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:20:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:20:51 --> Final output sent to browser
DEBUG - 2011-04-05 16:20:51 --> Total execution time: 0.0939
DEBUG - 2011-04-05 16:20:52 --> Config Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:20:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:20:52 --> URI Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Router Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Output Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Input Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:20:52 --> Language Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Loader Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Controller Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Model Class Initialized
DEBUG - 2011-04-05 16:20:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:20:52 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:20:53 --> Final output sent to browser
DEBUG - 2011-04-05 16:20:53 --> Total execution time: 0.8984
DEBUG - 2011-04-05 16:21:27 --> Config Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:21:27 --> URI Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Router Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Output Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Input Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:21:27 --> Language Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Loader Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Controller Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Model Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Model Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Model Class Initialized
DEBUG - 2011-04-05 16:21:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:21:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:21:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:21:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:21:28 --> Final output sent to browser
DEBUG - 2011-04-05 16:21:28 --> Total execution time: 0.1016
DEBUG - 2011-04-05 16:21:44 --> Config Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:21:44 --> URI Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Router Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Output Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Input Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:21:44 --> Language Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Loader Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Controller Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Model Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Model Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Model Class Initialized
DEBUG - 2011-04-05 16:21:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:21:44 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:21:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:21:44 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:21:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:21:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:21:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:21:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:21:44 --> Final output sent to browser
DEBUG - 2011-04-05 16:21:44 --> Total execution time: 0.0441
DEBUG - 2011-04-05 16:23:50 --> Config Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:23:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:23:50 --> URI Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Router Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Output Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Input Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:23:50 --> Language Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Loader Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Controller Class Initialized
ERROR - 2011-04-05 16:23:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 16:23:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 16:23:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 16:23:50 --> Model Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Model Class Initialized
DEBUG - 2011-04-05 16:23:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:23:50 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:23:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 16:23:50 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:23:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:23:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:23:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:23:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:23:50 --> Final output sent to browser
DEBUG - 2011-04-05 16:23:50 --> Total execution time: 0.0278
DEBUG - 2011-04-05 16:23:51 --> Config Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:23:51 --> URI Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Router Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Output Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Input Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:23:51 --> Language Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Loader Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Controller Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:23:51 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:23:52 --> Final output sent to browser
DEBUG - 2011-04-05 16:23:52 --> Total execution time: 0.9933
DEBUG - 2011-04-05 16:30:27 --> Config Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:30:27 --> URI Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Router Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Output Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Input Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:30:27 --> Language Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Loader Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Controller Class Initialized
ERROR - 2011-04-05 16:30:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 16:30:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 16:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 16:30:27 --> Model Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Model Class Initialized
DEBUG - 2011-04-05 16:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:30:27 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 16:30:27 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:30:27 --> Final output sent to browser
DEBUG - 2011-04-05 16:30:27 --> Total execution time: 0.0516
DEBUG - 2011-04-05 16:32:19 --> Config Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:32:19 --> URI Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Router Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Output Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Input Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:32:19 --> Language Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Loader Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Controller Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Model Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Model Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Model Class Initialized
DEBUG - 2011-04-05 16:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:32:19 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:32:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:32:19 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:32:19 --> Final output sent to browser
DEBUG - 2011-04-05 16:32:19 --> Total execution time: 0.0450
DEBUG - 2011-04-05 16:32:22 --> Config Class Initialized
DEBUG - 2011-04-05 16:32:22 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:32:22 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:32:22 --> URI Class Initialized
DEBUG - 2011-04-05 16:32:22 --> Router Class Initialized
ERROR - 2011-04-05 16:32:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 16:36:51 --> Config Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:36:51 --> URI Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Router Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Output Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Input Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:36:51 --> Language Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Loader Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Controller Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Model Class Initialized
DEBUG - 2011-04-05 16:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:36:51 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:36:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:36:51 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:36:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:36:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:36:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:36:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:36:51 --> Final output sent to browser
DEBUG - 2011-04-05 16:36:51 --> Total execution time: 0.3007
DEBUG - 2011-04-05 16:41:09 --> Config Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:41:09 --> URI Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Router Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Output Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Input Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 16:41:09 --> Language Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Loader Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Controller Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Model Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Model Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Model Class Initialized
DEBUG - 2011-04-05 16:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 16:41:09 --> Database Driver Class Initialized
DEBUG - 2011-04-05 16:41:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 16:41:09 --> Helper loaded: url_helper
DEBUG - 2011-04-05 16:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 16:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 16:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 16:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 16:41:09 --> Final output sent to browser
DEBUG - 2011-04-05 16:41:09 --> Total execution time: 0.0730
DEBUG - 2011-04-05 16:52:02 --> Config Class Initialized
DEBUG - 2011-04-05 16:52:02 --> Hooks Class Initialized
DEBUG - 2011-04-05 16:52:02 --> Utf8 Class Initialized
DEBUG - 2011-04-05 16:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 16:52:02 --> URI Class Initialized
DEBUG - 2011-04-05 16:52:02 --> Router Class Initialized
DEBUG - 2011-04-05 16:52:02 --> Output Class Initialized
DEBUG - 2011-04-05 16:52:02 --> Input Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Config Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:27:01 --> URI Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Router Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Output Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Input Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:27:01 --> Language Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Loader Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Controller Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:27:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:27:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 17:27:01 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:27:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:27:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:27:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:27:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:27:01 --> Final output sent to browser
DEBUG - 2011-04-05 17:27:01 --> Total execution time: 0.6605
DEBUG - 2011-04-05 17:27:04 --> Config Class Initialized
DEBUG - 2011-04-05 17:27:04 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:27:04 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:27:04 --> URI Class Initialized
DEBUG - 2011-04-05 17:27:04 --> Router Class Initialized
ERROR - 2011-04-05 17:27:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 17:27:14 --> Config Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:27:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:27:14 --> URI Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Router Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Output Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Input Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:27:14 --> Language Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Loader Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Controller Class Initialized
ERROR - 2011-04-05 17:27:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:27:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:27:14 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:27:14 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:27:14 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:27:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:27:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:27:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:27:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:27:14 --> Final output sent to browser
DEBUG - 2011-04-05 17:27:14 --> Total execution time: 0.1443
DEBUG - 2011-04-05 17:27:15 --> Config Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:27:15 --> URI Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Router Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Output Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Input Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:27:15 --> Language Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Loader Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Controller Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:27:15 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:27:15 --> Final output sent to browser
DEBUG - 2011-04-05 17:27:15 --> Total execution time: 0.7302
DEBUG - 2011-04-05 17:27:58 --> Config Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:27:58 --> URI Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Router Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Output Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Input Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:27:58 --> Language Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Loader Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Controller Class Initialized
ERROR - 2011-04-05 17:27:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:27:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:27:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:27:58 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:27:58 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:27:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:27:58 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:27:58 --> Final output sent to browser
DEBUG - 2011-04-05 17:27:58 --> Total execution time: 0.0380
DEBUG - 2011-04-05 17:27:59 --> Config Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:27:59 --> URI Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Router Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Output Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Input Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:27:59 --> Language Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Loader Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Controller Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Model Class Initialized
DEBUG - 2011-04-05 17:27:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:27:59 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:00 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:00 --> Total execution time: 0.6807
DEBUG - 2011-04-05 17:28:11 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:11 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:11 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Controller Class Initialized
ERROR - 2011-04-05 17:28:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:28:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:28:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:11 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:11 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:11 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:28:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:28:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:28:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:28:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:28:11 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:11 --> Total execution time: 0.0543
DEBUG - 2011-04-05 17:28:12 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:12 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:12 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Controller Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:12 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:15 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:15 --> Total execution time: 3.0312
DEBUG - 2011-04-05 17:28:25 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:25 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:25 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Controller Class Initialized
ERROR - 2011-04-05 17:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:25 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:25 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:25 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:28:25 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:25 --> Total execution time: 0.0314
DEBUG - 2011-04-05 17:28:26 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:26 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:26 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Controller Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:26 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:26 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:26 --> Total execution time: 0.8283
DEBUG - 2011-04-05 17:28:40 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:40 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:40 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Controller Class Initialized
ERROR - 2011-04-05 17:28:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:28:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:40 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:40 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:28:40 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:40 --> Total execution time: 0.0325
DEBUG - 2011-04-05 17:28:40 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:40 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:40 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Controller Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:40 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:41 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:41 --> Total execution time: 0.6293
DEBUG - 2011-04-05 17:28:46 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:46 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:46 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Controller Class Initialized
ERROR - 2011-04-05 17:28:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:28:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:28:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:46 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:46 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:28:46 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:28:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:28:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:28:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:28:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:28:46 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:46 --> Total execution time: 0.0416
DEBUG - 2011-04-05 17:28:47 --> Config Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:28:47 --> URI Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Router Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Output Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Input Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:28:47 --> Language Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Loader Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Controller Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Model Class Initialized
DEBUG - 2011-04-05 17:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:28:47 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:28:48 --> Final output sent to browser
DEBUG - 2011-04-05 17:28:48 --> Total execution time: 0.6362
DEBUG - 2011-04-05 17:29:01 --> Config Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:29:01 --> URI Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Router Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Output Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Input Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:29:01 --> Language Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Loader Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Controller Class Initialized
ERROR - 2011-04-05 17:29:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-05 17:29:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-05 17:29:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:29:01 --> Model Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Model Class Initialized
DEBUG - 2011-04-05 17:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:29:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:29:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-05 17:29:01 --> Helper loaded: url_helper
DEBUG - 2011-04-05 17:29:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 17:29:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 17:29:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 17:29:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 17:29:01 --> Final output sent to browser
DEBUG - 2011-04-05 17:29:01 --> Total execution time: 0.0295
DEBUG - 2011-04-05 17:29:02 --> Config Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Hooks Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Utf8 Class Initialized
DEBUG - 2011-04-05 17:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 17:29:02 --> URI Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Router Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Output Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Input Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 17:29:02 --> Language Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Loader Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Controller Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Model Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Model Class Initialized
DEBUG - 2011-04-05 17:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 17:29:02 --> Database Driver Class Initialized
DEBUG - 2011-04-05 17:29:03 --> Final output sent to browser
DEBUG - 2011-04-05 17:29:03 --> Total execution time: 0.6801
DEBUG - 2011-04-05 18:34:34 --> Config Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:34:34 --> URI Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Router Class Initialized
DEBUG - 2011-04-05 18:34:34 --> No URI present. Default controller set.
DEBUG - 2011-04-05 18:34:34 --> Output Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Input Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:34:34 --> Language Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Loader Class Initialized
DEBUG - 2011-04-05 18:34:34 --> Controller Class Initialized
DEBUG - 2011-04-05 18:34:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 18:34:34 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:34:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:34:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:34:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:34:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:34:34 --> Final output sent to browser
DEBUG - 2011-04-05 18:34:34 --> Total execution time: 0.4902
DEBUG - 2011-04-05 18:34:35 --> Config Class Initialized
DEBUG - 2011-04-05 18:34:35 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:34:35 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:34:35 --> URI Class Initialized
DEBUG - 2011-04-05 18:34:35 --> Router Class Initialized
ERROR - 2011-04-05 18:34:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:35:43 --> Config Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:35:43 --> URI Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Router Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Output Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Input Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:35:43 --> Language Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Loader Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Controller Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Model Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Model Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Model Class Initialized
DEBUG - 2011-04-05 18:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:35:43 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:35:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:35:44 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:35:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:35:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:35:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:35:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:35:44 --> Final output sent to browser
DEBUG - 2011-04-05 18:35:44 --> Total execution time: 0.3754
DEBUG - 2011-04-05 18:35:45 --> Config Class Initialized
DEBUG - 2011-04-05 18:35:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:35:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:35:45 --> URI Class Initialized
DEBUG - 2011-04-05 18:35:45 --> Router Class Initialized
ERROR - 2011-04-05 18:35:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:36:00 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:00 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:00 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:00 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:00 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:00 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:00 --> Total execution time: 0.1795
DEBUG - 2011-04-05 18:36:01 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:01 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:01 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:01 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:01 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:01 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:01 --> Total execution time: 0.0456
DEBUG - 2011-04-05 18:36:01 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:01 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:01 --> Router Class Initialized
ERROR - 2011-04-05 18:36:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:36:13 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:13 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:13 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:13 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:14 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:14 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:14 --> Total execution time: 1.0289
DEBUG - 2011-04-05 18:36:15 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:15 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:15 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:15 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:15 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:15 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:15 --> Total execution time: 0.0425
DEBUG - 2011-04-05 18:36:15 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:15 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:15 --> Router Class Initialized
ERROR - 2011-04-05 18:36:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:36:29 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:29 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:29 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:29 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:29 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:29 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:29 --> Total execution time: 0.1883
DEBUG - 2011-04-05 18:36:30 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:30 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:30 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:30 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:30 --> Router Class Initialized
ERROR - 2011-04-05 18:36:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:36:57 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:57 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:57 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:57 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:57 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:57 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:57 --> Total execution time: 0.2863
DEBUG - 2011-04-05 18:36:58 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:58 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Router Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Output Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Input Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:36:58 --> Language Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Loader Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Controller Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Model Class Initialized
DEBUG - 2011-04-05 18:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:36:58 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:36:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:36:58 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:36:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:36:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:36:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:36:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:36:58 --> Final output sent to browser
DEBUG - 2011-04-05 18:36:58 --> Total execution time: 0.0451
DEBUG - 2011-04-05 18:36:59 --> Config Class Initialized
DEBUG - 2011-04-05 18:36:59 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:36:59 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:36:59 --> URI Class Initialized
DEBUG - 2011-04-05 18:36:59 --> Router Class Initialized
ERROR - 2011-04-05 18:36:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:37:00 --> Config Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:37:00 --> URI Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Router Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Output Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Input Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:37:00 --> Language Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Loader Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Controller Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:37:00 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:37:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:37:00 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:37:00 --> Final output sent to browser
DEBUG - 2011-04-05 18:37:00 --> Total execution time: 0.0993
DEBUG - 2011-04-05 18:37:07 --> Config Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:37:07 --> URI Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Router Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Output Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Input Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:37:07 --> Language Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Loader Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Controller Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:37:07 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:37:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:37:07 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:37:07 --> Final output sent to browser
DEBUG - 2011-04-05 18:37:07 --> Total execution time: 0.2077
DEBUG - 2011-04-05 18:37:09 --> Config Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:37:09 --> URI Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Router Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Output Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Input Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:37:09 --> Language Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Loader Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Controller Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:37:09 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:37:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:37:09 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:37:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:37:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:37:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:37:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:37:09 --> Final output sent to browser
DEBUG - 2011-04-05 18:37:09 --> Total execution time: 0.0486
DEBUG - 2011-04-05 18:37:09 --> Config Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:37:09 --> URI Class Initialized
DEBUG - 2011-04-05 18:37:09 --> Router Class Initialized
ERROR - 2011-04-05 18:37:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 18:37:21 --> Config Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:37:21 --> URI Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Router Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Output Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Input Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 18:37:21 --> Language Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Loader Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Controller Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Model Class Initialized
DEBUG - 2011-04-05 18:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 18:37:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 18:37:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 18:37:21 --> Helper loaded: url_helper
DEBUG - 2011-04-05 18:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 18:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 18:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 18:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 18:37:21 --> Final output sent to browser
DEBUG - 2011-04-05 18:37:21 --> Total execution time: 0.2315
DEBUG - 2011-04-05 18:37:22 --> Config Class Initialized
DEBUG - 2011-04-05 18:37:22 --> Hooks Class Initialized
DEBUG - 2011-04-05 18:37:22 --> Utf8 Class Initialized
DEBUG - 2011-04-05 18:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 18:37:22 --> URI Class Initialized
DEBUG - 2011-04-05 18:37:22 --> Router Class Initialized
ERROR - 2011-04-05 18:37:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 20:48:40 --> Config Class Initialized
DEBUG - 2011-04-05 20:48:40 --> Hooks Class Initialized
DEBUG - 2011-04-05 20:48:40 --> Utf8 Class Initialized
DEBUG - 2011-04-05 20:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 20:48:40 --> URI Class Initialized
DEBUG - 2011-04-05 20:48:40 --> Router Class Initialized
DEBUG - 2011-04-05 20:48:40 --> Output Class Initialized
DEBUG - 2011-04-05 20:48:40 --> Input Class Initialized
DEBUG - 2011-04-05 20:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 20:48:40 --> Language Class Initialized
DEBUG - 2011-04-05 20:48:41 --> Loader Class Initialized
DEBUG - 2011-04-05 20:48:41 --> Controller Class Initialized
DEBUG - 2011-04-05 20:48:41 --> Model Class Initialized
DEBUG - 2011-04-05 20:48:41 --> Model Class Initialized
DEBUG - 2011-04-05 20:48:41 --> Model Class Initialized
DEBUG - 2011-04-05 20:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 20:48:41 --> Database Driver Class Initialized
DEBUG - 2011-04-05 20:48:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 20:48:42 --> Helper loaded: url_helper
DEBUG - 2011-04-05 20:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 20:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 20:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 20:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 20:48:42 --> Final output sent to browser
DEBUG - 2011-04-05 20:48:42 --> Total execution time: 1.6343
DEBUG - 2011-04-05 20:48:45 --> Config Class Initialized
DEBUG - 2011-04-05 20:48:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 20:48:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 20:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 20:48:45 --> URI Class Initialized
DEBUG - 2011-04-05 20:48:45 --> Router Class Initialized
ERROR - 2011-04-05 20:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 20:48:48 --> Config Class Initialized
DEBUG - 2011-04-05 20:48:48 --> Hooks Class Initialized
DEBUG - 2011-04-05 20:48:48 --> Utf8 Class Initialized
DEBUG - 2011-04-05 20:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 20:48:48 --> URI Class Initialized
DEBUG - 2011-04-05 20:48:48 --> Router Class Initialized
ERROR - 2011-04-05 20:48:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 20:49:21 --> Config Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Hooks Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Utf8 Class Initialized
DEBUG - 2011-04-05 20:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 20:49:21 --> URI Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Router Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Output Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Input Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 20:49:21 --> Language Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Loader Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Controller Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Model Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Model Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Model Class Initialized
DEBUG - 2011-04-05 20:49:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 20:49:21 --> Database Driver Class Initialized
DEBUG - 2011-04-05 20:49:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 20:49:21 --> Helper loaded: url_helper
DEBUG - 2011-04-05 20:49:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 20:49:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 20:49:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 20:49:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 20:49:21 --> Final output sent to browser
DEBUG - 2011-04-05 20:49:21 --> Total execution time: 0.2965
DEBUG - 2011-04-05 20:49:31 --> Config Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Hooks Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Utf8 Class Initialized
DEBUG - 2011-04-05 20:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 20:49:31 --> URI Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Router Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Output Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Input Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 20:49:31 --> Language Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Loader Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Controller Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Model Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Model Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Model Class Initialized
DEBUG - 2011-04-05 20:49:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 20:49:31 --> Database Driver Class Initialized
DEBUG - 2011-04-05 20:49:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 20:49:32 --> Helper loaded: url_helper
DEBUG - 2011-04-05 20:49:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 20:49:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 20:49:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 20:49:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 20:49:32 --> Final output sent to browser
DEBUG - 2011-04-05 20:49:32 --> Total execution time: 1.0008
DEBUG - 2011-04-05 21:04:28 --> Config Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 21:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 21:04:28 --> URI Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Router Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Output Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Input Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 21:04:28 --> Language Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Loader Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Controller Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Model Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Model Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Model Class Initialized
DEBUG - 2011-04-05 21:04:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 21:04:28 --> Database Driver Class Initialized
DEBUG - 2011-04-05 21:04:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 21:04:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 21:04:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 21:04:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 21:04:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 21:04:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 21:04:28 --> Final output sent to browser
DEBUG - 2011-04-05 21:04:28 --> Total execution time: 0.1714
DEBUG - 2011-04-05 21:04:31 --> Config Class Initialized
DEBUG - 2011-04-05 21:04:31 --> Hooks Class Initialized
DEBUG - 2011-04-05 21:04:31 --> Utf8 Class Initialized
DEBUG - 2011-04-05 21:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 21:04:31 --> URI Class Initialized
DEBUG - 2011-04-05 21:04:31 --> Router Class Initialized
ERROR - 2011-04-05 21:04:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:15:27 --> Config Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:15:27 --> URI Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Router Class Initialized
DEBUG - 2011-04-05 22:15:27 --> No URI present. Default controller set.
DEBUG - 2011-04-05 22:15:27 --> Output Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Input Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:15:27 --> Language Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Loader Class Initialized
DEBUG - 2011-04-05 22:15:27 --> Controller Class Initialized
DEBUG - 2011-04-05 22:15:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 22:15:27 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:15:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:15:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:15:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:15:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:15:27 --> Final output sent to browser
DEBUG - 2011-04-05 22:15:27 --> Total execution time: 0.4243
DEBUG - 2011-04-05 22:15:30 --> Config Class Initialized
DEBUG - 2011-04-05 22:15:30 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:15:30 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:15:30 --> URI Class Initialized
DEBUG - 2011-04-05 22:15:30 --> Router Class Initialized
ERROR - 2011-04-05 22:15:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:18:28 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:28 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Router Class Initialized
DEBUG - 2011-04-05 22:18:28 --> No URI present. Default controller set.
DEBUG - 2011-04-05 22:18:28 --> Output Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Input Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:18:28 --> Language Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Loader Class Initialized
DEBUG - 2011-04-05 22:18:28 --> Controller Class Initialized
DEBUG - 2011-04-05 22:18:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 22:18:28 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:18:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:18:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:18:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:18:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:18:28 --> Final output sent to browser
DEBUG - 2011-04-05 22:18:28 --> Total execution time: 0.0140
DEBUG - 2011-04-05 22:18:29 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:29 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:29 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:29 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:29 --> Router Class Initialized
ERROR - 2011-04-05 22:18:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:18:31 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:31 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Router Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Output Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Input Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:18:31 --> Language Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Loader Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Controller Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:18:31 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:18:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:18:31 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:18:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:18:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:18:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:18:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:18:31 --> Final output sent to browser
DEBUG - 2011-04-05 22:18:31 --> Total execution time: 0.6784
DEBUG - 2011-04-05 22:18:33 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:33 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:33 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:33 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:33 --> Router Class Initialized
ERROR - 2011-04-05 22:18:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:18:42 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:42 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Router Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Output Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Input Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:18:42 --> Language Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Loader Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Controller Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:18:42 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:18:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:18:43 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:18:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:18:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:18:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:18:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:18:43 --> Final output sent to browser
DEBUG - 2011-04-05 22:18:43 --> Total execution time: 0.2524
DEBUG - 2011-04-05 22:18:45 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:45 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Router Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Output Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Input Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:18:45 --> Language Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Loader Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Controller Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:18:45 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:45 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:45 --> Router Class Initialized
ERROR - 2011-04-05 22:18:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:18:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:18:45 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:18:45 --> Final output sent to browser
DEBUG - 2011-04-05 22:18:45 --> Total execution time: 0.1289
DEBUG - 2011-04-05 22:18:53 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:53 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Router Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Output Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Input Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:18:53 --> Language Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Loader Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Controller Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:18:53 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:18:54 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:18:54 --> Final output sent to browser
DEBUG - 2011-04-05 22:18:54 --> Total execution time: 0.3672
DEBUG - 2011-04-05 22:18:55 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:55 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Router Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Output Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Input Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:18:55 --> Language Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Loader Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Controller Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Model Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:18:55 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:18:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:18:55 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:18:55 --> Final output sent to browser
DEBUG - 2011-04-05 22:18:55 --> Total execution time: 0.0711
DEBUG - 2011-04-05 22:18:55 --> Config Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:18:55 --> URI Class Initialized
DEBUG - 2011-04-05 22:18:55 --> Router Class Initialized
ERROR - 2011-04-05 22:18:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:19:05 --> Config Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:19:05 --> URI Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Router Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Output Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Input Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:19:05 --> Language Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Loader Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Controller Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Model Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Model Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Model Class Initialized
DEBUG - 2011-04-05 22:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:19:05 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:19:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:19:05 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:19:05 --> Final output sent to browser
DEBUG - 2011-04-05 22:19:05 --> Total execution time: 0.2825
DEBUG - 2011-04-05 22:19:08 --> Config Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:19:08 --> URI Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Router Class Initialized
ERROR - 2011-04-05 22:19:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-05 22:19:08 --> Config Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Hooks Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Utf8 Class Initialized
DEBUG - 2011-04-05 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 22:19:08 --> URI Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Router Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Output Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Input Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 22:19:08 --> Language Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Loader Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Controller Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Model Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Model Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Model Class Initialized
DEBUG - 2011-04-05 22:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-05 22:19:08 --> Database Driver Class Initialized
DEBUG - 2011-04-05 22:19:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-05 22:19:08 --> Helper loaded: url_helper
DEBUG - 2011-04-05 22:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 22:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 22:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 22:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 22:19:08 --> Final output sent to browser
DEBUG - 2011-04-05 22:19:08 --> Total execution time: 0.0859
DEBUG - 2011-04-05 23:42:44 --> Config Class Initialized
DEBUG - 2011-04-05 23:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-05 23:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-05 23:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 23:42:44 --> URI Class Initialized
DEBUG - 2011-04-05 23:42:44 --> Router Class Initialized
ERROR - 2011-04-05 23:42:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-05 23:42:45 --> Config Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Hooks Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Utf8 Class Initialized
DEBUG - 2011-04-05 23:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-05 23:42:45 --> URI Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Router Class Initialized
DEBUG - 2011-04-05 23:42:45 --> No URI present. Default controller set.
DEBUG - 2011-04-05 23:42:45 --> Output Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Input Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-05 23:42:45 --> Language Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Loader Class Initialized
DEBUG - 2011-04-05 23:42:45 --> Controller Class Initialized
DEBUG - 2011-04-05 23:42:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-05 23:42:45 --> Helper loaded: url_helper
DEBUG - 2011-04-05 23:42:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-05 23:42:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-05 23:42:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-05 23:42:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-05 23:42:45 --> Final output sent to browser
DEBUG - 2011-04-05 23:42:45 --> Total execution time: 0.1870

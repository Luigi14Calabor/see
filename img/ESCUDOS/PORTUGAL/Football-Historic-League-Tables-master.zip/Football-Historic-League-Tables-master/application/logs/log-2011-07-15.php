<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-15 01:19:33 --> Config Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Hooks Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Utf8 Class Initialized
DEBUG - 2011-07-15 01:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 01:19:33 --> URI Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Router Class Initialized
DEBUG - 2011-07-15 01:19:33 --> No URI present. Default controller set.
DEBUG - 2011-07-15 01:19:33 --> Output Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Input Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 01:19:33 --> Language Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Loader Class Initialized
DEBUG - 2011-07-15 01:19:33 --> Controller Class Initialized
DEBUG - 2011-07-15 01:19:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-15 01:19:33 --> Helper loaded: url_helper
DEBUG - 2011-07-15 01:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 01:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 01:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 01:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 01:19:33 --> Final output sent to browser
DEBUG - 2011-07-15 01:19:33 --> Total execution time: 0.2324
DEBUG - 2011-07-15 02:22:58 --> Config Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:22:58 --> URI Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Router Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Output Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Input Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:22:58 --> Language Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Loader Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Controller Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Model Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Model Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Model Class Initialized
DEBUG - 2011-07-15 02:22:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:22:58 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:22:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:22:58 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:22:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:22:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:22:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:22:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:22:58 --> Final output sent to browser
DEBUG - 2011-07-15 02:22:58 --> Total execution time: 0.7419
DEBUG - 2011-07-15 02:23:06 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:06 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:06 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:06 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:06 --> Router Class Initialized
ERROR - 2011-07-15 02:23:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 02:23:06 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:06 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:06 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:06 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:06 --> Router Class Initialized
ERROR - 2011-07-15 02:23:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 02:23:28 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:28 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Router Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Output Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Input Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:23:28 --> Language Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Loader Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Controller Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:23:28 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:23:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:23:29 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:23:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:23:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:23:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:23:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:23:29 --> Final output sent to browser
DEBUG - 2011-07-15 02:23:29 --> Total execution time: 0.6274
DEBUG - 2011-07-15 02:23:32 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:32 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Router Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Output Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Input Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:23:32 --> Language Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Loader Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Controller Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:23:32 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:23:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:23:32 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:23:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:23:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:23:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:23:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:23:32 --> Final output sent to browser
DEBUG - 2011-07-15 02:23:32 --> Total execution time: 0.0478
DEBUG - 2011-07-15 02:23:41 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:41 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Router Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Output Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Input Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:23:41 --> Language Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Loader Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Controller Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:23:41 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:23:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:23:41 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:23:41 --> Final output sent to browser
DEBUG - 2011-07-15 02:23:41 --> Total execution time: 0.3505
DEBUG - 2011-07-15 02:23:43 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:43 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Router Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Output Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Input Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:23:43 --> Language Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Loader Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Controller Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:23:43 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:23:43 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:23:43 --> Final output sent to browser
DEBUG - 2011-07-15 02:23:43 --> Total execution time: 0.0785
DEBUG - 2011-07-15 02:23:43 --> Config Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:23:43 --> URI Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Router Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Output Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Input Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:23:43 --> Language Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Loader Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Controller Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:23:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:23:43 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:23:43 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:23:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:23:43 --> Final output sent to browser
DEBUG - 2011-07-15 02:23:43 --> Total execution time: 0.2886
DEBUG - 2011-07-15 02:24:02 --> Config Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:24:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:24:02 --> URI Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Router Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Output Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Input Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:24:02 --> Language Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Loader Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Controller Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:24:02 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:24:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:24:02 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:24:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:24:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:24:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:24:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:24:02 --> Final output sent to browser
DEBUG - 2011-07-15 02:24:02 --> Total execution time: 0.2558
DEBUG - 2011-07-15 02:24:09 --> Config Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:24:09 --> URI Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Router Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Output Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Input Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:24:09 --> Language Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Loader Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Controller Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:24:09 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:24:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:24:10 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:24:10 --> Final output sent to browser
DEBUG - 2011-07-15 02:24:10 --> Total execution time: 0.3742
DEBUG - 2011-07-15 02:24:34 --> Config Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:24:34 --> URI Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Router Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Output Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Input Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:24:34 --> Language Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Loader Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Controller Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:24:34 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:24:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:24:35 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:24:35 --> Final output sent to browser
DEBUG - 2011-07-15 02:24:35 --> Total execution time: 0.7785
DEBUG - 2011-07-15 02:24:53 --> Config Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:24:53 --> URI Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Router Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Output Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Input Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:24:53 --> Language Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Loader Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Controller Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Model Class Initialized
DEBUG - 2011-07-15 02:24:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:24:53 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:24:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:24:53 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:24:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:24:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:24:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:24:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:24:53 --> Final output sent to browser
DEBUG - 2011-07-15 02:24:53 --> Total execution time: 0.5292
DEBUG - 2011-07-15 02:25:02 --> Config Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:25:02 --> URI Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Router Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Output Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Input Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:25:02 --> Language Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Loader Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Controller Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:25:02 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:25:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:25:03 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:25:03 --> Final output sent to browser
DEBUG - 2011-07-15 02:25:03 --> Total execution time: 0.7316
DEBUG - 2011-07-15 02:25:12 --> Config Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:25:12 --> URI Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Router Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Output Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Input Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:25:12 --> Language Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Loader Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Controller Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:25:12 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:25:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:25:13 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:25:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:25:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:25:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:25:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:25:13 --> Final output sent to browser
DEBUG - 2011-07-15 02:25:13 --> Total execution time: 0.5905
DEBUG - 2011-07-15 02:25:27 --> Config Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:25:27 --> URI Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Router Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Output Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Input Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:25:27 --> Language Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Loader Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Controller Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Model Class Initialized
DEBUG - 2011-07-15 02:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:25:27 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:25:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:25:27 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:25:27 --> Final output sent to browser
DEBUG - 2011-07-15 02:25:27 --> Total execution time: 0.0525
DEBUG - 2011-07-15 02:26:38 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:38 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:38 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:38 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:38 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:38 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:38 --> Total execution time: 0.0919
DEBUG - 2011-07-15 02:26:39 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:39 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:39 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:39 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:39 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:39 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:39 --> Total execution time: 0.0662
DEBUG - 2011-07-15 02:26:43 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:43 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:43 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:43 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:43 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:43 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:43 --> Total execution time: 0.0853
DEBUG - 2011-07-15 02:26:44 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:44 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:44 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:44 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:44 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:44 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:44 --> Total execution time: 0.0903
DEBUG - 2011-07-15 02:26:46 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:46 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:46 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:46 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:46 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:46 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:46 --> Total execution time: 0.0721
DEBUG - 2011-07-15 02:26:47 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:47 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:47 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:47 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:47 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:47 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:47 --> Total execution time: 0.1448
DEBUG - 2011-07-15 02:26:49 --> Config Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Hooks Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Utf8 Class Initialized
DEBUG - 2011-07-15 02:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 02:26:49 --> URI Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Router Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Output Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Input Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 02:26:49 --> Language Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Loader Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Controller Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Model Class Initialized
DEBUG - 2011-07-15 02:26:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 02:26:49 --> Database Driver Class Initialized
DEBUG - 2011-07-15 02:26:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 02:26:49 --> Helper loaded: url_helper
DEBUG - 2011-07-15 02:26:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 02:26:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 02:26:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 02:26:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 02:26:49 --> Final output sent to browser
DEBUG - 2011-07-15 02:26:49 --> Total execution time: 0.0495
DEBUG - 2011-07-15 03:23:43 --> Config Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Hooks Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Utf8 Class Initialized
DEBUG - 2011-07-15 03:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 03:23:43 --> URI Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Router Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Output Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Input Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 03:23:43 --> Language Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Loader Class Initialized
DEBUG - 2011-07-15 03:23:43 --> Controller Class Initialized
ERROR - 2011-07-15 03:23:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 03:23:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 03:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 03:23:44 --> Model Class Initialized
DEBUG - 2011-07-15 03:23:44 --> Model Class Initialized
DEBUG - 2011-07-15 03:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 03:23:44 --> Database Driver Class Initialized
DEBUG - 2011-07-15 03:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 03:23:44 --> Helper loaded: url_helper
DEBUG - 2011-07-15 03:23:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 03:23:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 03:23:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 03:23:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 03:23:44 --> Final output sent to browser
DEBUG - 2011-07-15 03:23:44 --> Total execution time: 1.0863
DEBUG - 2011-07-15 03:23:47 --> Config Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Hooks Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Utf8 Class Initialized
DEBUG - 2011-07-15 03:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 03:23:47 --> URI Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Router Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Output Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Input Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 03:23:47 --> Language Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Loader Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Controller Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Model Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Model Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 03:23:47 --> Database Driver Class Initialized
DEBUG - 2011-07-15 03:23:47 --> Final output sent to browser
DEBUG - 2011-07-15 03:23:47 --> Total execution time: 0.7191
DEBUG - 2011-07-15 03:23:49 --> Config Class Initialized
DEBUG - 2011-07-15 03:23:49 --> Hooks Class Initialized
DEBUG - 2011-07-15 03:23:49 --> Utf8 Class Initialized
DEBUG - 2011-07-15 03:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 03:23:49 --> URI Class Initialized
DEBUG - 2011-07-15 03:23:49 --> Router Class Initialized
ERROR - 2011-07-15 03:23:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 04:10:12 --> Config Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:10:12 --> URI Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Router Class Initialized
DEBUG - 2011-07-15 04:10:12 --> No URI present. Default controller set.
DEBUG - 2011-07-15 04:10:12 --> Output Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Input Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:10:12 --> Language Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Loader Class Initialized
DEBUG - 2011-07-15 04:10:12 --> Controller Class Initialized
DEBUG - 2011-07-15 04:10:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-15 04:10:13 --> Helper loaded: url_helper
DEBUG - 2011-07-15 04:10:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 04:10:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 04:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 04:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 04:10:14 --> Final output sent to browser
DEBUG - 2011-07-15 04:10:14 --> Total execution time: 2.6004
DEBUG - 2011-07-15 04:42:30 --> Config Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:42:30 --> URI Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Router Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Output Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Input Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:42:30 --> Language Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Loader Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Controller Class Initialized
ERROR - 2011-07-15 04:42:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 04:42:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 04:42:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 04:42:30 --> Model Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Model Class Initialized
DEBUG - 2011-07-15 04:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 04:42:30 --> Database Driver Class Initialized
DEBUG - 2011-07-15 04:42:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 04:42:31 --> Helper loaded: url_helper
DEBUG - 2011-07-15 04:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 04:42:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 04:42:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 04:42:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 04:42:31 --> Final output sent to browser
DEBUG - 2011-07-15 04:42:31 --> Total execution time: 0.5312
DEBUG - 2011-07-15 04:42:33 --> Config Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:42:33 --> URI Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Router Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Output Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Input Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:42:33 --> Language Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Loader Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Controller Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Model Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Model Class Initialized
DEBUG - 2011-07-15 04:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 04:42:33 --> Database Driver Class Initialized
DEBUG - 2011-07-15 04:42:34 --> Final output sent to browser
DEBUG - 2011-07-15 04:42:34 --> Total execution time: 0.6347
DEBUG - 2011-07-15 04:42:36 --> Config Class Initialized
DEBUG - 2011-07-15 04:42:36 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:42:36 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:42:36 --> URI Class Initialized
DEBUG - 2011-07-15 04:42:36 --> Router Class Initialized
ERROR - 2011-07-15 04:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 04:43:19 --> Config Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:43:19 --> URI Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Router Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Output Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Input Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:43:19 --> Language Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Loader Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Controller Class Initialized
ERROR - 2011-07-15 04:43:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 04:43:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 04:43:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 04:43:19 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 04:43:19 --> Database Driver Class Initialized
DEBUG - 2011-07-15 04:43:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 04:43:19 --> Helper loaded: url_helper
DEBUG - 2011-07-15 04:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 04:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 04:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 04:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 04:43:19 --> Final output sent to browser
DEBUG - 2011-07-15 04:43:19 --> Total execution time: 0.0286
DEBUG - 2011-07-15 04:43:21 --> Config Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:43:21 --> URI Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Router Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Output Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Input Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:43:21 --> Language Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Loader Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Controller Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 04:43:21 --> Database Driver Class Initialized
DEBUG - 2011-07-15 04:43:21 --> Final output sent to browser
DEBUG - 2011-07-15 04:43:21 --> Total execution time: 0.5495
DEBUG - 2011-07-15 04:43:23 --> Config Class Initialized
DEBUG - 2011-07-15 04:43:23 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:43:23 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:43:23 --> URI Class Initialized
DEBUG - 2011-07-15 04:43:23 --> Router Class Initialized
ERROR - 2011-07-15 04:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 04:43:37 --> Config Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:43:37 --> URI Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Router Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Output Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Input Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:43:37 --> Language Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Loader Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Controller Class Initialized
ERROR - 2011-07-15 04:43:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 04:43:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 04:43:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 04:43:37 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 04:43:37 --> Database Driver Class Initialized
DEBUG - 2011-07-15 04:43:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 04:43:37 --> Helper loaded: url_helper
DEBUG - 2011-07-15 04:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 04:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 04:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 04:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 04:43:37 --> Final output sent to browser
DEBUG - 2011-07-15 04:43:37 --> Total execution time: 0.0276
DEBUG - 2011-07-15 04:43:39 --> Config Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:43:39 --> URI Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Router Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Output Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Input Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 04:43:39 --> Language Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Loader Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Controller Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Model Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 04:43:39 --> Database Driver Class Initialized
DEBUG - 2011-07-15 04:43:39 --> Final output sent to browser
DEBUG - 2011-07-15 04:43:39 --> Total execution time: 0.5616
DEBUG - 2011-07-15 04:43:41 --> Config Class Initialized
DEBUG - 2011-07-15 04:43:41 --> Hooks Class Initialized
DEBUG - 2011-07-15 04:43:41 --> Utf8 Class Initialized
DEBUG - 2011-07-15 04:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 04:43:41 --> URI Class Initialized
DEBUG - 2011-07-15 04:43:41 --> Router Class Initialized
ERROR - 2011-07-15 04:43:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 06:45:04 --> Config Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Hooks Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Utf8 Class Initialized
DEBUG - 2011-07-15 06:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 06:45:04 --> URI Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Router Class Initialized
ERROR - 2011-07-15 06:45:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-15 06:45:04 --> Config Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Hooks Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Utf8 Class Initialized
DEBUG - 2011-07-15 06:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 06:45:04 --> URI Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Router Class Initialized
DEBUG - 2011-07-15 06:45:04 --> Output Class Initialized
DEBUG - 2011-07-15 06:45:05 --> Input Class Initialized
DEBUG - 2011-07-15 06:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 06:45:05 --> Language Class Initialized
DEBUG - 2011-07-15 06:45:05 --> Loader Class Initialized
DEBUG - 2011-07-15 06:45:05 --> Controller Class Initialized
DEBUG - 2011-07-15 06:45:05 --> Model Class Initialized
DEBUG - 2011-07-15 06:45:06 --> Model Class Initialized
DEBUG - 2011-07-15 06:45:06 --> Model Class Initialized
DEBUG - 2011-07-15 06:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 06:45:06 --> Database Driver Class Initialized
DEBUG - 2011-07-15 06:45:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 06:45:07 --> Helper loaded: url_helper
DEBUG - 2011-07-15 06:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 06:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 06:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 06:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 06:45:07 --> Final output sent to browser
DEBUG - 2011-07-15 06:45:07 --> Total execution time: 2.7502
DEBUG - 2011-07-15 09:35:26 --> Config Class Initialized
DEBUG - 2011-07-15 09:35:26 --> Hooks Class Initialized
DEBUG - 2011-07-15 09:35:26 --> Utf8 Class Initialized
DEBUG - 2011-07-15 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 09:35:26 --> URI Class Initialized
DEBUG - 2011-07-15 09:35:26 --> Router Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Output Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Input Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 09:35:27 --> Language Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Loader Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Controller Class Initialized
ERROR - 2011-07-15 09:35:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 09:35:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 09:35:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 09:35:27 --> Model Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Model Class Initialized
DEBUG - 2011-07-15 09:35:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 09:35:28 --> Database Driver Class Initialized
DEBUG - 2011-07-15 09:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 09:35:28 --> Helper loaded: url_helper
DEBUG - 2011-07-15 09:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 09:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 09:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 09:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 09:35:28 --> Final output sent to browser
DEBUG - 2011-07-15 09:35:28 --> Total execution time: 2.2440
DEBUG - 2011-07-15 09:35:29 --> Config Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Hooks Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Utf8 Class Initialized
DEBUG - 2011-07-15 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 09:35:29 --> URI Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Router Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Output Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Input Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 09:35:29 --> Language Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Loader Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Controller Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Model Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Model Class Initialized
DEBUG - 2011-07-15 09:35:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 09:35:29 --> Database Driver Class Initialized
DEBUG - 2011-07-15 09:35:30 --> Final output sent to browser
DEBUG - 2011-07-15 09:35:30 --> Total execution time: 0.7033
DEBUG - 2011-07-15 09:35:32 --> Config Class Initialized
DEBUG - 2011-07-15 09:35:32 --> Hooks Class Initialized
DEBUG - 2011-07-15 09:35:32 --> Utf8 Class Initialized
DEBUG - 2011-07-15 09:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 09:35:32 --> URI Class Initialized
DEBUG - 2011-07-15 09:35:32 --> Router Class Initialized
ERROR - 2011-07-15 09:35:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 09:35:33 --> Config Class Initialized
DEBUG - 2011-07-15 09:35:33 --> Hooks Class Initialized
DEBUG - 2011-07-15 09:35:33 --> Utf8 Class Initialized
DEBUG - 2011-07-15 09:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 09:35:33 --> URI Class Initialized
DEBUG - 2011-07-15 09:35:33 --> Router Class Initialized
ERROR - 2011-07-15 09:35:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 10:03:29 --> Config Class Initialized
DEBUG - 2011-07-15 10:03:29 --> Hooks Class Initialized
DEBUG - 2011-07-15 10:03:29 --> Utf8 Class Initialized
DEBUG - 2011-07-15 10:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 10:03:29 --> URI Class Initialized
DEBUG - 2011-07-15 10:03:29 --> Router Class Initialized
ERROR - 2011-07-15 10:03:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-15 10:03:30 --> Config Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Hooks Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Utf8 Class Initialized
DEBUG - 2011-07-15 10:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 10:03:30 --> URI Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Router Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Output Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Input Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 10:03:30 --> Language Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Loader Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Controller Class Initialized
ERROR - 2011-07-15 10:03:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 10:03:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 10:03:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 10:03:30 --> Model Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Model Class Initialized
DEBUG - 2011-07-15 10:03:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 10:03:30 --> Database Driver Class Initialized
DEBUG - 2011-07-15 10:03:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 10:03:30 --> Helper loaded: url_helper
DEBUG - 2011-07-15 10:03:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 10:03:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 10:03:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 10:03:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 10:03:30 --> Final output sent to browser
DEBUG - 2011-07-15 10:03:30 --> Total execution time: 0.5993
DEBUG - 2011-07-15 10:03:31 --> Config Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Hooks Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Utf8 Class Initialized
DEBUG - 2011-07-15 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 10:03:31 --> URI Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Router Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Output Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Input Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 10:03:31 --> Language Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Loader Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Controller Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Model Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Model Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Model Class Initialized
DEBUG - 2011-07-15 10:03:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 10:03:31 --> Database Driver Class Initialized
DEBUG - 2011-07-15 10:03:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 10:03:31 --> Helper loaded: url_helper
DEBUG - 2011-07-15 10:03:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 10:03:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 10:03:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 10:03:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 10:03:31 --> Final output sent to browser
DEBUG - 2011-07-15 10:03:31 --> Total execution time: 0.5938
DEBUG - 2011-07-15 11:54:32 --> Config Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Hooks Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Utf8 Class Initialized
DEBUG - 2011-07-15 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 11:54:32 --> URI Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Router Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Output Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Input Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 11:54:32 --> Language Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Loader Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Controller Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Model Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Model Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Model Class Initialized
DEBUG - 2011-07-15 11:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 11:54:32 --> Database Driver Class Initialized
DEBUG - 2011-07-15 11:54:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 11:54:33 --> Helper loaded: url_helper
DEBUG - 2011-07-15 11:54:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 11:54:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 11:54:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 11:54:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 11:54:33 --> Final output sent to browser
DEBUG - 2011-07-15 11:54:33 --> Total execution time: 0.6348
DEBUG - 2011-07-15 11:54:34 --> Config Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Hooks Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Utf8 Class Initialized
DEBUG - 2011-07-15 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 11:54:34 --> URI Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Router Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Output Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Input Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 11:54:34 --> Language Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Loader Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Controller Class Initialized
ERROR - 2011-07-15 11:54:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 11:54:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 11:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 11:54:34 --> Model Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Model Class Initialized
DEBUG - 2011-07-15 11:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 11:54:34 --> Database Driver Class Initialized
DEBUG - 2011-07-15 11:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 11:54:34 --> Helper loaded: url_helper
DEBUG - 2011-07-15 11:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 11:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 11:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 11:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 11:54:34 --> Final output sent to browser
DEBUG - 2011-07-15 11:54:34 --> Total execution time: 0.0880
DEBUG - 2011-07-15 14:09:13 --> Config Class Initialized
DEBUG - 2011-07-15 14:09:13 --> Hooks Class Initialized
DEBUG - 2011-07-15 14:09:13 --> Utf8 Class Initialized
DEBUG - 2011-07-15 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 14:09:13 --> URI Class Initialized
DEBUG - 2011-07-15 14:09:13 --> Router Class Initialized
ERROR - 2011-07-15 14:09:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-15 14:27:45 --> Config Class Initialized
DEBUG - 2011-07-15 14:27:45 --> Hooks Class Initialized
DEBUG - 2011-07-15 14:27:45 --> Utf8 Class Initialized
DEBUG - 2011-07-15 14:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 14:27:45 --> URI Class Initialized
DEBUG - 2011-07-15 14:27:45 --> Router Class Initialized
ERROR - 2011-07-15 14:27:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-15 14:27:47 --> Config Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Hooks Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Utf8 Class Initialized
DEBUG - 2011-07-15 14:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 14:27:47 --> URI Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Router Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Output Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Input Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 14:27:47 --> Language Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Loader Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Controller Class Initialized
ERROR - 2011-07-15 14:27:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 14:27:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 14:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 14:27:47 --> Model Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Model Class Initialized
DEBUG - 2011-07-15 14:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 14:27:47 --> Database Driver Class Initialized
DEBUG - 2011-07-15 14:27:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 14:27:48 --> Helper loaded: url_helper
DEBUG - 2011-07-15 14:27:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 14:27:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 14:27:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 14:27:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 14:27:48 --> Final output sent to browser
DEBUG - 2011-07-15 14:27:48 --> Total execution time: 0.2963
DEBUG - 2011-07-15 14:51:38 --> Config Class Initialized
DEBUG - 2011-07-15 14:51:38 --> Hooks Class Initialized
DEBUG - 2011-07-15 14:51:38 --> Utf8 Class Initialized
DEBUG - 2011-07-15 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 14:51:38 --> URI Class Initialized
DEBUG - 2011-07-15 14:51:38 --> Router Class Initialized
DEBUG - 2011-07-15 14:51:38 --> Output Class Initialized
DEBUG - 2011-07-15 14:51:39 --> Input Class Initialized
DEBUG - 2011-07-15 14:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 14:51:39 --> Language Class Initialized
DEBUG - 2011-07-15 14:51:39 --> Loader Class Initialized
DEBUG - 2011-07-15 14:51:39 --> Controller Class Initialized
ERROR - 2011-07-15 14:51:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 14:51:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 14:51:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 14:51:39 --> Model Class Initialized
DEBUG - 2011-07-15 14:51:39 --> Model Class Initialized
DEBUG - 2011-07-15 14:51:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 14:51:39 --> Database Driver Class Initialized
DEBUG - 2011-07-15 14:51:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 14:51:39 --> Helper loaded: url_helper
DEBUG - 2011-07-15 14:51:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 14:51:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 14:51:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 14:51:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 14:51:39 --> Final output sent to browser
DEBUG - 2011-07-15 14:51:39 --> Total execution time: 1.0890
DEBUG - 2011-07-15 16:18:35 --> Config Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Hooks Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Utf8 Class Initialized
DEBUG - 2011-07-15 16:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 16:18:35 --> URI Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Router Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Output Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Input Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 16:18:35 --> Language Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Loader Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Controller Class Initialized
ERROR - 2011-07-15 16:18:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 16:18:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 16:18:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 16:18:35 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 16:18:35 --> Database Driver Class Initialized
DEBUG - 2011-07-15 16:18:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 16:18:35 --> Helper loaded: url_helper
DEBUG - 2011-07-15 16:18:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 16:18:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 16:18:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 16:18:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 16:18:35 --> Final output sent to browser
DEBUG - 2011-07-15 16:18:35 --> Total execution time: 0.4321
DEBUG - 2011-07-15 16:18:36 --> Config Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Hooks Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Utf8 Class Initialized
DEBUG - 2011-07-15 16:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 16:18:36 --> URI Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Router Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Output Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Input Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 16:18:36 --> Language Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Loader Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Controller Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 16:18:36 --> Database Driver Class Initialized
DEBUG - 2011-07-15 16:18:37 --> Final output sent to browser
DEBUG - 2011-07-15 16:18:37 --> Total execution time: 0.7999
DEBUG - 2011-07-15 16:18:38 --> Config Class Initialized
DEBUG - 2011-07-15 16:18:38 --> Hooks Class Initialized
DEBUG - 2011-07-15 16:18:38 --> Utf8 Class Initialized
DEBUG - 2011-07-15 16:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 16:18:38 --> URI Class Initialized
DEBUG - 2011-07-15 16:18:38 --> Router Class Initialized
ERROR - 2011-07-15 16:18:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 16:18:46 --> Config Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Hooks Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Utf8 Class Initialized
DEBUG - 2011-07-15 16:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 16:18:46 --> URI Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Router Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Output Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Input Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 16:18:46 --> Language Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Loader Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Controller Class Initialized
ERROR - 2011-07-15 16:18:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 16:18:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 16:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 16:18:46 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 16:18:46 --> Database Driver Class Initialized
DEBUG - 2011-07-15 16:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 16:18:46 --> Helper loaded: url_helper
DEBUG - 2011-07-15 16:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 16:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 16:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 16:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 16:18:46 --> Final output sent to browser
DEBUG - 2011-07-15 16:18:46 --> Total execution time: 0.0278
DEBUG - 2011-07-15 16:18:47 --> Config Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Hooks Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Utf8 Class Initialized
DEBUG - 2011-07-15 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 16:18:47 --> URI Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Router Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Output Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Input Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 16:18:47 --> Language Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Loader Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Controller Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Model Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 16:18:47 --> Database Driver Class Initialized
DEBUG - 2011-07-15 16:18:47 --> Final output sent to browser
DEBUG - 2011-07-15 16:18:47 --> Total execution time: 0.5560
DEBUG - 2011-07-15 16:18:48 --> Config Class Initialized
DEBUG - 2011-07-15 16:18:48 --> Hooks Class Initialized
DEBUG - 2011-07-15 16:18:48 --> Utf8 Class Initialized
DEBUG - 2011-07-15 16:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 16:18:48 --> URI Class Initialized
DEBUG - 2011-07-15 16:18:48 --> Router Class Initialized
ERROR - 2011-07-15 16:18:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:17:48 --> Config Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:17:48 --> URI Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Router Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Output Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Input Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:17:48 --> Language Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Loader Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Controller Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Model Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Model Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Model Class Initialized
DEBUG - 2011-07-15 18:17:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:17:48 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:17:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:17:49 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:17:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:17:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:17:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:17:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:17:49 --> Final output sent to browser
DEBUG - 2011-07-15 18:17:49 --> Total execution time: 0.6004
DEBUG - 2011-07-15 18:18:04 --> Config Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:18:04 --> URI Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Router Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Output Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Input Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:18:04 --> Language Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Loader Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Controller Class Initialized
ERROR - 2011-07-15 18:18:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 18:18:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 18:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 18:18:04 --> Model Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Model Class Initialized
DEBUG - 2011-07-15 18:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:18:04 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 18:18:04 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:18:04 --> Final output sent to browser
DEBUG - 2011-07-15 18:18:04 --> Total execution time: 0.0887
DEBUG - 2011-07-15 18:43:05 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:05 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Router Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Output Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Input Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:43:05 --> Language Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Loader Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Controller Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:43:05 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:43:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:43:05 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:43:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:43:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:43:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:43:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:43:05 --> Final output sent to browser
DEBUG - 2011-07-15 18:43:05 --> Total execution time: 0.2822
DEBUG - 2011-07-15 18:43:08 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:08 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:08 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:08 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:08 --> Router Class Initialized
ERROR - 2011-07-15 18:43:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:43:21 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:21 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Router Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Output Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Input Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:43:21 --> Language Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Loader Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Controller Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:43:21 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:43:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:43:21 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:43:21 --> Final output sent to browser
DEBUG - 2011-07-15 18:43:21 --> Total execution time: 0.2162
DEBUG - 2011-07-15 18:43:23 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:23 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Router Class Initialized
ERROR - 2011-07-15 18:43:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-15 18:43:23 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:23 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Router Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Output Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Input Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:43:23 --> Language Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Loader Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Controller Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:43:23 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:43:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:43:23 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:43:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:43:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:43:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:43:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:43:23 --> Final output sent to browser
DEBUG - 2011-07-15 18:43:23 --> Total execution time: 0.0745
DEBUG - 2011-07-15 18:43:23 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:23 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:23 --> Router Class Initialized
ERROR - 2011-07-15 18:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:43:37 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:37 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Router Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Output Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Input Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:43:37 --> Language Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Loader Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Controller Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:43:37 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:43:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:43:37 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:43:37 --> Final output sent to browser
DEBUG - 2011-07-15 18:43:37 --> Total execution time: 0.1946
DEBUG - 2011-07-15 18:43:38 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:38 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Router Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Output Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Input Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:43:38 --> Language Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Loader Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Controller Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:43:38 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:43:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:43:38 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:43:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:43:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:43:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:43:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:43:38 --> Final output sent to browser
DEBUG - 2011-07-15 18:43:38 --> Total execution time: 0.0627
DEBUG - 2011-07-15 18:43:38 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:38 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:38 --> Router Class Initialized
ERROR - 2011-07-15 18:43:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:43:50 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:50 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Router Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Output Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Input Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:43:50 --> Language Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Loader Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Controller Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Model Class Initialized
DEBUG - 2011-07-15 18:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:43:50 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:43:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:43:50 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:43:50 --> Final output sent to browser
DEBUG - 2011-07-15 18:43:50 --> Total execution time: 0.2006
DEBUG - 2011-07-15 18:43:52 --> Config Class Initialized
DEBUG - 2011-07-15 18:43:52 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:43:52 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:43:52 --> URI Class Initialized
DEBUG - 2011-07-15 18:43:52 --> Router Class Initialized
ERROR - 2011-07-15 18:43:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:44:03 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:03 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Router Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Output Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Input Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:44:03 --> Language Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Loader Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Controller Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:44:03 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:44:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:44:03 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:44:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:44:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:44:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:44:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:44:03 --> Final output sent to browser
DEBUG - 2011-07-15 18:44:03 --> Total execution time: 0.2363
DEBUG - 2011-07-15 18:44:04 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:04 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:04 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:04 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:04 --> Router Class Initialized
ERROR - 2011-07-15 18:44:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:44:12 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:12 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Router Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Output Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Input Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:44:12 --> Language Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Loader Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Controller Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:44:12 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:44:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:44:13 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:44:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:44:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:44:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:44:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:44:13 --> Final output sent to browser
DEBUG - 2011-07-15 18:44:13 --> Total execution time: 0.2189
DEBUG - 2011-07-15 18:44:14 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:14 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:14 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:14 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:14 --> Router Class Initialized
ERROR - 2011-07-15 18:44:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:44:27 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:27 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Router Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Output Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Input Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:44:27 --> Language Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Loader Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Controller Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:44:27 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:44:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:44:28 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:44:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:44:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:44:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:44:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:44:28 --> Final output sent to browser
DEBUG - 2011-07-15 18:44:28 --> Total execution time: 0.2162
DEBUG - 2011-07-15 18:44:29 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:29 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:29 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:29 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:29 --> Router Class Initialized
ERROR - 2011-07-15 18:44:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:44:41 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:41 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Router Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Output Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Input Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:44:41 --> Language Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Loader Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Controller Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:44:41 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:44:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:44:41 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:44:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:44:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:44:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:44:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:44:41 --> Final output sent to browser
DEBUG - 2011-07-15 18:44:41 --> Total execution time: 0.2218
DEBUG - 2011-07-15 18:44:42 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:42 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:42 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:42 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:42 --> Router Class Initialized
ERROR - 2011-07-15 18:44:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:44:51 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:51 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Router Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Output Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Input Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:44:51 --> Language Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Loader Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Controller Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Model Class Initialized
DEBUG - 2011-07-15 18:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:44:51 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:44:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:44:52 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:44:52 --> Final output sent to browser
DEBUG - 2011-07-15 18:44:52 --> Total execution time: 0.4661
DEBUG - 2011-07-15 18:44:53 --> Config Class Initialized
DEBUG - 2011-07-15 18:44:53 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:44:53 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:44:53 --> URI Class Initialized
DEBUG - 2011-07-15 18:44:53 --> Router Class Initialized
ERROR - 2011-07-15 18:44:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:45:09 --> Config Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:45:09 --> URI Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Router Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Output Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Input Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:45:09 --> Language Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Loader Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Controller Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Model Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Model Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Model Class Initialized
DEBUG - 2011-07-15 18:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:45:09 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:45:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:45:09 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:45:09 --> Final output sent to browser
DEBUG - 2011-07-15 18:45:09 --> Total execution time: 0.2326
DEBUG - 2011-07-15 18:45:11 --> Config Class Initialized
DEBUG - 2011-07-15 18:45:11 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:45:11 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:45:11 --> URI Class Initialized
DEBUG - 2011-07-15 18:45:11 --> Router Class Initialized
ERROR - 2011-07-15 18:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 18:45:20 --> Config Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:45:20 --> URI Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Router Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Output Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Input Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 18:45:20 --> Language Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Loader Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Controller Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Model Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Model Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Model Class Initialized
DEBUG - 2011-07-15 18:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 18:45:20 --> Database Driver Class Initialized
DEBUG - 2011-07-15 18:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 18:45:20 --> Helper loaded: url_helper
DEBUG - 2011-07-15 18:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 18:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 18:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 18:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 18:45:20 --> Final output sent to browser
DEBUG - 2011-07-15 18:45:20 --> Total execution time: 0.0446
DEBUG - 2011-07-15 18:45:22 --> Config Class Initialized
DEBUG - 2011-07-15 18:45:22 --> Hooks Class Initialized
DEBUG - 2011-07-15 18:45:22 --> Utf8 Class Initialized
DEBUG - 2011-07-15 18:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 18:45:22 --> URI Class Initialized
DEBUG - 2011-07-15 18:45:22 --> Router Class Initialized
ERROR - 2011-07-15 18:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 20:07:20 --> Config Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Hooks Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Utf8 Class Initialized
DEBUG - 2011-07-15 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 20:07:20 --> URI Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Router Class Initialized
DEBUG - 2011-07-15 20:07:20 --> No URI present. Default controller set.
DEBUG - 2011-07-15 20:07:20 --> Output Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Input Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 20:07:20 --> Language Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Loader Class Initialized
DEBUG - 2011-07-15 20:07:20 --> Controller Class Initialized
DEBUG - 2011-07-15 20:07:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-15 20:07:20 --> Helper loaded: url_helper
DEBUG - 2011-07-15 20:07:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 20:07:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 20:07:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 20:07:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 20:07:20 --> Final output sent to browser
DEBUG - 2011-07-15 20:07:20 --> Total execution time: 0.1744
DEBUG - 2011-07-15 20:07:22 --> Config Class Initialized
DEBUG - 2011-07-15 20:07:22 --> Hooks Class Initialized
DEBUG - 2011-07-15 20:07:22 --> Utf8 Class Initialized
DEBUG - 2011-07-15 20:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 20:07:22 --> URI Class Initialized
DEBUG - 2011-07-15 20:07:22 --> Router Class Initialized
ERROR - 2011-07-15 20:07:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 21:59:46 --> Config Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Hooks Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Utf8 Class Initialized
DEBUG - 2011-07-15 21:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 21:59:46 --> URI Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Router Class Initialized
DEBUG - 2011-07-15 21:59:46 --> No URI present. Default controller set.
DEBUG - 2011-07-15 21:59:46 --> Output Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Input Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 21:59:46 --> Language Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Loader Class Initialized
DEBUG - 2011-07-15 21:59:46 --> Controller Class Initialized
DEBUG - 2011-07-15 21:59:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-15 21:59:46 --> Helper loaded: url_helper
DEBUG - 2011-07-15 21:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 21:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 21:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 21:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 21:59:46 --> Final output sent to browser
DEBUG - 2011-07-15 21:59:46 --> Total execution time: 0.3147
DEBUG - 2011-07-15 22:56:23 --> Config Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:56:23 --> URI Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Router Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Output Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Input Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:56:23 --> Language Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Loader Class Initialized
DEBUG - 2011-07-15 22:56:23 --> Controller Class Initialized
ERROR - 2011-07-15 22:56:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 22:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 22:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:56:24 --> Model Class Initialized
DEBUG - 2011-07-15 22:56:24 --> Model Class Initialized
DEBUG - 2011-07-15 22:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:56:24 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:56:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:56:24 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:56:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:56:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:56:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:56:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:56:24 --> Final output sent to browser
DEBUG - 2011-07-15 22:56:24 --> Total execution time: 0.4501
DEBUG - 2011-07-15 22:57:41 --> Config Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:57:41 --> URI Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Router Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Output Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Input Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:57:41 --> Language Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Loader Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Controller Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Model Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Model Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Model Class Initialized
DEBUG - 2011-07-15 22:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:57:41 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 22:57:42 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:57:42 --> Final output sent to browser
DEBUG - 2011-07-15 22:57:42 --> Total execution time: 0.9122
DEBUG - 2011-07-15 22:57:44 --> Config Class Initialized
DEBUG - 2011-07-15 22:57:44 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:57:44 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:57:44 --> URI Class Initialized
DEBUG - 2011-07-15 22:57:44 --> Router Class Initialized
ERROR - 2011-07-15 22:57:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 22:57:51 --> Config Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:57:51 --> URI Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Router Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Output Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Input Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:57:51 --> Language Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Loader Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Controller Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Model Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Model Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Model Class Initialized
DEBUG - 2011-07-15 22:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:57:51 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:57:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-15 22:57:51 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:57:51 --> Final output sent to browser
DEBUG - 2011-07-15 22:57:51 --> Total execution time: 0.1010
DEBUG - 2011-07-15 22:57:53 --> Config Class Initialized
DEBUG - 2011-07-15 22:57:53 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:57:53 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:57:53 --> URI Class Initialized
DEBUG - 2011-07-15 22:57:53 --> Router Class Initialized
ERROR - 2011-07-15 22:57:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 22:58:09 --> Config Class Initialized
DEBUG - 2011-07-15 22:58:09 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:58:09 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:58:09 --> URI Class Initialized
DEBUG - 2011-07-15 22:58:09 --> Router Class Initialized
ERROR - 2011-07-15 22:58:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 22:58:13 --> Config Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:58:13 --> URI Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Router Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Output Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Input Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:58:13 --> Language Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Loader Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Controller Class Initialized
ERROR - 2011-07-15 22:58:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 22:58:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 22:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:58:13 --> Model Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Model Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:58:13 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:58:13 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:58:13 --> Final output sent to browser
DEBUG - 2011-07-15 22:58:13 --> Total execution time: 0.0345
DEBUG - 2011-07-15 22:58:13 --> Config Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:58:13 --> URI Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Router Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Output Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Input Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:58:13 --> Language Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Loader Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Controller Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Model Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Model Class Initialized
DEBUG - 2011-07-15 22:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:58:13 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:58:14 --> Final output sent to browser
DEBUG - 2011-07-15 22:58:14 --> Total execution time: 0.6786
DEBUG - 2011-07-15 22:58:15 --> Config Class Initialized
DEBUG - 2011-07-15 22:58:15 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:58:15 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:58:15 --> URI Class Initialized
DEBUG - 2011-07-15 22:58:15 --> Router Class Initialized
ERROR - 2011-07-15 22:58:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 22:59:21 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:21 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Router Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Output Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Input Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:59:21 --> Language Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Loader Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Controller Class Initialized
ERROR - 2011-07-15 22:59:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 22:59:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 22:59:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:59:21 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:59:21 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:59:22 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:59:22 --> Final output sent to browser
DEBUG - 2011-07-15 22:59:22 --> Total execution time: 0.6725
DEBUG - 2011-07-15 22:59:23 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:23 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Router Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Output Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Input Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:59:23 --> Language Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Loader Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Controller Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:59:23 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:59:24 --> Final output sent to browser
DEBUG - 2011-07-15 22:59:24 --> Total execution time: 0.5573
DEBUG - 2011-07-15 22:59:25 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:25 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:25 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:25 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:25 --> Router Class Initialized
ERROR - 2011-07-15 22:59:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 22:59:44 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:44 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Router Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Output Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Input Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:59:44 --> Language Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Loader Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Controller Class Initialized
ERROR - 2011-07-15 22:59:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 22:59:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 22:59:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:59:44 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:59:44 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:59:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:59:44 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:59:44 --> Final output sent to browser
DEBUG - 2011-07-15 22:59:44 --> Total execution time: 0.0281
DEBUG - 2011-07-15 22:59:45 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:45 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Router Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Output Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Input Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:59:45 --> Language Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Loader Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Controller Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:59:45 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:59:46 --> Final output sent to browser
DEBUG - 2011-07-15 22:59:46 --> Total execution time: 0.6300
DEBUG - 2011-07-15 22:59:47 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:47 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:47 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:47 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:47 --> Router Class Initialized
ERROR - 2011-07-15 22:59:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 22:59:54 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:54 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Router Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Output Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Input Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:59:54 --> Language Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Loader Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Controller Class Initialized
ERROR - 2011-07-15 22:59:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 22:59:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 22:59:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:59:54 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:59:54 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:59:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 22:59:54 --> Helper loaded: url_helper
DEBUG - 2011-07-15 22:59:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 22:59:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 22:59:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 22:59:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 22:59:54 --> Final output sent to browser
DEBUG - 2011-07-15 22:59:54 --> Total execution time: 0.0387
DEBUG - 2011-07-15 22:59:55 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:55 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Router Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Output Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Input Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 22:59:55 --> Language Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Loader Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Controller Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Model Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 22:59:55 --> Database Driver Class Initialized
DEBUG - 2011-07-15 22:59:55 --> Final output sent to browser
DEBUG - 2011-07-15 22:59:55 --> Total execution time: 0.6911
DEBUG - 2011-07-15 22:59:57 --> Config Class Initialized
DEBUG - 2011-07-15 22:59:57 --> Hooks Class Initialized
DEBUG - 2011-07-15 22:59:57 --> Utf8 Class Initialized
DEBUG - 2011-07-15 22:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 22:59:57 --> URI Class Initialized
DEBUG - 2011-07-15 22:59:57 --> Router Class Initialized
ERROR - 2011-07-15 22:59:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 23:00:57 --> Config Class Initialized
DEBUG - 2011-07-15 23:00:57 --> Hooks Class Initialized
DEBUG - 2011-07-15 23:00:57 --> Utf8 Class Initialized
DEBUG - 2011-07-15 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 23:00:57 --> URI Class Initialized
DEBUG - 2011-07-15 23:00:57 --> Router Class Initialized
ERROR - 2011-07-15 23:00:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-15 23:19:54 --> Config Class Initialized
DEBUG - 2011-07-15 23:19:54 --> Hooks Class Initialized
DEBUG - 2011-07-15 23:19:54 --> Utf8 Class Initialized
DEBUG - 2011-07-15 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 23:19:54 --> URI Class Initialized
DEBUG - 2011-07-15 23:19:54 --> Router Class Initialized
ERROR - 2011-07-15 23:19:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-15 23:20:01 --> Config Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Hooks Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Utf8 Class Initialized
DEBUG - 2011-07-15 23:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-15 23:20:01 --> URI Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Router Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Output Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Input Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-15 23:20:01 --> Language Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Loader Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Controller Class Initialized
ERROR - 2011-07-15 23:20:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-15 23:20:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-15 23:20:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 23:20:01 --> Model Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Model Class Initialized
DEBUG - 2011-07-15 23:20:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-15 23:20:01 --> Database Driver Class Initialized
DEBUG - 2011-07-15 23:20:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-15 23:20:01 --> Helper loaded: url_helper
DEBUG - 2011-07-15 23:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-15 23:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-15 23:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-15 23:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-15 23:20:01 --> Final output sent to browser
DEBUG - 2011-07-15 23:20:01 --> Total execution time: 0.0949
